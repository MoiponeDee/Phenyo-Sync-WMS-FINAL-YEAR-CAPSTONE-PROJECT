using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Auth;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Exercises OTP/trusted-device controls and protected help-media storage/access.
public sealed class PhaseA3SecurityHelpMediaTests
{
    [Fact]
    public void HelpCatalogContainsSubstantiveCrossSubsystemContent()
    {
        Assert.True(PhaseA3Catalog.HelpCategories.Count >= 8);
        Assert.True(PhaseA3Catalog.HelpTopics.Count >= 30);
        Assert.All(PhaseA3Catalog.HelpTopics, topic =>
        {
            Assert.True(topic.Body.Length >= 120);
            Assert.False(string.IsNullOrWhiteSpace(topic.Summary));
        });
    }

    [Fact]
    public void HelpCatalogSlugsAndContextRoutesAreUnique()
    {
        Assert.Equal(
            PhaseA3Catalog.HelpTopics.Count,
            PhaseA3Catalog.HelpTopics
                .Select(topic => topic.Slug)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count());
        Assert.Equal(
            PhaseA3Catalog.HelpContexts.Count,
            PhaseA3Catalog.HelpContexts
                .Select(mapping => $"{mapping.RoutePattern}|{mapping.ComponentKey}")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count());
    }

    [Fact]
    public void TwoFactorSettingsMatchApprovedSecurityDefaults()
    {
        var settings = PhaseA2Catalog.Settings.ToDictionary(
            setting => setting.Key,
            setting => setting.DefaultValue);

        Assert.Equal("5", settings[SystemSettingKeys.SecurityOtpLifetimeMinutes]);
        Assert.Equal("5", settings[SystemSettingKeys.SecurityOtpMaximumAttempts]);
        Assert.Equal("60", settings[SystemSettingKeys.SecurityOtpResendDelaySeconds]);
        Assert.Equal("5", settings[SystemSettingKeys.SecurityOtpMaximumResendsPerHour]);
        Assert.Equal("30", settings[SystemSettingKeys.SecurityTrustedDeviceDays]);
        Assert.Equal("10", settings[SystemSettingKeys.SecurityRecoveryCodeCount]);
    }

    [Fact]
    public void ProofAndMediaSettingsAreConfiguredSafely()
    {
        var settings = PhaseA2Catalog.Settings.ToDictionary(
            setting => setting.Key,
            setting => setting.DefaultValue);

        Assert.Equal("true", settings[
            SystemSettingKeys.DeliveryRequireProofImageForCompletion]);
        Assert.Equal("10", settings[
            SystemSettingKeys.FilesProofImageMaximumMb]);
        Assert.True(int.Parse(settings[
            SystemSettingKeys.FilesTrainingVideoMaximumMb]) >= 100);
    }

    [Fact]
    public void EveryBusinessRoleCanViewHelp()
    {
        foreach (var role in new[]
                 {
                     RoleCodes.OperationsManager,
                     RoleCodes.Admin,
                     RoleCodes.Packer,
                     RoleCodes.WarehouseManager,
                     RoleCodes.Driver,
                     RoleCodes.MarketBuyer
                 })
        {
            Assert.Contains(
                Permissions.Help.View,
                SecurityRoleMatrix.Assignments[role]);
        }
    }

    [Fact]
    public void HelpAdministrationRemainsWithTheAdministrator()
    {
        Assert.Contains(
            Permissions.Help.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.Contains(
            Permissions.HelpMedia.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.DoesNotContain(
            Permissions.Help.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.OperationsManager]);

        Assert.DoesNotContain(
            Permissions.Help.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
    }

    [Fact]
    public void A3ManagementControllersRequireAuthentication()
    {
        Assert.NotEmpty(typeof(HelpManagementController)
            .GetCustomAttributes(typeof(AuthorizeAttribute), true));
        Assert.NotEmpty(typeof(HelpMediaManagementController)
            .GetCustomAttributes(typeof(AuthorizeAttribute), true));
    }

    [Fact]
    public void TrustedDevicePersistsOnlyAHashNotARawToken()
    {
        var names = typeof(TrustedDevice)
            .GetProperties()
            .Select(property => property.Name)
            .ToArray();

        Assert.Contains(nameof(TrustedDevice.TokenHash), names);
        Assert.DoesNotContain("Token", names);
        Assert.DoesNotContain("RawToken", names);
    }

    [Fact]
    public void RecoveryCodePersistsOnlySaltedHashMaterial()
    {
        var names = typeof(UserRecoveryCode)
            .GetProperties()
            .Select(property => property.Name)
            .ToArray();

        Assert.Contains(nameof(UserRecoveryCode.CodeHash), names);
        Assert.DoesNotContain("Code", names);
        Assert.DoesNotContain("PlainTextCode", names);
    }

    [Fact]
    public void StoredFileNeverExposesAWebUrlOrPublicPath()
    {
        var names = typeof(StoredFile)
            .GetProperties()
            .Select(property => property.Name)
            .ToArray();

        Assert.Contains(nameof(StoredFile.StorageKey), names);
        Assert.DoesNotContain("PublicUrl", names);
        Assert.DoesNotContain("PhysicalPath", names);
    }

    [Fact]
    public void NoTrainingMediaIsSeededAsAPlaceholder()
    {
        Assert.Null(typeof(PhaseA3Catalog).GetProperty("HelpMedia"));
    }

    [Fact]
    public async Task OtpTrustedDeviceAndRecoverySecretsAreNeverStoredRaw()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();

        var role = new Role
        {
            RoleCode = RoleCodes.Admin,
            RoleName = "Admin",
            IsActive = true
        };
        var user = new User
        {
            Email = "otp@example.test",
            NormalizedEmail = "OTP@EXAMPLE.TEST",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Testing-123!"),
            FirstName = "OTP",
            LastName = "Tester",
            Status = "Active",
            Role = role
        };
        context.Add(user);
        await context.SaveChangesAsync();

        var email = new CapturingEmailService();
        var service = new TwoFactorService(
            context,
            new CatalogSettingProvider(),
            email,
            new NullAuditService());
        var challenge = await service.CreateChallengeAsync(
            user,
            "test-correlation",
            "127.0.0.1",
            "test-agent",
            CancellationToken.None);

        var storedChallenge = await context.UserOtpChallenges.SingleAsync();
        Assert.NotEqual(challenge.ChallengeToken, storedChallenge.ChallengeTokenHash);
        Assert.NotEqual(email.Otp, storedChallenge.OtpHash);

        var verified = await service.VerifyOtpAsync(
            challenge.ChallengeToken,
            email.Otp!,
            true,
            "Test browser",
            "test-agent",
            CancellationToken.None);

        Assert.Equal(10, verified.RecoveryCodes?.Count);
        Assert.False(string.IsNullOrWhiteSpace(verified.TrustedDeviceToken));
        Assert.DoesNotContain(
            await context.TrustedDevices.Select(item => item.TokenHash).ToListAsync(),
            value => value == verified.TrustedDeviceToken);
        Assert.DoesNotContain(
            await context.UserRecoveryCodes.Select(item => item.CodeHash).ToListAsync(),
            value => verified.RecoveryCodes!.Contains(value));
    }

    [Fact]
    public async Task PostResetTwoFactorAppliesOnceToWebButNeverBlocksMobile()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();

        const string password = "Testing-123!";
        var user = new User
        {
            Email = "postreset@example.test",
            NormalizedEmail = "POSTRESET@EXAMPLE.TEST",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
            FirstName = "Post-reset",
            LastName = "Tester",
            Status = "Active",
            RequireTwoFactorOnNextWebLogin = true,
            Role = new Role
            {
                RoleCode = RoleCodes.Driver,
                RoleName = "Driver",
                IsActive = true
            }
        };
        context.Add(user);
        await context.SaveChangesAsync();

        var email = new CapturingEmailService();
        var twoFactor = new TwoFactorService(
            context,
            new CatalogSettingProvider(),
            email,
            new NullAuditService());
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Jwt:Key"] = "test-only-signing-key-with-at-least-32-characters",
                ["Jwt:Issuer"] = "PhenyoSync.Tests",
                ["Jwt:Audience"] = "PhenyoSync.Tests"
            })
            .Build();
        var controller = new AuthController(
            context,
            new JwtService(configuration),
            email,
            configuration,
            new NullAuditService(),
            twoFactor,
            NullLogger<AuthController>.Instance)
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext()
            }
        };

        var mobile = await controller.Login(new LoginDto
        {
            Email = user.Email,
            Password = password,
            Client = AuthenticationClients.Mobile
        }, CancellationToken.None);
        Assert.IsType<AuthenticationResponse>(
            Assert.IsType<OkObjectResult>(mobile).Value);
        Assert.True(user.RequireTwoFactorOnNextWebLogin);
        Assert.Empty(context.UserOtpChallenges);

        var web = await controller.Login(new LoginDto
        {
            Email = user.Email,
            Password = password,
            Client = AuthenticationClients.Web
        }, CancellationToken.None);
        var challenge = Assert.IsType<TwoFactorChallengeResponse>(
            Assert.IsType<OkObjectResult>(web).Value);
        Assert.True(challenge.RequiresTwoFactor);
        Assert.True(user.RequireTwoFactorOnNextWebLogin);

        var wrongOtp = email.Otp == "000000" ? "000001" : "000000";
        var rejected = await controller.VerifyOtp(new VerifyOtpRequest
        {
            ChallengeToken = challenge.ChallengeToken,
            Otp = wrongOtp
        }, CancellationToken.None);
        Assert.IsNotType<OkObjectResult>(rejected);
        Assert.True(user.RequireTwoFactorOnNextWebLogin);

        var verified = await controller.VerifyOtp(new VerifyOtpRequest
        {
            ChallengeToken = challenge.ChallengeToken,
            Otp = email.Otp!
        }, CancellationToken.None);
        Assert.IsType<AuthenticationResponse>(
            Assert.IsType<OkObjectResult>(verified).Value);
        Assert.False(user.RequireTwoFactorOnNextWebLogin);

        var nextWebLogin = await controller.Login(new LoginDto
        {
            Email = user.Email,
            Password = password,
            Client = AuthenticationClients.Web
        }, CancellationToken.None);
        Assert.IsType<AuthenticationResponse>(
            Assert.IsType<OkObjectResult>(nextWebLogin).Value);
    }

    private sealed class CatalogSettingProvider : ISystemSettingProvider
    {
        public Task<int> GetIntAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(int.Parse(PhaseA2Catalog.GetSetting(key).DefaultValue));
        public Task<decimal> GetDecimalAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(decimal.Parse(PhaseA2Catalog.GetSetting(key).DefaultValue));
        public Task<bool> GetBooleanAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(bool.Parse(PhaseA2Catalog.GetSetting(key).DefaultValue));
        public Task<string> GetStringAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(PhaseA2Catalog.GetSetting(key).DefaultValue);
        public Task<string[]> GetStringArrayAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(Array.Empty<string>());
        public void Invalidate(string key) {}
        public void InvalidateAll() {}
    }

    private sealed class NullAuditService : IAuditService
    {
        public Task RecordAsync(
            AuditEvent auditEvent,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;
    }

    private sealed class CapturingEmailService : IEmailService
    {
        public string? Otp { get; private set; }

        public Task SendPasswordResetEmailAsync(
            string recipientEmail,
            string resetLink) =>
            Task.CompletedTask;
        public Task SendExpiryAlertEmailAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string reviewLink,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;
        public Task SendExpiryDecisionConfirmationAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string decision,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;
        public Task SendCustomerOrderLinkEmailAsync(
            string recipientEmail,
            string customerName,
            string orderLink,
            DateTime expiresAtUtc,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;
        public Task SendLoginOtpEmailAsync(
            string recipientEmail,
            string recipientName,
            string otp,
            DateTime expiresAtUtc,
            CancellationToken cancellationToken = default)
        {
            Otp = otp;
            return Task.CompletedTask;
        }
    }
}
