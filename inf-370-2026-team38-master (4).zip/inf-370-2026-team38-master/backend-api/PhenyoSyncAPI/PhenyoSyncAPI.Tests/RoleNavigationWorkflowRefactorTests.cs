using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Protects the final role/navigation matrix and Track Driver separation from Driver execution.
public sealed class RoleNavigationWorkflowRefactorTests
{
    [Fact]
    public void RoleNormalizationMapsLegacyAssignmentsToTheRevisedRoles()
    {
        Assert.Equal(
            RoleCodes.WarehouseManager,
            RoleCodes.Normalize(RoleCodes.LegacyStockTaker));
        Assert.Equal(
            RoleCodes.OperationsManager,
            RoleCodes.Normalize(RoleCodes.LegacyCeo));
        Assert.Equal(
            RoleCodes.OperationsManager,
            RoleCodes.Normalize(RoleCodes.LegacyCoo));
    }

    [Fact]
    public void EveryRevisedRoleReceivesDashboardAndHelpAccess()
    {
        foreach (var role in RoleCodes.SystemRoles)
        {
            var permissions = SecurityRoleMatrix.Assignments[role];
            Assert.Contains(Permissions.Dashboards.View, permissions);
            Assert.Contains(Permissions.Help.View, permissions);
        }
    }

    [Fact]
    public async Task AdministratorDashboardUsesDatabaseBackedRoleContent()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        context.AuditLogs.Add(new PhenyoSyncAPI.Entities.AuditLog
        {
            OccurredAtUtc = DateTime.UtcNow.AddMinutes(-5),
            ActorType = "User",
            ActionType = "Update",
            SystemModule = "Security",
            OperationName = "Update user access",
            EntityDisplay = "User #8",
            UserDisplayNameSnapshot = "System administrator",
            Description = "User access was updated.",
            Success = true,
            CorrelationId = Guid.NewGuid().ToString("N"),
            EventSource = "API"
        });
        await context.SaveChangesAsync();
        var service = new RoleDashboardService(context);

        var dashboard = await service.GetAsync(
            1,
            RoleCodes.Admin,
            DateTime.UtcNow.AddDays(-7),
            DateTime.UtcNow,
            CancellationToken.None);

        Assert.Equal(RoleCodes.Admin, dashboard.RoleCode);
        Assert.Equal("Administrator dashboard", dashboard.Title);
        Assert.Collection(
            dashboard.Metrics,
            metric => Assert.Equal("Awaiting order decision", metric.Label),
            metric => Assert.Equal("Active customers", metric.Label),
            metric => Assert.Equal("Products without a current price", metric.Label),
            metric => Assert.Equal("Active users", metric.Label));
        Assert.Equal("Customer orders by status", dashboard.BarChart.Title);
        Assert.Equal("Customer orders", dashboard.LineChart.Title);
        Assert.Contains(
            dashboard.AttentionItems,
            item => item.Label == "Open buying lists" && item.Route == "/buying-lists");
        var activity = Assert.Single(dashboard.RecentActivity);
        Assert.Equal("Update user access", activity.OperationName);
        Assert.Equal("System administrator", activity.ActorDisplayName);
    }

    [Fact]
    public async Task DashboardRejectsAnInvalidPeriodBeforeQueryingBusinessData()
    {
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite("Data Source=:memory:")
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        var service = new RoleDashboardService(context);

        var error = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.GetAsync(
                1,
                RoleCodes.WarehouseManager,
                DateTime.UtcNow,
                DateTime.UtcNow.AddDays(-1),
                CancellationToken.None));

        Assert.Equal(400, error.StatusCode);
    }

    [Theory]
    [InlineData(RoleCodes.WarehouseManager, "Warehouse Manager dashboard", "Raw-stock items")]
    [InlineData(RoleCodes.OperationsManager, "Operations Manager dashboard", "Orders this period")]
    public async Task OperationalDashboardsExposeRealKpisAttentionAndRecentActivity(
        string roleCode,
        string expectedTitle,
        string expectedMetric)
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        context.AuditLogs.Add(new PhenyoSyncAPI.Entities.AuditLog
        {
            OccurredAtUtc = DateTime.UtcNow.AddMinutes(-2),
            ActorType = "User",
            ActionType = "Update",
            SystemModule = roleCode == RoleCodes.WarehouseManager
                ? "RawStock"
                : "OrderManagement",
            OperationName = "Operational test activity",
            EntityDisplay = "Record #1",
            UserDisplayNameSnapshot = "Authorised operator",
            Description = "An operational record changed.",
            Success = true,
            CorrelationId = Guid.NewGuid().ToString("N"),
            EventSource = "API"
        });
        await context.SaveChangesAsync();
        var service = new RoleDashboardService(context);

        var dashboard = await service.GetAsync(
            1,
            roleCode,
            DateTime.UtcNow.AddDays(-7),
            DateTime.UtcNow,
            CancellationToken.None);

        Assert.Equal(expectedTitle, dashboard.Title);
        Assert.Contains(dashboard.Metrics, item => item.Label == expectedMetric);
        Assert.NotEmpty(dashboard.RecentActivity);
        Assert.All(dashboard.Metrics, item => Assert.NotNull(item.Route));
        if (roleCode == RoleCodes.OperationsManager)
        {
            Assert.Equal(
                [
                    "stock takes await approval",
                    "payment reversals await approval",
                    "write-offs await approval",
                    "orders need management follow-up",
                    "deliveries need assignment"
                ],
                dashboard.AttentionItems.Select(item => item.Label).ToArray());
            Assert.Contains(
                dashboard.Metrics,
                item => item.Label == "Pending stock-take approvals" &&
                        item.Route == "/raw-stock/approvals?tab=takes");
        }
    }
}

