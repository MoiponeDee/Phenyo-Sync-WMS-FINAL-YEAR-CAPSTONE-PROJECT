using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Exercises order lifecycle, stock reservation/deduction idempotency and invalid transitions.
public sealed class Subsystem10OrderTests
{
    [Fact]
    public async Task LegacyPendingValidationOrder_IsProjectedAndDecidedAsSubmitted()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var created = await db.Orders.CreateAsync(
            db.AdminRequest(30m),
            db.Manager.UserId,
            null,
            default);
        var persisted = await db.Context.SalesOrders.SingleAsync(item =>
            item.SalesOrderId == created.SalesOrderId);
        persisted.Status = SalesOrderStatuses.LegacyPendingValidation;
        await db.Context.SaveChangesAsync();

        var detail = await db.Orders.GetAsync(created.SalesOrderId, default);
        var search = await db.Orders.SearchAsync(
            new OrderSearchQueryDto
            {
                Status = SalesOrderStatuses.Submitted,
                Page = 1,
                PageSize = 20
            },
            default);

        Assert.Equal(SalesOrderStatuses.Submitted, detail.Status);
        var summary = Assert.Single(search.Items);
        Assert.Equal(SalesOrderStatuses.Submitted, summary.Status);
        Assert.True(summary.CanValidate);

        var approved = await db.Workflow.ApproveAsync(
            created.SalesOrderId,
            new OrderDecisionDto(),
            db.Manager.UserId,
            default);

        Assert.Equal(SalesOrderStatuses.Approved, approved.Status);
        Assert.Equal(OrderValidationStatuses.Approved, approved.ValidationStatus);
    }

    [Fact]
    public async Task OrderLink_IsUniqueHashedAndValidationDoesNotMutate()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var first = await db.Links.SendAsync(db.Customer.CustomerId, db.Manager.UserId, default);
        var firstToken = db.Email.LastToken();
        var second = await db.Links.SendAsync(db.Customer.CustomerId, db.Manager.UserId, default);

        var stored = await db.Context.CustomerOrderLinks.OrderBy(item => item.CustomerOrderLinkId).ToListAsync();
        Assert.NotEqual(stored[0].TokenHash, stored[1].TokenHash);
        Assert.DoesNotContain(firstToken, stored[0].TokenHash);
        var before = stored[0].UsedAtUtc;
        var publicForm = await db.Links.ValidateAsync(firstToken, default);
        Assert.Equal(db.Customer.CustomerName, publicForm.CustomerName);
        Assert.Null(before);
        Assert.Null((await db.Context.CustomerOrderLinks.FindAsync(first.CustomerOrderLinkId))!.UsedAtUtc);
        Assert.Equal("Active", second.Status);
    }

    [Fact]
    public async Task PublicLink_CreatesExactlyOneOrderForBoundCustomer()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await db.Links.SendAsync(db.Customer.CustomerId, db.Manager.UserId, default);
        var token = db.Email.LastToken();
        var order = await db.Links.SubmitAsync(db.PublicRequest(token, 2m), default);

        Assert.Equal(db.Customer.CustomerId, order.CustomerId);
        Assert.Equal(20m, order.TotalAmount);
        Assert.Equal(1, await db.Context.SalesOrders.CountAsync());
        var exception = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Links.SubmitAsync(db.PublicRequest(token, 1m), default));
        Assert.Equal(409, exception.StatusCode);
    }

    [Fact]
    public async Task InvalidOrInactiveCustomer_PreventsLinkAndOrderCreation()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        db.Customer.Status = CustomerStatuses.Inactive;
        await db.Context.SaveChangesAsync();

        var linkError = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Links.SendAsync(db.Customer.CustomerId, db.Manager.UserId, default));
        var orderError = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Orders.CreateAsync(db.AdminRequest(1m), db.Manager.UserId, null, default));
        Assert.Equal(400, linkError.StatusCode);
        Assert.Equal(400, orderError.StatusCode);
    }

    [Fact]
    public async Task OrderCreation_RejectsDuplicateProductLines()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var request = db.AdminRequest(2m);
        request.Items.Add(new OrderItemRequestDto { ProductId = db.Product.ProductId, QuantityKg = 3m });
        var exception = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Orders.CreateAsync(request, db.Manager.UserId, null, default));

        Assert.Equal(400, exception.StatusCode);
        Assert.Empty(await db.Context.SalesOrders.ToListAsync());
    }

    [Fact]
    public async Task OrderCreation_PersistsThreeIndependentServerPricedLines()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var second = await db.AddOrderableProductAsync("Second Product", 6m);
        var third = await db.AddOrderableProductAsync("Third Product", 4m);
        var request = db.AdminRequest(2m);
        request.Items.Add(new OrderItemRequestDto
        {
            ProductId = second.ProductId,
            QuantityKg = 3m
        });
        request.Items.Add(new OrderItemRequestDto
        {
            ProductId = third.ProductId,
            QuantityKg = 5m
        });

        var order = await db.Orders.CreateAsync(
            request,
            db.Manager.UserId,
            null,
            default);

        Assert.Equal(3, order.Items.Count);
        Assert.Equal(58m, order.TotalAmount);
        Assert.Equal(
            new[] { db.Product.ProductId, second.ProductId, third.ProductId },
            order.Items.Select(item => item.ProductId).ToArray());
    }

    [Fact]
    public async Task OrderCreation_PersistsTwoIndependentLines()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var second = await db.AddOrderableProductAsync("Second Product", 6m);
        var request = db.AdminRequest(1m);
        request.Items.Add(new OrderItemRequestDto
        {
            ProductId = second.ProductId,
            QuantityKg = 2m
        });

        var order = await db.Orders.CreateAsync(
            request,
            db.Manager.UserId,
            null,
            default);

        Assert.Equal(2, order.Items.Count);
        Assert.Equal(22m, order.TotalAmount);
    }

    [Fact]
    public async Task InvalidThirdLineRollsBackTheEntireOrder()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var second = await db.AddOrderableProductAsync("Second Product", 6m);
        var inactive = await db.AddOrderableProductAsync(
            "Inactive Product",
            4m,
            ProductStatuses.Inactive);
        var request = db.AdminRequest(1m);
        request.Items.Add(new OrderItemRequestDto
        {
            ProductId = second.ProductId,
            QuantityKg = 1m
        });
        request.Items.Add(new OrderItemRequestDto
        {
            ProductId = inactive.ProductId,
            QuantityKg = 1m
        });

        var exception = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Orders.CreateAsync(
                request,
                db.Manager.UserId,
                null,
                default));

        Assert.Equal(400, exception.StatusCode);
        Assert.Empty(await db.Context.SalesOrders.ToListAsync());
        Assert.Empty(await db.Context.SalesOrderItems.ToListAsync());
    }

    [Fact]
    public async Task Validation_UsesFefoAndSplitsAcrossBatches()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var early = await db.AddBatchAsync(2m, DateTime.UtcNow.AddDays(2));
        var later = await db.AddBatchAsync(5m, DateTime.UtcNow.AddDays(5));
        var order = await db.Orders.CreateAsync(db.AdminRequest(6m), db.Manager.UserId, null, default);

        var result = await db.Stock.ValidateAndReserveAsync(order.SalesOrderId, db.Manager.UserId, default);

        Assert.True(result.Approved);
        Assert.Equal(2, result.Reservations.Count);
        Assert.Equal(early.ProductBatchId, result.Reservations[0].ProductBatchId);
        Assert.Equal(2m, result.Reservations[0].QuantityReservedKg);
        Assert.Equal(later.ProductBatchId, result.Reservations[1].ProductBatchId);
        Assert.Equal(4m, result.Reservations[1].QuantityReservedKg);
        Assert.Equal(7m, (await db.Context.Stocks.SingleAsync()).QuantityAvailableKg);
    }

    [Fact]
    public async Task Validation_DoesNotReserveBeyondAggregateStockInvariant()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await db.AddBatchAsync(5m, DateTime.UtcNow.AddDays(2));
        var aggregate = await db.Context.Stocks.SingleAsync();
        aggregate.QuantityAvailableKg = 1m;
        await db.Context.SaveChangesAsync();
        var order = await db.Orders.CreateAsync(db.AdminRequest(2m), db.Manager.UserId, null, default);

        var result = await db.Stock.ValidateAndReserveAsync(order.SalesOrderId, db.Manager.UserId, default);

        Assert.False(result.Approved);
        Assert.Equal(1m, Assert.Single(result.Shortages).AvailableQuantityKg);
        Assert.DoesNotContain(
            await db.Context.OrderStockReservations.ToListAsync(),
            item => item.Status == OrderReservationStatuses.Active);
    }

    [Fact]
    public async Task WarehouseReadinessRequiresCommercialApproval()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await db.AddBatchAsync(5m, DateTime.UtcNow.AddDays(2));
        var order = await db.Orders.CreateAsync(
            db.AdminRequest(2m),
            db.Manager.UserId,
            null,
            default);

        var exception = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Stock.ValidateApprovedAndReserveAsync(
                order.SalesOrderId,
                db.Manager.UserId,
                default));

        Assert.Equal(409, exception.StatusCode);
        var persisted = await db.Context.SalesOrders.SingleAsync(item =>
            item.SalesOrderId == order.SalesOrderId);
        Assert.Equal(SalesOrderStatuses.Submitted, persisted.Status);
        Assert.Empty(await db.Context.OrderStockReservations.ToListAsync());
    }

    [Fact]
    public async Task Validation_ReservesEveryLineWhenAllProductsHaveStock()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var second = await db.AddOrderableProductAsync("Second Product", 6m);
        await db.AddBatchAsync(db.Product, 3m, DateTime.UtcNow.AddDays(2));
        await db.AddBatchAsync(second, 4m, DateTime.UtcNow.AddDays(3));
        var request = db.AdminRequest(2m);
        request.Items.Add(new OrderItemRequestDto
        {
            ProductId = second.ProductId,
            QuantityKg = 3m
        });
        var order = await db.Orders.CreateAsync(
            request,
            db.Manager.UserId,
            null,
            default);

        var result = await db.Stock.ValidateAndReserveAsync(
            order.SalesOrderId,
            db.Manager.UserId,
            default);

        Assert.True(result.Approved);
        Assert.Equal(2, result.Reservations.Count);
        Assert.All(result.Reservations, item =>
            Assert.Equal(OrderReservationStatuses.Active, item.Status));
    }

    [Fact]
    public async Task Validation_LeavesNoReservationsWhenOneOfSeveralLinesIsShort()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var second = await db.AddOrderableProductAsync("Second Product", 6m);
        await db.AddBatchAsync(db.Product, 3m, DateTime.UtcNow.AddDays(2));
        await db.AddBatchAsync(second, 1m, DateTime.UtcNow.AddDays(3));
        var request = db.AdminRequest(2m);
        request.Items.Add(new OrderItemRequestDto
        {
            ProductId = second.ProductId,
            QuantityKg = 3m
        });
        var order = await db.Orders.CreateAsync(
            request,
            db.Manager.UserId,
            null,
            default);

        var result = await db.Stock.ValidateAndReserveAsync(
            order.SalesOrderId,
            db.Manager.UserId,
            default);

        Assert.False(result.Approved);
        Assert.Empty(await db.Context.OrderStockReservations.ToListAsync());
    }

    [Fact]
    public async Task Validation_RejectsInsufficientOrExpiredStockWithoutPartialReservations()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await db.AddBatchAsync(2m, DateTime.UtcNow.AddHours(-1), ProductBatchStatuses.ExpiredPendingDecision);
        await db.AddBatchAsync(1m, DateTime.UtcNow.AddDays(2));
        var order = await db.Orders.CreateAsync(db.AdminRequest(4m), db.Manager.UserId, null, default);

        var result = await db.Stock.ValidateAndReserveAsync(order.SalesOrderId, db.Manager.UserId, default);

        Assert.False(result.Approved);
        Assert.Single(result.Shortages);
        Assert.Equal(3m, result.Shortages[0].ShortageQuantityKg);
        Assert.Empty(await db.Context.OrderStockReservations.Where(item => item.Status == OrderReservationStatuses.Active).ToListAsync());
    }

    [Fact]
    public async Task CommercialApprovalKeepsShortOrderActiveForProcurementDemand()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var order = await db.Orders.CreateAsync(
            db.AdminRequest(4m),
            db.Manager.UserId,
            null,
            default);

        var approved = await db.Workflow.ApproveAsync(
            order.SalesOrderId,
            new OrderDecisionDto
            {
                Reason = "Customer account and commercial terms approved."
            },
            db.Manager.UserId,
            default);
        var readiness = await db.Stock.ValidateAndReserveAsync(
            order.SalesOrderId,
            db.Manager.UserId,
            default);

        Assert.Equal(SalesOrderStatuses.Approved, approved.Status);
        Assert.False(readiness.Approved);
        Assert.NotEmpty(readiness.Shortages);
        var persisted = await db.Context.SalesOrders.SingleAsync(item =>
            item.SalesOrderId == order.SalesOrderId);
        Assert.Equal(SalesOrderStatuses.Approved, persisted.Status);
        Assert.Equal(OrderValidationStatuses.Approved, persisted.ValidationStatus);
    }

    [Fact]
    public async Task CommercialDecision_AllowsEmptyReasonAndRecordsAccurateAuditText()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var acceptedOrder = await db.Orders.CreateAsync(db.AdminRequest(2m), db.Manager.UserId, null, default);
        var deniedOrder = await db.Orders.CreateAsync(db.AdminRequest(1m), db.Manager.UserId, null, default);

        var accepted = await db.Workflow.ApproveAsync(
            acceptedOrder.SalesOrderId,
            new OrderDecisionDto(),
            db.Manager.UserId,
            default);
        var denied = await db.Workflow.RejectAsync(
            deniedOrder.SalesOrderId,
            new OrderDecisionDto { Reason = "   " },
            db.Manager.UserId,
            default);

        Assert.Equal(SalesOrderStatuses.Approved, accepted.Status);
        Assert.Equal("Order accepted.", accepted.StatusHistory[0].Reason);
        Assert.Equal(SalesOrderStatuses.Rejected, denied.Status);
        Assert.Equal("Order denied.", denied.StatusHistory[0].Reason);
    }

    [Fact]
    public async Task SubmittedAndDeniedOrdersCannotBeCancelled()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var order = await db.Orders.CreateAsync(db.AdminRequest(1m), db.Manager.UserId, null, default);
        var request = new CancelOrderDto
        {
            Confirmed = true,
            ConfirmationText = order.OrderNumber,
            Reason = "Customer request"
        };

        var submittedError = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Workflow.CancelAsync(order.SalesOrderId, request, db.Manager.UserId, default));
        await db.Workflow.RejectAsync(order.SalesOrderId, new OrderDecisionDto(), db.Manager.UserId, default);
        var deniedError = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Workflow.CancelAsync(order.SalesOrderId, request, db.Manager.UserId, default));

        Assert.Equal(409, submittedError.StatusCode);
        Assert.Equal(409, deniedError.StatusCode);
    }

    [Fact]
    public async Task PackagedOrder_ConvertsUnitsToKilogramsAndSnapshotsCommercialMeaning()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        db.Product.SellingUnit = "bag";
        db.Product.KilogramsPerUnit = 10m;
        db.Product.IsVariableWeight = false;
        await db.Context.SaveChangesAsync();

        var order = await db.Orders.CreateAsync(new CreateSalesOrderDto
        {
            CustomerId = db.Customer.CustomerId,
            DeliveryAddress = "10 Test Avenue",
            BillingAddress = "10 Test Avenue",
            Items = [new OrderItemRequestDto
            {
                ProductId = db.Product.ProductId,
                QuantityUnits = 3m
            }]
        }, db.Manager.UserId, null, default);

        var line = Assert.Single(order.Items);
        Assert.Equal(3m, line.QuantityUnits);
        Assert.Equal("bag", line.SellingUnit);
        Assert.Equal(10m, line.KilogramsPerUnit);
        Assert.Equal(30m, line.QuantityKg);
        Assert.Equal(100m, line.UnitPrice);
        Assert.Equal(300m, line.LineTotal);

        db.Product.KilogramsPerUnit = 5m;
        db.Product.SellingPricePerKg = 20m;
        await db.Context.SaveChangesAsync();
        var historical = await db.Orders.GetAsync(order.SalesOrderId, default);
        Assert.Equal(30m, historical.Items.Single().QuantityKg);
        Assert.Equal(100m, historical.Items.Single().UnitPrice);
        Assert.Equal(300m, historical.Subtotal);
    }

    [Fact]
    public async Task PerUnitPackagedOrderWithoutWeight_PreservesCountAndUnknownDerivedWeight()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        db.Product.SellingUnit = "box";
        db.Product.KilogramsPerUnit = null;
        db.Product.IsVariableWeight = false;
        var currentPrice = await db.Context.ProductPrices.SingleAsync(item =>
            item.ProductId == db.Product.ProductId && item.IsCurrent);
        currentPrice.PriceBasis = ProductPriceBases.PerSellableUnit;
        await db.Context.SaveChangesAsync();

        var order = await db.Orders.CreateAsync(new CreateSalesOrderDto
        {
            CustomerId = db.Customer.CustomerId,
            DeliveryAddress = "10 Test Avenue",
            BillingAddress = "10 Test Avenue",
            Items = [new OrderItemRequestDto
            {
                ProductId = db.Product.ProductId,
                QuantityUnits = 2m
            }]
        }, db.Manager.UserId, null, default);

        var line = Assert.Single(order.Items);
        Assert.Equal(2m, line.QuantityUnits);
        Assert.Equal("box", line.SellingUnit);
        Assert.Null(line.KilogramsPerUnit);
        Assert.Null(line.QuantityKg);
        Assert.Null(line.UnitPricePerKg);
        Assert.Equal(ProductPriceBases.PerSellableUnit, line.PriceBasis);
        Assert.Equal(10m, line.UnitPrice);
        Assert.Equal(20m, line.LineTotal);

        var updated = await db.Orders.UpdateAsync(order.SalesOrderId, new UpdateSalesOrderDto
        {
            CustomerId = db.Customer.CustomerId,
            DeliveryAddress = order.DeliveryAddress,
            BillingAddress = order.BillingAddress,
            RowVersion = order.RowVersion,
            Items = [new OrderItemRequestDto
            {
                ProductId = db.Product.ProductId,
                QuantityUnits = 3m
            }]
        }, db.Manager.UserId, default);
        var reloaded = await db.Orders.GetAsync(order.SalesOrderId, default);

        Assert.Equal(3m, Assert.Single(updated.Items).QuantityUnits);
        Assert.Equal(3m, Assert.Single(reloaded.Items).QuantityUnits);
        Assert.Null(reloaded.Items[0].QuantityKg);
        Assert.Equal(30m, reloaded.Subtotal);
    }

    [Fact]
    public async Task PerKilogramPackagedOrderWithoutWeight_RequiresARealConversionOrPerUnitPrice()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        db.Product.SellingUnit = "box";
        db.Product.KilogramsPerUnit = null;
        db.Product.IsVariableWeight = false;
        await db.Context.SaveChangesAsync();

        var error = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Orders.CreateAsync(new CreateSalesOrderDto
            {
                CustomerId = db.Customer.CustomerId,
                DeliveryAddress = "10 Test Avenue",
                BillingAddress = "10 Test Avenue",
                Items = [new OrderItemRequestDto
                {
                    ProductId = db.Product.ProductId,
                    QuantityUnits = 2m
                }]
            }, db.Manager.UserId, null, default));

        Assert.Equal(409, error.StatusCode);
        Assert.Contains("per-unit price", error.Message, StringComparison.OrdinalIgnoreCase);
        Assert.Empty(await db.Context.SalesOrders.ToListAsync());
    }

    [Fact]
    public async Task VatSettingChangesNewCalculationsWithoutRewritingExistingOrders()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var existing = await db.Orders.CreateAsync(db.AdminRequest(10m), db.Manager.UserId, null, default);

        db.Settings.VatRatePercent = 15m;
        var newer = await db.Orders.CreateAsync(db.AdminRequest(10m), db.Manager.UserId, null, default);
        var unchanged = await db.Orders.GetAsync(existing.SalesOrderId, default);

        Assert.Equal(0m, unchanged.TaxRatePercent);
        Assert.Equal(0m, unchanged.TaxAmount);
        Assert.Equal(15m, newer.TaxRatePercent);
        Assert.Equal(15m, newer.TaxAmount);
        Assert.Equal(115m, newer.TotalAmount);
    }

    [Fact]
    public async Task RejectedOrderCannotReceiveASecondCommercialDecision()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var order = await db.Orders.CreateAsync(
            db.AdminRequest(2m),
            db.Manager.UserId,
            null,
            default);
        await db.Workflow.RejectAsync(
            order.SalesOrderId,
            new OrderDecisionDto
            {
                Reason = "Commercial terms were not accepted."
            },
            db.Manager.UserId,
            default);

        var exception = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Workflow.ApproveAsync(
                order.SalesOrderId,
                new OrderDecisionDto
                {
                    Reason = "Attempting to decide the rejected order again."
                },
                db.Manager.UserId,
                default));

        Assert.Equal(409, exception.StatusCode);
        Assert.Equal(
            SalesOrderStatuses.Rejected,
            (await db.Context.SalesOrders.FindAsync(order.SalesOrderId))!.Status);
    }

    [Fact]
    public async Task MaterialUpdate_ReleasesReservationsAndRequiresRevalidation()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await db.AddBatchAsync(8m, DateTime.UtcNow.AddDays(4));
        var order = await db.Orders.CreateAsync(db.AdminRequest(3m), db.Manager.UserId, null, default);
        await db.Stock.ValidateAndReserveAsync(order.SalesOrderId, db.Manager.UserId, default);
        var detail = await db.Orders.GetAsync(order.SalesOrderId, default);

        var update = db.AdminRequest(2m);
        var updated = await db.Orders.UpdateAsync(order.SalesOrderId, new UpdateSalesOrderDto
        {
            CustomerId = update.CustomerId,
            DeliveryAddress = update.DeliveryAddress,
            BillingAddress = update.BillingAddress,
            Items = update.Items,
            RowVersion = detail.RowVersion
        }, db.Manager.UserId, default);

        Assert.Equal(SalesOrderStatuses.Submitted, updated.Status);
        Assert.Equal(OrderValidationStatuses.Pending, updated.ValidationStatus);
        Assert.DoesNotContain(updated.Reservations, item => item.Status == OrderReservationStatuses.Active);
    }

    [Fact]
    public async Task Cancellation_ReleasesReservationsAndRecordsReason()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await db.AddBatchAsync(6m, DateTime.UtcNow.AddDays(4));
        var order = await db.Orders.CreateAsync(db.AdminRequest(3m), db.Manager.UserId, null, default);
        await db.Stock.ValidateAndReserveAsync(order.SalesOrderId, db.Manager.UserId, default);

        var cancelled = await db.Workflow.CancelAsync(order.SalesOrderId, new CancelOrderDto
        {
            Confirmed = true,
            ConfirmationText = order.OrderNumber,
            Reason = "Customer requested cancellation"
        }, db.Manager.UserId, default);

        Assert.Equal(SalesOrderStatuses.Cancelled, cancelled.Status);
        Assert.Contains(cancelled.StatusHistory, item => item.Reason == "Customer requested cancellation");
        Assert.DoesNotContain(cancelled.Reservations, item => item.Status == OrderReservationStatuses.Active);
    }

    [Fact]
    public async Task ReadyForDispatch_IssuesOneSnapshotInvoiceAndBlocksSkippedTransition()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await db.AddBatchAsync(5m, DateTime.UtcNow.AddDays(4));
        var order = await db.Orders.CreateAsync(db.AdminRequest(2m), db.Manager.UserId, null, default);
        await db.Stock.ValidateAndReserveAsync(order.SalesOrderId, db.Manager.UserId, default);

        var skipped = await Assert.ThrowsAsync<OrderManagementException>(() => db.Workflow.TransitionAsync(
            order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.Packed },
            db.Manager.UserId,
            "AdminClerk",
            default));
        Assert.Equal(409, skipped.StatusCode);

        await db.Workflow.TransitionAsync(order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.Packing },
            db.Packer.UserId, RoleCodes.Packer, default);
        await db.AddPackingScansAsync(order.SalesOrderId);
        await db.Workflow.TransitionAsync(order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.Packed },
            db.Packer.UserId, RoleCodes.Packer, default);
        await db.Workflow.TransitionAsync(order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.ReadyForDispatch },
            db.Manager.UserId, RoleCodes.WarehouseManager, default);
        db.Product.ProductName = "Renamed later";
        await db.Context.SaveChangesAsync();
        var invoice = await db.Workflow.GetInvoiceAsync(order.SalesOrderId, default);
        Assert.Equal("Orderable Product", invoice.Items[0].ProductName);
        Assert.Single(await db.Context.Invoices.ToListAsync());
    }

    [Fact]
    public async Task Dispatch_ConsumesPackingReservationsExactlyOnce()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var batch = await db.AddBatchAsync(5m, DateTime.UtcNow.AddDays(4));
        var order = await db.Orders.CreateAsync(db.AdminRequest(3m), db.Manager.UserId, null, default);
        await db.Stock.ValidateAndReserveAsync(order.SalesOrderId, db.Manager.UserId, default);
        await db.Workflow.TransitionAsync(order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.Packing }, db.Packer.UserId, "Packer", default);
        await db.AddPackingScansAsync(order.SalesOrderId);
        var packed = await db.Workflow.TransitionAsync(order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.Packed }, db.Packer.UserId, "Packer", default);

        await db.Context.Entry(batch).ReloadAsync();
        Assert.Equal(SalesOrderStatuses.Packed, packed.Status);
        Assert.Equal(5m, batch.QuantityRemainingKg);
        Assert.Equal(5m, (await db.Context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.DoesNotContain(await db.Context.StockMovements.ToListAsync(), movement =>
            movement.SalesOrderId == order.SalesOrderId && movement.MovementType == StockMovementTypes.Decrease);

        await db.Workflow.TransitionAsync(order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.ReadyForDispatch },
            db.Manager.UserId, RoleCodes.WarehouseManager, default);
        var dispatched = await db.Workflow.TransitionAsync(order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.OutForDelivery },
            db.Manager.UserId, RoleCodes.WarehouseManager, default);

        await db.Context.Entry(batch).ReloadAsync();
        Assert.Equal(SalesOrderStatuses.OutForDelivery, dispatched.Status);
        Assert.Equal(2m, batch.QuantityRemainingKg);
        Assert.Equal(2m, (await db.Context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.Contains(await db.Context.StockMovements.ToListAsync(), movement =>
            movement.SalesOrderId == order.SalesOrderId && movement.MovementType == StockMovementTypes.Decrease);
    }

    [Fact]
    public async Task PackingAndInvoiceProcessEveryOrderLine()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var second = await db.AddOrderableProductAsync("Second Product", 6m);
        await db.AddBatchAsync(db.Product, 4m, DateTime.UtcNow.AddDays(3));
        await db.AddBatchAsync(second, 5m, DateTime.UtcNow.AddDays(4));
        var request = db.AdminRequest(2m);
        request.Items.Add(new OrderItemRequestDto
        {
            ProductId = second.ProductId,
            QuantityKg = 3m
        });
        var order = await db.Orders.CreateAsync(
            request,
            db.Manager.UserId,
            null,
            default);
        await db.Stock.ValidateAndReserveAsync(
            order.SalesOrderId,
            db.Manager.UserId,
            default);
        await db.Workflow.TransitionAsync(
            order.SalesOrderId,
            new UpdateOrderStatusDto
            {
                NewStatus = SalesOrderStatuses.Packing
            },
            db.Packer.UserId,
            RoleCodes.Packer,
            default);
        await db.AddPackingScansAsync(order.SalesOrderId);
        await db.Workflow.TransitionAsync(
            order.SalesOrderId,
            new UpdateOrderStatusDto
            {
                NewStatus = SalesOrderStatuses.Packed,
                OperationId = "packing-two-lines"
            },
            db.Packer.UserId,
            RoleCodes.Packer,
            default);
        await db.Workflow.TransitionAsync(
            order.SalesOrderId,
            new UpdateOrderStatusDto
            {
                NewStatus = SalesOrderStatuses.ReadyForDispatch
            },
            db.Manager.UserId,
            RoleCodes.WarehouseManager,
            default);
        var invoice = await db.Workflow.GetInvoiceAsync(
            order.SalesOrderId,
            default);
        await db.Workflow.TransitionAsync(
            order.SalesOrderId,
            new UpdateOrderStatusDto
            {
                NewStatus = SalesOrderStatuses.OutForDelivery
            },
            db.Manager.UserId,
            RoleCodes.WarehouseManager,
            default);

        Assert.Equal(2, invoice.Items.Count);
        Assert.Equal(order.TotalAmount, invoice.TotalAmount);
        Assert.Equal(
            2,
            await db.Context.StockMovements.CountAsync(item =>
                item.SalesOrderId == order.SalesOrderId &&
                item.MovementType == StockMovementTypes.Decrease));
    }

    [Fact]
    public async Task PackingCompletion_IsIdempotentAndNeverDeductsStockTwice()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await db.AddBatchAsync(5m, DateTime.UtcNow.AddDays(4));
        var order = await db.Orders.CreateAsync(
            db.AdminRequest(3m),
            db.Manager.UserId,
            null,
            default);
        await db.Stock.ValidateAndReserveAsync(
            order.SalesOrderId,
            db.Manager.UserId,
            default);
        await db.Workflow.TransitionAsync(
            order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.Packing },
            db.Packer.UserId,
            RoleCodes.Packer,
            default);
        await db.AddPackingScansAsync(order.SalesOrderId);

        var request = new UpdateOrderStatusDto
        {
            NewStatus = SalesOrderStatuses.Packed,
            OperationId = "packing-complete-order-1"
        };
        var first = await db.Workflow.TransitionAsync(
            order.SalesOrderId,
            request,
            db.Packer.UserId,
            RoleCodes.Packer,
            default);
        var retry = await db.Workflow.TransitionAsync(
            order.SalesOrderId,
            request,
            db.Packer.UserId,
            RoleCodes.Packer,
            default);

        Assert.Equal(SalesOrderStatuses.Packed, first.Status);
        Assert.Equal(SalesOrderStatuses.Packed, retry.Status);
        Assert.Equal(5m, (await db.Context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.Empty(await db.Context.StockMovements.Where(item =>
            item.SalesOrderId == order.SalesOrderId &&
            item.MovementType == StockMovementTypes.Decrease).ToListAsync());

        var conflict = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Workflow.TransitionAsync(
                order.SalesOrderId,
                new UpdateOrderStatusDto
                {
                    NewStatus = SalesOrderStatuses.Packed,
                    OperationId = "packing-complete-order-1-different"
                },
                db.Packer.UserId,
                RoleCodes.Packer,
                default));
        Assert.Equal(409, conflict.StatusCode);

        await db.Workflow.TransitionAsync(
            order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.ReadyForDispatch },
            db.Manager.UserId,
            RoleCodes.WarehouseManager,
            default);
        await db.Workflow.TransitionAsync(
            order.SalesOrderId,
            new UpdateOrderStatusDto { NewStatus = SalesOrderStatuses.OutForDelivery },
            db.Manager.UserId,
            RoleCodes.WarehouseManager,
            default);
        Assert.Equal(2m, (await db.Context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.Single(await db.Context.StockMovements.Where(item =>
            item.SalesOrderId == order.SalesOrderId &&
            item.MovementType == StockMovementTypes.Decrease).ToListAsync());
    }

    [Fact]
    public async Task MobilePackingQueue_IncludesApprovedOrdersWithFinishedProductShortage()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await db.AddBatchAsync(3m, DateTime.UtcNow.AddDays(3));
        var pending = await db.Orders.CreateAsync(
            db.AdminRequest(1m), db.Manager.UserId, null, default);
        var approved = await db.Orders.CreateAsync(
            db.AdminRequest(2m), db.Manager.UserId, null, default);
        await db.Stock.ValidateAndReserveAsync(
            approved.SalesOrderId, db.Manager.UserId, default);
        var shortOrder = await db.Orders.CreateAsync(
            db.AdminRequest(4m), db.Manager.UserId, null, default);
        await db.Workflow.ApproveAsync(
            shortOrder.SalesOrderId,
            new OrderDecisionDto { Reason = "Commercially valid demand." },
            db.Manager.UserId,
            default);

        var tasks = await db.MobilePacking.PackingTasksAsync(default);

        Assert.Equal(2, tasks.Count);
        Assert.Contains(tasks, item => item.SalesOrderId == approved.SalesOrderId);
        Assert.DoesNotContain(tasks, item => item.SalesOrderId == pending.SalesOrderId);
        Assert.Contains(tasks, item => item.SalesOrderId == shortOrder.SalesOrderId);

        var detail = await db.MobilePacking.PackingTaskAsync(
            shortOrder.SalesOrderId,
            default);
        var line = Assert.Single(detail.Lines);
        Assert.Equal(4m, line.OrderedQuantityUnits);
        Assert.Equal("kg", line.SellingUnit);
        Assert.Equal(4m, line.RequiredQuantityKg);
        Assert.Equal(1m, line.AvailableQuantityKg);
        Assert.Equal(0m, line.PackedQuantityKg);
        Assert.Equal(4m, line.RemainingQuantityKg);

        var webPackingList = await db.Stock.GetPackingListAsync(
            shortOrder.SalesOrderId,
            default);
        var webLine = Assert.Single(webPackingList.Lines);
        Assert.Equal(4m, webLine.OrderedQuantityUnits);
        Assert.Equal(4m, webLine.RequiredQuantityKg);
        Assert.Equal(1m, webLine.AvailableQuantityKg);
        Assert.Equal(0m, webLine.PackedQuantityKg);
        Assert.Equal(4m, webLine.RemainingQuantityKg);
        Assert.Empty(webPackingList.Allocations);
    }

    [Fact]
    public async Task MobilePackingScan_ValidatesBatchesAndRefreshesCorrectionsImmediately()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var early = await db.AddBatchAsync(5m, DateTime.UtcNow.AddDays(2));
        var later = await db.AddBatchAsync(5m, DateTime.UtcNow.AddDays(5));
        var expired = await db.AddBatchAsync(
            1m,
            DateTime.UtcNow.AddHours(-1),
            ProductBatchStatuses.ExpiredPendingDecision);
        var writtenOff = await db.AddBatchAsync(
            1m,
            DateTime.UtcNow.AddDays(4),
            ProductBatchStatuses.WrittenOff);
        var otherProduct = await db.AddOrderableProductAsync("Wrong Product", 8m);
        var wrong = await db.AddBatchAsync(
            otherProduct,
            2m,
            DateTime.UtcNow.AddDays(3));
        var order = await db.Orders.CreateAsync(
            db.AdminRequest(2m), db.Manager.UserId, null, default);
        await db.Stock.ValidateAndReserveAsync(
            order.SalesOrderId, db.Manager.UserId, default);

        var unknown = await Assert.ThrowsAsync<PhaseCException>(() =>
            db.MobilePacking.ScanAsync(
                order.SalesOrderId,
                Scan("UNKNOWN-CODE", 1m),
                db.Packer.UserId,
                default));
        Assert.Equal(
            "This QR code does not match a PhenyoSync Product Batch.",
            unknown.Message);

        var expiredError = await Assert.ThrowsAsync<PhaseCException>(() =>
            db.MobilePacking.ScanAsync(
                order.SalesOrderId,
                Scan(expired.QRCodeValue, 1m),
                db.Packer.UserId,
                default));
        Assert.Contains("expired", expiredError.Message, StringComparison.OrdinalIgnoreCase);

        var writtenOffError = await Assert.ThrowsAsync<PhaseCException>(() =>
            db.MobilePacking.ScanAsync(
                order.SalesOrderId,
                Scan(writtenOff.QRCodeValue, 1m),
                db.Packer.UserId,
                default));
        Assert.Contains("written off", writtenOffError.Message, StringComparison.OrdinalIgnoreCase);

        var wrongError = await Assert.ThrowsAsync<PhaseCException>(() =>
            db.MobilePacking.ScanAsync(
                order.SalesOrderId,
                Scan(wrong.QRCodeValue, 1m),
                db.Packer.UserId,
                default));
        Assert.Contains("not required", wrongError.Message);

        var fefoError = await Assert.ThrowsAsync<PhaseCException>(() =>
            db.MobilePacking.ScanAsync(
                order.SalesOrderId,
                Scan(later.QRCodeValue, 1m),
                db.Packer.UserId,
                default));
        Assert.Contains("earliest-expiring", fefoError.Message);

        var firstRequest = Scan(early.QRCodeValue, 1m);
        var first = await db.MobilePacking.ScanAsync(
            order.SalesOrderId,
            firstRequest,
            db.Packer.UserId,
            default);
        var retry = await db.MobilePacking.ScanAsync(
            order.SalesOrderId,
            firstRequest,
            db.Packer.UserId,
            default);
        Assert.Equal(SalesOrderStatuses.Packing, first.Status);
        Assert.Equal(1m, first.Lines.Single().PackedQuantityKg);
        Assert.Equal(1m, first.Lines.Single().RemainingQuantityKg);
        Assert.Single(retry.Scans, item => !item.IsRemoved);

        var overpack = await Assert.ThrowsAsync<PhaseCException>(() =>
            db.MobilePacking.ScanAsync(
                order.SalesOrderId,
                Scan(early.QRCodeValue, 2m),
                db.Packer.UserId,
                default));
        Assert.Equal("Only 1 unit remains for this Product.", overpack.Message);

        var corrected = await db.MobilePacking.RemoveScanAsync(
            order.SalesOrderId,
            first.Scans.Single().PackingScanId,
            Reason("Correcting the selected quantity."),
            db.Packer.UserId,
            default);
        Assert.Equal(0m, corrected.Lines.Single().PackedQuantityKg);
        Assert.Equal(2m, corrected.Lines.Single().RemainingQuantityKg);

        var completeScan = await db.MobilePacking.ScanAsync(
            order.SalesOrderId,
            Scan(early.QRCodeValue, 2m),
            db.Packer.UserId,
            default);
        Assert.Equal(2m, completeScan.Lines.Single().PackedQuantityKg);
        var completed = await db.MobilePacking.CompletePackingAsync(
            order.SalesOrderId,
            Reason("All required Products were verified and packed."),
            db.Packer.UserId,
            RoleCodes.Packer,
            default);
        Assert.Equal(SalesOrderStatuses.Packed, completed.Status);
        var stockQuantities = await db.Context.Stocks
            .Select(item => item.QuantityAvailableKg)
            .ToListAsync();
        Assert.Equal(12m, stockQuantities.Sum());
        Assert.Empty(await db.Context.StockMovements.Where(item =>
            item.SalesOrderId == order.SalesOrderId &&
            item.MovementType == StockMovementTypes.Decrease).ToListAsync());
    }

    [Fact]
    public async Task ExpiryWriteOff_IsBlockedWhenBatchHasActiveOrderReservation()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var batch = await db.AddBatchAsync(5m, DateTime.UtcNow.AddHours(10));
        var order = await db.Orders.CreateAsync(db.AdminRequest(2m), db.Manager.UserId, null, default);
        await db.Stock.ValidateAndReserveAsync(order.SalesOrderId, db.Manager.UserId, default);
        var token = await db.AddExpiryTokenAsync(batch);
        var exception = await Assert.ThrowsAsync<Subsystem7Exception>(() =>
            db.Expiry.WriteOffAsync(token, "Final write off", db.Manager.UserId, default));
        Assert.Equal(409, exception.StatusCode);
    }

    [Fact]
    public async Task Search_ReturnsEmptyAndFiltersByOrderCustomerProductAndStatus()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var empty = await db.Orders.SearchAsync(new OrderSearchQueryDto { SearchTerm = "missing" }, default);
        Assert.Empty(empty.Items);
        var order = await db.Orders.CreateAsync(db.AdminRequest(1m), db.Manager.UserId, null, default);
        Assert.Single((await db.Orders.SearchAsync(new OrderSearchQueryDto { SearchTerm = order.OrderNumber }, default)).Items);
        Assert.Single((await db.Orders.SearchAsync(new OrderSearchQueryDto { SearchTerm = db.Customer.CustomerName }, default)).Items);
        Assert.Single((await db.Orders.SearchAsync(new OrderSearchQueryDto { SearchTerm = db.Product.ProductName }, default)).Items);
        Assert.Single((await db.Orders.SearchAsync(new OrderSearchQueryDto { Status = SalesOrderStatuses.Submitted }, default)).Items);
    }

    [Fact]
    public void InternalOrderEndpointsDeclarePermissionAuthorization()
    {
        var send = typeof(OrderLinksController).GetCustomAttribute<AuthorizeAttribute>()!;
        var create = typeof(OrdersController).GetMethod(nameof(OrdersController.Create))!
            .GetCustomAttribute<AuthorizeAttribute>()!;
        var packing = typeof(OrdersController).GetMethod(nameof(OrdersController.PackingList))!
            .GetCustomAttribute<AuthorizeAttribute>()!;
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.Orders.SendLink,
            send.Policy);
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.Orders.Create,
            create.Policy);
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.Packing.View,
            packing.Policy);
        Assert.Contains(
            Permissions.Packing.View,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
    }

    private static PackingScanRequest Scan(string code, decimal quantity) =>
        new()
        {
            Code = code,
            QuantityKg = quantity,
            OperationId = Guid.NewGuid().ToString("N")
        };

    private static ReasonRequest Reason(string reason) =>
        new()
        {
            Reason = reason,
            OperationId = Guid.NewGuid().ToString("N")
        };
}

internal sealed class OrderTestDatabase : IAsyncDisposable
{
    private readonly SqliteConnection _connection;
    public PhenyoSyncDbContext Context { get; }
    public Customer Customer { get; private set; } = null!;
    public Product Product { get; private set; } = null!;
    public WarehouseSection Section { get; private set; } = null!;
    public User Manager { get; private set; } = null!;
    public User Packer { get; private set; } = null!;
    public FakeOrderEmailService Email { get; } = new();
    public IOrderService Orders { get; private set; } = null!;
    public IOrderStockService Stock { get; private set; } = null!;
    public IOrderWorkflowService Workflow { get; private set; } = null!;
    public IMobilePackingDispatchService MobilePacking { get; private set; } = null!;
    public IOrderLinkService Links { get; private set; } = null!;
    public IExpiryService Expiry { get; private set; } = null!;
    public MutableOrderSettings Settings { get; } = new();

    private OrderTestDatabase(SqliteConnection connection, PhenyoSyncDbContext context)
    {
        _connection = connection;
        Context = context;
    }

    public static async Task<OrderTestDatabase> CreateAsync()
    {
        var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var context = new PhenyoSyncDbContext(new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection).Options);
        await context.Database.EnsureCreatedAsync();
        var db = new OrderTestDatabase(connection, context);
        await db.SeedAsync();
        db.WireServices();
        return db;
    }

    public CreateSalesOrderDto AdminRequest(decimal quantity) => new()
    {
        CustomerId = Customer.CustomerId,
        DeliveryAddress = "10 Test Avenue",
        BillingAddress = "10 Test Avenue",
        Items = [new OrderItemRequestDto { ProductId = Product.ProductId, QuantityKg = quantity }]
    };

    public PublicCreateSalesOrderDto PublicRequest(string token, decimal quantity) => new()
    {
        Token = token,
        DeliveryAddress = "10 Test Avenue",
        BillingAddress = "10 Test Avenue",
        Items = [new OrderItemRequestDto { ProductId = Product.ProductId, QuantityKg = quantity }]
    };

    public async Task<ProductBatch> AddBatchAsync(
        decimal quantity,
        DateTime expiry,
        string status = ProductBatchStatuses.Available) =>
        await AddBatchAsync(Product, quantity, expiry, status);

    public async Task<ProductBatch> AddBatchAsync(
        Product product,
        decimal quantity,
        DateTime expiry,
        string status = ProductBatchStatuses.Available)
    {
        var batch = new ProductBatch
        {
            ProductId = product.ProductId,
            SectionId = Section.SectionId,
            BatchCode = $"BATCH-{Guid.NewGuid():N}",
            QRCodeValue = $"PHENYOSYNC:BATCH:{Guid.NewGuid():N}",
            QuantityProducedKg = quantity,
            QuantityRemainingKg = quantity,
            PackedAtUtc = expiry.AddDays(-4),
            OriginalExpiryAtUtc = expiry,
            EffectiveExpiryAtUtc = expiry,
            Status = status,
            CreatedAtUtc = DateTime.UtcNow
        };
        Context.ProductBatches.Add(batch);
        var stock = await Context.Stocks.SingleOrDefaultAsync(item =>
            item.ProductId == product.ProductId &&
            item.SectionId == Section.SectionId);
        if (stock is null)
        {
            Context.Stocks.Add(new Stock
            {
                ProductId = product.ProductId,
                SectionId = Section.SectionId,
                QuantityAvailableKg = status == ProductBatchStatuses.Available && expiry > DateTime.UtcNow ? quantity : 0,
                InventoryStatus = ProductBatchStatuses.Available
            });
        }
        else if (status == ProductBatchStatuses.Available && expiry > DateTime.UtcNow)
        {
            stock.QuantityAvailableKg += quantity;
        }
        await Context.SaveChangesAsync();
        return batch;
    }

    public async Task<Product> AddOrderableProductAsync(
        string name,
        decimal price,
        string status = ProductStatuses.Active)
    {
        var product = new Product
        {
            ProductName = name,
            ProductTypeId = Product.ProductTypeId,
            ProductCategoryId = Product.ProductCategoryId,
            Size = "1 KG",
            ShelfLifeDays = 10,
            SellingPricePerKg = price,
            Status = status,
            CreatedAt = DateTime.UtcNow
        };
        Context.Products.Add(product);
        await Context.SaveChangesAsync();
        Context.ProductPrices.Add(new ProductPrice
        {
            ProductId = product.ProductId,
            SellingPrice = price,
            EffectiveFromUtc = DateTime.UtcNow,
            IsCurrent = true,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedByUserId = Manager.UserId,
            ChangeReason = "Multi-line order test seed"
        });
        await Context.SaveChangesAsync();
        return product;
    }

    public async Task<string> AddExpiryTokenAsync(ProductBatch batch)
    {
        var raw = $"expiry-{Guid.NewGuid():N}";
        Context.ExpiryActionTokens.Add(new ExpiryActionToken
        {
            ProductBatchId = batch.ProductBatchId,
            TokenHash = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(raw))),
            AlertLevel = ExpiryAlertLevels.Urgent,
            CreatedAtUtc = DateTime.UtcNow,
            ExpiresAtUtc = DateTime.UtcNow.AddHours(24)
        });
        await Context.SaveChangesAsync();
        return raw;
    }

    public async Task AddPackingScansAsync(int orderId)
    {
        var reservations = await Context.OrderStockReservations
            .Where(item =>
                item.SalesOrderId == orderId &&
                item.Status == OrderReservationStatuses.Active)
            .ToListAsync();
        foreach (var reservation in reservations)
        {
            Context.PackingScans.Add(new PackingScan
            {
                SalesOrderId = reservation.SalesOrderId,
                SalesOrderItemId = reservation.SalesOrderItemId,
                OrderStockReservationId = reservation.OrderStockReservationId,
                ProductBatchId = reservation.ProductBatchId,
                ScannedByUserId = Packer.UserId,
                QuantityPackedKg = reservation.QuantityReservedKg,
                ScannedAtUtc = DateTime.UtcNow,
                OperationKeyHash = Convert.ToHexString(
                    System.Security.Cryptography.SHA256.HashData(
                        System.Text.Encoding.UTF8.GetBytes($"packing-{Guid.NewGuid():N}")))
            });
        }

        await Context.SaveChangesAsync();
    }

    private async Task SeedAsync()
    {
        var managerRole = new Role { RoleName = "AdminClerk", Users = [], RolePermissions = [] };
        var packerRole = new Role { RoleName = "Packer", Users = [], RolePermissions = [] };
        Manager = User("manager@example.test", "Order", "Manager", managerRole);
        Packer = User("packer@example.test", "Test", "Packer", packerRole);
        Customer = new Customer
        {
            CustomerNumber = "CUS-000001", CustomerName = "Test Customer", Email = "customer@example.test",
            BillingAddress = "10 Test Avenue", DeliveryAddress = "10 Test Avenue",
            Status = CustomerStatuses.Active, CreatedAtUtc = DateTime.UtcNow
        };
        var type = new ProductType { ProductTypeName = "Fresh", Status = ProductStatuses.Active, CreatedAt = DateTime.UtcNow };
        var category = new ProductCategory { ProductCategoryName = "Fruit", Status = ProductStatuses.Active, CreatedAt = DateTime.UtcNow };
        Section = new WarehouseSection { SectionName = "Order Test", Status = ProductStatuses.Active };
        Product = new Product
        {
            ProductName = "Orderable Product", ProductType = type, ProductCategory = category,
            Size = "1 KG", ShelfLifeDays = 10, SellingPricePerKg = 10m,
            Status = ProductStatuses.Active, CreatedAt = DateTime.UtcNow
        };
        Context.AddRange(Manager, Packer, Customer, Section, Product);
        await Context.SaveChangesAsync();
        Context.ProductPrices.Add(new ProductPrice
        {
            ProductId = Product.ProductId,
            SellingPrice = 10m,
            EffectiveFromUtc = DateTime.UtcNow,
            IsCurrent = true,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedByUserId = Manager.UserId,
            ChangeReason = "Order test seed"
        });
        await Context.SaveChangesAsync();
    }

    private void WireServices()
    {
        var options = Microsoft.Extensions.Options.Options.Create(new OrderManagementOptions
        {
            OrderLinkLifetimeHours = 72,
            TaxRatePercent = 0,
            DeliverySafetyHours = 0
        });
        var pricing = new ProductPricingService(Context);
        Orders = new OrderService(Context, options, pricing, Settings);
        Stock = new OrderStockService(Context, options);
        Workflow = new OrderWorkflowService(Context, Stock, Orders);
        MobilePacking = new MobilePackingDispatchService(
            Context,
            Workflow,
            Stock,
            new FakeDeliveryAuditService(),
            new OperationalNotificationService(Context));
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?> { ["FrontendUrl"] = "http://localhost:4200" })
            .Build();
        Links = new OrderLinkService(Context, Email, Orders, configuration, options);
        Expiry = new ExpiryService(Context, Email, Microsoft.Extensions.Options.Options.Create(new ExpiryAlertOptions
        {
            YellowThresholdHours = 72,
            RedThresholdHours = 24,
            ActionTokenLifetimeHours = 48,
            RecipientRoles = ["AdminClerk"]
        }), configuration);
    }

    private static User User(string email, string firstName, string lastName, Role role) => new()
    {
        Email = email,
        PasswordHash = "test",
        FirstName = firstName,
        LastName = lastName,
        Role = role,
        Status = ProductStatuses.Active,
        StockTakeSessions = []
    };

    public async ValueTask DisposeAsync()
    {
        await Context.DisposeAsync();
        await _connection.DisposeAsync();
    }
}

internal sealed class MutableOrderSettings : ISystemSettingProvider
{
    public decimal VatRatePercent { get; set; }
    public Task<decimal> GetDecimalAsync(string key, CancellationToken cancellationToken = default) =>
        Task.FromResult(key == SystemSettingKeys.OrdersVatRatePercent ? VatRatePercent : 0m);
    public Task<int> GetIntAsync(string key, CancellationToken cancellationToken = default) => Task.FromResult(0);
    public Task<bool> GetBooleanAsync(string key, CancellationToken cancellationToken = default) => Task.FromResult(false);
    public Task<string> GetStringAsync(string key, CancellationToken cancellationToken = default) => Task.FromResult(string.Empty);
    public Task<string[]> GetStringArrayAsync(string key, CancellationToken cancellationToken = default) => Task.FromResult(Array.Empty<string>());
    public void Invalidate(string key) { }
    public void InvalidateAll() { }
}

internal sealed class FakeOrderEmailService : IEmailService
{
    public List<string> OrderLinks { get; } = [];
    public Task SendPasswordResetEmailAsync(string recipientEmail, string resetLink) => Task.CompletedTask;
    public Task SendExpiryAlertEmailAsync(IReadOnlyCollection<string> recipientEmails, ExpiryEmailModel model, string reviewLink, CancellationToken cancellationToken = default) => Task.CompletedTask;
    public Task SendExpiryDecisionConfirmationAsync(IReadOnlyCollection<string> recipientEmails, ExpiryEmailModel model, string decision, CancellationToken cancellationToken = default) => Task.CompletedTask;
    public Task SendCustomerOrderLinkEmailAsync(string recipientEmail, string customerName, string orderLink, DateTime expiresAtUtc, CancellationToken cancellationToken = default)
    {
        OrderLinks.Add(orderLink);
        return Task.CompletedTask;
    }
    public string LastToken()
    {
        var query = new Uri(OrderLinks.Last()).Query.TrimStart('?');
        return Uri.UnescapeDataString(query.Split('&').Single(item => item.StartsWith("token="))["token=".Length..]);
    }
}
