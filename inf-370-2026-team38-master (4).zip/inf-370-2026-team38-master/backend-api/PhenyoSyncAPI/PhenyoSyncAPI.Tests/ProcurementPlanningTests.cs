using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Proves only approved finished shortage drives recipe raw demand and net procurement shortage.
public sealed class ProcurementPlanningTests
{
    [Fact]
    public async Task PendingValidationOrder_ContributesNoProcurementDemand()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        await AddRawRequirementAsync(db);
        await db.Orders.CreateAsync(
            db.AdminRequest(5m), db.Manager.UserId, null, default);

        var service = new ProcurementPlanningService(
            db.Context,
            new FakeDeliveryAuditService());

        Assert.Empty(await service.ShortagesAsync(default));
    }

    [Fact]
    public async Task ApprovedDemand_UsesOnlyFinishedShortage_AndNetsRawStockAndOutstandingProcurement()
    {
        await using var db = await OrderTestDatabase.CreateAsync();
        var raw = await AddRawRequirementAsync(db, quantityOnHand: 5m);
        await db.AddBatchAsync(2m, DateTime.UtcNow.AddDays(5));

        var stockedOrder = await db.Orders.CreateAsync(
            db.AdminRequest(2m), db.Manager.UserId, null, default);
        var stockReadiness = await db.Stock.ValidateAndReserveAsync(
            stockedOrder.SalesOrderId,
            db.Manager.UserId,
            default);
        Assert.True(stockReadiness.Approved);

        var shortOrder = await db.Orders.CreateAsync(
            db.AdminRequest(3m), db.Manager.UserId, null, default);
        await db.Workflow.ApproveAsync(
            shortOrder.SalesOrderId,
            new() { Reason = "Commercially valid demand." },
            db.Manager.UserId,
            default);

        var supplier = new Supplier
        {
            SupplierName = "Test Supplier",
            SupplierCode = "SUP-TEST",
            SupplierTypeCode = "GeneralSupplier",
            Status = ProductStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        db.Context.SupplierOrders.Add(new SupplierOrder
        {
            Supplier = supplier,
            OrderNumber = "PO-TEST-001",
            OrderDate = DateTime.UtcNow,
            WarehouseSectionId = db.Section.SectionId,
            Status = SupplierOrderStatuses.Ordered,
            CreatedByUserId = db.Manager.UserId,
            CreatedAtUtc = DateTime.UtcNow,
            Lines =
            [
                new SupplierOrderLine
                {
                    RawStockItemId = raw.RawStockItemId,
                    OrderedQuantity = 7m,
                    ReceivedQuantity = 0m,
                    ExpectedUnitPrice = 1m,
                    UnitOfMeasure = RawStockUnits.Kilogram
                }
            ]
        });
        await db.Context.SaveChangesAsync();

        var reservations = await db.Context.OrderStockReservations
            .Where(item =>
                item.SalesOrderId == stockedOrder.SalesOrderId &&
                item.Status == OrderReservationStatuses.Active)
            .Select(item => item.QuantityReservedKg)
            .ToListAsync();
        Assert.Equal(2m, reservations.Sum());

        var service = new ProcurementPlanningService(
            db.Context,
            new FakeDeliveryAuditService());
        var result = Assert.Single(await service.ShortagesAsync(default));
        var breakdown = Assert.Single(result.DemandBreakdown);

        Assert.Equal(5m, breakdown.UnfulfilledDemand);
        Assert.Equal(2m, breakdown.FinishedStockAvailable);
        Assert.Equal(3m, breakdown.FinishedProductShortage);
        Assert.Equal(30m, breakdown.RawQuantityRequired);
        Assert.Equal(30m, result.GrossRawRequirement);
        Assert.Equal(5m, result.UsableRawStock);
        Assert.Equal(7m, result.SupplierOrderOutstanding);
        Assert.Equal(18m, result.SuggestedPurchaseQuantity);
    }

    private static async Task<RawStockItem> AddRawRequirementAsync(
        OrderTestDatabase db,
        decimal quantityOnHand = 0m)
    {
        var raw = new RawStockItem
        {
            ItemCode = "RAW-TEST",
            ItemName = "Test Raw Input",
            CategoryCode = RawStockCategories.Produce,
            DefaultUnitOfMeasure = RawStockUnits.Kilogram,
            IsProduce = true,
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        var balance = new RawStockBalance
        {
            RawStockItem = raw,
            WarehouseSectionId = db.Section.SectionId,
            UnitOfMeasure = RawStockUnits.Kilogram,
            QuantityOnHand = quantityOnHand,
            ReservedQuantity = 0m
        };
        db.Context.AddRange(
            raw,
            balance,
            new ProductRawStockRequirement
            {
                ProductId = db.Product.ProductId,
                RawStockItem = raw,
                RawQuantityPerProductUnit = 10m,
                UnitOfMeasure = RawStockUnits.Kilogram,
                WastePercentage = 0m,
                YieldPercentage = 100m,
                IsActive = true,
                CreatedByUserId = db.Manager.UserId,
                CreatedAtUtc = DateTime.UtcNow
            });

        if (quantityOnHand > 0)
        {
            db.Context.RawStockBatches.Add(new RawStockBatch
            {
                RawStockItem = raw,
                RawStockBalance = balance,
                BatchCode = "RAW-BATCH-TEST",
                QrCodeValue = "PHENYOSYNC:RAW:TEST",
                QuantityReceived = quantityOnHand,
                QuantityRemaining = quantityOnHand,
                ReceivedAtUtc = DateTime.UtcNow,
                BestBeforeAtUtc = DateTime.UtcNow.AddDays(5),
                Status = ProductBatchStatuses.Available
            });
        }

        await db.Context.SaveChangesAsync();
        return raw;
    }
}
