using System.Net;
using System.Text;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Protects external-row idempotency, exact product matching and contact preference mapping.
public sealed class GoogleOrderIntakeTests
{
    [Fact]
    public async Task RepeatedSyncUsesStableExternalKeyAndDoesNotDuplicateOrder()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();

        var actor = new User
        {
            Email = "buyer@example.test",
            NormalizedEmail = "BUYER@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Order",
            LastName = "Manager",
            Status = "Active",
            Role = new Role
            {
                RoleCode = "OperationsManager",
                RoleName = "Operations Manager",
                IsActive = true
            }
        };
        var customer = new Customer
        {
            CustomerNumber = "CUS-001",
            CustomerName = "Test Customer",
            Email = "customer@example.test",
            NormalizedEmail = "CUSTOMER@EXAMPLE.TEST",
            BillingAddress = "1 Billing Road",
            DeliveryAddress = "2 Delivery Road",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var product = new Product
        {
            ProductName = "Carrots 1 KG",
            ProductType = new ProductType
            {
                ProductTypeName = "Fresh Produce",
                Status = ProductStatuses.Active,
                CreatedAt = DateTime.UtcNow
            },
            ProductCategory = new ProductCategory
            {
                ProductCategoryName = "Vegetables",
                Status = ProductStatuses.Active,
                CreatedAt = DateTime.UtcNow
            },
            QRCodeValue = "CARROT-1KG",
            Size = "1 KG",
            ShelfLifeDays = 10,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var secondProduct = new Product
        {
            ProductName = "Beetroot 1 KG",
            ProductType = product.ProductType,
            ProductCategory = product.ProductCategory,
            QRCodeValue = "BEETROOT-1KG",
            Size = "1 KG",
            ShelfLifeDays = 10,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        context.AddRange(actor, customer, product, secondProduct);
        await context.SaveChangesAsync();

        const string apiKey = "test-provider-key-never-placed-in-the-url";
        var handler = new SheetResponseHandler("""
            {
              "values": [
                ["Timestamp", "Business / Customer Name", "Contact Person", "Phone / WhatsApp Number", "Email Address", "Customer Account / Reference Number", "How would you like to receive your order?", "Delivery Address", "Requested Delivery / Collection Date", "Purchase Order / Customer Reference", "Product / Item 1", "Quantity 1", "Product / Item 2", "Quantity 2", "Product / Item 3", "Quantity 3", "Product / Item 4", "Quantity 4", "Product / Item 5", "Quantity 5", "Product / Item 6", "Quantity 6", "Additional Products / Quantities", "Special Instructions / Notes", "WhatsApp preference", "Order Request Confirmation"],
                ["2026-08-16T10:00:00+02:00", "Test Customer", "Receiving Team", "082 555 0100", "customer@example.test", "CUS-001", "Delivery", "2 Delivery Road", "2026-08-18", "PO-7781", "CARROT-1KG", "4.5", "Beetroot, 1KG", "2", "", "", "", "", "", "", "", "", "", "Leave at receiving", "Yes", "Confirmed"]
              ]
            }
            """);
        var audit = new RecordingOrderIntakeAudit();
        var orderService = new RecordingOrderService(context);
        var service = new GoogleOrderIntakeService(
            new HttpClient(handler),
            context,
            orderService,
            audit,
            Microsoft.Extensions.Options.Options.Create(
                new GoogleOrderIntakeOptions
            {
                SpreadsheetId = "sheet-id",
                Range = "Form Responses 1!A:Z",
                ApiKey = apiKey
            }));

        var first = await service.SyncAsync(actor.UserId, default);
        var second = await service.SyncAsync(actor.UserId, default);

        Assert.Equal(1, first.Imported);
        Assert.Equal(1, second.SkippedAsDuplicate);
        Assert.Single(await context.ExternalOrderSubmissions.ToListAsync());
        var order = Assert.Single(await context.SalesOrders.ToListAsync());
        Assert.Equal(SalesOrderStatuses.Submitted, order.Status);
        Assert.Equal(OrderValidationStatuses.Pending, order.ValidationStatus);
        Assert.Equal(apiKey, handler.LastApiKey);
        Assert.DoesNotContain(apiKey, handler.LastRequestUri, StringComparison.Ordinal);
        Assert.Equal(2, orderService.LastCreatedRequest?.Items.Count);
        Assert.Contains("PO-7781", orderService.LastCreatedRequest?.Notes);
        Assert.Contains("Receiving Team", orderService.LastCreatedRequest?.Notes);
        Assert.Contains("WhatsApp contact preference: Yes", orderService.LastCreatedRequest?.Notes);
        Assert.DoesNotContain(
            typeof(OrderItemRequestDto).GetProperties(),
            property => property.Name.Contains(
                "Price",
                StringComparison.OrdinalIgnoreCase));
        Assert.Equal(4, audit.Events.Count);
        Assert.Contains(
            audit.Events,
            item => item.OperationName ==
                "Start manual Google Form synchronisation");
        Assert.Contains(
            audit.Events,
            item => item.OperationName ==
                "Ignore duplicate Google Form response");
    }

    [Fact]
    public async Task SimplifiedFormHeadersCreateOnePendingOrderAndMapContactPreference()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var dbOptions = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(dbOptions);
        await context.Database.EnsureCreatedAsync();

        var actor = new User
        {
            Email = "intake@example.test",
            NormalizedEmail = "INTAKE@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Intake",
            LastName = "Manager",
            Status = "Active",
            Role = new Role { RoleCode = "Admin", RoleName = "Super Admin", IsActive = true }
        };
        var customer = new Customer
        {
            CustomerNumber = "CUS-100",
            CustomerName = "Simple Customer",
            Email = "simple@example.test",
            NormalizedEmail = "SIMPLE@EXAMPLE.TEST",
            PhoneNumber = "0825550100",
            BillingAddress = "1 Billing Road",
            DeliveryAddress = "2 Delivery Road",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var product = new Product
        {
            ProductName = "Granny Smith Apples",
            ProductType = new ProductType
            {
                ProductTypeName = "Packed Produce",
                Status = ProductStatuses.Active,
                CreatedAt = DateTime.UtcNow
            },
            ProductCategory = new ProductCategory
            {
                ProductCategoryName = "Fruit",
                Status = ProductStatuses.Active,
                CreatedAt = DateTime.UtcNow
            },
            QRCodeValue = "APPLE-GS-3KG",
            Size = "3 KG",
            ShelfLifeDays = 10,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        context.AddRange(actor, customer, product);
        await context.SaveChangesAsync();

        var handler = new SheetResponseHandler("""
            {
              "values": [
                ["Timestamp", "Customer Email", "Phone Number", "Fulfilment", "Delivery Address", "Requested Date", "Purchase Order / Customer Reference", "Notes", "WhatsApp preference", "Product", "Quantity"],
                ["2026-09-05T10:00:00+02:00", "simple@example.test", "082 555 0100", "Delivery", "2 Delivery Road", "2026-09-06", "PO-100", "Call on arrival", "No", "Granny Smith Apples — 3 KG", "2"]
              ]
            }
            """);
        var orderService = new RecordingOrderService(context);
        var service = new GoogleOrderIntakeService(
            new HttpClient(handler),
            context,
            orderService,
            new RecordingOrderIntakeAudit(),
            Microsoft.Extensions.Options.Options.Create(new GoogleOrderIntakeOptions
            {
                SpreadsheetId = "sheet-id",
                Range = "Form Responses 1!A:Z",
                ApiKey = "test-key"
            }));

        var result = await service.SyncAsync(actor.UserId, default);

        Assert.Equal(1, result.Imported);
        Assert.Equal(0, result.NeedsAttention);
        Assert.Single(await context.SalesOrders.ToListAsync());
        Assert.Equal(2m, orderService.LastCreatedRequest?.Items.Single().QuantityUnits);
        Assert.Null(orderService.LastCreatedRequest?.Items.Single().QuantityKg);
        Assert.Contains("WhatsApp contact preference: No", orderService.LastCreatedRequest?.Notes);
        Assert.Contains("Special instructions: Call on arrival", orderService.LastCreatedRequest?.Notes);
    }

    [Fact]
    public async Task InvalidRowsRemainNeedsAttentionWithoutCreatingOrders()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var actor = new User
        {
            Email = "intake@example.test",
            NormalizedEmail = "INTAKE@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Intake",
            LastName = "Reviewer",
            Status = "Active",
            Role = new Role
            {
                RoleCode = "OperationsManager",
                RoleName = "Operations Manager",
                IsActive = true
            }
        };
        var customer = new Customer
        {
            CustomerNumber = "CUS-002",
            CustomerName = "Controlled Customer",
            Email = "known@example.test",
            NormalizedEmail = "KNOWN@EXAMPLE.TEST",
            BillingAddress = "1 Billing Road",
            DeliveryAddress = null,
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var category = new ProductCategory
        {
            ProductCategoryName = "Produce",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var type = new ProductType
        {
            ProductTypeName = "Produce Type",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        Product Product(string name, string code) => new()
        {
            ProductName = name,
            ProductCategory = category,
            ProductType = type,
            QRCodeValue = code,
            Size = "1 KG",
            ShelfLifeDays = 7,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        context.AddRange(
            actor,
            customer,
            Product("Known Product", "KNOWN-1KG"),
            Product("Ambiguous A", "AMBIGUOUS"),
            Product("Ambiguous B", "AMBIGUOUS"));
        await context.SaveChangesAsync();

        var handler = new SheetResponseHandler("""
            {
              "values": [
                ["Timestamp", "Business / Customer Name", "Contact Person", "Phone / WhatsApp Number", "Email Address", "Customer Account / Reference Number", "How would you like to receive your order?", "Delivery Address", "Requested Delivery / Collection Date", "Purchase Order / Customer Reference", "Product / Item 1", "Quantity 1", "Product / Item 2", "Quantity 2", "Product / Item 3", "Quantity 3", "Product / Item 4", "Quantity 4", "Product / Item 5", "Quantity 5", "Product / Item 6", "Quantity 6", "Additional Products / Quantities", "Special Instructions / Notes", "WhatsApp preference", "Order Request Confirmation"],
                ["2026-08-16T10:01:00+02:00", "Customer", "Contact", "", "known@example.test", "CUS-002", "Delivery", "2 Delivery Road", "", "", "UNKNOWN", "1", "", "", "", "", "", "", "", "", "", "", "", "", "Yes", "Confirmed"],
                ["2026-08-16T10:02:00+02:00", "Customer", "Contact", "", "known@example.test", "CUS-002", "Delivery", "2 Delivery Road", "", "", "AMBIGUOUS", "1", "", "", "", "", "", "", "", "", "", "", "", "", "Yes", "Confirmed"],
                ["2026-08-16T10:03:00+02:00", "Missing", "Contact", "", "missing@example.test", "UNKNOWN", "Delivery", "2 Delivery Road", "", "", "KNOWN-1KG", "1", "", "", "", "", "", "", "", "", "", "", "", "", "Yes", "Confirmed"],
                ["2026-08-16T10:04:00+02:00", "Customer", "Contact", "", "known@example.test", "CUS-002", "Delivery", "2 Delivery Road", "", "", "KNOWN-1KG", "zero", "", "", "", "", "", "", "", "", "", "", "", "", "Yes", "Confirmed"],
                ["2026-08-16T10:05:00+02:00", "Customer", "Contact", "", "known@example.test", "CUS-002", "Collection", "", "", "", "KNOWN-1KG", "1", "", "", "", "", "", "", "", "", "", "", "Extra produce requested", "", "Yes", "Confirmed"]
              ]
            }
            """);
        var orderService = new RecordingOrderService(context);
        var service = new GoogleOrderIntakeService(
            new HttpClient(handler),
            context,
            orderService,
            new RecordingOrderIntakeAudit(),
            Microsoft.Extensions.Options.Options.Create(
                new GoogleOrderIntakeOptions
                {
                    SpreadsheetId = "sheet-id",
                    Range = "Form Responses 1!A:Z",
                    ApiKey = "test-key"
                }));

        var result = await service.SyncAsync(actor.UserId, default);

        Assert.Equal(5, result.NeedsAttention);
        Assert.Equal(0, result.Imported);
        Assert.Null(orderService.LastCreatedRequest);
        Assert.Empty(await context.SalesOrders.ToListAsync());
        Assert.Equal(
            5,
            await context.ExternalOrderSubmissions.CountAsync(item =>
                item.Status == ExternalOrderSubmissionStatuses.NeedsAttention));
    }

    private sealed class SheetResponseHandler(string responseJson)
        : HttpMessageHandler
    {
        public string? LastApiKey { get; private set; }
        public string LastRequestUri { get; private set; } = string.Empty;

        protected override Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            LastRequestUri = request.RequestUri?.ToString() ?? string.Empty;
            LastApiKey = request.Headers.TryGetValues(
                "X-Goog-Api-Key",
                out var values)
                ? values.Single()
                : null;
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(
                    responseJson,
                    Encoding.UTF8,
                    "application/json")
            });
        }
    }

    private sealed class RecordingOrderService(PhenyoSyncDbContext context)
        : IOrderService
    {
        public CreateSalesOrderDto? LastCreatedRequest { get; private set; }

        public async Task<SalesOrderDetailDto> CreateAsync(
            CreateSalesOrderDto request,
            int? createdByUserId,
            long? orderLinkId,
            CancellationToken cancellationToken)
        {
            LastCreatedRequest = request;
            var order = new SalesOrder
            {
                OrderNumber = $"GOOGLE-{Guid.NewGuid():N}"[..24],
                CustomerId = request.CustomerId,
                OrderDateUtc = DateTime.UtcNow,
                RequestedDeliveryDateUtc = request.RequestedDeliveryDateUtc,
                DeliveryAddressSnapshot = request.DeliveryAddress,
                BillingAddressSnapshot = request.BillingAddress,
                Status = SalesOrderStatuses.Submitted,
                ValidationStatus = OrderValidationStatuses.Pending,
                Notes = request.Notes,
                CreatedByUserId = createdByUserId,
                CreatedAtUtc = DateTime.UtcNow
            };
            context.SalesOrders.Add(order);
            await context.SaveChangesAsync(cancellationToken);
            return new SalesOrderDetailDto
            {
                SalesOrderId = order.SalesOrderId,
                OrderNumber = order.OrderNumber,
                CustomerId = order.CustomerId,
                Status = order.Status,
                ValidationStatus = order.ValidationStatus
            };
        }

        public Task<SalesOrderDetailDto> GetAsync(
            int orderId,
            CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public Task<PagedResultDto<SalesOrderSummaryDto>> SearchAsync(
            OrderSearchQueryDto query,
            CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public Task<SalesOrderDetailDto> UpdateAsync(
            int orderId,
            UpdateSalesOrderDto request,
            int userId,
            CancellationToken cancellationToken) =>
            throw new NotSupportedException();
    }

    private sealed class RecordingOrderIntakeAudit : IAuditService
    {
        public List<AuditEvent> Events { get; } = [];

        public Task RecordAsync(
            AuditEvent auditEvent,
            CancellationToken cancellationToken = default)
        {
            Events.Add(auditEvent);
            return Task.CompletedTask;
        }
    }
}
