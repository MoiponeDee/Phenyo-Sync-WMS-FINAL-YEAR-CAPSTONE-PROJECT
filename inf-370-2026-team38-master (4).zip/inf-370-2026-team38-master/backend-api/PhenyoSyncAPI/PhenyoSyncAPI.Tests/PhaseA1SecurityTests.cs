using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Contracts;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Security;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Protects backend authorization, role normalization and account/session security behavior.
public sealed class PhaseA1SecurityTests
{
    [Fact]
    public void RevisedBusinessRolesAreScopedInsteadOfReceivingTheCompleteCatalog()
    {
        foreach (var role in new[]
                 {
                     RoleCodes.OperationsManager,
                     RoleCodes.Admin,
                     RoleCodes.WarehouseManager
                 })
        {
            Assert.Contains(role, SecurityRoleMatrix.Assignments.Keys);
            Assert.Contains(
                Permissions.Dashboards.View,
                SecurityRoleMatrix.Assignments[role]);
            Assert.True(
                SecurityRoleMatrix.Assignments[role].Count < Permissions.Catalog.Count,
                $"{role} should receive only the permissions required by its responsibilities.");
        }

        Assert.Equal(
            RoleCodes.Admin,
            RoleCodes.Normalize(RoleCodes.BusinessManager));
    }

    [Fact]
    public void AdministratorOwnsSecurityPricingAndCustomerAdministration()
    {
        var permissions = SecurityRoleMatrix.Assignments[RoleCodes.Admin];

        Assert.Contains(Permissions.Users.AssignRole, permissions);
        Assert.Contains(Permissions.Roles.AssignPermissions, permissions);
        Assert.Contains(Permissions.Pricing.Manage, permissions);
        Assert.Contains(Permissions.Customers.Manage, permissions);
        Assert.Contains(Permissions.Orders.Confirm, permissions);
        Assert.DoesNotContain(Permissions.RawStock.View, permissions);
        Assert.DoesNotContain(Permissions.Products.Make, permissions);
        Assert.DoesNotContain(Permissions.Payments.Confirm, permissions);
        Assert.DoesNotContain(Permissions.Deliveries.AssignDriver, permissions);
    }

    [Fact]
    public void FinalManagementRoleBoundariesRemainLeastPrivilege()
    {
        var operations =
            SecurityRoleMatrix.Assignments[RoleCodes.OperationsManager];
        var warehouse =
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager];
        var administrator =
            SecurityRoleMatrix.Assignments[RoleCodes.Admin];

        Assert.DoesNotContain(Permissions.RawStock.View, operations);
        Assert.DoesNotContain(Permissions.Products.Make, operations);
        Assert.DoesNotContain(Permissions.ProductTypes.Manage, operations);
        Assert.DoesNotContain(Permissions.ProductCategories.Manage, operations);
        Assert.DoesNotContain(Permissions.WarehouseSections.Manage, operations);
        Assert.DoesNotContain(Permissions.Users.View, operations);
        Assert.DoesNotContain(Permissions.Roles.View, operations);
        Assert.DoesNotContain(Permissions.PermissionDefinitions.View, operations);
        Assert.DoesNotContain(Permissions.Orders.Validate, operations);
        Assert.DoesNotContain(Permissions.Orders.Confirm, operations);

        Assert.DoesNotContain(Permissions.Users.View, warehouse);
        Assert.DoesNotContain(Permissions.Roles.View, warehouse);
        Assert.DoesNotContain(Permissions.PermissionDefinitions.View, warehouse);
        Assert.DoesNotContain(Permissions.ProductTypes.Manage, warehouse);
        Assert.DoesNotContain(Permissions.ProductCategories.Manage, warehouse);
        Assert.DoesNotContain(Permissions.Orders.Validate, warehouse);
        Assert.DoesNotContain(Permissions.Orders.Confirm, warehouse);

        Assert.DoesNotContain(Permissions.RawStock.View, administrator);
        Assert.DoesNotContain(Permissions.Products.Make, administrator);
        Assert.DoesNotContain(
            Permissions.WarehouseSections.Manage,
            administrator);
        Assert.Contains(Permissions.Orders.Validate, administrator);
        Assert.Contains(Permissions.Orders.Confirm, administrator);
    }

    [Fact]
    public void OperationalRolesRemainLeastPrivilege()
    {
        Assert.Contains(
            Permissions.Mobile.PackingComplete,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.DoesNotContain(
            Permissions.Pricing.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.Contains(
            Permissions.Stock.WriteOff,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
        Assert.Contains(
            Permissions.Products.Make,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
        Assert.DoesNotContain(
            Permissions.Users.View,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
    }

    [Theory]
    [InlineData(RoleCodes.OperationsManager, false)]
    [InlineData(RoleCodes.Admin, false)]
    [InlineData(RoleCodes.WarehouseManager, true)]
    public async Task EffectiveSystemRolePermissionsRespectTheFinalRoleBoundary(
        string roleCode,
        bool expectsRawStockView)
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var role = new Role
        {
            RoleCode = roleCode,
            RoleName = roleCode,
            IsActive = true
        };
        var rawStock = new Permission
        {
            PermissionCode = Permissions.RawStock.View,
            DisplayName = "View Raw Stock",
            Module = "RawStock",
            IsActive = true
        };
        var dashboard = new Permission
        {
            PermissionCode = Permissions.Dashboards.View,
            DisplayName = "View dashboard",
            Module = "Dashboard",
            IsActive = true
        };
        var user = new User
        {
            Email = $"{roleCode.ToLowerInvariant()}@example.test",
            NormalizedEmail = $"{roleCode.ToUpperInvariant()}@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Role",
            LastName = "Boundary",
            Status = "Active",
            Role = role
        };
        context.AddRange(role, rawStock, dashboard, user);
        role.RolePermissions.Add(new RolePermission { Permission = rawStock });
        role.RolePermissions.Add(new RolePermission { Permission = dashboard });
        await context.SaveChangesAsync();

        var snapshot = await new PermissionService(context)
            .GetSnapshotAsync(user.UserId);

        Assert.NotNull(snapshot);
        Assert.Contains(snapshot!.Permissions,
            item => item.Code == Permissions.Dashboards.View);
        Assert.Equal(
            expectsRawStockView,
            snapshot.Permissions.Any(item =>
                item.Code == Permissions.RawStock.View));
    }

    [Fact]
    public async Task LegacySuperAdminSnapshotRestoresBuyingListNavigationPermissions()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var role = new Role
        {
            RoleCode = RoleCodes.Admin,
            RoleName = "Super Admin",
            IsActive = true
        };
        var view = new Permission
        {
            PermissionCode = Permissions.BuyingLists.View,
            DisplayName = "View Buying Lists",
            Module = "BuyingList",
            IsActive = true
        };
        var viewAll = new Permission
        {
            PermissionCode = Permissions.BuyingLists.ViewAll,
            DisplayName = "View all Buying Lists",
            Module = "BuyingList",
            IsActive = true
        };
        var user = new User
        {
            Email = "superadmin@example.test",
            NormalizedEmail = "SUPERADMIN@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Super",
            LastName = "Admin",
            Status = "Active",
            Role = role
        };
        context.AddRange(role, view, viewAll, user);
        await context.SaveChangesAsync();

        var snapshot = await new PermissionService(context)
            .GetSnapshotAsync(user.UserId);

        Assert.NotNull(snapshot);
        Assert.Contains(snapshot!.Permissions,
            item => item.Code == Permissions.BuyingLists.View);
        Assert.Contains(snapshot.Permissions,
            item => item.Code == Permissions.BuyingLists.ViewAll);
    }

    [Fact]
    public void ApiResponsesUseTheFriendlyEnvelopeAndTraceIdentifier()
    {
        var context = new DefaultHttpContext
        {
            TraceIdentifier = "phase-a1-trace"
        };

        var success = ApiResponses.Ok(
            context,
            new { value = 42 },
            "Saved.",
            "SAVED");
        var failure = ApiResponses.Error(
            context,
            "Enter a valid value.",
            "VALIDATION_FAILED",
            new Dictionary<string, string[]>
            {
                ["value"] = ["A value is required."]
            });

        Assert.True(success.Success);
        Assert.Equal("phase-a1-trace", success.TraceId);
        Assert.False(failure.Success);
        Assert.Equal("VALIDATION_FAILED", failure.Code);
        Assert.Single(failure.Errors!["value"]);
    }

    [Fact]
    public async Task ForbiddenPermissionResultReturnsApi403WithoutCallingEndpoint()
    {
        var context = new DefaultHttpContext();
        context.Response.Body = new MemoryStream();
        var policy = new AuthorizationPolicyBuilder()
            .RequireAuthenticatedUser()
            .Build();
        var endpointCalled = false;

        await new ApiAuthorizationResultHandler().HandleAsync(
            _ =>
            {
                endpointCalled = true;
                return Task.CompletedTask;
            },
            context,
            policy,
            PolicyAuthorizationResult.Forbid());

        context.Response.Body.Position = 0;
        using var reader = new StreamReader(context.Response.Body);
        var responseBody = await reader.ReadToEndAsync();

        Assert.False(endpointCalled);
        Assert.Equal(StatusCodes.Status403Forbidden, context.Response.StatusCode);
        Assert.StartsWith("application/json", context.Response.ContentType);
        Assert.Contains("PERMISSION_DENIED", responseBody);
    }

    [Fact]
    public async Task OnlyDriverCreationRequiresALicenceNumber()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var roleCodes = new[]
        {
            RoleCodes.Admin,
            RoleCodes.WarehouseManager,
            RoleCodes.Packer,
            RoleCodes.MarketBuyer,
            RoleCodes.Driver
        };
        context.Roles.AddRange(roleCodes.Select((code, index) => new Role
        {
            RoleId = index + 1,
            RoleCode = code,
            RoleName = code,
            IsActive = true
        }));
        await context.SaveChangesAsync();

        var controller = new UserController(
            context,
            new EmptyPermissionService(),
            new NoopEmailService(),
            new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["FrontendUrl"] = "https://app.example.test"
                })
                .Build(),
            new NoopAuditService());

        for (var index = 0; index < roleCodes.Length - 1; index++)
        {
            var result = await controller.Create(
                new CreateUserRequest
                {
                    FirstName = "Test",
                    LastName = roleCodes[index],
                    Email = $"role{index}@example.test",
                    RoleId = index + 1
                },
                CancellationToken.None);

            Assert.IsType<CreatedAtActionResult>(result);
        }

        var driverResult = await controller.Create(
            new CreateUserRequest
            {
                FirstName = "Test",
                LastName = "Driver",
                Email = "driver@example.test",
                RoleId = roleCodes.Length
            },
            CancellationToken.None);

        var validation = Assert.IsType<ObjectResult>(driverResult);
        var problem = Assert.IsType<ValidationProblemDetails>(validation.Value);
        Assert.Contains(nameof(CreateUserRequest.LicenseNumber), problem.Errors.Keys);

        var validDriverResult = await controller.Create(
            new CreateUserRequest
            {
                FirstName = "Valid",
                LastName = "Driver",
                Email = "valid-driver@example.test",
                RoleId = roleCodes.Length,
                LicenseNumber = "LIC-2026-001",
                LicenseExpiryDate = DateTime.UtcNow.Date.AddYears(1)
            },
            CancellationToken.None);

        Assert.IsType<CreatedAtActionResult>(validDriverResult);
        Assert.Equal(5, await context.Users.CountAsync());
        Assert.Single(await context.Drivers.ToListAsync());
    }

    [Fact]
    public async Task DriverRoleConversionPersistsOneProfileAndPreservesItWhenRoleChangesAway()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var packer = new Role
        {
            RoleCode = RoleCodes.Packer,
            RoleName = "Packer",
            IsActive = true
        };
        var driver = new Role
        {
            RoleCode = RoleCodes.Driver,
            RoleName = "Driver",
            IsActive = true
        };
        var user = new User
        {
            Email = "convert.driver@example.test",
            NormalizedEmail = "CONVERT.DRIVER@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Convert",
            LastName = "Driver",
            Status = "Active",
            Role = packer,
            SecurityVersion = 1
        };
        context.AddRange(packer, driver, user);
        await context.SaveChangesAsync();
        var controller = new UserController(
            context,
            new EmptyPermissionService(),
            new NoopEmailService(),
            new ConfigurationBuilder().Build(),
            new NoopAuditService());
        var expiry = DateTime.UtcNow.Date.AddMonths(18);

        var converted = await controller.Update(
            user.UserId,
            new UpdateUserRequest
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                RoleId = driver.RoleId,
                RoleChangeReason = "Approved driver conversion",
                LicenseNumber = "DRV-2026-44",
                LicenseExpiryDate = expiry,
                VehicleAssigned = "Fleet 12",
                RowVersion = string.Empty
            },
            default);

        Assert.IsType<OkObjectResult>(converted);
        var profile = Assert.Single(await context.Drivers.ToListAsync());
        Assert.Equal("DRV-2026-44", profile.LicenseNumber);
        Assert.Equal(expiry, profile.LicenseExpiryDate);
        Assert.Equal("Fleet 12", profile.VehicleAssigned);

        var unrelatedEdit = await controller.Update(
            user.UserId,
            new UpdateUserRequest
            {
                FirstName = "Updated",
                LastName = user.LastName,
                Email = user.Email,
                RoleId = driver.RoleId,
                RowVersion = string.Empty
            },
            default);

        Assert.IsType<OkObjectResult>(unrelatedEdit);
        Assert.Single(await context.Drivers.ToListAsync());
        Assert.Equal("Fleet 12", (await context.Drivers.SingleAsync()).VehicleAssigned);

        var movedAway = await controller.Update(
            user.UserId,
            new UpdateUserRequest
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                RoleId = packer.RoleId,
                RoleChangeReason = "Returned to packing",
                RowVersion = string.Empty
            },
            default);

        Assert.IsType<OkObjectResult>(movedAway);
        Assert.Single(await context.Drivers.ToListAsync());
        Assert.Equal("DRV-2026-44", (await context.Drivers.SingleAsync()).LicenseNumber);
    }

    [Fact]
    public async Task AuthenticatedUserWithoutRoleAssignmentPermissionCannotCreateSuperAdmin()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var role = new Role
        {
            RoleCode = RoleCodes.Admin,
            RoleName = "Super Admin",
            IsActive = true
        };
        context.Roles.Add(role);
        await context.SaveChangesAsync();

        var controller = new UserController(
            context,
            new EmptyPermissionService(),
            new NoopEmailService(),
            new ConfigurationBuilder().Build(),
            new NoopAuditService())
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity(
                    [
                        new Claim(ClaimTypes.NameIdentifier, "99")
                    ], "test"))
                }
            }
        };

        var result = await controller.Create(
            new CreateUserRequest
            {
                FirstName = "Unauthorised",
                LastName = "Operator",
                Email = "unauthorised@example.test",
                RoleId = role.RoleId
            },
            default);

        Assert.IsType<ForbidResult>(result);
        Assert.Empty(await context.Users.ToListAsync());
    }

    [Fact]
    public async Task AdminClerkCannotEscalateAnotherUserToSuperAdmin()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var superAdminRole = new Role
        {
            RoleCode = RoleCodes.Admin,
            RoleName = "Super Admin",
            IsActive = true
        };
        var adminClerkRole = new Role
        {
            RoleCode = RoleCodes.AdminClerk,
            RoleName = "Admin",
            IsActive = true
        };
        var actor = new User
        {
            Email = "admin.clerk@example.test",
            NormalizedEmail = "ADMIN.CLERK@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Admin",
            LastName = "Clerk",
            Status = "Active",
            Role = adminClerkRole
        };
        context.AddRange(superAdminRole, adminClerkRole, actor);
        await context.SaveChangesAsync();

        var controller = new UserController(
            context,
            new EmptyPermissionService(),
            new NoopEmailService(),
            new ConfigurationBuilder().Build(),
            new NoopAuditService())
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity(
                    [
                        new Claim(
                            ClaimTypes.NameIdentifier,
                            actor.UserId.ToString())
                    ], "test"))
                }
            }
        };

        var result = await controller.Create(
            new CreateUserRequest
            {
                FirstName = "Escalated",
                LastName = "User",
                Email = "escalated@example.test",
                RoleId = superAdminRole.RoleId
            },
            default);

        Assert.IsType<ForbidResult>(result);
        Assert.DoesNotContain(
            await context.Users.ToListAsync(),
            user => user.Email == "escalated@example.test");
    }

    [Fact]
    public async Task SuperAdminRoleOptionsExposeOneFriendlyAdminChoiceWithoutASuperAdminCode()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var superAdminRole = new Role
        {
            RoleCode = RoleCodes.Admin,
            RoleName = "Super Admin",
            IsSystemRole = true,
            IsActive = true
        };
        var adminRole = new Role
        {
            RoleCode = RoleCodes.AdminClerk,
            RoleName = "Admin",
            IsSystemRole = true,
            IsActive = true
        };
        var driverRole = new Role
        {
            RoleCode = RoleCodes.Driver,
            RoleName = "Driver",
            IsSystemRole = true,
            IsActive = true
        };
        var actor = new User
        {
            Email = "role.owner@example.test",
            NormalizedEmail = "ROLE.OWNER@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Role",
            LastName = "Owner",
            Status = "Active",
            Role = superAdminRole
        };
        context.AddRange(superAdminRole, adminRole, driverRole, actor);
        await context.SaveChangesAsync();

        var controller = new RolesController(context, new NoopAuditService())
        {
            ControllerContext = AuthenticatedContext(actor.UserId)
        };

        var result = await controller.Active(CancellationToken.None);

        var ok = Assert.IsType<OkObjectResult>(result);
        using var document = JsonDocument.Parse(JsonSerializer.Serialize(
            ok.Value,
            new JsonSerializerOptions(JsonSerializerDefaults.Web)));
        var roleOptions = document.RootElement.EnumerateArray().ToArray();
        var friendlyAdmin = Assert.Single(roleOptions, item =>
            item.GetProperty("roleName").GetString() == "Admin");
        Assert.Equal(
            RoleCodes.AdminClerk,
            friendlyAdmin.GetProperty("roleCode").GetString());
        Assert.Contains(roleOptions, item =>
            item.GetProperty("roleCode").GetString() == RoleCodes.Admin &&
            item.GetProperty("roleName").GetString() == "Super Admin");
        Assert.DoesNotContain(roleOptions, item =>
            item.GetProperty("roleCode").GetString() == "SuperAdmin");
    }

    [Fact]
    public async Task NormalAdminRoleOptionsKeepFriendlyAdminButHidePersistedSuperAdmin()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var superAdminRole = new Role
        {
            RoleCode = RoleCodes.Admin,
            RoleName = "Super Admin",
            IsSystemRole = true,
            IsActive = true
        };
        var adminRole = new Role
        {
            RoleCode = RoleCodes.AdminClerk,
            RoleName = "Admin",
            IsSystemRole = true,
            IsActive = true
        };
        var actor = new User
        {
            Email = "normal.admin@example.test",
            NormalizedEmail = "NORMAL.ADMIN@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Normal",
            LastName = "Administrator",
            Status = "Active",
            Role = adminRole
        };
        context.AddRange(superAdminRole, adminRole, actor);
        await context.SaveChangesAsync();

        var controller = new RolesController(context, new NoopAuditService())
        {
            ControllerContext = AuthenticatedContext(actor.UserId)
        };

        var result = await controller.Active(CancellationToken.None);

        var ok = Assert.IsType<OkObjectResult>(result);
        using var document = JsonDocument.Parse(JsonSerializer.Serialize(
            ok.Value,
            new JsonSerializerOptions(JsonSerializerDefaults.Web)));
        var roleOptions = document.RootElement.EnumerateArray().ToArray();
        Assert.Contains(roleOptions, item =>
            item.GetProperty("roleCode").GetString() == RoleCodes.AdminClerk &&
            item.GetProperty("roleName").GetString() == "Admin");
        Assert.DoesNotContain(roleOptions, item =>
            item.GetProperty("roleCode").GetString() == RoleCodes.Admin);
    }

    [Fact]
    public async Task SuperAdminCanCreateBothAdministrationLevelsAndReloadFriendlyNames()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var superAdminRole = new Role
        {
            RoleCode = RoleCodes.Admin,
            RoleName = "Super Admin",
            IsSystemRole = true,
            IsActive = true
        };
        var adminRole = new Role
        {
            RoleCode = RoleCodes.AdminClerk,
            RoleName = "Admin",
            IsSystemRole = true,
            IsActive = true
        };
        var actor = new User
        {
            Email = "creator@example.test",
            NormalizedEmail = "CREATOR@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Super",
            LastName = "Administrator",
            Status = "Active",
            Role = superAdminRole
        };
        context.AddRange(superAdminRole, adminRole, actor);
        await context.SaveChangesAsync();

        var controller = new UserController(
            context,
            new EmptyPermissionService(),
            new NoopEmailService(),
            new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["FrontendUrl"] = "https://app.example.test"
                })
                .Build(),
            new NoopAuditService())
        {
            ControllerContext = AuthenticatedContext(actor.UserId)
        };

        var adminResult = await controller.Create(
            new CreateUserRequest
            {
                FirstName = "Standard",
                LastName = "Administrator",
                Email = "standard.admin@example.test",
                RoleId = adminRole.RoleId
            },
            CancellationToken.None);
        var superAdminResult = await controller.Create(
            new CreateUserRequest
            {
                FirstName = "Elevated",
                LastName = "Administrator",
                Email = "elevated.admin@example.test",
                RoleId = superAdminRole.RoleId
            },
            CancellationToken.None);

        Assert.IsType<CreatedAtActionResult>(adminResult);
        Assert.IsType<CreatedAtActionResult>(superAdminResult);
        Assert.Equal(
            RoleCodes.AdminClerk,
            (await context.Users.Include(item => item.Role).SingleAsync(item =>
                item.Email == "standard.admin@example.test")).Role!.RoleCode);
        Assert.Equal(
            RoleCodes.Admin,
            (await context.Users.Include(item => item.Role).SingleAsync(item =>
                item.Email == "elevated.admin@example.test")).Role!.RoleCode);

        var searchResult = await controller.Search(
            new UserSearchQuery { PageSize = 100 },
            CancellationToken.None);
        var ok = Assert.IsType<OkObjectResult>(searchResult);
        using var document = JsonDocument.Parse(JsonSerializer.Serialize(
            ok.Value,
            new JsonSerializerOptions(JsonSerializerDefaults.Web)));
        var users = document.RootElement.GetProperty("items").EnumerateArray().ToArray();
        Assert.Contains(users, item =>
            item.GetProperty("email").GetString() == "standard.admin@example.test" &&
            item.GetProperty("roleCode").GetString() == RoleCodes.AdminClerk &&
            item.GetProperty("role").GetString() == "Admin");
        Assert.Contains(users, item =>
            item.GetProperty("email").GetString() == "elevated.admin@example.test" &&
            item.GetProperty("roleCode").GetString() == RoleCodes.Admin &&
            item.GetProperty("role").GetString() == "Super Admin");
    }

    private static ControllerContext AuthenticatedContext(int userId) =>
        new()
        {
            HttpContext = new DefaultHttpContext
            {
                User = new ClaimsPrincipal(new ClaimsIdentity(
                [
                    new Claim(ClaimTypes.NameIdentifier, userId.ToString())
                ], "test"))
            }
        };

    private sealed class EmptyPermissionService : IPermissionService
    {
        public Task<UserPermissionSnapshot?> GetSnapshotAsync(
            int userId,
            CancellationToken cancellationToken = default) =>
            Task.FromResult<UserPermissionSnapshot?>(null);

        public Task<bool> HasPermissionAsync(
            int userId,
            string permissionCode,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(false);
    }

    private sealed class NoopAuditService : IAuditService
    {
        public Task RecordAsync(
            AuditEvent auditEvent,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;
    }

    private sealed class NoopEmailService : IEmailService
    {
        public Task SendPasswordResetEmailAsync(
            string recipientEmail,
            string resetLink) => Task.CompletedTask;

        public Task SendExpiryAlertEmailAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string reviewLink,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;

        public Task SendExpiryDecisionConfirmationAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string decision,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;

        public Task SendCustomerOrderLinkEmailAsync(
            string recipientEmail,
            string customerName,
            string orderLink,
            DateTime expiresAtUtc,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;
    }
}
