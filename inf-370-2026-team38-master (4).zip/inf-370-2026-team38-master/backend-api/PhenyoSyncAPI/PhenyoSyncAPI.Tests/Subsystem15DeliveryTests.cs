using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Delivery;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Protects conflict-safe assignment, ownership, proof rules and coordinated order completion.
public sealed class Subsystem15DeliveryTests
{
    [Fact]
    public async Task AvailableDriver_CanBeAssignedAndHistoryAndAuditAreRecorded()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var delivery = await db.ScheduleAsync();

        var available = await db.Service.AvailableDriversAsync(delivery.DeliveryId, default);
        var assigned = await db.Service.AssignDriverAsync(
            delivery.DeliveryId,
            new AssignDriverDto
            {
                DriverId = db.Driver.DriverId,
                AssignmentNotes = "Morning delivery"
            },
            db.Manager.UserId,
            default);

        Assert.Contains(available, item => item.DriverId == db.Driver.DriverId);
        Assert.Equal(DeliveryStatuses.Assigned, assigned.Status);
        Assert.Equal(db.Driver.DriverId, assigned.DriverId);
        Assert.Single(assigned.AssignmentHistory);
        Assert.Contains(assigned.StatusHistory, item => item.NewStatus == DeliveryStatuses.Assigned);
        Assert.Contains(db.Audit.Events, item => item.OperationName == "AssignDriver");
        Assert.Contains(
            await db.Context.AuditLogs.ToListAsync(),
            item => item.SystemModule == AuditModules.DeliveryLogistics);
    }

    [Theory]
    [InlineData(-30, 30)]
    [InlineData(0, 60)]
    [InlineData(-60, 120)]
    public async Task OverlappingWindow_IsUnavailableAndRejected(int startMinutes, int endMinutes)
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var existing = await db.ScheduleAsync();
        await db.Service.AssignDriverAsync(
            existing.DeliveryId,
            new AssignDriverDto { DriverId = db.Driver.DriverId },
            db.Manager.UserId,
            default);
        var candidate = await db.AddDeliveryAsync(
            db.WindowStart.AddMinutes(startMinutes),
            db.WindowStart.AddMinutes(endMinutes));

        Assert.DoesNotContain(
            await db.Service.AvailableDriversAsync(candidate.DeliveryId, default),
            item => item.DriverId == db.Driver.DriverId);
        var error = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            db.Service.AssignDriverAsync(
                candidate.DeliveryId,
                new AssignDriverDto { DriverId = db.Driver.DriverId },
                db.Manager.UserId,
                default));
        Assert.Equal(409, error.StatusCode);
    }

    [Fact]
    public async Task EndEqualsStart_DoesNotOverlap()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var first = await db.ScheduleAsync();
        await db.Service.AssignDriverAsync(
            first.DeliveryId,
            new AssignDriverDto { DriverId = db.Driver.DriverId },
            db.Manager.UserId,
            default);
        var second = await db.AddDeliveryAsync(
            db.WindowStart.AddHours(1),
            db.WindowStart.AddHours(2));

        Assert.Contains(
            await db.Service.AvailableDriversAsync(second.DeliveryId, default),
            item => item.DriverId == db.Driver.DriverId);
    }

    [Fact]
    public async Task InactiveOrLicenceExpiredDriver_IsRejected()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var delivery = await db.ScheduleAsync();
        db.Driver.LicenseExpiryDate = db.WindowStart.AddMinutes(20);
        await db.Context.SaveChangesAsync();

        var error = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            db.Service.AssignDriverAsync(
                delivery.DeliveryId,
                new AssignDriverDto { DriverId = db.Driver.DriverId },
                db.Manager.UserId,
                default));
        Assert.Equal(409, error.StatusCode);
        Assert.DoesNotContain(
            await db.Service.AvailableDriversAsync(delivery.DeliveryId, default),
            item => item.DriverId == db.Driver.DriverId);
    }

    [Fact]
    public async Task Reassignment_RequiresReasonAndPreservesOldAssignment()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var second = await db.AddDriverAsync("second.driver@example.test");
        var delivery = await db.ScheduleAsync();
        await db.Service.AssignDriverAsync(
            delivery.DeliveryId,
            new AssignDriverDto { DriverId = db.Driver.DriverId },
            db.Manager.UserId,
            default);

        var missingReason = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            db.Service.AssignDriverAsync(
                delivery.DeliveryId,
                new AssignDriverDto { DriverId = second.DriverId },
                db.Manager.UserId,
                default));
        Assert.Equal(400, missingReason.StatusCode);

        var reassigned = await db.Service.AssignDriverAsync(
            delivery.DeliveryId,
            new AssignDriverDto
            {
                DriverId = second.DriverId,
                ReassignmentReason = "Original driver became unavailable"
            },
            db.Manager.UserId,
            default);
        Assert.Equal(2, reassigned.AssignmentHistory.Count);
        Assert.Single(reassigned.AssignmentHistory, item => item.IsCurrent);
        Assert.Contains(
            reassigned.AssignmentHistory,
            item => !item.IsCurrent && item.ReassignmentReason != null);
    }

    [Fact]
    public async Task AssignedDriver_StartsAndCompletesWithImmutableProofAndDeliveredOrder()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var delivery = await db.ScheduleAsync();
        await db.Service.AssignDriverAsync(
            delivery.DeliveryId,
            new AssignDriverDto { DriverId = db.Driver.DriverId },
            db.Manager.UserId,
            default);
        var dispatchedOrder = await db.Context.SalesOrders.SingleAsync(item =>
            item.SalesOrderId == delivery.SalesOrderId);
        dispatchedOrder.Status = SalesOrderStatuses.OutForDelivery;
        await db.Context.SaveChangesAsync();
        var started = await db.Service.StartAsync(
            delivery.DeliveryId,
            db.Driver.UserId,
            "Driver",
            default);
        var proof = await db.Service.CompleteAsync(
            delivery.DeliveryId,
            new CompleteDeliveryDto
            {
                RecipientName = "Receiving Clerk",
                RecipientConfirmed = true,
                FulfillmentConfirmed = true,
                ProofReference = "POD-TEST-001"
            },
            db.Driver.UserId,
            "Driver",
            default);

        Assert.Equal(DeliveryStatuses.InTransit, started.Status);
        Assert.True(proof.RecipientConfirmed);
        Assert.False(proof.CompletedOnBehalfOfDriver);
        Assert.Equal(
            SalesOrderStatuses.Delivered,
            (await db.Context.SalesOrders.FindAsync(delivery.SalesOrderId))!.Status);
        Assert.Single(await db.Context.DeliveryCompletionRecords.ToListAsync());

        var secondAttempt = await db.Service.CompleteAsync(
                delivery.DeliveryId,
                new CompleteDeliveryDto
                {
                    RecipientName = "Receiving Clerk",
                    RecipientConfirmed = true,
                    FulfillmentConfirmed = true
                },
                db.Driver.UserId,
                "Driver",
                default);
        Assert.Equal(proof.DeliveryCompletionRecordId, secondAttempt.DeliveryCompletionRecordId);
        Assert.Single(await db.Context.DeliveryCompletionRecords.ToListAsync());
    }

    [Fact]
    public async Task ForegroundTracking_IsOwnedIdempotentAndStopsOnCompletion()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var delivery = await db.ScheduleAndStartAsync();
        var tracking = new DriverTrackingService(
            db.Context,
            new FakeDeliveryAuditService());
        var startRequest = new StartTrackingRequest
        {
            ConsentConfirmed = true,
            OperationId = "tracking-start-test"
        };

        var session = await tracking.StartAsync(
            delivery.DeliveryId,
            startRequest,
            db.Driver.UserId,
            false,
            "tracking-correlation-test",
            default);
        var retrySession = await tracking.StartAsync(
            delivery.DeliveryId,
            startRequest,
            db.Driver.UserId,
            false,
            "tracking-correlation-test",
            default);
        Assert.Equal(session.TrackingSessionId, retrySession.TrackingSessionId);

        var wrongDriver = await Assert.ThrowsAsync<PhaseCException>(() =>
            tracking.AddLocationAsync(
                session.TrackingSessionId,
                Location("wrong-driver-location"),
                db.Manager.UserId,
                false,
                default));
        Assert.Equal(403, wrongDriver.StatusCode);

        var request = Location("location-point-1");
        var first = await tracking.AddLocationAsync(
            session.TrackingSessionId,
            request,
            db.Driver.UserId,
            false,
            default);
        var retry = await tracking.AddLocationAsync(
            session.TrackingSessionId,
            request,
            db.Driver.UserId,
            false,
            default);
        Assert.Equal(first.CapturedAtUtc, retry.CapturedAtUtc);
        Assert.Single(await db.Context.DriverLocationUpdates.ToListAsync());

        await db.Service.CompleteAsync(
            delivery.DeliveryId,
            new CompleteDeliveryDto
            {
                RecipientName = "Receiving Clerk",
                RecipientConfirmed = true,
                FulfillmentConfirmed = true,
                ProofReference = "POD-TRACKING-001"
            },
            db.Driver.UserId,
            RoleCodes.Driver,
            default);
        var stored = await db.Context.DriverTrackingSessions.SingleAsync();
        Assert.Equal(TrackingSessionStatuses.Completed, stored.Status);
        Assert.NotNull(stored.EndedAtUtc);

        var restart = await Assert.ThrowsAsync<PhaseCException>(() =>
            tracking.StartAsync(
                delivery.DeliveryId,
                startRequest,
                db.Driver.UserId,
                false,
                "tracking-restart-test",
                default));
        Assert.Equal(409, restart.StatusCode);
    }

    [Fact]
    public async Task AnotherDriverCannotViewStartOrCompleteDelivery()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var other = await db.AddDriverAsync("other.driver@example.test");
        var delivery = await db.ScheduleAsync();
        await db.Service.AssignDriverAsync(
            delivery.DeliveryId,
            new AssignDriverDto { DriverId = db.Driver.DriverId },
            db.Manager.UserId,
            default);

        var view = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            db.Service.GetAsync(delivery.DeliveryId, other.UserId, "Driver", default));
        var start = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            db.Service.StartAsync(delivery.DeliveryId, other.UserId, "Driver", default));
        Assert.Equal(403, view.StatusCode);
        Assert.Equal(403, start.StatusCode);
    }

    [Fact]
    public async Task ProofUpload_AllowsAssignedDriverAndRejectsOtherUsers()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var other = await db.AddDriverAsync("proof.other.driver@example.test");
        var delivery = await db.ScheduleAsync();
        await db.Service.AssignDriverAsync(
            delivery.DeliveryId,
            new AssignDriverDto { DriverId = db.Driver.DriverId },
            db.Manager.UserId,
            default);
        var proofs = new DeliveryProofImageService(
            db.Context,
            new FakeProtectedFileStorage(),
            new DeliveryProofSettings(),
            db.Audit);
        var upload = new FormFile(
            new MemoryStream([1, 2, 3, 4]),
            0,
            4,
            "file",
            "proof.jpg")
        {
            Headers = new HeaderDictionary(),
            ContentType = "image/jpeg"
        };

        var saved = await proofs.UploadAsync(
            delivery.DeliveryId,
            upload,
            new UploadDeliveryProofImageRequest { Caption = "Recipient accepted" },
            db.Driver.UserId,
            RoleCodes.Driver,
            false,
            default);

        Assert.Equal(delivery.DeliveryId, saved.DeliveryId);
        Assert.True(saved.IsPrimary);
        Assert.Single(await db.Context.DeliveryProofImages.ToListAsync());

        var otherDriver = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            proofs.UploadAsync(
                delivery.DeliveryId,
                upload,
                new UploadDeliveryProofImageRequest(),
                other.UserId,
                RoleCodes.Driver,
                false,
                default));
        var unrelatedRole = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            proofs.UploadAsync(
                delivery.DeliveryId,
                upload,
                new UploadDeliveryProofImageRequest(),
                db.Manager.UserId,
                RoleCodes.Packer,
                false,
                default));

        Assert.Equal(403, otherDriver.StatusCode);
        Assert.Equal(403, unrelatedRole.StatusCode);
    }

    [Fact]
    public async Task ManagementCompletion_RequiresReason()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var delivery = await db.ScheduleAndStartAsync();
        var request = new CompleteDeliveryDto
        {
            RecipientName = "Receiving Clerk",
            RecipientConfirmed = true,
            FulfillmentConfirmed = true
        };

        var error = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            db.Service.CompleteAsync(
                delivery.DeliveryId,
                request,
                db.Manager.UserId,
                RoleCodes.WarehouseManager,
                default));
        Assert.Equal(400, error.StatusCode);

        request.ManagementOverrideReason = "Driver device failed after recipient confirmation";
        var proof = await db.Service.CompleteAsync(
            delivery.DeliveryId,
            request,
            db.Manager.UserId,
            RoleCodes.WarehouseManager,
            default);
        Assert.True(proof.CompletedOnBehalfOfDriver);
    }

    [Fact]
    public async Task CompletionValidatesRecipientAndFulfillment()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var delivery = await db.ScheduleAndStartAsync();

        var error = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            db.Service.CompleteAsync(
                delivery.DeliveryId,
                new CompleteDeliveryDto { RecipientName = " " },
                db.Driver.UserId,
                "Driver",
                default));
        Assert.Equal(400, error.StatusCode);
    }

    [Fact]
    public async Task MyDeliveriesUsesAuthenticatedDriverMappingOnly()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var own = await db.ScheduleAsync();
        await db.Service.AssignDriverAsync(
            own.DeliveryId,
            new AssignDriverDto { DriverId = db.Driver.DriverId },
            db.Manager.UserId,
            default);
        await db.AddDeliveryAsync(db.WindowStart.AddDays(1), db.WindowStart.AddDays(1).AddHours(1));

        var mine = await db.Service.MyDeliveriesAsync(db.Driver.UserId, null, null, null, default);
        Assert.Single(mine);
        Assert.Equal(own.DeliveryId, mine[0].DeliveryId);

        var error = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            db.Service.MyDeliveriesAsync(db.Manager.UserId, null, null, null, default));
        Assert.Equal(403, error.StatusCode);
    }

    [Fact]
    public async Task CompletedDeliveryCannotBeReassigned()
    {
        await using var db = await DeliveryTestDatabase.CreateAsync();
        var second = await db.AddDriverAsync("replacement.driver@example.test");
        var delivery = await db.ScheduleAndStartAsync();
        await db.Service.CompleteAsync(
            delivery.DeliveryId,
            new CompleteDeliveryDto
            {
                RecipientName = "Receiver",
                RecipientConfirmed = true,
                FulfillmentConfirmed = true
            },
            db.Driver.UserId,
            "Driver",
            default);

        var error = await Assert.ThrowsAsync<DeliveryManagementException>(() =>
            db.Service.AssignDriverAsync(
                delivery.DeliveryId,
                new AssignDriverDto
                {
                    DriverId = second.DriverId,
                    ReassignmentReason = "Attempt after completion"
                },
                db.Manager.UserId,
                default));
        Assert.Equal(409, error.StatusCode);
    }

    [Fact]
    public void ControllerDeclaresPermissionAuthorization()
    {
        var controller = typeof(DeliveriesController).GetCustomAttribute<AuthorizeAttribute>();
        var search = typeof(DeliveriesController).GetMethod(nameof(DeliveriesController.Search))!
            .GetCustomAttribute<AuthorizeAttribute>();
        var get = typeof(DeliveriesController).GetMethod(nameof(DeliveriesController.Get))!
            .GetCustomAttribute<AuthorizeAttribute>();
        var assign = typeof(DeliveriesController).GetMethod(nameof(DeliveriesController.AssignDriver))!
            .GetCustomAttribute<AuthorizeAttribute>();
        var my = typeof(DeliveriesController).GetMethod(nameof(DeliveriesController.My))!
            .GetCustomAttribute<AuthorizeAttribute>();
        var complete = typeof(DeliveriesController).GetMethod(nameof(DeliveriesController.Complete))!
            .GetCustomAttribute<AuthorizeAttribute>();

        Assert.NotNull(controller);
        Assert.Null(controller!.Policy);
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.Deliveries.View,
            search!.Policy);
        Assert.Equal(
            HasAnyPermissionAttribute.PolicyPrefix + string.Join(",",
                Permissions.Deliveries.View,
                Permissions.Deliveries.ViewOwn),
            get!.Policy);
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix +
            Permissions.Deliveries.AssignDriver,
            assign!.Policy);
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix +
            Permissions.Deliveries.ViewOwn,
            my!.Policy);
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix +
            Permissions.Deliveries.CompleteOwn,
            complete!.Policy);
        Assert.DoesNotContain(
            Permissions.Deliveries.AssignDriver,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
    }

    [Fact]
    public async Task ControllerExecutionWrapper_DoesNotNestActionResults()
    {
        var execute = typeof(DeliveriesController)
            .GetMethods(BindingFlags.NonPublic | BindingFlags.Static)
            .Single(method =>
                method.Name == "Execute" &&
                method.IsGenericMethodDefinition);
        var closedExecute = execute.MakeGenericMethod(typeof(OkObjectResult));
        Func<Task<OkObjectResult>> action = () =>
            Task.FromResult(new OkObjectResult(new
            {
                message = "Delivery completed.",
                proof = "POD-001"
            }));

        var task = Assert.IsAssignableFrom<Task<IActionResult>>(
            closedExecute.Invoke(null, [action]));
        var result = Assert.IsType<OkObjectResult>(await task);
        var response = result.Value!;

        Assert.Equal(
            "Delivery completed.",
            response.GetType().GetProperty("message")!.GetValue(response));
        Assert.Equal(
            "POD-001",
            response.GetType().GetProperty("proof")!.GetValue(response));
    }

    private static DriverLocationRequest Location(string operationId) =>
        new()
        {
            Latitude = -25.7479m,
            Longitude = 28.2293m,
            AccuracyMetres = 6m,
            CapturedAtUtc = DateTime.UtcNow,
            OperationId = operationId
        };
}

internal sealed class DeliveryTestDatabase : IAsyncDisposable
{
    private readonly SqliteConnection _connection;
    public PhenyoSyncDbContext Context { get; }
    public DeliveryService Service { get; }
    public FakeDeliveryAuditService Audit { get; }
    public User Manager { get; private set; } = null!;
    public Driver Driver { get; private set; } = null!;
    public DateTime WindowStart { get; } = DateTime.UtcNow.Date.AddDays(2).AddHours(9);

    private DeliveryTestDatabase(
        SqliteConnection connection,
        PhenyoSyncDbContext context,
        DeliveryService service,
        FakeDeliveryAuditService audit)
    {
        _connection = connection;
        Context = context;
        Service = service;
        Audit = audit;
    }

    public static async Task<DeliveryTestDatabase> CreateAsync()
    {
        var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var context = new PhenyoSyncDbContext(
            new DbContextOptionsBuilder<PhenyoSyncDbContext>()
                .UseSqlite(connection)
                .Options);
        await context.Database.EnsureCreatedAsync();
        var audit = new FakeDeliveryAuditService();
        var service = new DeliveryService(
            context,
            new FakeDeliveryOrderWorkflow(),
            audit);
        var db = new DeliveryTestDatabase(connection, context, service, audit);
        await db.SeedAsync();
        return db;
    }

    public async Task<DeliveryDetailDto> ScheduleAsync() =>
        await Service.ScheduleAsync(
            new ScheduleDeliveryDto
            {
                SalesOrderId = await AddPackedOrderAsync(),
                ScheduledStartUtc = WindowStart,
                ScheduledEndUtc = WindowStart.AddHours(1)
            },
            Manager.UserId,
            default);

    public async Task<DeliveryDetailDto> ScheduleAndStartAsync()
    {
        var delivery = await ScheduleAsync();
        await Service.AssignDriverAsync(
            delivery.DeliveryId,
            new AssignDriverDto { DriverId = Driver.DriverId },
            Manager.UserId,
            default);
        var order = await Context.SalesOrders.SingleAsync(item =>
            item.SalesOrderId == delivery.SalesOrderId);
        order.Status = SalesOrderStatuses.OutForDelivery;
        await Context.SaveChangesAsync();
        return await Service.StartAsync(delivery.DeliveryId, Driver.UserId, "Driver", default);
    }

    public async Task<Delivery> AddDeliveryAsync(DateTime start, DateTime end)
    {
        var orderId = await AddPackedOrderAsync();
        var detail = await Service.ScheduleAsync(
            new ScheduleDeliveryDto
            {
                SalesOrderId = orderId,
                ScheduledStartUtc = start,
                ScheduledEndUtc = end
            },
            Manager.UserId,
            default);
        return (await Context.Deliveries.FindAsync(detail.DeliveryId))!;
    }

    public async Task<Driver> AddDriverAsync(string email)
    {
        var role = await Context.Roles.SingleAsync(item => item.RoleName == "Driver");
        var user = User(email, "Other", "Driver", role);
        var driver = new Driver
        {
            User = user,
            LicenseNumber = $"LIC-{Guid.NewGuid():N}",
            LicenseExpiryDate = WindowStart.AddYears(1),
            AvailabilityStatus = "Available",
            VehicleAssigned = "Van"
        };
        Context.Drivers.Add(driver);
        await Context.SaveChangesAsync();
        return driver;
    }

    private async Task SeedAsync()
    {
        var managerRole = new Role { RoleName = "BusinessManager", Users = [], RolePermissions = [] };
        var driverRole = new Role { RoleName = "Driver", Users = [], RolePermissions = [] };
        Manager = User("delivery.manager@example.test", "Delivery", "Manager", managerRole);
        var driverUser = User("assigned.driver@example.test", "Assigned", "Driver", driverRole);
        Driver = new Driver
        {
            User = driverUser,
            LicenseNumber = "LIC-TEST-001",
            LicenseExpiryDate = WindowStart.AddYears(1),
            AvailabilityStatus = "Available",
            VehicleAssigned = "Van 12"
        };
        Context.AddRange(Manager, Driver);
        await Context.SaveChangesAsync();
    }

    private async Task<int> AddPackedOrderAsync()
    {
        var customer = new Customer
        {
            CustomerNumber = $"CUS-{Guid.NewGuid():N}"[..20],
            CustomerName = "Delivery Test Customer",
            Email = $"customer.{Guid.NewGuid():N}@example.test",
            DeliveryAddress = "15 Warehouse Road",
            BillingAddress = "15 Warehouse Road",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var order = new SalesOrder
        {
            OrderNumber = $"SO-{Guid.NewGuid():N}"[..25],
            Customer = customer,
            OrderDateUtc = DateTime.UtcNow,
            RequestedDeliveryDateUtc = WindowStart,
            DeliveryAddressSnapshot = customer.DeliveryAddress,
            BillingAddressSnapshot = customer.BillingAddress,
            Status = SalesOrderStatuses.ReadyForDispatch,
            ValidationStatus = OrderValidationStatuses.Approved,
            CreatedAtUtc = DateTime.UtcNow
        };
        Context.SalesOrders.Add(order);
        await Context.SaveChangesAsync();
        return order.SalesOrderId;
    }

    private static User User(string email, string first, string last, Role role) => new()
    {
        Email = email,
        PasswordHash = "not-a-real-password",
        FirstName = first,
        LastName = last,
        Status = "Active",
        Role = role,
        CreatedDate = DateTime.UtcNow
    };

    public async ValueTask DisposeAsync()
    {
        await Context.DisposeAsync();
        await _connection.DisposeAsync();
    }
}

internal sealed class FakeDeliveryOrderWorkflow : IOrderWorkflowService
{
    public Task<SalesOrderDetailDto> ApproveAsync(
        int orderId,
        OrderDecisionDto request,
        int userId,
        CancellationToken cancellationToken) =>
        throw new NotSupportedException();

    public Task<SalesOrderDetailDto> RejectAsync(
        int orderId,
        OrderDecisionDto request,
        int userId,
        CancellationToken cancellationToken) =>
        throw new NotSupportedException();

    public Task ApplyLogisticsTransitionAsync(
        SalesOrder order,
        string newStatus,
        int userId,
        string? reason,
        CancellationToken cancellationToken)
    {
        var valid = order.Status == SalesOrderStatuses.OutForDelivery &&
                    newStatus == SalesOrderStatuses.Delivered;
        if (!valid)
            throw new OrderManagementException(409, "Invalid order delivery transition.");
        var previous = order.Status;
        order.Status = newStatus;
        order.UpdatedAtUtc = DateTime.UtcNow;
        order.StatusHistory.Add(new OrderStatusHistory
        {
            PreviousStatus = previous,
            NewStatus = newStatus,
            ChangedAtUtc = DateTime.UtcNow,
            ChangedByUserId = userId,
            Reason = reason
        });
        return Task.CompletedTask;
    }

    public Task<SalesOrderDetailDto> CancelAsync(
        int orderId,
        CancelOrderDto request,
        int userId,
        CancellationToken cancellationToken) =>
        throw new NotSupportedException();

    public Task<SalesOrderDetailDto> TransitionAsync(
        int orderId,
        UpdateOrderStatusDto request,
        int userId,
        string role,
        CancellationToken cancellationToken) =>
        throw new NotSupportedException();

    public Task<InvoiceDto> GetInvoiceAsync(int orderId, CancellationToken cancellationToken) =>
        throw new NotSupportedException();
}

internal sealed class FakeDeliveryAuditService : IAuditService
{
    public List<AuditEvent> Events { get; } = [];

    public Task RecordAsync(AuditEvent auditEvent, CancellationToken cancellationToken = default)
    {
        Events.Add(auditEvent);
        return Task.CompletedTask;
    }
}

internal sealed class FakeProtectedFileStorage : IProtectedFileStorage
{
    public Task<StoredImageResult> SaveProofImageAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        CancellationToken cancellationToken) => Task.FromResult(new StoredImageResult(
            Stored("proof.jpg", uploadedByUserId),
            Stored("proof-thumb.jpg", uploadedByUserId)));

    public Task<StoredImageResult> SaveDocketImageAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        CancellationToken cancellationToken) =>
        SaveProofImageAsync(file, uploadedByUserId, maximumMegabytes, cancellationToken);

    public Task<StoredFile> SaveTrainingVideoAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        CancellationToken cancellationToken) =>
        Task.FromResult(Stored("training.mp4", uploadedByUserId));

    public Task<StoredFile> SaveCaptionAsync(
        IFormFile file,
        int uploadedByUserId,
        CancellationToken cancellationToken) =>
        Task.FromResult(Stored("caption.vtt", uploadedByUserId));

    public FileStream OpenRead(StoredFile file) => throw new NotSupportedException();

    public Task DeletePhysicalAsync(StoredFile file, CancellationToken cancellationToken) =>
        Task.CompletedTask;

    private static StoredFile Stored(string name, int userId) => new()
    {
        StorageKey = Guid.NewGuid().ToString("N"),
        OriginalFileName = name,
        SafeDownloadName = name,
        ContentType = "image/jpeg",
        Extension = ".jpg",
        SizeBytes = 4,
        Sha256Hash = new string('a', 64),
        UploadedAtUtc = DateTime.UtcNow,
        UploadedByUserId = userId
    };
}

internal sealed class DeliveryProofSettings : ISystemSettingProvider
{
    public Task<int> GetIntAsync(string key, CancellationToken cancellationToken = default) =>
        Task.FromResult(5);
    public Task<decimal> GetDecimalAsync(string key, CancellationToken cancellationToken = default) =>
        Task.FromResult(0m);
    public Task<bool> GetBooleanAsync(string key, CancellationToken cancellationToken = default) =>
        Task.FromResult(true);
    public Task<string> GetStringAsync(string key, CancellationToken cancellationToken = default) =>
        Task.FromResult(string.Empty);
    public Task<string[]> GetStringArrayAsync(string key, CancellationToken cancellationToken = default) =>
        Task.FromResult(Array.Empty<string>());
    public void Invalidate(string key) { }
    public void InvalidateAll() { }
}
