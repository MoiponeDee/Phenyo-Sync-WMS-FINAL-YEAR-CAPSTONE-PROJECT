using System.ComponentModel.DataAnnotations;
using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.DTOs.Lookups;
using PhenyoSyncAPI.DTOs.Expiry;
using PhenyoSyncAPI.DTOs.Product;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Services;
using PhenyoSyncAPI.Security;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Covers core product, batch, expiry and supporting service business rules.
public sealed class Subsystem7ServiceTests
{
    [Fact]
    public async Task MakeProduct_ConsumesRawStockAndCreatesTraceableFinishedBatch()
    {
        await using var database = await TestDatabase.CreateAsync();
        var service = new ProductionService(database.Context);
        var product = await database.SeedPackableProductAsync(
            "Fresh Test Product",
            rawQuantity: 100m);

        var result = await service.MakeProductAsync(
            database.Request(product, 12.5m),
            database.Manager.UserId,
            default);

        Assert.False(result.ProductCreated);
        Assert.Equal(1, await database.Context.Products.CountAsync());
        Assert.Equal(1, await database.Context.ProductBatches.CountAsync());
        Assert.Equal(12.5m, (await database.Context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.Equal(StockMovementTypes.Increase, (await database.Context.StockMovements.SingleAsync()).MovementType);
        Assert.Equal(87.5m, (await database.Context.RawStockBalances.SingleAsync()).QuantityOnHand);
        Assert.Equal(
            -12.5m,
            (await database.Context.RawStockMovements.SingleAsync()).QuantityChange);
        Assert.Single(await database.Context.PackingConversions.ToListAsync());
        Assert.Single(await database.Context.PackingConversionRawStock.ToListAsync());
        Assert.False(string.IsNullOrWhiteSpace(result.CorrelationId));
    }

    [Fact]
    public async Task MakeProduct_InsufficientRawStockRollsBackEveryWrite()
    {
        await using var database = await TestDatabase.CreateAsync();
        var service = new ProductionService(database.Context);
        var product = await database.SeedPackableProductAsync(
            "Insufficient Raw Product",
            rawQuantity: 5m);

        var error = await Assert.ThrowsAsync<Subsystem7Exception>(() =>
            service.MakeProductAsync(
                database.Request(product, 10m),
                database.Manager.UserId,
                default));

        Assert.Equal(409, error.StatusCode);
        Assert.Equal(
            5m,
            (await database.Context.RawStockBalances.SingleAsync())
                .QuantityOnHand);
        Assert.Equal(
            5m,
            (await database.Context.RawStockBatches.SingleAsync())
                .QuantityRemaining);
        Assert.Empty(await database.Context.ProductBatches.ToListAsync());
        Assert.Empty(await database.Context.Stocks.ToListAsync());
        Assert.Empty(await database.Context.StockMovements.ToListAsync());
        Assert.Empty(await database.Context.RawStockMovements.ToListAsync());
        Assert.Empty(await database.Context.PackingConversions.ToListAsync());
    }

    [Fact]
    public async Task PackableProducts_SubtractsReservedRawStockFromCapacity()
    {
        await using var database = await TestDatabase.CreateAsync();
        var service = new ProductionService(database.Context);
        await database.SeedPackableProductAsync(
            "Reserved Raw Product",
            rawQuantity: 100m);
        var balance = await database.Context.RawStockBalances.SingleAsync();
        balance.ReservedQuantity = 12.5m;
        await database.Context.SaveChangesAsync();

        var result = Assert.Single(await service.PackableProductsAsync(
            database.Section.SectionId,
            default));

        Assert.Equal(87.5m, result.MaximumPackableQuantity);
        Assert.Equal(87.5m, Assert.Single(result.Requirements).AvailableQuantity);
    }

    [Fact]
    public async Task MakeProduct_ExistingActiveSku_ReusesProductAndIncreasesStock()
    {
        await using var database = await TestDatabase.CreateAsync();
        var service = new ProductionService(database.Context);
        var product = await database.SeedPackableProductAsync(
            "Reusable",
            rawQuantity: 100m);
        await service.MakeProductAsync(
            database.Request(product, 5m),
            database.Manager.UserId,
            default);

        var result = await service.MakeProductAsync(
            database.Request(product, 7m),
            database.Manager.UserId,
            default);

        Assert.False(result.ProductCreated);
        Assert.Equal(1, await database.Context.Products.CountAsync());
        Assert.Equal(2, await database.Context.ProductBatches.CountAsync());
        Assert.Equal(12m, (await database.Context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.Equal(2, await database.Context.StockMovements.CountAsync(m => m.MovementType == StockMovementTypes.Increase));
    }

    [Fact]
    public async Task MakeProduct_RemovesExpiredBatchBeforeApplyingNewIncrease()
    {
        await using var database = await TestDatabase.CreateAsync();
        var service = new ProductionService(database.Context);
        var product = await database.SeedPackableProductAsync(
            "Expiry Reuse",
            shelfLifeDays: 10,
            rawQuantity: 100m);
        var oldRequest = database.Request(product, 8m);
        oldRequest.PackedAtUtc = DateTime.UtcNow.AddDays(-20);
        await service.MakeProductAsync(
            oldRequest,
            database.Manager.UserId,
            default);

        var result = await service.MakeProductAsync(
            database.Request(product, 3m),
            database.Manager.UserId,
            default);

        Assert.Equal(3m, result.AggregateQuantityAvailableKg);
        var oldBatch = await database.Context.ProductBatches.OrderBy(b => b.ProductBatchId).FirstAsync();
        Assert.Equal(ProductBatchStatuses.ExpiredPendingDecision, oldBatch.Status);
        Assert.NotNull(oldBatch.AvailableQuantityRemovedAtUtc);
        Assert.Contains(await database.Context.StockMovements.ToListAsync(), m => m.MovementType == StockMovementTypes.Decrease);
    }

    [Fact]
    public async Task MakeProduct_InactiveLookup_IsRejectedWithoutPartialWrites()
    {
        await using var database = await TestDatabase.CreateAsync();
        var product = await database.SeedPackableProductAsync("Rejected");
        product.Status = ProductStatuses.Inactive;
        await database.Context.SaveChangesAsync();
        var service = new ProductionService(database.Context);

        var exception = await Assert.ThrowsAsync<Subsystem7Exception>(() =>
            service.MakeProductAsync(
                database.Request(product),
                database.Manager.UserId,
                default));

        Assert.Equal(409, exception.StatusCode);
        Assert.Empty(await database.Context.ProductBatches.ToListAsync());
        Assert.Equal(
            100m,
            (await database.Context.RawStockBalances.SingleAsync()).QuantityOnHand);
    }

    [Theory]
    [InlineData(60, ExpiryAlertLevels.Warning)]
    [InlineData(20, ExpiryAlertLevels.Urgent)]
    [InlineData(-1, ExpiryAlertLevels.Expired)]
    [InlineData(100, ExpiryAlertLevels.Normal)]
    public async Task ExpiryThresholds_AreClassifiedCorrectly(int hours, string expected)
    {
        await using var database = await TestDatabase.CreateAsync();
        var service = database.CreateExpiryService(new FakeEmailService());
        Assert.Equal(expected, service.GetAlertLevel(DateTime.UtcNow.AddHours(hours), DateTime.UtcNow));
    }

    [Fact]
    public async Task ExpiryScan_SendsEachWarningStageOnlyOnce()
    {
        await using var database = await TestDatabase.CreateAsync();
        await database.SeedBatchAsync(DateTime.UtcNow.AddHours(60), 6m);
        var email = new FakeEmailService();
        var service = database.CreateExpiryService(email);

        var first = await service.RunScanAsync(default);
        var second = await service.RunScanAsync(default);

        Assert.Equal(1, first.WarningEmailsSent);
        Assert.Equal(0, second.WarningEmailsSent);
        Assert.Single(email.AlertLinks);
    }

    [Fact]
    public async Task ExpiryScan_RemovesExpiredQuantityExactlyOnce()
    {
        await using var database = await TestDatabase.CreateAsync();
        await database.SeedBatchAsync(DateTime.UtcNow.AddHours(-1), 9m);
        var email = new FakeEmailService();
        var service = database.CreateExpiryService(email);

        await service.RunScanAsync(default);
        await service.RunScanAsync(default);

        Assert.Equal(0m, (await database.Context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.Single(await database.Context.StockMovements.Where(m => m.MovementType == StockMovementTypes.Decrease).ToListAsync());
        Assert.Single(email.AlertLinks);
    }

    [Fact]
    public async Task ExpiryAction_UsesSelectedDateAndTokenCannotBeReused()
    {
        await using var database = await TestDatabase.CreateAsync();
        var batch = await database.SeedBatchAsync(DateTime.UtcNow.AddHours(20), 4m);
        var email = new FakeEmailService();
        var service = database.CreateExpiryService(email);
        await service.RunScanAsync(default);
        var token = email.LastToken();
        var requestedExpiry = DateTime.UtcNow.AddDays(1);

        await service.ExtendShelfLifeAsync(
            token,
            "Quality inspection passed",
            requestedExpiry,
            database.Manager.UserId,
            default);
        await database.Context.Entry(batch).ReloadAsync();

        Assert.Equal(requestedExpiry, batch.EffectiveExpiryAtUtc);
        Assert.True(batch.ShelfLifeExtended);
        await Assert.ThrowsAsync<Subsystem7Exception>(() =>
            service.ExtendShelfLifeAsync(
                token,
                "Trying token again",
                DateTime.UtcNow.AddDays(1),
                database.Manager.UserId,
                default));
    }

    [Fact]
    public async Task ExpiryAction_WriteOffZerosBatchAndCannotDoubleDecrementStock()
    {
        await using var database = await TestDatabase.CreateAsync();
        var batch = await database.SeedBatchAsync(DateTime.UtcNow.AddHours(10), 11m);
        var email = new FakeEmailService();
        var service = database.CreateExpiryService(email);
        await service.RunScanAsync(default);
        var token = email.LastToken();

        await service.WriteOffAsync(token, "Manager approved disposal", database.Manager.UserId, default);
        await database.Context.Entry(batch).ReloadAsync();

        Assert.Equal(0m, batch.QuantityRemainingKg);
        Assert.Equal(ProductBatchStatuses.WrittenOff, batch.Status);
        Assert.Equal(0m, (await database.Context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.Single(await database.Context.StockMovements.Where(m => m.MovementType == StockMovementTypes.WriteOff).ToListAsync());
        await Assert.ThrowsAsync<Subsystem7Exception>(() =>
            service.WriteOffAsync(token, "Trying token again", database.Manager.UserId, default));
    }

    [Fact]
    public async Task ExpiryAction_GetReviewDoesNotMutateTokenOrBatch()
    {
        await using var database = await TestDatabase.CreateAsync();
        var batch = await database.SeedBatchAsync(DateTime.UtcNow.AddHours(20), 3m);
        var email = new FakeEmailService();
        var service = database.CreateExpiryService(email);
        await service.RunScanAsync(default);
        var token = email.LastToken();

        var review = await service.GetActionReviewAsync(token, default);
        var storedToken = await database.Context.ExpiryActionTokens.SingleAsync();

        Assert.Equal(batch.ProductBatchId, review.ProductBatchId);
        Assert.Null(storedToken.UsedAtUtc);
        Assert.Null(storedToken.InvalidatedAtUtc);
        Assert.Equal(3m, batch.QuantityRemainingKg);
    }

    [Fact]
    public async Task ExpiredOrUnknownActionToken_IsRejected()
    {
        await using var database = await TestDatabase.CreateAsync();
        var service = database.CreateExpiryService(new FakeEmailService());
        var exception = await Assert.ThrowsAsync<Subsystem7Exception>(() => service.GetActionReviewAsync("not-a-token", default));
        Assert.Equal(400, exception.StatusCode);
    }

    [Fact]
    public async Task ExpiredDecisionLinkStillResolvesPendingExpiredStock()
    {
        await using var database = await TestDatabase.CreateAsync();
        var batch = await database.SeedBatchAsync(
            DateTime.UtcNow.AddDays(-30),
            5m);
        var email = new FakeEmailService();
        var service = database.CreateExpiryService(email);
        await service.RunScanAsync(default);
        var token = email.LastToken();
        var storedToken = await database.Context.ExpiryActionTokens.SingleAsync();
        storedToken.ExpiresAtUtc = DateTime.UtcNow.AddDays(-20);
        await database.Context.SaveChangesAsync();

        await service.WriteOffAsync(
            token,
            "Manager confirmed disposal after delayed inspection.",
            database.Manager.UserId,
            default);
        await database.Context.Entry(batch).ReloadAsync();

        Assert.Equal(ProductBatchStatuses.WrittenOff, batch.Status);
        Assert.Equal(0m, batch.QuantityRemainingKg);
    }

    [Fact]
    public void ExpiryDecisionDto_RequiresConfirmationAndReason()
    {
        var dto = new ExpiryDecisionDto { Reason = "no", Confirmed = false };
        var results = new List<ValidationResult>();
        Assert.False(Validator.TryValidateObject(dto, new ValidationContext(dto), results, true));
        Assert.Contains(results, result => result.ErrorMessage?.Contains("Confirmation") == true);
    }

    [Fact]
    public async Task ProductHardDelete_WithInventoryHistory_ReturnsConflictAndCanDeactivate()
    {
        await using var database = await TestDatabase.CreateAsync();
        var production = new ProductionService(database.Context);
        var product = await database.SeedPackableProductAsync("Protected Product");
        var made = await production.MakeProductAsync(
            database.Request(product),
            database.Manager.UserId,
            default);
        var controller = new ProductController(
            database.Context,
            production,
            Microsoft.Extensions.Options.Options.Create(new ExpiryAlertOptions()));

        var deleteResult = await controller.DeleteProduct(made.ProductId, default);

        Assert.IsType<ConflictObjectResult>(deleteResult);
        Assert.NotNull(await database.Context.Products.FindAsync(made.ProductId));
        var statusResult = await controller.ChangeStatus(
            made.ProductId,
            new UpdateProductStatusDto { Status = ProductStatuses.Inactive },
            default);
        Assert.IsType<OkObjectResult>(statusResult);
        Assert.Equal(ProductStatuses.Inactive, (await database.Context.Products.FindAsync(made.ProductId))!.Status);
    }

    [Fact]
    public async Task ProductTypeAndCategoryDelete_WhenLinked_ReturnConflict()
    {
        await using var database = await TestDatabase.CreateAsync();
        await database.SeedPackableProductAsync("Linked Product");
        var typeController = new ProductTypeController(database.Context);
        var categoryController = new ProductCategoryController(database.Context);

        Assert.IsType<ConflictObjectResult>(await typeController.Delete(database.Type.ProductTypeId, default));
        Assert.IsType<ConflictObjectResult>(await categoryController.Delete(database.Category.ProductCategoryId, default));
    }

    [Fact]
    public async Task ProductTypeAndCategoryNames_AreCaseInsensitivelyUnique()
    {
        await using var database = await TestDatabase.CreateAsync();
        var typeController = new ProductTypeController(database.Context);
        var categoryController = new ProductCategoryController(database.Context);

        var duplicateType = await typeController.Create(
            new SaveProductTypeDto { ProductTypeName = "fresh produce", Status = ProductStatuses.Active }, default);
        var duplicateCategory = await categoryController.Create(
            new SaveProductCategoryDto { ProductCategoryName = "FRUIT", Status = ProductStatuses.Active }, default);

        Assert.IsType<ConflictObjectResult>(duplicateType);
        Assert.IsType<ConflictObjectResult>(duplicateCategory);
    }

    [Fact]
    public void RestrictedEndpoints_DeclarePermissionAuthorization()
    {
        var deletePolicy = typeof(ProductController)
            .GetMethod(nameof(ProductController.DeleteProduct))!
            .GetCustomAttribute<AuthorizeAttribute>()!.Policy;
        var expiryPolicy = typeof(ExpiryAlertsController)
            .GetMethod(nameof(ExpiryAlertsController.WriteOff))!
            .GetCustomAttribute<AuthorizeAttribute>()!.Policy;

        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.Products.Delete,
            deletePolicy);
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.Expiry.Resolve,
            expiryPolicy);
        Assert.DoesNotContain(
            Permissions.Products.Delete,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.Contains(
            Permissions.Expiry.Resolve,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
    }

    [Fact]
    public async Task ExpiredBatch_ExtensionRestoresSameBatchWithoutReceipt()
    {
        await using var database = await TestDatabase.CreateAsync();
        var batch = await database.SeedBatchAsync(
            DateTime.UtcNow.AddHours(-1),
            9m);
        var email = new FakeEmailService();
        var service = database.CreateExpiryService(email);

        await service.RunScanAsync(default);
        var token = email.LastToken();
        var requestedExpiry = DateTime.UtcNow.AddDays(1);
        await service.ExtendShelfLifeAsync(
            token,
            "Inspection confirmed the batch remains usable.",
            requestedExpiry,
            database.Manager.UserId,
            default);
        await database.Context.Entry(batch).ReloadAsync();

        Assert.Equal(ProductBatchStatuses.Available, batch.Status);
        Assert.Equal(requestedExpiry, batch.EffectiveExpiryAtUtc);
        Assert.Null(batch.AvailableQuantityRemovedAtUtc);
        Assert.Equal(
            9m,
            (await database.Context.Stocks.SingleAsync())
                .QuantityAvailableKg);
        Assert.Empty(await database.Context.RawStockReceipts.ToListAsync());
        Assert.Contains(
            await database.Context.StockMovements.ToListAsync(),
            movement => movement.MovementType ==
                StockMovementTypes.Adjustment);
    }
}

internal sealed class TestDatabase : IAsyncDisposable
{
    private readonly SqliteConnection _connection;
    public PhenyoSyncDbContext Context { get; }
    public ProductType Type { get; private set; } = null!;
    public ProductCategory Category { get; private set; } = null!;
    public WarehouseSection Section { get; private set; } = null!;
    public User Manager { get; private set; } = null!;

    private TestDatabase(SqliteConnection connection, PhenyoSyncDbContext context)
    {
        _connection = connection;
        Context = context;
    }

    public static async Task<TestDatabase> CreateAsync()
    {
        var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>().UseSqlite(connection).Options;
        var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var database = new TestDatabase(connection, context);
        await database.SeedLookupsAsync();
        return database;
    }

    public CreateProductDto Request(Product product, decimal quantity = 2m) => new()
    {
        ProductId = product.ProductId,
        QuantityProducedKg = quantity,
        SectionId = Section.SectionId,
        PackedAtUtc = DateTime.UtcNow
    };

    public async Task<Product> SeedPackableProductAsync(
        string name,
        int shelfLifeDays = 10,
        decimal rawQuantity = 100m)
    {
        var product = new Product
        {
            ProductName = name,
            ProductTypeId = Type.ProductTypeId,
            ProductCategoryId = Category.ProductCategoryId,
            Size = "1 KG",
            ShelfLifeDays = shelfLifeDays,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var rawItem = new RawStockItem
        {
            ItemCode = $"RAW-{Guid.NewGuid():N}"[..20].ToUpperInvariant(),
            ItemName = $"Raw {name} {Guid.NewGuid():N}",
            CategoryCode = RawStockCategories.Produce,
            DefaultUnitOfMeasure = RawStockUnits.Kilogram,
            IsProduce = true,
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        Context.AddRange(product, rawItem);
        await Context.SaveChangesAsync();
        product.QRCodeValue = $"PRODUCT-{product.ProductId:D6}";

        var balance = new RawStockBalance
        {
            RawStockItemId = rawItem.RawStockItemId,
            WarehouseSectionId = Section.SectionId,
            UnitOfMeasure = RawStockUnits.Kilogram,
            QuantityOnHand = rawQuantity,
            ReservedQuantity = 0m
        };
        Context.RawStockBalances.Add(balance);
        Context.ProductRawStockRequirements.Add(new ProductRawStockRequirement
        {
            ProductId = product.ProductId,
            RawStockItemId = rawItem.RawStockItemId,
            RawQuantityPerProductUnit = 1m,
            UnitOfMeasure = RawStockUnits.Kilogram,
            WastePercentage = 0m,
            YieldPercentage = 100m,
            IsActive = true,
            CreatedByUserId = Manager.UserId,
            CreatedAtUtc = DateTime.UtcNow
        });
        await Context.SaveChangesAsync();
        Context.RawStockBatches.Add(new RawStockBatch
        {
            RawStockItemId = rawItem.RawStockItemId,
            RawStockBalanceId = balance.RawStockBalanceId,
            BatchCode = $"RAW-BATCH-{Guid.NewGuid():N}"[..35].ToUpperInvariant(),
            QrCodeValue = $"PHENYOSYNC:RAW:{Guid.NewGuid():N}",
            QuantityReceived = rawQuantity,
            QuantityRemaining = rawQuantity,
            ReceivedAtUtc = DateTime.UtcNow.AddDays(-1),
            BestBeforeAtUtc = DateTime.UtcNow.AddDays(30),
            Status = ProductBatchStatuses.Available
        });
        await Context.SaveChangesAsync();
        return product;
    }

    public ExpiryService CreateExpiryService(FakeEmailService email)
    {
        var options = Microsoft.Extensions.Options.Options.Create(new ExpiryAlertOptions
        {
            YellowThresholdHours = 72,
            RedThresholdHours = 24,
            ActionTokenLifetimeHours = 48,
            RecipientRoles = ["BusinessManager"]
        });
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?> { ["FrontendUrl"] = "http://localhost:4200" })
            .Build();
        return new ExpiryService(Context, email, options, configuration);
    }

    public async Task<ProductBatch> SeedBatchAsync(DateTime expiry, decimal quantity)
    {
        var product = new Product
        {
            ProductName = $"Batch Product {Guid.NewGuid():N}", ProductTypeId = Type.ProductTypeId,
            ProductCategoryId = Category.ProductCategoryId, Size = "1 KG", ShelfLifeDays = 5,
            Status = ProductStatuses.Active, CreatedAt = DateTime.UtcNow
        };
        Context.Products.Add(product);
        await Context.SaveChangesAsync();
        product.QRCodeValue = $"PRODUCT-{product.ProductId:D6}";
        var batch = new ProductBatch
        {
            ProductId = product.ProductId, SectionId = Section.SectionId,
            BatchCode = $"BATCH-{Guid.NewGuid():N}", QRCodeValue = $"PHENYOSYNC:BATCH:{Guid.NewGuid():N}",
            QuantityProducedKg = quantity, QuantityRemainingKg = quantity,
            PackedAtUtc = expiry.AddDays(-5), OriginalExpiryAtUtc = expiry, EffectiveExpiryAtUtc = expiry,
            Status = ProductBatchStatuses.Available, CreatedAtUtc = DateTime.UtcNow
        };
        Context.ProductBatches.Add(batch);
        Context.Stocks.Add(new Stock
        {
            ProductId = product.ProductId, SectionId = Section.SectionId,
            QuantityAvailableKg = quantity, ReorderLevelKg = 0, InventoryStatus = ProductBatchStatuses.Available
        });
        await Context.SaveChangesAsync();
        return batch;
    }

    private async Task SeedLookupsAsync()
    {
        Type = new ProductType { ProductTypeName = "Fresh Produce", Status = ProductStatuses.Active, CreatedAt = DateTime.UtcNow };
        Category = new ProductCategory { ProductCategoryName = "Fruit", Status = ProductStatuses.Active, CreatedAt = DateTime.UtcNow };
        Section = new WarehouseSection { SectionName = "Production", Status = ProductStatuses.Active };
        var role = new Role { RoleName = "BusinessManager", Users = [], RolePermissions = [] };
        Manager = new User
        {
            Email = "manager@example.test", PasswordHash = "test", FirstName = "Test", LastName = "Manager",
            Status = ProductStatuses.Active, Role = role, StockTakeSessions = []
        };
        Context.AddRange(Type, Category, Section, Manager);
        await Context.SaveChangesAsync();
    }

    public async ValueTask DisposeAsync()
    {
        await Context.DisposeAsync();
        await _connection.DisposeAsync();
    }
}

internal sealed class FakeEmailService : IEmailService
{
    public List<string> AlertLinks { get; } = [];
    public List<string> Decisions { get; } = [];
    public Task SendPasswordResetEmailAsync(string recipientEmail, string resetLink) => Task.CompletedTask;
    public Task SendCustomerOrderLinkEmailAsync(string recipientEmail, string customerName, string orderLink, DateTime expiresAtUtc, CancellationToken cancellationToken = default) => Task.CompletedTask;
    public Task SendExpiryAlertEmailAsync(IReadOnlyCollection<string> recipientEmails, ExpiryEmailModel model, string reviewLink, CancellationToken cancellationToken = default)
    {
        AlertLinks.Add(reviewLink);
        return Task.CompletedTask;
    }
    public Task SendExpiryDecisionConfirmationAsync(IReadOnlyCollection<string> recipientEmails, ExpiryEmailModel model, string decision, CancellationToken cancellationToken = default)
    {
        Decisions.Add(decision);
        return Task.CompletedTask;
    }
    public string LastToken()
    {
        var query = new Uri(AlertLinks.Last()).Query.TrimStart('?');
        var tokenPair = query.Split('&').Single(part => part.StartsWith("token="));
        return Uri.UnescapeDataString(tokenPair["token=".Length..]);
    }
}
