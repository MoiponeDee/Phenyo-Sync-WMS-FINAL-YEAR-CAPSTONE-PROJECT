using System.Reflection;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Audit;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Proves audit immutability, sanitization, actor context and permission-filtered retrieval.
public sealed class Subsystem14AuditLogTests
{
    [Fact]
    public async Task CreateUpdateAndDelete_AreCapturedWithActorAndChangedValues()
    {
        await using var db = await AuditTestDatabase.CreateAsync();
        var permission = new Permission
        {
            PermissionName = "Audit test permission",
            RolePermissions = []
        };

        db.Context.Permissions.Add(permission);
        await db.Context.SaveChangesAsync();

        var created = await db.Context.AuditLogs
            .AsNoTracking()
            .SingleAsync(item =>
                item.EntityType == nameof(Permission) &&
                item.ActionType == AuditActionTypes.Create);

        Assert.Equal(permission.PermissionId.ToString(), EntityKey(created.EntityId));
        Assert.Equal(71, created.UserId);
        Assert.Equal("audit.manager@example.test", created.UserEmailSnapshot);
        Assert.Equal("Audit Manager", created.UserDisplayNameSnapshot);
        Assert.Equal("BusinessManager", created.UserRoleSnapshot);
        Assert.Equal(AuditModules.Permissions, created.SystemModule);
        Assert.Equal(AuditEventSources.EntityChange, created.EventSource);
        Assert.Equal("audit-test-correlation", created.CorrelationId);
        Assert.Contains("Audit test permission", created.AfterValuesJson);
        Assert.Null(created.BeforeValuesJson);

        permission.PermissionName = "Renamed audit permission";
        await db.Context.SaveChangesAsync();

        var updated = await db.Context.AuditLogs
            .AsNoTracking()
            .SingleAsync(item =>
                item.EntityType == nameof(Permission) &&
                item.ActionType == AuditActionTypes.Update);

        Assert.Equal(
            ["PermissionName"],
            JsonSerializer.Deserialize<string[]>(updated.ChangedFieldsJson!)!);
        Assert.Contains("Audit test permission", updated.BeforeValuesJson);
        Assert.Contains("Renamed audit permission", updated.AfterValuesJson);
        Assert.DoesNotContain("PermissionId", updated.AfterValuesJson);

        db.Context.Permissions.Remove(permission);
        await db.Context.SaveChangesAsync();

        var deleted = await db.Context.AuditLogs
            .AsNoTracking()
            .SingleAsync(item =>
                item.EntityType == nameof(Permission) &&
                item.ActionType == AuditActionTypes.Delete);

        Assert.Contains("Renamed audit permission", deleted.BeforeValuesJson);
        Assert.Null(deleted.AfterValuesJson);
    }

    [Fact]
    public async Task SensitiveUserFields_AreRedactedAndNeverStoredInPlainText()
    {
        await using var db = await AuditTestDatabase.CreateAsync();
        const string passwordHash = "super-secret-password-hash";
        const string resetTokenHash = "super-secret-reset-token";
        var role = new Role
        {
            RoleName = "Packer",
            Users = [],
            RolePermissions = []
        };
        var user = new User
        {
            Email = "sensitive.user@example.test",
            PasswordHash = passwordHash,
            FirstName = "Sensitive",
            LastName = "User",
            Role = role,
            Status = "Active",
            PasswordResetTokenHash = resetTokenHash,
            Driver = null!,
            StockTakeSessions = []
        };

        db.Context.Users.Add(user);
        await db.Context.SaveChangesAsync();

        var audit = await db.Context.AuditLogs
            .AsNoTracking()
            .SingleAsync(item =>
                item.EntityType == nameof(User) &&
                item.EntityId!.Contains($"UserId={user.UserId}"));

        Assert.Contains("[REDACTED]", audit.AfterValuesJson);
        Assert.DoesNotContain(passwordHash, audit.AfterValuesJson);
        Assert.DoesNotContain(resetTokenHash, audit.AfterValuesJson);
        Assert.Equal("se***@example.test", audit.EntityDisplay);
    }

    [Fact]
    public async Task AuditLogMutations_AreRejectedAndDoNotCreateRecursiveAuditRows()
    {
        await using var db = await AuditTestDatabase.CreateAsync();
        var explicitLog = AuditTestDatabase.NewLog(
            "manual-correlation",
            AuditActionTypes.LoginSuccess,
            AuditModules.Authentication,
            DateTime.UtcNow);
        db.Context.AuditLogs.Add(explicitLog);
        await db.Context.SaveChangesAsync();

        Assert.Equal(1, await db.Context.AuditLogs.CountAsync());

        explicitLog.Description = "Attempted modification";
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => db.Context.SaveChangesAsync());
        db.Context.Entry(explicitLog).State = EntityState.Unchanged;

        db.Context.AuditLogs.Remove(explicitLog);
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => db.Context.SaveChangesAsync());
    }

    [Fact]
    public async Task ExternalTransactionRollback_RollsBackBusinessAndAuditRowsTogether()
    {
        await using var db = await AuditTestDatabase.CreateAsync();
        await using var transaction = await db.Context.Database.BeginTransactionAsync();
        db.Context.Permissions.Add(new Permission
        {
            PermissionName = "Rollback permission",
            RolePermissions = []
        });
        await db.Context.SaveChangesAsync();

        Assert.Equal(1, await db.Context.Permissions.CountAsync());
        Assert.Equal(1, await db.Context.AuditLogs.CountAsync());

        await transaction.RollbackAsync();
        db.Context.ChangeTracker.Clear();

        Assert.Equal(0, await db.Context.Permissions.CountAsync());
        Assert.Equal(0, await db.Context.AuditLogs.CountAsync());
    }

    [Fact]
    public async Task ProductOrderAndPriceChanges_AreMappedToTheirSubsystemModules()
    {
        await using var db = await AuditTestDatabase.CreateAsync();
        var productType = new ProductType
        {
            ProductTypeName = "Audit produce",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var category = new ProductCategory
        {
            ProductCategoryName = "Audit fruit",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var product = new Product
        {
            ProductName = "Audit apples",
            ProductType = productType,
            ProductCategory = category,
            Size = "1 KG",
            ShelfLifeDays = 7,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var customer = new Customer
        {
            CustomerNumber = "AUD-0001",
            CustomerName = "Audit Customer",
            Email = "audit.customer@example.test",
            DeliveryAddress = "14 Audit Avenue",
            BillingAddress = "14 Audit Avenue",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var order = new SalesOrder
        {
            OrderNumber = "AUDIT-ORDER-0001",
            Customer = customer,
            OrderDateUtc = DateTime.UtcNow,
            DeliveryAddressSnapshot = "14 Audit Avenue",
            BillingAddressSnapshot = "14 Audit Avenue",
            Status = SalesOrderStatuses.Submitted,
            ValidationStatus = OrderValidationStatuses.Pending,
            CreatedAtUtc = DateTime.UtcNow
        };
        var price = new ProductPrice
        {
            Product = product,
            SellingPrice = 25m,
            EffectiveFromUtc = DateTime.UtcNow,
            IsCurrent = true,
            CreatedAtUtc = DateTime.UtcNow
        };

        db.Context.AddRange(order, price);
        await db.Context.SaveChangesAsync();

        var audits = await db.Context.AuditLogs.AsNoTracking().ToListAsync();
        Assert.Contains(audits, item =>
            item.EntityType == nameof(Product) &&
            item.SystemModule == AuditModules.ProductManagement);
        Assert.Contains(audits, item =>
            item.EntityType == nameof(SalesOrder) &&
            item.SystemModule == AuditModules.OrderManagement);
        Assert.Contains(audits, item =>
            item.EntityType == nameof(ProductPrice) &&
            item.SystemModule == AuditModules.Pricing);
    }

    [Fact]
    public async Task StatusAndSoftDeleteChanges_UseBusinessActionNames()
    {
        await using var db = await AuditTestDatabase.CreateAsync();
        var productType = new ProductType
        {
            ProductTypeName = "Deactivate type",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var category = new ProductCategory
        {
            ProductCategoryName = "Deactivate category",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var product = new Product
        {
            ProductName = "Deactivate product",
            ProductType = productType,
            ProductCategory = category,
            Size = "1 KG",
            ShelfLifeDays = 5,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var price = new ProductPrice
        {
            Product = product,
            SellingPrice = 12m,
            EffectiveFromUtc = DateTime.UtcNow,
            IsCurrent = false,
            CreatedAtUtc = DateTime.UtcNow
        };
        db.Context.ProductPrices.Add(price);
        await db.Context.SaveChangesAsync();
        product.Status = ProductStatuses.Inactive;
        price.IsDeleted = true;
        price.DeletedAtUtc = DateTime.UtcNow;
        await db.Context.SaveChangesAsync();

        var changes = await db.Context.AuditLogs
            .AsNoTracking()
            .Where(item =>
                item.ActionType == AuditActionTypes.Deactivate ||
                item.ActionType == AuditActionTypes.SoftDelete)
            .ToListAsync();
        Assert.Contains(changes, item =>
            item.EntityType == nameof(Product) &&
            item.ActionType == AuditActionTypes.Deactivate);
        Assert.Contains(changes, item =>
            item.EntityType == nameof(ProductPrice) &&
            item.ActionType == AuditActionTypes.SoftDelete);
    }

    [Fact]
    public async Task QueryService_FiltersPaginatesOrdersNewestFirstAndReturnsDetails()
    {
        await using var db = await AuditTestDatabase.CreateAsync();
        var now = DateTime.UtcNow;
        db.Context.AuditLogs.AddRange(
            AuditTestDatabase.NewLog(
                "corr-a", AuditActionTypes.Create, AuditModules.Pricing, now.AddMinutes(-3)),
            AuditTestDatabase.NewLog(
                "corr-b", AuditActionTypes.Update, AuditModules.Pricing, now.AddMinutes(-2)),
            AuditTestDatabase.NewLog(
                "corr-b", AuditActionTypes.Update, AuditModules.Pricing, now.AddMinutes(-1)),
            AuditTestDatabase.NewLog(
                "corr-c", AuditActionTypes.Delete, AuditModules.ProductManagement, now));
        await db.Context.SaveChangesAsync();
        var query = new AuditLogQueryService(db.Context);

        var page = await query.SearchAsync(
            new AuditLogSearchDto
            {
                SystemModule = AuditModules.Pricing,
                ActionType = AuditActionTypes.Update,
                PageNumber = 1,
                PageSize = 1
            },
            default);

        Assert.Equal(2, page.TotalCount);
        Assert.Equal(2, page.TotalPages);
        Assert.True(page.HasNextPage);
        Assert.Single(page.Items);
        Assert.Equal(now.AddMinutes(-1), page.Items[0].OccurredAtUtc);

        var detail = await query.GetAsync(page.Items[0].AuditLogId, default);
        Assert.Single(detail.RelatedLogs);
        Assert.Equal("corr-b", detail.RelatedLogs[0].CorrelationId);
    }

    [Fact]
    public async Task QueryService_ValidatesDatesAndPagingAndSupportsEmptyResults()
    {
        await using var db = await AuditTestDatabase.CreateAsync();
        var query = new AuditLogQueryService(db.Context);

        await Assert.ThrowsAsync<AuditQueryException>(() =>
            query.SearchAsync(
                new AuditLogSearchDto { PageNumber = 0 },
                default));
        await Assert.ThrowsAsync<AuditQueryException>(() =>
            query.SearchAsync(
                new AuditLogSearchDto { PageSize = 101 },
                default));
        await Assert.ThrowsAsync<AuditQueryException>(() =>
            query.SearchAsync(
                new AuditLogSearchDto
                {
                    DateFromUtc = DateTime.UtcNow,
                    DateToUtc = DateTime.UtcNow.AddDays(-1)
                },
                default));

        var empty = await query.SearchAsync(
            new AuditLogSearchDto { SearchTerm = "does-not-exist" },
            default);
        Assert.Empty(empty.Items);
        Assert.Equal(0, empty.TotalCount);
        Assert.Equal(0, empty.TotalPages);
    }

    [Fact]
    public void AuditEndpoints_AreReadOnlyAndPermissionRestricted()
    {
        var authorize = typeof(AuditLogsController)
            .GetCustomAttribute<AuthorizeAttribute>();
        Assert.NotNull(authorize);
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.AuditLogs.View,
            authorize!.Policy);
        Assert.Contains(
            Permissions.AuditLogs.View,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.Contains(
            Permissions.AuditLogs.View,
            SecurityRoleMatrix.Assignments[RoleCodes.OperationsManager]);
        Assert.DoesNotContain(
            Permissions.AuditLogs.View,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);

        var publicMethods = typeof(AuditLogsController)
            .GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly);
        Assert.All(publicMethods, method =>
        {
            Assert.NotNull(method.GetCustomAttribute<HttpGetAttribute>());
            Assert.Null(method.GetCustomAttribute<HttpPostAttribute>());
            Assert.Null(method.GetCustomAttribute<HttpPutAttribute>());
            Assert.Null(method.GetCustomAttribute<HttpPatchAttribute>());
            Assert.Null(method.GetCustomAttribute<HttpDeleteAttribute>());
        });
    }

    [Fact]
    public async Task ExplicitSystemEvent_PreservesSourceAndSanitizesSensitiveDetails()
    {
        await using var db = await AuditTestDatabase.CreateAsync();
        var service = new AuditService(db.Context, db.Actor);
        const string secret = "secret-token-value";

        await service.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.BackgroundJob,
            SystemModule = AuditModules.ExpiryManagement,
            OperationName = "AuditTestBackgroundJob",
            Description = "A test background action completed.",
            ActorType = AuditActorTypes.BackgroundService,
            EventSource = AuditEventSources.BackgroundService,
            SafeDetails = new Dictionary<string, object?>
            {
                ["ResetToken"] = secret,
                ["ProcessedCount"] = 3
            }
        });

        var audit = await db.Context.AuditLogs.AsNoTracking().SingleAsync();
        Assert.Equal(AuditActorTypes.BackgroundService, audit.ActorType);
        Assert.Equal(AuditEventSources.BackgroundService, audit.EventSource);
        Assert.Contains("[REDACTED]", audit.AfterValuesJson);
        Assert.DoesNotContain(secret, audit.AfterValuesJson);
        Assert.Contains("3", audit.AfterValuesJson);
    }

    private static string EntityKey(string? entityId) =>
        entityId?.Split('=').Last() ?? string.Empty;
}

internal sealed class AuditTestDatabase : IAsyncDisposable
{
    private readonly SqliteConnection _connection;

    private AuditTestDatabase(
        SqliteConnection connection,
        PhenyoSyncDbContext context,
        StaticAuditContextAccessor actor)
    {
        _connection = connection;
        Context = context;
        Actor = actor;
    }

    public PhenyoSyncDbContext Context { get; }
    public StaticAuditContextAccessor Actor { get; }

    public static async Task<AuditTestDatabase> CreateAsync()
    {
        var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var actor = new StaticAuditContextAccessor(new AuditActorContext(
            71,
            "audit.manager@example.test",
            "Audit Manager",
            "BusinessManager",
            AuditActorTypes.User,
            "audit-test-correlation",
            "/api/audit-test",
            "POST",
            "127.0.0.1",
            "Subsystem14 tests"));
        var context = new PhenyoSyncDbContext(
            new DbContextOptionsBuilder<PhenyoSyncDbContext>()
                .UseSqlite(connection)
                .Options,
            actor);
        await context.Database.EnsureCreatedAsync();
        return new AuditTestDatabase(connection, context, actor);
    }

    public static AuditLog NewLog(
        string correlationId,
        string actionType,
        string module,
        DateTime occurredAtUtc) =>
        new()
        {
            OccurredAtUtc = occurredAtUtc,
            UserId = 71,
            UserEmailSnapshot = "audit.manager@example.test",
            UserDisplayNameSnapshot = "Audit Manager",
            UserRoleSnapshot = "BusinessManager",
            ActorType = AuditActorTypes.User,
            ActionType = actionType,
            SystemModule = module,
            OperationName = $"{actionType}Test",
            EntityType = "TestEntity",
            EntityId = Guid.NewGuid().ToString("N"),
            Description = $"{actionType} test record",
            Success = true,
            CorrelationId = correlationId,
            EventSource = AuditEventSources.SecurityEvent
        };

    public async ValueTask DisposeAsync()
    {
        await Context.DisposeAsync();
        await _connection.DisposeAsync();
    }
}

internal sealed class StaticAuditContextAccessor : IAuditContextAccessor
{
    public StaticAuditContextAccessor(AuditActorContext current)
    {
        Current = current;
    }

    public AuditActorContext Current { get; }
}
