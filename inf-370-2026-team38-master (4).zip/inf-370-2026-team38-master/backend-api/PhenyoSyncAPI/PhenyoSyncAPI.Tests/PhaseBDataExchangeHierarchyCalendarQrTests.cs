using ClosedXML.Excel;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Protects validate-then-import, hierarchy integrity, calendar projection and real QR resolution.
public sealed class PhaseBDataExchangeHierarchyCalendarQrTests
{
    [Fact]
    public void CatalogContainsAllPhaseBPermissionsExactlyOnce()
    {
        var codes = Permissions.Catalog.Select(item => item.Code).ToArray();
        var required = new[]
        {
            Permissions.ProductHierarchy.View,
            Permissions.ProductHierarchy.Manage,
            Permissions.ProductDataExchange.Export,
            Permissions.ProductDataExchange.Import,
            Permissions.StockCountExchange.Export,
            Permissions.StockCountExchange.Import,
            Permissions.OperationsCalendar.View,
            Permissions.ProductBatchScanner.View
        };

        foreach (var permission in required)
            Assert.Single(codes, code => code == permission);
    }

    [Fact]
    public void RoleMatrixKeepsOperationalAccessNarrow()
    {
        Assert.DoesNotContain(
            Permissions.ProductDataExchange.Import,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
        Assert.Contains(
            Permissions.ProductDataExchange.Import,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.Contains(
            Permissions.StockCountExchange.Import,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
        Assert.DoesNotContain(
            Permissions.StockCountExchange.Import,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.DoesNotContain(
            SecurityRoleMatrix.Assignments[RoleCodes.Driver],
            code => code.StartsWith("Operations", StringComparison.Ordinal));
    }

    [Fact]
    public void CatalogContainsValidatedPhaseBRuntimeSettings()
    {
        var keys = PhaseA2Catalog.Settings.Select(item => item.Key).ToArray();

        Assert.Contains(SystemSettingKeys.FilesExcelImportMaximumMb, keys);
        Assert.Contains(SystemSettingKeys.FilesJsonImportMaximumMb, keys);
        Assert.Contains(SystemSettingKeys.DataExchangeMaximumRows, keys);
        Assert.Contains(SystemSettingKeys.DataExchangeValidationLifetimeMinutes, keys);
        Assert.Contains(SystemSettingKeys.QrDuplicateDelaySeconds, keys);
        Assert.Contains(SystemSettingKeys.CalendarDefaultView, keys);
        Assert.Contains(SystemSettingKeys.CalendarMaximumDateRangeDays, keys);

        var calendarView = PhaseA2Catalog.GetSetting(
            SystemSettingKeys.CalendarDefaultView);
        Assert.True(PhaseA2Catalog.TryNormalizeValue(
            calendarView,
            "week",
            out var normalized,
            out _));
        Assert.Equal("week", normalized);
        Assert.False(PhaseA2Catalog.TryNormalizeValue(
            calendarView,
            "quarter",
            out _,
            out var error));
        Assert.NotNull(error);
    }

    [Fact]
    public void ModelContainsTraceablePhaseBRelationshipsAndUniqueIndexes()
    {
        using var context = Context();
        var association = context.Model.FindEntityType(typeof(ProductCategoryType));
        var job = context.Model.FindEntityType(typeof(DataExchangeJob));
        var stockTake = context.Model.FindEntityType(typeof(StockTakeSession));
        var movement = context.Model.FindEntityType(typeof(StockMovement));

        Assert.NotNull(association);
        Assert.NotNull(job);
        Assert.Contains(
            association!.GetIndexes(),
            index => index.IsUnique &&
                     index.Properties.Select(property => property.Name)
                         .SequenceEqual(new[]
                         {
                             nameof(ProductCategoryType.ProductCategoryId),
                             nameof(ProductCategoryType.ProductTypeId)
                         }));
        Assert.Contains(
            job!.GetIndexes(),
            index => index.IsUnique &&
                     index.Properties.Single().Name ==
                     nameof(DataExchangeJob.ValidationTokenHash));
        Assert.Contains(
            stockTake!.GetIndexes(),
            index => index.IsUnique &&
                     index.Properties.Single().Name ==
                     nameof(StockTakeSession.CorrelationId));
        Assert.Contains(
            movement!.GetForeignKeys(),
            foreignKey => foreignKey.PrincipalEntityType.ClrType ==
                          typeof(StockTakeSession));
    }

    [Fact]
    public void ControllersExposeExpectedPermissionProtectedEndpoints()
    {
        AssertPermission<ProductHierarchyController>(
            nameof(ProductHierarchyController.Get),
            Permissions.ProductHierarchy.View);
        AssertPermission<ProductHierarchyController>(
            nameof(ProductHierarchyController.CreateCategory),
            Permissions.ProductHierarchy.Manage);
        AssertPermission<ProductDataExchangeController>(
            nameof(ProductDataExchangeController.Export),
            Permissions.ProductDataExchange.Export);
        AssertPermission<ProductDataExchangeController>(
            nameof(ProductDataExchangeController.Validate),
            Permissions.ProductDataExchange.Import);
        AssertPermission<StockCountDataExchangeController>(
            nameof(StockCountDataExchangeController.Import),
            Permissions.StockCountExchange.Import);
        AssertPermission<OperationsCalendarController>(
            nameof(OperationsCalendarController.Events),
            Permissions.OperationsCalendar.View);
        AssertPermission<ProductBatchScannerController>(
            nameof(ProductBatchScannerController.Resolve),
            Permissions.ProductBatchScanner.View);
    }

    [Fact]
    public async Task ExcelTemplateIsARealStructuredWorkbook()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        await using var context = Context(connection);
        await context.Database.EnsureCreatedAsync();
        context.Roles.Add(new Role
        {
            RoleId = 1,
            RoleCode = RoleCodes.Admin,
            RoleName = "Admin"
        });
        context.Users.Add(new User
        {
            UserId = 1,
            Email = "tester@example.invalid",
            NormalizedEmail = "TESTER@EXAMPLE.INVALID",
            PasswordHash = "not-used",
            FirstName = "Phase",
            LastName = "Tester",
            RoleId = 1
        });
        await context.SaveChangesAsync();

        var service = new ProductExcelExchangeService(
            context,
            null!,
            new FixedSettings(),
            new NoopAudit());
        var generated = await service.TemplateAsync(1, CancellationToken.None);

        Assert.Equal(ProductExcelExchangeService.ContentType, generated.ContentType);
        Assert.StartsWith("PK", System.Text.Encoding.ASCII.GetString(
            generated.Content,
            0,
            2));
        using var workbook = new XLWorkbook(new MemoryStream(generated.Content));
        Assert.True(workbook.TryGetWorksheet("Instructions", out var instructions));
        Assert.Equal("2.1", instructions.Cell("B2").GetString());
        Assert.True(workbook.TryGetWorksheet("Products and Prices", out var data));
        Assert.Equal("ProductId", data.Cell(6, 1).GetString());
        Assert.Equal("PriceBasis", data.Cell(6, 15).GetString());
        Assert.Equal("PriceChangeReason", data.Cell(6, 18).GetString());
        Assert.Equal(6, data.SheetView.SplitRow);
        using var archive = new System.IO.Compression.ZipArchive(
            new MemoryStream(generated.Content),
            System.IO.Compression.ZipArchiveMode.Read);
        var worksheetXml = string.Join('\n', archive.Entries
            .Where(entry => entry.FullName.StartsWith("xl/worksheets/sheet", StringComparison.Ordinal))
            .Select(entry =>
            {
                using var reader = new StreamReader(entry.Open());
                return reader.ReadToEnd();
            }));
        Assert.Contains("dataValidations", worksheetXml);
        Assert.Contains("PerKilogram,PerSellableUnit", worksheetXml);
    }

    [Fact]
    public async Task ExcelValidationRejectsNonXlsxContentBeforeStaging()
    {
        using var context = Context();
        var service = new ProductExcelExchangeService(
            context,
            null!,
            new FixedSettings(),
            new NoopAudit());
        var bytes = "not an xlsx workbook"u8.ToArray();
        await using var stream = new MemoryStream(bytes);
        IFormFile file = new FormFile(stream, 0, bytes.Length, "file", "products.txt")
        {
            Headers = new HeaderDictionary(),
            ContentType = "text/plain"
        };

        var exception = await Assert.ThrowsAsync<PhaseBException>(() =>
            service.ValidateAsync(file, 1, "test", CancellationToken.None));
        Assert.Equal(400, exception.StatusCode);
    }

    [Fact]
    public async Task ExcelValidationRejectsDuplicateProductIdentityRows()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        await using var context = Context(connection);
        await context.Database.EnsureCreatedAsync();
        var role = new Role { RoleCode = RoleCodes.Admin, RoleName = "Super Admin", IsActive = true };
        var user = new User
        {
            Email = "exchange@example.test",
            NormalizedEmail = "EXCHANGE@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Exchange",
            LastName = "Tester",
            Status = "Active",
            Role = role
        };
        var category = new ProductCategory
        {
            ProductCategoryName = "Fruit",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var type = new ProductType
        {
            ProductTypeName = "Packed Produce",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        context.AddRange(user, category, type);
        await context.SaveChangesAsync();
        context.ProductCategoryTypes.Add(new ProductCategoryType
        {
            ProductCategoryId = category.ProductCategoryId,
            ProductTypeId = type.ProductTypeId,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedByUserId = user.UserId
        });
        var product = new Product
        {
            ProductName = "Granny Smith Apples",
            ProductCategoryId = category.ProductCategoryId,
            ProductTypeId = type.ProductTypeId,
            QRCodeValue = "APPLE-GS-3KG",
            Size = "3 KG",
            ShelfLifeDays = 10,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        context.Products.Add(product);
        await context.SaveChangesAsync();

        var settings = new FixedSettings();
        var service = new ProductExcelExchangeService(
            context,
            new DataExchangeJobService(context, settings),
            settings,
            new NoopAudit());
        var template = await service.TemplateAsync(user.UserId, default);
        using var workbook = new XLWorkbook(new MemoryStream(template.Content));
        var sheet = workbook.Worksheet("Products and Prices");
        for (var row = 7; row <= 8; row++)
        {
            sheet.Cell(row, 1).Value = product.ProductId;
            sheet.Cell(row, 2).Value = product.QRCodeValue;
            sheet.Cell(row, 3).Value = product.ProductName;
            sheet.Cell(row, 4).Value = $"CATEGORY-{category.ProductCategoryId:D4}";
            sheet.Cell(row, 6).Value = $"TYPE-{type.ProductTypeId:D4}";
            sheet.Cell(row, 8).Value = product.Size;
            sheet.Cell(row, 9).Value = "KG";
            sheet.Cell(row, 10).Value = "kg";
            sheet.Cell(row, 12).Value = true;
            sheet.Cell(row, 13).Value = product.ShelfLifeDays;
            sheet.Cell(row, 14).Value = ProductStatuses.Active;
            sheet.Cell(row, 15).Value = ProductPriceBases.PerKilogram;
            sheet.Cell(row, 16).Value = 42m;
            sheet.Cell(row, 18).Value = "Controlled price import";
        }
        await using var bytes = new MemoryStream();
        workbook.SaveAs(bytes);
        bytes.Position = 0;
        IFormFile file = new FormFile(bytes, 0, bytes.Length, "file", "products.xlsx")
        {
            Headers = new HeaderDictionary(),
            ContentType = ProductExcelExchangeService.ContentType
        };

        var result = await service.ValidateAsync(
            file,
            user.UserId,
            "duplicate-product-test",
            default);

        Assert.Equal(1, result.InvalidRows);
        Assert.Contains(
            result.Rows.Single(item => item.RowNumber == 8).Messages,
            message => message.Contains("ProductId is duplicated", StringComparison.Ordinal));
    }

    [Fact]
    public async Task ExcelValidateThenImportPersistsOnceAndIsVisibleOnReload()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        await using var context = Context(connection);
        await context.Database.EnsureCreatedAsync();
        var role = new Role { RoleCode = RoleCodes.Admin, RoleName = "Super Admin", IsActive = true };
        var user = new User
        {
            Email = "excel.persist@example.test",
            NormalizedEmail = "EXCEL.PERSIST@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Excel",
            LastName = "Tester",
            Status = "Active",
            Role = role
        };
        var category = new ProductCategory
        {
            ProductCategoryName = "Vegetables",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var type = new ProductType
        {
            ProductTypeName = "Packed Produce",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        context.AddRange(user, category, type);
        await context.SaveChangesAsync();
        context.ProductCategoryTypes.Add(new ProductCategoryType
        {
            ProductCategoryId = category.ProductCategoryId,
            ProductTypeId = type.ProductTypeId,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedByUserId = user.UserId
        });
        var product = new Product
        {
            ProductName = "Washed Potatoes",
            ProductCategoryId = category.ProductCategoryId,
            ProductTypeId = type.ProductTypeId,
            QRCodeValue = "POTATO-WASHED",
            Size = "Loose",
            ShelfLifeDays = 10,
            SellingPricePerKg = 10m,
            SellingUnit = "kg",
            IsVariableWeight = true,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        context.Products.Add(product);
        await context.SaveChangesAsync();

        var settings = new FixedSettings();
        var service = new ProductExcelExchangeService(
            context,
            new DataExchangeJobService(context, settings),
            settings,
            new NoopAudit());
        var template = await service.TemplateAsync(user.UserId, default);
        using var workbook = new XLWorkbook(new MemoryStream(template.Content));
        var sheet = workbook.Worksheet("Products and Prices");
        sheet.Cell(7, 1).Value = product.ProductId;
        sheet.Cell(7, 2).Value = product.QRCodeValue;
        sheet.Cell(7, 3).Value = product.ProductName;
        sheet.Cell(7, 4).Value = $"CATEGORY-{category.ProductCategoryId:D4}";
        sheet.Cell(7, 5).Value = category.ProductCategoryName;
        sheet.Cell(7, 6).Value = $"TYPE-{type.ProductTypeId:D4}";
        sheet.Cell(7, 7).Value = type.ProductTypeName;
        sheet.Cell(7, 8).Value = "10 kg bag";
        sheet.Cell(7, 9).Value = "KG";
        sheet.Cell(7, 10).Value = "bag";
        sheet.Cell(7, 11).Value = 10m;
        sheet.Cell(7, 12).Value = false;
        sheet.Cell(7, 13).Value = 14;
        sheet.Cell(7, 14).Value = ProductStatuses.Active;
        sheet.Cell(7, 15).Value = ProductPriceBases.PerKilogram;
        sheet.Cell(7, 16).Value = 12.5m;
        sheet.Cell(7, 18).Value = "Approved packaged product price";
        await using var bytes = new MemoryStream();
        workbook.SaveAs(bytes);
        bytes.Position = 0;
        IFormFile file = new FormFile(bytes, 0, bytes.Length, "file", "products.xlsx")
        {
            Headers = new HeaderDictionary(),
            ContentType = ProductExcelExchangeService.ContentType
        };

        var validation = await service.ValidateAsync(
            file,
            user.UserId,
            "excel-persistence-test",
            default);

        Assert.Equal(1, validation.ValidRows);
        Assert.Equal(0, validation.InvalidRows);
        Assert.True(product.IsVariableWeight);
        Assert.Equal(10m, product.SellingPricePerKg);

        var applied = await service.ImportAsync(
            validation.ValidationToken,
            new ApplyDataExchangeRequest { Reason = "Approved catalogue update" },
            user.UserId,
            default);
        context.ChangeTracker.Clear();
        var persisted = await context.Products
            .Include(item => item.ProductPrices)
            .SingleAsync(item => item.ProductId == product.ProductId);

        Assert.Equal(1, applied.UpdatedCount);
        Assert.False(persisted.IsVariableWeight);
        Assert.Equal("bag", persisted.SellingUnit);
        Assert.Equal(10m, persisted.KilogramsPerUnit);
        Assert.Equal(12.5m, persisted.SellingPricePerKg);
        Assert.Single(persisted.ProductPrices,
            price => price.IsCurrent && price.SellingPrice == 12.5m &&
                     price.PriceBasis == ProductPriceBases.PerKilogram);

        var replay = await Assert.ThrowsAsync<PhaseBException>(() =>
            service.ImportAsync(
                validation.ValidationToken,
                new ApplyDataExchangeRequest { Reason = "Unsafe duplicate retry" },
                user.UserId,
                default));
        Assert.Equal(409, replay.StatusCode);
        Assert.Single(await context.ProductPrices.ToListAsync());
    }

    [Fact]
    public async Task StockCountValidateThenImportPersistsOnceAndIsVisibleOnReload()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        await using var context = Context(connection);
        await context.Database.EnsureCreatedAsync();
        var role = new Role { RoleCode = RoleCodes.WarehouseManager, RoleName = "Warehouse Manager", IsActive = true };
        var user = new User
        {
            Email = "stock.persist@example.test",
            NormalizedEmail = "STOCK.PERSIST@EXAMPLE.TEST",
            PasswordHash = "test-only",
            FirstName = "Stock",
            LastName = "Tester",
            Status = "Active",
            Role = role
        };
        var category = new ProductCategory
        {
            ProductCategoryName = "Vegetables",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var type = new ProductType
        {
            ProductTypeName = "Fresh Produce",
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        var section = new WarehouseSection
        {
            SectionCode = "COLD",
            SectionName = "Cold Room",
            Status = "Active",
            CreatedAtUtc = DateTime.UtcNow
        };
        context.AddRange(user, category, type, section);
        await context.SaveChangesAsync();
        var product = new Product
        {
            ProductName = "Carrots",
            ProductCategoryId = category.ProductCategoryId,
            ProductTypeId = type.ProductTypeId,
            QRCodeValue = "CARROT-1KG",
            Size = "1 kg",
            ShelfLifeDays = 10,
            SellingUnit = "kg",
            IsVariableWeight = true,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        context.Products.Add(product);
        await context.SaveChangesAsync();
        context.Stocks.Add(new Stock
        {
            ProductId = product.ProductId,
            SectionId = section.SectionId,
            QuantityAvailableKg = 10m,
            InventoryStatus = "Available"
        });
        await context.SaveChangesAsync();

        var package = new StockCountPackageDto
        {
            ExportId = "stock-persistence-test",
            ExportedAtUtc = DateTime.UtcNow,
            ExportedBy = new StockCountExportedByDto { DisplayName = "Stock Tester" },
            WarehouseSection = new StockCountWarehouseSectionDto
            {
                Code = section.SectionCode,
                Name = section.SectionName
            },
            Items =
            [
                new StockCountPackageItemDto
                {
                    ProductCode = product.QRCodeValue!,
                    ProductName = product.ProductName,
                    UnitOfMeasure = "KG",
                    ExpectedQuantity = 10m,
                    CountedQuantity = 12m
                }
            ]
        };
        var content = JsonSerializer.SerializeToUtf8Bytes(
            package,
            new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
        await using var stream = new MemoryStream(content);
        IFormFile file = new FormFile(stream, 0, content.Length, "file", "stock-count.json")
        {
            Headers = new HeaderDictionary(),
            ContentType = "application/json"
        };
        var settings = new FixedSettings();
        var service = new StockCountJsonExchangeService(
            context,
            new DataExchangeJobService(context, settings),
            settings,
            new NoopAudit());

        var validation = await service.ValidateAsync(
            file,
            user.UserId,
            "stock-persistence-test",
            default);

        Assert.Equal(1, validation.ValidRows);
        Assert.Equal(10m, (await context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.Empty(await context.StockMovements.ToListAsync());

        var applied = await service.ImportAsync(
            validation.ValidationToken,
            new ApplyDataExchangeRequest { Reason = "Approved physical count" },
            user.UserId,
            default);
        context.ChangeTracker.Clear();

        Assert.Equal(1, applied.AdjustmentCount);
        Assert.Equal(12m, (await context.Stocks.SingleAsync()).QuantityAvailableKg);
        Assert.Single(await context.StockMovements.ToListAsync());
        Assert.Single(await context.StockTakeSessions.ToListAsync());

        var replay = await Assert.ThrowsAsync<PhaseBException>(() =>
            service.ImportAsync(
                validation.ValidationToken,
                new ApplyDataExchangeRequest { Reason = "Unsafe duplicate retry" },
                user.UserId,
                default));
        Assert.Equal(409, replay.StatusCode);
        Assert.Single(await context.StockMovements.ToListAsync());
        Assert.Single(await context.StockTakeSessions.ToListAsync());
    }

    [Fact]
    public async Task StockCountValidationRejectsMalformedJson()
    {
        using var context = Context();
        var service = new StockCountJsonExchangeService(
            context,
            null!,
            new FixedSettings(),
            new NoopAudit());
        var bytes = "{ malformed"u8.ToArray();
        await using var stream = new MemoryStream(bytes);
        IFormFile file = new FormFile(stream, 0, bytes.Length, "file", "count.json")
        {
            Headers = new HeaderDictionary(),
            ContentType = "application/json"
        };

        var exception = await Assert.ThrowsAsync<PhaseBException>(() =>
            service.ValidateAsync(file, 1, "test", CancellationToken.None));
        Assert.Equal(400, exception.StatusCode);
        Assert.Contains("valid JSON", exception.Message);
    }

    [Fact]
    public void StockCountPackageContainsOnlyInventorySnapshotFields()
    {
        var json = JsonSerializer.Serialize(new StockCountPackageDto
        {
            ExportId = "stock-count-example",
            ExportedAtUtc = DateTime.UtcNow,
            ExportedBy = new StockCountExportedByDto
            {
                DisplayName = "Stock Taker"
            },
            WarehouseSection = new StockCountWarehouseSectionDto
            {
                Code = "COLD",
                Name = "Cold Room"
            },
            Items =
            [
                new StockCountPackageItemDto
                {
                    ProductCode = "CARROT-1KG",
                    ProductName = "Carrots 1 kg",
                    ExpectedQuantity = 20,
                    CountedQuantity = 19
                }
            ]
        }, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });

        Assert.Contains("CARROT-1KG", json);
        Assert.DoesNotContain("productId", json, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("batchId", json, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("batchCode", json, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("price", json, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("cost", json, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void StockCountSchemaAndSampleMatchTheActiveParserContract()
    {
        using var context = Context();
        var service = new StockCountJsonExchangeService(
            context,
            null!,
            new FixedSettings(),
            new NoopAudit());

        var schema = JsonDocument.Parse(service.Schema().Content).RootElement;
        var sample = JsonSerializer.Deserialize<StockCountPackageDto>(
            service.Sample().Content,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

        Assert.Equal(StockCountJsonExchangeService.SchemaVersion,
            schema.GetProperty("properties").GetProperty("schemaVersion").GetProperty("const").GetString());
        Assert.NotNull(sample);
        Assert.Equal(StockCountJsonExchangeService.SchemaVersion, sample!.SchemaVersion);
        Assert.NotEmpty(sample.Items);
        Assert.Equal("KG", sample.Items.Single().UnitOfMeasure);
    }

    [Fact]
    public async Task HierarchyRejectsInvalidFilterIds()
    {
        using var context = Context();
        var service = new ProductHierarchyService(context, new NoopAudit());

        var exception = await Assert.ThrowsAsync<PhaseBException>(() =>
            service.GetAsync(null, false, 0, null, CancellationToken.None));
        Assert.Equal(400, exception.StatusCode);
    }

    [Fact]
    public async Task HierarchyCreatesProductWithoutOptionalInitialPrice()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        await using var context = Context(connection);
        await context.Database.EnsureCreatedAsync();
        var category = new ProductCategory
        {
            ProductCategoryName = "Produce",
            Status = "Active",
            CreatedAt = DateTime.UtcNow
        };
        var type = new ProductType
        {
            ProductTypeName = "Fresh",
            Status = "Active",
            CreatedAt = DateTime.UtcNow
        };
        context.AddRange(category, type);
        await context.SaveChangesAsync();
        context.ProductCategoryTypes.Add(new ProductCategoryType
        {
            ProductCategoryId = category.ProductCategoryId,
            ProductTypeId = type.ProductTypeId,
            CreatedAtUtc = DateTime.UtcNow
        });
        await context.SaveChangesAsync();
        var service = new ProductHierarchyService(context, new NoopAudit());

        var productId = await service.CreateProductAsync(
            category.ProductCategoryId,
            type.ProductTypeId,
            new CreateHierarchyProductRequest
            {
                ProductName = "Unpriced Product",
                Size = "1 kg",
                ShelfLifeDays = 30,
                InitialSellingPrice = null,
                InitialPriceBasis = ProductPriceBases.PerKilogram,
                SellingUnit = "kg",
                IsVariableWeight = true,
                PriceReason = null,
                Status = "Active"
            },
            999,
            CancellationToken.None);

        var product = await context.Products.FindAsync(productId);
        Assert.NotNull(product);
        Assert.Equal(0, product!.SellingPricePerKg);
        Assert.False(await context.ProductPrices.AnyAsync(
            item => item.ProductId == productId));
    }

    [Fact]
    public async Task CalendarRejectsInvertedOrExcessiveRanges()
    {
        using var context = Context();
        var service = new OperationsCalendarService(context, new FixedSettings());
        var now = DateTime.UtcNow;

        var inverted = await Assert.ThrowsAsync<PhaseBException>(() =>
            service.GetAsync(new OperationsCalendarQueryDto
            {
                StartUtc = now,
                EndUtc = now.AddHours(-1)
            }, 1, RoleCodes.Admin, CancellationToken.None));
        Assert.Equal(400, inverted.StatusCode);

        var excessive = await Assert.ThrowsAsync<PhaseBException>(() =>
            service.GetAsync(new OperationsCalendarQueryDto
            {
                StartUtc = now,
                EndUtc = now.AddDays(94)
            }, 1, RoleCodes.Admin, CancellationToken.None));
        Assert.Equal(400, excessive.StatusCode);
    }

    [Theory]
    [InlineData("")]
    [InlineData("bad")]
    [InlineData("    ")]
    public async Task QrResolutionRejectsMalformedValues(string value)
    {
        using var context = Context();
        var service = new QrResolutionService(
            context,
            new FixedSettings(),
            new NoopAudit());

        var exception = await Assert.ThrowsAsync<PhaseBException>(() =>
            service.ResolveAsync(value, 1, CancellationToken.None));
        Assert.Equal(400, exception.StatusCode);
    }

    private static PhenyoSyncDbContext Context(
        SqliteConnection? connection = null)
    {
        var builder = new DbContextOptionsBuilder<PhenyoSyncDbContext>();
        builder.UseSqlite(connection ?? new SqliteConnection("Data Source=:memory:"));
        return new PhenyoSyncDbContext(builder.Options);
    }

    private static void AssertPermission<TController>(
        string methodName,
        string expected)
    {
        var attributes = typeof(TController).GetMethod(methodName)!
            .GetCustomAttributes(true)
            .OfType<HasPermissionAttribute>()
            .Select(attribute => attribute.Policy)
            .Concat(typeof(TController).GetCustomAttributes(true)
                .OfType<HasPermissionAttribute>()
                .Select(attribute => attribute.Policy))
            .ToArray();
        Assert.Contains(HasPermissionAttribute.PolicyPrefix + expected, attributes);
    }

    private sealed class NoopAudit : IAuditService
    {
        public Task RecordAsync(
            AuditEvent auditEvent,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;
    }

    private sealed class FixedSettings : ISystemSettingProvider
    {
        public Task<int> GetIntAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(key switch
            {
                SystemSettingKeys.FilesExcelImportMaximumMb => 10,
                SystemSettingKeys.FilesJsonImportMaximumMb => 5,
                SystemSettingKeys.DataExchangeMaximumRows => 2000,
                SystemSettingKeys.DataExchangeValidationLifetimeMinutes => 30,
                SystemSettingKeys.CalendarMaximumDateRangeDays => 93,
                SystemSettingKeys.ExpiryYellowThresholdHours => 72,
                SystemSettingKeys.ExpiryRedThresholdHours => 24,
                _ => int.Parse(PhaseA2Catalog.GetSetting(key).DefaultValue)
            });

        public Task<decimal> GetDecimalAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(decimal.Parse(
                PhaseA2Catalog.GetSetting(key).DefaultValue));

        public Task<bool> GetBooleanAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(bool.Parse(
                PhaseA2Catalog.GetSetting(key).DefaultValue));

        public Task<string> GetStringAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(PhaseA2Catalog.GetSetting(key).DefaultValue);

        public Task<string[]> GetStringArrayAsync(
            string key,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(Array.Empty<string>());

        public void Invalidate(string key) {}
        public void InvalidateAll() {}
    }
}
