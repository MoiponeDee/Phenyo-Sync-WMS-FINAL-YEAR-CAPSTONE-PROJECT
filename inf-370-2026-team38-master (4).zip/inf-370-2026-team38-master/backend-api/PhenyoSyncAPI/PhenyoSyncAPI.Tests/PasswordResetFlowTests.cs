using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Auth;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Proves privacy-safe requests, single encoding, expiry/consumption and session invalidation.
public sealed class PasswordResetFlowTests
{
    [Fact]
    public async Task ForgotPasswordStoresTokenAndHandsAliasLinkToConfiguredSender()
    {
        await using var database = await ResetDatabase.CreateAsync();
        const string alias = "zafarsuliman+warehousemanager5@gmail.com";
        var user = await database.AddUserAsync(alias);

        var result = await database.Controller.ForgotPassword(
            new ForgotPasswordRequest { Email = alias },
            CancellationToken.None);

        Assert.IsType<OkObjectResult>(result);
        Assert.Equal(alias, database.Email.Recipient);
        Assert.NotNull(database.Email.ResetLink);
        Assert.StartsWith(
            "https://wms.example.test/reset-password?",
            database.Email.ResetLink,
            StringComparison.Ordinal);
        Assert.Contains(
            "email=zafarsuliman%2Bwarehousemanager5%40gmail.com",
            database.Email.ResetLink,
            StringComparison.Ordinal);
        Assert.DoesNotContain("%252B", database.Email.ResetLink, StringComparison.Ordinal);

        var query = QueryHelpers.ParseQuery(new Uri(database.Email.ResetLink!).Query);
        Assert.Equal(alias, query["email"].ToString());
        Assert.False(string.IsNullOrWhiteSpace(query["token"]));
        Assert.NotNull(user.PasswordResetTokenHash);
        Assert.NotNull(user.PasswordResetTokenExpiry);
        Assert.True(user.PasswordResetTokenExpiry > DateTime.UtcNow);
        Assert.DoesNotContain(
            query["token"].ToString(),
            user.PasswordResetTokenHash,
            StringComparison.Ordinal);
    }

    [Fact]
    public async Task UnknownAccountAndSmtpFailureReturnTheSamePrivacySafeResponse()
    {
        await using var database = await ResetDatabase.CreateAsync();
        var unknown = await database.Controller.ForgotPassword(
            new ForgotPasswordRequest { Email = "unknown@example.test" },
            CancellationToken.None);
        await database.AddUserAsync("known@example.test");
        database.Email.ThrowOnPasswordReset = true;

        var sendFailure = await database.Controller.ForgotPassword(
            new ForgotPasswordRequest { Email = "known@example.test" },
            CancellationToken.None);

        var unknownOk = Assert.IsType<OkObjectResult>(unknown);
        var failureOk = Assert.IsType<OkObjectResult>(sendFailure);
        Assert.Equal(
            JsonSerializer.Serialize(unknownOk.Value),
            JsonSerializer.Serialize(failureOk.Value));
        var audit = Assert.Single(
            database.Audit.Events,
            item => item.OperationName == "SendPasswordResetEmail");
        Assert.False(audit.Success);
        Assert.Equal("Email delivery failed.", audit.FailureReason);
        Assert.DoesNotContain("known@example.test", audit.EntityDisplay ?? string.Empty);
    }

    [Fact]
    public async Task ResetPasswordRejectsInvalidExpiredAndAlreadyUsedTokens()
    {
        await using var database = await ResetDatabase.CreateAsync();
        var user = await database.AddUserAsync("reset@example.test");
        await database.Controller.ForgotPassword(
            new ForgotPasswordRequest { Email = user.Email },
            CancellationToken.None);
        var token = QueryHelpers.ParseQuery(
            new Uri(database.Email.ResetLink!).Query)["token"].ToString();

        Assert.IsType<BadRequestObjectResult>(await database.Controller.ResetPassword(
            Request(user.Email, token + "invalid")));

        user.PasswordResetTokenExpiry = DateTime.UtcNow.AddMinutes(-1);
        await database.Context.SaveChangesAsync();
        Assert.IsType<BadRequestObjectResult>(await database.Controller.ResetPassword(
            Request(user.Email, token)));

        user.PasswordResetTokenExpiry = DateTime.UtcNow.AddMinutes(10);
        await database.Context.SaveChangesAsync();
        var securityVersion = user.SecurityVersion;
        Assert.IsType<OkObjectResult>(await database.Controller.ResetPassword(
            Request(user.Email, token)));

        Assert.True(BCrypt.Net.BCrypt.Verify("New-password-123!", user.PasswordHash));
        Assert.Null(user.PasswordResetTokenHash);
        Assert.Null(user.PasswordResetTokenExpiry);
        Assert.Equal(securityVersion + 1, user.SecurityVersion);
        Assert.True(user.RequireTwoFactorOnNextWebLogin);
        Assert.IsType<BadRequestObjectResult>(await database.Controller.ResetPassword(
            Request(user.Email, token)));
    }

    private static ResetPasswordRequest Request(string email, string token) => new()
    {
        Email = email,
        Token = token,
        NewPassword = "New-password-123!",
        ConfirmPassword = "New-password-123!"
    };

    private sealed class ResetDatabase : IAsyncDisposable
    {
        private readonly SqliteConnection _connection;

        private ResetDatabase(
            SqliteConnection connection,
            PhenyoSyncDbContext context,
            AuthController controller,
            CapturingEmail email,
            CapturingAudit audit)
        {
            _connection = connection;
            Context = context;
            Controller = controller;
            Email = email;
            Audit = audit;
        }

        public PhenyoSyncDbContext Context { get; }
        public AuthController Controller { get; }
        public CapturingEmail Email { get; }
        public CapturingAudit Audit { get; }

        public static async Task<ResetDatabase> CreateAsync()
        {
            var connection = new SqliteConnection("Data Source=:memory:");
            await connection.OpenAsync();
            var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
                .UseSqlite(connection)
                .Options;
            var context = new PhenyoSyncDbContext(options);
            await context.Database.EnsureCreatedAsync();
            var email = new CapturingEmail();
            var audit = new CapturingAudit();
            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["FrontendUrl"] = "https://wms.example.test",
                    ["Jwt:Key"] = "test-only-signing-key-with-at-least-32-characters",
                    ["Jwt:Issuer"] = "PhenyoSync.Tests",
                    ["Jwt:Audience"] = "PhenyoSync.Tests"
                })
                .Build();
            var twoFactor = new TwoFactorService(context, null!, email, audit);
            var controller = new AuthController(
                context,
                new JwtService(configuration),
                email,
                configuration,
                audit,
                twoFactor,
                NullLogger<AuthController>.Instance)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext()
                }
            };
            return new ResetDatabase(connection, context, controller, email, audit);
        }

        public async Task<User> AddUserAsync(string email)
        {
            var user = new User
            {
                Email = email,
                NormalizedEmail = email.ToUpperInvariant(),
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("Old-password-123!"),
                FirstName = "Reset",
                LastName = "Tester",
                Status = "Active",
                Role = new Role
                {
                    RoleCode = RoleCodes.Driver,
                    RoleName = "Driver",
                    IsActive = true
                }
            };
            Context.Users.Add(user);
            await Context.SaveChangesAsync();
            return user;
        }

        public async ValueTask DisposeAsync()
        {
            await Context.DisposeAsync();
            await _connection.DisposeAsync();
        }
    }

    private sealed class CapturingEmail : IEmailService
    {
        public string? Recipient { get; private set; }
        public string? ResetLink { get; private set; }
        public bool ThrowOnPasswordReset { get; set; }

        public Task SendPasswordResetEmailAsync(string recipientEmail, string resetLink)
        {
            Recipient = recipientEmail;
            ResetLink = resetLink;
            return ThrowOnPasswordReset
                ? Task.FromException(new InvalidOperationException("Test SMTP failure."))
                : Task.CompletedTask;
        }

        public Task SendExpiryAlertEmailAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string reviewLink,
            CancellationToken cancellationToken = default) => Task.CompletedTask;

        public Task SendExpiryDecisionConfirmationAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string decision,
            CancellationToken cancellationToken = default) => Task.CompletedTask;

        public Task SendCustomerOrderLinkEmailAsync(
            string recipientEmail,
            string customerName,
            string orderLink,
            DateTime expiresAtUtc,
            CancellationToken cancellationToken = default) => Task.CompletedTask;
    }

    private sealed class CapturingAudit : IAuditService
    {
        public List<AuditEvent> Events { get; } = [];

        public Task RecordAsync(
            AuditEvent auditEvent,
            CancellationToken cancellationToken = default)
        {
            Events.Add(auditEvent);
            return Task.CompletedTask;
        }
    }
}
