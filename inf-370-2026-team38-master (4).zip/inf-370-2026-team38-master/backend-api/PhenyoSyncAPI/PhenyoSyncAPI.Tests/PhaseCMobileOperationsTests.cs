using Microsoft.Data.Sqlite;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using System.Data.Common;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Exercises idempotent mobile buying, receiving, packing, tracking and write-off workflows.
public sealed class PhaseCMobileOperationsTests
{
    [Fact]
    public void CatalogContainsEveryPhaseCPermissionExactlyOnce()
    {
        var codes = Permissions.Catalog.Select(item => item.Code).ToArray();
        var required = codes
            .Where(code =>
                code.StartsWith("Mobile.", StringComparison.Ordinal) ||
                code.StartsWith("Notifications.", StringComparison.Ordinal))
            .ToArray();

        Assert.Equal(47, required.Length);
        Assert.Equal(
            required.Length,
            required.Distinct(StringComparer.OrdinalIgnoreCase).Count());
        Assert.Contains(Permissions.Mobile.DeliveryUploadProof, required);
        Assert.Contains(Permissions.Mobile.PackingScan, required);
        Assert.Contains(Permissions.Mobile.DispatchConfirm, required);
        Assert.Contains(Permissions.Mobile.WriteOffApprove, required);
        Assert.Contains(Permissions.Mobile.BuyingListViewAll, required);
        Assert.Contains(Permissions.Mobile.BuyingListCreate, required);
        Assert.Contains(Permissions.Mobile.BuyingListAssign, required);
        Assert.Contains(Permissions.Mobile.NotificationView, required);
        Assert.Contains(Permissions.Mobile.ProfileView, required);
        Assert.Contains(Permissions.Mobile.HelpView, required);
        Assert.Contains(Permissions.Notifications.View, required);
    }

    [Fact]
    public void ManagementRolesReceiveScopedPhaseCPermissionsWithoutBypassLogic()
    {
        var operations = SecurityRoleMatrix.Assignments[RoleCodes.OperationsManager];
        Assert.Contains(Permissions.Mobile.TrackingViewAll, operations);
        Assert.Contains(Permissions.Mobile.WriteOffApprove, operations);
        Assert.DoesNotContain(Permissions.Mobile.PackingScan, operations);

        var superAdmin = SecurityRoleMatrix.Assignments[RoleCodes.Admin];
        Assert.Contains(Permissions.Mobile.BuyingListCreate, superAdmin);
        Assert.Contains(Permissions.Mobile.DispatchView, superAdmin);
        Assert.Contains(Permissions.Orders.Validate, superAdmin);
        Assert.Contains(Permissions.Orders.Confirm, superAdmin);
        Assert.DoesNotContain(Permissions.Orders.ChangeStatus, superAdmin);
        Assert.DoesNotContain(Permissions.Mobile.StockReceiptSubmit, superAdmin);

        var warehouseManager = SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager];
        Assert.Contains(Permissions.Mobile.StockReceiptSubmit, warehouseManager);
        Assert.Contains(Permissions.Mobile.DispatchConfirm, warehouseManager);
        Assert.Contains(Permissions.Orders.ChangeStatus, warehouseManager);
        Assert.DoesNotContain(Permissions.Orders.Validate, warehouseManager);
        Assert.DoesNotContain(Permissions.Mobile.BuyingListCreate, warehouseManager);
    }

    [Fact]
    public void OperationalRolesRemainScopedToTheirOwnMobileWorkflows()
    {
        Assert.Contains(
            Permissions.Mobile.DeliveryCompleteOwn,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
        Assert.Contains(
            Permissions.Mobile.DeliveryUploadProof,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
        Assert.Contains(
            Permissions.Deliveries.ViewProof,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
        Assert.DoesNotContain(
            Permissions.Mobile.DispatchConfirm,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
        Assert.Contains(
            Permissions.Mobile.PackingScan,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.Contains(
            Permissions.Mobile.PackingRemoveScan,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.Contains(
            Permissions.Mobile.PackingComplete,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.DoesNotContain(
            Permissions.Orders.Validate,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.DoesNotContain(
            Permissions.Mobile.DispatchConfirm,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.DoesNotContain(
            Permissions.Orders.Validate,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
        Assert.DoesNotContain(
            Permissions.Mobile.PackingScan,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
        Assert.DoesNotContain(
            Permissions.Mobile.WriteOffApprove,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
        Assert.Contains(
            Permissions.Mobile.BuyingListUpdate,
            SecurityRoleMatrix.Assignments[RoleCodes.MarketBuyer]);
    }

    [Fact]
    public void CatalogContainsValidatedPhaseCRuntimeSettings()
    {
        var keys = PhaseA2Catalog.Settings.Select(item => item.Key).ToArray();
        var required = new[]
        {
            SystemSettingKeys.MobileLocationIntervalSeconds,
            SystemSettingKeys.MobileLocationRetentionDays,
            SystemSettingKeys.MapsTrafficAwareEnabled,
            SystemSettingKeys.NotificationsPushEnabled,
            SystemSettingKeys.NotificationsMaximumRetryCount,
            SystemSettingKeys.WriteOffWarehouseManagerMaximumValue,
            SystemSettingKeys.WriteOffRequireApprovalAboveValue
        };

        Assert.All(required, key => Assert.Contains(key, keys));
        Assert.Equal(keys.Length, keys.Distinct(StringComparer.OrdinalIgnoreCase).Count());
    }

    [Fact]
    public void ModelContainsTrackingNotificationAndWriteOffSafeguards()
    {
        using var context = Context();
        var tracking = context.Model.FindEntityType(typeof(DriverTrackingSession));
        var notificationRecipient =
            context.Model.FindEntityType(typeof(OperationalNotificationRecipient));
        var idempotency =
            context.Model.FindEntityType(typeof(MobileIdempotencyRecord));
        var writeOff = context.Model.FindEntityType(typeof(StockWriteOff));

        Assert.NotNull(tracking);
        Assert.NotNull(notificationRecipient);
        Assert.NotNull(idempotency);
        Assert.NotNull(writeOff);
        Assert.Contains(
            tracking!.GetIndexes(),
            index => index.IsUnique &&
                     index.Properties.Single().Name ==
                     nameof(DriverTrackingSession.DeliveryId));
        Assert.Contains(
            notificationRecipient!.GetIndexes(),
            index => index.IsUnique &&
                     index.Properties.Select(property => property.Name)
                         .SequenceEqual(new[]
                         {
                             nameof(OperationalNotificationRecipient.OperationalNotificationId),
                             nameof(OperationalNotificationRecipient.UserId)
                         }));
        Assert.Contains(
            idempotency!.GetIndexes(),
            index => index.IsUnique &&
                     index.Properties.Select(property => property.Name)
                         .SequenceEqual(new[]
                         {
                             nameof(MobileIdempotencyRecord.UserId),
                             nameof(MobileIdempotencyRecord.OperationType),
                             nameof(MobileIdempotencyRecord.OperationKeyHash)
                         }));
        Assert.Contains(
            writeOff!.GetForeignKeys(),
            foreignKey => foreignKey.PrincipalEntityType.ClrType ==
                          typeof(ProductBatch));
    }

    [Fact]
    public void ControllersProtectCriticalMobileMutationsWithPermissions()
    {
        AssertPermission<MobileBuyingListsController>(
            "UpdateItem",
            Permissions.Mobile.BuyingListUpdate);
        AssertPermission<MobileStockReceiptsController>(
            "Submit",
            Permissions.Mobile.StockReceiptSubmit);
        AssertPermission<MobilePackingController>(
            "Scan",
            Permissions.Mobile.PackingScan);
        AssertPermission<MobileDispatchController>(
            "Confirm",
            Permissions.Mobile.DispatchConfirm);
        AssertPermission<MobileWriteOffsController>(
            "Approve",
            Permissions.Mobile.WriteOffApprove);

        var proofUpload = typeof(DeliveriesController)
            .GetMethod(nameof(DeliveriesController.UploadProofImage))!
            .GetCustomAttributes(true)
            .OfType<AuthorizeAttribute>()
            .Select(attribute => attribute.Policy)
            .Single(policy => policy?.StartsWith(
                HasAnyPermissionAttribute.PolicyPrefix,
                StringComparison.Ordinal) == true);
        Assert.Equal(
            HasAnyPermissionAttribute.PolicyPrefix + string.Join(",",
                Permissions.Deliveries.ViewProof,
                Permissions.Mobile.DeliveryUploadProof),
            proofUpload);
    }

    [Fact]
    public async Task NotificationsResolveOnlyActiveUsersInTargetRoles()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        await using var context = Context(connection);
        await context.Database.EnsureCreatedAsync();

        context.Roles.AddRange(
            Role(1, RoleCodes.BusinessManager),
            Role(2, RoleCodes.OperationsManager),
            Role(3, RoleCodes.Admin));
        context.Users.AddRange(
            User(1, 1, "zafarsuliman+business-manager@gmail.com"),
            User(2, 2, "zafarsuliman+operations-manager@gmail.com"),
            User(3, 3, "zafarsuliman+administrator@gmail.com"));
        await context.SaveChangesAsync();

        var service = new OperationalNotificationService(context);
        await service.PublishToRolesAsync(
            "DeliveryCompleted",
            "Success",
            "Delivery completed",
            "Proof is available.",
            [RoleCodes.BusinessManager, RoleCodes.OperationsManager],
            nameof(Delivery),
            "8",
            "/deliveries",
            1,
            "delivery-completed-8",
            CancellationToken.None);

        var recipients = await context.OperationalNotificationRecipients
            .Select(item => item.UserId)
            .OrderBy(item => item)
            .ToArrayAsync();
        Assert.Equal(new[] { 2, 3 }, recipients);
    }

    [Fact]
    public void ExternalProvidersAreSafeWhenNotConfigured()
    {
        Assert.False(new GoogleMapsOptions().IsConfigured);
        Assert.False(new FirebaseMessagingOptions().IsConfigured);
        Assert.True(new MobileOperationsOptions().RequireHttpsOutsideDevelopment);
    }

    [Fact]
    public async Task TrackingHistoryReturnsOrderedPointsAndEnforcesOwnership()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        await using var context = Context(connection);
        await context.Database.EnsureCreatedAsync();

        var role = Role(1, RoleCodes.Driver);
        var user = User(1, role.RoleId, "zafarsuliman+driver-history@gmail.com");
        var customer = new Customer
        {
            CustomerNumber = "TRACK-CUST-001",
            CustomerName = "Tracking Test Customer",
            Email = "tracking-customer@example.invalid",
            NormalizedEmail = "TRACKING-CUSTOMER@EXAMPLE.INVALID",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var order = new SalesOrder
        {
            OrderNumber = "TRACK-ORDER-001",
            Customer = customer,
            OrderDateUtc = DateTime.UtcNow,
            DeliveryAddressSnapshot = "Test delivery address",
            BillingAddressSnapshot = "Test billing address",
            Status = SalesOrderStatuses.OutForDelivery,
            ValidationStatus = OrderValidationStatuses.Approved,
            CreatedAtUtc = DateTime.UtcNow
        };
        var driver = new Driver
        {
            User = user,
            LicenseNumber = "TEST-LICENCE",
            AvailabilityStatus = "Assigned"
        };
        var delivery = new Delivery
        {
            SalesOrder = order,
            Driver = driver,
            DeliveryAddressSnapshot = order.DeliveryAddressSnapshot,
            ScheduledStartUtc = DateTime.UtcNow.AddHours(-1),
            ScheduledEndUtc = DateTime.UtcNow.AddHours(1),
            Status = DeliveryStatuses.InTransit,
            CreatedAtUtc = DateTime.UtcNow
        };
        var session = new DriverTrackingSession
        {
            Delivery = delivery,
            Driver = driver,
            StartedByUser = user,
            StartedAtUtc = DateTime.UtcNow.AddMinutes(-4),
            ConsentConfirmedAtUtc = DateTime.UtcNow.AddMinutes(-4),
            Status = TrackingSessionStatuses.Active,
            CorrelationId = "tracking-history-test"
        };
        session.Locations.Add(new DriverLocationUpdate
        {
            Latitude = -25.75m,
            Longitude = 28.23m,
            AccuracyMetres = 12,
            CapturedAtUtc = DateTime.UtcNow.AddMinutes(-1),
            ReceivedAtUtc = DateTime.UtcNow.AddMinutes(-1),
            Source = "Browser",
            OperationKeyHash = "tracking-history-second"
        });
        session.Locations.Add(new DriverLocationUpdate
        {
            Latitude = -25.76m,
            Longitude = 28.22m,
            AccuracyMetres = 15,
            CapturedAtUtc = DateTime.UtcNow.AddMinutes(-3),
            ReceivedAtUtc = DateTime.UtcNow.AddMinutes(-3),
            Source = "Browser",
            OperationKeyHash = "tracking-history-first"
        });
        context.Roles.Add(role);
        context.DriverTrackingSessions.Add(session);
        await context.SaveChangesAsync();

        var service = new DriverTrackingService(context, new NoopAuditService());
        var history = await service.HistoryAsync(
            session.DriverTrackingSessionId,
            user.UserId,
            false,
            CancellationToken.None);

        Assert.Equal(2, history.Count);
        Assert.True(history[0].CapturedAtUtc < history[1].CapturedAtUtc);
        var forbidden = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.HistoryAsync(
                session.DriverTrackingSessionId,
                999,
                false,
                CancellationToken.None));
        Assert.Equal(403, forbidden.StatusCode);
    }

    [Fact]
    public async Task BuyingListProjectionUsesSplitQueriesForNestedStockCollections()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var commands = new CountingCommandInterceptor();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .AddInterceptors(commands)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();

        var buyerRole = Role(1, RoleCodes.MarketBuyer);
        var buyer = User(1, buyerRole.RoleId, "buyer@example.invalid");
        var rawStock = new RawStockItem
        {
            ItemCode = "RAW-SPLIT",
            ItemName = "Split Query Produce",
            CategoryCode = RawStockCategories.Produce,
            DefaultUnitOfMeasure = RawStockUnits.Kilogram,
            IsProduce = true,
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        var sectionA = new WarehouseSection
        {
            SectionCode = "SPLIT-A",
            SectionName = "Split A",
            Status = ProductStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var sectionB = new WarehouseSection
        {
            SectionCode = "SPLIT-B",
            SectionName = "Split B",
            Status = ProductStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        rawStock.Balances.Add(new RawStockBalance
        {
            WarehouseSection = sectionA,
            QuantityOnHand = 5m,
            UnitOfMeasure = RawStockUnits.Kilogram
        });
        rawStock.Balances.Add(new RawStockBalance
        {
            WarehouseSection = sectionB,
            QuantityOnHand = 7m,
            UnitOfMeasure = RawStockUnits.Kilogram
        });
        var list = new BuyerProcurement
        {
            ReferenceNumber = "BL-SPLIT-001",
            BuyingDateUtc = DateTime.UtcNow,
            AssignedBuyerUser = buyer,
            Status = BuyingListStatuses.Open,
            Priority = BuyingListPriorities.Standard,
            CorrelationId = "split-query-test",
            CreatedAtUtc = DateTime.UtcNow,
            UpdatedAtUtc = DateTime.UtcNow
        };
        list.Items.Add(new BuyerProcurementItem
        {
            RawStockItem = rawStock,
            RequiredQuantity = 20m,
            RecommendedQuantity = 20m,
            UnitOfMeasure = RawStockUnits.Kilogram,
            Status = BuyingItemStatuses.Pending,
            Priority = BuyingListPriorities.Standard,
            UpdatedAtUtc = DateTime.UtcNow
        });
        context.AddRange(buyerRole, list);
        await context.SaveChangesAsync();
        commands.Reset();

        var service = new MobileBuyingListService(
            context,
            new OperationalNotificationService(context),
            new DeliveryProofSettings(),
            new FakeProtectedFileStorage(),
            new NoopAuditService());

        var result = await service.ListAsync(
            buyer.UserId,
            false,
            CancellationToken.None);

        var projected = Assert.Single(Assert.Single(result).Items);
        Assert.Equal(12m, projected.CurrentStockKg);
        Assert.True(commands.ReaderCommands > 1);
    }

    private static PhenyoSyncDbContext Context(SqliteConnection? connection = null)
    {
        var builder = new DbContextOptionsBuilder<PhenyoSyncDbContext>();
        builder.UseSqlite(connection ?? new SqliteConnection("Data Source=:memory:"));
        return new PhenyoSyncDbContext(builder.Options);
    }

    private static Role Role(int id, string code) =>
        new()
        {
            RoleId = id,
            RoleCode = code,
            RoleName = code,
            IsActive = true
        };

    private static User User(int id, int roleId, string email) =>
        new()
        {
            UserId = id,
            Email = email,
            NormalizedEmail = email.ToUpperInvariant(),
            PasswordHash = "not-used",
            FirstName = "Phase",
            LastName = $"User{id}",
            RoleId = roleId,
            Status = ProductStatuses.Active
        };

    private static void AssertPermission<TController>(
        string methodName,
        string expected)
    {
        var attributes = typeof(TController).GetMethod(methodName)!
            .GetCustomAttributes(true)
            .OfType<HasPermissionAttribute>()
            .Select(attribute => attribute.Policy)
            .Concat(typeof(TController).GetCustomAttributes(true)
                .OfType<HasPermissionAttribute>()
                .Select(attribute => attribute.Policy))
            .ToArray();
        Assert.Contains(HasPermissionAttribute.PolicyPrefix + expected, attributes);
    }

    private sealed class NoopAuditService : IAuditService
    {
        public Task RecordAsync(
            AuditEvent auditEvent,
            CancellationToken cancellationToken = default) => Task.CompletedTask;
    }

    private sealed class CountingCommandInterceptor : DbCommandInterceptor
    {
        private int _readerCommands;

        public int ReaderCommands => _readerCommands;

        public void Reset() => _readerCommands = 0;

        public override InterceptionResult<DbDataReader> ReaderExecuting(
            DbCommand command,
            CommandEventData eventData,
            InterceptionResult<DbDataReader> result)
        {
            Interlocked.Increment(ref _readerCommands);
            return result;
        }

        public override ValueTask<InterceptionResult<DbDataReader>>
            ReaderExecutingAsync(
                DbCommand command,
                CommandEventData eventData,
                InterceptionResult<DbDataReader> result,
                CancellationToken cancellationToken = default)
        {
            Interlocked.Increment(ref _readerCommands);
            return ValueTask.FromResult(result);
        }
    }
}
