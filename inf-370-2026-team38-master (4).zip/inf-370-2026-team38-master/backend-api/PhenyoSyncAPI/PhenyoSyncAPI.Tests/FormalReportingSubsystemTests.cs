using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Reports;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services.Reports;
using QuestPDF.Infrastructure;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Proves filtered totals, permission-sensitive fields and preview-token PDF consistency.
public sealed class FormalReportingSubsystemTests
{
    [Fact]
    public void CatalogContainsEveryReportPermissionExactlyOnce()
    {
        var reportPermissions = Permissions.Catalog
            .Where(item => item.Code.StartsWith(
                "Reports.",
                StringComparison.Ordinal))
            .Select(item => item.Code)
            .ToArray();

        Assert.Equal(20, reportPermissions.Length);
        Assert.Equal(20, reportPermissions.Distinct().Count());
        Assert.Contains(Permissions.Reports.View, reportPermissions);
        Assert.Contains(Permissions.Reports.FinancialViewCost, reportPermissions);
        Assert.Contains(Permissions.Reports.MarkupExportPdf, reportPermissions);
    }

    [Fact]
    public void RoleMatrixRestrictsSensitiveReportsToIntendedRoles()
    {
        Assert.Contains(
            Permissions.Reports.FinancialViewCost,
            SecurityRoleMatrix.Assignments[RoleCodes.OperationsManager]);
        Assert.Contains(
            Permissions.Reports.StockMovementViewCost,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
        Assert.DoesNotContain(
            Permissions.Reports.FinancialView,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.DoesNotContain(
            Permissions.Reports.View,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
    }

    [Fact]
    public void QuantityWeightedAverageUsesQuantityAsItsWeight()
    {
        var average = ReportStatistics.QuantityWeightedAverage(
        [
            (1m, 10m),
            (3m, 20m)
        ]);

        Assert.Equal(17.5m, average);
        Assert.Null(ReportStatistics.QuantityWeightedAverage(
        [
            (0m, 10m)
        ]));
    }

    [Fact]
    public void AnnualAverageExcludesMonthsWithoutObservations()
    {
        decimal?[] months =
        [
            10m,
            null,
            30m,
            null
        ];

        Assert.Equal(20m, ReportStatistics.AnnualAverage(months));
        Assert.Null(ReportStatistics.AnnualAverage(
            Enumerable.Repeat<decimal?>(null, 12)));
    }

    [Fact]
    public void DistributionUsesInterpolatedQuartilesAndIqrOutliers()
    {
        var distribution = ReportStatistics.Distribution(
            new[] { 1m, 2m, 3m, 4m, 100m });

        Assert.True(distribution.IsReliable);
        Assert.Equal(2m, distribution.Q1);
        Assert.Equal(3m, distribution.Median);
        Assert.Equal(4m, distribution.Q3);
        Assert.Equal(2m, distribution.Iqr);
        Assert.Equal(new[] { 100m }, distribution.Outliers);
    }

    [Fact]
    public void DistributionRequiresAtLeastFiveObservations()
    {
        var distribution = ReportStatistics.Distribution(
            new[] { 10m, 12m, 14m, 16m });

        Assert.False(distribution.IsReliable);
        Assert.Empty(distribution.Outliers);
        Assert.Contains(
            "Not enough",
            distribution.Message,
            StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void ReportingModelContainsJustifiedCompositeIndexes()
    {
        using var context = Context();

        AssertIndex(
            context,
            typeof(SalesOrder),
            "IX_SalesOrders_ReportDateCustomerStatus");
        AssertIndex(
            context,
            typeof(StockMovement),
            "IX_StockMovements_ReportDateTypeProduct");
        AssertIndex(
            context,
            typeof(RawStockMovement),
            "IX_RawStockMovements_ReportDateTypeItem");
        AssertIndex(
            context,
            typeof(FinancialPayment),
            "IX_FinancialPayments_ReportDateCounterpartyStatus");
        AssertIndex(
            context,
            typeof(StockWriteOff),
            "IX_StockWriteOffs_ReportCompletedStatus");
    }

    [Fact]
    public void UnknownCostsRemainNullableInDomainAndReportModels()
    {
        using var context = Context();

        Assert.True(context.Model.FindEntityType(typeof(RawStockBalance))!
            .FindProperty(nameof(RawStockBalance.WeightedAverageUnitCost))!
            .IsNullable);
        Assert.True(context.Model.FindEntityType(typeof(RawStockMovement))!
            .FindProperty(nameof(RawStockMovement.UnitCost))!
            .IsNullable);
        Assert.True(context.Model.FindEntityType(typeof(StockWriteOff))!
            .FindProperty(nameof(StockWriteOff.EstimatedTotalLoss))!
            .IsNullable);

        var row = new MarkupReportRowDto(
            "PRD-UNKNOWN",
            "Product awaiting cost",
            "Produce",
            10,
            25,
            null,
            "N/A",
            null,
            null,
            null,
            "Cost unavailable");

        Assert.Null(row.AverageCost);
        Assert.Null(row.MarkupPercentage);
        Assert.Null(row.GrossMarginPercentage);
    }

    [Fact]
    public void CatalogContainsValidatedReportingSettings()
    {
        var required = new[]
        {
            SystemSettingKeys.ReportsDefaultPageSize,
            SystemSettingKeys.ReportsMaximumPageSize,
            SystemSettingKeys.ReportsPreviewLifetimeMinutes,
            SystemSettingKeys.ReportsMaximumDateRangeDays,
            SystemSettingKeys.ReportsMarkupAllowPriorReceiptCostFallback,
            SystemSettingKeys.ReportsPricingMinimumBoxPlotObservations
        };
        var actual = PhaseA2Catalog.Settings.Select(item => item.Key).ToArray();

        foreach (var key in required)
        {
            Assert.Contains(key, actual);
        }

        var boxPlotSetting = PhaseA2Catalog.GetSetting(
            SystemSettingKeys.ReportsPricingMinimumBoxPlotObservations);
        Assert.True(PhaseA2Catalog.TryNormalizeValue(
            boxPlotSetting,
            "5",
            out var normalized,
            out _));
        Assert.Equal("5", normalized);
    }

    [Fact]
    public async Task StockMovementOptionsExposeProductionConversionTrace()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();

        var reportOptions = await new FormalReportService(context)
            .GetOptionsAsync(default);

        Assert.Contains(
            reportOptions.MovementTypes,
            option => option.Code == RawStockMovementTypes.ProductionConversion);
    }

    [Fact]
    public void PdfGeneratorProducesStructuredPdfBytes()
    {
        QuestPDF.Settings.License = LicenseType.Community;
        var service = new ReportPdfService(new HostEnvironment());
        var report = new InventoryReportDto
        {
            Metadata = new ReportMetadataDto
            {
                ReportKey = "inventory",
                Title = "Inventory Position Report",
                Classification = "Simple list report",
                GeneratedAtUtc = new DateTime(
                    2026,
                    8,
                    2,
                    12,
                    0,
                    0,
                    DateTimeKind.Utc),
                GeneratedBy = "Operations Manager (Operations Manager)",
                Criteria =
                [
                    new ReportCriterionDto("Stock status", "All")
                ],
                RecordCount = 1
            },
            Rows =
            [
                new InventoryReportRowDto(
                    "CARROT-1KG",
                    "Premium Carrots",
                    "Fresh Produce",
                    "Root Vegetables",
                    "Cold Room",
                    85m,
                    15m,
                    100m,
                    20m,
                    new DateTime(2026, 8, 15, 0, 0, 0, DateTimeKind.Utc),
                    "Available")
            ],
            TotalRecords = 1,
            TotalAvailableQuantityKg = 85m,
            TotalReservedQuantityKg = 15m
        };

        var result = service.Generate(report);

        Assert.True(result.Content.Length > 1_000);
        Assert.Equal("%PDF", System.Text.Encoding.ASCII.GetString(
            result.Content,
            0,
            4));
        Assert.EndsWith(".pdf", result.FileName);
    }

    [Fact]
    public void PricingPdfSupportsLongProductsAndConsistentCurrencyColumns()
    {
        QuestPDF.Settings.License = LicenseType.Community;
        var distribution = new PriceDistributionDto(
            10m, 11m, 12m, 13m, 14m, 4m, [], 6, true, "Reliable");
        var report = new PricingReportDto
        {
            Metadata = new ReportMetadataDto
            {
                ReportKey = "pricing",
                Title = "Product Pricing Analysis",
                Classification = "Management graph report",
                GeneratedAtUtc = new DateTime(2026, 9, 25, 9, 0, 0, DateTimeKind.Utc),
                GeneratedBy = "Super Admin",
                Criteria = [new ReportCriterionDto("View", "Monthly")],
                RecordCount = 1
            },
            ViewMode = "monthly",
            Observations =
            [
                new PricingObservationDto(
                    new DateTime(2026, 9, 1, 0, 0, 0, DateTimeKind.Utc),
                    1,
                    "Extra Long Premium Organic Seasonal Vegetable Product Name 10 kg Family Pack",
                    "SO-2026-0001",
                    "INV-2026-0001",
                    "Customer",
                    20m,
                    62.50m,
                    1250m,
                    "Delivered")
            ],
            MonthlySummaries =
            [
                new MonthlyPricingSummaryDto(
                    1,
                    "Extra Long Premium Organic Seasonal Vegetable Product Name 10 kg Family Pack",
                    20m,
                    6,
                    10m,
                    14m,
                    12m,
                    12.50m,
                    13m,
                    -0.50m,
                    distribution)
            ],
            AnnualSummaries =
            [
                new AnnualPricingSummaryDto(
                    1,
                    "Extra Long Premium Organic Seasonal Vegetable Product Name 10 kg Family Pack",
                    Enumerable.Repeat<decimal?>(12.50m, 12).ToArray(),
                    12,
                    0,
                    12.50m,
                    distribution)
            ],
            Charts = []
        };

        var result = new ReportPdfService(new HostEnvironment()).Generate(report);

        Assert.True(result.Content.Length > 1_000);
        Assert.Equal("%PDF", System.Text.Encoding.ASCII.GetString(result.Content, 0, 4));
        Assert.Contains("product-pricing-analysis", result.FileName);
    }

    [Fact]
    public async Task PricingReportUsesPersistedSellableUnitSnapshotInsteadOfZeroLegacyPrice()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite(connection)
            .Options;
        await using var context = new PhenyoSyncDbContext(options);
        await context.Database.EnsureCreatedAsync();
        var role = new Role { RoleCode = "Admin", RoleName = "Admin" };
        var user = new User
        {
            Email = "reporter@example.test",
            NormalizedEmail = "REPORTER@EXAMPLE.TEST",
            PasswordHash = "not-a-real-password",
            FirstName = "Report",
            LastName = "Reviewer",
            Role = role
        };
        var category = new ProductCategory
        {
            ProductCategoryName = "Prepared produce",
            CreatedAt = DateTime.UtcNow
        };
        var type = new ProductType
        {
            ProductTypeName = "Prepared pack",
            CreatedAt = DateTime.UtcNow
        };
        var product = new Product
        {
            ProductName = "Cabbage Halves",
            ProductCategory = category,
            ProductType = type,
            Size = "Half",
            ShelfLifeDays = 5,
            SellingUnit = "unit",
            IsVariableWeight = false,
            CreatedAt = DateTime.UtcNow
        };
        product.ProductPrices.Add(new ProductPrice
        {
            SellingPrice = 25m,
            PriceBasis = ProductPriceBases.PerSellableUnit,
            EffectiveFromUtc = DateTime.UtcNow.AddDays(-1),
            IsCurrent = true,
            CreatedAtUtc = DateTime.UtcNow.AddDays(-1)
        });
        var customer = new Customer
        {
            CustomerNumber = "CUS-REPORT",
            CustomerName = "Report Customer",
            Email = "customer@example.test",
            NormalizedEmail = "CUSTOMER@EXAMPLE.TEST",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var order = new SalesOrder
        {
            OrderNumber = "SO-REPORT-001",
            Customer = customer,
            OrderDateUtc = DateTime.UtcNow,
            DeliveryAddressSnapshot = "Test address",
            BillingAddressSnapshot = "Test address",
            Status = SalesOrderStatuses.Approved,
            ValidationStatus = OrderValidationStatuses.Approved,
            CreatedAtUtc = DateTime.UtcNow,
            Items =
            [
                new SalesOrderItem
                {
                    Product = product,
                    ProductNameSnapshot = product.ProductName,
                    ProductSizeSnapshot = product.Size,
                    QuantityKg = 0m,
                    QuantityUnits = 10m,
                    SellingUnitSnapshot = "unit",
                    UnitPricePerKg = 0m,
                    UnitPrice = 25m,
                    PriceBasisSnapshot = ProductPriceBases.PerSellableUnit,
                    LineTotal = 250m
                }
            ]
        };
        context.AddRange(user, order);
        await context.SaveChangesAsync();

        var report = await new FormalReportService(context).PricingAsync(
            new PricingReportCriteriaDto
            {
                ViewMode = "monthly",
                Year = DateTime.UtcNow.Year,
                Month = DateTime.UtcNow.Month
            },
            user.UserId,
            default);

        var observation = Assert.Single(report.Observations);
        Assert.Equal(10m, observation.QuantitySoldKg);
        Assert.Equal(25m, observation.StoredUnitPrice);
        Assert.Equal(250m, observation.LineTotal);
        Assert.Equal(25m, Assert.Single(report.MonthlySummaries).QuantityWeightedMonthlyAverage);
    }

    private static PhenyoSyncDbContext Context()
    {
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite("Data Source=:memory:")
            .Options;
        return new PhenyoSyncDbContext(options);
    }

    private static void AssertIndex(
        PhenyoSyncDbContext context,
        Type entityType,
        string databaseName)
    {
        var entity = context.Model.FindEntityType(entityType);
        Assert.NotNull(entity);
        Assert.Contains(
            entity!.GetIndexes(),
            index => index.GetDatabaseName() == databaseName);
    }

    private sealed class HostEnvironment : IWebHostEnvironment
    {
        public string ApplicationName { get; set; } = "PhenyoSyncAPI.Tests";
        public IFileProvider WebRootFileProvider { get; set; } =
            new NullFileProvider();
        public string WebRootPath { get; set; } = string.Empty;
        public string EnvironmentName { get; set; } = "Test";
        public string ContentRootPath { get; set; } = Path.GetTempPath();
        public IFileProvider ContentRootFileProvider { get; set; } =
            new NullFileProvider();
    }
}
