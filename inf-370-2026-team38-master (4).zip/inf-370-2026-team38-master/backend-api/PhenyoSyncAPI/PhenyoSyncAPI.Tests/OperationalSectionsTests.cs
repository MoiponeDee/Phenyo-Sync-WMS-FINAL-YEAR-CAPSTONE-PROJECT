using System.Reflection;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Operational;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Exercises raw stock, stock takes, write-offs, parties, supplier orders and payment controls.
public sealed class OperationalSectionsTests
{
    [Fact]
    public void PermissionCatalogContainsOperationalSectionsWithoutDuplicates()
    {
        var codes = Permissions.Catalog.Select(item => item.Code).ToArray();
        var required = new[]
        {
            Permissions.RawStock.View,
            Permissions.RawStock.Receive,
            Permissions.RawStockTakes.Capture,
            Permissions.RawStockTakes.Approve,
            Permissions.CustomerPayments.Capture,
            Permissions.SupplierPayments.Reverse,
            Permissions.Reconciliation.Manage,
            Permissions.ManagementDashboard.View
        };

        Assert.All(required, permission => Assert.Contains(permission, codes));
        Assert.Equal(
            codes.Length,
            codes.Distinct(StringComparer.OrdinalIgnoreCase).Count());
    }

    [Fact]
    public void OperationalPermissionsFollowTheRevisedResponsibilitySplit()
    {
        var operations = SecurityRoleMatrix.Assignments[RoleCodes.OperationsManager];
        Assert.Contains(Permissions.CustomerPayments.Capture, operations);
        Assert.Contains(Permissions.SupplierPayments.Capture, operations);
        Assert.Contains(Permissions.Reconciliation.View, operations);
        Assert.DoesNotContain(Permissions.RawStock.Receive, operations);
        Assert.DoesNotContain(Permissions.Reconciliation.Manage, operations);
        Assert.Contains(Permissions.RawStockTakes.View, operations);
        Assert.Contains(Permissions.RawStockTakes.Approve, operations);
        Assert.DoesNotContain(Permissions.RawStockTakes.Capture, operations);
        Assert.DoesNotContain(Permissions.RawStockTakes.Review, operations);
        Assert.DoesNotContain(Permissions.RawStock.View, operations);
        Assert.Contains(Permissions.CustomerPayments.ApproveReversal, operations);
        Assert.Contains(Permissions.SupplierPayments.ApproveReversal, operations);

        var warehouse = SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager];
        Assert.Contains(Permissions.RawStock.Receive, warehouse);
        Assert.Contains(Permissions.RawStockTakes.Capture, warehouse);
        Assert.Contains(Permissions.RawStockTakes.View, warehouse);
        Assert.Contains(Permissions.RawStockTakes.Review, warehouse);
        Assert.DoesNotContain(Permissions.RawStockTakes.Approve, warehouse);
        Assert.Contains(Permissions.Reconciliation.Manage, warehouse);
        Assert.DoesNotContain(Permissions.RawStock.ApproveWriteOff, warehouse);
        Assert.DoesNotContain(Permissions.CustomerPayments.Capture, warehouse);

        Assert.Contains(
            Permissions.RawStock.ApproveWriteOff,
            operations);

        Assert.Contains(
            Permissions.SupplierOrders.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.Contains(
            Permissions.CustomerPayments.Capture,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.DoesNotContain(
            Permissions.SupplierOrders.Manage,
            warehouse);
        Assert.DoesNotContain(
            Permissions.RawStockTakes.View,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.DoesNotContain(
            Permissions.CustomerPayments.ApproveReversal,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
    }

    [Fact]
    public void RuntimeCatalogContainsApprovalAndPaymentControls()
    {
        var keys = PhaseA2Catalog.Settings.Select(item => item.Key).ToArray();
        var required = new[]
        {
            "RawStockTake.RequireApprovalAboveKg",
            "RawStockTake.RequireApprovalAbovePercentage",
            "RawStockTake.RequireApprovalAboveValue",
            "Payments.AdminVoidSameDayMaximumValue",
            "Payments.RequireManagementApprovalAfterHours",
            "RawStock.WriteOffRequireApprovalAboveValue",
            "RawStock.WriteOffEvidenceAboveValue"
        };

        Assert.All(required, key => Assert.Contains(key, keys));
    }

    [Fact]
    public void ModelKeepsRawStockSeparateAndTraceable()
    {
        using var context = Context();
        var rawItem = context.Model.FindEntityType(typeof(RawStockItem));
        var balance = context.Model.FindEntityType(typeof(RawStockBalance));
        var movement = context.Model.FindEntityType(typeof(RawStockMovement));
        var payment = context.Model.FindEntityType(typeof(FinancialPayment));

        Assert.NotNull(rawItem);
        Assert.NotNull(balance);
        Assert.NotNull(movement);
        Assert.NotNull(payment);
        Assert.Contains(
            rawItem!.GetIndexes(),
            index => index.IsUnique &&
                     index.Properties.Single().Name ==
                     nameof(RawStockItem.ItemCode));
        Assert.Contains(
            balance!.GetIndexes(),
            index => index.IsUnique &&
                     index.Properties.Select(property => property.Name)
                         .SequenceEqual(new[]
                         {
                             nameof(RawStockBalance.RawStockItemId),
                             nameof(RawStockBalance.WarehouseSectionId),
                             nameof(RawStockBalance.UnitOfMeasure)
                         }));
        Assert.DoesNotContain(
            rawItem.GetForeignKeys(),
            key => key.PrincipalEntityType.ClrType == typeof(Product));
        Assert.Contains(
            movement!.GetProperties(),
            property => property.Name == nameof(RawStockMovement.CorrelationId));
    }

    [Fact]
    public async Task CreatingRawStockBuildsOpeningBatchBalanceAndMovement()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new RawStockService(database.Context, new NoopAudit());

        var id = await service.CreateAsync(
            RawStockRequest("CARROT-RAW", 12, 4.50m),
            database.UserId,
            CancellationToken.None);

        var item = await database.Context.RawStockItems.SingleAsync();
        var balance = await database.Context.RawStockBalances.SingleAsync();
        var batch = await database.Context.RawStockBatches.SingleAsync();
        var movement = await database.Context.RawStockMovements.SingleAsync();

        Assert.Equal(id, item.RawStockItemId);
        Assert.Equal(12m, balance.QuantityOnHand);
        Assert.Equal(12m, batch.QuantityRemaining);
        Assert.Equal(RawStockMovementTypes.OpeningBalance, movement.MovementType);
        Assert.Equal(balance.RawStockBalanceId, movement.RawStockBalanceId);
        Assert.False(string.IsNullOrWhiteSpace(movement.CorrelationId));
    }

    [Fact]
    public async Task CreatingEmptyRawStockKeepsCostUnknown()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new RawStockService(database.Context, new NoopAudit());
        var request = RawStockRequest("UNKNOWN-COST", 0, 1m);
        request.InitialUnitCost = null;

        await service.CreateAsync(
            request,
            database.UserId,
            CancellationToken.None);

        var balance = await database.Context.RawStockBalances.SingleAsync();
        Assert.Equal(0m, balance.QuantityOnHand);
        Assert.Null(balance.WeightedAverageUnitCost);
        Assert.Empty(await database.Context.RawStockBatches.ToListAsync());
        Assert.Empty(await database.Context.RawStockMovements.ToListAsync());
    }

    [Fact]
    public async Task RawStockSearch_OnlyOffersHardDeleteForUnusedItemsWithoutHistory()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new RawStockService(database.Context, new NoopAudit());
        await service.CreateAsync(
            RawStockRequest("UNUSED-ITEM", 0, null),
            database.UserId,
            CancellationToken.None);
        await service.CreateAsync(
            RawStockRequest("HISTORIC-ITEM", 2, 3m),
            database.UserId,
            CancellationToken.None);

        var result = await service.SearchAsync(
            new RawStockSearchRequest { PageSize = 20 },
            CancellationToken.None);

        Assert.True(result.Items.Single(item => item.ItemCode == "UNUSED-ITEM").CanDelete);
        var historic = result.Items.Single(item => item.ItemCode == "HISTORIC-ITEM");
        Assert.False(historic.CanDelete);
        Assert.True(historic.CanDeactivate);
    }

    [Fact]
    public async Task CreatingOpeningStockRequiresPositiveCost()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new RawStockService(database.Context, new NoopAudit());
        var request = RawStockRequest("MISSING-COST", 10, 1m);
        request.InitialUnitCost = null;

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.CreateAsync(
                request,
                database.UserId,
                CancellationToken.None));

        Assert.Equal(400, exception.StatusCode);
        Assert.Empty(await database.Context.RawStockItems.ToListAsync());
    }

    [Fact]
    public async Task ReceiptRejectsMissingCostBeforeWriting()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new RawStockService(database.Context, new NoopAudit());
        var rawStockItemId = await service.CreateAsync(
            RawStockRequest("NO-RECEIPT-COST", 10, 2m),
            database.UserId,
            CancellationToken.None);
        var request = await ReceiptRequest(database, rawStockItemId, 0);

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.ReceiveAsync(
                request,
                database.UserId,
                CancellationToken.None));

        Assert.Equal(400, exception.StatusCode);
        Assert.Single(await database.Context.RawStockMovements.ToListAsync());
        Assert.Empty(await database.Context.RawStockReceipts.ToListAsync());
    }

    [Fact]
    public async Task WeightedAverageDoesNotTreatUnknownOpeningCostAsZero()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new RawStockService(database.Context, new NoopAudit());
        var request = RawStockRequest("UNKNOWN-WEIGHTED", 0, null);
        var rawStockItemId = await service.CreateAsync(
            request,
            database.UserId,
            CancellationToken.None);
        var balance = await database.Context.RawStockBalances.SingleAsync();
        balance.QuantityOnHand = 10;
        await database.Context.SaveChangesAsync();

        await service.ReceiveAsync(
            await ReceiptRequest(database, rawStockItemId, 4m),
            database.UserId,
            CancellationToken.None);

        Assert.Null(balance.WeightedAverageUnitCost);
        Assert.Equal(18m, balance.QuantityOnHand);
    }

    [Fact]
    public async Task ReceiptReconcilesQuantitiesAndIsIdempotent()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new RawStockService(database.Context, new NoopAudit());
        var rawStockItemId = await service.CreateAsync(
            RawStockRequest("ONION-RAW", 10, 2m),
            database.UserId,
            CancellationToken.None);
        var operationId = Guid.NewGuid().ToString("N");
        var request = await ReceiptRequest(database, rawStockItemId, 4m);
        request.OperationId = operationId;
        request.Lines[0].QuantityReceived = 10;
        request.Lines[0].AcceptedQuantity = 8;
        request.Lines[0].RejectedQuantity = 2;

        var first = await service.ReceiveAsync(
            request,
            database.UserId,
            CancellationToken.None);
        var second = await service.ReceiveAsync(
            request,
            database.UserId,
            CancellationToken.None);

        var balance = await database.Context.RawStockBalances.SingleAsync();
        Assert.Equal(first.RawStockReceiptId, second.RawStockReceiptId);
        Assert.Equal(18m, balance.QuantityOnHand);
        Assert.Equal(2, await database.Context.RawStockMovements.CountAsync());
        Assert.Single(await database.Context.RawStockReceipts.ToListAsync());
    }

    [Fact]
    public async Task ReceiptRejectsUnreconciledLineBeforeWriting()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new RawStockService(database.Context, new NoopAudit());
        var rawStockItemId = await service.CreateAsync(
            RawStockRequest("BAD-RECEIPT", 0, null),
            database.UserId,
            CancellationToken.None);
        var request = await ReceiptRequest(database, rawStockItemId, 1m);
        request.Lines[0].QuantityReceived = 10;
        request.Lines[0].AcceptedQuantity = 8;
        request.Lines[0].RejectedQuantity = 1;

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.ReceiveAsync(
                request,
                database.UserId,
                CancellationToken.None));

        Assert.Equal(400, exception.StatusCode);
        Assert.Empty(await database.Context.RawStockReceipts.ToListAsync());
    }

    [Fact]
    public async Task ReceiptRejectsAdHocSourceBeforeWriting()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new RawStockService(database.Context, new NoopAudit());

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.ReceiveAsync(
                new CreateRawStockReceiptRequest
                {
                    SourceType = RawStockReceiptSources.AdHocSupplier,
                    WarehouseSectionId = database.WarehouseSectionId,
                    DocketReference = "UNCONTROLLED",
                    OperationId = Guid.NewGuid().ToString("N")
                },
                database.UserId,
                CancellationToken.None));

        Assert.Equal(400, exception.StatusCode);
        Assert.Contains("Supplier Order or submitted Buying List", exception.Message);
        Assert.Empty(await database.Context.RawStockReceipts.ToListAsync());
    }

    [Fact]
    public void CustomerDirectoryAndMutationsDeclareSeparatePermissions()
    {
        var controllerPermission = typeof(OperationalCustomersController)
            .GetCustomAttributes(typeof(HasPermissionAttribute), true)
            .Cast<HasPermissionAttribute>()
            .Single();
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.Customers.View,
            controllerPermission.Policy);

        foreach (var methodName in new[] { "Create", "Update" })
        {
            var methodPermission = typeof(OperationalCustomersController)
                .GetMethod(methodName)!
                .GetCustomAttributes(typeof(HasPermissionAttribute), true)
                .Cast<HasPermissionAttribute>()
                .Single();
            Assert.Equal(
                HasPermissionAttribute.PolicyPrefix + Permissions.Customers.Manage,
                methodPermission.Policy);
        }
    }

    [Fact]
    public async Task RawStockWriteOffSubmitterCannotApproveTheirOwnRequest()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var rawStock = new RawStockService(database.Context, new NoopAudit());
        var itemId = await rawStock.CreateAsync(
            RawStockRequest("SPINACH-RAW", 20, 6m),
            database.UserId,
            CancellationToken.None);
        var balance = await database.Context.RawStockBalances.SingleAsync(
            item => item.RawStockItemId == itemId);
        var reason = new OperationalReason
        {
            ReasonCode = "SPOILED",
            ReasonName = "Spoiled",
            CategoryCode = "WriteOff",
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        database.Context.OperationalReasons.Add(reason);
        await database.Context.SaveChangesAsync();
        var writeOff = new RawStockWriteOff
        {
            RawStockItemId = itemId,
            RawStockBalanceId = balance.RawStockBalanceId,
            OperationalReasonId = reason.OperationalReasonId,
            SubmittedByUserId = database.UserId,
            Quantity = 2,
            EstimatedUnitCost = 6,
            EstimatedTotalLoss = 12,
            Status = WriteOffStatuses.PendingApproval,
            SubmittedAtUtc = DateTime.UtcNow,
            CorrelationId = Guid.NewGuid().ToString("N")
        };
        database.Context.RawStockWriteOffs.Add(writeOff);
        await database.Context.SaveChangesAsync();
        var service = new RawStockControlService(
            database.Context,
            new NoopAudit(),
            null!);

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.DecideWriteOffAsync(
                writeOff.RawStockWriteOffId,
                new RawStockWriteOffDecisionRequest
                {
                    Approved = true,
                    Reason = "Approved after inspection.",
                    RowVersion = string.Empty
                },
                database.UserId,
                CancellationToken.None));

        Assert.Equal(409, exception.StatusCode);
        Assert.Contains("different authorised Operations Manager", exception.Message);
    }

    [Theory]
    [InlineData(1, 2, 1)]
    [InlineData(2, 1, 1)]
    public async Task RawStockTakeCreatorOrReviewerCannotApproveTheirOwnSession(
        int creatorUserId,
        int reviewerUserId,
        int decisionUserId)
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var session = new RawStockTakeSession
        {
            WarehouseSectionId = database.WarehouseSectionId,
            CreatedByUserId = creatorUserId,
            ReviewedByUserId = reviewerUserId,
            PeriodStartUtc = DateTime.UtcNow.AddDays(-1),
            PeriodEndUtc = DateTime.UtcNow,
            CreatedAtUtc = DateTime.UtcNow,
            SubmittedAtUtc = DateTime.UtcNow,
            ReviewedAtUtc = DateTime.UtcNow,
            Status = RawStockTakeStatuses.PendingManagementApproval,
            ManagementApprovalRequired = true,
            CorrelationId = Guid.NewGuid().ToString("N")
        };
        database.Context.RawStockTakeSessions.Add(session);
        await database.Context.SaveChangesAsync();
        var service = new RawStockControlService(
            database.Context,
            new NoopAudit(),
            null!);

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.DecideStockTakeAsync(
                session.RawStockTakeSessionId,
                new RawStockTakeDecisionRequest
                {
                    Approved = true,
                    Reason = "Approved after review.",
                    RowVersion = string.Empty
                },
                decisionUserId,
                CancellationToken.None));

        Assert.Equal(409, exception.StatusCode);
        Assert.Contains("different authorised Operations Manager", exception.Message);
        Assert.Null(session.DecidedByUserId);
    }

    [Fact]
    public async Task SupplierOrderCreatesMultipleLinesAndTrustedTotal()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        database.Context.RawStockItems.AddRange(
            new RawStockItem
            {
                ItemCode = "CARROT-RAW",
                ItemName = "Carrots",
                CategoryCode = RawStockCategories.Produce,
                DefaultUnitOfMeasure = RawStockUnits.Kilogram,
                IsProduce = true,
                IsActive = true,
                CreatedAtUtc = DateTime.UtcNow
            },
            new RawStockItem
            {
                ItemCode = "POTATO-RAW",
                ItemName = "Potatoes",
                CategoryCode = RawStockCategories.Produce,
                DefaultUnitOfMeasure = RawStockUnits.Kilogram,
                IsProduce = true,
                IsActive = true,
                CreatedAtUtc = DateTime.UtcNow
            });
        await database.Context.SaveChangesAsync();
        var rawStockIds = await database.Context.RawStockItems
            .OrderBy(item => item.RawStockItemId)
            .Select(item => item.RawStockItemId)
            .ToListAsync();
        var service = new OperationalPartyService(
            database.Context,
            new NoopAudit());

        var result = await service.CreateSupplierOrderAsync(
            new CreateSupplierOrderRequest
            {
                SupplierId = database.SupplierId,
                WarehouseSectionId = database.WarehouseSectionId,
                Lines =
                [
                    new SupplierOrderLineRequest
                    {
                        RawStockItemId = rawStockIds[0],
                        OrderedQuantity = 10,
                        ExpectedUnitPrice = 8.50m,
                        UnitOfMeasure = RawStockUnits.Kilogram
                    },
                    new SupplierOrderLineRequest
                    {
                        RawStockItemId = rawStockIds[1],
                        OrderedQuantity = 20,
                        ExpectedUnitPrice = 5.25m,
                        UnitOfMeasure = RawStockUnits.Kilogram
                    }
                ]
            },
            database.UserId,
            CancellationToken.None);

        Assert.Equal(2, result.Lines.Count);
        Assert.Equal(190m, result.TotalAmount);
        Assert.Equal(
            SupplierOrderStatuses.Draft,
            result.Status);
        Assert.Equal(
            2,
            await database.Context.SupplierOrderLines.CountAsync());
    }

    [Fact]
    public async Task CustomerEmailIsNormalizedAndCaseInsensitiveDuplicateIsRejected()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new OperationalPartyService(
            database.Context,
            new NoopAudit());
        var request = new SaveCustomerRequest
        {
            CustomerName = "Fresh Foods",
            Email = " Accounts@FreshFoods.Example ",
            BillingAddress = "12 Market Street",
            DeliveryAddress = "34 Warehouse Road",
            Status = CustomerStatuses.Active
        };

        var created = await service.SaveCustomerAsync(
            null,
            request,
            database.UserId,
            CancellationToken.None);

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.SaveCustomerAsync(
                null,
                new SaveCustomerRequest
                {
                    CustomerName = "Duplicate",
                    Email = "accounts@freshfoods.example",
                    Status = CustomerStatuses.Active
                },
                database.UserId,
                CancellationToken.None));

        Assert.Equal("accounts@freshfoods.example", created.Email);
        Assert.Equal("12 Market Street", created.BillingAddress);
        Assert.Equal("34 Warehouse Road", created.DeliveryAddress);

        var loaded = await service.CustomerAsync(
            created.CustomerId,
            CancellationToken.None);
        Assert.Equal(created.BillingAddress, loaded.BillingAddress);
        Assert.Equal(created.DeliveryAddress, loaded.DeliveryAddress);
        Assert.Equal(409, exception.StatusCode);
        Assert.Single(await database.Context.Customers.ToListAsync());
    }

    [Fact]
    public async Task CustomerDirectoryExcludesInactiveCustomersUnlessRequested()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var service = new OperationalPartyService(
            database.Context,
            new NoopAudit());

        await service.SaveCustomerAsync(
            null,
            new SaveCustomerRequest
            {
                CustomerName = "Active Customer",
                Email = "active.customer@example.com",
                Status = CustomerStatuses.Active
            },
            database.UserId,
            CancellationToken.None);

        await service.SaveCustomerAsync(
            null,
            new SaveCustomerRequest
            {
                CustomerName = "Inactive Customer",
                Email = "inactive.customer@example.com",
                Status = CustomerStatuses.Inactive
            },
            database.UserId,
            CancellationToken.None);

        var activeCustomers = await service.CustomersAsync(
            null,
            false,
            CancellationToken.None);
        var allCustomers = await service.CustomersAsync(
            null,
            true,
            CancellationToken.None);

        Assert.Single(activeCustomers);
        Assert.Equal("Active Customer", activeCustomers[0].CustomerName);
        Assert.Equal(2, allCustomers.Count);
    }

    [Fact]
    public async Task PaymentReversalUsesLinkedNegativeAdjustmentAndSeparateApproval()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var customer = new Customer
        {
            CustomerNumber = "CUS-000001",
            CustomerName = "Payment Test Customer",
            Email = "accounts@payment-test.example",
            NormalizedEmail = "ACCOUNTS@PAYMENT-TEST.EXAMPLE",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var order = new SalesOrder
        {
            OrderNumber = "ORD-PAY-001",
            Customer = customer,
            OrderDateUtc = DateTime.UtcNow,
            DeliveryAddressSnapshot = "1 Delivery Road",
            BillingAddressSnapshot = "1 Billing Road",
            Status = SalesOrderStatuses.Confirmed,
            ValidationStatus = OrderValidationStatuses.Approved,
            Subtotal = 100m,
            TotalAmount = 100m,
            CreatedByUserId = database.UserId,
            CreatedAtUtc = DateTime.UtcNow
        };
        var invoice = new Invoice
        {
            InvoiceNumber = "INV-PAY-001",
            SalesOrder = order,
            IssuedAtUtc = DateTime.UtcNow,
            CustomerNameSnapshot = customer.CustomerName,
            CustomerEmailSnapshot = customer.Email,
            BillingAddressSnapshot = order.BillingAddressSnapshot,
            Subtotal = 100m,
            TotalAmount = 100m,
            Status = InvoiceStatuses.Issued
        };
        database.Context.Invoices.Add(invoice);
        await database.Context.SaveChangesAsync();
        var service = new OperationalPartyService(
            database.Context,
            new NoopAudit());

        var captured = await service.CapturePaymentAsync(
            new PaymentRequest
            {
                CustomerId = customer.CustomerId,
                SalesOrderId = order.SalesOrderId,
                InvoiceId = invoice.InvoiceId,
                Amount = 100m,
                PaymentDateUtc = DateTime.UtcNow,
                PaymentMethodCode = "EFT"
            },
            database.UserId,
            CancellationToken.None);

        var adjustment = await service.RequestReversalAsync(
            captured.FinancialPaymentId,
            new PaymentDecisionRequest
            {
                Reason = "Duplicate customer receipt.",
                RowVersion = captured.RowVersion
            },
            database.UserId,
            CancellationToken.None);

        var duplicate = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.RequestReversalAsync(
                captured.FinancialPaymentId,
                new PaymentDecisionRequest
                {
                    Reason = "A retry must not create another reversal.",
                    RowVersion = captured.RowVersion
                },
                database.UserId,
                CancellationToken.None));

        Assert.Equal(captured.FinancialPaymentId, adjustment.OriginalPaymentId);
        Assert.Equal(409, duplicate.StatusCode);
        Assert.Equal(
            1,
            await database.Context.FinancialPayments.CountAsync(
                item => item.OriginalPaymentId == captured.FinancialPaymentId));
        Assert.Equal(-100m, adjustment.Amount);
        Assert.Equal(
            FinancialPaymentStatuses.PendingReversalApproval,
            adjustment.Status);
        Assert.Equal(
            FinancialPaymentStatuses.Posted,
            (await database.Context.FinancialPayments.FindAsync(
                captured.FinancialPaymentId))!.Status);

        var pendingFilteredReversal = Assert.Single(await service.PaymentsAsync(
            new PaymentSearchRequest { Search = adjustment.PaymentNumber },
            CancellationToken.None));
        Assert.Equal(0m, pendingFilteredReversal.OutstandingBeforePosting);
        Assert.Equal(0m, pendingFilteredReversal.OutstandingAfterPosting);

        var selfApproval = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.DecideReversalAsync(
                adjustment.FinancialPaymentId,
                true,
                new PaymentDecisionRequest
                {
                    Reason = "Attempted self approval.",
                    RowVersion = adjustment.RowVersion
                },
                database.UserId,
                CancellationToken.None));
        Assert.Equal(409, selfApproval.StatusCode);

        var approved = await service.DecideReversalAsync(
            adjustment.FinancialPaymentId,
            true,
            new PaymentDecisionRequest
            {
                Reason = "Verified against the bank statement.",
                RowVersion = adjustment.RowVersion
            },
            database.ApproverUserId,
            CancellationToken.None);

        Assert.Equal(FinancialPaymentStatuses.Posted, approved.Status);
        Assert.Equal(100m, approved.OutstandingAfterPosting);
        var effectiveAmounts = await database.Context.FinancialPayments
                .Where(item =>
                    item.InvoiceId == invoice.InvoiceId &&
                    item.Status == FinancialPaymentStatuses.Posted)
                .Select(item => item.Amount)
                .ToListAsync();
        Assert.Equal(0m, effectiveAmounts.Sum());

        var filteredReversal = Assert.Single(await service.PaymentsAsync(
            new PaymentSearchRequest { Search = adjustment.PaymentNumber },
            CancellationToken.None));
        Assert.Equal(0m, filteredReversal.OutstandingBeforePosting);
        Assert.Equal(100m, filteredReversal.OutstandingAfterPosting);
    }

    [Fact]
    public async Task PaymentReversalDecisionRequiresMatchingCounterpartyPermission()
    {
        var payment = new PaymentDto
        {
            FinancialPaymentId = 41,
            PaymentNumber = "SUP-PAY-0041",
            CounterpartyType = "Supplier",
            CounterpartyName = "Permission Test Supplier",
            Amount = -125m,
            PaymentMethodCode = "EFT",
            Status = FinancialPaymentStatuses.PendingReversalApproval,
            CreatedByUserId = 7,
            PaymentDateUtc = DateTime.UtcNow,
            RowVersion = "permission-test-version"
        };
        var decisionCalled = false;
        var service = InterfaceProxy<IOperationalPartyService>.Create(
            (method, _) => method.Name switch
            {
                nameof(IOperationalPartyService.PaymentAsync) =>
                    Task.FromResult(payment),
                nameof(IOperationalPartyService.DecideReversalAsync) =>
                    DecideAsync(),
                _ => throw new NotSupportedException(method.Name)
            });
        var permissions = InterfaceProxy<IPermissionService>.Create(
            (method, arguments) => method.Name switch
            {
                nameof(IPermissionService.HasPermissionAsync) => Task.FromResult(
                    (string)arguments![1]! ==
                    Permissions.CustomerPayments.ApproveReversal),
                _ => throw new NotSupportedException(method.Name)
            });
        var controller = new FinancialPaymentsController(service, permissions)
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(
                        new ClaimsIdentity(
                            [new Claim(ClaimTypes.NameIdentifier, "13")],
                            "Test"))
                }
            }
        };

        var error = await Assert.ThrowsAsync<PhaseCException>(() =>
            controller.DecideReversal(
                payment.FinancialPaymentId,
                true,
                new PaymentDecisionRequest
                {
                    Reason = "Attempted cross-counterparty approval.",
                    RowVersion = payment.RowVersion
                },
                CancellationToken.None));

        Assert.Equal(StatusCodes.Status403Forbidden, error.StatusCode);
        Assert.False(decisionCalled);

        Task<PaymentDto> DecideAsync()
        {
            decisionCalled = true;
            return Task.FromResult(payment);
        }
    }

    [Fact]
    public async Task SupplierOrderOptionsExposeOnlyActivePurchasingItemsThroughManagePermission()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var rawStock = new RawStockService(database.Context, new NoopAudit());
        var activeId = await rawStock.CreateAsync(
            RawStockRequest("PURCHASE-ACTIVE", 5, 2m),
            database.UserId,
            CancellationToken.None);
        var inactiveId = await rawStock.CreateAsync(
            RawStockRequest("PURCHASE-INACTIVE", 5, 2m),
            database.UserId,
            CancellationToken.None);
        (await database.Context.RawStockItems.FindAsync(inactiveId))!.IsActive = false;
        await database.Context.SaveChangesAsync();

        var service = new OperationalPartyService(database.Context, new NoopAudit());
        var options = await service.SupplierOrderRawStockOptionsAsync(
            CancellationToken.None);

        var option = Assert.Single(options);
        Assert.Equal(activeId, option.RawStockItemId);
        Assert.Equal("PURCHASE-ACTIVE", option.ItemCode);
        Assert.Equal("kg", option.UnitOfMeasure);

        var permission = Assert.Single(
            typeof(SupplierOrdersController)
                .GetMethod(nameof(SupplierOrdersController.RawStockOptions))!
                .GetCustomAttributes(typeof(HasPermissionAttribute), true)
                .Cast<HasPermissionAttribute>()).Policy;
        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.SupplierOrders.Manage,
            permission);
    }

    [Fact]
    public async Task PaymentSearchUsesServerSideReferenceCounterpartyAndStatusFilters()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var customer = new Customer
        {
            CustomerNumber = "CUS-FILTER-001",
            CustomerName = "Filtered Foods",
            Email = "payments@filtered.example.invalid",
            NormalizedEmail = "PAYMENTS@FILTERED.EXAMPLE.INVALID",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var order = new SalesOrder
        {
            OrderNumber = "ORD-FILTER-001",
            Customer = customer,
            OrderDateUtc = DateTime.UtcNow,
            DeliveryAddressSnapshot = "1 Filter Road",
            BillingAddressSnapshot = "1 Filter Road",
            Status = SalesOrderStatuses.Confirmed,
            ValidationStatus = OrderValidationStatuses.Approved,
            Subtotal = 42m,
            TotalAmount = 42m,
            CreatedByUserId = database.UserId,
            CreatedAtUtc = DateTime.UtcNow
        };
        var invoice = new Invoice
        {
            InvoiceNumber = "INV-FILTER-001",
            SalesOrder = order,
            IssuedAtUtc = DateTime.UtcNow,
            CustomerNameSnapshot = customer.CustomerName,
            CustomerEmailSnapshot = customer.Email,
            BillingAddressSnapshot = order.BillingAddressSnapshot,
            Subtotal = 42m,
            TotalAmount = 42m,
            Status = InvoiceStatuses.Issued
        };
        database.Context.Invoices.Add(invoice);
        await database.Context.SaveChangesAsync();
        var service = new OperationalPartyService(
            database.Context,
            new NoopAudit());
        var captured = await service.CapturePaymentAsync(
            new PaymentRequest
            {
                CustomerId = customer.CustomerId,
                SalesOrderId = order.SalesOrderId,
                InvoiceId = invoice.InvoiceId,
                Amount = 42m,
                PaymentDateUtc = DateTime.UtcNow.AddHours(-1),
                PaymentMethodCode = "EFT",
                Reference = "BANK-TRACE-90210"
            },
            database.UserId,
            CancellationToken.None);

        var byReference = await service.PaymentsAsync(
            new PaymentSearchRequest
            {
                Search = "TRACE-90210",
                Status = FinancialPaymentStatuses.Posted,
                PaymentMethodCode = "EFT",
                FromUtc = DateTime.UtcNow.AddDays(-1),
                ToUtc = DateTime.UtcNow
            },
            CancellationToken.None);
        var byCustomerNumber = await service.PaymentsAsync(
            new PaymentSearchRequest { Search = "CUS-FILTER-001" },
            CancellationToken.None);

        Assert.Equal(captured.FinancialPaymentId, Assert.Single(byReference).FinancialPaymentId);
        Assert.Equal("BANK-TRACE-90210", byReference[0].Reference);
        Assert.Equal("CUS-FILTER-001", Assert.Single(byCustomerNumber).CounterpartyNumber);
    }

    [Fact]
    public async Task StockTakeReconstructsHistoricalBalanceFromLedgerWithoutFinishedStockSubstitution()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var rawStock = new RawStockService(database.Context, new NoopAudit());
        var itemId = await rawStock.CreateAsync(
            RawStockRequest("HISTORIC-CARROT", 100, 3m),
            database.UserId,
            CancellationToken.None);
        var balance = await database.Context.RawStockBalances.SingleAsync(
            item => item.RawStockItemId == itemId);
        var opening = await database.Context.RawStockMovements.SingleAsync();
        var now = DateTime.UtcNow;
        var start = now.AddDays(-10);
        var end = now.AddDays(-2);
        opening.OccurredAtUtc = start.AddDays(-1);
        database.Context.RawStockMovements.AddRange(
            Movement(RawStockMovementTypes.Receipt, 50, start.AddDays(2)),
            Movement(RawStockMovementTypes.ProductionConversion, -30, start.AddDays(4)),
            Movement(RawStockMovementTypes.WriteOff, -10, end.AddDays(1)));
        balance.QuantityOnHand = 110;
        await database.Context.SaveChangesAsync();
        var service = new RawStockControlService(
            database.Context,
            new NoopAudit(),
            null!);

        var take = await service.CreateStockTakeAsync(
            new CreateRawStockTakeRequest
            {
                WarehouseSectionId = database.WarehouseSectionId,
                PeriodStartUtc = start,
                PeriodEndUtc = end
            },
            database.UserId,
            CancellationToken.None);

        var line = Assert.Single(take.Lines);
        Assert.Equal(100m, line.OpeningRawStock);
        Assert.Equal(50m, line.RawStockReceived);
        Assert.Equal(30m, line.ExistingPackedProductWeight);
        Assert.Equal(120m, line.EstimatedRawStockRemaining);

        RawStockMovement Movement(string type, decimal quantity, DateTime occurredAt) =>
            new()
            {
                RawStockItemId = itemId,
                RawStockBalanceId = balance.RawStockBalanceId,
                CreatedByUserId = database.UserId,
                MovementType = type,
                QuantityChange = quantity,
                UnitCost = 3m,
                OccurredAtUtc = occurredAt,
                SourceType = "RegressionTest",
                CorrelationId = Guid.NewGuid().ToString("N")
            };
    }

    [Fact]
    public async Task StockTakeRequiresIndependentApprovalAndPostsVarianceExactlyOnce()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var rawStock = new RawStockService(database.Context, new NoopAudit());
        var itemId = await rawStock.CreateAsync(
            RawStockRequest("APPROVAL-CARROT", 10, 4m),
            database.UserId,
            CancellationToken.None);
        var service = new RawStockControlService(
            database.Context,
            new NoopAudit(),
            new FixedSettings());
        var now = DateTime.UtcNow;
        var take = await service.CreateStockTakeAsync(
            new CreateRawStockTakeRequest
            {
                WarehouseSectionId = database.WarehouseSectionId,
                PeriodStartUtc = now.AddHours(-2),
                PeriodEndUtc = now
            },
            database.UserId,
            CancellationToken.None);
        var line = Assert.Single(take.Lines);

        take = await service.SaveCountAsync(
            take.RawStockTakeSessionId,
            line.RawStockTakeLineId,
            new SaveRawStockCountRequest
            {
                PhysicalStockCount = 7,
                RowVersion = line.RowVersion
            },
            database.UserId,
            CancellationToken.None);
        take = await service.SubmitStockTakeAsync(
            take.RawStockTakeSessionId,
            take.RowVersion,
            database.UserId,
            CancellationToken.None);

        Assert.Equal(RawStockTakeStatuses.Submitted, take.Status);
        Assert.True(take.ManagementApprovalRequired);

        take = await service.ReviewStockTakeAsync(
            take.RawStockTakeSessionId,
            new RawStockTakeReviewRequest
            {
                Notes = "Count and discrepancy checked by the warehouse manager.",
                RowVersion = take.RowVersion
            },
            database.UserId,
            CancellationToken.None);

        Assert.Equal(RawStockTakeStatuses.PendingManagementApproval, take.Status);
        Assert.Empty(await database.Context.RawStockMovements.Where(item =>
            item.SourceType == nameof(RawStockTakeSession) &&
            item.SourceId == take.RawStockTakeSessionId.ToString()).ToListAsync());
        Assert.Equal(10m, (await database.Context.RawStockBalances.SingleAsync(
            item => item.RawStockItemId == itemId)).QuantityOnHand);

        take = await service.DecideStockTakeAsync(
            take.RawStockTakeSessionId,
            new RawStockTakeDecisionRequest
            {
                Approved = true,
                Reason = "Independent approval after reviewing the variance.",
                RowVersion = take.RowVersion
            },
            database.ApproverUserId,
            CancellationToken.None);

        Assert.Equal(RawStockTakeStatuses.Closed, take.Status);
        Assert.Equal(7m, (await database.Context.RawStockBalances.SingleAsync(
            item => item.RawStockItemId == itemId)).QuantityOnHand);
        var adjustment = Assert.Single(await database.Context.RawStockMovements
            .Where(item => item.SourceType == nameof(RawStockTakeSession) &&
                           item.SourceId == take.RawStockTakeSessionId.ToString())
            .ToListAsync());
        Assert.Equal(-3m, adjustment.QuantityChange);

        var retry = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.DecideStockTakeAsync(
                take.RawStockTakeSessionId,
                new RawStockTakeDecisionRequest
                {
                    Approved = true,
                    Reason = "Retry must not post twice.",
                    RowVersion = take.RowVersion
                },
                database.ApproverUserId,
                CancellationToken.None));
        Assert.Equal(409, retry.StatusCode);
        Assert.Single(await database.Context.RawStockMovements.Where(item =>
            item.SourceType == nameof(RawStockTakeSession) &&
            item.SourceId == take.RawStockTakeSessionId.ToString()).ToListAsync());
    }

    [Fact]
    public async Task ApprovedZeroVarianceStockTakeClosesWithoutChangingBalanceOrPostingMovement()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var rawStock = new RawStockService(database.Context, new NoopAudit());
        var itemId = await rawStock.CreateAsync(
            RawStockRequest("ZERO-VARIANCE", 12.5m, 4m),
            database.UserId,
            CancellationToken.None);
        var service = new RawStockControlService(
            database.Context,
            new NoopAudit(),
            new FixedSettings());
        var now = DateTime.UtcNow;
        var take = await service.CreateStockTakeAsync(
            new CreateRawStockTakeRequest
            {
                WarehouseSectionId = database.WarehouseSectionId,
                PeriodStartUtc = now.AddHours(-2),
                PeriodEndUtc = now
            },
            database.UserId,
            CancellationToken.None);
        var line = Assert.Single(take.Lines);
        take = await service.SaveCountAsync(
            take.RawStockTakeSessionId,
            line.RawStockTakeLineId,
            new SaveRawStockCountRequest
            {
                PhysicalStockCount = line.EstimatedRawStockRemaining,
                RowVersion = line.RowVersion
            },
            database.UserId,
            CancellationToken.None);
        take = await service.SubmitStockTakeAsync(
            take.RawStockTakeSessionId,
            take.RowVersion,
            database.UserId,
            CancellationToken.None);
        take = await service.ReviewStockTakeAsync(
            take.RawStockTakeSessionId,
            new RawStockTakeReviewRequest
            {
                Notes = "Zero-variance QA review.",
                RowVersion = take.RowVersion
            },
            database.UserId,
            CancellationToken.None);
        take = await service.DecideStockTakeAsync(
            take.RawStockTakeSessionId,
            new RawStockTakeDecisionRequest
            {
                Approved = true,
                Reason = "Independent zero-variance approval.",
                RowVersion = take.RowVersion
            },
            database.ApproverUserId,
            CancellationToken.None);

        Assert.Equal(RawStockTakeStatuses.Closed, take.Status);
        Assert.Equal(12.5m, (await database.Context.RawStockBalances.SingleAsync(
            item => item.RawStockItemId == itemId)).QuantityOnHand);
        Assert.Empty(await database.Context.RawStockMovements.Where(item =>
            item.SourceType == nameof(RawStockTakeSession) &&
            item.SourceId == take.RawStockTakeSessionId.ToString()).ToListAsync());
    }

    [Fact]
    public void WriteOffApprovalEndpointAllowsTheDedicatedApprovalPermission()
    {
        var policy = Assert.Single(
            typeof(RawStockWriteOffsController)
                .GetCustomAttributes(typeof(HasAnyPermissionAttribute), true)
                .Cast<HasAnyPermissionAttribute>()).Policy;

        Assert.Contains(Permissions.RawStock.View, policy);
        Assert.Contains(Permissions.RawStock.ApproveWriteOff, policy);
    }

    [Fact]
    public async Task RejectedStockTakeRetainsAuthoritativeStockAndReason()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var rawStock = new RawStockService(database.Context, new NoopAudit());
        var itemId = await rawStock.CreateAsync(
            RawStockRequest("REJECT-CARROT", 5, 4m),
            database.UserId,
            CancellationToken.None);
        var service = new RawStockControlService(
            database.Context,
            new NoopAudit(),
            new FixedSettings());
        var now = DateTime.UtcNow;
        var take = await service.CreateStockTakeAsync(
            new CreateRawStockTakeRequest
            {
                WarehouseSectionId = database.WarehouseSectionId,
                PeriodStartUtc = now.AddHours(-2),
                PeriodEndUtc = now
            },
            database.UserId,
            CancellationToken.None);
        var line = Assert.Single(take.Lines);
        take = await service.SaveCountAsync(
            take.RawStockTakeSessionId,
            line.RawStockTakeLineId,
            new SaveRawStockCountRequest
            {
                PhysicalStockCount = 3,
                RowVersion = line.RowVersion
            },
            database.UserId,
            CancellationToken.None);
        take = await service.SubmitStockTakeAsync(
            take.RawStockTakeSessionId,
            take.RowVersion,
            database.UserId,
            CancellationToken.None);
        take = await service.ReviewStockTakeAsync(
            take.RawStockTakeSessionId,
            new RawStockTakeReviewRequest
            {
                Notes = "Warehouse review complete.",
                RowVersion = take.RowVersion
            },
            database.UserId,
            CancellationToken.None);
        take = await service.DecideStockTakeAsync(
            take.RawStockTakeSessionId,
            new RawStockTakeDecisionRequest
            {
                Approved = false,
                Reason = "Physical recount is required.",
                RowVersion = take.RowVersion
            },
            database.ApproverUserId,
            CancellationToken.None);

        Assert.Equal(RawStockTakeStatuses.Rejected, take.Status);
        Assert.Equal("Physical recount is required.", take.ManagementDecisionReason);
        Assert.Equal(5m, (await database.Context.RawStockBalances.SingleAsync(
            item => item.RawStockItemId == itemId)).QuantityOnHand);
        Assert.Empty(await database.Context.RawStockMovements.Where(item =>
            item.SourceType == nameof(RawStockTakeSession) &&
            item.SourceId == take.RawStockTakeSessionId.ToString()).ToListAsync());
    }

    [Fact]
    public async Task PaymentCaptureRejectsCrossPartyBusinessDocuments()
    {
        await using var database = await OperationalDatabase.CreateAsync();
        var orderCustomer = new Customer
        {
            CustomerNumber = "CUS-PAY-001",
            CustomerName = "Order Customer",
            Email = "order-customer@example.invalid",
            NormalizedEmail = "ORDER-CUSTOMER@EXAMPLE.INVALID",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var otherCustomer = new Customer
        {
            CustomerNumber = "CUS-PAY-002",
            CustomerName = "Other Customer",
            Email = "other-customer@example.invalid",
            NormalizedEmail = "OTHER-CUSTOMER@EXAMPLE.INVALID",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        var order = new SalesOrder
        {
            OrderNumber = "ORD-CROSS-001",
            Customer = orderCustomer,
            OrderDateUtc = DateTime.UtcNow,
            DeliveryAddressSnapshot = "1 Order Road",
            BillingAddressSnapshot = "1 Billing Road",
            Status = SalesOrderStatuses.Confirmed,
            ValidationStatus = OrderValidationStatuses.Approved,
            Subtotal = 75m,
            TotalAmount = 75m,
            CreatedByUserId = database.UserId,
            CreatedAtUtc = DateTime.UtcNow
        };
        var invoice = new Invoice
        {
            InvoiceNumber = "INV-CROSS-001",
            SalesOrder = order,
            IssuedAtUtc = DateTime.UtcNow,
            CustomerNameSnapshot = orderCustomer.CustomerName,
            CustomerEmailSnapshot = orderCustomer.Email,
            BillingAddressSnapshot = order.BillingAddressSnapshot,
            Subtotal = 75m,
            TotalAmount = 75m,
            Status = InvoiceStatuses.Issued
        };
        var otherSupplier = new Supplier
        {
            SupplierCode = "SUP-CROSS-002",
            SupplierName = "Other Supplier",
            SupplierTypeCode = "PRODUCER",
            Status = "Active",
            CreatedAtUtc = DateTime.UtcNow
        };
        var supplierOrder = new SupplierOrder
        {
            SupplierId = database.SupplierId,
            OrderNumber = "SO-CROSS-001",
            OrderDate = DateTime.UtcNow,
            WarehouseSectionId = database.WarehouseSectionId,
            Status = SupplierOrderStatuses.Ordered,
            TotalAmount = 80m,
            CreatedAtUtc = DateTime.UtcNow
        };
        database.Context.AddRange(
            otherCustomer,
            invoice,
            otherSupplier,
            supplierOrder);
        await database.Context.SaveChangesAsync();
        var service = new OperationalPartyService(
            database.Context,
            new NoopAudit());

        var customerMismatch = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.CapturePaymentAsync(
                new PaymentRequest
                {
                    CustomerId = otherCustomer.CustomerId,
                    SalesOrderId = order.SalesOrderId,
                    InvoiceId = invoice.InvoiceId,
                    Amount = 10m,
                    PaymentDateUtc = DateTime.UtcNow,
                    PaymentMethodCode = "EFT"
                },
                database.UserId,
                CancellationToken.None));

        var supplierMismatch = await Assert.ThrowsAsync<PhaseCException>(() =>
            service.CapturePaymentAsync(
                new PaymentRequest
                {
                    SupplierId = otherSupplier.SupplierId,
                    SupplierOrderId = supplierOrder.SupplierOrderId,
                    Amount = 10m,
                    PaymentDateUtc = DateTime.UtcNow,
                    PaymentMethodCode = "EFT"
                },
                database.UserId,
                CancellationToken.None));

        Assert.Equal(404, customerMismatch.StatusCode);
        Assert.Equal(404, supplierMismatch.StatusCode);
        Assert.Empty(await database.Context.FinancialPayments.ToListAsync());
    }

    private static CreateRawStockRequest RawStockRequest(
        string code,
        decimal quantity,
        decimal? cost) =>
        new()
        {
            ItemCode = code,
            ItemName = code.Replace('-', ' '),
            CategoryCode = RawStockCategories.Produce,
            UnitOfMeasure = RawStockUnits.Kilogram,
            WarehouseSectionId = 1,
            InitialQuantity = quantity,
            InitialUnitCost = cost,
            BestBeforeAtUtc = DateTime.UtcNow.AddDays(10),
            Reason = "Verified test opening balance."
        };

    private static async Task<CreateRawStockReceiptRequest> ReceiptRequest(
        OperationalDatabase database,
        int rawStockItemId,
        decimal unitCost)
    {
        var supplierOrder = new SupplierOrder
        {
            SupplierId = database.SupplierId,
            OrderNumber = $"SO-{Guid.NewGuid():N}"[..20].ToUpperInvariant(),
            OrderDate = DateTime.UtcNow,
            WarehouseSectionId = database.WarehouseSectionId,
            Status = SupplierOrderStatuses.Ordered,
            CreatedAtUtc = DateTime.UtcNow,
            Lines =
            [
                new SupplierOrderLine
                {
                    RawStockItemId = rawStockItemId,
                    OrderedQuantity = 10,
                    ExpectedUnitPrice = unitCost,
                    UnitOfMeasure = RawStockUnits.Kilogram
                }
            ]
        };
        database.Context.SupplierOrders.Add(supplierOrder);
        await database.Context.SaveChangesAsync();

        return new CreateRawStockReceiptRequest
        {
            SourceType = RawStockReceiptSources.SupplierOrder,
            SupplierOrderId = supplierOrder.SupplierOrderId,
            SupplierId = null,
            WarehouseSectionId = database.WarehouseSectionId,
            DocketReference = $"DOCKET-{Guid.NewGuid():N}"[..24],
            ReceivedAtUtc = DateTime.UtcNow,
            OperationId = Guid.NewGuid().ToString("N"),
            Lines =
            [
                new CreateRawStockReceiptLineRequest
                {
                    SupplierOrderLineId = supplierOrder.Lines.Single()
                        .SupplierOrderLineId,
                    RawStockItemId = rawStockItemId,
                    QuantityReceived = 8,
                    AcceptedQuantity = 8,
                    RejectedQuantity = 0,
                    UnitCost = unitCost,
                    UnitOfMeasure = RawStockUnits.Kilogram
                }
            ]
        };
    }

    private static PhenyoSyncDbContext Context()
    {
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite("Data Source=:memory:")
            .Options;
        return new PhenyoSyncDbContext(options);
    }

    private sealed class NoopAudit : IAuditService
    {
        public Task RecordAsync(
            AuditEvent auditEvent,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;
    }

    public class InterfaceProxy<T> : DispatchProxy where T : class
    {
        private Func<MethodInfo, object?[]?, object?> _handler = null!;

        public static T Create(Func<MethodInfo, object?[]?, object?> handler)
        {
            var proxy = Create<T, InterfaceProxy<T>>();
            ((InterfaceProxy<T>)(object)proxy)._handler = handler;
            return proxy;
        }

        protected override object? Invoke(MethodInfo? targetMethod, object?[]? args) =>
            _handler(targetMethod!, args);
    }

    private sealed class FixedSettings : ISystemSettingProvider
    {
        public Task<int> GetIntAsync(string key, CancellationToken cancellationToken = default) =>
            Task.FromResult(1000);

        public Task<decimal> GetDecimalAsync(string key, CancellationToken cancellationToken = default) =>
            Task.FromResult(1000m);

        public Task<bool> GetBooleanAsync(string key, CancellationToken cancellationToken = default) =>
            Task.FromResult(false);

        public Task<string> GetStringAsync(string key, CancellationToken cancellationToken = default) =>
            Task.FromResult(string.Empty);

        public Task<string[]> GetStringArrayAsync(string key, CancellationToken cancellationToken = default) =>
            Task.FromResult(Array.Empty<string>());

        public void Invalidate(string key) { }
        public void InvalidateAll() { }
    }

    private sealed class OperationalDatabase : IAsyncDisposable
    {
        private readonly SqliteConnection _connection;

        private OperationalDatabase(
            SqliteConnection connection,
            PhenyoSyncDbContext context)
        {
            _connection = connection;
            Context = context;
        }

        public PhenyoSyncDbContext Context { get; }
        public int UserId => 1;
        public int ApproverUserId => 2;
        public int SupplierId => 1;
        public int WarehouseSectionId => 1;

        public static async Task<OperationalDatabase> CreateAsync()
        {
            var connection = new SqliteConnection("Data Source=:memory:");
            await connection.OpenAsync();
            var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
                .UseSqlite(connection)
                .Options;
            var context = new PhenyoSyncDbContext(options);
            await context.Database.EnsureCreatedAsync();

            context.Roles.Add(new Role
            {
                RoleId = 1,
                RoleCode = RoleCodes.BusinessManager,
                RoleName = "Business Manager",
                IsActive = true
            });
            context.Users.Add(new User
            {
                UserId = 1,
                Email = "manager@example.invalid",
                NormalizedEmail = "MANAGER@EXAMPLE.INVALID",
                PasswordHash = "not-used",
                FirstName = "Business",
                LastName = "Manager",
                RoleId = 1,
                Status = "Active"
            });
            context.Users.Add(new User
            {
                UserId = 2,
                Email = "approver@example.invalid",
                NormalizedEmail = "APPROVER@EXAMPLE.INVALID",
                PasswordHash = "not-used",
                FirstName = "Second",
                LastName = "Approver",
                RoleId = 1,
                Status = "Active"
            });
            context.WarehouseSections.Add(new WarehouseSection
            {
                SectionId = 1,
                SectionCode = "RAW",
                SectionName = "Raw Stock",
                Status = "Active",
                CreatedAtUtc = DateTime.UtcNow
            });
            context.Suppliers.Add(new Supplier
            {
                SupplierId = 1,
                SupplierCode = "SUP-000001",
                SupplierName = "Test Produce Supplier",
                SupplierTypeCode = "PRODUCER",
                Status = "Active",
                CreatedAtUtc = DateTime.UtcNow
            });
            await context.SaveChangesAsync();
            return new OperationalDatabase(connection, context);
        }

        public async ValueTask DisposeAsync()
        {
            await Context.DisposeAsync();
            await _connection.DisposeAsync();
        }
    }
}
