using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Auth;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Locks profile field restrictions and Super Admin/Admin persisted-role normalization.
public sealed class ProcurementProfileSuperAdminTests
{
    [Fact]
    public void LegacyBusinessManagerNormalizesToCanonicalSuperAdminRole()
    {
        Assert.Equal(RoleCodes.Admin, RoleCodes.Normalize(RoleCodes.BusinessManager));
        Assert.DoesNotContain(RoleCodes.BusinessManager, RoleCodes.SystemRoles);
        Assert.Contains(Permissions.SupplierOrders.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.Contains(Permissions.ProductCategories.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.DoesNotContain(Permissions.ProductCategories.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
        Assert.Contains(Permissions.Orders.Confirm,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.DoesNotContain(Permissions.Orders.Confirm,
            SecurityRoleMatrix.Assignments[RoleCodes.OperationsManager]);
        Assert.DoesNotContain(Permissions.RawStock.View,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
        Assert.Contains(Permissions.Products.Make,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
    }

    [Fact]
    public void SupplierOrderLifecycleAndReceiptLinkAreExplicit()
    {
        Assert.Equal(2, SupplierOrderStatuses.Receivable.Count);
        Assert.Contains(
            SupplierOrderStatuses.Ordered,
            SupplierOrderStatuses.Receivable);
        Assert.Contains(
            SupplierOrderStatuses.PartiallyReceived,
            SupplierOrderStatuses.Receivable);

        using var context = Context();
        var receiptLine = context.Model.FindEntityType(typeof(RawStockReceiptLine));
        Assert.NotNull(receiptLine);
        Assert.Contains(receiptLine!.GetForeignKeys(), foreignKey =>
            foreignKey.PrincipalEntityType.ClrType == typeof(SupplierOrderLine) &&
            foreignKey.Properties.Single().Name ==
                nameof(RawStockReceiptLine.SupplierOrderLineId));
    }

    [Fact]
    public void ProductRawStockRequirementHasUniqueProductMaterialMapping()
    {
        using var context = Context();
        var entity = context.Model.FindEntityType(
            typeof(ProductRawStockRequirement));
        Assert.NotNull(entity);
        Assert.Contains(entity!.GetIndexes(), index =>
            index.IsUnique &&
            index.Properties.Select(item => item.Name).SequenceEqual(
                [nameof(ProductRawStockRequirement.ProductId),
                 nameof(ProductRawStockRequirement.RawStockItemId)]));
    }

    [Fact]
    public void OwnProfileRequestCannotSelfAssignRoleOrPermissions()
    {
        var properties = typeof(UpdateMyProfileRequest)
            .GetProperties()
            .Select(item => item.Name)
            .ToArray();
        Assert.DoesNotContain("RoleId", properties);
        Assert.DoesNotContain("RoleCode", properties);
        Assert.DoesNotContain("Permissions", properties);
        Assert.DoesNotContain("Status", properties);
    }

    [Fact]
    public void OwnProfileRequestAcceptsOnlyPhoneAndConcurrencyVersion()
    {
        var properties = typeof(UpdateMyProfileRequest)
            .GetProperties()
            .Select(item => item.Name)
            .OrderBy(item => item)
            .ToArray();

        Assert.Equal(
            [nameof(UpdateMyProfileRequest.PhoneNumber),
             nameof(UpdateMyProfileRequest.RowVersion)],
            properties);
    }

    [Theory]
    [InlineData(nameof(AuthController.MyProfile))]
    [InlineData(nameof(AuthController.UpdateMyProfile))]
    [InlineData(nameof(AuthController.ChangeMyPassword))]
    public void ProfileEndpointsRequireAuthentication(string methodName)
    {
        var method = typeof(AuthController).GetMethod(methodName);
        Assert.NotNull(method);
        Assert.NotNull(method!.GetCustomAttributes(
            typeof(AuthorizeAttribute), true).SingleOrDefault());
    }

    private static PhenyoSyncDbContext Context()
    {
        var options = new DbContextOptionsBuilder<PhenyoSyncDbContext>()
            .UseSqlite("Data Source=:memory:")
            .Options;
        return new PhenyoSyncDbContext(options);
    }
}
