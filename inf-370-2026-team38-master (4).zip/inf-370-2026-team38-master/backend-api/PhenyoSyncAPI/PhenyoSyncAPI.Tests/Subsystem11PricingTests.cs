using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.DTOs.Pricing;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Proves effective-date overlap, current-price selection and immutable price history.
public sealed class Subsystem11PricingTests
{
    [Fact]
    public async Task CreateFirstPrice_SucceedsAndSynchronizesLegacyProjection()
    {
        await using var db = await PricingTestDatabase.CreateAsync();

        var created = await db.Pricing.CreateAsync(
            new CreateProductPriceDto { ProductId = db.Product.ProductId, SellingPrice = 24.50m },
            db.Manager.UserId,
            default);

        Assert.True(created.IsCurrent);
        Assert.Equal(24.50m, created.SellingPrice);
        Assert.Equal(24.50m, (await db.Context.Products.FindAsync(db.Product.ProductId))!.SellingPricePerKg);
    }

    [Theory]
    [InlineData("0")]
    [InlineData("-1")]
    [InlineData("1.999")]
    public async Task InvalidPrices_AreRejected(string value)
    {
        await using var db = await PricingTestDatabase.CreateAsync();

        var exception = await Assert.ThrowsAsync<PricingException>(() =>
            db.Pricing.CreateAsync(
                new CreateProductPriceDto
                {
                    ProductId = db.Product.ProductId,
                    SellingPrice = decimal.Parse(value)
                },
                db.Manager.UserId,
                default));

        Assert.Equal(400, exception.StatusCode);
    }

    [Fact]
    public async Task InactiveProduct_IsRejectedForCurrentPricing()
    {
        await using var db = await PricingTestDatabase.CreateAsync();
        db.Product.Status = ProductStatuses.Inactive;
        await db.Context.SaveChangesAsync();

        var exception = await Assert.ThrowsAsync<PricingException>(() =>
            db.Pricing.CreateAsync(
                new CreateProductPriceDto { ProductId = db.Product.ProductId, SellingPrice = 12m },
                db.Manager.UserId,
                default));

        Assert.Equal(409, exception.StatusCode);
    }

    [Fact]
    public async Task SecondCurrentPrice_IsRejected()
    {
        await using var db = await PricingTestDatabase.CreateAsync();
        await db.CreatePriceAsync(12m);

        var exception = await Assert.ThrowsAsync<PricingException>(() =>
            db.Pricing.CreateAsync(
                new CreateProductPriceDto { ProductId = db.Product.ProductId, SellingPrice = 13m },
                db.Manager.UserId,
                default));

        Assert.Equal(409, exception.StatusCode);
        Assert.Single(await db.Context.ProductPrices.Where(item => item.IsCurrent).ToListAsync());
    }

    [Fact]
    public async Task Update_AppendsHistoryAndKeepsExactlyOneCurrentPrice()
    {
        await using var db = await PricingTestDatabase.CreateAsync();
        var original = await db.CreatePriceAsync(12m);

        var changed = await db.Pricing.UpdateAsync(
            original.ProductPriceId,
            new UpdateProductPriceDto { SellingPrice = 15m, ChangeReason = "Annual review" },
            db.Manager.UserId,
            default);

        var records = await db.Context.ProductPrices.OrderBy(item => item.ProductPriceId).ToListAsync();
        Assert.Equal(2, records.Count);
        Assert.False(records[0].IsCurrent);
        Assert.NotNull(records[0].EffectiveToUtc);
        Assert.True(records[1].IsCurrent);
        Assert.Equal(12m, changed.PreviousPrice!.SellingPrice);
        Assert.Equal(15m, changed.CurrentPrice.SellingPrice);
    }

    [Fact]
    public async Task SamePriceUpdate_DoesNotCreateHistory()
    {
        await using var db = await PricingTestDatabase.CreateAsync();
        var original = await db.CreatePriceAsync(12m);

        var exception = await Assert.ThrowsAsync<PricingException>(() =>
            db.Pricing.UpdateAsync(
                original.ProductPriceId,
                new UpdateProductPriceDto { SellingPrice = 12m },
                db.Manager.UserId,
                default));

        Assert.Equal(409, exception.StatusCode);
        Assert.Single(await db.Context.ProductPrices.ToListAsync());
    }

    [Fact]
    public async Task Search_DefaultsToCurrentAndHistoryRemainsAvailable()
    {
        await using var db = await PricingTestDatabase.CreateAsync();
        var original = await db.CreatePriceAsync(10m);
        await db.Pricing.UpdateAsync(
            original.ProductPriceId,
            new UpdateProductPriceDto { SellingPrice = 18m },
            db.Manager.UserId,
            default);

        var current = await db.Pricing.SearchAsync(new ProductPriceSearchDto(), false, default);
        var history = await db.Pricing.GetHistoryAsync(db.Product.ProductId, true, default);

        Assert.Single(current.Items);
        Assert.Equal(18m, current.Items[0].SellingPrice);
        Assert.Equal(2, history.Count);
    }

    [Fact]
    public async Task FuturePriceIsScheduledWhileOrdersKeepTheActivePrice()
    {
        await using var db = await PricingTestDatabase.CreateAsync();
        var original = await db.CreatePriceAsync(10m);

        var replacement = await db.Pricing.UpdateAsync(
            original.ProductPriceId,
            new UpdateProductPriceDto
            {
                SellingPrice = 18m,
                EffectiveFromUtc = DateTime.UtcNow.AddDays(2),
                ChangeReason = "Approved future catalogue change"
            },
            db.Manager.UserId,
            default);

        var current = await db.Pricing.SearchAsync(
            new ProductPriceSearchDto(),
            false,
            default);
        var scheduled = await db.Pricing.SearchAsync(
            new ProductPriceSearchDto
            {
                Status = PriceRecordStatuses.Scheduled
            },
            false,
            default);
        var order = await db.Orders.CreateAsync(
            db.OrderRequest(1m),
            db.Manager.UserId,
            null,
            default);

        Assert.Equal(18m, replacement.CurrentPrice.SellingPrice);
        Assert.True(replacement.CurrentPrice.IsScheduled);
        Assert.Single(current.Items);
        Assert.Equal(10m, current.Items[0].SellingPrice);
        Assert.Single(scheduled.Items);
        Assert.Equal(10m, order.Items[0].UnitPricePerKg);
    }

    [Fact]
    public async Task SoftDelete_IsPhysicalRetentionAndCurrentActivePriceIsBlocked()
    {
        await using var db = await PricingTestDatabase.CreateAsync();
        var current = await db.CreatePriceAsync(10m);

        var blocked = await Assert.ThrowsAsync<PricingException>(() =>
            db.Pricing.SoftDeleteAsync(
                current.ProductPriceId,
                new DeleteProductPriceDto { Confirmed = true, Reason = "No longer used" },
                db.Manager.UserId,
                default));
        Assert.Equal(409, blocked.StatusCode);

        var changed = await db.Pricing.UpdateAsync(
            current.ProductPriceId,
            new UpdateProductPriceDto { SellingPrice = 11m },
            db.Manager.UserId,
            default);
        var deleted = await db.Pricing.SoftDeleteAsync(
            changed.PreviousPrice!.ProductPriceId,
            new DeleteProductPriceDto { Confirmed = true, Reason = "Archive correction" },
            db.Manager.UserId,
            default);

        Assert.True(deleted.IsDeleted);
        Assert.Equal(2, await db.Context.ProductPrices.CountAsync());
    }

    [Fact]
    public async Task ExistingOrderSnapshot_DoesNotChangeWhenCurrentPriceChanges()
    {
        await using var db = await PricingTestDatabase.CreateAsync();
        var current = await db.CreatePriceAsync(10m);
        var order = await db.Orders.CreateAsync(db.OrderRequest(2m), db.Manager.UserId, null, default);

        await db.Pricing.UpdateAsync(
            current.ProductPriceId,
            new UpdateProductPriceDto { SellingPrice = 20m },
            db.Manager.UserId,
            default);

        var reloaded = await db.Orders.GetAsync(order.SalesOrderId, default);
        Assert.Equal(10m, reloaded.Items[0].UnitPricePerKg);
        Assert.Equal(20m, reloaded.TotalAmount);
    }

    [Fact]
    public async Task NewOrderRequiresAndUsesCurrentServerPrice()
    {
        await using var db = await PricingTestDatabase.CreateAsync();
        var noPrice = await Assert.ThrowsAsync<OrderManagementException>(() =>
            db.Orders.CreateAsync(db.OrderRequest(1m), db.Manager.UserId, null, default));
        Assert.Equal(409, noPrice.StatusCode);

        var current = await db.CreatePriceAsync(7.25m);
        var order = await db.Orders.CreateAsync(db.OrderRequest(2m), db.Manager.UserId, null, default);
        Assert.Equal(7.25m, order.Items[0].UnitPricePerKg);
        Assert.Equal(current.ProductPriceId, order.Items[0].ProductPriceId);
    }

    [Fact]
    public void PricingEndpoints_DeclarePermissionAuthorization()
    {
        var controller = typeof(PricesController).GetCustomAttribute<AuthorizeAttribute>()!;
        var create = typeof(PricesController).GetMethod(nameof(PricesController.Create))!
            .GetCustomAttribute<AuthorizeAttribute>()!;
        var update = typeof(PricesController).GetMethod(nameof(PricesController.Update))!
            .GetCustomAttribute<AuthorizeAttribute>()!;
        var delete = typeof(PricesController).GetMethod(nameof(PricesController.SoftDelete))!
            .GetCustomAttribute<AuthorizeAttribute>()!;

        Assert.Equal(
            HasPermissionAttribute.PolicyPrefix + Permissions.Pricing.View,
            controller.Policy);
        Assert.Equal(
            HasAnyPermissionAttribute.PolicyPrefix +
            $"{Permissions.Pricing.Create},{Permissions.Pricing.Manage}",
            create.Policy);
        Assert.Equal(create.Policy, update.Policy);
        Assert.Equal(
            HasAnyPermissionAttribute.PolicyPrefix +
            $"{Permissions.Pricing.Cancel},{Permissions.Pricing.Manage}",
            delete.Policy);
        Assert.DoesNotContain(
            Permissions.Pricing.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
    }
}

internal sealed class PricingTestDatabase : IAsyncDisposable
{
    private readonly SqliteConnection _connection;

    public PhenyoSyncDbContext Context { get; }
    public ProductPricingService Pricing { get; }
    public OrderService Orders { get; }
    public Product Product { get; private set; } = null!;
    public Customer Customer { get; private set; } = null!;
    public User Manager { get; private set; } = null!;

    private PricingTestDatabase(
        SqliteConnection connection,
        PhenyoSyncDbContext context,
        ProductPricingService pricing,
        OrderService orders)
    {
        _connection = connection;
        Context = context;
        Pricing = pricing;
        Orders = orders;
    }

    public static async Task<PricingTestDatabase> CreateAsync()
    {
        var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var context = new PhenyoSyncDbContext(
            new DbContextOptionsBuilder<PhenyoSyncDbContext>()
                .UseSqlite(connection)
                .Options);
        await context.Database.EnsureCreatedAsync();
        var pricing = new ProductPricingService(context);
        var options = Microsoft.Extensions.Options.Options.Create(new OrderManagementOptions
        {
            TaxRatePercent = 0,
            DefaultPageSize = 20,
            MaximumPageSize = 100
        });
        var orders = new OrderService(context, options, pricing);
        var db = new PricingTestDatabase(connection, context, pricing, orders);
        await db.SeedAsync();
        return db;
    }

    public Task<ProductPriceResponseDto> CreatePriceAsync(decimal amount)
    {
        return Pricing.CreateAsync(
            new CreateProductPriceDto
            {
                ProductId = Product.ProductId,
                SellingPrice = amount,
                Reason = "Test price"
            },
            Manager.UserId,
            default);
    }

    public CreateSalesOrderDto OrderRequest(decimal quantity) => new()
    {
        CustomerId = Customer.CustomerId,
        DeliveryAddress = "11 Pricing Road",
        BillingAddress = "11 Pricing Road",
        Items =
        [
            new OrderItemRequestDto
            {
                ProductId = Product.ProductId,
                QuantityKg = quantity
            }
        ]
    };

    private async Task SeedAsync()
    {
        var role = new Role
        {
            RoleName = "BusinessManager",
            Users = [],
            RolePermissions = []
        };
        Manager = new User
        {
            Email = "pricing.manager@example.test",
            PasswordHash = "test",
            FirstName = "Pricing",
            LastName = "Manager",
            Role = role,
            Status = "Active",
            Driver = null!,
            StockTakeSessions = []
        };
        Customer = new Customer
        {
            CustomerNumber = "PRICE-0001",
            CustomerName = "Pricing Customer",
            Email = "pricing.customer@example.test",
            BillingAddress = "11 Pricing Road",
            DeliveryAddress = "11 Pricing Road",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        Product = new Product
        {
            ProductName = "Pricing Product",
            ProductType = new ProductType
            {
                ProductTypeName = "Fresh",
                Status = ProductStatuses.Active,
                CreatedAt = DateTime.UtcNow
            },
            ProductCategory = new ProductCategory
            {
                ProductCategoryName = "Fruit",
                Status = ProductStatuses.Active,
                CreatedAt = DateTime.UtcNow
            },
            Size = "1 KG",
            ShelfLifeDays = 7,
            Status = ProductStatuses.Active,
            CreatedAt = DateTime.UtcNow
        };
        Context.AddRange(Manager, Customer, Product);
        await Context.SaveChangesAsync();
    }

    public async ValueTask DisposeAsync()
    {
        await Context.DisposeAsync();
        await _connection.DisposeAsync();
    }
}
