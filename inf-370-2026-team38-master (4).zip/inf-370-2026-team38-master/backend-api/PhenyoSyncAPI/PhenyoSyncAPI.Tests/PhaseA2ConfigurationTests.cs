using Microsoft.AspNetCore.Authorization;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Controllers;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Proves governed lookup and system-setting validation, history and concurrency behavior.
public sealed class PhaseA2ConfigurationTests
{
    [Fact]
    public void CatalogContainsRequiredOperationalLookupTypes()
    {
        var codes = PhaseA2Catalog.LookupTypes.Select(item => item.Code).ToArray();

        Assert.Contains(LookupCodes.StockMovementReason, codes);
        Assert.Contains(LookupCodes.WriteOffReason, codes);
        Assert.Contains(LookupCodes.OrderCancellationReason, codes);
        Assert.Contains(LookupCodes.DeliveryFailureReason, codes);
        Assert.Contains(LookupCodes.PaymentMethod, codes);
        Assert.Contains(LookupCodes.UnitOfMeasure, codes);
        Assert.Equal(9, codes.Distinct(StringComparer.OrdinalIgnoreCase).Count());
    }

    [Fact]
    public void CatalogContainsAllRequiredRuntimeSettings()
    {
        var keys = PhaseA2Catalog.Settings.Select(item => item.Key).ToArray();

        Assert.Contains(SystemSettingKeys.ExpiryYellowThresholdHours, keys);
        Assert.Contains(SystemSettingKeys.ExpiryRedThresholdHours, keys);
        Assert.Contains(SystemSettingKeys.ExpiryScanIntervalMinutes, keys);
        Assert.Contains(SystemSettingKeys.ExpiryShelfLifeExtensionDays, keys);
        Assert.Contains(SystemSettingKeys.OrdersOrderLinkLifetimeHours, keys);
        Assert.Contains(SystemSettingKeys.OrdersDeliverySafetyHours, keys);
        Assert.Contains(SystemSettingKeys.DeliveryDefaultDurationMinutes, keys);
        Assert.Equal(keys.Length, keys.Distinct(StringComparer.OrdinalIgnoreCase).Count());
    }

    [Theory]
    [InlineData(SystemSettingKeys.ExpiryYellowThresholdHours, "96", "96")]
    [InlineData(SystemSettingKeys.ExpiryScanIntervalMinutes, "15", "15")]
    [InlineData(SystemSettingKeys.OrdersDeliverySafetyHours, "0", "0")]
    public void NumericSettingsNormalizeValidValues(
        string key,
        string supplied,
        string expected)
    {
        var definition = PhaseA2Catalog.GetSetting(key);

        var valid = PhaseA2Catalog.TryNormalizeValue(
            definition,
            supplied,
            out var normalized,
            out var error);

        Assert.True(valid);
        Assert.Null(error);
        Assert.Equal(expected, normalized);
    }

    [Theory]
    [InlineData(SystemSettingKeys.ExpiryYellowThresholdHours, "1")]
    [InlineData(SystemSettingKeys.ExpiryRedThresholdHours, "0")]
    [InlineData(SystemSettingKeys.ExpiryScanIntervalMinutes, "2000")]
    [InlineData(SystemSettingKeys.DeliveryDefaultDurationMinutes, "not-a-number")]
    public void NumericSettingsRejectOutOfRangeOrMalformedValues(
        string key,
        string supplied)
    {
        var definition = PhaseA2Catalog.GetSetting(key);

        Assert.False(PhaseA2Catalog.TryNormalizeValue(
            definition,
            supplied,
            out _,
            out var error));
        Assert.False(string.IsNullOrWhiteSpace(error));
    }

    [Fact]
    public void RecipientRolesAreNormalizedAsUniqueJsonArray()
    {
        var definition = PhaseA2Catalog.GetSetting(
            SystemSettingKeys.ExpiryRecipientRoleCodes);

        var valid = PhaseA2Catalog.TryNormalizeValue(
            definition,
            """["CEO","CEO","StockTaker"]""",
            out var normalized,
            out _);

        Assert.True(valid);
        Assert.Equal("""["CEO","StockTaker"]""", normalized);
    }

    [Fact]
    public void PhaseA2ManagementPermissionsRemainWithConfigurationOwners()
    {
        var administrator = SecurityRoleMatrix.Assignments[RoleCodes.Admin];
        Assert.Contains(Permissions.Lookups.Manage, administrator);
        Assert.DoesNotContain(Permissions.WarehouseSections.Manage, administrator);
        Assert.Contains(Permissions.SystemSettings.Manage, administrator);

        Assert.Contains(
            Permissions.WarehouseSections.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);

        var operations = SecurityRoleMatrix.Assignments[RoleCodes.OperationsManager];
        Assert.Contains(Permissions.SystemSettings.View, operations);
        Assert.DoesNotContain(Permissions.SystemSettings.Manage, operations);

        Assert.DoesNotContain(
            RoleCodes.BusinessManager,
            SecurityRoleMatrix.Assignments.Keys);
    }

    [Fact]
    public void OperationalRolesReceiveOnlyRelevantConfigurationReads()
    {
        Assert.DoesNotContain(
            Permissions.Lookups.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Packer]);
        Assert.Contains(
            Permissions.WarehouseSections.View,
            SecurityRoleMatrix.Assignments[RoleCodes.WarehouseManager]);
        Assert.DoesNotContain(
            Permissions.SystemSettings.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Driver]);
        Assert.Contains(
            Permissions.Lookups.Manage,
            SecurityRoleMatrix.Assignments[RoleCodes.Admin]);
    }

    [Fact]
    public void ConfigurationControllersRequireAuthentication()
    {
        Assert.NotEmpty(typeof(LookupsController)
            .GetCustomAttributes(typeof(AuthorizeAttribute), true));
        Assert.NotEmpty(typeof(SystemSettingsController)
            .GetCustomAttributes(typeof(AuthorizeAttribute), true));
        Assert.NotEmpty(typeof(WarehouseSectionController)
            .GetCustomAttributes(typeof(AuthorizeAttribute), true));
    }

    [Fact]
    public async Task SettingProviderReadsStoredValueAndAppliesInvalidationImmediately()
    {
        await using var connection = new SqliteConnection("Data Source=:memory:");
        await connection.OpenAsync();
        var services = new ServiceCollection();
        services.AddDbContext<PhenyoSyncDbContext>(options =>
            options.UseSqlite(connection));
        await using var provider = services.BuildServiceProvider();
        using (var setupScope = provider.CreateScope())
        {
            var context = setupScope.ServiceProvider
                .GetRequiredService<PhenyoSyncDbContext>();
            await context.Database.EnsureCreatedAsync();
            var setting = await context.SystemSettings.SingleAsync(item =>
                item.Key == SystemSettingKeys.ExpiryYellowThresholdHours);
            setting.Value = "84";
            await context.SaveChangesAsync();
        }

        var settings = new SystemSettingProvider(
            provider.GetRequiredService<IServiceScopeFactory>(),
            NullLogger<SystemSettingProvider>.Instance);

        Assert.Equal(84, await settings.GetIntAsync(
            SystemSettingKeys.ExpiryYellowThresholdHours));

        using (var updateScope = provider.CreateScope())
        {
            var context = updateScope.ServiceProvider
                .GetRequiredService<PhenyoSyncDbContext>();
            var setting = await context.SystemSettings.SingleAsync(item =>
                item.Key == SystemSettingKeys.ExpiryYellowThresholdHours);
            setting.Value = "96";
            await context.SaveChangesAsync();
        }
        settings.Invalidate(SystemSettingKeys.ExpiryYellowThresholdHours);

        Assert.Equal(96, await settings.GetIntAsync(
            SystemSettingKeys.ExpiryYellowThresholdHours));
    }
}
