using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.BuyingLists;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using Xunit;

namespace PhenyoSyncAPI.Tests;

// Proves draft editing, assignment, publication and buyer execution boundaries.
public sealed class BuyingListWorkflowTests
{
    [Fact]
    public async Task ManagementCanCreateAndPublishAnAssignedBuyingList()
    {
        await using var fixture = await BuyingListFixture.CreateAsync();
        var service = fixture.Service;

        var created = await service.CreateAsync(
            ValidCreateRequest(fixture.RawStockItemId, fixture.BuyerUserId),
            fixture.ManagerUserId,
            "buying-list-create-test",
            CancellationToken.None);

        Assert.Equal(BuyingListStatuses.Draft, created.Status);
        Assert.Single(created.Items);
        Assert.StartsWith("BL-", created.ReferenceNumber);

        var published = await service.PublishAsync(
            created.BuyerProcurementId,
            new BuyingListCommandRequest
            {
                Reason = "Ready for the purchasing run.",
                RowVersion = created.RowVersion
            },
            fixture.ManagerUserId,
            "buying-list-publish-test",
            CancellationToken.None);

        Assert.Equal(BuyingListStatuses.Open, published.Status);
        Assert.NotNull(published.PublishedAtUtc);
        Assert.Contains(
            fixture.Audit.Events,
            item => item.OperationName == "Create Buying List");
        Assert.Contains(
            fixture.Audit.Events,
            item => item.OperationName == "Publish Buying List");
        Assert.True(
            await fixture.Context.OperationalNotificationRecipients.AnyAsync(
                item => item.UserId == fixture.BuyerUserId));
    }

    [Fact]
    public async Task DuplicateItemsAreRejectedBeforeTheDraftIsSaved()
    {
        await using var fixture = await BuyingListFixture.CreateAsync();
        var request = ValidCreateRequest(
            fixture.RawStockItemId,
            fixture.BuyerUserId);
        request.Items.Add(new SaveBuyingListLineRequest
        {
            RawStockItemId = fixture.RawStockItemId,
            RecommendedQuantity = 4,
            RequiredQuantity = 5,
            UnitOfMeasure = RawStockUnits.Kilogram,
            Priority = BuyingListPriorities.Standard
        });

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            fixture.Service.CreateAsync(
                request,
                fixture.ManagerUserId,
                "buying-list-duplicate-test",
                CancellationToken.None));

        Assert.Equal(409, exception.StatusCode);
        Assert.Empty(fixture.Context.BuyerProcurements);
    }

    [Fact]
    public async Task RawStockUnitMustMatchTheDatabaseConfiguration()
    {
        await using var fixture = await BuyingListFixture.CreateAsync();
        var request = ValidCreateRequest(
            fixture.RawStockItemId,
            fixture.BuyerUserId);
        request.Items[0].UnitOfMeasure = RawStockUnits.Box;

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            fixture.Service.CreateAsync(
                request,
                fixture.ManagerUserId,
                "buying-list-unit-test",
                CancellationToken.None));

        Assert.Equal(400, exception.StatusCode);
        Assert.Contains("must be", exception.Message);
    }

    [Fact]
    public async Task PublishedBuyingListCannotBeChangedAsADraft()
    {
        await using var fixture = await BuyingListFixture.CreateAsync();
        var created = await fixture.Service.CreateAsync(
            ValidCreateRequest(fixture.RawStockItemId, fixture.BuyerUserId),
            fixture.ManagerUserId,
            "buying-list-lock-create-test",
            CancellationToken.None);
        var published = await fixture.Service.PublishAsync(
            created.BuyerProcurementId,
            new BuyingListCommandRequest
            {
                Reason = "Ready for purchasing.",
                RowVersion = created.RowVersion
            },
            fixture.ManagerUserId,
            "buying-list-lock-publish-test",
            CancellationToken.None);

        var exception = await Assert.ThrowsAsync<PhaseCException>(() =>
            fixture.Service.UpdateHeaderAsync(
                published.BuyerProcurementId,
                new UpdateBuyingListHeaderRequest
                {
                    BuyingDateUtc = published.BuyingDateUtc,
                    Title = "Changed after publication",
                    Priority = published.Priority,
                    RowVersion = published.RowVersion
                },
                fixture.ManagerUserId,
                CancellationToken.None));

        Assert.Equal(409, exception.StatusCode);
    }

    [Fact]
    public void BuyingListModelHasTraceabilityAndConcurrencySafeguards()
    {
        using var context = Context();
        var list = context.Model.FindEntityType(typeof(BuyerProcurement));
        var line = context.Model.FindEntityType(typeof(BuyerProcurementItem));
        var receiptLine = context.Model.FindEntityType(typeof(RawStockReceiptLine));

        Assert.NotNull(list);
        Assert.NotNull(line);
        Assert.NotNull(receiptLine);
        Assert.Contains(
            list!.GetIndexes(),
            index => index.IsUnique &&
                     index.Properties.Single().Name ==
                     nameof(BuyerProcurement.ReferenceNumber));
        Assert.True(
            list.FindProperty(nameof(BuyerProcurement.RowVersion))!
                .IsConcurrencyToken);
        Assert.True(
            line!.FindProperty(nameof(BuyerProcurementItem.RowVersion))!
                .IsConcurrencyToken);
        Assert.Contains(
            receiptLine!.GetForeignKeys(),
            foreignKey => foreignKey.PrincipalEntityType.ClrType ==
                          typeof(BuyerProcurementItem));
    }

    private static CreateBuyingListManagementRequest ValidCreateRequest(
        int rawStockItemId,
        int buyerUserId) =>
        new()
        {
            BuyingDateUtc = DateTime.UtcNow.Date,
            Title = "Fresh produce buying list",
            Priority = BuyingListPriorities.Urgent,
            Notes = "Prioritise the morning market collection.",
            AssignedBuyerUserId = buyerUserId,
            Items =
            [
                new SaveBuyingListLineRequest
                {
                    RawStockItemId = rawStockItemId,
                    RecommendedQuantity = 8,
                    RequiredQuantity = 10,
                    UnitOfMeasure = RawStockUnits.Kilogram,
                    Priority = BuyingListPriorities.Urgent,
                    ManagementNotes = "Select good quality stock."
                }
            ]
        };

    private static PhenyoSyncDbContext Context(SqliteConnection? connection = null)
    {
        var builder = new DbContextOptionsBuilder<PhenyoSyncDbContext>();
        builder.UseSqlite(connection ?? new SqliteConnection("Data Source=:memory:"));
        return new PhenyoSyncDbContext(builder.Options);
    }

    private sealed class RecordingAuditService : IAuditService
    {
        public List<AuditEvent> Events { get; } = [];

        public Task RecordAsync(
            AuditEvent auditEvent,
            CancellationToken cancellationToken = default)
        {
            Events.Add(auditEvent);
            return Task.CompletedTask;
        }
    }

    private sealed class BuyingListFixture : IAsyncDisposable
    {
        private readonly SqliteConnection _connection;

        private BuyingListFixture(
            SqliteConnection connection,
            PhenyoSyncDbContext context,
            RecordingAuditService audit)
        {
            _connection = connection;
            Context = context;
            Audit = audit;
            Service = new BuyingListManagementService(
                context,
                audit,
                new OperationalNotificationService(context));
        }

        public PhenyoSyncDbContext Context { get; }
        public RecordingAuditService Audit { get; }
        public BuyingListManagementService Service { get; }
        public int ManagerUserId { get; private set; }
        public int BuyerUserId { get; private set; }
        public int RawStockItemId { get; private set; }

        public static async Task<BuyingListFixture> CreateAsync()
        {
            var connection = new SqliteConnection("Data Source=:memory:");
            await connection.OpenAsync();
            var context = Context(connection);
            await context.Database.EnsureCreatedAsync();
            var fixture = new BuyingListFixture(
                connection,
                context,
                new RecordingAuditService());
            await fixture.SeedAsync();
            return fixture;
        }

        public async ValueTask DisposeAsync()
        {
            await Context.DisposeAsync();
            await _connection.DisposeAsync();
        }

        private async Task SeedAsync()
        {
            var now = DateTime.UtcNow;
            var managerRole = new Role
            {
                RoleCode = RoleCodes.BusinessManager,
                RoleName = "Business Manager",
                IsActive = true
            };
            var buyerRole = new Role
            {
                RoleCode = RoleCodes.MarketBuyer,
                RoleName = "Market Buyer",
                IsActive = true
            };
            var permission = new Permission
            {
                PermissionCode = Permissions.Mobile.BuyingListView,
                PermissionName = Permissions.Mobile.BuyingListView,
                DisplayName = "View mobile buying lists",
                Module = "Mobile",
                IsActive = true
            };
            buyerRole.RolePermissions.Add(new RolePermission
            {
                Permission = permission,
                AssignedAtUtc = now
            });

            var passwordHash = BCrypt.Net.BCrypt.HashPassword("12345678");
            var manager = new User
            {
                Email = "zafarsuliman+buyingmanager@gmail.com",
                NormalizedEmail =
                    "ZAFARSULIMAN+BUYINGMANAGER@GMAIL.COM",
                PasswordHash = passwordHash,
                FirstName = "Business",
                LastName = "Manager",
                Status = ProductStatuses.Active,
                Role = managerRole
            };
            var buyer = new User
            {
                Email = "zafarsuliman+marketbuyer@gmail.com",
                NormalizedEmail =
                    "ZAFARSULIMAN+MARKETBUYER@GMAIL.COM",
                PasswordHash = passwordHash,
                FirstName = "Market",
                LastName = "Buyer",
                Status = ProductStatuses.Active,
                Role = buyerRole
            };
            var rawStock = new RawStockItem
            {
                ItemCode = "RAW-CARROT",
                ItemName = "Fresh Carrots",
                CategoryCode = RawStockCategories.Produce,
                DefaultUnitOfMeasure = RawStockUnits.Kilogram,
                IsProduce = true,
                IsActive = true,
                CreatedAtUtc = now
            };

            Context.AddRange(manager, buyer, rawStock);
            await Context.SaveChangesAsync();
            ManagerUserId = manager.UserId;
            BuyerUserId = buyer.UserId;
            RawStockItemId = rawStock.RawStockItemId;
        }
    }
}
