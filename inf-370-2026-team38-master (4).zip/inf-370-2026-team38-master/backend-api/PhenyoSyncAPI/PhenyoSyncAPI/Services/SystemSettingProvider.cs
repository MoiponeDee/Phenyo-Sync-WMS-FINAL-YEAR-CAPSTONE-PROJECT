using System.Collections.Concurrent;
using System.Globalization;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;

namespace PhenyoSyncAPI.Services;

public interface ISystemSettingProvider
{
    Task<int> GetIntAsync(string key, CancellationToken cancellationToken = default);
    Task<decimal> GetDecimalAsync(string key, CancellationToken cancellationToken = default);
    Task<bool> GetBooleanAsync(string key, CancellationToken cancellationToken = default);
    Task<string> GetStringAsync(string key, CancellationToken cancellationToken = default);
    Task<string[]> GetStringArrayAsync(string key, CancellationToken cancellationToken = default);
    void Invalidate(string key);
    void InvalidateAll();
}

/// <summary>Reads typed operational settings with bounded defaults and no secret-value logging.</summary>
public sealed class SystemSettingProvider : ISystemSettingProvider
{
    private static readonly TimeSpan CacheLifetime = TimeSpan.FromMinutes(10);
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<SystemSettingProvider> _logger;
    private readonly ConcurrentDictionary<string, CacheEntry> _cache =
        new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, SemaphoreSlim> _locks =
        new(StringComparer.OrdinalIgnoreCase);

    public SystemSettingProvider(
        IServiceScopeFactory scopeFactory,
        ILogger<SystemSettingProvider> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    public async Task<int> GetIntAsync(
        string key,
        CancellationToken cancellationToken = default)
    {
        var value = await GetValueAsync(key, cancellationToken);
        return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed)
            ? parsed
            : int.Parse(PhaseA2Catalog.GetSetting(key).DefaultValue, CultureInfo.InvariantCulture);
    }

    public async Task<decimal> GetDecimalAsync(
        string key,
        CancellationToken cancellationToken = default)
    {
        var value = await GetValueAsync(key, cancellationToken);
        return decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out var parsed)
            ? parsed
            : decimal.Parse(PhaseA2Catalog.GetSetting(key).DefaultValue, CultureInfo.InvariantCulture);
    }

    public async Task<bool> GetBooleanAsync(
        string key,
        CancellationToken cancellationToken = default)
    {
        var value = await GetValueAsync(key, cancellationToken);
        return bool.TryParse(value, out var parsed)
            ? parsed
            : bool.Parse(PhaseA2Catalog.GetSetting(key).DefaultValue);
    }

    public Task<string> GetStringAsync(
        string key,
        CancellationToken cancellationToken = default) =>
        GetValueAsync(key, cancellationToken);

    public async Task<string[]> GetStringArrayAsync(
        string key,
        CancellationToken cancellationToken = default)
    {
        var value = await GetValueAsync(key, cancellationToken);
        try
        {
            return JsonSerializer.Deserialize<string[]>(value) ?? [];
        }
        catch (JsonException)
        {
            return JsonSerializer.Deserialize<string[]>(
                PhaseA2Catalog.GetSetting(key).DefaultValue) ?? [];
        }
    }

    public void Invalidate(string key) => _cache.TryRemove(key, out _);

    public void InvalidateAll() => _cache.Clear();

    private async Task<string> GetValueAsync(
        string key,
        CancellationToken cancellationToken)
    {
        if (!PhaseA2Catalog.TryGetSetting(key, out var definition))
        {
            throw new ArgumentOutOfRangeException(nameof(key), "Unknown system setting.");
        }

        if (_cache.TryGetValue(key, out var cached) &&
            cached.ExpiresAtUtc > DateTime.UtcNow)
        {
            return cached.Value;
        }

        var gate = _locks.GetOrAdd(key, _ => new SemaphoreSlim(1, 1));
        await gate.WaitAsync(cancellationToken);
        try
        {
            if (_cache.TryGetValue(key, out cached) &&
                cached.ExpiresAtUtc > DateTime.UtcNow)
            {
                return cached.Value;
            }

            string value = definition.DefaultValue;
            try
            {
                using var scope = _scopeFactory.CreateScope();
                var context = scope.ServiceProvider.GetRequiredService<PhenyoSyncDbContext>();
                var stored = await context.SystemSettings
                    .AsNoTracking()
                    .Where(item =>
                        item.Key == definition.Key &&
                        item.IsActive &&
                        !item.IsSensitive)
                    .Select(item => item.Value)
                    .SingleOrDefaultAsync(cancellationToken);
                if (stored is not null &&
                    PhaseA2Catalog.TryNormalizeValue(
                        definition,
                        stored,
                        out var normalized,
                        out _))
                {
                    value = normalized;
                }
                else if (stored is not null)
                {
                    _logger.LogWarning(
                        "System setting {SettingKey} was malformed; its safe default is being used.",
                        key);
                }
            }
            catch (Exception exception) when (
                exception is not OperationCanceledException)
            {
                _logger.LogWarning(
                    exception,
                    "System setting {SettingKey} could not be read; its safe default is being used.",
                    key);
            }

            _cache[key] = new CacheEntry(value, DateTime.UtcNow.Add(CacheLifetime));
            return value;
        }
        finally
        {
            gate.Release();
        }
    }

    private sealed record CacheEntry(string Value, DateTime ExpiresAtUtc);
}
