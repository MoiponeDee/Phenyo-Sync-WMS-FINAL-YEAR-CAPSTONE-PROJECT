using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Help;
using PhenyoSyncAPI.Entities;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace PhenyoSyncAPI.Services;

public interface IHelpService
{
    Task<HelpHomeDto> HomeAsync(
        string? role,
        bool authenticated,
        CancellationToken cancellationToken);
    Task<HelpSearchResultDto> SearchAsync(
        HelpSearchQuery query,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken);
    Task<HelpTopicDto> TopicAsync(
        string slug,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken);
    Task<HelpContextResultDto> ResolveContextAsync(
        string route,
        string? componentKey,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken);
    Task<byte[]> PdfAsync(
        string? role,
        bool authenticated,
        string generatedBy,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<HelpCategoryDto>> ManageCategoriesAsync(
        CancellationToken cancellationToken);
    Task<HelpCategoryDto> SaveCategoryAsync(
        int? id,
        SaveHelpCategoryRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<HelpTopicSummaryDto>> ManageTopicsAsync(
        CancellationToken cancellationToken);
    Task<HelpTopicDto> ManageTopicAsync(
        int id,
        CancellationToken cancellationToken);
    Task<HelpTopicDto> SaveTopicAsync(
        int? id,
        SaveHelpTopicRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<HelpContextResultDto> SaveContextAsync(
        int? id,
        SaveHelpContextRequest request,
        int userId,
        CancellationToken cancellationToken);
}

/// <summary>Resolves role- and route-aware help content while preserving management versions.</summary>
public sealed class HelpService : IHelpService
{
    private static readonly Regex HtmlTag = new(
        @"<[^>]+>",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _audit;

    public HelpService(
        PhenyoSyncDbContext context,
        IAuditService audit)
    {
        _context = context;
        _audit = audit;
    }

    public async Task<HelpHomeDto> HomeAsync(
        string? role,
        bool authenticated,
        CancellationToken cancellationToken)
    {
        var topics = await VisibleTopics(role, authenticated)
            .Include(item => item.Category)
            .OrderBy(item => item.Category.SortOrder)
            .ThenBy(item => item.SortOrder)
            .ToListAsync(cancellationToken);
        var categoryIds = topics.Select(item => item.HelpCategoryId).ToHashSet();
        var categoryRows = await _context.HelpCategories
            .AsNoTracking()
            .Where(item => item.IsActive && categoryIds.Contains(item.HelpCategoryId))
            .OrderBy(item => item.SortOrder)
            .ToListAsync(cancellationToken);
        var categories = categoryRows.Select(Category).ToList();
        var recommended = topics
            .Take(8)
            .Select(item => Summary(item))
            .ToList();
        var media = await _context.HelpMedia
            .AsNoTracking()
            .Where(item =>
                item.IsPublished &&
                item.IsFeatured &&
                item.RemovedAtUtc == null)
            .OrderBy(item => item.SortOrder)
            .Select(item => new FeaturedHelpMediaDto(
                item.HelpMediaId,
                item.Title,
                item.Description,
                item.Transcript,
                item.CaptionStoredFileId != null))
            .FirstOrDefaultAsync(cancellationToken);
        return new HelpHomeDto(categories, recommended, media);
    }

    public async Task<HelpSearchResultDto> SearchAsync(
        HelpSearchQuery query,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken)
    {
        var source = VisibleTopics(role, authenticated)
            .Include(item => item.Category)
            .AsQueryable();
        if (query.CategoryId.HasValue)
        {
            source = source.Where(item =>
                item.HelpCategoryId == query.CategoryId.Value);
        }
        var term = query.Query?.Trim();
        if (!string.IsNullOrWhiteSpace(term))
        {
            source = source.Where(item =>
                item.Title.Contains(term) ||
                item.Summary.Contains(term) ||
                (item.Keywords != null && item.Keywords.Contains(term)) ||
                item.BodyContent.Contains(term) ||
                item.Category.DisplayName.Contains(term));
        }
        var total = await source.CountAsync(cancellationToken);
        var rows = await source
            .OrderByDescending(item =>
                term != null && item.Title.StartsWith(term))
            .ThenBy(item => item.Category.SortOrder)
            .ThenBy(item => item.SortOrder)
            .Skip((query.Page - 1) * query.PageSize)
            .Take(query.PageSize)
            .ToListAsync(cancellationToken);
        return new HelpSearchResultDto(
            rows.Select(item => Summary(
                item,
                Snippet(item.BodyContent, term)))
                .ToList(),
            query.Page,
            query.PageSize,
            total,
            (int)Math.Ceiling(total / (double)query.PageSize));
    }

    public async Task<HelpTopicDto> TopicAsync(
        string slug,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken)
    {
        var topic = await VisibleTopics(role, authenticated)
            .Include(item => item.Category)
            .SingleOrDefaultAsync(item => item.Slug == slug, cancellationToken)
            ?? throw new KeyNotFoundException("The Help topic was not found.");
        var siblings = await VisibleTopics(role, authenticated)
            .Include(item => item.Category)
            .Where(item => item.HelpCategoryId == topic.HelpCategoryId)
            .OrderBy(item => item.SortOrder)
            .ToListAsync(cancellationToken);
        var index = siblings.FindIndex(item =>
            item.HelpTopicId == topic.HelpTopicId);
        var related = await VisibleTopics(role, authenticated)
            .Include(item => item.Category)
            .Where(item =>
                item.HelpTopicId != topic.HelpTopicId &&
                item.HelpCategoryId == topic.HelpCategoryId)
            .OrderBy(item => item.SortOrder)
            .Take(4)
            .ToListAsync(cancellationToken);
        return Detail(
            topic,
            index > 0 ? Summary(siblings[index - 1]) : null,
            index >= 0 && index < siblings.Count - 1
                ? Summary(siblings[index + 1])
                : null,
            related.Select(item => Summary(item)).ToList());
    }

    // Route context is normalized server-side so aliases cannot bypass role-targeted help rules.
    public async Task<HelpContextResultDto> ResolveContextAsync(
        string route,
        string? componentKey,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken)
    {
        var topics = await VisibleTopics(role, authenticated)
            .Include(item => item.ContextMappings)
            .ToListAsync(cancellationToken);
        var mapping = topics
            .SelectMany(topic => topic.ContextMappings
                .Where(item => item.IsActive)
                .Select(item => new { Topic = topic, Mapping = item }))
            .Where(item =>
                string.IsNullOrWhiteSpace(componentKey) ||
                string.Equals(
                    item.Mapping.ComponentKey,
                    componentKey,
                    StringComparison.OrdinalIgnoreCase) ||
                RouteMatches(item.Mapping.RoutePattern, route))
            .OrderByDescending(item => item.Mapping.Priority)
            .FirstOrDefault(item =>
                RouteMatches(item.Mapping.RoutePattern, route) ||
                string.Equals(
                    item.Mapping.ComponentKey,
                    componentKey,
                    StringComparison.OrdinalIgnoreCase));
        var selected = mapping?.Topic ??
            topics.FirstOrDefault(item => item.Slug == "getting-started")
            ?? throw new KeyNotFoundException("No Help topic is available.");
        return new HelpContextResultDto(
            selected.Slug,
            selected.Title,
            selected.Summary);
    }

    public async Task<byte[]> PdfAsync(
        string? role,
        bool authenticated,
        string generatedBy,
        CancellationToken cancellationToken)
    {
        var topics = await VisibleTopics(role, authenticated)
            .Include(item => item.Category)
            .OrderBy(item => item.Category.SortOrder)
            .ThenBy(item => item.SortOrder)
            .ToListAsync(cancellationToken);
        var generatedAt = DateTime.UtcNow;
        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(42);
                page.DefaultTextStyle(text => text.FontSize(10));
                page.Header().Column(column =>
                {
                    column.Item().Text("PhenyoSync WMS")
                        .FontSize(20)
                        .Bold()
                        .FontColor("#146c3c");
                    column.Item().Text("User Guide - Version 1.0")
                        .FontSize(11);
                    column.Item().Text(
                        $"Generated {generatedAt:u} by {generatedBy}")
                        .FontSize(8)
                        .FontColor(Colors.Grey.Darken1);
                });
                page.Content().PaddingVertical(18).Column(column =>
                {
                    column.Spacing(10);
                    column.Item().Text("Contents").FontSize(16).Bold();
                    foreach (var group in topics.GroupBy(item => item.Category))
                    {
                        column.Item().Text(group.Key.DisplayName)
                            .FontSize(13)
                            .Bold()
                            .FontColor("#146c3c");
                        foreach (var topic in group)
                        {
                            column.Item().PaddingLeft(12).Text(topic.Title);
                        }
                    }
                    foreach (var group in topics.GroupBy(item => item.Category))
                    {
                        column.Item().PageBreak();
                        column.Item().Text(group.Key.DisplayName)
                            .FontSize(18)
                            .Bold()
                            .FontColor("#146c3c");
                        foreach (var topic in group)
                        {
                            column.Item().PaddingTop(10).Text(topic.Title)
                                .FontSize(14)
                                .Bold();
                            column.Item().Text(topic.Summary)
                                .Italic()
                                .FontColor(Colors.Grey.Darken1);
                            column.Item().Text(PlainText(topic.BodyContent))
                                .LineHeight(1.35f);
                        }
                    }
                });
                page.Footer().AlignCenter().Text(text =>
                {
                    text.Span("PhenyoSync User Guide - ");
                    text.CurrentPageNumber();
                    text.Span(" / ");
                    text.TotalPages();
                });
            });
        });
        var bytes = document.GeneratePdf();
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.GenerateInvoice,
            SystemModule = "Help",
            OperationName = "ExportHelpPdf",
            Description = "A role-appropriate Help user guide PDF was generated.",
            SafeDetails = new Dictionary<string, object?>
            {
                ["TopicCount"] = topics.Count
            }
        }, cancellationToken);
        return bytes;
    }

    public async Task<IReadOnlyList<HelpCategoryDto>> ManageCategoriesAsync(
        CancellationToken cancellationToken)
    {
        var rows = await _context.HelpCategories
            .AsNoTracking()
            .OrderBy(item => item.SortOrder)
            .ThenBy(item => item.DisplayName)
            .ToListAsync(cancellationToken);
        return rows.Select(Category).ToList();
    }

    public async Task<HelpCategoryDto> SaveCategoryAsync(
        int? id,
        SaveHelpCategoryRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var category = id.HasValue
            ? await _context.HelpCategories.SingleOrDefaultAsync(
                item => item.HelpCategoryId == id.Value,
                cancellationToken)
                ?? throw new KeyNotFoundException("The Help category was not found.")
            : new HelpCategory
            {
                CreatedAtUtc = DateTime.UtcNow
            };
        CheckVersion(category.RowVersion, request.RowVersion);
        var code = request.SystemCode.Trim().ToUpperInvariant();
        if (id.HasValue &&
            !string.Equals(
                category.SystemCode,
                code,
                StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                "The Help category system code is immutable.");
        }
        if (await _context.HelpCategories.AnyAsync(
                item =>
                    item.SystemCode == code &&
                    item.HelpCategoryId != category.HelpCategoryId,
                cancellationToken))
        {
            throw new InvalidOperationException(
                "A Help category with that system code already exists.");
        }
        category.SystemCode = code;
        category.DisplayName = request.DisplayName.Trim();
        category.Description = Clean(request.Description, 500);
        category.SortOrder = request.SortOrder;
        category.IsActive = request.IsActive;
        category.UpdatedAtUtc = DateTime.UtcNow;
        if (!id.HasValue)
        {
            _context.HelpCategories.Add(category);
        }
        await _context.SaveChangesAsync(cancellationToken);
        await AuditManageAsync(
            id.HasValue ? AuditActionTypes.Update : AuditActionTypes.Create,
            "SaveHelpCategory",
            nameof(HelpCategory),
            category.HelpCategoryId,
            category.DisplayName,
            userId,
            cancellationToken);
        return Category(category);
    }

    public async Task<IReadOnlyList<HelpTopicSummaryDto>> ManageTopicsAsync(
        CancellationToken cancellationToken)
    {
        var topics = await _context.HelpTopics
            .AsNoTracking()
            .Include(item => item.Category)
            .OrderBy(item => item.Category.SortOrder)
            .ThenBy(item => item.SortOrder)
            .ToListAsync(cancellationToken);
        return topics.Select(item => Summary(item)).ToList();
    }

    public async Task<HelpTopicDto> ManageTopicAsync(
        int id,
        CancellationToken cancellationToken)
    {
        var topic = await _context.HelpTopics
            .AsNoTracking()
            .Include(item => item.Category)
            .SingleOrDefaultAsync(
                item => item.HelpTopicId == id,
                cancellationToken)
            ?? throw new KeyNotFoundException("The Help topic was not found.");
        return Detail(topic, null, null, []);
    }

    // Management saves use RowVersion to prevent editors from replacing a newer help revision.
    public async Task<HelpTopicDto> SaveTopicAsync(
        int? id,
        SaveHelpTopicRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        if (!await _context.HelpCategories.AnyAsync(
                item => item.HelpCategoryId == request.HelpCategoryId,
                cancellationToken))
        {
            throw new InvalidOperationException("Select a valid Help category.");
        }
        var topic = id.HasValue
            ? await _context.HelpTopics
                .Include(item => item.Category)
                .SingleOrDefaultAsync(
                    item => item.HelpTopicId == id.Value,
                    cancellationToken)
                ?? throw new KeyNotFoundException("The Help topic was not found.")
            : new HelpTopic
            {
                CreatedAtUtc = DateTime.UtcNow
            };
        CheckVersion(topic.RowVersion, request.RowVersion);
        var slug = request.Slug.Trim().ToLowerInvariant();
        if (id.HasValue &&
            !string.Equals(
                topic.Slug,
                slug,
                StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                "The Help topic slug is immutable.");
        }
        if (await _context.HelpTopics.AnyAsync(
                item =>
                    item.Slug == slug &&
                    item.HelpTopicId != topic.HelpTopicId,
                cancellationToken))
        {
            throw new InvalidOperationException(
                "A Help topic with that slug already exists.");
        }
        topic.HelpCategoryId = request.HelpCategoryId;
        topic.Slug = slug;
        topic.Title = request.Title.Trim();
        topic.Summary = request.Summary.Trim();
        topic.BodyContent = SafeMarkdown(request.BodyContent);
        topic.Keywords = Clean(request.Keywords, 800);
        topic.AudienceRolesCsv = request.AudienceRoles.Count == 0
            ? null
            : string.Join(
                ',',
                request.AudienceRoles
                    .Select(item => item.Trim())
                    .Where(item => item.Length > 0)
                    .Distinct(StringComparer.OrdinalIgnoreCase));
        topic.IsPublic = request.IsPublic;
        topic.IsPublished = request.IsPublished;
        topic.SortOrder = request.SortOrder;
        topic.UpdatedAtUtc = DateTime.UtcNow;
        topic.UpdatedByUserId = userId;
        if (!id.HasValue)
        {
            _context.HelpTopics.Add(topic);
        }
        await _context.SaveChangesAsync(cancellationToken);
        topic.Category = await _context.HelpCategories.SingleAsync(
            item => item.HelpCategoryId == topic.HelpCategoryId,
            cancellationToken);
        await AuditManageAsync(
            id.HasValue ? AuditActionTypes.Update : AuditActionTypes.Create,
            "SaveHelpTopic",
            nameof(HelpTopic),
            topic.HelpTopicId,
            topic.Title,
            userId,
            cancellationToken);
        return Detail(topic, null, null, []);
    }

    public async Task<HelpContextResultDto> SaveContextAsync(
        int? id,
        SaveHelpContextRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var topic = await _context.HelpTopics.SingleOrDefaultAsync(
            item => item.HelpTopicId == request.HelpTopicId,
            cancellationToken)
            ?? throw new KeyNotFoundException("The Help topic was not found.");
        var mapping = id.HasValue
            ? await _context.HelpContextMappings.SingleOrDefaultAsync(
                item => item.HelpContextMappingId == id.Value,
                cancellationToken)
                ?? throw new KeyNotFoundException("The Help context mapping was not found.")
            : new HelpContextMapping();
        mapping.HelpTopicId = topic.HelpTopicId;
        mapping.RoutePattern = request.RoutePattern.Trim();
        mapping.ComponentKey = Clean(request.ComponentKey, 120);
        mapping.Priority = request.Priority;
        mapping.IsActive = request.IsActive;
        if (!id.HasValue)
        {
            _context.HelpContextMappings.Add(mapping);
        }
        await _context.SaveChangesAsync(cancellationToken);
        await AuditManageAsync(
            id.HasValue ? AuditActionTypes.Update : AuditActionTypes.Create,
            "SaveHelpContextMapping",
            nameof(HelpContextMapping),
            mapping.HelpContextMappingId,
            mapping.RoutePattern,
            userId,
            cancellationToken);
        return new HelpContextResultDto(topic.Slug, topic.Title, topic.Summary);
    }

    private IQueryable<HelpTopic> VisibleTopics(
        string? role,
        bool authenticated)
    {
        var source = _context.HelpTopics
            .AsNoTracking()
            .Where(item =>
                item.IsPublished &&
                item.Category.IsActive);
        if (!authenticated)
        {
            return source.Where(item => item.IsPublic);
        }
        if (string.IsNullOrWhiteSpace(role))
        {
            return source.Where(item => item.IsPublic);
        }
        return source.Where(item =>
            item.IsPublic ||
            item.AudienceRolesCsv == null ||
            ("," + item.AudienceRolesCsv + ",").Contains("," + role + ","));
    }

    private async Task AuditManageAsync(
        string action,
        string operation,
        string entityType,
        int entityId,
        string display,
        int userId,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = "Help",
            OperationName = operation,
            Description = "Help content was managed.",
            EntityType = entityType,
            EntityId = entityId.ToString(),
            EntityDisplay = display,
            UserId = userId
        }, cancellationToken);

    private static HelpCategoryDto Category(HelpCategory item) =>
        new(
            item.HelpCategoryId,
            item.SystemCode,
            item.DisplayName,
            item.Description,
            item.SortOrder,
            item.IsActive,
            Version(item.RowVersion));

    private static HelpTopicSummaryDto Summary(
        HelpTopic item,
        string? snippet = null) =>
        new(
            item.HelpTopicId,
            item.Slug,
            item.Title,
            item.Summary,
            item.Category.DisplayName,
            snippet,
            item.IsPublic,
            item.IsPublished,
            item.SortOrder);

    private static HelpTopicDto Detail(
        HelpTopic item,
        HelpTopicSummaryDto? previous,
        HelpTopicSummaryDto? next,
        IReadOnlyList<HelpTopicSummaryDto> related) =>
        new(
            item.HelpTopicId,
            item.HelpCategoryId,
            item.Category.DisplayName,
            item.Slug,
            item.Title,
            item.Summary,
            item.BodyContent,
            item.Keywords,
            string.IsNullOrWhiteSpace(item.AudienceRolesCsv)
                ? []
                : item.AudienceRolesCsv.Split(
                    ',',
                    StringSplitOptions.RemoveEmptyEntries |
                    StringSplitOptions.TrimEntries),
            item.IsPublic,
            item.IsPublished,
            item.SortOrder,
            Version(item.RowVersion),
            previous,
            next,
            related);

    private static string Snippet(string body, string? term)
    {
        var text = PlainText(body);
        if (string.IsNullOrWhiteSpace(term))
        {
            return text.Length <= 220 ? text : text[..220] + "...";
        }
        var index = text.IndexOf(term, StringComparison.OrdinalIgnoreCase);
        var start = Math.Max(0, index < 0 ? 0 : index - 80);
        var length = Math.Min(240, text.Length - start);
        return text.Substring(start, length) +
            (start + length < text.Length ? "..." : string.Empty);
    }

    private static string SafeMarkdown(string value)
    {
        var clean = HtmlTag.Replace(value, string.Empty)
            .Replace("\0", string.Empty)
            .Trim();
        if (clean.Length < 40)
        {
            throw new InvalidOperationException(
                "Provide substantive Help content of at least 40 characters.");
        }
        return clean;
    }

    private static string PlainText(string value) =>
        value.Replace("#", string.Empty)
            .Replace("**", string.Empty)
            .Replace("__", string.Empty)
            .Trim();

    private static bool RouteMatches(string pattern, string route)
    {
        var cleanRoute = route.Split('?', '#')[0].TrimEnd('/');
        var cleanPattern = pattern.TrimEnd('/');
        var patternSegments = cleanPattern.Split(
            '/',
            StringSplitOptions.RemoveEmptyEntries);
        var routeSegments = cleanRoute.Split(
            '/',
            StringSplitOptions.RemoveEmptyEntries);
        if (patternSegments.Length != routeSegments.Length)
        {
            return false;
        }
        return patternSegments
            .Zip(routeSegments)
            .All(pair =>
                pair.First.StartsWith(':') ||
                string.Equals(
                    pair.First,
                    pair.Second,
                    StringComparison.OrdinalIgnoreCase));
    }

    private static void CheckVersion(byte[]? actual, string? supplied)
    {
        if (actual is null || string.IsNullOrWhiteSpace(supplied))
        {
            return;
        }
        byte[] expected;
        try
        {
            expected = Convert.FromBase64String(supplied);
        }
        catch (FormatException)
        {
            throw new InvalidOperationException("The row version is invalid.");
        }
        if (!actual.SequenceEqual(expected))
        {
            throw new DbUpdateConcurrencyException(
                "The Help content changed. Refresh and try again.");
        }
    }

    private static string Version(byte[]? value) =>
        value is null ? string.Empty : Convert.ToBase64String(value);

    private static string? Clean(string? value, int maximum)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }
        var clean = HtmlTag.Replace(value, string.Empty).Trim();
        return clean.Length <= maximum ? clean : clean[..maximum];
    }
}
