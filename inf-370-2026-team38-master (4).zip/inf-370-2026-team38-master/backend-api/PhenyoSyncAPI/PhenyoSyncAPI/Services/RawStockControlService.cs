using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Operational;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IRawStockControlService
{
    Task<IReadOnlyList<RawStockTakeDto>> ListStockTakesAsync(
        CancellationToken cancellationToken);
    Task<RawStockTakeDto> GetStockTakeAsync(
        long id,
        CancellationToken cancellationToken);
    Task<RawStockTakeDto> CreateStockTakeAsync(
        CreateRawStockTakeRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<RawStockTakeDto> SaveCountAsync(
        long sessionId,
        long lineId,
        SaveRawStockCountRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<RawStockTakeDto> SubmitStockTakeAsync(
        long id,
        string rowVersion,
        int userId,
        CancellationToken cancellationToken);
    Task<RawStockTakeDto> ReviewStockTakeAsync(
        long id,
        RawStockTakeReviewRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<RawStockTakeDto> DecideStockTakeAsync(
        long id,
        RawStockTakeDecisionRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<RawStockWriteOffDto>> ListWriteOffsAsync(
        CancellationToken cancellationToken);
    Task<RawStockWriteOffDto> CreateWriteOffAsync(
        CreateRawStockWriteOffRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<RawStockWriteOffDto> DecideWriteOffAsync(
        long id,
        RawStockWriteOffDecisionRequest request,
        int userId,
        CancellationToken cancellationToken);
}

public sealed class RawStockControlService : IRawStockControlService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _audit;
    private readonly ISystemSettingProvider _settings;

    public RawStockControlService(
        PhenyoSyncDbContext context,
        IAuditService audit,
        ISystemSettingProvider settings)
    {
        _context = context;
        _audit = audit;
        _settings = settings;
    }

    public async Task<IReadOnlyList<RawStockTakeDto>> ListStockTakesAsync(
        CancellationToken cancellationToken)
    {
        var ids = await _context.RawStockTakeSessions.AsNoTracking()
            .OrderByDescending(item => item.CreatedAtUtc)
            .Take(100)
            .Select(item => item.RawStockTakeSessionId)
            .ToListAsync(cancellationToken);
        var result = new List<RawStockTakeDto>();
        foreach (var id in ids)
            result.Add(await GetStockTakeAsync(id, cancellationToken));
        return result;
    }

    public async Task<RawStockTakeDto> GetStockTakeAsync(
        long id,
        CancellationToken cancellationToken)
    {
        var session = await StockTakeQuery()
            .AsNoTracking()
            .SingleOrDefaultAsync(
                item => item.RawStockTakeSessionId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock take not found.");
        return Map(session);
    }

    public async Task<RawStockTakeDto> CreateStockTakeAsync(
        CreateRawStockTakeRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var start = request.PeriodStartUtc.ToUniversalTime();
        var end = request.PeriodEndUtc.ToUniversalTime();
        if (start >= end || end > DateTime.UtcNow.AddMinutes(1))
            throw new PhaseCException(400, "Select a valid historical stock-take period.");
        if (await _context.RawStockTakeSessions.AnyAsync(
                item => item.WarehouseSectionId == request.WarehouseSectionId &&
                        (item.Status == RawStockTakeStatuses.Draft ||
                         item.Status == RawStockTakeStatuses.Submitted ||
                         item.Status == RawStockTakeStatuses.AdministratorReviewed ||
                         item.Status == RawStockTakeStatuses.PendingManagementApproval),
                cancellationToken))
            throw new PhaseCException(
                409,
                "This warehouse section already has an open raw-stock take.");

        var balances = await _context.RawStockBalances
            .Include(item => item.RawStockItem)
            .Where(item => item.WarehouseSectionId == request.WarehouseSectionId &&
                           item.RawStockItem.IsActive)
            .OrderBy(item => item.RawStockItem.ItemName)
            .ToListAsync(cancellationToken);
        if (balances.Count == 0)
            throw new PhaseCException(400, "This warehouse section has no active raw stock.");

        var movements = await _context.RawStockMovements.AsNoTracking()
            .Where(item => item.RawStockBalance.WarehouseSectionId ==
                           request.WarehouseSectionId &&
                           item.OccurredAtUtc >= start)
            .ToListAsync(cancellationToken);
        var mappings = await _context.RawStockReconciliationGroupItems
            .AsNoTracking()
            .Where(item => balances.Select(balance => balance.RawStockItemId)
                .Contains(item.RawStockItemId))
            .ToDictionaryAsync(
                item => item.RawStockItemId,
                item => item.RawStockReconciliationGroupId,
                cancellationToken);

        var now = DateTime.UtcNow;
        var session = new RawStockTakeSession
        {
            WarehouseSectionId = request.WarehouseSectionId,
            CreatedByUserId = userId,
            PeriodStartUtc = start,
            PeriodEndUtc = end,
            CreatedAtUtc = now,
            Status = RawStockTakeStatuses.Draft,
            Notes = Clean(request.Notes),
            CorrelationId = Guid.NewGuid().ToString("N")
        };

        foreach (var balance in balances)
        {
            var itemMovements = movements
                .Where(item => item.RawStockBalanceId == balance.RawStockBalanceId &&
                               item.OccurredAtUtc <= end)
                .ToArray();
            var futureMovement = movements
                .Where(item => item.RawStockBalanceId == balance.RawStockBalanceId &&
                               item.OccurredAtUtc > end)
                .Sum(item => item.QuantityChange);
            var received = itemMovements
                .Where(item => item.MovementType == RawStockMovementTypes.Receipt)
                .Sum(item => item.QuantityChange);
            var positive = itemMovements
                .Where(item => item.MovementType ==
                               RawStockMovementTypes.PositiveAdjustment)
                .Sum(item => item.QuantityChange);
            var writeOff = Math.Abs(itemMovements
                .Where(item => item.MovementType == RawStockMovementTypes.WriteOff)
                .Sum(item => item.QuantityChange));
            var negative = Math.Abs(itemMovements
                .Where(item => item.MovementType ==
                               RawStockMovementTypes.NegativeAdjustment)
                .Sum(item => item.QuantityChange));
            var productionUsed = Math.Abs(itemMovements
                .Where(item => item.MovementType ==
                               RawStockMovementTypes.ProductionConversion)
                .Sum(item => item.QuantityChange));
            // The live balance already includes production conversion. Rebuild
            // the selected historical closing balance from the movement ledger;
            // subtracting current finished-stock weight double-counted usage and
            // could manufacture negative estimates for otherwise valid stock.
            var estimated = balance.QuantityOnHand - futureMovement;
            var opening = estimated -
                          itemMovements.Sum(item => item.QuantityChange);
            mappings.TryGetValue(balance.RawStockItemId, out var groupId);

            session.Lines.Add(new RawStockTakeLine
            {
                RawStockItemId = balance.RawStockItemId,
                RawStockBalanceId = balance.RawStockBalanceId,
                RawStockReconciliationGroupId = groupId > 0 ? groupId : null,
                OpeningRawStock = opening,
                RawStockReceived = received,
                ApprovedPositiveAdjustments = positive,
                ExistingPackedProductWeight = productionUsed,
                RecordedRawStockWriteOffs = writeOff,
                ApprovedNegativeAdjustments = negative,
                EstimatedRawStockRemaining = estimated,
                IsMapped = groupId > 0
            });
        }

        _context.RawStockTakeSessions.Add(session);
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Create,
            "Create raw-stock take",
            session.RawStockTakeSessionId,
            userId,
            session.CorrelationId,
            new Dictionary<string, object?>
            {
                ["warehouseSectionId"] = session.WarehouseSectionId,
                ["periodStartUtc"] = start,
                ["periodEndUtc"] = end,
                ["lineCount"] = session.Lines.Count
            },
            cancellationToken);
        return await GetStockTakeAsync(
            session.RawStockTakeSessionId,
            cancellationToken);
    }

    public async Task<RawStockTakeDto> SaveCountAsync(
        long sessionId,
        long lineId,
        SaveRawStockCountRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var line = await _context.RawStockTakeLines
            .Include(item => item.Session)
            .Include(item => item.RawStockBalance)
            .SingleOrDefaultAsync(
                item => item.RawStockTakeSessionId == sessionId &&
                        item.RawStockTakeLineId == lineId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock take line not found.");
        if (line.Session.Status != RawStockTakeStatuses.Draft)
            throw new PhaseCException(409, "Only a draft stock take can be counted.");
        ValidateVersion(line.RowVersion, request.RowVersion);
        line.PhysicalStockCount = request.PhysicalStockCount;
        line.UnexplainedStockDifference =
            request.PhysicalStockCount - line.EstimatedRawStockRemaining;
        line.EstimatedFinancialImpact =
            line.RawStockBalance.WeightedAverageUnitCost.HasValue
                ? Math.Abs(line.UnexplainedStockDifference.Value) *
                  line.RawStockBalance.WeightedAverageUnitCost.Value
                : null;
        await SaveConcurrencyAsync(cancellationToken);
        return await GetStockTakeAsync(sessionId, cancellationToken);
    }

    public async Task<RawStockTakeDto> SubmitStockTakeAsync(
        long id,
        string rowVersion,
        int userId,
        CancellationToken cancellationToken)
    {
        var session = await StockTakeQuery().SingleOrDefaultAsync(
                item => item.RawStockTakeSessionId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock take not found.");
        if (session.Status != RawStockTakeStatuses.Draft)
            throw new PhaseCException(409, "Only a draft stock take can be submitted.");
        ValidateVersion(session.RowVersion, rowVersion);
        if (session.Lines.Any(item => !item.PhysicalStockCount.HasValue))
            throw new PhaseCException(400, "Count every raw-stock line before submission.");

        var quantityThreshold = await _settings.GetDecimalAsync(
            SystemSettingKeys.RawStockTakeRequireApprovalAboveKg,
            cancellationToken);
        var percentageThreshold = await _settings.GetDecimalAsync(
            SystemSettingKeys.RawStockTakeRequireApprovalAbovePercentage,
            cancellationToken);
        var valueThreshold = await _settings.GetDecimalAsync(
            SystemSettingKeys.RawStockTakeRequireApprovalAboveValue,
            cancellationToken);
        foreach (var line in session.Lines)
        {
            var variance = Math.Abs(line.UnexplainedStockDifference ?? 0);
            var percentage = line.EstimatedRawStockRemaining == 0
                ? variance > 0 ? 100 : 0
                : variance / Math.Abs(line.EstimatedRawStockRemaining) * 100;
            line.RequiresManagementApproval =
                variance >= quantityThreshold ||
                percentage >= percentageThreshold ||
                !line.EstimatedFinancialImpact.HasValue ||
                line.EstimatedFinancialImpact.Value >= valueThreshold;
        }
        // Every completed warehouse count requires an independent Operations
        // Manager decision. Per-line threshold flags still identify the largest
        // discrepancies, but never bypass separation of duties.
        session.ManagementApprovalRequired = true;
        session.Status = RawStockTakeStatuses.Submitted;
        session.SubmittedAtUtc = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.StatusChange,
            "Submit raw-stock take",
            session.RawStockTakeSessionId,
            userId,
            session.CorrelationId,
            new Dictionary<string, object?>
            {
                ["managementApprovalRequired"] =
                    session.ManagementApprovalRequired,
                ["totalFinancialImpact"] =
                    session.Lines.Sum(item => item.EstimatedFinancialImpact)
            },
            cancellationToken);
        return await GetStockTakeAsync(id, cancellationToken);
    }

    public async Task<RawStockTakeDto> ReviewStockTakeAsync(
        long id,
        RawStockTakeReviewRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var session = await StockTakeQuery().SingleOrDefaultAsync(
                item => item.RawStockTakeSessionId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock take not found.");
        if (session.Status != RawStockTakeStatuses.Submitted)
            throw new PhaseCException(409, "Only a submitted stock take can be reviewed.");
        ValidateVersion(session.RowVersion, request.RowVersion);
        session.ReviewedByUserId = userId;
        session.ReviewedAtUtc = DateTime.UtcNow;
        session.AdministratorReviewNotes = Required(request.Notes);
        session.Status = RawStockTakeStatuses.PendingManagementApproval;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.StatusChange,
            "Review raw-stock take",
            session.RawStockTakeSessionId,
            userId,
            session.CorrelationId,
            new Dictionary<string, object?>
            {
                ["status"] = session.Status,
                ["notes"] = request.Notes
            },
            cancellationToken);
        return await GetStockTakeAsync(id, cancellationToken);
    }

    public async Task<RawStockTakeDto> DecideStockTakeAsync(
        long id,
        RawStockTakeDecisionRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Load the complete stock-take record because the decision may need to
        // apply every counted line to its matching raw-stock balance.
        var session = await StockTakeQuery().SingleOrDefaultAsync(
                item => item.RawStockTakeSessionId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock take not found.");
        if (session.Status != RawStockTakeStatuses.PendingManagementApproval)
            throw new PhaseCException(409, "This stock take is not awaiting management approval.");
        // Separation of duties: the creator and reviewer cannot approve their
        // own work. The controller has already checked the user's permission;
        // this business rule still belongs here so every caller is protected.
        if (session.CreatedByUserId == userId || session.ReviewedByUserId == userId)
            throw new PhaseCException(
                409,
                "A different authorised Operations Manager must decide this stock take.");
        ValidateVersion(session.RowVersion, request.RowVersion);
        // The row version stops two managers from deciding the same snapshot.
        session.DecidedByUserId = userId;
        session.DecidedAtUtc = DateTime.UtcNow;
        session.ManagementDecisionReason = Required(request.Reason);
        if (request.Approved)
            // Approval posts the variances and movements in one transaction.
            await ApplyStockTakeAsync(session, userId, cancellationToken);
        else
        {
            // Rejection records the decision but never changes stock balances.
            session.Status = RawStockTakeStatuses.Rejected;
            await SaveConcurrencyAsync(cancellationToken);
        }
        await AuditAsync(
            AuditActionTypes.StatusChange,
            request.Approved
                ? "Approve raw-stock take"
                : "Reject raw-stock take",
            session.RawStockTakeSessionId,
            userId,
            session.CorrelationId,
            new Dictionary<string, object?>
            {
                ["approved"] = request.Approved,
                ["reason"] = request.Reason
            },
            cancellationToken);
        // Re-query the DTO so the UI receives the committed status, people and
        // new concurrency token instead of a partly tracked entity.
        return await GetStockTakeAsync(id, cancellationToken);
    }

    public async Task<IReadOnlyList<RawStockWriteOffDto>> ListWriteOffsAsync(
        CancellationToken cancellationToken) =>
        await WriteOffQuery()
            .AsNoTracking()
            .OrderByDescending(item => item.SubmittedAtUtc)
            .Take(100)
            .Select(item => Map(item))
            .ToListAsync(cancellationToken);

    public async Task<RawStockWriteOffDto> CreateWriteOffAsync(
        CreateRawStockWriteOffRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Available stock excludes reserved quantity because an approved order
        // already depends on that material.
        var balance = await _context.RawStockBalances
            .Include(item => item.RawStockItem)
            .Include(item => item.WarehouseSection)
            .SingleOrDefaultAsync(
                item => item.RawStockBalanceId == request.RawStockBalanceId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock balance not found.");
        if (request.Quantity > balance.QuantityOnHand - balance.ReservedQuantity)
            throw new PhaseCException(409, "The requested write-off exceeds available raw stock.");
        var reason = await _context.OperationalReasons.SingleOrDefaultAsync(
            item => item.OperationalReasonId == request.OperationalReasonId &&
                    item.IsActive,
            cancellationToken)
            ?? throw new PhaseCException(400, "Select an active write-off reason.");
        RawStockBatch? batch = null;
        if (request.RawStockBatchId.HasValue)
        {
            batch = await _context.RawStockBatches.SingleOrDefaultAsync(
                item => item.RawStockBatchId == request.RawStockBatchId.Value &&
                        item.RawStockBalanceId == balance.RawStockBalanceId,
                cancellationToken);
            if (batch is null || batch.QuantityRemaining < request.Quantity)
                throw new PhaseCException(409, "The selected batch cannot cover this write-off.");
        }

        var quantityThreshold = await _settings.GetDecimalAsync(
            SystemSettingKeys.RawStockWriteOffRequireApprovalAboveQuantity,
            cancellationToken);
        var valueThreshold = await _settings.GetDecimalAsync(
            SystemSettingKeys.RawStockWriteOffRequireApprovalAboveValue,
            cancellationToken);
        var totalLoss = balance.WeightedAverageUnitCost.HasValue
            ? request.Quantity * balance.WeightedAverageUnitCost.Value
            : (decimal?)null;
        var approvalRequired =
            !totalLoss.HasValue ||
            request.Quantity >= quantityThreshold ||
            totalLoss.Value >= valueThreshold;
        // Unknown cost is sent for approval as a safe default. Known small
        // losses can complete automatically under the configured thresholds.
        var correlationId = Guid.NewGuid().ToString("N");
        var item = new RawStockWriteOff
        {
            RawStockItemId = balance.RawStockItemId,
            RawStockBalanceId = balance.RawStockBalanceId,
            RawStockBatchId = request.RawStockBatchId,
            OperationalReasonId = reason.OperationalReasonId,
            SubmittedByUserId = userId,
            Quantity = request.Quantity,
            EstimatedUnitCost = balance.WeightedAverageUnitCost,
            EstimatedTotalLoss = totalLoss,
            Condition = Clean(request.Condition),
            Notes = Clean(request.Notes),
            Status = approvalRequired
                ? WriteOffStatuses.PendingApproval
                : WriteOffStatuses.Draft,
            SubmittedAtUtc = DateTime.UtcNow,
            CorrelationId = correlationId
        };
        _context.RawStockWriteOffs.Add(item);
        await _context.SaveChangesAsync(cancellationToken);
        if (!approvalRequired)
        {
            item.DecidedByUserId = userId;
            item.DecidedAtUtc = DateTime.UtcNow;
            item.DecisionReason = "Within configured automatic-completion limits.";
            await ApplyWriteOffAsync(item, balance, batch, userId, cancellationToken);
        }
        await AuditAsync(
            AuditActionTypes.WriteOff,
            "Submit raw-stock write-off",
            item.RawStockWriteOffId,
            userId,
            correlationId,
            new Dictionary<string, object?>
            {
                ["rawStockItemId"] = item.RawStockItemId,
                ["quantity"] = item.Quantity,
                ["estimatedLoss"] = item.EstimatedTotalLoss,
                ["approvalRequired"] = approvalRequired,
                ["reasonCode"] = reason.ReasonCode
            },
            cancellationToken);
        return await WriteOffDtoAsync(item.RawStockWriteOffId, cancellationToken);
    }

    public async Task<RawStockWriteOffDto> DecideWriteOffAsync(
        long id,
        RawStockWriteOffDecisionRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await WriteOffQuery().SingleOrDefaultAsync(
                value => value.RawStockWriteOffId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock write-off not found.");
        if (item.Status != WriteOffStatuses.PendingApproval)
            throw new PhaseCException(409, "This write-off is not awaiting approval.");
        if (item.SubmittedByUserId == userId)
            throw new PhaseCException(
                409,
                "A different authorised Operations Manager must decide this write-off.");
        ValidateVersion(item.RowVersion, request.RowVersion);
        item.DecidedByUserId = userId;
        item.DecidedAtUtc = DateTime.UtcNow;
        item.DecisionReason = Required(request.Reason);
        if (request.Approved)
        {
            await ApplyWriteOffAsync(
                item,
                item.RawStockBalance,
                item.RawStockBatch,
                userId,
                cancellationToken);
        }
        else
        {
            item.Status = WriteOffStatuses.Rejected;
            await SaveConcurrencyAsync(cancellationToken);
        }
        await AuditAsync(
            AuditActionTypes.StatusChange,
            request.Approved
                ? "Approve raw-stock write-off"
                : "Reject raw-stock write-off",
            item.RawStockWriteOffId,
            userId,
            item.CorrelationId,
            new Dictionary<string, object?>
            {
                ["approved"] = request.Approved,
                ["reason"] = request.Reason
            },
            cancellationToken);
        return await WriteOffDtoAsync(id, cancellationToken);
    }

    private async Task ApplyStockTakeAsync(
        RawStockTakeSession session,
        int userId,
        CancellationToken cancellationToken)
    {
        await using var transaction =
            await _context.Database.BeginTransactionAsync(cancellationToken);
        foreach (var line in session.Lines)
        {
            var variance = line.UnexplainedStockDifference ?? 0;
            if (variance == 0)
            {
                line.RawStockBalance.LastStockTakeAtUtc = DateTime.UtcNow;
                continue;
            }
            line.RawStockBalance.QuantityOnHand += variance;
            line.RawStockBalance.LastStockTakeAtUtc = DateTime.UtcNow;
            _context.RawStockMovements.Add(new RawStockMovement
            {
                RawStockItemId = line.RawStockItemId,
                RawStockBalanceId = line.RawStockBalanceId,
                CreatedByUserId = userId,
                MovementType = variance > 0
                    ? RawStockMovementTypes.PositiveAdjustment
                    : RawStockMovementTypes.NegativeAdjustment,
                QuantityChange = variance,
                UnitCost = line.RawStockBalance.WeightedAverageUnitCost,
                OccurredAtUtc = DateTime.UtcNow,
                SourceType = nameof(RawStockTakeSession),
                SourceId = session.RawStockTakeSessionId.ToString(),
                ReasonText = session.AdministratorReviewNotes ??
                             session.ManagementDecisionReason ??
                             "Approved raw-stock reconciliation.",
                CorrelationId = session.CorrelationId
            });
        }
        session.Status = RawStockTakeStatuses.Closed;
        session.ClosedAtUtc = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
    }

    private async Task ApplyWriteOffAsync(
        RawStockWriteOff item,
        RawStockBalance balance,
        RawStockBatch? batch,
        int userId,
        CancellationToken cancellationToken)
    {
        await using var transaction =
            await _context.Database.BeginTransactionAsync(cancellationToken);
        if (balance.QuantityOnHand - balance.ReservedQuantity < item.Quantity)
            throw new PhaseCException(409, "Available raw stock changed before approval.");
        if (batch is not null)
        {
            if (batch.QuantityRemaining < item.Quantity)
                throw new PhaseCException(409, "The selected batch changed before approval.");
            batch.QuantityRemaining -= item.Quantity;
            if (batch.QuantityRemaining == 0)
                batch.Status = ProductBatchStatuses.WrittenOff;
        }
        balance.QuantityOnHand -= item.Quantity;
        item.Status = WriteOffStatuses.Completed;
        item.CompletedAtUtc = DateTime.UtcNow;
        _context.RawStockMovements.Add(new RawStockMovement
        {
            RawStockItemId = item.RawStockItemId,
            RawStockBalanceId = item.RawStockBalanceId,
            RawStockBatchId = item.RawStockBatchId,
            OperationalReasonId = item.OperationalReasonId,
            CreatedByUserId = userId,
            MovementType = RawStockMovementTypes.WriteOff,
            QuantityChange = -item.Quantity,
            UnitCost = item.EstimatedUnitCost,
            OccurredAtUtc = DateTime.UtcNow,
            SourceType = nameof(RawStockWriteOff),
            SourceId = item.RawStockWriteOffId.ToString(),
            ReasonText = item.Notes ?? item.DecisionReason,
            CorrelationId = item.CorrelationId
        });
        await SaveConcurrencyAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
    }

    private IQueryable<RawStockTakeSession> StockTakeQuery() =>
        _context.RawStockTakeSessions
            .Include(item => item.WarehouseSection)
            .Include(item => item.CreatedByUser)
            .Include(item => item.ReviewedByUser)
            .Include(item => item.DecidedByUser)
            .Include(item => item.Lines)
                .ThenInclude(item => item.RawStockItem)
            .Include(item => item.Lines)
                .ThenInclude(item => item.RawStockBalance)
            .Include(item => item.Lines)
                .ThenInclude(item => item.ReconciliationGroup);

    private IQueryable<RawStockWriteOff> WriteOffQuery() =>
        _context.RawStockWriteOffs
            .Include(item => item.RawStockItem)
            .Include(item => item.RawStockBalance)
                .ThenInclude(item => item.WarehouseSection)
            .Include(item => item.RawStockBatch)
            .Include(item => item.OperationalReason);

    private async Task<RawStockWriteOffDto> WriteOffDtoAsync(
        long id,
        CancellationToken cancellationToken)
    {
        var item = await WriteOffQuery().AsNoTracking().SingleOrDefaultAsync(
                value => value.RawStockWriteOffId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock write-off not found.");
        return Map(item);
    }

    private static RawStockWriteOffDto Map(RawStockWriteOff item) =>
        new()
        {
            RawStockWriteOffId = item.RawStockWriteOffId,
            ItemName = item.RawStockItem.ItemName,
            WarehouseSection = item.RawStockBalance.WarehouseSection.SectionName,
            Quantity = item.Quantity,
            EstimatedUnitCost = item.EstimatedUnitCost,
            EstimatedTotalLoss = item.EstimatedTotalLoss,
            Reason = item.OperationalReason.ReasonName,
            Status = item.Status,
            RequiresManagementApproval =
                item.Status == WriteOffStatuses.PendingApproval,
            CorrelationId = item.CorrelationId,
            RowVersion = Encode(item.RowVersion)
        };

    private static RawStockTakeDto Map(RawStockTakeSession session) =>
        new()
        {
            RawStockTakeSessionId = session.RawStockTakeSessionId,
            WarehouseSection = session.WarehouseSection.SectionName,
            StartedBy = $"{session.CreatedByUser.FirstName} {session.CreatedByUser.LastName}".Trim(),
            CreatedAtUtc = session.CreatedAtUtc,
            SubmittedAtUtc = session.SubmittedAtUtc,
            ReviewedBy = session.ReviewedByUser == null
                ? null
                : $"{session.ReviewedByUser.FirstName} {session.ReviewedByUser.LastName}".Trim(),
            ReviewedAtUtc = session.ReviewedAtUtc,
            DecidedBy = session.DecidedByUser == null
                ? null
                : $"{session.DecidedByUser.FirstName} {session.DecidedByUser.LastName}".Trim(),
            DecidedAtUtc = session.DecidedAtUtc,
            PeriodStartUtc = session.PeriodStartUtc,
            PeriodEndUtc = session.PeriodEndUtc,
            Status = session.Status,
            ManagementApprovalRequired = session.ManagementApprovalRequired,
            AdministratorReviewNotes = session.AdministratorReviewNotes,
            ManagementDecisionReason = session.ManagementDecisionReason,
            CorrelationId = session.CorrelationId,
            RowVersion = Encode(session.RowVersion),
            EstimateGeneratedAtUtc = session.CreatedAtUtc,
            Lines = session.Lines.OrderBy(item => item.RawStockItem.ItemName)
                .Select(item => new RawStockTakeLineDto
                {
                    RawStockTakeLineId = item.RawStockTakeLineId,
                    RawStockItemId = item.RawStockItemId,
                    ItemCode = item.RawStockItem.ItemCode,
                    ItemName = item.RawStockItem.ItemName,
                    ReconciliationGroup = item.ReconciliationGroup?.GroupName,
                    IsMapped = item.IsMapped,
                    OpeningRawStock = item.OpeningRawStock,
                    RawStockReceived = item.RawStockReceived,
                    ApprovedPositiveAdjustments =
                        item.ApprovedPositiveAdjustments,
                    ExistingPackedProductWeight =
                        item.ExistingPackedProductWeight,
                    RecordedRawStockWriteOffs =
                        item.RecordedRawStockWriteOffs,
                    ApprovedNegativeAdjustments =
                        item.ApprovedNegativeAdjustments,
                    EstimatedRawStockRemaining =
                        item.EstimatedRawStockRemaining,
                    PhysicalStockCount = item.PhysicalStockCount,
                    UnexplainedStockDifference =
                        item.UnexplainedStockDifference,
                    EstimatedFinancialImpact = item.EstimatedFinancialImpact,
                    ManagementApprovalRequired =
                        item.RequiresManagementApproval,
                    RowVersion = Encode(item.RowVersion)
                })
                .ToArray()
        };

    private async Task AuditAsync(
        string action,
        string operation,
        long id,
        int userId,
        string correlationId,
        IReadOnlyDictionary<string, object?> details,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = AuditModules.RawStockTake,
            OperationName = operation,
            Description = $"{operation} #{id}.",
            EntityType = operation.Contains("write-off", StringComparison.OrdinalIgnoreCase)
                ? nameof(RawStockWriteOff)
                : nameof(RawStockTakeSession),
            EntityId = id.ToString(),
            EntityDisplay = $"#{id}",
            UserId = userId,
            SafeDetails = new Dictionary<string, object?>(details)
            {
                ["correlationId"] = correlationId
            }
        }, cancellationToken);

    private async Task SaveConcurrencyAsync(CancellationToken cancellationToken)
    {
        try
        {
            await _context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new PhaseCException(
                409,
                "This record changed since it was loaded. Reload and try again.");
        }
    }

    private static void ValidateVersion(byte[]? current, string supplied)
    {
        try
        {
            if (current is not null &&
                !CryptographicOperations.FixedTimeEquals(
                    current,
                    Convert.FromBase64String(supplied)))
                throw new PhaseCException(
                    409,
                    "This record changed since it was loaded. Reload and try again.");
        }
        catch (FormatException)
        {
            throw new PhaseCException(400, "The concurrency token is invalid.");
        }
    }

    private static string Encode(byte[]? value) =>
        value is null ? string.Empty : Convert.ToBase64String(value);

    private static string Required(string value) =>
        string.IsNullOrWhiteSpace(value)
            ? throw new PhaseCException(400, "A required value is missing.")
            : value.Trim();

    private static string? Clean(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
