using System.Data;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Product;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

/// <summary>
/// Converts recipe-backed raw material into a traceable finished-product batch.
/// Availability checks and all raw/finished stock movements commit together.
/// </summary>
public sealed class ProductionService : IProductionService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService? _audit;

    public ProductionService(
        PhenyoSyncDbContext context,
        IAuditService? audit = null)
    {
        _context = context;
        _audit = audit;
    }

    public async Task<IReadOnlyList<PackableProductDto>> PackableProductsAsync(
        int sectionId,
        CancellationToken cancellationToken)
    {
        if (sectionId < 1)
            throw new Subsystem7Exception(400, "Select a warehouse section.");

        var products = await _context.Products
            .AsNoTracking()
            .Where(product =>
                product.Status == ProductStatuses.Active &&
                product.RawStockRequirements.Any(requirement =>
                    requirement.IsActive))
            .Select(product => new
            {
                product.ProductId,
                product.ProductName,
                product.Size,
                product.ShelfLifeDays,
                product.QRCodeValue,
                Requirements = product.RawStockRequirements
                    .Where(requirement => requirement.IsActive)
                    .Select(requirement => new
                    {
                        requirement.RawStockItemId,
                        requirement.RawQuantityPerProductUnit,
                        requirement.UnitOfMeasure,
                        requirement.WastePercentage,
                        requirement.YieldPercentage,
                        requirement.RawStockItem.ItemCode,
                        requirement.RawStockItem.ItemName
                    })
                    .ToList()
            })
            .OrderBy(product => product.ProductName)
            .ThenBy(product => product.Size)
            .ToListAsync(cancellationToken);

        var rawStockIds = products
            .SelectMany(product => product.Requirements)
            .Select(requirement => requirement.RawStockItemId)
            .Distinct()
            .ToArray();
        var now = DateTime.UtcNow;
        var balances = await _context.RawStockBalances
            .AsNoTracking()
            .Where(balance =>
                balance.WarehouseSectionId == sectionId &&
                rawStockIds.Contains(balance.RawStockItemId))
            .Select(balance => new
            {
                balance.RawStockBalanceId,
                balance.RawStockItemId,
                balance.UnitOfMeasure,
                NetQuantity = balance.QuantityOnHand - balance.ReservedQuantity
            })
            .ToListAsync(cancellationToken);
        var balanceIds = balances
            .Select(balance => balance.RawStockBalanceId)
            .ToArray();
        var eligibleBatchQuantities = await _context.RawStockBatches
            .AsNoTracking()
            .Where(batch =>
                balanceIds.Contains(batch.RawStockBalanceId) &&
                batch.Status == ProductBatchStatuses.Available &&
                batch.QuantityRemaining > 0 &&
                (!batch.BestBeforeAtUtc.HasValue ||
                 batch.BestBeforeAtUtc.Value > now))
            .Select(batch => new
            {
                batch.RawStockBalanceId,
                batch.QuantityRemaining
            })
            .ToListAsync(cancellationToken);
        var batchQuantityByBalance = eligibleBatchQuantities
            .GroupBy(batch => batch.RawStockBalanceId)
            .ToDictionary(
                group => group.Key,
                group => group.Sum(batch => batch.QuantityRemaining));

        var results = new List<PackableProductDto>();
        foreach (var product in products)
        {
            var requirementResults = new List<PackableRawStockRequirementDto>();
            decimal? maximum = null;
            var validRecipe = true;

            foreach (var requirement in product.Requirements)
            {
                var adjusted = AdjustedRequirement(
                    requirement.RawQuantityPerProductUnit,
                    requirement.WastePercentage,
                    requirement.YieldPercentage);
                if (adjusted <= 0)
                {
                    validRecipe = false;
                    break;
                }

                var balance = balances.FirstOrDefault(item =>
                    item.RawStockItemId == requirement.RawStockItemId &&
                    item.UnitOfMeasure.Equals(
                        requirement.UnitOfMeasure,
                        StringComparison.OrdinalIgnoreCase));
                var available = balance is null
                    ? 0m
                    : Math.Max(
                        0m,
                        Math.Min(
                            balance.NetQuantity,
                            batchQuantityByBalance.GetValueOrDefault(
                                balance.RawStockBalanceId)));
                var packable = Math.Floor(available / adjusted * 1000m) / 1000m;
                maximum = maximum.HasValue
                    ? Math.Min(maximum.Value, packable)
                    : packable;
                requirementResults.Add(new PackableRawStockRequirementDto
                {
                    RawStockItemId = requirement.RawStockItemId,
                    ItemCode = requirement.ItemCode,
                    ItemName = requirement.ItemName,
                    UnitOfMeasure = requirement.UnitOfMeasure,
                    QuantityPerProductUnit =
                        requirement.RawQuantityPerProductUnit,
                    AdjustedQuantityPerProductUnit = adjusted,
                    AvailableQuantity = available
                });
            }

            if (!validRecipe || maximum is null || maximum <= 0)
                continue;

            results.Add(new PackableProductDto
            {
                ProductId = product.ProductId,
                ProductCode = product.QRCodeValue ??
                    $"PRODUCT-{product.ProductId:D6}",
                ProductName = product.ProductName,
                Size = product.Size,
                ShelfLifeDays = product.ShelfLifeDays,
                MaximumPackableQuantity = maximum.Value,
                Requirements = requirementResults
            });
        }

        return results;
    }

    public async Task<MakeProductResponseDto> MakeProductAsync(
        CreateProductDto request,
        int? userId,
        CancellationToken cancellationToken)
    {
        // Production is a multi-ledger operation, so the transaction prevents
        // raw consumption without the corresponding finished batch (or vice versa).
        if (!userId.HasValue)
            throw new Subsystem7Exception(401, "Sign in before recording production.");

        var packedAtUtc = request.PackedAtUtc ?? DateTime.UtcNow;
        packedAtUtc = packedAtUtc.Kind == DateTimeKind.Utc
            ? packedAtUtc
            : packedAtUtc.ToUniversalTime();
        if (packedAtUtc > DateTime.UtcNow.AddMinutes(5))
            throw new Subsystem7Exception(400, "Packed date cannot be in the future.");

        var correlationId = Guid.NewGuid().ToString("N");
        await using var transaction = await _context.Database
            .BeginTransactionAsync(
                IsolationLevel.Serializable,
                cancellationToken);

        try
        {
            var product = await _context.Products
                .Include(item => item.RawStockRequirements
                    .Where(requirement => requirement.IsActive))
                .ThenInclude(requirement => requirement.RawStockItem)
                .SingleOrDefaultAsync(
                    item => item.ProductId == request.ProductId,
                    cancellationToken)
                ?? throw new Subsystem7Exception(404, "Product not found.");
            if (product.Status != ProductStatuses.Active)
                throw new Subsystem7Exception(409, "Only active Products can be packed.");
            if (product.RawStockRequirements.Count == 0)
                throw new Subsystem7Exception(
                    409,
                    "Configure the Product's Raw Stock requirements before packing it.");

            var section = await _context.WarehouseSections
                .SingleOrDefaultAsync(
                    item => item.SectionId == request.SectionId,
                    cancellationToken)
                ?? throw new Subsystem7Exception(400, "Warehouse section not found.");
            if (!section.Status.Equals(
                    ProductStatuses.Active,
                    StringComparison.OrdinalIgnoreCase))
                throw new Subsystem7Exception(400, "Select an active warehouse section.");

            var plans = new List<ConsumptionPlan>();
            var now = DateTime.UtcNow;
            foreach (var requirement in product.RawStockRequirements)
            {
                var adjustedPerUnit = AdjustedRequirement(
                    requirement.RawQuantityPerProductUnit,
                    requirement.WastePercentage,
                    requirement.YieldPercentage);
                if (adjustedPerUnit <= 0)
                    throw new Subsystem7Exception(
                        409,
                        $"The recipe for {requirement.RawStockItem.ItemName} is invalid.");

                var requiredQuantity = decimal.Round(
                    request.QuantityProducedKg * adjustedPerUnit,
                    3,
                    MidpointRounding.AwayFromZero);
                var balance = await _context.RawStockBalances
                    .Include(item => item.Batches)
                    .SingleOrDefaultAsync(
                        item =>
                            item.RawStockItemId == requirement.RawStockItemId &&
                            item.WarehouseSectionId == request.SectionId &&
                            item.UnitOfMeasure == requirement.UnitOfMeasure,
                        cancellationToken)
                    ?? throw InsufficientStock(
                        requirement.RawStockItem.ItemName,
                        requiredQuantity,
                        requirement.UnitOfMeasure,
                        0m);

                var availableBalance = Math.Max(
                    0m,
                    balance.QuantityOnHand - balance.ReservedQuantity);
                var eligibleBatches = balance.Batches
                    .Where(batch =>
                        batch.Status == ProductBatchStatuses.Available &&
                        batch.QuantityRemaining > 0 &&
                        (!batch.BestBeforeAtUtc.HasValue ||
                         batch.BestBeforeAtUtc.Value > now))
                    .OrderBy(batch => !batch.BestBeforeAtUtc.HasValue)
                    .ThenBy(batch => batch.BestBeforeAtUtc)
                    .ThenBy(batch => batch.ReceivedAtUtc)
                    .ThenBy(batch => batch.RawStockBatchId)
                    .ToList();
                var batchAvailable = eligibleBatches.Sum(batch => batch.QuantityRemaining);
                var available = Math.Min(availableBalance, batchAvailable);
                if (available < requiredQuantity)
                    throw InsufficientStock(
                        requirement.RawStockItem.ItemName,
                        requiredQuantity,
                        requirement.UnitOfMeasure,
                        available);

                plans.Add(new ConsumptionPlan(
                    requirement,
                    balance,
                    eligibleBatches,
                    requiredQuantity));
            }

            var stock = await _context.Stocks.SingleOrDefaultAsync(
                item =>
                    item.ProductId == product.ProductId &&
                    item.SectionId == request.SectionId,
                cancellationToken);
            await RemoveNewlyExpiredFinishedStockAsync(
                product.ProductId,
                request.SectionId,
                stock,
                userId.Value,
                now,
                cancellationToken);

            var batchCode = CreateBatchCode(product.ProductId);
            var batch = new ProductBatch
            {
                ProductId = product.ProductId,
                SectionId = request.SectionId,
                BatchCode = batchCode,
                QRCodeValue = $"PHENYOSYNC:BATCH:{batchCode}",
                QuantityProducedKg = request.QuantityProducedKg,
                QuantityRemainingKg = request.QuantityProducedKg,
                PackedAtUtc = packedAtUtc,
                OriginalExpiryAtUtc = packedAtUtc.AddDays(product.ShelfLifeDays),
                EffectiveExpiryAtUtc = packedAtUtc.AddDays(product.ShelfLifeDays),
                Status = ProductBatchStatuses.Available,
                CreatedAtUtc = now
            };
            _context.ProductBatches.Add(batch);

            if (stock is null)
            {
                stock = new Stock
                {
                    ProductId = product.ProductId,
                    SectionId = request.SectionId,
                    QuantityAvailableKg = request.QuantityProducedKg,
                    ReorderLevelKg = 0,
                    InventoryStatus = ProductBatchStatuses.Available
                };
                _context.Stocks.Add(stock);
            }
            else
            {
                stock.QuantityAvailableKg += request.QuantityProducedKg;
                stock.InventoryStatus = ProductBatchStatuses.Available;
            }

            var conversion = new PackingConversion
            {
                Product = product,
                ProductBatch = batch,
                WarehouseSectionId = request.SectionId,
                QuantityProduced = request.QuantityProducedKg,
                PackedByUserId = userId.Value,
                PackedAtUtc = packedAtUtc,
                CreatedAtUtc = now,
                CorrelationId = correlationId
            };
            _context.PackingConversions.Add(conversion);
            await _context.SaveChangesAsync(cancellationToken);

            decimal rawQuantityConsumed = 0m;
            foreach (var plan in plans)
            {
                var balanceBefore = plan.Balance.QuantityOnHand;
                var remaining = plan.RequiredQuantity;
                foreach (var rawBatch in plan.Batches)
                {
                    if (remaining <= 0)
                        break;

                    var batchBefore = rawBatch.QuantityRemaining;
                    var consumed = Math.Min(batchBefore, remaining);
                    rawBatch.QuantityRemaining -= consumed;
                    if (rawBatch.QuantityRemaining == 0)
                        rawBatch.Status = ProductBatchStatuses.Consumed;
                    plan.Balance.QuantityOnHand -= consumed;
                    remaining -= consumed;
                    rawQuantityConsumed += consumed;

                    _context.PackingConversionRawStock.Add(
                        new PackingConversionRawStock
                        {
                            PackingConversionId = conversion.PackingConversionId,
                            RawStockItemId = plan.Requirement.RawStockItemId,
                            RawStockBalanceId = plan.Balance.RawStockBalanceId,
                            RawStockBatchId = rawBatch.RawStockBatchId,
                            QuantityConsumed = consumed,
                            UnitOfMeasure = plan.Requirement.UnitOfMeasure,
                            BalanceBefore = balanceBefore,
                            BalanceAfter = plan.Balance.QuantityOnHand,
                            BatchBefore = batchBefore,
                            BatchAfter = rawBatch.QuantityRemaining,
                            UnitCost = rawBatch.UnitCost
                        });
                    _context.RawStockMovements.Add(new RawStockMovement
                    {
                        RawStockItemId = plan.Requirement.RawStockItemId,
                        RawStockBalanceId = plan.Balance.RawStockBalanceId,
                        RawStockBatchId = rawBatch.RawStockBatchId,
                        CreatedByUserId = userId.Value,
                        MovementType = RawStockMovementTypes.ProductionConversion,
                        QuantityChange = -consumed,
                        UnitCost = rawBatch.UnitCost,
                        OccurredAtUtc = now,
                        SourceType = nameof(PackingConversion),
                        SourceId = conversion.PackingConversionId.ToString(),
                        ReasonText =
                            $"Consumed while packing {product.ProductName} batch {batch.BatchCode}.",
                        CorrelationId = correlationId
                    });
                    balanceBefore = plan.Balance.QuantityOnHand;
                }

                if (remaining > 0)
                    throw new Subsystem7Exception(
                        409,
                        "Raw Stock changed while the Product was being packed. Refresh and try again.");
            }

            _context.StockMovements.Add(new StockMovement
            {
                ProductId = product.ProductId,
                ProductBatchId = batch.ProductBatchId,
                SectionId = request.SectionId,
                MovementType = StockMovementTypes.Increase,
                QuantityKg = request.QuantityProducedKg,
                OccurredAtUtc = now,
                CreatedByUserId = userId.Value,
                Reason =
                    $"Production conversion {conversion.PackingConversionId}; correlation {correlationId}."
            });
            await _context.SaveChangesAsync(cancellationToken);

            if (_audit is not null)
            {
                await _audit.RecordAsync(new AuditEvent
                {
                    ActionType = AuditActionTypes.IncreaseStock,
                    SystemModule = AuditModules.Packing,
                    OperationName = "Convert Raw Stock to finished Product",
                    Description =
                        "Raw Stock was consumed and a traceable finished Product batch was created atomically.",
                    EntityType = nameof(PackingConversion),
                    EntityId = conversion.PackingConversionId.ToString(),
                    EntityDisplay = $"{product.ProductName} / {batch.BatchCode}",
                    UserId = userId.Value,
                    Success = true,
                    EventSource = AuditEventSources.BusinessEvent,
                    SafeDetails = new Dictionary<string, object?>
                    {
                        ["productId"] = product.ProductId,
                        ["productBatchId"] = batch.ProductBatchId,
                        ["warehouseSectionId"] = request.SectionId,
                        ["quantityProduced"] = request.QuantityProducedKg,
                        ["rawStockRequirementCount"] = plans.Count,
                        ["correlationId"] = correlationId
                    }
                }, cancellationToken);
            }

            await transaction.CommitAsync(cancellationToken);
            return new MakeProductResponseDto
            {
                Message =
                    "Raw Stock converted and the finished Product batch recorded successfully.",
                ProductCreated = false,
                ProductId = product.ProductId,
                ProductCode = product.QRCodeValue ??
                    $"PRODUCT-{product.ProductId:D6}",
                ProductBatchId = batch.ProductBatchId,
                BatchCode = batch.BatchCode,
                QRCodeValue = batch.QRCodeValue,
                QuantityAddedKg = request.QuantityProducedKg,
                AggregateQuantityAvailableKg = stock.QuantityAvailableKg,
                PackedAtUtc = batch.PackedAtUtc,
                EffectiveExpiryAtUtc = batch.EffectiveExpiryAtUtc,
                PackingConversionId = conversion.PackingConversionId,
                CorrelationId = correlationId,
                RawStockQuantityConsumed = rawQuantityConsumed
            };
        }
        catch (DbUpdateConcurrencyException)
        {
            await transaction.RollbackAsync(cancellationToken);
            throw new Subsystem7Exception(
                409,
                "Stock changed while the Product was being packed. Refresh and try again.");
        }
        catch
        {
            await transaction.RollbackAsync(cancellationToken);
            throw;
        }
    }

    private async Task RemoveNewlyExpiredFinishedStockAsync(
        int productId,
        int sectionId,
        Stock? stock,
        int userId,
        DateTime now,
        CancellationToken cancellationToken)
    {
        var expiredBatches = await _context.ProductBatches
            .Where(batch =>
                batch.ProductId == productId &&
                batch.SectionId == sectionId &&
                batch.QuantityRemainingKg > 0 &&
                batch.EffectiveExpiryAtUtc <= now &&
                batch.AvailableQuantityRemovedAtUtc == null &&
                batch.Status != ProductBatchStatuses.Consumed &&
                batch.Status != ProductBatchStatuses.WrittenOff)
            .ToListAsync(cancellationToken);
        var expiredQuantity = expiredBatches.Sum(batch => batch.QuantityRemainingKg);
        if (expiredQuantity <= 0)
            return;
        if (stock is null || stock.QuantityAvailableKg < expiredQuantity)
            throw new Subsystem7Exception(
                409,
                "Existing finished stock is inconsistent with expired batches. Reconcile it before packing more stock.");

        stock.QuantityAvailableKg -= expiredQuantity;
        foreach (var expiredBatch in expiredBatches)
        {
            expiredBatch.Status = ProductBatchStatuses.ExpiredPendingDecision;
            expiredBatch.AvailableQuantityRemovedAtUtc = now;
            expiredBatch.UpdatedAtUtc = now;
            _context.StockMovements.Add(new StockMovement
            {
                ProductId = productId,
                ProductBatchId = expiredBatch.ProductBatchId,
                SectionId = sectionId,
                MovementType = StockMovementTypes.Decrease,
                QuantityKg = expiredBatch.QuantityRemainingKg,
                OccurredAtUtc = now,
                CreatedByUserId = userId,
                Reason = "Expired batch removed from available stock before production conversion."
            });
        }
    }

    private static decimal AdjustedRequirement(
        decimal quantityPerUnit,
        decimal wastePercentage,
        decimal yieldPercentage)
    {
        if (quantityPerUnit <= 0 ||
            wastePercentage < 0 ||
            yieldPercentage <= 0 ||
            yieldPercentage > 100)
            return 0m;
        return decimal.Round(
            quantityPerUnit *
            (1m + wastePercentage / 100m) /
            (yieldPercentage / 100m),
            6,
            MidpointRounding.AwayFromZero);
    }

    private static Subsystem7Exception InsufficientStock(
        string itemName,
        decimal required,
        string unit,
        decimal available) =>
        new(
            409,
            $"Insufficient Raw Stock for {itemName}. Required {required:0.###} {unit}; available {available:0.###} {unit}.");

    private static string CreateBatchCode(int productId) =>
        $"BATCH-{productId:D6}-{DateTime.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid():N}"[..43]
            .ToUpperInvariant();

    private sealed record ConsumptionPlan(
        ProductRawStockRequirement Requirement,
        RawStockBalance Balance,
        IReadOnlyList<RawStockBatch> Batches,
        decimal RequiredQuantity);
}
