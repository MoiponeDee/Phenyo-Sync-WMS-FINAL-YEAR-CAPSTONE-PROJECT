using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Delivery;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public sealed record ProtectedFileReadResult(
    StoredFile StoredFile,
    FileStream Stream);

public interface IDeliveryProofImageService
{
    Task<IReadOnlyList<DeliveryProofImageDto>> ListAsync(
        int deliveryId,
        int userId,
        string role,
        CancellationToken cancellationToken);

    Task<DeliveryProofImageDto> UploadAsync(
        int deliveryId,
        IFormFile file,
        UploadDeliveryProofImageRequest request,
        int userId,
        string role,
        bool canManage,
        CancellationToken cancellationToken);

    Task<ProtectedFileReadResult> OpenAsync(
        int deliveryId,
        long imageId,
        bool thumbnail,
        int userId,
        string role,
        CancellationToken cancellationToken);

    Task RemoveAsync(
        int deliveryId,
        long imageId,
        string? reason,
        int userId,
        string role,
        bool canManage,
        CancellationToken cancellationToken);
}

/// <summary>Validates and stores delivery proof images behind delivery ownership rules.</summary>
public sealed class DeliveryProofImageService : IDeliveryProofImageService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IProtectedFileStorage _storage;
    private readonly ISystemSettingProvider _settings;
    private readonly IAuditService _audit;

    public DeliveryProofImageService(
        PhenyoSyncDbContext context,
        IProtectedFileStorage storage,
        ISystemSettingProvider settings,
        IAuditService audit)
    {
        _context = context;
        _storage = storage;
        _settings = settings;
        _audit = audit;
    }

    public async Task<IReadOnlyList<DeliveryProofImageDto>> ListAsync(
        int deliveryId,
        int userId,
        string role,
        CancellationToken cancellationToken)
    {
        var delivery = await LoadDeliveryAsync(
            deliveryId,
            cancellationToken);
        EnsureAccess(delivery, userId, role, true);
        var items = await _context.DeliveryProofImages
            .AsNoTracking()
            .Include(item => item.StoredFile)
            .Include(item => item.UploadedByUser)
            .Where(item =>
                item.DeliveryId == deliveryId &&
                item.RemovedAtUtc == null)
            .OrderByDescending(item => item.IsPrimary)
            .ThenBy(item => item.UploadedAtUtc)
            .ToListAsync(cancellationToken);
        return items.Select(Map).ToList();
    }

    // Validate delivery ownership and image content before storing a protected proof reference.
    public async Task<DeliveryProofImageDto> UploadAsync(
        int deliveryId,
        IFormFile file,
        UploadDeliveryProofImageRequest request,
        int userId,
        string role,
        bool canManage,
        CancellationToken cancellationToken)
    {
        var delivery = await LoadDeliveryAsync(
            deliveryId,
            cancellationToken);
        EnsureAccess(delivery, userId, role, canManage);
        if (delivery.Status is DeliveryStatuses.Completed or DeliveryStatuses.Cancelled)
        {
            throw new DeliveryManagementException(
                409,
                "Proof images cannot be added to a completed or cancelled delivery.");
        }

        var maximumMb = await _settings.GetIntAsync(
            SystemSettingKeys.FilesProofImageMaximumMb,
            cancellationToken);
        StoredImageResult stored;
        try
        {
            stored = await _storage.SaveProofImageAsync(
                file,
                userId,
                maximumMb,
                cancellationToken);
        }
        catch (ProtectedFileException exception)
        {
            throw new DeliveryManagementException(400, exception.Message);
        }

        try
        {
            var hasActive = await _context.DeliveryProofImages.AnyAsync(
                item =>
                    item.DeliveryId == deliveryId &&
                    item.RemovedAtUtc == null,
                cancellationToken);
            var makePrimary = request.IsPrimary || !hasActive;
            if (makePrimary)
            {
                var currentPrimary = await _context.DeliveryProofImages
                    .Where(item =>
                        item.DeliveryId == deliveryId &&
                        item.IsPrimary &&
                        item.RemovedAtUtc == null)
                    .ToListAsync(cancellationToken);
                foreach (var item in currentPrimary)
                {
                    item.IsPrimary = false;
                }
            }

            _context.StoredFiles.AddRange(stored.Image, stored.Thumbnail);
            var proof = new DeliveryProofImage
            {
                DeliveryId = deliveryId,
                StoredFile = stored.Image,
                ThumbnailStoredFile = stored.Thumbnail,
                UploadedAtUtc = DateTime.UtcNow,
                UploadedByUserId = userId,
                UploadedByDriverId = delivery.Driver?.UserId == userId
                    ? delivery.DriverId
                    : null,
                Caption = Clean(request.Caption, 300),
                IsPrimary = makePrimary
            };
            _context.DeliveryProofImages.Add(proof);
            await _context.SaveChangesAsync(cancellationToken);
            await AuditAsync(
                AuditActionTypes.Create,
                "UploadDeliveryProofImage",
                proof,
                "A protected delivery proof image was uploaded.",
                cancellationToken);
            return Map(proof);
        }
        catch
        {
            await _storage.DeletePhysicalAsync(
                stored.Image,
                CancellationToken.None);
            await _storage.DeletePhysicalAsync(
                stored.Thumbnail,
                CancellationToken.None);
            throw;
        }
    }

    // Recheck authorization on every read; a protected storage key is not an access token.
    public async Task<ProtectedFileReadResult> OpenAsync(
        int deliveryId,
        long imageId,
        bool thumbnail,
        int userId,
        string role,
        CancellationToken cancellationToken)
    {
        var delivery = await LoadDeliveryAsync(
            deliveryId,
            cancellationToken);
        EnsureAccess(delivery, userId, role, true);
        var proof = await _context.DeliveryProofImages
            .AsNoTracking()
            .Include(item => item.StoredFile)
            .Include(item => item.ThumbnailStoredFile)
            .SingleOrDefaultAsync(
                item =>
                    item.DeliveryProofImageId == imageId &&
                    item.DeliveryId == deliveryId &&
                    item.RemovedAtUtc == null,
                cancellationToken)
            ?? throw new DeliveryManagementException(
                404,
                "The delivery proof image was not found.");
        var stored = thumbnail
            ? proof.ThumbnailStoredFile ?? proof.StoredFile
            : proof.StoredFile;
        if (stored.IsDeleted)
        {
            throw new DeliveryManagementException(
                404,
                "The delivery proof image is unavailable.");
        }
        try
        {
            await AuditAsync(
                AuditActionTypes.ViewSensitiveRecord,
                thumbnail
                    ? "ViewDeliveryProofThumbnail"
                    : "ViewDeliveryProofImage",
                proof,
                "Protected delivery proof evidence was viewed.",
                cancellationToken);
            return new ProtectedFileReadResult(
                stored,
                _storage.OpenRead(stored));
        }
        catch (FileNotFoundException)
        {
            throw new DeliveryManagementException(
                404,
                "The delivery proof image is unavailable.");
        }
    }

    // Removal is logical first so historical completion evidence is never silently overwritten.
    public async Task RemoveAsync(
        int deliveryId,
        long imageId,
        string? reason,
        int userId,
        string role,
        bool canManage,
        CancellationToken cancellationToken)
    {
        var delivery = await LoadDeliveryAsync(
            deliveryId,
            cancellationToken);
        EnsureAccess(delivery, userId, role, canManage);
        if (delivery.Status == DeliveryStatuses.Completed)
        {
            throw new DeliveryManagementException(
                409,
                "Completed-delivery proof is immutable.");
        }
        var proof = await _context.DeliveryProofImages
            .SingleOrDefaultAsync(
                item =>
                    item.DeliveryProofImageId == imageId &&
                    item.DeliveryId == deliveryId &&
                    item.RemovedAtUtc == null,
                cancellationToken)
            ?? throw new DeliveryManagementException(
                404,
                "The delivery proof image was not found.");
        var own = proof.UploadedByUserId == userId;
        if (!own && !canManage)
        {
            throw new DeliveryManagementException(
                403,
                "Only the uploader or authorized management may remove this proof image.");
        }
        if (canManage && string.IsNullOrWhiteSpace(reason))
        {
            throw new DeliveryManagementException(
                400,
                "Management removal requires a reason.");
        }

        var removedPrimary = proof.IsPrimary;
        proof.RemovedAtUtc = DateTime.UtcNow;
        proof.RemovedByUserId = userId;
        proof.RemovalReason = own
            ? Clean(reason, 500) ?? "Removed by the uploader before completion."
            : Clean(reason, 500);
        proof.IsPrimary = false;
        if (removedPrimary)
        {
            var replacement = await _context.DeliveryProofImages
                .Where(item =>
                    item.DeliveryId == deliveryId &&
                    item.DeliveryProofImageId != imageId &&
                    item.RemovedAtUtc == null)
                .OrderBy(item => item.UploadedAtUtc)
                .FirstOrDefaultAsync(cancellationToken);
            if (replacement is not null)
            {
                replacement.IsPrimary = true;
            }
        }
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.SoftDelete,
            "RemoveDeliveryProofImage",
            proof,
            "A delivery proof image was removed before completion.",
            cancellationToken);
    }

    private async Task<Delivery> LoadDeliveryAsync(
        int deliveryId,
        CancellationToken cancellationToken) =>
        await _context.Deliveries
            .Include(item => item.Driver)
            .SingleOrDefaultAsync(
                item => item.DeliveryId == deliveryId,
                cancellationToken)
        ?? throw new DeliveryManagementException(
            404,
            "Delivery not found.");

    private static void EnsureAccess(
        Delivery delivery,
        int userId,
        string role,
        bool canManage)
    {
        if (delivery.Driver?.UserId == userId)
        {
            return;
        }
        if (role == RoleCodes.Driver || !canManage)
        {
            throw new DeliveryManagementException(
                403,
                "Drivers may access proof only for their own assigned delivery.");
        }
    }

    private async Task AuditAsync(
        string action,
        string operation,
        DeliveryProofImage proof,
        string description,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = AuditModules.DeliveryLogistics,
            OperationName = operation,
            Description = description,
            EntityType = nameof(DeliveryProofImage),
            EntityId = proof.DeliveryProofImageId.ToString(),
            EntityDisplay = $"Delivery {proof.DeliveryId} proof image",
            SafeDetails = new Dictionary<string, object?>
            {
                ["DeliveryId"] = proof.DeliveryId,
                ["IsPrimary"] = proof.IsPrimary
            }
        }, cancellationToken);

    private static DeliveryProofImageDto Map(DeliveryProofImage item) =>
        new(
            item.DeliveryProofImageId,
            item.DeliveryId,
            item.StoredFile?.SafeDownloadName ?? "proof-image",
            item.StoredFile?.ContentType ?? "image/jpeg",
            item.StoredFile?.SizeBytes ?? 0,
            item.Caption,
            item.IsPrimary,
            item.UploadedAtUtc,
            item.UploadedByUser is null
                ? "User"
                : $"{item.UploadedByUser.FirstName} {item.UploadedByUser.LastName}".Trim(),
            item.RemovedAtUtc is not null,
            item.RowVersion is null
                ? string.Empty
                : Convert.ToBase64String(item.RowVersion));

    private static string? Clean(string? value, int maximum)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }
        var clean = value.Trim();
        return clean.Length <= maximum ? clean : clean[..maximum];
    }
}
