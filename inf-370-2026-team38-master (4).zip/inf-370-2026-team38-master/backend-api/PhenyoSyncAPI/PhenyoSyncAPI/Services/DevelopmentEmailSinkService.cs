using System.Text.Json;

namespace PhenyoSyncAPI.Services;

/// <summary>
/// Explicitly enabled development-only email sink used by isolated acceptance
/// tests. It is never registered in production and must point at a disposable
/// directory that is removed after verification.
/// </summary>
public sealed class DevelopmentEmailSinkService : IEmailService
{
    private readonly string _root;

    public DevelopmentEmailSinkService(
        IConfiguration configuration,
        IWebHostEnvironment environment)
    {
        var configured = configuration[
            "EmailSettings:DevelopmentSinkPath"];
        if (string.IsNullOrWhiteSpace(configured))
        {
            throw new InvalidOperationException(
                "The development email sink path is not configured.");
        }
        _root = Path.GetFullPath(
            Path.IsPathRooted(configured)
                ? configured
                : Path.Combine(environment.ContentRootPath, configured));
        Directory.CreateDirectory(_root);
    }

    public Task SendPasswordResetEmailAsync(
        string recipientEmail,
        string resetLink) =>
        WriteAsync("password-reset", new
        {
            recipientEmail,
            resetLink
        });

    public Task SendExpiryAlertEmailAsync(
        IReadOnlyCollection<string> recipientEmails,
        ExpiryEmailModel model,
        string reviewLink,
        CancellationToken cancellationToken = default) =>
        WriteAsync("expiry-alert", new
        {
            recipientEmails,
            model.BatchCode,
            reviewLink
        }, cancellationToken);

    public Task SendExpiryDecisionConfirmationAsync(
        IReadOnlyCollection<string> recipientEmails,
        ExpiryEmailModel model,
        string decision,
        CancellationToken cancellationToken = default) =>
        WriteAsync("expiry-decision", new
        {
            recipientEmails,
            model.BatchCode,
            decision
        }, cancellationToken);

    public Task SendCustomerOrderLinkEmailAsync(
        string recipientEmail,
        string customerName,
        string orderLink,
        DateTime expiresAtUtc,
        CancellationToken cancellationToken = default) =>
        WriteAsync("order-link", new
        {
            recipientEmail,
            customerName,
            orderLink,
            expiresAtUtc
        }, cancellationToken);

    public Task SendLoginOtpEmailAsync(
        string recipientEmail,
        string recipientName,
        string otp,
        DateTime expiresAtUtc,
        CancellationToken cancellationToken = default) =>
        WriteAsync("login-otp", new
        {
            recipientEmail,
            recipientName,
            otp,
            expiresAtUtc
        }, cancellationToken);

    public Task SendRecoveryCodeUsedNotificationAsync(
        string recipientEmail,
        string recipientName,
        DateTime usedAtUtc,
        CancellationToken cancellationToken = default) =>
        WriteAsync("recovery-code-used", new
        {
            recipientEmail,
            recipientName,
            usedAtUtc
        }, cancellationToken);

    private async Task WriteAsync(
        string messageType,
        object payload,
        CancellationToken cancellationToken = default)
    {
        var envelope = new
        {
            messageType,
            capturedAtUtc = DateTime.UtcNow,
            payload
        };
        var path = Path.Combine(
            _root,
            $"{DateTime.UtcNow:yyyyMMddHHmmssfff}-{Guid.NewGuid():N}.json");
        await File.WriteAllTextAsync(
            path,
            JsonSerializer.Serialize(
                envelope,
                new JsonSerializerOptions { WriteIndented = true }),
            cancellationToken);
    }
}
