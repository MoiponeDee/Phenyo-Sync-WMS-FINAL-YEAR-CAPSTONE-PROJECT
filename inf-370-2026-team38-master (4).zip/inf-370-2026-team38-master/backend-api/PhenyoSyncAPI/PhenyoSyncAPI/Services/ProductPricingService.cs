using System.Data;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Pricing;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

/// <summary>
/// Maintains effective-dated product prices. Historical rows are preserved so
/// orders and pricing reports can explain which price was active at a date.
/// </summary>
public sealed class ProductPricingService : IProductPricingService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService? _audit;

    public ProductPricingService(
        PhenyoSyncDbContext context,
        IAuditService? audit = null)
    {
        _context = context;
        _audit = audit;
    }

    public async Task<ProductPriceResponseDto> CreateAsync(
        CreateProductPriceDto request,
        int userId,
        CancellationToken cancellationToken)
    {
        // A new effective row is inserted instead of overwriting history.
        // Overlap checks keep one unambiguous current price per product.
        ValidatePrice(request.SellingPrice);
        ValidatePriceBasis(request.PriceBasis);

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);

        var product = await _context.Products.FirstOrDefaultAsync(
            item => item.ProductId == request.ProductId,
            cancellationToken);

        if (product is null)
        {
            throw new PricingException(404, "Product not found.");
        }

        if (product.Status != ProductStatuses.Active)
        {
            throw new PricingException(409, "An inactive product cannot receive a new current price.");
        }

        var currentExists = await _context.ProductPrices.AnyAsync(
            item => item.ProductId == request.ProductId &&
                item.IsCurrent &&
                !item.IsDeleted,
            cancellationToken);

        if (currentExists)
        {
            throw new PricingException(
                409,
                "This product already has a current price. Use Update Price to create a new version.");
        }

        var now = DateTime.UtcNow;
        var effectiveFrom = EffectiveFrom(request.EffectiveFromUtc, now);
        var price = new ProductPrice
        {
            ProductId = product.ProductId,
            SellingPrice = request.SellingPrice,
            PriceBasis = request.PriceBasis,
            EffectiveFromUtc = effectiveFrom,
            IsCurrent = true,
            CreatedAtUtc = now,
            CreatedByUserId = userId,
            ChangeReason = Clean(request.Reason)
        };

        _context.ProductPrices.Add(price);
        if (effectiveFrom <= now)
        {
            product.SellingPricePerKg = price.SellingPrice;
            product.UpdatedAt = now;
        }

        try
        {
            await _context.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
        }
        catch (DbUpdateException)
        {
            throw new PricingException(
                409,
                "A current price was created by another user. Reload Pricing Management.");
        }

        await AuditPriceAsync(
            AuditActionTypes.Create,
            "Create product price",
            price,
            userId,
            null,
            cancellationToken);
        return await LoadResponseAsync(price.ProductPriceId, true, cancellationToken);
    }

    public async Task<ProductPriceChangeResponseDto> UpdateAsync(
        int productPriceId,
        UpdateProductPriceDto request,
        int userId,
        CancellationToken cancellationToken)
    {
        ValidatePrice(request.SellingPrice);
        ValidatePriceBasis(request.PriceBasis);

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);

        var current = await _context.ProductPrices
            .Include(item => item.Product)
            .FirstOrDefaultAsync(
                item => item.ProductPriceId == productPriceId,
                cancellationToken)
            ?? throw new PricingException(404, "Price record not found.");

        if (current.IsDeleted || !current.IsCurrent)
        {
            throw new PricingException(409, "Only a current, non-deleted price can be updated.");
        }

        if (current.Product.Status != ProductStatuses.Active)
        {
            throw new PricingException(409, "Reactivate the product before assigning a new current price.");
        }

        ValidateRowVersion(current.RowVersion, request.RowVersion);

        if (current.SellingPrice == request.SellingPrice &&
            current.PriceBasis == request.PriceBasis)
        {
            throw new PricingException(
                409,
                "The new price is the same as the current price. No history version was created.");
        }

        var previous = await LoadResponseAsync(current.ProductPriceId, true, cancellationToken);
        var now = DateTime.UtcNow;
        var effectiveFrom = EffectiveFrom(request.EffectiveFromUtc, now);
        if (effectiveFrom <= current.EffectiveFromUtc)
        {
            throw new PricingException(
                409,
                "The replacement price must start after the current price began.");
        }
        current.IsCurrent = false;
        current.EffectiveToUtc = effectiveFrom;

        var replacement = new ProductPrice
        {
            ProductId = current.ProductId,
            SellingPrice = request.SellingPrice,
            PriceBasis = request.PriceBasis,
            EffectiveFromUtc = effectiveFrom,
            IsCurrent = true,
            CreatedAtUtc = now,
            CreatedByUserId = userId,
            ChangeReason = Clean(request.ChangeReason)
        };

        _context.ProductPrices.Add(replacement);
        if (effectiveFrom <= now)
        {
            current.Product.SellingPricePerKg = replacement.SellingPrice;
            current.Product.UpdatedAt = now;
        }

        try
        {
            await _context.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new PricingException(
                409,
                "This price was changed by another user. Reload it before saving.");
        }
        catch (DbUpdateException)
        {
            throw new PricingException(
                409,
                "Another current price already exists. Reload Pricing Management.");
        }

        await AuditPriceAsync(
            AuditActionTypes.Update,
            "Create replacement price version",
            replacement,
            userId,
            previous.SellingPrice,
            cancellationToken);
        return new ProductPriceChangeResponseDto
        {
            Message = "Price updated. The previous price remains in history.",
            PreviousPrice = previous,
            CurrentPrice = await LoadResponseAsync(
                replacement.ProductPriceId,
                true,
                cancellationToken)
        };
    }

    public async Task<ProductPricePageDto> SearchAsync(
        ProductPriceSearchDto request,
        bool mayViewDeleted,
        CancellationToken cancellationToken)
    {
        ValidateSearch(request, mayViewDeleted);

        var page = Math.Max(1, request.Page);
        var pageSize = Math.Clamp(request.PageSize, 1, 100);
        var query = _context.ProductPrices.AsNoTracking().AsQueryable();

        if (!mayViewDeleted)
        {
            query = query.Where(item => !item.IsDeleted);
        }

        if (!string.IsNullOrWhiteSpace(request.SearchTerm))
        {
            var term = request.SearchTerm.Trim();
            query = query.Where(item =>
                item.Product.ProductName.Contains(term) ||
                item.Product.Size.Contains(term) ||
                (item.Product.QRCodeValue != null && item.Product.QRCodeValue.Contains(term)) ||
                item.Product.ProductType!.ProductTypeName.Contains(term) ||
                item.Product.ProductCategory!.ProductCategoryName.Contains(term) ||
                item.ProductPriceId.ToString() == term);
        }

        if (request.ProductId.HasValue)
            query = query.Where(item => item.ProductId == request.ProductId.Value);
        if (request.ProductTypeId.HasValue)
            query = query.Where(item => item.Product.ProductTypeId == request.ProductTypeId.Value);
        if (request.ProductCategoryId.HasValue)
            query = query.Where(item => item.Product.ProductCategoryId == request.ProductCategoryId.Value);
        if (request.MinimumPrice.HasValue)
            query = query.Where(item => item.SellingPrice >= request.MinimumPrice.Value);
        if (request.MaximumPrice.HasValue)
            query = query.Where(item => item.SellingPrice <= request.MaximumPrice.Value);
        if (request.EffectiveFromUtc.HasValue)
            query = query.Where(item => item.EffectiveFromUtc >= request.EffectiveFromUtc.Value);
        if (request.EffectiveToUtc.HasValue)
            query = query.Where(item => item.EffectiveFromUtc <= request.EffectiveToUtc.Value);

        var now = DateTime.UtcNow;
        query = request.Status.ToUpperInvariant() switch
        {
            "CURRENT" => query.Where(item =>
                !item.IsDeleted &&
                item.EffectiveFromUtc <= now &&
                (item.EffectiveToUtc == null || item.EffectiveToUtc > now)),
            "HISTORICAL" => query.Where(item =>
                !item.IsDeleted &&
                item.EffectiveToUtc != null &&
                item.EffectiveToUtc <= now),
            "SCHEDULED" => query.Where(item =>
                !item.IsDeleted &&
                item.EffectiveFromUtc > now),
            "DELETED" => query.Where(item => item.IsDeleted),
            _ => query
        };

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await Project(query)
            .OrderByDescending(item => item.IsCurrent)
            .ThenBy(item => item.ProductName)
            .ThenBy(item => item.Size)
            .ThenByDescending(item => item.EffectiveFromUtc)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);

        return new ProductPricePageDto
        {
            Items = items,
            Page = page,
            PageSize = pageSize,
            TotalCount = totalCount,
            TotalPages = totalCount == 0
                ? 0
                : (int)Math.Ceiling(totalCount / (double)pageSize)
        };
    }

    public async Task<ProductPriceResponseDto> GetAsync(
        int productPriceId,
        bool mayViewDeleted,
        CancellationToken cancellationToken)
    {
        var result = await Project(_context.ProductPrices.AsNoTracking())
            .FirstOrDefaultAsync(
                item => item.ProductPriceId == productPriceId,
                cancellationToken)
            ?? throw new PricingException(404, "Price record not found.");

        if (result.IsDeleted && !mayViewDeleted)
        {
            throw new PricingException(404, "Price record not found.");
        }

        return result;
    }

    public async Task<List<ProductPriceResponseDto>> GetHistoryAsync(
        int productId,
        bool mayViewDeleted,
        CancellationToken cancellationToken)
    {
        var productExists = await _context.Products.AsNoTracking().AnyAsync(
            item => item.ProductId == productId,
            cancellationToken);

        if (!productExists)
        {
            throw new PricingException(404, "Product not found.");
        }

        var query = _context.ProductPrices.AsNoTracking()
            .Where(item => item.ProductId == productId);

        if (!mayViewDeleted)
        {
            query = query.Where(item => !item.IsDeleted);
        }

        return await Project(query)
            .OrderByDescending(item => item.EffectiveFromUtc)
            .ToListAsync(cancellationToken);
    }

    public async Task<ProductPriceResponseDto> SoftDeleteAsync(
        int productPriceId,
        DeleteProductPriceDto request,
        int userId,
        CancellationToken cancellationToken)
    {
        if (!request.Confirmed)
        {
            throw new PricingException(400, "Explicit deletion confirmation is required.");
        }

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);

        var price = await _context.ProductPrices
            .Include(item => item.Product)
            .FirstOrDefaultAsync(
                item => item.ProductPriceId == productPriceId,
                cancellationToken)
            ?? throw new PricingException(404, "Price record not found.");

        if (price.IsDeleted)
        {
            throw new PricingException(409, "This price record is already soft deleted.");
        }

        if (price.IsCurrent && price.Product.Status == ProductStatuses.Active)
        {
            throw new PricingException(
                409,
                "The current price for an active product cannot be deleted. Create a replacement price or deactivate the product first.",
                "DELETE_NOT_ALLOWED");
        }

        var isUsed = await _context.SalesOrderItems.AsNoTracking()
            .AnyAsync(item =>
                item.ProductPriceId == price.ProductPriceId,
                cancellationToken);

        if (isUsed)
        {
            throw new PricingException(
                409,
                "This price is part of Sales Order history and cannot be deleted.",
                "DELETE_NOT_ALLOWED");
        }

        var now = DateTime.UtcNow;
        price.IsDeleted = true;
        price.DeletedAtUtc = now;
        price.DeletedByUserId = userId;
        price.DeleteReason = request.Reason.Trim();

        if (price.IsCurrent)
        {
            price.IsCurrent = false;
            price.EffectiveToUtc = now;
            price.Product.SellingPricePerKg = 0;
            price.Product.UpdatedAt = now;
        }

        await _context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        await AuditPriceAsync(
            AuditActionTypes.SoftDelete,
            "Soft delete product price",
            price,
            userId,
            price.SellingPrice,
            cancellationToken);
        return await LoadResponseAsync(price.ProductPriceId, true, cancellationToken);
    }

    public async Task<IReadOnlyDictionary<int, ProductPrice>> GetCurrentPricesForProductsAsync(
        IReadOnlyCollection<int> productIds,
        CancellationToken cancellationToken)
    {
        // Resolve all requested products at the same timestamp so one order
        // cannot mix prices selected at slightly different effective instants.
        if (productIds.Count == 0)
        {
            return new Dictionary<int, ProductPrice>();
        }

        var uniqueIds = productIds.Distinct().ToArray();
        var now = DateTime.UtcNow;
        return await _context.ProductPrices.AsNoTracking()
            .Include(item => item.Product)
            .Where(item =>
                uniqueIds.Contains(item.ProductId) &&
                !item.IsDeleted &&
                item.EffectiveFromUtc <= now &&
                (item.EffectiveToUtc == null || item.EffectiveToUtc > now) &&
                item.Product.Status == ProductStatuses.Active)
            .ToDictionaryAsync(item => item.ProductId, cancellationToken);
    }

    public Task<List<OrderableProductPriceDto>> GetOrderableProductsAsync(
        CancellationToken cancellationToken)
    {
        var now = DateTime.UtcNow;
        return _context.ProductPrices.AsNoTracking()
            .Where(item =>
                !item.IsDeleted &&
                item.EffectiveFromUtc <= now &&
                (item.EffectiveToUtc == null || item.EffectiveToUtc > now) &&
                item.Product.Status == ProductStatuses.Active)
            .OrderBy(item => item.Product.ProductName)
            .ThenBy(item => item.Product.Size)
            .Select(item => new OrderableProductPriceDto
            {
                ProductId = item.ProductId,
                ProductPriceId = item.ProductPriceId,
                ProductCode = item.Product.QRCodeValue ?? ("PRODUCT-" + item.ProductId),
                ProductName = item.Product.ProductName,
                ProductTypeName = item.Product.ProductType!.ProductTypeName,
                ProductCategoryName = item.Product.ProductCategory!.ProductCategoryName,
                Size = item.Product.Size,
                SellingPrice = item.SellingPrice,
                PriceBasis = item.PriceBasis,
                SellingUnit = item.Product.SellingUnit,
                KilogramsPerUnit = item.Product.KilogramsPerUnit,
                IsVariableWeight = item.Product.IsVariableWeight,
                SellingPricePerUnit = item.PriceBasis == ProductPriceBases.PerSellableUnit
                    ? item.SellingPrice
                    : item.Product.IsVariableWeight
                        ? item.SellingPrice
                        : item.Product.KilogramsPerUnit.HasValue
                            ? item.SellingPrice * item.Product.KilogramsPerUnit.Value
                            : null,
                AvailableQuantityKg =
                    (item.Product.Stocks.Sum(stock => (decimal?)stock.QuantityAvailableKg) ?? 0) -
                    (item.Product.OrderStockReservations
                        .Where(reservation =>
                            reservation.Status == OrderReservationStatuses.Active)
                        .Sum(reservation => (decimal?)reservation.QuantityReservedKg) ?? 0)
            })
            .ToListAsync(cancellationToken);
    }

    private async Task<ProductPriceResponseDto> LoadResponseAsync(
        int productPriceId,
        bool mayViewDeleted,
        CancellationToken cancellationToken)
    {
        return await GetAsync(productPriceId, mayViewDeleted, cancellationToken);
    }

    private static IQueryable<ProductPriceResponseDto> Project(
        IQueryable<ProductPrice> query)
    {
        var now = DateTime.UtcNow;
        return query.Select(item => new ProductPriceResponseDto
        {
            ProductPriceId = item.ProductPriceId,
            ProductId = item.ProductId,
            ProductCode = item.Product.QRCodeValue ?? ("PRODUCT-" + item.ProductId),
            ProductName = item.Product.ProductName,
            ProductTypeName = item.Product.ProductType!.ProductTypeName,
            ProductCategoryName = item.Product.ProductCategory!.ProductCategoryName,
            Size = item.Product.Size,
            ProductStatus = item.Product.Status,
            SellingPrice = item.SellingPrice,
            PriceBasis = item.PriceBasis,
            EffectiveFromUtc = item.EffectiveFromUtc,
            EffectiveToUtc = item.EffectiveToUtc,
            IsCurrent = !item.IsDeleted &&
                item.EffectiveFromUtc <= now &&
                (item.EffectiveToUtc == null || item.EffectiveToUtc > now),
            IsScheduled = !item.IsDeleted && item.EffectiveFromUtc > now,
            IsDeleted = item.IsDeleted,
            CreatedAtUtc = item.CreatedAtUtc,
            CreatedBy = item.CreatedByUser == null
                ? null
                : item.CreatedByUser.FirstName + " " + item.CreatedByUser.LastName,
            ChangeReason = item.ChangeReason,
            DeletedAtUtc = item.DeletedAtUtc,
            DeletedBy = item.DeletedByUser == null
                ? null
                : item.DeletedByUser.FirstName + " " + item.DeletedByUser.LastName,
            DeleteReason = item.DeleteReason,
            LinkedOrderCount = item.SalesOrderItems.Count,
            IsCommitted = item.SalesOrderItems.Any(),
            CanSoftDelete = !item.IsCurrent && !item.SalesOrderItems.Any(),
            DeleteBlockedReason = item.IsCurrent
                ? "Current prices must be replaced before they can be removed."
                : item.SalesOrderItems.Any()
                    ? "Used prices are retained as immutable Sales Order history."
                    : null,
            RowVersion = item.RowVersion == null
                ? string.Empty
                : Convert.ToBase64String(item.RowVersion)
        });
    }

    private static void ValidatePriceBasis(string priceBasis)
    {
        if (!ProductPriceBases.IsValid(priceBasis))
            throw new PricingException(400, "Price basis must be PerKilogram or PerSellableUnit.");
    }

    private static void ValidatePrice(decimal price)
    {
        if (price <= 0)
        {
            throw new PricingException(400, "Selling price must be greater than zero.");
        }

        if (decimal.Round(price, 2, MidpointRounding.AwayFromZero) != price)
        {
            throw new PricingException(400, "Selling price may contain no more than two decimal places.");
        }
    }

    private static void ValidateSearch(
        ProductPriceSearchDto request,
        bool mayViewDeleted)
    {
        if (!PriceRecordStatuses.AllValues.Contains(request.Status))
        {
            throw new PricingException(
                400,
                "Price status must be Current, Scheduled, Historical, Deleted, or All.");
        }

        if (!mayViewDeleted &&
            (request.Status.Equals(PriceRecordStatuses.Deleted, StringComparison.OrdinalIgnoreCase) ||
             request.Status.Equals(PriceRecordStatuses.All, StringComparison.OrdinalIgnoreCase)))
        {
            throw new PricingException(403, "Only pricing managers may view soft-deleted price history.");
        }

        if (request.ProductId is < 1 ||
            request.ProductTypeId is < 1 ||
            request.ProductCategoryId is < 1)
        {
            throw new PricingException(400, "Product and lookup IDs must be greater than zero.");
        }

        if (request.MinimumPrice is < 0 || request.MaximumPrice is < 0)
        {
            throw new PricingException(400, "Price filters cannot be negative.");
        }

        if (request.MinimumPrice.HasValue &&
            request.MaximumPrice.HasValue &&
            request.MinimumPrice.Value > request.MaximumPrice.Value)
        {
            throw new PricingException(400, "Minimum price cannot exceed maximum price.");
        }

        if (request.EffectiveFromUtc.HasValue &&
            request.EffectiveToUtc.HasValue &&
            request.EffectiveFromUtc.Value > request.EffectiveToUtc.Value)
        {
            throw new PricingException(400, "Effective-from date cannot be after effective-to date.");
        }
    }

    private static void ValidateRowVersion(
        byte[]? current,
        string? supplied)
    {
        if (string.IsNullOrWhiteSpace(supplied) || current is null)
        {
            return;
        }

        byte[] expected;
        try
        {
            expected = Convert.FromBase64String(supplied);
        }
        catch (FormatException)
        {
            throw new PricingException(400, "The price concurrency token is invalid.");
        }

        if (!CryptographicOperations.FixedTimeEquals(current, expected))
        {
            throw new PricingException(
                409,
                "This price was changed by another user. Reload it before saving.");
        }
    }

    private static string? Clean(string? value)
    {
        return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
    }

    private static DateTime EffectiveFrom(DateTime? supplied, DateTime now)
    {
        if (!supplied.HasValue)
            return now;

        var value = supplied.Value.Kind == DateTimeKind.Utc
            ? supplied.Value
            : supplied.Value.ToUniversalTime();
        if (value < now.AddMinutes(-5))
        {
            throw new PricingException(
                400,
                "The effective date cannot be in the past.");
        }

        return value;
    }

    private Task AuditPriceAsync(
        string actionType,
        string operation,
        ProductPrice price,
        int userId,
        decimal? previousPrice,
        CancellationToken cancellationToken)
    {
        if (_audit is null)
            return Task.CompletedTask;

        return _audit.RecordAsync(new AuditEvent
        {
            ActionType = actionType,
            SystemModule = AuditModules.Pricing,
            OperationName = operation,
            Description = $"{operation} for Product #{price.ProductId}.",
            EntityType = nameof(ProductPrice),
            EntityId = price.ProductPriceId.ToString(),
            EntityDisplay = $"Product #{price.ProductId} price",
            UserId = userId,
            SafeDetails = new Dictionary<string, object?>
            {
                ["productId"] = price.ProductId,
                ["previousPrice"] = previousPrice,
                ["newPrice"] = price.SellingPrice,
                ["effectiveFromUtc"] = price.EffectiveFromUtc,
                ["effectiveToUtc"] = price.EffectiveToUtc,
                ["reason"] = price.ChangeReason ?? price.DeleteReason
            }
        }, cancellationToken);
    }
}
