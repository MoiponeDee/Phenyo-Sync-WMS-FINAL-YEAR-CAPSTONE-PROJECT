using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Procurement;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IProcurementPlanningService
{
    Task<IReadOnlyList<ProductRawStockRequirementDto>> RequirementsAsync(
        int productId,
        bool includeInactive,
        CancellationToken cancellationToken);

    Task<ProductRawStockRequirementDto> SaveRequirementAsync(
        int productId,
        int? requirementId,
        SaveProductRawStockRequirementRequest request,
        int actorUserId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<ProcurementShortageSuggestionDto>> ShortagesAsync(
        CancellationToken cancellationToken);

    Task<IReadOnlyList<UnmappedProductDemandDto>> UnmappedDemandAsync(
        CancellationToken cancellationToken);
}

/// <summary>
/// Converts approved finished-product shortage into recipe-based raw-material
/// demand, then subtracts usable raw stock and valid outstanding procurement.
/// Pending Validation orders deliberately contribute zero demand.
/// </summary>
public sealed class ProcurementPlanningService : IProcurementPlanningService
{
    private static readonly string[] UnfulfilledOrderStatuses =
    [
        SalesOrderStatuses.Approved,
        SalesOrderStatuses.Confirmed,
        SalesOrderStatuses.Packing,
        SalesOrderStatuses.Packed,
        SalesOrderStatuses.ReadyForDispatch,
        SalesOrderStatuses.OutForDelivery
    ];

    private static readonly string[] ActiveBuyingListStatuses =
    [
        BuyingListStatuses.Draft,
        BuyingListStatuses.Open,
        BuyingListStatuses.InProgress,
        BuyingListStatuses.Submitted,
        BuyingListStatuses.PartiallyReceived
    ];

    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _audit;

    public ProcurementPlanningService(
        PhenyoSyncDbContext context,
        IAuditService audit)
    {
        _context = context;
        _audit = audit;
    }

    public async Task<IReadOnlyList<ProductRawStockRequirementDto>>
        RequirementsAsync(
            int productId,
            bool includeInactive,
            CancellationToken cancellationToken)
    {
        var query = _context.ProductRawStockRequirements
            .AsNoTracking()
            .Include(item => item.Product)
            .Include(item => item.RawStockItem)
            .Where(item => item.ProductId == productId);

        if (!includeInactive)
            query = query.Where(item => item.IsActive);

        var items = await query
            .OrderBy(item => item.RawStockItem.ItemName)
            .ToListAsync(cancellationToken);

        return items
            .Select(MapRequirement)
            .ToArray();
    }

    public async Task<ProductRawStockRequirementDto> SaveRequirementAsync(
        int productId,
        int? requirementId,
        SaveProductRawStockRequirementRequest request,
        int actorUserId,
        CancellationToken cancellationToken)
    {
        if (!await _context.Products.AnyAsync(
                item => item.ProductId == productId,
                cancellationToken))
            throw new PhaseCException(404, "Product not found.");

        var rawStock = await _context.RawStockItems.SingleOrDefaultAsync(
                item => item.RawStockItemId == request.RawStockItemId &&
                        item.IsActive,
                cancellationToken)
            ?? throw new PhaseCException(
                400,
                "Select an active Raw Stock item.");

        var unit = request.UnitOfMeasure.Trim().ToLowerInvariant();

        if (!unit.Equals(
                rawStock.DefaultUnitOfMeasure,
                StringComparison.OrdinalIgnoreCase))
            throw new PhaseCException(
                400,
                $"The unit must be {rawStock.DefaultUnitOfMeasure} for {rawStock.ItemName}.");

        var duplicate = await _context.ProductRawStockRequirements.AnyAsync(
            item => item.ProductId == productId &&
                    item.RawStockItemId == request.RawStockItemId &&
                    item.ProductRawStockRequirementId != requirementId,
            cancellationToken);

        if (duplicate)
            throw new PhaseCException(
                409,
                "This Raw Stock item is already mapped to the Product.");

        var now = DateTime.UtcNow;
        ProductRawStockRequirement item;

        if (requirementId.HasValue)
        {
            item = await _context.ProductRawStockRequirements
                .SingleOrDefaultAsync(
                    value => value.ProductRawStockRequirementId ==
                             requirementId.Value &&
                             value.ProductId == productId,
                    cancellationToken)
                ?? throw new PhaseCException(
                    404,
                    "Raw Stock requirement not found.");

            ValidateVersion(item.RowVersion, request.RowVersion);

            item.RawStockItemId = request.RawStockItemId;
            item.UpdatedByUserId = actorUserId;
            item.UpdatedAtUtc = now;
        }
        else
        {
            item = new ProductRawStockRequirement
            {
                ProductId = productId,
                RawStockItemId = request.RawStockItemId,
                CreatedByUserId = actorUserId,
                CreatedAtUtc = now
            };

            _context.ProductRawStockRequirements.Add(item);
        }

        item.RawQuantityPerProductUnit =
            request.RawQuantityPerProductUnit;

        item.UnitOfMeasure = unit;
        item.WastePercentage = request.WastePercentage;
        item.YieldPercentage = request.YieldPercentage;
        item.IsActive = request.IsActive;

        await _context.SaveChangesAsync(cancellationToken);

        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = requirementId.HasValue
                ? AuditActionTypes.Update
                : AuditActionTypes.Create,

            SystemModule = AuditModules.ProductManagement,

            OperationName = requirementId.HasValue
                ? "Update product Raw Stock requirement"
                : "Create product Raw Stock requirement",

            Description =
                "A quantitative Product-to-Raw-Stock requirement was saved.",

            EntityType = nameof(ProductRawStockRequirement),

            EntityId =
                item.ProductRawStockRequirementId.ToString(),

            EntityDisplay =
                $"Product {productId} / Raw Stock {request.RawStockItemId}",

            UserId = actorUserId,
            Success = true,

            EventSource =
                AuditEventSources.BusinessEvent,

            SafeDetails = new Dictionary<string, object?>
            {
                ["productId"] = productId,
                ["rawStockItemId"] = request.RawStockItemId,
                ["quantityPerUnit"] =
                    request.RawQuantityPerProductUnit,
                ["wastePercentage"] =
                    request.WastePercentage,
                ["yieldPercentage"] =
                    request.YieldPercentage
            }
        }, cancellationToken);

        var savedItem =
            await _context.ProductRawStockRequirements
                .AsNoTracking()
                .Include(value => value.Product)
                .Include(value => value.RawStockItem)
                .SingleAsync(
                    value =>
                        value.ProductRawStockRequirementId ==
                        item.ProductRawStockRequirementId,
                    cancellationToken);

        return MapRequirement(savedItem);
    }

    public async Task<IReadOnlyList<ProcurementShortageSuggestionDto>>
        ShortagesAsync(CancellationToken cancellationToken)
    {
        // The status list contains only approved operational work. Pending
        // Validation rows are excluded before demand is grouped by product.
        var demandRows = await _context.SalesOrderItems
            .AsNoTracking()
            .Where(item =>
                item.IsActive &&
                UnfulfilledOrderStatuses.Contains(
                    item.SalesOrder.Status))
            .Select(item => new
            {
                item.ProductId,
                Quantity = item.QuantityKg
            })
            .ToListAsync(cancellationToken);

        var demand = demandRows
            .GroupBy(item => item.ProductId)
            .ToDictionary(
                group => group.Key,
                group => group.Sum(item => item.Quantity));

        if (demand.Count == 0)
            return [];

        var productIds = demand.Keys.ToArray();

        var finishedStockRows = await _context.Stocks
            .AsNoTracking()
            .Where(item => productIds.Contains(item.ProductId))
            .Select(item => new
            {
                item.ProductId,
                Quantity = item.QuantityAvailableKg
            })
            .ToListAsync(cancellationToken);

        var finishedStock = finishedStockRows
            .GroupBy(item => item.ProductId)
            .ToDictionary(
                group => group.Key,
                group => group.Sum(item => item.Quantity));

        // Recipe demand is calculated later from the finished shortage, not the
        // full sales demand, because on-hand finished stock already covers part.

        var requirements =
            await _context.ProductRawStockRequirements
                .AsNoTracking()
                .Where(item =>
                    item.IsActive &&
                    productIds.Contains(item.ProductId))
                .Select(item => new
                {
                    item.ProductId,
                    ProductName =
                        item.Product.ProductName,

                    item.RawStockItemId,
                    item.RawStockItem.ItemCode,
                    item.RawStockItem.ItemName,
                    item.RawStockItem.DefaultUnitOfMeasure,

                    item.RawQuantityPerProductUnit,
                    item.WastePercentage,
                    item.YieldPercentage
                })
                .ToListAsync(cancellationToken);

        var rawIds = requirements
            .Select(item => item.RawStockItemId)
            .Distinct()
            .ToArray();

        var rawBalanceRows = await _context.RawStockBalances
            .AsNoTracking()
            .Where(item =>
                rawIds.Contains(item.RawStockItemId))
            .Select(item => new
            {
                item.RawStockItemId,
                item.QuantityOnHand,
                item.ReservedQuantity
            })
            .ToListAsync(cancellationToken);

        var rawBalances = rawBalanceRows
            .GroupBy(item => item.RawStockItemId)
            .ToDictionary(
                group => group.Key,
                group => new
                {
                    QuantityOnHand = group.Sum(item => item.QuantityOnHand),
                    ReservedQuantity = group.Sum(item => item.ReservedQuantity)
                });

        var now = DateTime.UtcNow;
        var usableBatchRows = await _context.RawStockBatches
            .AsNoTracking()
            .Where(item =>
                rawIds.Contains(item.RawStockItemId) &&
                item.Status == ProductBatchStatuses.Available &&
                item.QuantityRemaining > 0m &&
                (!item.BestBeforeAtUtc.HasValue ||
                 item.BestBeforeAtUtc.Value > now))
            .Select(item => new
            {
                item.RawStockItemId,
                Quantity = item.QuantityRemaining
            })
            .ToListAsync(cancellationToken);

        var usableBatchQuantities = usableBatchRows
            .GroupBy(item => item.RawStockItemId)
            .ToDictionary(
                group => group.Key,
                group => group.Sum(item => item.Quantity));

        var rawStock = rawIds.ToDictionary(
            rawStockItemId => rawStockItemId,
            rawStockItemId =>
            {
                var balance = rawBalances.GetValueOrDefault(rawStockItemId);
                var netBalance = balance == null
                    ? 0m
                    : Math.Max(
                        0m,
                        balance.QuantityOnHand - balance.ReservedQuantity);
                var eligibleBatches = Math.Max(
                    0m,
                    usableBatchQuantities.GetValueOrDefault(rawStockItemId));
                return Math.Min(netBalance, eligibleBatches);
            });

        var supplierOutstandingRows =
            await _context.SupplierOrderLines
                .AsNoTracking()
                .Where(item =>
                    rawIds.Contains(item.RawStockItemId) &&
                    SupplierOrderStatuses.Receivable.Contains(
                        item.SupplierOrder.Status))
                .Select(item => new
                {
                    item.RawStockItemId,
                    Quantity = item.OrderedQuantity -
                               item.ReceivedQuantity > 0m
                        ? item.OrderedQuantity - item.ReceivedQuantity
                        : 0m
                })
                .ToListAsync(cancellationToken);

        var supplierOutstanding = supplierOutstandingRows
            .GroupBy(item => item.RawStockItemId)
            .ToDictionary(
                group => group.Key,
                group => group.Sum(item => item.Quantity));

        var buyingOutstandingRows =
            await _context.BuyerProcurementItems
                .AsNoTracking()
                .Where(item =>
                    item.RawStockItemId.HasValue &&
                    rawIds.Contains(
                        item.RawStockItemId.Value) &&
                    ActiveBuyingListStatuses.Contains(
                        item.BuyerProcurement.Status) &&
                    item.Status !=
                    BuyingItemStatuses.Cancelled)
                .Select(item => new
                {
                    RawStockItemId = item.RawStockItemId!.Value,
                    Quantity = (item.ActualQuantity ??
                                item.RequiredQuantity) -
                               item.ReceivedQuantity > 0m
                        ? (item.ActualQuantity ?? item.RequiredQuantity) -
                          item.ReceivedQuantity
                        : 0m
                })
                .ToListAsync(cancellationToken);

        var buyingOutstanding = buyingOutstandingRows
            .GroupBy(item => item.RawStockItemId)
            .ToDictionary(
                group => group.Key,
                group => group.Sum(item => item.Quantity));

        return requirements
            .Select(item =>
            {
                // Active reservations belong to the same unfulfilled demand above.
                // Subtracting them from stock here counts them twice and inflates the
                // finished-product (and therefore raw-stock) shortage.
                var finishedAvailable = Math.Max(
                    0,
                    finishedStock.GetValueOrDefault(
                        item.ProductId));

                var shortage = Math.Max(
                    0,
                    demand[item.ProductId] -
                    finishedAvailable);

                var yieldFactor =
                    item.YieldPercentage / 100m;

                var wasteFactor =
                    1m + item.WastePercentage / 100m;

                var rawRequired = yieldFactor <= 0
                    ? 0
                    : shortage *
                      item.RawQuantityPerProductUnit *
                      wasteFactor /
                      yieldFactor;

                return new
                {
                    Requirement = item,

                    Breakdown =
                        new ProcurementDemandBreakdownDto
                        {
                            ProductId =
                                item.ProductId,

                            ProductName =
                                item.ProductName,

                            UnfulfilledDemand =
                                demand[item.ProductId],

                            FinishedStockAvailable =
                                finishedAvailable,

                            FinishedProductShortage =
                                shortage,

                            RawQuantityPerProductUnit =
                                item.RawQuantityPerProductUnit,

                            WastePercentage =
                                item.WastePercentage,

                            YieldPercentage =
                                item.YieldPercentage,

                            RawQuantityRequired =
                                rawRequired
                        }
                };
            })
            .Where(item =>
                item.Breakdown.RawQuantityRequired > 0)
            .GroupBy(item => new
            {
                item.Requirement.RawStockItemId,
                item.Requirement.ItemCode,
                item.Requirement.ItemName,
                item.Requirement.DefaultUnitOfMeasure
            })
            .Select(group =>
            {
                var gross = group.Sum(item =>
                    item.Breakdown.RawQuantityRequired);

                var usable =
                    rawStock.GetValueOrDefault(
                        group.Key.RawStockItemId);

                var supplier = Math.Max(
                    0,
                    supplierOutstanding.GetValueOrDefault(
                        group.Key.RawStockItemId));

                var buying = Math.Max(
                    0,
                    buyingOutstanding.GetValueOrDefault(
                        group.Key.RawStockItemId));

                return new ProcurementShortageSuggestionDto
                {
                    RawStockItemId =
                        group.Key.RawStockItemId,

                    ItemCode =
                        group.Key.ItemCode,

                    ItemName =
                        group.Key.ItemName,

                    UnitOfMeasure =
                        group.Key.DefaultUnitOfMeasure,

                    GrossRawRequirement =
                        gross,

                    UsableRawStock =
                        usable,

                    SupplierOrderOutstanding =
                        supplier,

                    BuyingListOutstanding =
                        buying,

                    SuggestedPurchaseQuantity =
                        Math.Max(
                            0,
                            gross -
                            usable -
                            supplier -
                            buying),

                    DemandBreakdown = group
                        .Select(item =>
                            item.Breakdown)
                        .OrderBy(item =>
                            item.ProductName)
                        .ToArray()
                };
            })
            .Where(item =>
                item.SuggestedPurchaseQuantity > 0)
            .OrderByDescending(item =>
                item.SuggestedPurchaseQuantity)
            .ThenBy(item => item.ItemName)
            .ToArray();
    }

    public async Task<IReadOnlyList<UnmappedProductDemandDto>>
        UnmappedDemandAsync(
            CancellationToken cancellationToken) =>
        await _context.SalesOrderItems
            .AsNoTracking()
            .Where(item =>
                item.IsActive &&
                UnfulfilledOrderStatuses.Contains(
                    item.SalesOrder.Status) &&
                !_context.ProductRawStockRequirements.Any(
                    requirement =>
                        requirement.ProductId ==
                        item.ProductId &&
                        requirement.IsActive))
            .GroupBy(item => new
            {
                item.ProductId,
                item.Product.ProductName
            })
            .Select(group =>
                new UnmappedProductDemandDto
                {
                    ProductId =
                        group.Key.ProductId,

                    ProductName =
                        group.Key.ProductName,

                    UnfulfilledDemand =
                        group.Sum(
                            item => item.QuantityKg),

                    Guidance =
                        "Product-to-Raw-Stock mapping required before a procurement suggestion can be calculated."
                })
            .OrderBy(item => item.ProductName)
            .ToListAsync(cancellationToken);

    private static ProductRawStockRequirementDto
        MapRequirement(
            ProductRawStockRequirement item) => new()
            {
                ProductRawStockRequirementId =
                item.ProductRawStockRequirementId,

                ProductId =
                item.ProductId,

                ProductName =
                item.Product?.ProductName ??
                "Unknown Product",

                RawStockItemId =
                item.RawStockItemId,

                RawStockItemCode =
                item.RawStockItem?.ItemCode ??
                string.Empty,

                RawStockItemName =
                item.RawStockItem?.ItemName ??
                "Unknown Raw Stock",

                RawQuantityPerProductUnit =
                item.RawQuantityPerProductUnit,

                UnitOfMeasure =
                item.UnitOfMeasure,

                WastePercentage =
                item.WastePercentage,

                YieldPercentage =
                item.YieldPercentage,

                IsActive =
                item.IsActive,

                RowVersion = item.RowVersion is null
                ? string.Empty
                : Convert.ToBase64String(
                    item.RowVersion)
            };

    private static void ValidateVersion(
        byte[]? current,
        string? supplied)
    {
        if (current is null ||
            string.IsNullOrWhiteSpace(supplied))
            return;

        byte[] parsed;

        try
        {
            parsed =
                Convert.FromBase64String(supplied);
        }
        catch (FormatException)
        {
            throw new PhaseCException(
                400,
                "The record version is invalid.");
        }

        if (!current.SequenceEqual(parsed))
            throw new PhaseCException(
                409,
                "This requirement changed after it was opened. Refresh and try again.");
    }
}
