using PhenyoSyncAPI.DTOs.Order;

namespace PhenyoSyncAPI.Services;

public interface IOrderLinkService
{
    Task<OrderLinkDto> SendAsync(int customerId, int userId, CancellationToken cancellationToken);
    Task<List<OrderLinkDto>> ListAsync(CancellationToken cancellationToken);
    Task<OrderLinkDto> RevokeAsync(long linkId, CancellationToken cancellationToken);
    Task<OrderLinkDto> ResendAsync(long linkId, int userId, CancellationToken cancellationToken);
    Task<PublicOrderLinkValidationDto> ValidateAsync(string token, CancellationToken cancellationToken);
    Task<SalesOrderDetailDto> SubmitAsync(PublicCreateSalesOrderDto request, CancellationToken cancellationToken);
}
