using System.Data;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IStockCountJsonExchangeService
{
    GeneratedExchangeFile Schema();

    GeneratedExchangeFile Sample();

    Task<GeneratedExchangeFile> ExportAsync(
        StockCountExportQueryDto query,
        int userId,
        CancellationToken cancellationToken);

    Task<DataExchangeValidationResponseDto> ValidateAsync(
        IFormFile file,
        int userId,
        string correlationId,
        CancellationToken cancellationToken);

    Task<DataExchangeApplyResponseDto> ImportAsync(
        string validationToken,
        ApplyDataExchangeRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task<GeneratedExchangeFile> ResultAsync(
        string resultToken,
        int userId,
        CancellationToken cancellationToken);
}

/// <summary>Validates offline stock-count files before applying controlled inventory adjustments.</summary>
public sealed class StockCountJsonExchangeService
    : IStockCountJsonExchangeService
{
    public const string SchemaVersion = "2.0";
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };

    private readonly PhenyoSyncDbContext _context;
    private readonly IDataExchangeJobService _jobs;
    private readonly ISystemSettingProvider _settings;
    private readonly IAuditService _audit;

    public StockCountJsonExchangeService(
        PhenyoSyncDbContext context,
        IDataExchangeJobService jobs,
        ISystemSettingProvider settings,
        IAuditService audit)
    {
        _context = context;
        _jobs = jobs;
        _settings = settings;
        _audit = audit;
    }

    public GeneratedExchangeFile Schema()
    {
        var schema = new Dictionary<string, object>
        {
            ["$schema"] = "https://json-schema.org/draft/2020-12/schema",
            ["$id"] = "https://phenyosync.local/schemas/stock-count-2.0.json",
            ["title"] = "PhenyoSync Stock Count Package",
            ["type"] = "object",
            ["additionalProperties"] = false,
            ["required"] = new[] { "schemaVersion", "exportId", "exportedAtUtc", "exportedBy", "warehouseSection", "items" },
            ["properties"] = new Dictionary<string, object>
            {
                ["schemaVersion"] = new { type = "string", @const = SchemaVersion },
                ["exportId"] = new { type = "string", minLength = 1, maxLength = 100 },
                ["exportedAtUtc"] = new { type = "string", format = "date-time" },
                ["exportedBy"] = new
                {
                    type = "object",
                    additionalProperties = false,
                    required = new[] { "displayName" },
                    properties = new { displayName = new { type = "string" } }
                },
                ["warehouseSection"] = new
                {
                    type = "object",
                    additionalProperties = false,
                    required = new[] { "code", "name" },
                    properties = new
                    {
                        code = new { type = "string", minLength = 1 },
                        name = new { type = "string" }
                    }
                },
                ["items"] = new
                {
                    type = "array",
                    minItems = 1,
                    items = new
                    {
                        type = "object",
                        additionalProperties = false,
                        required = new[] { "productCode", "productName", "unitOfMeasure", "countedQuantity" },
                        properties = new
                        {
                            productCode = new { type = "string" },
                            productName = new { type = "string" },
                            unitOfMeasure = new { type = "string", @const = "KG" },
                            expectedQuantity = new { type = new[] { "number", "null" }, minimum = 0 },
                            countedQuantity = new { type = "number", minimum = 0 }
                        }
                    }
                }
            }
        };
        return JsonFile(schema, "PhenyoSync-StockCount-Schema-2.0.json");
    }

    public GeneratedExchangeFile Sample()
    {
        var sample = new StockCountPackageDto
        {
            SchemaVersion = SchemaVersion,
            ExportId = "replace-with-export-id",
            ExportedAtUtc = DateTime.UtcNow,
            ExportedBy = new StockCountExportedByDto { DisplayName = "Stock Taker" },
            WarehouseSection = new StockCountWarehouseSectionDto
            {
                Code = "REPLACE-WITH-EXPORTED-SECTION-CODE",
                Name = "Warehouse section name"
            },
            Items =
            [
                new StockCountPackageItemDto
                {
                    ProductCode = "PRODUCT-000001",
                    ProductName = "Example product",
                    UnitOfMeasure = "KG",
                    ExpectedQuantity = 25,
                    CountedQuantity = 24.5m
                }
            ]
        };
        return JsonFile(sample, "PhenyoSync-StockCount-Sample-2.0.json");
    }

    public async Task<GeneratedExchangeFile> ExportAsync(
        StockCountExportQueryDto query,
        int userId,
        CancellationToken cancellationToken)
    {
        var section = await _context.WarehouseSections.AsNoTracking()
            .SingleOrDefaultAsync(
                item => item.SectionId == query.WarehouseSectionId,
                cancellationToken)
            ?? throw new PhaseBException(404, "Warehouse section not found.");
        var stock = _context.Stocks.AsNoTracking()
            .Where(item => item.SectionId == query.WarehouseSectionId);
        if (query.ProductCategoryId.HasValue)
            stock = stock.Where(item =>
                item.Product.ProductCategoryId == query.ProductCategoryId.Value);
        if (query.ProductTypeId.HasValue)
            stock = stock.Where(item =>
                item.Product.ProductTypeId == query.ProductTypeId.Value);
        if (query.ActiveProductsOnly)
            stock = stock.Where(item => item.Product.Status == ProductStatuses.Active);
        var items = await stock
            .OrderBy(item => item.Product.ProductName)
            .Select(item => new StockCountPackageItemDto
            {
                ProductCode = item.Product.QRCodeValue ??
                    item.Product.ProductName,
                ProductName = item.Product.ProductName,
                UnitOfMeasure = "KG",
                ExpectedQuantity = query.IncludeExpectedQuantities
                    ? item.QuantityAvailableKg
                    : null,
                CountedQuantity = null
            })
            .ToListAsync(cancellationToken);
        var user = await _context.Users.AsNoTracking()
            .Where(item => item.UserId == userId)
            .Select(item => item.FirstName + " " + item.LastName)
            .SingleOrDefaultAsync(cancellationToken) ?? $"User {userId}";
        var package = new StockCountPackageDto
        {
            ExportId = Guid.NewGuid().ToString("N"),
            ExportedAtUtc = DateTime.UtcNow,
            ExportedBy = new StockCountExportedByDto
            {
                DisplayName = user
            },
            WarehouseSection = new StockCountWarehouseSectionDto
            {
                Code = section.SectionCode,
                Name = section.SectionName
            },
            Items = items
        };
        var bytes = JsonSerializer.SerializeToUtf8Bytes(package, JsonOptions);
        await AuditAsync(
            AuditActionTypes.Export,
            "Export Stock Count JSON",
            userId,
            $"Exported {items.Count} inventory-count rows for {section.SectionName}.",
            new Dictionary<string, object?>
            {
                ["warehouseSectionId"] = section.SectionId,
                ["rowCount"] = items.Count,
                ["exportId"] = package.ExportId
            },
            cancellationToken);
        return new GeneratedExchangeFile(
            bytes,
            "application/json",
            $"PhenyoSync-StockCount-{DateTime.UtcNow:yyyy-MM-dd}.json");
    }

    // Validation parses and stages the count file without changing stock balances.
    public async Task<DataExchangeValidationResponseDto> ValidateAsync(
        IFormFile file,
        int userId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        var bytes = await ReadAndValidateFileAsync(file, cancellationToken);
        StockCountPackageDto package;
        try
        {
            package = JsonSerializer.Deserialize<StockCountPackageDto>(
                    bytes,
                    JsonOptions)
                ?? throw new PhaseBException(400, "The JSON package is empty.");
        }
        catch (JsonException)
        {
            throw new PhaseBException(400, "The uploaded file is not valid JSON.");
        }
        if (package.SchemaVersion != SchemaVersion)
            throw new PhaseBException(400, "The Stock Count schema version is not supported.");
        if (string.IsNullOrWhiteSpace(package.ExportId) ||
            package.ExportId.Length > 100)
            throw new PhaseBException(400, "The Stock Count export identifier is invalid.");
        if (package.ExportedAtUtc > DateTime.UtcNow.AddMinutes(5) ||
            package.ExportedAtUtc < DateTime.UtcNow.AddHours(-24))
            throw new PhaseBException(
                409,
                "The Stock Count package is stale. Export a fresh package before counting.");
        var maximumRows = await _settings.GetIntAsync(
            SystemSettingKeys.DataExchangeMaximumRows,
            cancellationToken);
        if (package.Items.Count == 0)
            throw new PhaseBException(400, "The Stock Count package contains no rows.");
        if (package.Items.Count > maximumRows)
            throw new PhaseBException(400, $"The package exceeds the {maximumRows}-row limit.");
        var sectionCode = package.WarehouseSection.Code?.Trim() ?? string.Empty;
        var section = await _context.WarehouseSections.AsNoTracking()
            .Where(item => item.SectionCode == sectionCode)
            .Select(item => new
            {
                item.SectionId,
                item.SectionCode,
                item.SectionName
            })
            .SingleOrDefaultAsync(cancellationToken);
        if (section is null)
            throw new PhaseBException(400, "The package warehouse section does not exist.");
        if (!string.IsNullOrWhiteSpace(package.WarehouseSection.Name) &&
            !string.Equals(
                package.WarehouseSection.Name.Trim(),
                section.SectionName,
                StringComparison.OrdinalIgnoreCase))
            throw new PhaseBException(
                400,
                "The warehouse section name does not match its current code.");
        var duplicateKeys = package.Items
            .GroupBy(ExternalProductKey, StringComparer.OrdinalIgnoreCase)
            .Where(group => group.Count() > 1)
            .Select(group => group.Key)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var stock = await _context.Stocks.AsNoTracking()
            .Where(item => item.SectionId == section.SectionId)
            .Select(item => new
            {
                item.ProductId,
                ProductCode = item.Product.QRCodeValue,
                item.Product.ProductName,
                item.Product.Status,
                item.QuantityAvailableKg
            })
            .ToListAsync(cancellationToken);
        var staged = new StockCountStagedPayload
        {
            ExportId = package.ExportId,
            ExportedAtUtc = package.ExportedAtUtc,
            WarehouseSectionId = section.SectionId
        };
        for (var index = 0; index < package.Items.Count; index++)
        {
            var item = package.Items[index];
            var productCode = item.ProductCode?.Trim() ?? string.Empty;
            var productName = item.ProductName?.Trim() ?? string.Empty;
            var candidates = stock
                .Where(candidate =>
                    (!string.IsNullOrWhiteSpace(productCode) &&
                     string.Equals(
                         candidate.ProductCode,
                         productCode,
                         StringComparison.OrdinalIgnoreCase)) ||
                    (!string.IsNullOrWhiteSpace(productName) &&
                     string.Equals(
                         candidate.ProductName,
                         productName,
                         StringComparison.OrdinalIgnoreCase)))
                .ToList();
            var current = candidates.Count == 1 ? candidates[0] : null;
            var row = new StockCountStagedRow
            {
                RowNumber = index + 1,
                ProductId = current?.ProductId ?? 0,
                ProductCode = productCode,
                ProductName = productName,
                UnitOfMeasure = (item.UnitOfMeasure ?? string.Empty)
                    .Trim()
                    .ToUpperInvariant(),
                ExpectedQuantity = item.ExpectedQuantity ?? -1,
                CountedQuantity = item.CountedQuantity ?? -1
            };
            if (string.IsNullOrWhiteSpace(productCode) &&
                string.IsNullOrWhiteSpace(productName))
                row.Messages.Add("ProductCode or ProductName is required.");
            if (duplicateKeys.Contains(ExternalProductKey(item)))
                row.Messages.Add("The Product is duplicated in the package.");
            if (candidates.Count == 0)
                row.Messages.Add("The Product is not stocked in the selected section.");
            else if (candidates.Count > 1)
                row.Messages.Add(
                    "The Product description is ambiguous. Use its unique ProductCode.");
            else
            {
                if (!string.Equals(
                        current!.ProductName,
                        productName,
                        StringComparison.OrdinalIgnoreCase))
                    row.Messages.Add(
                        "ProductName does not match the current ProductCode.");
                if (item.ExpectedQuantity.HasValue &&
                    item.ExpectedQuantity.Value != current.QuantityAvailableKg)
                    row.Messages.Add("Expected quantity changed after export. Export a fresh package.");
                row.ExpectedQuantity = current.QuantityAvailableKg;
            }
            if (item.CountedQuantity is null)
                row.Messages.Add("CountedQuantity is required.");
            else if (item.CountedQuantity < 0 ||
                     decimal.Round(item.CountedQuantity.Value, 2) != item.CountedQuantity.Value)
                row.Messages.Add("CountedQuantity must be non-negative with at most two decimals.");
            if (row.UnitOfMeasure != "KG")
                row.Messages.Add("UnitOfMeasure must be KG.");
            row.Variance = row.CountedQuantity >= 0
                ? row.CountedQuantity - row.ExpectedQuantity
                : 0;
            row.ValidationStatus = row.Messages.Count == 0 ? "Valid" : "Invalid";
            staged.Rows.Add(row);
        }
        var valid = staged.Rows.Count(item => item.ValidationStatus == "Valid");
        var invalid = staged.Rows.Count - valid;
        var job = await _jobs.StageAsync(
            DataExchangeTypes.StockCountJson,
            file.FileName,
            bytes,
            staged,
            staged.Rows.Count,
            valid,
            0,
            invalid,
            userId,
            correlationId,
            cancellationToken);
        await AuditAsync(
            AuditActionTypes.ValidateImport,
            "Validate Stock Count JSON",
            userId,
            $"Validated {staged.Rows.Count} Stock Count rows.",
            new Dictionary<string, object?>
            {
                ["validRows"] = valid,
                ["invalidRows"] = invalid,
                ["jobId"] = job.Job.DataExchangeJobId,
                ["exportId"] = staged.ExportId
            },
            cancellationToken);
        return new DataExchangeValidationResponseDto
        {
            ValidationToken = job.ValidationToken,
            ExpiresAtUtc = job.Job.ExpiresAtUtc,
            TotalRows = staged.Rows.Count,
            ValidRows = valid,
            InvalidRows = invalid,
            Rows = staged.Rows.Select(item => new DataExchangePreviewRowDto
            {
                RowNumber = item.RowNumber,
                Status = item.ValidationStatus,
                Action = item.Variance == 0
                    ? "No change"
                    : item.Variance > 0 ? "Increase" : "Decrease",
                RecordKey = string.IsNullOrWhiteSpace(item.ProductCode)
                    ? item.ProductName
                    : item.ProductCode,
                Messages = item.Messages,
                ExpectedQuantity = item.ExpectedQuantity,
                CountedQuantity = item.CountedQuantity,
                Variance = item.Variance
            }).ToList()
        };
    }

    // Import consumes the server-owned validation job and applies balance plus ledger changes atomically.
    public async Task<DataExchangeApplyResponseDto> ImportAsync(
        string validationToken,
        ApplyDataExchangeRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var job = await _jobs.GetValidatedAsync(
            validationToken,
            DataExchangeTypes.StockCountJson,
            userId,
            cancellationToken);
        if (job.InvalidRows > 0)
            throw new PhaseBException(409, "Resolve all invalid Stock Count rows first.");
        var payload = JsonSerializer.Deserialize<StockCountStagedPayload>(
                job.StagedPayloadJson,
                JsonOptions)
            ?? throw new PhaseBException(409, "The staged Stock Count data is unavailable.");
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var session = new StockTakeSession
        {
            UserId = userId,
            SectionId = payload.WarehouseSectionId,
            SessionDate = DateTime.UtcNow,
            Status = "Completed",
            Notes = request.Reason.Trim(),
            CorrelationId = job.CorrelationId
        };
        _context.StockTakeSessions.Add(session);
        await _context.SaveChangesAsync(cancellationToken);
        var adjustmentCount = 0;
        var results = new List<DataExchangePreviewRowDto>();
        try
        {
            foreach (var row in payload.Rows)
            {
                var stock = await _context.Stocks.SingleOrDefaultAsync(
                        item => item.ProductId == row.ProductId &&
                                item.SectionId == payload.WarehouseSectionId,
                        cancellationToken)
                    ?? throw new PhaseBException(
                        409,
                        $"Stock for {row.ProductName} no longer exists.");
                if (stock.QuantityAvailableKg != row.ExpectedQuantity)
                    throw new PhaseBException(
                        409,
                        $"Stock for {row.ProductName} changed after validation. Validate a fresh export.");
                if (row.Variance != 0)
                {
                    if (row.Variance < 0)
                    {
                        await ApplyStockCountDecreaseAsync(
                            row,
                            payload.WarehouseSectionId,
                            session.SessionId,
                            userId,
                            request.Reason,
                            cancellationToken);
                    }
                    else
                    {
                        await ApplyStockCountIncreaseAsync(
                            row,
                            payload.WarehouseSectionId,
                            session.SessionId,
                            userId,
                            request.Reason,
                            cancellationToken);
                    }
                    stock.QuantityAvailableKg = row.CountedQuantity;
                    stock.InventoryStatus = row.CountedQuantity == 0
                        ? "Empty"
                        : "Available";
                    adjustmentCount++;
                }
                results.Add(new DataExchangePreviewRowDto
                {
                    RowNumber = row.RowNumber,
                    Status = "Applied",
                    Action = row.Variance == 0
                        ? "No change"
                        : row.Variance > 0 ? "Increase" : "Decrease",
                    RecordKey = string.IsNullOrWhiteSpace(row.ProductCode)
                        ? row.ProductName
                        : row.ProductCode,
                    ExpectedQuantity = row.ExpectedQuantity,
                    CountedQuantity = row.CountedQuantity,
                    Variance = row.Variance,
                    Messages = ["Stock Count row applied successfully."]
                });
            }
            job.Status = DataExchangeStatuses.Applied;
            job.AppliedAtUtc = DateTime.UtcNow;
            job.ApplyReason = request.Reason.Trim();
            job.ResultPayloadJson = JsonSerializer.Serialize(results, JsonOptions);
            await _context.SaveChangesAsync(cancellationToken);
            await AuditAsync(
                AuditActionTypes.Import,
                "Import Stock Count JSON",
                userId,
                $"Applied {payload.Rows.Count} Stock Count rows with {adjustmentCount} adjustments.",
                new Dictionary<string, object?>
                {
                    ["stockTakeSessionId"] = session.SessionId,
                    ["jobId"] = job.DataExchangeJobId,
                    ["adjustmentCount"] = adjustmentCount,
                    ["reason"] = request.Reason.Trim()
                },
                cancellationToken);
            await transaction.CommitAsync(cancellationToken);
        }
        catch
        {
            await transaction.RollbackAsync(cancellationToken);
            throw;
        }
        return new DataExchangeApplyResponseDto
        {
            Message = "The validated Stock Count package was applied transactionally.",
            ResultToken = validationToken,
            AdjustmentCount = adjustmentCount,
            CorrelationId = job.CorrelationId
        };
    }

    public async Task<GeneratedExchangeFile> ResultAsync(
        string resultToken,
        int userId,
        CancellationToken cancellationToken)
    {
        var job = await _jobs.GetResultAsync(
            resultToken,
            DataExchangeTypes.StockCountJson,
            userId,
            cancellationToken);
        var result = new
        {
            schemaVersion = SchemaVersion,
            jobId = job.DataExchangeJobId,
            job.CorrelationId,
            job.AppliedAtUtc,
            job.TotalRows,
            job.ValidRows,
            rows = JsonSerializer.Deserialize<List<DataExchangePreviewRowDto>>(
                job.ResultPayloadJson ?? "[]",
                JsonOptions)
        };
        return new GeneratedExchangeFile(
            JsonSerializer.SerializeToUtf8Bytes(result, JsonOptions),
            "application/json",
            $"PhenyoSync-StockCount-Result-{job.DataExchangeJobId}.json");
    }

    private static GeneratedExchangeFile JsonFile(object value, string fileName) =>
        new(
            JsonSerializer.SerializeToUtf8Bytes(value, JsonOptions),
            "application/json",
            fileName);

    private async Task ApplyStockCountDecreaseAsync(
        StockCountStagedRow row,
        int sectionId,
        int stockTakeSessionId,
        int userId,
        string reason,
        CancellationToken cancellationToken)
    {
        var quantityToRemove = Math.Abs(row.Variance);
        var batches = await _context.ProductBatches
            .Where(item =>
                item.ProductId == row.ProductId &&
                item.SectionId == sectionId &&
                item.Status == ProductBatchStatuses.Available &&
                item.QuantityRemainingKg > 0 &&
                item.EffectiveExpiryAtUtc > DateTime.UtcNow)
            .OrderBy(item => item.EffectiveExpiryAtUtc)
            .ThenBy(item => item.ProductBatchId)
            .ToListAsync(cancellationToken);
        if (batches.Sum(item => item.QuantityRemainingKg) < quantityToRemove)
            throw new PhaseBException(
                409,
                $"Available Product stock for {row.ProductName} changed after validation.");
        foreach (var batch in batches)
        {
            if (quantityToRemove <= 0)
                break;
            var removed = Math.Min(batch.QuantityRemainingKg, quantityToRemove);
            batch.QuantityRemainingKg -= removed;
            batch.UpdatedAtUtc = DateTime.UtcNow;
            if (batch.QuantityRemainingKg == 0)
            {
                batch.Status = ProductBatchStatuses.Consumed;
                batch.AvailableQuantityRemovedAtUtc = DateTime.UtcNow;
            }
            _context.StockMovements.Add(new StockMovement
            {
                ProductId = row.ProductId,
                ProductBatchId = batch.ProductBatchId,
                SectionId = sectionId,
                MovementType = StockMovementTypes.Decrease,
                QuantityKg = removed,
                OccurredAtUtc = DateTime.UtcNow,
                CreatedByUserId = userId,
                StockTakeSessionId = stockTakeSessionId,
                Reason = $"Stock Count import: {reason.Trim()}"
            });
            quantityToRemove -= removed;
        }
    }

    private async Task ApplyStockCountIncreaseAsync(
        StockCountStagedRow row,
        int sectionId,
        int stockTakeSessionId,
        int userId,
        string reason,
        CancellationToken cancellationToken)
    {
        var shelfLifeDays = await _context.Products.AsNoTracking()
            .Where(item => item.ProductId == row.ProductId)
            .Select(item => item.ShelfLifeDays)
            .SingleAsync(cancellationToken);
        var now = DateTime.UtcNow;
        var batchCode = $"SC-{now:yyyyMMddHHmmss}-{Guid.NewGuid():N}"[..32]
            .ToUpperInvariant();
        var batch = new ProductBatch
        {
            ProductId = row.ProductId,
            SectionId = sectionId,
            BatchCode = batchCode,
            QRCodeValue = $"PHENYOSYNC:STOCKCOUNT:{batchCode}",
            QuantityProducedKg = row.Variance,
            QuantityRemainingKg = row.Variance,
            PackedAtUtc = now,
            OriginalExpiryAtUtc = now.AddDays(Math.Max(1, shelfLifeDays)),
            EffectiveExpiryAtUtc = now.AddDays(Math.Max(1, shelfLifeDays)),
            Status = ProductBatchStatuses.Available,
            CreatedAtUtc = now
        };
        _context.ProductBatches.Add(batch);
        await _context.SaveChangesAsync(cancellationToken);
        _context.StockMovements.Add(new StockMovement
        {
            ProductId = row.ProductId,
            ProductBatchId = batch.ProductBatchId,
            SectionId = sectionId,
            MovementType = StockMovementTypes.Increase,
            QuantityKg = row.Variance,
            OccurredAtUtc = now,
            CreatedByUserId = userId,
            StockTakeSessionId = stockTakeSessionId,
            Reason = $"Stock Count import: {reason.Trim()}"
        });
    }

    private static string ExternalProductKey(StockCountPackageItemDto item)
    {
        var productCode = item.ProductCode?.Trim();
        return string.IsNullOrWhiteSpace(productCode)
            ? item.ProductName?.Trim() ?? string.Empty
            : productCode;
    }

    private async Task<byte[]> ReadAndValidateFileAsync(
        IFormFile file,
        CancellationToken cancellationToken)
    {
        var maximumMb = await _settings.GetIntAsync(
            SystemSettingKeys.FilesJsonImportMaximumMb,
            cancellationToken);
        if (file.Length <= 0)
            throw new PhaseBException(400, "Select a non-empty JSON file.");
        if (file.Length > maximumMb * 1024L * 1024L)
            throw new PhaseBException(400, $"The JSON file exceeds the {maximumMb} MB limit.");
        if (!Path.GetExtension(file.FileName).Equals(".json", StringComparison.OrdinalIgnoreCase))
            throw new PhaseBException(400, "Stock Count imports must use .json files.");
        if (!file.ContentType.Equals("application/json", StringComparison.OrdinalIgnoreCase) &&
            !file.ContentType.Equals("application/octet-stream", StringComparison.OrdinalIgnoreCase))
            throw new PhaseBException(400, "The uploaded file does not declare a JSON content type.");
        await using var stream = new MemoryStream();
        await file.CopyToAsync(stream, cancellationToken);
        var bytes = stream.ToArray();
        var first = Encoding.UTF8.GetString(bytes).FirstOrDefault(character =>
            !char.IsWhiteSpace(character) && character != '\uFEFF');
        if (first != '{')
            throw new PhaseBException(400, "The JSON file signature is invalid.");
        return bytes;
    }

    private Task AuditAsync(
        string action,
        string operation,
        int userId,
        string description,
        IReadOnlyDictionary<string, object?> details,
        CancellationToken cancellationToken) =>
        _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = AuditModules.DataExchange,
            OperationName = operation,
            Description = description,
            EntityType = "DataExchangeJob",
            UserId = userId,
            SafeDetails = details
        }, cancellationToken);
}
