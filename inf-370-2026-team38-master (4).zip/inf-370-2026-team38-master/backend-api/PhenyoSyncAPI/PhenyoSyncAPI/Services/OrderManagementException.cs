namespace PhenyoSyncAPI.Services;

public sealed class OrderManagementException : Exception
{
    public OrderManagementException(int statusCode, string message, object? details = null)
        : base(message)
    {
        StatusCode = statusCode;
        Details = details;
    }

    public int StatusCode { get; }
    public object? Details { get; }
}
