using PhenyoSyncAPI.DTOs.Delivery;

// Defines delivery operations with assignment and transition authorization.
namespace PhenyoSyncAPI.Services;

public interface IDeliveryService
{
    Task<DeliveryPagedResultDto> SearchAsync(DeliverySearchQueryDto query, CancellationToken cancellationToken);
    Task<DeliveryDetailDto> GetAsync(int deliveryId, int userId, string role, CancellationToken cancellationToken);
    Task<DeliveryDetailDto> ScheduleAsync(ScheduleDeliveryDto request, int userId, CancellationToken cancellationToken);
    Task<IReadOnlyList<AvailableDriverDto>> AvailableDriversAsync(int deliveryId, CancellationToken cancellationToken);
    Task<DeliveryDetailDto> AssignDriverAsync(
        int deliveryId,
        AssignDriverDto request,
        int userId,
        CancellationToken cancellationToken);
    Task<DeliveryDetailDto> UnassignDriverAsync(
        int deliveryId,
        UnassignDriverDto request,
        int userId,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<DeliveryListItemDto>> MyDeliveriesAsync(
        int userId,
        string? status,
        DateTime? fromUtc,
        DateTime? toUtc,
        CancellationToken cancellationToken);
    Task<DeliveryDetailDto> StartAsync(
        int deliveryId,
        int userId,
        string role,
        CancellationToken cancellationToken);
    Task<DeliveryProofDto> CompleteAsync(
        int deliveryId,
        CompleteDeliveryDto request,
        int userId,
        string role,
        CancellationToken cancellationToken);
    Task<DeliveryProofDto> GetProofAsync(
        int deliveryId,
        int userId,
        string role,
        CancellationToken cancellationToken);
}
