using System.Data;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Expiry;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services
{
    /// <summary>Evaluates batch expiry and applies the controlled review, write-off and extension lifecycle.</summary>
    public class ExpiryService : IExpiryService
    {
        private static readonly SemaphoreSlim ScanLock = new(1, 1);
        private readonly PhenyoSyncDbContext _context;
        private readonly IEmailService _emailService;
        private readonly ExpiryAlertOptions _options;
        private readonly IConfiguration _configuration;
        private readonly ISystemSettingProvider? _settings;
        private readonly IOperationalNotificationService? _notifications;
        private readonly ILogger<ExpiryService>? _logger;

        public ExpiryService(
            PhenyoSyncDbContext context,
            IEmailService emailService,
            IOptions<ExpiryAlertOptions> options,
            IConfiguration configuration,
            ISystemSettingProvider? settings = null,
            IOperationalNotificationService? notifications = null,
            ILogger<ExpiryService>? logger = null)
        {
            _context = context;
            _emailService = emailService;
            _options = options.Value;
            _configuration = configuration;
            _settings = settings;
            _notifications = notifications;
            _logger = logger;
        }

        public async Task<ExpiryAlertSummaryDto> GetAlertsAsync(
            string? level,
            int? productId,
            int? categoryId,
            int? sectionId,
            CancellationToken cancellationToken)
        {
            var query = _context.ProductBatches
                .AsNoTracking()
                .Where(batch =>
                    batch.QuantityRemainingKg > 0 &&
                    batch.Status != ProductBatchStatuses.Consumed &&
                    batch.Status != ProductBatchStatuses.WrittenOff);

            if (productId.HasValue)
            {
                query = query.Where(batch => batch.ProductId == productId.Value);
            }

            if (categoryId.HasValue)
            {
                query = query.Where(batch =>
                    batch.Product.ProductCategoryId == categoryId.Value);
            }

            if (sectionId.HasValue)
            {
                query = query.Where(batch => batch.SectionId == sectionId.Value);
            }

            var now = DateTime.UtcNow;
            var redThreshold = await SettingInt(
                SystemSettingKeys.ExpiryRedThresholdHours,
                _options.RedThresholdHours,
                cancellationToken);
            var yellowThreshold = await SettingInt(
                SystemSettingKeys.ExpiryYellowThresholdHours,
                _options.YellowThresholdHours,
                cancellationToken);
            var batches = await query
                .Include(batch => batch.Product)
                    .ThenInclude(product => product.ProductCategory)
                .Include(batch => batch.WarehouseSection)
                .OrderBy(batch => batch.EffectiveExpiryAtUtc)
                .ToListAsync(cancellationToken);

            var alerts = batches
                .Select(batch => ToAlertDto(
                    batch,
                    now,
                    redThreshold,
                    yellowThreshold))
                .Where(alert => alert.AlertLevel != ExpiryAlertLevels.Normal)
                .ToList();

            var warningCount = alerts.Count(item => item.AlertLevel == ExpiryAlertLevels.Warning);
            var urgentCount = alerts.Count(item => item.AlertLevel == ExpiryAlertLevels.Urgent);
            var expiredCount = alerts.Count(item => item.AlertLevel == ExpiryAlertLevels.Expired);

            if (!string.IsNullOrWhiteSpace(level))
            {
                alerts = alerts
                    .Where(alert => alert.AlertLevel.Equals(
                        level.Trim(),
                        StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }

            return new ExpiryAlertSummaryDto
            {
                WarningCount = warningCount,
                UrgentCount = urgentCount,
                ExpiredCount = expiredCount,
                Batches = alerts
            };
        }

        // One scan promotes batches through warning/urgent/expired states and records notifications.
        public async Task<ExpiryScanResult> RunScanAsync(CancellationToken cancellationToken)
        {
            await ScanLock.WaitAsync(cancellationToken);
            try
            {
            var now = DateTime.UtcNow;
            var redThreshold = await SettingInt(
                SystemSettingKeys.ExpiryRedThresholdHours,
                _options.RedThresholdHours,
                cancellationToken);
            var yellowThreshold = await SettingInt(
                SystemSettingKeys.ExpiryYellowThresholdHours,
                _options.YellowThresholdHours,
                cancellationToken);
            var tokenLifetime = await SettingInt(
                SystemSettingKeys.ExpiryActionTokenLifetimeHours,
                _options.ActionTokenLifetimeHours,
                cancellationToken);
            await using var expiryTransaction = await _context.Database
                .BeginTransactionAsync(IsolationLevel.Serializable, cancellationToken);
            var batches = await _context.ProductBatches
                .Include(batch => batch.Product)
                .Include(batch => batch.WarehouseSection)
                .Where(batch =>
                    batch.QuantityRemainingKg > 0 &&
                    batch.Status != ProductBatchStatuses.Consumed &&
                    batch.Status != ProductBatchStatuses.WrittenOff)
                .OrderBy(batch => batch.EffectiveExpiryAtUtc)
                .ToListAsync(cancellationToken);

            var markedExpired = 0;
            var newlyExpired = new List<ProductBatch>();
            foreach (var batch in batches.Where(batch => batch.EffectiveExpiryAtUtc <= now))
            {
                if (batch.Status != ProductBatchStatuses.ExpiredPendingDecision)
                {
                    batch.Status = ProductBatchStatuses.ExpiredPendingDecision;
                    markedExpired++;
                    newlyExpired.Add(batch);
                }

                if (batch.AvailableQuantityRemovedAtUtc is null)
                {
                    var stock = await _context.Stocks.FirstOrDefaultAsync(item =>
                        item.ProductId == batch.ProductId && item.SectionId == batch.SectionId,
                        cancellationToken);

                    if (stock is not null)
                    {
                        stock.QuantityAvailableKg = Math.Max(
                            0,
                            stock.QuantityAvailableKg - batch.QuantityRemainingKg);
                        stock.InventoryStatus = stock.QuantityAvailableKg > 0
                            ? ProductBatchStatuses.Available
                            : ProductBatchStatuses.ExpiredPendingDecision;
                    }

                    batch.AvailableQuantityRemovedAtUtc = now;
                    batch.UpdatedAtUtc = now;
                    _context.StockMovements.Add(new StockMovement
                    {
                        ProductId = batch.ProductId,
                        ProductBatchId = batch.ProductBatchId,
                        SectionId = batch.SectionId,
                        MovementType = StockMovementTypes.Decrease,
                        QuantityKg = batch.QuantityRemainingKg,
                        OccurredAtUtc = now,
                        Reason = "Expired batch removed from available stock pending final decision."
                    });
                }
            }

            await _context.SaveChangesAsync(cancellationToken);
            await expiryTransaction.CommitAsync(cancellationToken);

            var recipients = await GetRecipientsAsync(cancellationToken);
            var warningSent = 0;
            var urgentSent = 0;

            foreach (var batch in newlyExpired)
            {
                try
                {
                    await SendExpiryTransitionAlertAsync(
                        batch,
                        recipients,
                        tokenLifetime,
                        now,
                        cancellationToken);
                }
                catch (Exception exception)
                {
                    _logger?.LogWarning(
                        exception,
                        "Batch {ProductBatchId} remains unavailable after its expiry transition, but the transition alert could not be delivered.",
                        batch.ProductBatchId);
                }
            }

            foreach (var batch in batches.Where(batch => batch.EffectiveExpiryAtUtc > now))
            {
                var alertLevel = GetAlertLevel(
                    batch.EffectiveExpiryAtUtc,
                    now,
                    redThreshold,
                    yellowThreshold);
                var needsWarning = alertLevel == ExpiryAlertLevels.Warning && batch.YellowAlertSentAtUtc is null;
                var needsUrgent = alertLevel == ExpiryAlertLevels.Urgent && batch.RedAlertSentAtUtc is null;

                if ((!needsWarning && !needsUrgent) || recipients.Count == 0)
                {
                    continue;
                }

                var rawToken = CreateActionToken();
                var actionToken = new ExpiryActionToken
                {
                    ProductBatchId = batch.ProductBatchId,
                    TokenHash = HashToken(rawToken),
                    AlertLevel = alertLevel,
                    CreatedAtUtc = now,
                    ExpiresAtUtc = now.AddHours(tokenLifetime)
                };

                _context.ExpiryActionTokens.Add(actionToken);
                await _context.SaveChangesAsync(cancellationToken);

                var frontendUrl = (_configuration["FrontendUrl"] ?? "http://localhost:4200").TrimEnd('/');
                var reviewLink = $"{frontendUrl}/expiry-action?token={Uri.EscapeDataString(rawToken)}";
                try
                {
                    await _emailService.SendExpiryAlertEmailAsync(
                        recipients,
                        CreateEmailModel(batch, now, alertLevel),
                        reviewLink,
                        cancellationToken);

                    await PublishExpiryNotificationAsync(
                        batch,
                        alertLevel,
                        cancellationToken);
                }
                catch
                {
                    actionToken.InvalidatedAtUtc = DateTime.UtcNow;
                    await _context.SaveChangesAsync(cancellationToken);
                    throw;
                }

                if (needsWarning)
                {
                    batch.YellowAlertSentAtUtc = now;
                    warningSent++;
                }
                else
                {
                    batch.RedAlertSentAtUtc = now;
                    urgentSent++;
                }

                batch.UpdatedAtUtc = now;
                await _context.SaveChangesAsync(cancellationToken);
            }

            return new ExpiryScanResult(batches.Count, markedExpired, warningSent, urgentSent);
            }
            finally
            {
                ScanLock.Release();
            }
        }

        private async Task SendExpiryTransitionAlertAsync(
            ProductBatch batch,
            IReadOnlyCollection<string> recipients,
            int tokenLifetimeHours,
            DateTime now,
            CancellationToken cancellationToken)
        {
            if (recipients.Count == 0)
            {
                await PublishExpiryNotificationAsync(
                    batch,
                    ExpiryAlertLevels.Expired,
                    cancellationToken);
                return;
            }

            var rawToken = CreateActionToken();
            var actionToken = new ExpiryActionToken
            {
                ProductBatchId = batch.ProductBatchId,
                TokenHash = HashToken(rawToken),
                AlertLevel = ExpiryAlertLevels.Expired,
                CreatedAtUtc = now,
                ExpiresAtUtc = now.AddHours(tokenLifetimeHours)
            };
            _context.ExpiryActionTokens.Add(actionToken);
            await _context.SaveChangesAsync(cancellationToken);

            var frontendUrl = (_configuration["FrontendUrl"] ?? "http://localhost:4200")
                .TrimEnd('/');
            var reviewLink =
                $"{frontendUrl}/expiry-action?token={Uri.EscapeDataString(rawToken)}";

            try
            {
                await _emailService.SendExpiryAlertEmailAsync(
                    recipients,
                    CreateEmailModel(batch, now, ExpiryAlertLevels.Expired),
                    reviewLink,
                    cancellationToken);
                await PublishExpiryNotificationAsync(
                    batch,
                    ExpiryAlertLevels.Expired,
                    cancellationToken);
            }
            catch
            {
                actionToken.InvalidatedAtUtc = DateTime.UtcNow;
                await _context.SaveChangesAsync(cancellationToken);
                throw;
            }
        }

        private async Task PublishExpiryNotificationAsync(
            ProductBatch batch,
            string alertLevel,
            CancellationToken cancellationToken)
        {
            if (_notifications is null) return;

            try
            {
                var severity = alertLevel is ExpiryAlertLevels.Urgent or ExpiryAlertLevels.Expired
                    ? "Critical"
                    : "Warning";
                await _notifications.PublishToRolesAsync(
                    $"Expiry{alertLevel}",
                    severity,
                    $"{alertLevel} expiry alert: {batch.Product.ProductName}",
                    $"Batch {batch.BatchCode} has {batch.QuantityRemainingKg:0.##} kg remaining and reaches its effective best-before time on {batch.EffectiveExpiryAtUtc:u}.",
                    [RoleCodes.WarehouseManager, RoleCodes.OperationsManager],
                    nameof(ProductBatch),
                    batch.ProductBatchId.ToString(),
                    "/write-offs",
                    null,
                    $"expiry-{alertLevel.ToLowerInvariant()}-{batch.ProductBatchId}",
                    cancellationToken);
            }
            catch (Exception exception)
            {
                _logger?.LogWarning(
                    exception,
                    "Expiry email for batch {ProductBatchId} was sent, but its operational notification could not be queued.",
                    batch.ProductBatchId);
            }
        }

        public async Task<ExpiryActionReviewDto> GetActionReviewAsync(
            string token,
            CancellationToken cancellationToken)
        {
            var actionToken = await FindValidTokenAsync(token, cancellationToken);
            var batch = actionToken.ProductBatch;
            var now = DateTime.UtcNow;
            var redThreshold = await SettingInt(
                SystemSettingKeys.ExpiryRedThresholdHours,
                _options.RedThresholdHours,
                cancellationToken);
            var yellowThreshold = await SettingInt(
                SystemSettingKeys.ExpiryYellowThresholdHours,
                _options.YellowThresholdHours,
                cancellationToken);
            var extensionDays = await SettingInt(
                SystemSettingKeys.ExpiryShelfLifeExtensionDays,
                2,
                cancellationToken);
            var alert = ToAlertDto(
                batch,
                now,
                redThreshold,
                yellowThreshold);

            return new ExpiryActionReviewDto
            {
                ProductBatchId = alert.ProductBatchId,
                ProductId = alert.ProductId,
                ProductName = alert.ProductName,
                ProductCategoryName = alert.ProductCategoryName,
                BatchCode = alert.BatchCode,
                SectionName = alert.SectionName,
                QuantityRemainingKg = alert.QuantityRemainingKg,
                PackedAtUtc = alert.PackedAtUtc,
                EffectiveExpiryAtUtc = alert.EffectiveExpiryAtUtc,
                RemainingHours = alert.RemainingHours,
                AlertLevel = alert.AlertLevel,
                BatchStatus = alert.BatchStatus,
                ShelfLifeExtended = alert.ShelfLifeExtended,
                CanWriteOff = batch.QuantityRemainingKg > 0 &&
                    batch.Status != ProductBatchStatuses.WrittenOff &&
                    batch.Status != ProductBatchStatuses.Consumed,
                CanExtend = batch.QuantityRemainingKg > 0 &&
                    !batch.ShelfLifeExtended &&
                    batch.Status is ProductBatchStatuses.Available or
                        ProductBatchStatuses.ExpiredPendingDecision,
                ShelfLifeExtensionDays = extensionDays,
                TokenExpiresAtUtc = actionToken.ExpiresAtUtc
            };
        }

        // A valid single-use action token authorizes the specific batch decision, not general stock access.
        public async Task<string> WriteOffAsync(
            string token,
            string reason,
            int userId,
            CancellationToken cancellationToken)
        {
            await using var transaction = await _context.Database
                .BeginTransactionAsync(IsolationLevel.Serializable, cancellationToken);
            var actionToken = await FindValidTokenAsync(token, cancellationToken);
            var batch = actionToken.ProductBatch;
            var quantity = batch.QuantityRemainingKg;

            var reservedOrders = await _context.OrderStockReservations
                .AsNoTracking()
                .Where(reservation =>
                    reservation.ProductBatchId == batch.ProductBatchId &&
                    reservation.Status == OrderReservationStatuses.Active)
                .Select(reservation => reservation.SalesOrder.OrderNumber)
                .Distinct()
                .OrderBy(number => number)
                .ToListAsync(cancellationToken);

            if (reservedOrders.Count > 0)
            {
                throw new Subsystem7Exception(
                    409,
                    $"This batch is reserved for active sales orders ({string.Join(", ", reservedOrders)}). Cancel or revalidate those orders before final write-off.");
            }

            if (quantity <= 0 || batch.Status is ProductBatchStatuses.WrittenOff or ProductBatchStatuses.Consumed)
            {
                throw new Subsystem7Exception(409, "This batch no longer has stock available to write off.");
            }

            if (batch.AvailableQuantityRemovedAtUtc is null)
            {
                var stock = await _context.Stocks.FirstOrDefaultAsync(item =>
                    item.ProductId == batch.ProductId && item.SectionId == batch.SectionId,
                    cancellationToken);

                if (stock is null || stock.QuantityAvailableKg < quantity)
                {
                    throw new Subsystem7Exception(409, "Available stock is inconsistent; the write-off was not applied.");
                }

                stock.QuantityAvailableKg -= quantity;
                stock.InventoryStatus = stock.QuantityAvailableKg > 0
                    ? ProductBatchStatuses.Available
                    : ProductBatchStatuses.WrittenOff;
                batch.AvailableQuantityRemovedAtUtc = DateTime.UtcNow;
            }

            batch.QuantityRemainingKg = 0;
            batch.Status = ProductBatchStatuses.WrittenOff;
            batch.UpdatedAtUtc = DateTime.UtcNow;
            actionToken.UsedAtUtc = DateTime.UtcNow;

            _context.StockMovements.Add(new StockMovement
            {
                ProductId = batch.ProductId,
                ProductBatchId = batch.ProductBatchId,
                SectionId = batch.SectionId,
                MovementType = StockMovementTypes.WriteOff,
                QuantityKg = quantity,
                OccurredAtUtc = DateTime.UtcNow,
                CreatedByUserId = userId,
                Reason = reason.Trim()
            });

            await InvalidateOtherTokensAsync(batch.ProductBatchId, actionToken.ExpiryActionTokenId, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);

            await SendDecisionConfirmationAsync(batch, "Final stock write-off", cancellationToken);
            return $"{quantity:0.##} kg was written off successfully.";
        }

        // Extension preserves the original expiry and records the accountable decision separately.
        public async Task<string> ExtendShelfLifeAsync(
            string token,
            string reason,
            DateTime newExpiryAtUtc,
            int userId,
            CancellationToken cancellationToken)
        {
            await using var transaction = await _context.Database
                .BeginTransactionAsync(IsolationLevel.Serializable, cancellationToken);
            var actionToken = await FindValidTokenAsync(token, cancellationToken);
            var batch = actionToken.ProductBatch;
            var now = DateTime.UtcNow;

            if (batch.ShelfLifeExtended)
            {
                throw new Subsystem7Exception(409, "This batch has already received its one permitted extension.");
            }

            if (batch.QuantityRemainingKg <= 0 ||
                batch.Status is not (
                    ProductBatchStatuses.Available or
                    ProductBatchStatuses.ExpiredPendingDecision))
            {
                throw new Subsystem7Exception(409, "This batch is not eligible for an extension.");
            }

            var extensionDays = await SettingInt(
                SystemSettingKeys.ExpiryShelfLifeExtensionDays,
                2,
                cancellationToken);
            var requestedExpiry = newExpiryAtUtc.Kind == DateTimeKind.Unspecified
                ? DateTime.SpecifyKind(newExpiryAtUtc, DateTimeKind.Utc)
                : newExpiryAtUtc.ToUniversalTime();
            var maximumExpiry = (batch.EffectiveExpiryAtUtc > now
                    ? batch.EffectiveExpiryAtUtc
                    : now)
                .AddDays(extensionDays);

            if (requestedExpiry <= now ||
                requestedExpiry <= batch.EffectiveExpiryAtUtc)
            {
                throw new Subsystem7Exception(
                    400,
                    "The new expiry must be later than both the current expiry and the present time.");
            }

            if (requestedExpiry > maximumExpiry)
            {
                throw new Subsystem7Exception(
                    400,
                    $"The new expiry cannot exceed the configured {extensionDays}-day extension limit.");
            }

            if (batch.AvailableQuantityRemovedAtUtc is not null)
            {
                var stock = await _context.Stocks.FirstOrDefaultAsync(item =>
                    item.ProductId == batch.ProductId &&
                    item.SectionId == batch.SectionId,
                    cancellationToken)
                    ?? throw new Subsystem7Exception(
                        409,
                        "The batch cannot be restored because its stock balance is missing.");

                stock.QuantityAvailableKg += batch.QuantityRemainingKg;
                stock.InventoryStatus = ProductBatchStatuses.Available;
                batch.AvailableQuantityRemovedAtUtc = null;
                _context.StockMovements.Add(new StockMovement
                {
                    ProductId = batch.ProductId,
                    ProductBatchId = batch.ProductBatchId,
                    SectionId = batch.SectionId,
                    MovementType = StockMovementTypes.Adjustment,
                    QuantityKg = batch.QuantityRemainingKg,
                    OccurredAtUtc = now,
                    CreatedByUserId = userId,
                    Reason = "Expiry decision restored the existing batch to usable stock; no new receipt was created."
                });
            }

            batch.EffectiveExpiryAtUtc = requestedExpiry;
            batch.Status = ProductBatchStatuses.Available;
            batch.ShelfLifeExtended = true;
            batch.ShelfLifeExtendedAtUtc = now;
            batch.ShelfLifeExtendedByUserId = userId;
            batch.ShelfLifeExtensionReason = reason.Trim();
            batch.UpdatedAtUtc = now;
            actionToken.UsedAtUtc = now;

            await InvalidateOtherTokensAsync(batch.ProductBatchId, actionToken.ExpiryActionTokenId, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);

            await SendDecisionConfirmationAsync(
                batch,
                $"Shelf life extended to {requestedExpiry:u}",
                cancellationToken);
            return $"Shelf life was extended to {requestedExpiry:u}.";
        }

        // Tokens are hashed, time-bound and consumed once to prevent replay from forwarded email links.
        private async Task<ExpiryActionToken> FindValidTokenAsync(
            string rawToken,
            CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(rawToken))
            {
                throw new Subsystem7Exception(400, "The expiry action token is required.");
            }

            var tokenHash = HashToken(rawToken);
            var actionToken = await _context.ExpiryActionTokens
                .Include(item => item.ProductBatch)
                    .ThenInclude(batch => batch.Product)
                        .ThenInclude(product => product.ProductCategory)
                .Include(item => item.ProductBatch)
                    .ThenInclude(batch => batch.WarehouseSection)
                .FirstOrDefaultAsync(item => item.TokenHash == tokenHash, cancellationToken);

            var expiredLinkMayResolvePendingStock =
                actionToken?.ProductBatch.Status ==
                    ProductBatchStatuses.ExpiredPendingDecision;

            if (actionToken is null ||
                actionToken.UsedAtUtc is not null ||
                actionToken.InvalidatedAtUtc is not null ||
                (actionToken.ExpiresAtUtc <= DateTime.UtcNow &&
                 !expiredLinkMayResolvePendingStock))
            {
                throw new Subsystem7Exception(400, "This expiry action link is invalid, expired, or already used.");
            }

            return actionToken;
        }

        private async Task InvalidateOtherTokensAsync(
            int batchId,
            long currentTokenId,
            CancellationToken cancellationToken)
        {
            var others = await _context.ExpiryActionTokens
                .Where(item =>
                    item.ProductBatchId == batchId &&
                    item.ExpiryActionTokenId != currentTokenId &&
                    item.UsedAtUtc == null &&
                    item.InvalidatedAtUtc == null)
                .ToListAsync(cancellationToken);

            foreach (var item in others)
            {
                item.InvalidatedAtUtc = DateTime.UtcNow;
            }
        }

        private async Task<IReadOnlyCollection<string>> GetRecipientsAsync(
            CancellationToken cancellationToken)
        {
            var recipientRoles = _settings is null
                ? _options.RecipientRoles
                : await _settings.GetStringArrayAsync(
                    SystemSettingKeys.ExpiryRecipientRoleCodes,
                    cancellationToken);
            return await _context.Users
                .AsNoTracking()
                .Where(user =>
                    user.Status == ProductStatuses.Active &&
                    user.Role != null &&
                    (recipientRoles.Contains(user.Role.RoleCode) ||
                     recipientRoles.Contains(user.Role.RoleName)))
                .Select(user => user.Email)
                .Distinct()
                .ToListAsync(cancellationToken);
        }

        private async Task SendDecisionConfirmationAsync(
            ProductBatch batch,
            string decision,
            CancellationToken cancellationToken)
        {
            var recipients = await GetRecipientsAsync(cancellationToken);
            var redThreshold = await SettingInt(
                SystemSettingKeys.ExpiryRedThresholdHours,
                _options.RedThresholdHours,
                cancellationToken);
            var yellowThreshold = await SettingInt(
                SystemSettingKeys.ExpiryYellowThresholdHours,
                _options.YellowThresholdHours,
                cancellationToken);
            await _emailService.SendExpiryDecisionConfirmationAsync(
                recipients,
                CreateEmailModel(
                    batch,
                    DateTime.UtcNow,
                    GetAlertLevel(
                        batch.EffectiveExpiryAtUtc,
                        DateTime.UtcNow,
                        redThreshold,
                        yellowThreshold)),
                decision,
                cancellationToken);
        }

        private ExpiryAlertDto ToAlertDto(
            ProductBatch batch,
            DateTime now,
            int? redThreshold = null,
            int? yellowThreshold = null)
        {
            return new ExpiryAlertDto
            {
                ProductBatchId = batch.ProductBatchId,
                ProductId = batch.ProductId,
                ProductName = batch.Product.ProductName,
                ProductCategoryName = batch.Product.ProductCategory?.ProductCategoryName ?? string.Empty,
                BatchCode = batch.BatchCode,
                SectionName = batch.WarehouseSection.SectionName,
                QuantityRemainingKg = batch.QuantityRemainingKg,
                PackedAtUtc = batch.PackedAtUtc,
                EffectiveExpiryAtUtc = batch.EffectiveExpiryAtUtc,
                RemainingHours = (batch.EffectiveExpiryAtUtc - now).TotalHours,
                AlertLevel = GetAlertLevel(
                    batch.EffectiveExpiryAtUtc,
                    now,
                    redThreshold,
                    yellowThreshold),
                BatchStatus = batch.Status,
                ShelfLifeExtended = batch.ShelfLifeExtended
            };
        }

        private ExpiryEmailModel CreateEmailModel(ProductBatch batch, DateTime now, string level)
        {
            return new ExpiryEmailModel(
                batch.Product.ProductName,
                batch.BatchCode,
                batch.WarehouseSection.SectionName,
                batch.QuantityRemainingKg,
                batch.PackedAtUtc,
                batch.EffectiveExpiryAtUtc,
                level,
                (batch.EffectiveExpiryAtUtc - now).TotalHours);
        }

        public string GetAlertLevel(
            DateTime expiryAtUtc,
            DateTime nowUtc,
            int? redThreshold = null,
            int? yellowThreshold = null)
        {
            var hours = (expiryAtUtc - nowUtc).TotalHours;
            if (hours <= 0) return ExpiryAlertLevels.Expired;
            if (hours <= (redThreshold ?? _options.RedThresholdHours))
                return ExpiryAlertLevels.Urgent;
            if (hours <= (yellowThreshold ?? _options.YellowThresholdHours))
                return ExpiryAlertLevels.Warning;
            return ExpiryAlertLevels.Normal;
        }

        private async Task<int> SettingInt(
            string key,
            int fallback,
            CancellationToken cancellationToken) =>
            _settings is null
                ? fallback
                : await _settings.GetIntAsync(key, cancellationToken);

        private static string CreateActionToken()
        {
            return Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
                .Replace('+', '-')
                .Replace('/', '_')
                .TrimEnd('=');
        }

        private static string HashToken(string token)
        {
            return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
        }
    }
}
