using System.Data;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public sealed class OrderWorkflowService : IOrderWorkflowService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IOrderStockService _stockService;
    private readonly IOrderService _orderService;

    public OrderWorkflowService(
        PhenyoSyncDbContext context,
        IOrderStockService stockService,
        IOrderService orderService)
    {
        _context = context;
        _stockService = stockService;
        _orderService = orderService;
    }

    public Task<SalesOrderDetailDto> ApproveAsync(
        int orderId,
        OrderDecisionDto request,
        int userId,
        CancellationToken cancellationToken) =>
        DecideAsync(
            orderId,
            request,
            userId,
            approved: true,
            cancellationToken);

    public Task<SalesOrderDetailDto> RejectAsync(
        int orderId,
        OrderDecisionDto request,
        int userId,
        CancellationToken cancellationToken) =>
        DecideAsync(
            orderId,
            request,
            userId,
            approved: false,
            cancellationToken);

    private async Task<SalesOrderDetailDto> DecideAsync(
        int orderId,
        OrderDecisionDto request,
        int userId,
        bool approved,
        CancellationToken cancellationToken)
    {
        var suppliedReason = request.Reason?.Trim();
        var auditDescription = string.IsNullOrWhiteSpace(suppliedReason)
            ? approved ? "Order accepted." : "Order denied."
            : suppliedReason;

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var order = await _context.SalesOrders
            .Include(item => item.StockReservations)
            .Include(item => item.StatusHistory)
            .FirstOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
            ?? throw new OrderManagementException(404, "Sales order not found.");
        if (!SalesOrderStatuses.IsPendingCommercialDecision(order.Status))
            throw new OrderManagementException(
                409,
                "Only a submitted order can receive a commercial decision.");

        await _stockService.ReleaseActiveReservationsAsync(order, cancellationToken);
        var previous = order.Status;
        var now = DateTime.UtcNow;
        order.Status = approved
            ? SalesOrderStatuses.Approved
            : SalesOrderStatuses.Rejected;
        order.ValidationStatus = approved
            ? OrderValidationStatuses.Approved
            : OrderValidationStatuses.Rejected;
        order.ValidationMessage = approved
            ? "Order accepted. Warehouse readiness and stock allocation are handled separately."
            : string.IsNullOrWhiteSpace(suppliedReason)
                ? "Order denied."
                : $"Order denied. Reason: {suppliedReason}";
        order.ValidatedByUserId = userId;
        order.ValidatedAtUtc = now;
        order.UpdatedAtUtc = now;
        order.StatusHistory.Add(History(
            orderId,
            previous,
            order.Status,
            userId,
            auditDescription));
        await _context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return await _orderService.GetAsync(orderId, cancellationToken);
    }

    public async Task<SalesOrderDetailDto> CancelAsync(
        int orderId,
        CancelOrderDto request,
        int userId,
        CancellationToken cancellationToken)
    {
        if (!request.Confirmed)
            throw new OrderManagementException(400, "Explicit cancellation confirmation is required.");

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var order = await _context.SalesOrders
            .Include(item => item.StockReservations)
            .Include(item => item.StatusHistory)
            .Include(item => item.Invoice)
            .FirstOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
            ?? throw new OrderManagementException(404, "Sales order not found.");

        if (!string.Equals(request.ConfirmationText.Trim(), order.OrderNumber, StringComparison.OrdinalIgnoreCase))
            throw new OrderManagementException(400, $"Type {order.OrderNumber} to confirm cancellation.");
        if (SalesOrderStatuses.IsPendingCommercialDecision(order.Status) ||
            order.Status == SalesOrderStatuses.Rejected)
            throw new OrderManagementException(409, "Only an accepted order can be cancelled.");
        if (order.Status is SalesOrderStatuses.Packed or
            SalesOrderStatuses.ReadyForDispatch or
            SalesOrderStatuses.OutForDelivery or
            SalesOrderStatuses.Delivered)
            throw new OrderManagementException(409, "Packed or delivered orders cannot be cancelled; use a future returns/write-off process.");
        if (order.Status == SalesOrderStatuses.Cancelled)
            throw new OrderManagementException(409, "This order is already cancelled.");

        var previous = order.Status;
        await _stockService.ReleaseActiveReservationsAsync(order, cancellationToken);
        order.Status = SalesOrderStatuses.Cancelled;
        order.CancelledByUserId = userId;
        order.CancelledAtUtc = DateTime.UtcNow;
        order.CancellationReason = request.Reason.Trim();
        order.UpdatedAtUtc = DateTime.UtcNow;
        if (order.Invoice is not null) order.Invoice.Status = InvoiceStatuses.Cancelled;
        order.StatusHistory.Add(History(orderId, previous, order.Status, userId, request.Reason));
        await _context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return await _orderService.GetAsync(orderId, cancellationToken);
    }

    public async Task<SalesOrderDetailDto> TransitionAsync(
        int orderId,
        UpdateOrderStatusDto request,
        int userId,
        string role,
        CancellationToken cancellationToken)
    {
        // First reject unknown status text. This keeps the database state
        // machine limited to the values listed in SalesOrderStatuses.
        if (!SalesOrderStatuses.All.Contains(request.NewStatus))
            throw new OrderManagementException(400, "The requested order status is not valid.");

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        // Serializable isolation keeps the status, packing scans, reservations
        // and stock consumption consistent when two requests arrive together.
        var order = await _context.SalesOrders
            .Include(item => item.Customer)
            .Include(item => item.Items)
            .Include(item => item.PackingScans)
            .Include(item => item.StockReservations)
            .Include(item => item.StatusHistory)
            .Include(item => item.Invoice)
            .FirstOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
            ?? throw new OrderManagementException(404, "Sales order not found.");

        var completionOperationHash = request.NewStatus == SalesOrderStatuses.Packed
            ? MobileSecurity.Hash(
                string.IsNullOrWhiteSpace(request.OperationId)
                    ? $"order-packing:{orderId}"
                    : request.OperationId)
            : null;
        // A mobile retry carries the same operation id. If the first request
        // already committed, return the current order without deducting again.
        if (order.Status == SalesOrderStatuses.Packed &&
            completionOperationHash is not null)
        {
            if (string.Equals(
                    order.PackingCompletionOperationKeyHash,
                    completionOperationHash,
                    StringComparison.Ordinal))
            {
                await transaction.CommitAsync(cancellationToken);
                return await _orderService.GetAsync(orderId, cancellationToken);
            }

            throw new OrderManagementException(
                409,
                "Packing was already committed by another operation. Reload the order before continuing.");
        }

        var expected = order.Status switch
        {
            SalesOrderStatuses.Approved => SalesOrderStatuses.Packing,
            SalesOrderStatuses.Confirmed => SalesOrderStatuses.Packing,
            SalesOrderStatuses.Packing => SalesOrderStatuses.Packed,
            SalesOrderStatuses.Packed => SalesOrderStatuses.ReadyForDispatch,
            SalesOrderStatuses.ReadyForDispatch => SalesOrderStatuses.OutForDelivery,
            SalesOrderStatuses.OutForDelivery => SalesOrderStatuses.Delivered,
            _ => null
        };
        // The expected-next-state map prevents skipping business checkpoints.
        if (expected is null || request.NewStatus != expected)
            throw new OrderManagementException(409, $"Status cannot change from {order.Status} to {request.NewStatus}.");

        var isPacker = string.Equals(role, "Packer", StringComparison.OrdinalIgnoreCase);
        if (isPacker && !((order.Status is SalesOrderStatuses.Approved or SalesOrderStatuses.Confirmed) &&
                          request.NewStatus == SalesOrderStatuses.Packing) &&
            !(order.Status == SalesOrderStatuses.Packing && request.NewStatus == SalesOrderStatuses.Packed))
            throw new OrderManagementException(403, "Packers may only start and complete packing.");

        if (request.NewStatus == SalesOrderStatuses.ReadyForDispatch)
        {
            // Dispatch readiness needs commercial approval, full reservation
            // coverage and full packing coverage for every active order line.
            if (order.ValidationStatus != OrderValidationStatuses.Approved)
                throw new OrderManagementException(409, "The order must be commercially approved before dispatch readiness can be confirmed.");
            EnsureKnownFulfilmentWeights(order);
            var activeByItem = order.StockReservations
                .Where(item => item.Status == OrderReservationStatuses.Active)
                .GroupBy(item => item.SalesOrderItemId)
                .ToDictionary(group => group.Key, group => group.Sum(item => item.QuantityReservedKg));
            if (order.Items.Where(item => item.IsActive).Any(item =>
                activeByItem.GetValueOrDefault(item.SalesOrderItemId) != item.QuantityKg))
                throw new OrderManagementException(409, "The order does not have complete active stock reservations.");
            var packedByItem = order.PackingScans
                .Where(item => item.RemovedAtUtc == null)
                .GroupBy(item => item.SalesOrderItemId)
                .ToDictionary(group => group.Key, group => group.Sum(item => item.QuantityPackedKg));
            if (order.Items.Where(item => item.IsActive).Any(item =>
                packedByItem.GetValueOrDefault(item.SalesOrderItemId) != item.QuantityKg))
                throw new OrderManagementException(409, "Every required Product line must be fully packed before dispatch readiness can be confirmed.");
            await IssueInvoiceAsync(order, cancellationToken);
        }

        if (request.NewStatus == SalesOrderStatuses.Packed)
        {
            // Packing completion validates reservations and stores the retry
            // key, but physical stock is not consumed until dispatch starts.
            EnsureKnownFulfilmentWeights(order);
            await _stockService.EnsurePackableReservationsAsync(order, cancellationToken);
            order.PackingCompletionOperationKeyHash = completionOperationHash;
            order.PackedByUserId = userId;
            order.PackedAtUtc = DateTime.UtcNow;
        }

        if (request.NewStatus == SalesOrderStatuses.OutForDelivery)
        {
            // Stock is consumed once at this controlled transition. The hashed
            // packing operation key and transaction make retries safe.
            await ConsumeReservationsAsync(order, userId, cancellationToken);
        }

        var previous = order.Status;
        order.Status = request.NewStatus;
        order.UpdatedAtUtc = DateTime.UtcNow;
        order.StatusHistory.Add(History(orderId, previous, order.Status, userId, request.Reason));
        await _context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        // Return a freshly mapped detail view with the final history/status.
        return await _orderService.GetAsync(orderId, cancellationToken);
    }

    public async Task<InvoiceDto> GetInvoiceAsync(int orderId, CancellationToken cancellationToken)
    {
        var invoice = await _context.Invoices.AsNoTracking()
            .Include(item => item.SalesOrder).ThenInclude(order => order.Items)
            .FirstOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
            ?? throw new OrderManagementException(404, "An invoice has not been issued for this order.");
        return new InvoiceDto
        {
            InvoiceId = invoice.InvoiceId,
            InvoiceNumber = invoice.InvoiceNumber,
            OrderNumber = invoice.SalesOrder.OrderNumber,
            IssuedAtUtc = invoice.IssuedAtUtc,
            CustomerName = invoice.CustomerNameSnapshot,
            CustomerEmail = invoice.CustomerEmailSnapshot,
            BillingAddress = invoice.BillingAddressSnapshot,
            Subtotal = invoice.Subtotal,
            TaxAmount = invoice.TaxAmount,
            TotalAmount = invoice.TotalAmount,
            InvoiceStatus = invoice.Status,
            OrderStatus = invoice.SalesOrder.Status,
            Items = invoice.SalesOrder.Items.Where(item => item.IsActive).Select(item => new OrderItemDto
            {
                SalesOrderItemId = item.SalesOrderItemId,
                ProductId = item.ProductId,
                ProductName = item.ProductNameSnapshot,
                ProductSize = item.ProductSizeSnapshot,
                QuantityKg = item.QuantityKg,
                UnitPricePerKg = item.UnitPricePerKg,
                QuantityUnits = item.QuantityUnits ?? item.QuantityKg,
                SellingUnit = item.SellingUnitSnapshot ?? "kg",
                KilogramsPerUnit = item.KilogramsPerUnitSnapshot,
                UnitPrice = item.UnitPrice ?? item.UnitPricePerKg,
                PriceBasis = item.PriceBasisSnapshot ?? "LegacyPerKilogram",
                LineTotal = item.LineTotal,
                Notes = item.Notes
            }).ToList()
        };
    }

    private static void EnsureKnownFulfilmentWeights(SalesOrder order)
    {
        var missing = order.Items.FirstOrDefault(item =>
            item.IsActive && !item.HasKnownFulfilmentWeight);
        if (missing is not null)
            throw new OrderManagementException(
                409,
                $"{missing.ProductNameSnapshot} cannot enter warehouse fulfilment until its weight conversion is configured and the order is resaved.");
    }

    public Task ApplyLogisticsTransitionAsync(
        SalesOrder order,
        string newStatus,
        int userId,
        string? reason,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var valid = order.Status switch
        {
            SalesOrderStatuses.OutForDelivery => newStatus == SalesOrderStatuses.Delivered,
            _ => false
        };
        if (!valid)
            throw new OrderManagementException(
                409,
                $"Order status cannot change from {order.Status} to {newStatus} during delivery.");

        var previous = order.Status;
        order.Status = newStatus;
        order.UpdatedAtUtc = DateTime.UtcNow;
        order.StatusHistory.Add(History(
            order.SalesOrderId,
            previous,
            newStatus,
            userId,
            reason));
        return Task.CompletedTask;
    }

    private async Task IssueInvoiceAsync(SalesOrder order, CancellationToken cancellationToken)
    {
        var invoice = order.Invoice;
        if (invoice is null)
        {
            invoice = new Invoice { SalesOrderId = order.SalesOrderId };
            _context.Invoices.Add(invoice);
            order.Invoice = invoice;
        }
        invoice.InvoiceNumber = string.IsNullOrWhiteSpace(invoice.InvoiceNumber)
            ? await CreateInvoiceNumberAsync(cancellationToken)
            : invoice.InvoiceNumber;
        invoice.IssuedAtUtc = DateTime.UtcNow;
        invoice.CustomerNameSnapshot = order.Customer.CustomerName;
        invoice.CustomerEmailSnapshot = order.Customer.Email;
        invoice.BillingAddressSnapshot = order.BillingAddressSnapshot;
        invoice.Subtotal = order.Subtotal;
        invoice.TaxAmount = order.TaxAmount;
        invoice.TotalAmount = order.TotalAmount;
        invoice.Status = InvoiceStatuses.Issued;
    }

    private async Task ConsumeReservationsAsync(
        SalesOrder order,
        int userId,
        CancellationToken cancellationToken)
    {
        await _stockService.EnsurePackableReservationsAsync(order, cancellationToken);
        var reservations = await _context.OrderStockReservations
            .Include(item => item.ProductBatch).ThenInclude(batch => batch.Product)
            .Include(item => item.Stock)
            .Where(item => item.SalesOrderId == order.SalesOrderId && item.Status == OrderReservationStatuses.Active)
            .OrderBy(item => item.ProductBatch.EffectiveExpiryAtUtc)
            .ThenBy(item => item.ProductBatchId)
            .ToListAsync(cancellationToken);
        if (reservations.Count == 0)
            throw new OrderManagementException(409, "The order has no active stock reservations to consume.");

        foreach (var reservation in reservations)
        {
            var batch = reservation.ProductBatch;
            var stock = reservation.Stock;
            if (batch.Status != ProductBatchStatuses.Available ||
                batch.Product.Status != ProductStatuses.Active ||
                batch.EffectiveExpiryAtUtc <= DateTime.UtcNow ||
                batch.QuantityRemainingKg < reservation.QuantityReservedKg ||
                stock.QuantityAvailableKg < reservation.QuantityReservedKg)
                throw new OrderManagementException(409, $"Batch {batch.BatchCode} is no longer available for packing.");

            batch.QuantityRemainingKg -= reservation.QuantityReservedKg;
            batch.UpdatedAtUtc = DateTime.UtcNow;
            if (batch.QuantityRemainingKg == 0) batch.Status = ProductBatchStatuses.Consumed;
            stock.QuantityAvailableKg -= reservation.QuantityReservedKg;
            stock.InventoryStatus = stock.QuantityAvailableKg > 0
                ? ProductBatchStatuses.Available
                : ProductBatchStatuses.Consumed;
            reservation.Status = OrderReservationStatuses.Consumed;
            reservation.ConsumedAtUtc = DateTime.UtcNow;
            _context.StockMovements.Add(new StockMovement
            {
                ProductId = reservation.ProductId,
                ProductBatchId = reservation.ProductBatchId,
                SectionId = reservation.SectionId,
                MovementType = StockMovementTypes.Decrease,
                QuantityKg = reservation.QuantityReservedKg,
                OccurredAtUtc = DateTime.UtcNow,
                CreatedByUserId = userId,
                SalesOrderId = order.SalesOrderId,
                Reason = $"Dispatched sales order {order.OrderNumber}."
            });
        }
    }

    private async Task<string> CreateInvoiceNumberAsync(CancellationToken cancellationToken)
    {
        for (var attempt = 0; attempt < 20; attempt++)
        {
            var candidate = $"INV-{DateTime.UtcNow:yyyyMM}-{RandomNumberGenerator.GetInt32(0, 1_000_000):D6}";
            if (!await _context.Invoices.AnyAsync(item => item.InvoiceNumber == candidate, cancellationToken))
                return candidate;
        }
        throw new OrderManagementException(409, "Unable to allocate a unique invoice number. Try again.");
    }

    private static OrderStatusHistory History(int orderId, string previous, string next, int userId, string? reason) => new()
    {
        SalesOrderId = orderId,
        PreviousStatus = previous,
        NewStatus = next,
        ChangedByUserId = userId,
        ChangedAtUtc = DateTime.UtcNow,
        Reason = reason?.Trim()
    };
}
