namespace PhenyoSyncAPI.Services;

public sealed class PhaseBException : Exception
{
    public PhaseBException(int statusCode, string message) : base(message)
    {
        StatusCode = statusCode;
    }

    public int StatusCode { get; }
}
