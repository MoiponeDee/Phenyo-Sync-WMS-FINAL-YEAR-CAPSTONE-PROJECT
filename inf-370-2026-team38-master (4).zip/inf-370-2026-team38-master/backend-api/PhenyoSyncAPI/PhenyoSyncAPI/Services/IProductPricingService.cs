using PhenyoSyncAPI.DTOs.Pricing;
using PhenyoSyncAPI.Entities;

// Defines effective-price operations so callers cannot bypass pricing rules.
namespace PhenyoSyncAPI.Services;

public interface IProductPricingService
{
    Task<ProductPriceResponseDto> CreateAsync(
        CreateProductPriceDto request,
        int userId,
        CancellationToken cancellationToken);

    Task<ProductPriceChangeResponseDto> UpdateAsync(
        int productPriceId,
        UpdateProductPriceDto request,
        int userId,
        CancellationToken cancellationToken);

    Task<ProductPricePageDto> SearchAsync(
        ProductPriceSearchDto request,
        bool mayViewDeleted,
        CancellationToken cancellationToken);

    Task<ProductPriceResponseDto> GetAsync(
        int productPriceId,
        bool mayViewDeleted,
        CancellationToken cancellationToken);

    Task<List<ProductPriceResponseDto>> GetHistoryAsync(
        int productId,
        bool mayViewDeleted,
        CancellationToken cancellationToken);

    Task<ProductPriceResponseDto> SoftDeleteAsync(
        int productPriceId,
        DeleteProductPriceDto request,
        int userId,
        CancellationToken cancellationToken);

    Task<IReadOnlyDictionary<int, ProductPrice>> GetCurrentPricesForProductsAsync(
        IReadOnlyCollection<int> productIds,
        CancellationToken cancellationToken);

    Task<List<OrderableProductPriceDto>> GetOrderableProductsAsync(
        CancellationToken cancellationToken);
}
