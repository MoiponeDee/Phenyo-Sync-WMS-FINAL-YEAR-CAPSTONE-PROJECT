namespace PhenyoSyncAPI.Services;

public sealed class PhaseCException : Exception
{
    public PhaseCException(
        int statusCode,
        string message,
        object? details = null) : base(message)
    {
        StatusCode = statusCode;
        Details = details;
    }

    public int StatusCode { get; }
    public object? Details { get; }
}
