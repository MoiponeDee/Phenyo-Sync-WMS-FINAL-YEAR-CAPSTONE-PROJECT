using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public interface IMobileDashboardService
{
    Task<MobileDashboardDto> GetAsync(
        int userId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<MobileDeliverySummaryDto>> DeliveriesAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task RecordDeliveryEventAsync(
        int deliveryId,
        string eventType,
        MobileDeliveryEventRequest request,
        int userId,
        bool manageAll,
        string correlationId,
        CancellationToken cancellationToken);
}

/// <summary>Builds a permission-filtered mobile workload summary for the signed-in operator.</summary>
public sealed class MobileDashboardService : IMobileDashboardService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IPermissionService _permissions;

    public MobileDashboardService(
        PhenyoSyncDbContext context,
        IPermissionService permissions)
    {
        _context = context;
        _permissions = permissions;
    }

    // Workload cards are built from effective permissions, not from a client-selected dashboard role.
    public async Task<MobileDashboardDto> GetAsync(
        int userId,
        CancellationToken cancellationToken)
    {
        var snapshot = await _permissions.GetSnapshotAsync(userId, cancellationToken)
            ?? throw new PhaseCException(401, "The mobile session is not valid.");
        if (!snapshot.IsActive)
            throw new PhaseCException(403, "The user account is not active.");

        var codes = snapshot.Permissions
            .Select(item => item.Code)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var now = DateTime.UtcNow;
        var dayEnd = now.Date.AddDays(1);
        var driverId = await _context.Drivers.AsNoTracking()
            .Where(item => item.UserId == userId)
            .Select(item => (int?)item.DriverId)
            .SingleOrDefaultAsync(cancellationToken);
        var deliveryViewAll =
            codes.Contains(Permissions.Mobile.DeliveryViewAll);
        var buyingListViewAll =
            codes.Contains(Permissions.Mobile.BuyingListViewAll);
        var deliveryScope = _context.Deliveries.AsNoTracking().AsQueryable();
        if (!deliveryViewAll)
            deliveryScope = driverId.HasValue
                ? deliveryScope.Where(item => item.DriverId == driverId)
                : deliveryScope.Where(_ => false);

        var deliveriesToday = await deliveryScope.CountAsync(
            item =>
                item.ScheduledStartUtc < dayEnd &&
                item.ScheduledEndUtc >= now.Date,
            cancellationToken);
        var activeDeliveries = await deliveryScope.CountAsync(
            item => item.Status == DeliveryStatuses.InTransit,
            cancellationToken);
        var unread = await _context.OperationalNotificationRecipients.AsNoTracking()
            .CountAsync(
                item =>
                    item.UserId == userId &&
                    item.ReadAtUtc == null &&
                    item.DismissedAtUtc == null,
                cancellationToken);
        var canViewBuyingLists =
            codes.Contains(Permissions.Mobile.BuyingListView) ||
            buyingListViewAll;
        var buyingRemaining = canViewBuyingLists
            ? await _context.BuyerProcurementItems.AsNoTracking()
                .CountAsync(
                    item =>
                        (buyingListViewAll ||
                         item.BuyerProcurement.AssignedBuyerUserId == userId) &&
                        item.Status == BuyingItemStatuses.Pending,
                    cancellationToken)
            : 0;
        var receipts = codes.Contains(Permissions.Mobile.StockReceiptView)
            ? await _context.StockReceipts.AsNoTracking()
                .CountAsync(
                    item =>
                        item.Status == MobileOperationStatuses.Draft &&
                        (deliveryViewAll || item.ReceivedByUserId == userId),
                    cancellationToken)
            : 0;
        var packing = codes.Contains(Permissions.Mobile.PackingView)
            ? await _context.SalesOrders.AsNoTracking()
                .CountAsync(
                    item =>
                        item.Status == SalesOrderStatuses.Approved ||
                        item.Status == SalesOrderStatuses.Confirmed ||
                        item.Status == SalesOrderStatuses.Packing,
                    cancellationToken)
            : 0;
        var dispatch = codes.Contains(Permissions.Mobile.DispatchView)
            ? await _context.SalesOrders.AsNoTracking()
                .CountAsync(
                    item => item.Status == SalesOrderStatuses.ReadyForDispatch,
                    cancellationToken)
            : 0;
        var criticalExpiry = codes.Contains(Permissions.Mobile.WriteOffView)
            ? await _context.ProductBatches.AsNoTracking()
                .CountAsync(
                    item =>
                        item.QuantityRemainingKg > 0 &&
                        item.Status != ProductBatchStatuses.WrittenOff &&
                        item.EffectiveExpiryAtUtc <= now.AddHours(24),
                    cancellationToken)
            : 0;
        var approvals = codes.Contains(Permissions.Mobile.WriteOffApprove)
            ? await _context.StockWriteOffs.AsNoTracking()
                .CountAsync(
                    item => item.Status == WriteOffStatuses.PendingApproval,
                    cancellationToken)
            : 0;

        var workload = await WorkloadChartAsync(
            snapshot.RoleCode,
            userId,
            driverId,
            deliveryViewAll,
            buyingListViewAll,
            deliveriesToday,
            activeDeliveries,
            buyingRemaining,
            packing,
            dispatch,
            cancellationToken);
        var activity = await ActivityTrendAsync(
            snapshot.RoleCode,
            userId,
            driverId,
            deliveryViewAll,
            buyingListViewAll,
            now.Date.AddDays(-6),
            cancellationToken);

        return new MobileDashboardDto
        {
            RoleCode = snapshot.RoleCode,
            DisplayName = snapshot.Email,
            UnreadNotifications = unread,
            DeliveriesToday = deliveriesToday,
            ActiveDeliveries = activeDeliveries,
            BuyingItemsRemaining = buyingRemaining,
            DraftStockReceipts = receipts,
            PackingTasks = packing,
            DispatchQueue = dispatch,
            CriticalExpiryAlerts = criticalExpiry,
            PendingWriteOffApprovals = approvals,
            WorkloadChartTitle = workload.Title,
            WorkloadChart = workload.Points,
            ActivityTrendTitle = activity.Title,
            ActivityTrend = activity.Points,
            Modules = Modules(codes, unread, dispatch, approvals)
        };
    }

    private async Task<DashboardChart> WorkloadChartAsync(
        string roleCode,
        int userId,
        int? driverId,
        bool deliveryViewAll,
        bool buyingListViewAll,
        int deliveriesToday,
        int activeDeliveries,
        int buyingRemaining,
        int packing,
        int dispatch,
        CancellationToken cancellationToken)
    {
        if (string.Equals(roleCode, RoleCodes.Packer, StringComparison.OrdinalIgnoreCase))
        {
            var statuses = await _context.SalesOrders.AsNoTracking()
                .Where(order =>
                    order.Status == SalesOrderStatuses.Approved ||
                    order.Status == SalesOrderStatuses.Confirmed ||
                    order.Status == SalesOrderStatuses.Packing ||
                    order.Status == SalesOrderStatuses.Packed)
                .Select(order => order.Status)
                .ToListAsync(cancellationToken);

            return new DashboardChart(
                "Packing queue by status",
                [
                    new("Eligible", statuses.Count(status =>
                        status == SalesOrderStatuses.Approved ||
                        status == SalesOrderStatuses.Confirmed)),
                    new("Packing", statuses.Count(status => status == SalesOrderStatuses.Packing)),
                    new("Awaiting review", statuses.Count(status => status == SalesOrderStatuses.Packed))
                ]);
        }

        if (string.Equals(roleCode, RoleCodes.Driver, StringComparison.OrdinalIgnoreCase))
        {
            var query = _context.Deliveries.AsNoTracking().AsQueryable();
            query = deliveryViewAll
                ? query
                : driverId.HasValue
                    ? query.Where(delivery => delivery.DriverId == driverId)
                    : query.Where(_ => false);
            var statuses = await query
                .Where(delivery => delivery.Status != DeliveryStatuses.Cancelled)
                .Select(delivery => delivery.Status)
                .ToListAsync(cancellationToken);

            return new DashboardChart(
                "My deliveries by status",
                [
                    new("Scheduled", statuses.Count(status => status == DeliveryStatuses.Scheduled)),
                    new("Assigned", statuses.Count(status => status == DeliveryStatuses.Assigned)),
                    new("In transit", statuses.Count(status => status == DeliveryStatuses.InTransit)),
                    new("Completed", statuses.Count(status => status == DeliveryStatuses.Completed))
                ]);
        }

        if (string.Equals(roleCode, RoleCodes.MarketBuyer, StringComparison.OrdinalIgnoreCase))
        {
            var statuses = await _context.BuyerProcurementItems.AsNoTracking()
                .Where(item =>
                    buyingListViewAll ||
                    item.BuyerProcurement.AssignedBuyerUserId == userId)
                .Select(item => item.Status)
                .ToListAsync(cancellationToken);

            return new DashboardChart(
                "Buying items by status",
                [
                    new("Pending", statuses.Count(status => status == BuyingItemStatuses.Pending)),
                    new("Purchased", statuses.Count(status => status == BuyingItemStatuses.Purchased)),
                    new("Unavailable", statuses.Count(status => status == BuyingItemStatuses.Unavailable)),
                    new("Substituted", statuses.Count(status => status == BuyingItemStatuses.Substituted))
                ]);
        }

        return new DashboardChart(
            "Current operational workload",
            [
                new("Deliveries", deliveriesToday),
                new("On route", activeDeliveries),
                new("Buying", buyingRemaining),
                new("Packing", packing),
                new("Dispatch", dispatch)
            ]);
    }

    private async Task<DashboardChart> ActivityTrendAsync(
        string roleCode,
        int userId,
        int? driverId,
        bool deliveryViewAll,
        bool buyingListViewAll,
        DateTime startDateUtc,
        CancellationToken cancellationToken)
    {
        if (string.Equals(roleCode, RoleCodes.Packer, StringComparison.OrdinalIgnoreCase))
        {
            var dates = await _context.SalesOrders.AsNoTracking()
                .Where(order => order.PackedAtUtc >= startDateUtc)
                .Select(order => order.PackedAtUtc)
                .ToListAsync(cancellationToken);
            return DailyChart("Orders packed over seven days", startDateUtc, dates);
        }

        if (string.Equals(roleCode, RoleCodes.Driver, StringComparison.OrdinalIgnoreCase))
        {
            var query = _context.Deliveries.AsNoTracking().AsQueryable();
            query = deliveryViewAll
                ? query
                : driverId.HasValue
                    ? query.Where(delivery => delivery.DriverId == driverId)
                    : query.Where(_ => false);
            var dates = await query
                .Where(delivery => delivery.CompletedAtUtc >= startDateUtc)
                .Select(delivery => delivery.CompletedAtUtc)
                .ToListAsync(cancellationToken);
            return DailyChart("Deliveries completed over seven days", startDateUtc, dates);
        }

        if (string.Equals(roleCode, RoleCodes.MarketBuyer, StringComparison.OrdinalIgnoreCase))
        {
            var dates = await _context.BuyerProcurements.AsNoTracking()
                .Where(procurement =>
                    procurement.SubmittedAtUtc >= startDateUtc &&
                    (buyingListViewAll || procurement.AssignedBuyerUserId == userId))
                .Select(procurement => procurement.SubmittedAtUtc)
                .ToListAsync(cancellationToken);
            return DailyChart("Buying lists submitted over seven days", startDateUtc, dates);
        }

        var packedDates = await _context.SalesOrders.AsNoTracking()
            .Where(order => order.PackedAtUtc >= startDateUtc)
            .Select(order => order.PackedAtUtc)
            .ToListAsync(cancellationToken);
        var deliveryDates = await _context.Deliveries.AsNoTracking()
            .Where(delivery => delivery.CompletedAtUtc >= startDateUtc)
            .Select(delivery => delivery.CompletedAtUtc)
            .ToListAsync(cancellationToken);
        return DailyChart(
            "Completed warehouse activity over seven days",
            startDateUtc,
            packedDates.Concat(deliveryDates));
    }

    private static DashboardChart DailyChart(
        string title,
        DateTime startDateUtc,
        IEnumerable<DateTime?> dates)
    {
        var counts = dates
            .Where(date => date.HasValue)
            .GroupBy(date => date!.Value.Date)
            .ToDictionary(group => group.Key, group => group.Count());
        var points = Enumerable.Range(0, 7)
            .Select(offset => startDateUtc.Date.AddDays(offset))
            .Select(date => new MobileDashboardChartPointDto(
                date.ToString("ddd"),
                counts.GetValueOrDefault(date)))
            .ToList();
        return new DashboardChart(title, points);
    }

    private sealed record DashboardChart(
        string Title,
        IReadOnlyList<MobileDashboardChartPointDto> Points);

    public async Task<IReadOnlyList<MobileDeliverySummaryDto>> DeliveriesAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        var driverId = await _context.Drivers.AsNoTracking()
            .Where(item => item.UserId == userId)
            .Select(item => (int?)item.DriverId)
            .SingleOrDefaultAsync(cancellationToken);
        var query = _context.Deliveries.AsNoTracking().AsQueryable();
        if (!viewAll)
        {
            if (!driverId.HasValue) return [];
            query = query.Where(item => item.DriverId == driverId);
        }

        return await query
            .Where(item =>
                (item.SalesOrder.Status == SalesOrderStatuses.OutForDelivery &&
                 (item.Status == DeliveryStatuses.Assigned ||
                  item.Status == DeliveryStatuses.InTransit)) ||
                (item.Status == DeliveryStatuses.Completed &&
                 item.CompletedAtUtc >= DateTime.UtcNow.AddDays(-14)))
            .OrderBy(item => item.Status == DeliveryStatuses.InTransit ? 0 : 1)
            .ThenBy(item => item.ScheduledStartUtc)
            .Select(item => new MobileDeliverySummaryDto
            {
                DeliveryId = item.DeliveryId,
                SalesOrderId = item.SalesOrderId,
                OrderNumber = item.SalesOrder.OrderNumber,
                CustomerName = item.SalesOrder.Customer.CustomerName,
                ContactPerson = item.SalesOrder.Customer.ContactPerson,
                PhoneNumber = item.SalesOrder.Customer.PhoneNumber,
                DeliveryAddress = item.DeliveryAddressSnapshot,
                ScheduledStartUtc = item.ScheduledStartUtc,
                ScheduledEndUtc = item.ScheduledEndUtc,
                Status = item.Status,
                Vehicle = item.Driver != null ? item.Driver.VehicleAssigned : null,
                DriverName = item.Driver == null
                    ? null
                    : item.Driver.User.FirstName + " " + item.Driver.User.LastName,
                ItemSummary = item.SalesOrder.Items
                    .Where(line => line.IsActive)
                    .OrderBy(line => line.SalesOrderItemId)
                    .Select(line =>
                        line.ProductNameSnapshot + " × " +
                        (line.QuantityUnits.HasValue
                            ? line.QuantityUnits + " " + line.SellingUnitSnapshot
                            : line.QuantityKg + " kg"))
                    .ToList(),
                LastTrackingUpdateUtc = _context.DriverLocationUpdates
                    .Where(location =>
                        location.TrackingSession.DeliveryId == item.DeliveryId)
                    .Max(location => (DateTime?)location.ReceivedAtUtc),
                LastTrackingAccuracyMetres = _context.DriverLocationUpdates
                    .Where(location =>
                        location.TrackingSession.DeliveryId == item.DeliveryId)
                    .OrderByDescending(location => location.ReceivedAtUtc)
                    .Select(location => (decimal?)location.AccuracyMetres)
                    .FirstOrDefault(),
                HasActiveTracking = _context.DriverTrackingSessions.Any(session =>
                    session.DeliveryId == item.DeliveryId &&
                    session.Status == TrackingSessionStatuses.Active),
                HasProof = item.ProofImages.Any(proof => proof.RemovedAtUtc == null)
            })
            .ToListAsync(cancellationToken);
    }

    // Delivery events use operation keys so a weak mobile connection cannot duplicate milestones.
    public async Task RecordDeliveryEventAsync(
        int deliveryId,
        string eventType,
        MobileDeliveryEventRequest request,
        int userId,
        bool manageAll,
        string correlationId,
        CancellationToken cancellationToken)
    {
        if (eventType is not ("Acknowledged" or "Arrived" or "Issue"))
            throw new PhaseCException(400, "The delivery event type is invalid.");
        var delivery = await _context.Deliveries
            .Include(item => item.Driver)
            .SingleOrDefaultAsync(
                item => item.DeliveryId == deliveryId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Delivery not found.");
        var isAssignedDriver = delivery.Driver?.UserId == userId;
        if (!manageAll && !isAssignedDriver)
            throw new PhaseCException(403, "This delivery is not assigned to you.");
        if (delivery.Status is DeliveryStatuses.Completed or DeliveryStatuses.Cancelled)
            throw new PhaseCException(409, "The delivery is no longer active.");
        if (eventType == "Arrived" && delivery.Status != DeliveryStatuses.InTransit)
            throw new PhaseCException(409, "Arrival can be recorded only in transit.");

        var operationHash = MobileSecurity.Hash(request.OperationId);
        if (await _context.MobileIdempotencyRecords.AsNoTracking().AnyAsync(
                item =>
                    item.UserId == userId &&
                    item.OperationType == $"Delivery{eventType}" &&
                    item.OperationKeyHash == operationHash,
                cancellationToken))
            return;

        _context.MobileDeliveryEvents.Add(new MobileDeliveryEvent
        {
            DeliveryId = deliveryId,
            RecordedByUserId = userId,
            EventType = eventType,
            Notes = request.Notes.Trim(),
            RecordedAtUtc = DateTime.UtcNow,
            CorrelationId = correlationId
        });
        _context.MobileIdempotencyRecords.Add(
            MobileSecurity.Receipt(
                userId,
                $"Delivery{eventType}",
                request.OperationId,
                request.Notes,
                "{\"recorded\":true}"));
        await _context.SaveChangesAsync(cancellationToken);
    }

    private static IReadOnlyList<MobileModuleDto> Modules(
        IReadOnlySet<string> permissions,
        int unread,
        int dispatch,
        int approvals)
    {
        var modules = new List<MobileModuleDto>();
        Add(Permissions.Mobile.DeliveryViewOwn, "deliveries", "Deliveries", "/deliveries", "navigate");
        Add(
            Permissions.Mobile.DeliveryViewAll,
            "tracking",
            "Live tracking",
            "/deliveries",
            "location");
        AddAny(
            [
                Permissions.Mobile.BuyingListView,
                Permissions.Mobile.BuyingListViewAll
            ],
            "buying",
            "Buying list",
            "/buying-list",
            "cart");
        Add(Permissions.Mobile.StockReceiptView, "receiving", "Receive stock", "/stock-receipts", "cube");
        Add(Permissions.Mobile.PackingView, "packing", "Pack orders", "/packing", "barcode");
        Add(Permissions.Mobile.DispatchView, "dispatch", "Dispatch", "/dispatch", "send", dispatch);
        Add(Permissions.Mobile.WriteOffView, "writeoffs", "Write-offs", "/write-offs", "warning", approvals);
        Add(
            Permissions.Mobile.NotificationView,
            "notifications",
            "Notifications",
            "/notifications",
            "notifications",
            unread);
        return modules;

        void Add(
            string permission,
            string code,
            string title,
            string route,
            string icon,
            int badge = 0)
        {
            if (permissions.Contains(permission))
                modules.Add(new MobileModuleDto(code, title, route, icon, badge));
        }

        void AddAny(
            IEnumerable<string> requiredPermissions,
            string code,
            string title,
            string route,
            string icon,
            int badge = 0)
        {
            if (requiredPermissions.Any(permissions.Contains))
                modules.Add(new MobileModuleDto(code, title, route, icon, badge));
        }
    }
}

internal static class MobileSecurity
{
    public static string Hash(string value) =>
        Convert.ToHexString(
            System.Security.Cryptography.SHA256.HashData(
                System.Text.Encoding.UTF8.GetBytes(value.Trim())));

    public static MobileIdempotencyRecord Receipt(
        int userId,
        string operationType,
        string operationId,
        string requestValue,
        string responseJson) =>
        new()
        {
            UserId = userId,
            OperationType = operationType,
            OperationKeyHash = Hash(operationId),
            RequestHash = Hash(requestValue),
            ResponseJson = responseJson,
            CreatedAtUtc = DateTime.UtcNow,
            ExpiresAtUtc = DateTime.UtcNow.AddDays(7)
        };
}
