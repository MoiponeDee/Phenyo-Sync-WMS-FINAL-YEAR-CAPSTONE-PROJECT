﻿namespace PhenyoSyncAPI.Services
{
    // Email is abstracted so business workflows surface send failures and tests can avoid real SMTP.
    public interface IEmailService
    {
        Task SendPasswordResetEmailAsync(
            string recipientEmail,
            string resetLink
        );

        Task SendExpiryAlertEmailAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string reviewLink,
            CancellationToken cancellationToken = default);

        Task SendExpiryDecisionConfirmationAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string decision,
            CancellationToken cancellationToken = default);

        Task SendCustomerOrderLinkEmailAsync(
            string recipientEmail,
            string customerName,
            string orderLink,
            DateTime expiresAtUtc,
            CancellationToken cancellationToken = default);

        Task SendLoginOtpEmailAsync(
            string recipientEmail,
            string recipientName,
            string otp,
            DateTime expiresAtUtc,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;

        Task SendRecoveryCodeUsedNotificationAsync(
            string recipientEmail,
            string recipientName,
            DateTime usedAtUtc,
            CancellationToken cancellationToken = default) =>
            Task.CompletedTask;
    }

    public record ExpiryEmailModel(
        string ProductName,
        string BatchCode,
        string SectionName,
        decimal QuantityRemainingKg,
        DateTime PackedAtUtc,
        DateTime EffectiveExpiryAtUtc,
        string AlertLevel,
        double RemainingHours);
}
