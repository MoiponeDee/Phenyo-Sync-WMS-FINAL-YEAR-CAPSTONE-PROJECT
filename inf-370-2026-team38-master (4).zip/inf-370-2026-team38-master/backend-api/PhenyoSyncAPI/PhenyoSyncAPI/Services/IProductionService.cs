using PhenyoSyncAPI.DTOs.Product;

namespace PhenyoSyncAPI.Services
{
    public interface IProductionService
    {
        Task<IReadOnlyList<PackableProductDto>> PackableProductsAsync(
            int sectionId,
            CancellationToken cancellationToken);

        Task<MakeProductResponseDto> MakeProductAsync(
            CreateProductDto request,
            int? userId,
            CancellationToken cancellationToken);
    }
}
