using System.Globalization;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;

namespace PhenyoSyncAPI.Services;

public sealed record DeliveryRouteProviderResult(
    long DistanceMetres,
    int DurationSeconds,
    int? TrafficDurationSeconds,
    string? EncodedPolyline);

public interface IDeliveryRouteProvider
{
    bool IsConfigured { get; }
    Task<DeliveryRouteProviderResult> CalculateAsync(
        CalculateRouteRequest request,
        bool trafficAware,
        CancellationToken cancellationToken);
}

public interface IDeliveryRouteService
{
    Task<DeliveryRouteDto> StatusAsync(
        int deliveryId,
        CancellationToken cancellationToken);

    Task<DeliveryRouteDto> CalculateAsync(
        int deliveryId,
        CalculateRouteRequest request,
        CancellationToken cancellationToken);
}

/// <summary>Calls the configured Google route provider without persisting or logging API secrets.</summary>
public sealed class GoogleMapsRouteProvider : IDeliveryRouteProvider
{
    private readonly HttpClient _http;
    private readonly GoogleMapsOptions _options;

    public GoogleMapsRouteProvider(
        HttpClient http,
        IOptions<GoogleMapsOptions> options)
    {
        _http = http;
        _options = options.Value;
        _http.Timeout = TimeSpan.FromSeconds(
            Math.Clamp(_options.TimeoutSeconds, 5, 60));
    }

    public bool IsConfigured => _options.IsConfigured;

    public async Task<DeliveryRouteProviderResult> CalculateAsync(
        CalculateRouteRequest request,
        bool trafficAware,
        CancellationToken cancellationToken)
    {
        if (!IsConfigured)
            throw new PhaseCException(
                503,
                "Google Maps routing is not configured for this environment.");

        using var message = new HttpRequestMessage(
            HttpMethod.Post,
            _options.RoutesEndpoint);
        message.Headers.Add("X-Goog-Api-Key", _options.ServerApiKey);
        message.Headers.Add(
            "X-Goog-FieldMask",
            "routes.distanceMeters,routes.duration,routes.staticDuration,routes.polyline.encodedPolyline");
        message.Content = JsonContent.Create(new
        {
            origin = Waypoint(request.OriginLatitude, request.OriginLongitude),
            destination = Waypoint(
                request.DestinationLatitude,
                request.DestinationLongitude),
            travelMode = "DRIVE",
            routingPreference = trafficAware
                ? "TRAFFIC_AWARE"
                : "TRAFFIC_UNAWARE",
            computeAlternativeRoutes = false,
            languageCode = "en",
            units = "METRIC"
        });

        using var response = await _http.SendAsync(message, cancellationToken);
        if (!response.IsSuccessStatusCode)
            throw new PhaseCException(
                503,
                "The route provider could not calculate this delivery route.");
        using var document = JsonDocument.Parse(
            await response.Content.ReadAsStreamAsync(cancellationToken));
        var routes = document.RootElement.GetProperty("routes");
        if (routes.GetArrayLength() == 0)
            throw new PhaseCException(
                422,
                "No driving route was found for the selected points.");
        var route = routes[0];
        var duration = Seconds(route.GetProperty("duration").GetString());
        var normalDuration = route.TryGetProperty(
                "staticDuration",
                out var staticDuration)
            ? Seconds(staticDuration.GetString())
            : duration;
        var polyline = route.TryGetProperty("polyline", out var polylineObject) &&
                       polylineObject.TryGetProperty(
                           "encodedPolyline",
                           out var encoded)
            ? encoded.GetString()
            : null;
        return new DeliveryRouteProviderResult(
            route.GetProperty("distanceMeters").GetInt64(),
            normalDuration,
            trafficAware ? duration : null,
            polyline);
    }

    private static object Waypoint(decimal latitude, decimal longitude) =>
        new
        {
            location = new
            {
                latLng = new
                {
                    latitude,
                    longitude
                }
            }
        };

    private static int Seconds(string? value)
    {
        if (string.IsNullOrWhiteSpace(value) ||
            !value.EndsWith('s') ||
            !decimal.TryParse(
                value[..^1],
                NumberStyles.Number,
                CultureInfo.InvariantCulture,
                out var seconds))
            throw new PhaseCException(
                503,
                "The route provider returned an invalid duration.");
        return checked((int)Math.Ceiling(seconds));
    }
}

/// <summary>Builds delivery routes from persisted stops and falls back safely when routing is unavailable.</summary>
public sealed class DeliveryRouteService : IDeliveryRouteService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IDeliveryRouteProvider _provider;
    private readonly ISystemSettingProvider _settings;

    public DeliveryRouteService(
        PhenyoSyncDbContext context,
        IDeliveryRouteProvider provider,
        ISystemSettingProvider settings)
    {
        _context = context;
        _provider = provider;
        _settings = settings;
    }

    public async Task<DeliveryRouteDto> StatusAsync(
        int deliveryId,
        CancellationToken cancellationToken)
    {
        await EnsureDeliveryAsync(deliveryId, cancellationToken);
        var route = await _context.DeliveryRouteCalculations.AsNoTracking()
            .Where(item => item.DeliveryId == deliveryId)
            .OrderByDescending(item => item.CalculatedAtUtc)
            .FirstOrDefaultAsync(cancellationToken);
        return route is null
            ? new DeliveryRouteDto
            {
                DeliveryId = deliveryId,
                ProviderConfigured = _provider.IsConfigured,
                ConfigurationMessage = _provider.IsConfigured
                    ? "No route has been calculated yet."
                    : "Google Maps routing is not configured."
            }
            : Map(route, false);
    }

    public async Task<DeliveryRouteDto> CalculateAsync(
        int deliveryId,
        CalculateRouteRequest request,
        CancellationToken cancellationToken)
    {
        await EnsureDeliveryAsync(deliveryId, cancellationToken);
        if (!_provider.IsConfigured)
            return new DeliveryRouteDto
            {
                DeliveryId = deliveryId,
                ProviderConfigured = false,
                ConfigurationMessage =
                    "Google Maps routing is disabled until protected server configuration is supplied."
            };
        var fingerprint = Fingerprint(request);
        var cacheMinutes = await _settings.GetIntAsync(
            SystemSettingKeys.MapsRouteCacheMinutes,
            cancellationToken);
        if (!request.ForceRefresh)
        {
            var cached = await _context.DeliveryRouteCalculations.AsNoTracking()
                .Where(item =>
                    item.DeliveryId == deliveryId &&
                    item.RequestFingerprint == fingerprint &&
                    item.ExpiresAtUtc > DateTime.UtcNow)
                .OrderByDescending(item => item.CalculatedAtUtc)
                .FirstOrDefaultAsync(cancellationToken);
            if (cached is not null) return Map(cached, true);
        }

        var trafficAware = await _settings.GetBooleanAsync(
            SystemSettingKeys.MapsTrafficAwareEnabled,
            cancellationToken);
        var result = await _provider.CalculateAsync(
            request,
            trafficAware,
            cancellationToken);
        var now = DateTime.UtcNow;
        var calculation = new DeliveryRouteCalculation
        {
            DeliveryId = deliveryId,
            OriginLatitude = request.OriginLatitude,
            OriginLongitude = request.OriginLongitude,
            DestinationLatitude = request.DestinationLatitude,
            DestinationLongitude = request.DestinationLongitude,
            DistanceMetres = result.DistanceMetres,
            DurationSeconds = result.DurationSeconds,
            TrafficDurationSeconds = result.TrafficDurationSeconds,
            EncodedPolyline = result.EncodedPolyline,
            Provider = "GoogleRoutes",
            RequestFingerprint = fingerprint,
            CalculatedAtUtc = now,
            ExpiresAtUtc = now.AddMinutes(cacheMinutes)
        };
        _context.DeliveryRouteCalculations.Add(calculation);
        await _context.SaveChangesAsync(cancellationToken);
        return Map(calculation, false);
    }

    private async Task EnsureDeliveryAsync(
        int deliveryId,
        CancellationToken cancellationToken)
    {
        if (!await _context.Deliveries.AsNoTracking().AnyAsync(
                item => item.DeliveryId == deliveryId,
                cancellationToken))
            throw new PhaseCException(404, "Delivery not found.");
    }

    private static string Fingerprint(CalculateRouteRequest request)
    {
        var value = FormattableString.Invariant(
            $"{request.OriginLatitude:F6}|{request.OriginLongitude:F6}|{request.DestinationLatitude:F6}|{request.DestinationLongitude:F6}");
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));
    }

    private DeliveryRouteDto Map(
        DeliveryRouteCalculation item,
        bool fromCache) =>
        new()
        {
            RouteCalculationId = item.DeliveryRouteCalculationId,
            DeliveryId = item.DeliveryId,
            ProviderConfigured = _provider.IsConfigured,
            FromCache = fromCache,
            Provider = item.Provider,
            DistanceMetres = item.DistanceMetres,
            DurationSeconds = item.DurationSeconds,
            TrafficDurationSeconds = item.TrafficDurationSeconds,
            EncodedPolyline = item.EncodedPolyline,
            CalculatedAtUtc = item.CalculatedAtUtc,
            ExpiresAtUtc = item.ExpiresAtUtc
        };
}
