using System.Data;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Operational;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IOperationalPartyService
{
    Task<IReadOnlyList<CustomerSummaryDto>> CustomersAsync(
        string? search,
        bool includeInactive,
        CancellationToken cancellationToken);
    Task<CustomerSummaryDto> CustomerAsync(
        int id,
        CancellationToken cancellationToken);
    Task<CustomerSummaryDto> SaveCustomerAsync(
        int? id,
        SaveCustomerRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<PartyDeleteResult> DeleteCustomerAsync(
        int id,
        string reason,
        string? rowVersion,
        int userId,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<SupplierSummaryDto>> SuppliersAsync(
        string? search,
        bool includeInactive,
        CancellationToken cancellationToken);
    Task<SupplierSummaryDto> SaveSupplierAsync(
        int? id,
        SaveSupplierRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<PartyDeleteResult> DeleteSupplierAsync(
        int id,
        string reason,
        string? rowVersion,
        int userId,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<SupplierOrderDto>> SupplierOrdersAsync(
        CancellationToken cancellationToken);
    Task<IReadOnlyList<SupplierOrderRawStockOptionDto>> SupplierOrderRawStockOptionsAsync(
        CancellationToken cancellationToken);
    Task<SupplierOrderDto> CreateSupplierOrderAsync(
        CreateSupplierOrderRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<SupplierOrderDto> ApproveSupplierOrderAsync(
        int id,
        string rowVersion,
        int userId,
        CancellationToken cancellationToken);
    Task<SupplierOrderDto> UpdateSupplierOrderAsync(
        int id,
        CreateSupplierOrderRequest request,
        string rowVersion,
        int userId,
        CancellationToken cancellationToken);
    Task<SupplierOrderDto> CancelSupplierOrderAsync(
        int id,
        SupplierOrderCommandRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<PaymentDto>> PaymentsAsync(
        PaymentSearchRequest request,
        CancellationToken cancellationToken);
    Task<PaymentDto> PaymentAsync(
        long id,
        CancellationToken cancellationToken);
    Task<PaymentCaptureOptionsDto> PaymentCaptureOptionsAsync(
        bool includeCustomers,
        bool includeSuppliers,
        CancellationToken cancellationToken);
    Task<PaymentDto> CapturePaymentAsync(
        PaymentRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<PaymentDto> RequestReversalAsync(
        long id,
        PaymentDecisionRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<PaymentDto> DecideReversalAsync(
        long id,
        bool approved,
        PaymentDecisionRequest request,
        int userId,
        CancellationToken cancellationToken);
}

public sealed record PartyDeleteResult(
    bool Deleted,
    string Message,
    string? DeleteBlockedReason,
    bool CanDeactivate);

public sealed class OperationalPartyService : IOperationalPartyService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _audit;

    public OperationalPartyService(
        PhenyoSyncDbContext context,
        IAuditService audit)
    {
        _context = context;
        _audit = audit;
    }

    public async Task<IReadOnlyList<CustomerSummaryDto>> CustomersAsync(
        string? search,
        bool includeInactive,
        CancellationToken cancellationToken)
    {
        var query = _context.Customers.AsNoTracking().AsQueryable();
        if (!includeInactive)
            query = query.Where(item => item.Status == CustomerStatuses.Active);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            var normalized = term.ToUpperInvariant();
            query = query.Where(item =>
                item.CustomerNumber.Contains(term) ||
                item.CustomerName.Contains(term) ||
                item.NormalizedEmail.Contains(normalized));
        }

        var customers = await query
            .Include(item => item.SalesOrders)
                .ThenInclude(order => order.Invoice)
            .Include(item => item.Payments)
            .OrderBy(item => item.CustomerName)
            .ToListAsync(cancellationToken);

        return customers.Select(ToCustomerSummary).ToList();
    }

    public async Task<CustomerSummaryDto> CustomerAsync(
        int id,
        CancellationToken cancellationToken)
    {
        var item = await _context.Customers.AsNoTracking()
            .Include(value => value.SalesOrders)
                .ThenInclude(order => order.Invoice)
            .Include(value => value.Payments)
            .SingleOrDefaultAsync(
                value => value.CustomerId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Customer not found.");

        return ToCustomerSummary(item);
    }

    public async Task<CustomerSummaryDto> SaveCustomerAsync(
        int? id,
        SaveCustomerRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var normalizedEmail = Required(request.Email).ToUpperInvariant();
        if (await _context.Customers.AnyAsync(
                item => item.NormalizedEmail == normalizedEmail &&
                        (!id.HasValue || item.CustomerId != id.Value),
                cancellationToken))
            throw new PhaseCException(409, "A customer with this email already exists.");

        Customer item;
        if (id.HasValue)
        {
            item = await _context.Customers.SingleOrDefaultAsync(
                    value => value.CustomerId == id.Value,
                    cancellationToken)
                ?? throw new PhaseCException(404, "Customer not found.");
            ValidateVersion(item.RowVersion, request.RowVersion);
            item.UpdatedAtUtc = DateTime.UtcNow;
        }
        else
        {
            item = new Customer
            {
                CustomerNumber =
                    $"CUS-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid():N}"[..21]
                        .ToUpperInvariant(),
                CreatedAtUtc = DateTime.UtcNow
            };
            _context.Customers.Add(item);
        }
        item.CustomerName = Required(request.CustomerName);
        item.Email = Required(request.Email).ToLowerInvariant();
        item.NormalizedEmail = normalizedEmail;
        item.ContactPerson = Clean(request.ContactPerson);
        item.PhoneNumber = Clean(request.PhoneNumber);
        item.BillingAddress = Clean(request.BillingAddress);
        item.DeliveryAddress = Clean(request.DeliveryAddress);
        item.Status = Required(request.Status);
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            id.HasValue ? AuditActionTypes.Update : AuditActionTypes.Create,
            id.HasValue ? "Update customer" : "Create customer",
            AuditModules.CustomerManagement,
            nameof(Customer),
            item.CustomerId,
            item.CustomerName,
            userId,
            new Dictionary<string, object?>
            {
                ["customerNumber"] = item.CustomerNumber,
                ["status"] = item.Status
            },
            cancellationToken);
        var saved = await _context.Customers.AsNoTracking()
            .Include(value => value.SalesOrders)
                .ThenInclude(order => order.Invoice)
            .Include(value => value.Payments)
            .SingleAsync(
                value => value.CustomerId == item.CustomerId,
                cancellationToken);
        return ToCustomerSummary(saved);
    }

    private static CustomerSummaryDto ToCustomerSummary(Customer item) =>
        new()
        {
            CustomerId = item.CustomerId,
            CustomerNumber = item.CustomerNumber,
            CustomerName = item.CustomerName,
            Email = item.Email,
            ContactPerson = item.ContactPerson,
            PhoneNumber = item.PhoneNumber,
            BillingAddress = item.BillingAddress,
            DeliveryAddress = item.DeliveryAddress,
            Status = item.Status,
            OrderCount = item.SalesOrders.Count,
            OutstandingBalance =
                item.SalesOrders
                    .Where(order => order.Invoice != null)
                    .Sum(order => order.Invoice!.TotalAmount) -
                item.Payments
                    .Where(payment =>
                        payment.Status == FinancialPaymentStatuses.Posted)
                    .Sum(payment => payment.Amount),
            RowVersion = Encode(item.RowVersion)
        };

    public async Task<PartyDeleteResult> DeleteCustomerAsync(
        int id,
        string reason,
        string? rowVersion,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await _context.Customers.SingleOrDefaultAsync(
                value => value.CustomerId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Customer not found.");
        ValidateVersion(item.RowVersion, rowVersion);

        var hasHistory = await _context.SalesOrders.AnyAsync(
                value => value.CustomerId == id,
                cancellationToken) ||
            await _context.CustomerOrderLinks.AnyAsync(
                value => value.CustomerId == id,
                cancellationToken) ||
            await _context.FinancialPayments.AnyAsync(
                value => value.CustomerId == id,
                cancellationToken);
        if (hasHistory)
        {
            return new PartyDeleteResult(
                false,
                "This customer has business history and cannot be permanently deleted.",
                "Orders, customer links, invoices, or payments must be retained.",
                item.Status != CustomerStatuses.Inactive);
        }

        _context.Customers.Remove(item);
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Delete,
            "Delete unused customer",
            AuditModules.CustomerManagement,
            nameof(Customer),
            id,
            item.CustomerName,
            userId,
            new Dictionary<string, object?> { ["reason"] = Required(reason) },
            cancellationToken);
        return new PartyDeleteResult(
            true,
            "Unused customer permanently deleted.",
            null,
            false);
    }

    public async Task<IReadOnlyList<SupplierSummaryDto>> SuppliersAsync(
        string? search,
        bool includeInactive,
        CancellationToken cancellationToken)
    {
        var query = _context.Suppliers.AsNoTracking().AsQueryable();
        if (!includeInactive)
            query = query.Where(item => item.Status == "Active");
        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            var normalized = term.ToUpperInvariant();
            query = query.Where(item =>
                item.SupplierCode.Contains(term) ||
                item.SupplierName.Contains(term) ||
                (item.NormalizedEmail != null &&
                 item.NormalizedEmail.Contains(normalized)));
        }
        return await query.OrderBy(item => item.SupplierName)
            .Select(item => new SupplierSummaryDto
            {
                SupplierId = item.SupplierId,
                SupplierCode = item.SupplierCode,
                SupplierName = item.SupplierName,
                SupplierTypeCode = item.SupplierTypeCode,
                ContactPerson = item.ContactPerson,
                Email = item.Email,
                Phone = item.Phone,
                Address = item.Address,
                Status = item.Status,
                OrderCount = item.SupplierOrders.Count,
                OutstandingBalance =
                    (item.SupplierOrders.Sum(
                        order => (decimal?)order.TotalAmount) ?? 0) -
                    (item.Payments
                        .Where(payment =>
                            payment.Status == FinancialPaymentStatuses.Posted)
                        .Sum(payment => (decimal?)payment.Amount) ?? 0),
                RowVersion = item.RowVersion == null
                    ? string.Empty
                    : Convert.ToBase64String(item.RowVersion)
            })
            .ToListAsync(cancellationToken);
    }

    public async Task<SupplierSummaryDto> SaveSupplierAsync(
        int? id,
        SaveSupplierRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var normalizedEmail = Clean(request.Email)?.ToUpperInvariant();
        if (normalizedEmail is not null &&
            await _context.Suppliers.AnyAsync(
                item => item.NormalizedEmail == normalizedEmail &&
                        (!id.HasValue || item.SupplierId != id.Value),
                cancellationToken))
            throw new PhaseCException(409, "A supplier with this email already exists.");

        Supplier item;
        if (id.HasValue)
        {
            item = await _context.Suppliers.SingleOrDefaultAsync(
                    value => value.SupplierId == id.Value,
                    cancellationToken)
                ?? throw new PhaseCException(404, "Supplier not found.");
            ValidateVersion(item.RowVersion, request.RowVersion);
            item.UpdatedAtUtc = DateTime.UtcNow;
        }
        else
        {
            item = new Supplier
            {
                SupplierCode =
                    $"SUP-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid():N}"[..21]
                        .ToUpperInvariant(),
                CreatedAtUtc = DateTime.UtcNow
            };
            _context.Suppliers.Add(item);
        }
        item.SupplierName = Required(request.SupplierName);
        item.SupplierTypeCode = Required(request.SupplierTypeCode);
        item.ContactPerson = Clean(request.ContactPerson);
        item.Email = Clean(request.Email)?.ToLowerInvariant();
        item.NormalizedEmail = normalizedEmail;
        item.Phone = Clean(request.Phone);
        item.Address = Clean(request.Address);
        item.Status = Required(request.Status);
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            id.HasValue ? AuditActionTypes.Update : AuditActionTypes.Create,
            id.HasValue ? "Update supplier" : "Create supplier",
            AuditModules.SupplierManagement,
            nameof(Supplier),
            item.SupplierId,
            item.SupplierName,
            userId,
            new Dictionary<string, object?>
            {
                ["supplierCode"] = item.SupplierCode,
                ["supplierType"] = item.SupplierTypeCode,
                ["status"] = item.Status
            },
            cancellationToken);
        return await _context.Suppliers.AsNoTracking()
            .Where(value => value.SupplierId == item.SupplierId)
            .Select(value => new SupplierSummaryDto
            {
                SupplierId = value.SupplierId,
                SupplierCode = value.SupplierCode,
                SupplierName = value.SupplierName,
                SupplierTypeCode = value.SupplierTypeCode,
                ContactPerson = value.ContactPerson,
                Email = value.Email,
                Phone = value.Phone,
                Address = value.Address,
                Status = value.Status,
                OrderCount = value.SupplierOrders.Count,
                OutstandingBalance =
                    (value.SupplierOrders.Sum(
                        order => (decimal?)order.TotalAmount) ?? 0) -
                    (value.Payments
                        .Where(payment =>
                            payment.Status == FinancialPaymentStatuses.Posted)
                        .Sum(payment => (decimal?)payment.Amount) ?? 0),
                RowVersion = value.RowVersion == null
                    ? string.Empty
                    : Convert.ToBase64String(value.RowVersion)
            })
            .SingleAsync(cancellationToken);
    }

    public async Task<PartyDeleteResult> DeleteSupplierAsync(
        int id,
        string reason,
        string? rowVersion,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await _context.Suppliers.SingleOrDefaultAsync(
                value => value.SupplierId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Supplier not found.");
        ValidateVersion(item.RowVersion, rowVersion);

        var hasHistory = await _context.SupplierOrders.AnyAsync(
                value => value.SupplierId == id,
                cancellationToken) ||
            await _context.RawStockBatches.AnyAsync(
                value => value.SupplierId == id,
                cancellationToken) ||
            await _context.RawStockReceipts.AnyAsync(
                value => value.SupplierId == id,
                cancellationToken) ||
            await _context.FinancialPayments.AnyAsync(
                value => value.SupplierId == id,
                cancellationToken) ||
            await _context.BuyerProcurementItems.AnyAsync(
                value => value.SupplierId == id ||
                         value.PreferredSupplierId == id,
                cancellationToken) ||
            await _context.StockReceipts.AnyAsync(
                value => value.SupplierId == id,
                cancellationToken);
        if (hasHistory)
        {
            return new PartyDeleteResult(
                false,
                "This supplier has business history and cannot be permanently deleted.",
                "Orders, receipts, batches, buying activity, or payments must be retained.",
                item.Status != ProductStatuses.Inactive);
        }

        _context.Suppliers.Remove(item);
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Delete,
            "Delete unused supplier",
            AuditModules.SupplierManagement,
            nameof(Supplier),
            id,
            item.SupplierName,
            userId,
            new Dictionary<string, object?> { ["reason"] = Required(reason) },
            cancellationToken);
        return new PartyDeleteResult(
            true,
            "Unused supplier permanently deleted.",
            null,
            false);
    }

    public async Task<IReadOnlyList<SupplierOrderDto>> SupplierOrdersAsync(
        CancellationToken cancellationToken) =>
        await SupplierOrderQuery().AsNoTracking()
            .OrderByDescending(item => item.OrderDate)
            .Take(100)
            .Select(item => SupplierOrderDto(item))
            .ToListAsync(cancellationToken);

    public async Task<IReadOnlyList<SupplierOrderRawStockOptionDto>>
        SupplierOrderRawStockOptionsAsync(CancellationToken cancellationToken) =>
        await _context.RawStockItems
            .AsNoTracking()
            .Where(item => item.IsActive)
            .OrderBy(item => item.ItemName)
            .Select(item => new SupplierOrderRawStockOptionDto
            {
                RawStockItemId = item.RawStockItemId,
                ItemCode = item.ItemCode,
                ItemName = item.ItemName,
                UnitOfMeasure = item.DefaultUnitOfMeasure
            })
            .ToListAsync(cancellationToken);

    public async Task<SupplierOrderDto> CreateSupplierOrderAsync(
        CreateSupplierOrderRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        if (request.Lines.Count == 0)
            throw new PhaseCException(400, "Add at least one supplier-order line.");
        if (!await _context.Suppliers.AnyAsync(
                item => item.SupplierId == request.SupplierId &&
                        item.Status == "Active",
                cancellationToken))
            throw new PhaseCException(400, "Select an active supplier.");
        if (!await _context.WarehouseSections.AnyAsync(
                item => item.SectionId == request.WarehouseSectionId &&
                        item.Status == "Active",
                cancellationToken))
            throw new PhaseCException(400, "Select an active warehouse section.");
        var rawIds = request.Lines
            .Select(item => item.RawStockItemId)
            .Distinct()
            .ToArray();
        if (rawIds.Length != request.Lines.Count ||
            await _context.RawStockItems.CountAsync(
                item => rawIds.Contains(item.RawStockItemId) && item.IsActive,
                cancellationToken) != rawIds.Length)
            throw new PhaseCException(
                400,
                "Supplier-order lines must reference unique active raw-stock items.");

        var now = DateTime.UtcNow;
        var item = new SupplierOrder
        {
            SupplierId = request.SupplierId,
            WarehouseSectionId = request.WarehouseSectionId,
            OrderNumber =
                $"PO-{now:yyyyMMdd}-{Guid.NewGuid():N}"[..20].ToUpperInvariant(),
            OrderDate = now,
            ExpectedDeliveryAtUtc =
                request.ExpectedDeliveryAtUtc?.ToUniversalTime(),
            Status = SupplierOrderStatuses.Draft,
            Notes = Clean(request.Notes),
            CreatedByUserId = userId,
            CreatedAtUtc = now,
            Lines = request.Lines.Select(line => new SupplierOrderLine
            {
                RawStockItemId = line.RawStockItemId,
                OrderedQuantity = line.OrderedQuantity,
                ExpectedUnitPrice = line.ExpectedUnitPrice,
                UnitOfMeasure = Required(line.UnitOfMeasure).ToLowerInvariant(),
                Notes = Clean(line.Notes)
            }).ToList()
        };
        item.TotalAmount = item.Lines.Sum(line =>
            line.OrderedQuantity * line.ExpectedUnitPrice);
        _context.SupplierOrders.Add(item);
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Create,
            "Create supplier order",
            AuditModules.SupplierManagement,
            nameof(SupplierOrder),
            item.SupplierOrderId,
            item.OrderNumber,
            userId,
            new Dictionary<string, object?>
            {
                ["supplierId"] = item.SupplierId,
                ["lineCount"] = item.Lines.Count,
                ["totalAmount"] = item.TotalAmount
            },
            cancellationToken);
        return await SupplierOrderDtoAsync(
            item.SupplierOrderId,
            cancellationToken);
    }

    public async Task<SupplierOrderDto> ApproveSupplierOrderAsync(
        int id,
        string rowVersion,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await _context.SupplierOrders.SingleOrDefaultAsync(
                value => value.SupplierOrderId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Supplier order not found.");
        if (item.Status != SupplierOrderStatuses.Draft)
            throw new PhaseCException(409, "Only a draft supplier order can be approved.");
        ValidateVersion(item.RowVersion, rowVersion);
        item.Status = SupplierOrderStatuses.Ordered;
        item.ApprovedByUserId = userId;
        item.ApprovedAtUtc = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.StatusChange,
            "Place supplier order",
            AuditModules.SupplierManagement,
            nameof(SupplierOrder),
            item.SupplierOrderId,
            item.OrderNumber,
            userId,
            new Dictionary<string, object?> { ["status"] = item.Status },
            cancellationToken);
        return await SupplierOrderDtoAsync(id, cancellationToken);
    }

    public async Task<SupplierOrderDto> UpdateSupplierOrderAsync(
        int id,
        CreateSupplierOrderRequest request,
        string rowVersion,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await _context.SupplierOrders
            .Include(value => value.Lines)
            .SingleOrDefaultAsync(
                value => value.SupplierOrderId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Supplier order not found.");
        if (item.Status != SupplierOrderStatuses.Draft)
            throw new PhaseCException(409, "Only draft Supplier Orders can be edited.");
        ValidateVersion(item.RowVersion, rowVersion);
        await ValidateSupplierOrderRequestAsync(request, cancellationToken);

        item.SupplierId = request.SupplierId;
        item.WarehouseSectionId = request.WarehouseSectionId;
        item.ExpectedDeliveryAtUtc =
            request.ExpectedDeliveryAtUtc?.ToUniversalTime();
        item.Notes = Clean(request.Notes);
        _context.SupplierOrderLines.RemoveRange(item.Lines);
        item.Lines = request.Lines.Select(line => new SupplierOrderLine
        {
            RawStockItemId = line.RawStockItemId,
            OrderedQuantity = line.OrderedQuantity,
            ExpectedUnitPrice = line.ExpectedUnitPrice,
            UnitOfMeasure = Required(line.UnitOfMeasure).ToLowerInvariant(),
            Notes = Clean(line.Notes)
        }).ToList();
        item.TotalAmount = item.Lines.Sum(line =>
            line.OrderedQuantity * line.ExpectedUnitPrice);

        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Update,
            "Update draft supplier order",
            AuditModules.SupplierManagement,
            nameof(SupplierOrder),
            item.SupplierOrderId,
            item.OrderNumber,
            userId,
            new Dictionary<string, object?>
            {
                ["lineCount"] = item.Lines.Count,
                ["totalAmount"] = item.TotalAmount
            },
            cancellationToken);
        return await SupplierOrderDtoAsync(id, cancellationToken);
    }

    public async Task<SupplierOrderDto> CancelSupplierOrderAsync(
        int id,
        SupplierOrderCommandRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await _context.SupplierOrders.SingleOrDefaultAsync(
                value => value.SupplierOrderId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Supplier order not found.");
        if (item.Status is SupplierOrderStatuses.FullyReceived or
            SupplierOrderStatuses.Cancelled)
            throw new PhaseCException(
                409,
                "A fully received or cancelled Supplier Order cannot be cancelled.");
        ValidateVersion(item.RowVersion, request.RowVersion);
        item.Status = SupplierOrderStatuses.Cancelled;
        item.CancelledAtUtc = DateTime.UtcNow;
        item.Notes = string.Join(
            Environment.NewLine,
            new[] { item.Notes, $"Cancellation reason: {Required(request.Reason)}" }
                .Where(value => !string.IsNullOrWhiteSpace(value)));
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.StatusChange,
            "Cancel supplier order",
            AuditModules.SupplierManagement,
            nameof(SupplierOrder),
            item.SupplierOrderId,
            item.OrderNumber,
            userId,
            new Dictionary<string, object?>
            {
                ["status"] = item.Status,
                ["reason"] = request.Reason
            },
            cancellationToken);
        return await SupplierOrderDtoAsync(id, cancellationToken);
    }

    public async Task<IReadOnlyList<PaymentDto>> PaymentsAsync(
        PaymentSearchRequest request,
        CancellationToken cancellationToken)
    {
        var query = PaymentQuery().AsNoTracking();
        if (!string.IsNullOrWhiteSpace(request.CounterpartyType))
        {
            var type = request.CounterpartyType.Trim();
            query = query.Where(item => item.CounterpartyType == type);
        }
        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var search = request.Search.Trim();
            query = query.Where(item =>
                item.PaymentNumber.Contains(search) ||
                (item.Reference != null && item.Reference.Contains(search)) ||
                (item.Customer != null &&
                    (item.Customer.CustomerName.Contains(search) ||
                     item.Customer.CustomerNumber.Contains(search))) ||
                (item.Supplier != null &&
                    (item.Supplier.SupplierName.Contains(search) ||
                     item.Supplier.SupplierCode.Contains(search))));
        }
        if (!string.IsNullOrWhiteSpace(request.Status))
        {
            var status = request.Status.Trim();
            query = query.Where(item => item.Status == status);
        }
        if (!string.IsNullOrWhiteSpace(request.PaymentMethodCode))
        {
            var method = request.PaymentMethodCode.Trim();
            query = query.Where(item => item.PaymentMethodCode == method);
        }
        if (request.FromUtc.HasValue)
        {
            var from = request.FromUtc.Value.ToUniversalTime();
            query = query.Where(item => item.PaymentDateUtc >= from);
        }
        if (request.ToUtc.HasValue)
        {
            var to = request.ToUtc.Value.ToUniversalTime();
            query = query.Where(item => item.PaymentDateUtc <= to);
        }
        var payments = await query.OrderByDescending(item => item.PaymentDateUtc)
            .ThenByDescending(item => item.FinancialPaymentId)
            .Take(200)
            .ToListAsync(cancellationToken);
        if (payments.Count == 0) return [];

        var selectedIds = payments
            .Select(item => item.FinancialPaymentId)
            .ToHashSet();
        var invoiceIds = payments
            .Where(item => item.InvoiceId.HasValue)
            .Select(item => item.InvoiceId!.Value)
            .Distinct()
            .ToArray();
        var supplierOrderIds = payments
            .Where(item => item.SupplierOrderId.HasValue)
            .Select(item => item.SupplierOrderId!.Value)
            .Distinct()
            .ToArray();
        // Search controls which rows are returned, never the accounting history
        // used to calculate each row's before/after outstanding balance.
        var ledger = await PaymentQuery().AsNoTracking()
            .Where(item =>
                (item.InvoiceId.HasValue && invoiceIds.Contains(item.InvoiceId.Value)) ||
                (item.SupplierOrderId.HasValue &&
                 supplierOrderIds.Contains(item.SupplierOrderId.Value)))
            .ToListAsync(cancellationToken);

        return MapPayments(ledger)
            .Where(item => selectedIds.Contains(item.FinancialPaymentId))
            .OrderByDescending(item => item.PaymentDateUtc)
            .ThenByDescending(item => item.FinancialPaymentId)
            .ToArray();
    }

    public Task<PaymentDto> PaymentAsync(
        long id,
        CancellationToken cancellationToken) =>
        PaymentDtoAsync(id, cancellationToken);

    public async Task<PaymentCaptureOptionsDto> PaymentCaptureOptionsAsync(
        bool includeCustomers,
        bool includeSuppliers,
        CancellationToken cancellationToken)
    {
        var customers = new List<PaymentCustomerOptionDto>();
        var customerOrders = new List<PaymentCustomerOrderOptionDto>();
        var invoices = new List<PaymentInvoiceOptionDto>();
        var suppliers = new List<PaymentSupplierOptionDto>();
        var supplierOrders = new List<PaymentSupplierOrderOptionDto>();

        if (includeCustomers)
        {
            var postedByInvoice = await _context.FinancialPayments
                .AsNoTracking()
                .Where(item =>
                    item.InvoiceId.HasValue &&
                    item.Status == FinancialPaymentStatuses.Posted)
                .GroupBy(item => item.InvoiceId!.Value)
                .Select(group => new
                {
                    InvoiceId = group.Key,
                    Paid = group.Sum(item => item.Amount)
                })
                .ToDictionaryAsync(
                    item => item.InvoiceId,
                    item => item.Paid,
                    cancellationToken);

            var invoiceRecords = await _context.Invoices
                .AsNoTracking()
                .Include(item => item.SalesOrder)
                    .ThenInclude(order => order.Customer)
                .Where(item =>
                    item.SalesOrder.Status != SalesOrderStatuses.Cancelled)
                .OrderBy(item => item.SalesOrder.Customer.CustomerName)
                .ThenBy(item => item.InvoiceNumber)
                .ToListAsync(cancellationToken);

            invoices = invoiceRecords
                .Select(item =>
                {
                    var paid = postedByInvoice.GetValueOrDefault(item.InvoiceId);
                    return new PaymentInvoiceOptionDto
                    {
                        InvoiceId = item.InvoiceId,
                        SalesOrderId = item.SalesOrderId,
                        CustomerId = item.SalesOrder.CustomerId,
                        InvoiceNumber = item.InvoiceNumber,
                        TotalAmount = item.TotalAmount,
                        PaidAmount = paid,
                        OutstandingAmount = Math.Max(0m, item.TotalAmount - paid),
                        IssuedAtUtc = item.IssuedAtUtc
                    };
                })
                .Where(item => item.OutstandingAmount > 0m)
                .ToList();

            var payableOrderIds = invoices
                .Select(item => item.SalesOrderId)
                .ToHashSet();
            customerOrders = invoiceRecords
                .Where(item => payableOrderIds.Contains(item.SalesOrderId))
                .Select(item => new PaymentCustomerOrderOptionDto
                {
                    SalesOrderId = item.SalesOrderId,
                    CustomerId = item.SalesOrder.CustomerId,
                    OrderNumber = item.SalesOrder.OrderNumber,
                    Status = item.SalesOrder.Status,
                    TotalAmount = item.TotalAmount,
                    OrderDateUtc = item.SalesOrder.OrderDateUtc
                })
                .DistinctBy(item => item.SalesOrderId)
                .ToList();

            var payableCustomerIds = invoices
                .Select(item => item.CustomerId)
                .ToHashSet();
            customers = invoiceRecords
                .Where(item => payableCustomerIds.Contains(
                    item.SalesOrder.CustomerId))
                .Select(item => new PaymentCustomerOptionDto
                {
                    CustomerId = item.SalesOrder.CustomerId,
                    CustomerNumber = item.SalesOrder.Customer.CustomerNumber,
                    CustomerName = item.SalesOrder.Customer.CustomerName,
                    ContactPerson = item.SalesOrder.Customer.ContactPerson,
                    PhoneNumber = item.SalesOrder.Customer.PhoneNumber,
                    Email = item.SalesOrder.Customer.Email
                })
                .DistinctBy(item => item.CustomerId)
                .OrderBy(item => item.CustomerName)
                .ToList();
        }

        if (includeSuppliers)
        {
            var postedByOrder = await _context.FinancialPayments
                .AsNoTracking()
                .Where(item =>
                    item.SupplierOrderId.HasValue &&
                    item.Status == FinancialPaymentStatuses.Posted)
                .GroupBy(item => item.SupplierOrderId!.Value)
                .Select(group => new
                {
                    SupplierOrderId = group.Key,
                    Paid = group.Sum(item => item.Amount)
                })
                .ToDictionaryAsync(
                    item => item.SupplierOrderId,
                    item => item.Paid,
                    cancellationToken);

            var orderRecords = await _context.SupplierOrders
                .AsNoTracking()
                .Include(item => item.Supplier)
                .Where(item => item.Status != SupplierOrderStatuses.Cancelled)
                .OrderBy(item => item.Supplier.SupplierName)
                .ThenBy(item => item.OrderNumber)
                .ToListAsync(cancellationToken);

            supplierOrders = orderRecords
                .Select(item =>
                {
                    var paid = postedByOrder.GetValueOrDefault(
                        item.SupplierOrderId);
                    return new PaymentSupplierOrderOptionDto
                    {
                        SupplierOrderId = item.SupplierOrderId,
                        SupplierId = item.SupplierId,
                        OrderNumber = item.OrderNumber,
                        Status = item.Status,
                        TotalAmount = item.TotalAmount,
                        PaidAmount = paid,
                        OutstandingAmount = Math.Max(0m, item.TotalAmount - paid),
                        ExpectedDeliveryAtUtc = item.ExpectedDeliveryAtUtc
                    };
                })
                .Where(item => item.OutstandingAmount > 0m)
                .ToList();

            var payableSupplierIds = supplierOrders
                .Select(item => item.SupplierId)
                .ToHashSet();
            suppliers = orderRecords
                .Where(item => payableSupplierIds.Contains(item.SupplierId))
                .Select(item => new PaymentSupplierOptionDto
                {
                    SupplierId = item.SupplierId,
                    SupplierCode = item.Supplier.SupplierCode,
                    SupplierName = item.Supplier.SupplierName,
                    ContactPerson = item.Supplier.ContactPerson,
                    PhoneNumber = item.Supplier.Phone,
                    Email = item.Supplier.Email
                })
                .DistinctBy(item => item.SupplierId)
                .OrderBy(item => item.SupplierName)
                .ToList();
        }

        return new PaymentCaptureOptionsDto
        {
            Customers = customers,
            CustomerOrders = customerOrders,
            Invoices = invoices,
            Suppliers = suppliers,
            SupplierOrders = supplierOrders
        };
    }

    public async Task<PaymentDto> CapturePaymentAsync(
        PaymentRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        // A payment belongs to exactly one side of the business. Customer
        // payments require customer + order + invoice; supplier payments
        // require supplier + supplier order. Mixed references are rejected.
        var isCustomer = request.CustomerId.HasValue &&
                         request.SalesOrderId.HasValue &&
                         request.InvoiceId.HasValue &&
                         !request.SupplierId.HasValue &&
                         !request.SupplierOrderId.HasValue;
        var isSupplier = request.SupplierId.HasValue &&
                         request.SupplierOrderId.HasValue &&
                         !request.CustomerId.HasValue &&
                         !request.SalesOrderId.HasValue &&
                         !request.InvoiceId.HasValue;
        if (!isCustomer && !isSupplier)
            throw new PhaseCException(
                400,
                "A payment must reference exactly one customer invoice or supplier order.");

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        // The serializable transaction prevents two simultaneous payments from
        // both reading the same outstanding amount and overpaying it.

        decimal outstanding;
        string display;
        if (isCustomer)
        {
            var invoice = await _context.Invoices
                .Include(item => item.SalesOrder)
                .SingleOrDefaultAsync(
                    item => item.InvoiceId == request.InvoiceId &&
                            item.SalesOrderId == request.SalesOrderId &&
                            item.SalesOrder.CustomerId == request.CustomerId,
                    cancellationToken)
                ?? throw new PhaseCException(404, "Customer invoice not found.");
            var postedAmounts = await _context.FinancialPayments
                .Where(item => item.InvoiceId == invoice.InvoiceId &&
                               item.Status == FinancialPaymentStatuses.Posted)
                .Select(item => item.Amount)
                .ToListAsync(cancellationToken);
            var paid = postedAmounts.Sum();
            outstanding = invoice.TotalAmount - paid;
            display = invoice.InvoiceNumber;
        }
        else
        {
            var order = await _context.SupplierOrders.SingleOrDefaultAsync(
                item => item.SupplierOrderId == request.SupplierOrderId &&
                        item.SupplierId == request.SupplierId,
                cancellationToken)
                ?? throw new PhaseCException(404, "Supplier order not found.");
            var postedAmounts = await _context.FinancialPayments
                .Where(item => item.SupplierOrderId == order.SupplierOrderId &&
                               item.Status == FinancialPaymentStatuses.Posted)
                .Select(item => item.Amount)
                .ToListAsync(cancellationToken);
            var paid = postedAmounts.Sum();
            outstanding = order.TotalAmount - paid;
            display = order.OrderNumber;
        }
        if (request.Amount > outstanding)
            throw new PhaseCException(
                409,
                $"Payment exceeds the outstanding balance of {outstanding:0.00}.");

        var now = DateTime.UtcNow;
        // The stored payment keeps the exact business document links and a
        // correlation id so finance reports and the audit trail can follow it.
        var item = new FinancialPayment
        {
            PaymentNumber =
                $"PAY-{now:yyyyMMdd}-{Guid.NewGuid():N}"[..21].ToUpperInvariant(),
            CounterpartyType = isCustomer ? "Customer" : "Supplier",
            CustomerId = request.CustomerId,
            SupplierId = request.SupplierId,
            InvoiceId = request.InvoiceId,
            SupplierOrderId = request.SupplierOrderId,
            Amount = request.Amount,
            PaymentDateUtc = request.PaymentDateUtc == default
                ? now
                : request.PaymentDateUtc.ToUniversalTime(),
            PaymentMethodCode = Required(request.PaymentMethodCode),
            Reference = Clean(request.Reference),
            Notes = Clean(request.Notes),
            Status = FinancialPaymentStatuses.Posted,
            CreatedByUserId = userId,
            PostedByUserId = userId,
            CreatedAtUtc = now,
            PostedAtUtc = now,
            CorrelationId = Guid.NewGuid().ToString("N")
        };
        _context.FinancialPayments.Add(item);
        await SaveConcurrencyAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Create,
            $"Capture {item.CounterpartyType.ToLowerInvariant()} payment",
            AuditModules.Payments,
            nameof(FinancialPayment),
            item.FinancialPaymentId,
            item.PaymentNumber,
            userId,
            new Dictionary<string, object?>
            {
                ["amount"] = item.Amount,
                ["document"] = display,
                ["paymentMethod"] = item.PaymentMethodCode,
                ["correlationId"] = item.CorrelationId
            },
            cancellationToken);
        return await PaymentDtoAsync(item.FinancialPaymentId, cancellationToken);
    }

    public async Task<PaymentDto> RequestReversalAsync(
        long id,
        PaymentDecisionRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);

        var original = await _context.FinancialPayments.SingleOrDefaultAsync(
                value => value.FinancialPaymentId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Payment not found.");
        if (original.OriginalPaymentId.HasValue ||
            original.Status != FinancialPaymentStatuses.Posted)
            throw new PhaseCException(409, "Only a posted payment can be reversed.");
        ValidateVersion(original.RowVersion, request.RowVersion);

        var hasExistingReversal = await _context.FinancialPayments.AnyAsync(
            value => value.OriginalPaymentId == original.FinancialPaymentId &&
                     (value.Status == FinancialPaymentStatuses.PendingReversalApproval ||
                      value.Status == FinancialPaymentStatuses.Posted),
            cancellationToken);
        if (hasExistingReversal)
            throw new PhaseCException(
                409,
                "This payment already has a pending or approved reversal.");

        var now = DateTime.UtcNow;
        var adjustment = new FinancialPayment
        {
            PaymentNumber =
                $"REV-{now:yyyyMMdd}-{Guid.NewGuid():N}"[..21].ToUpperInvariant(),
            CounterpartyType = original.CounterpartyType,
            CustomerId = original.CustomerId,
            SupplierId = original.SupplierId,
            InvoiceId = original.InvoiceId,
            SupplierOrderId = original.SupplierOrderId,
            OriginalPaymentId = original.FinancialPaymentId,
            Amount = -original.Amount,
            PaymentDateUtc = now,
            PaymentMethodCode = original.PaymentMethodCode,
            Reference = original.Reference,
            Notes = original.Notes,
            Status = FinancialPaymentStatuses.PendingReversalApproval,
            ReversalReason = Required(request.Reason),
            CreatedByUserId = userId,
            CreatedAtUtc = now,
            CorrelationId = original.CorrelationId
        };
        _context.FinancialPayments.Add(adjustment);
        await SaveConcurrencyAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        // Audit only safe business metadata; no credentials or payment secrets
        // are written into the event details.
        await AuditAsync(
            AuditActionTypes.StatusChange,
            "Request payment reversal",
            AuditModules.Payments,
            nameof(FinancialPayment),
            adjustment.FinancialPaymentId,
            adjustment.PaymentNumber,
            userId,
            new Dictionary<string, object?>
            {
                ["reason"] = request.Reason,
                ["amount"] = adjustment.Amount,
                ["originalPaymentId"] = original.FinancialPaymentId,
                ["correlationId"] = adjustment.CorrelationId
            },
            cancellationToken);
        return await PaymentDtoAsync(
            adjustment.FinancialPaymentId,
            cancellationToken);
    }

    public async Task<PaymentDto> DecideReversalAsync(
        long id,
        bool approved,
        PaymentDecisionRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);

        var adjustment = await _context.FinancialPayments.SingleOrDefaultAsync(
                value => value.FinancialPaymentId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Payment not found.");
        if (!adjustment.OriginalPaymentId.HasValue ||
            adjustment.Status != FinancialPaymentStatuses.PendingReversalApproval ||
            adjustment.Amount >= 0)
            throw new PhaseCException(409, "This payment is not awaiting a reversal decision.");
        if (adjustment.CreatedByUserId == userId)
            throw new PhaseCException(
                409,
                "A payment reversal must be decided by a different authorised user.");

        ValidateVersion(adjustment.RowVersion, request.RowVersion);
        adjustment.DecidedByUserId = userId;
        adjustment.DecidedAtUtc = DateTime.UtcNow;
        adjustment.ReversalReason =
            $"{adjustment.ReversalReason} Decision: {Required(request.Reason)}";
        adjustment.Status = approved
            ? FinancialPaymentStatuses.Posted
            : FinancialPaymentStatuses.Rejected;
        if (approved)
        {
            adjustment.PostedByUserId = userId;
            adjustment.PostedAtUtc = adjustment.DecidedAtUtc;
        }
        await SaveConcurrencyAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.StatusChange,
            approved ? "Approve payment reversal" : "Reject payment reversal",
            AuditModules.Payments,
            nameof(FinancialPayment),
            adjustment.FinancialPaymentId,
            adjustment.PaymentNumber,
            userId,
            new Dictionary<string, object?>
            {
                ["approved"] = approved,
                ["reason"] = request.Reason,
                ["amount"] = adjustment.Amount,
                ["originalPaymentId"] = adjustment.OriginalPaymentId,
                ["correlationId"] = adjustment.CorrelationId
            },
            cancellationToken);
        return await PaymentDtoAsync(id, cancellationToken);
    }

    private IQueryable<SupplierOrder> SupplierOrderQuery() =>
        _context.SupplierOrders
            .Include(item => item.Supplier)
            .Include(item => item.WarehouseSection)
            .Include(item => item.Payments)
            .Include(item => item.Lines)
                .ThenInclude(item => item.RawStockItem);

    private IQueryable<FinancialPayment> PaymentQuery() =>
        _context.FinancialPayments
            .Include(item => item.Customer)
            .Include(item => item.Supplier)
            .Include(item => item.Invoice)
            .Include(item => item.SupplierOrder)
            .Include(item => item.OriginalPayment);

    private async Task<SupplierOrderDto> SupplierOrderDtoAsync(
        int id,
        CancellationToken cancellationToken)
    {
        var item = await SupplierOrderQuery().AsNoTracking().SingleOrDefaultAsync(
                value => value.SupplierOrderId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Supplier order not found.");
        return SupplierOrderDto(item);
    }

    private async Task<PaymentDto> PaymentDtoAsync(
        long id,
        CancellationToken cancellationToken)
    {
        var item = await PaymentQuery().AsNoTracking().SingleOrDefaultAsync(
                value => value.FinancialPaymentId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Payment not found.");
        var related = await PaymentQuery()
            .AsNoTracking()
            .Where(value => item.InvoiceId.HasValue
                ? value.InvoiceId == item.InvoiceId
                : value.SupplierOrderId == item.SupplierOrderId)
            .ToListAsync(cancellationToken);
        return MapPayments(related).Single(value =>
            value.FinancialPaymentId == item.FinancialPaymentId);
    }

    private static SupplierOrderDto SupplierOrderDto(SupplierOrder item) =>
        new()
        {
            SupplierOrderId = item.SupplierOrderId,
            SupplierId = item.SupplierId,
            OrderNumber = item.OrderNumber,
            SupplierName = item.Supplier.SupplierName,
            SupplierContactPerson = item.Supplier.ContactPerson,
            SupplierEmail = item.Supplier.Email,
            SupplierPhone = item.Supplier.Phone,
            WarehouseSectionId = item.WarehouseSectionId,
            WarehouseSection = item.WarehouseSection.SectionName,
            Status = item.Status,
            OrderDateUtc = item.OrderDate,
            ExpectedDeliveryAtUtc = item.ExpectedDeliveryAtUtc,
            TotalAmount = item.TotalAmount,
            OutstandingBalance = item.TotalAmount -
                item.Payments
                    .Where(payment =>
                        payment.Status == FinancialPaymentStatuses.Posted)
                    .Sum(payment => payment.Amount),
            RowVersion = Encode(item.RowVersion),
            Lines = item.Lines.Select(line => new SupplierOrderLineDto
            {
                SupplierOrderLineId = line.SupplierOrderLineId,
                RawStockItemId = line.RawStockItemId,
                ItemName = line.RawStockItem.ItemName,
                OrderedQuantity = line.OrderedQuantity,
                ReceivedQuantity = line.ReceivedQuantity,
                ExpectedUnitPrice = line.ExpectedUnitPrice,
                UnitOfMeasure = line.UnitOfMeasure
            }).ToArray()
        };

    private async Task ValidateSupplierOrderRequestAsync(
        CreateSupplierOrderRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Lines.Count == 0)
            throw new PhaseCException(400, "Add at least one supplier-order line.");
        if (!await _context.Suppliers.AnyAsync(
                item => item.SupplierId == request.SupplierId &&
                        item.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(400, "Select an active supplier.");
        if (!await _context.WarehouseSections.AnyAsync(
                item => item.SectionId == request.WarehouseSectionId &&
                        item.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(400, "Select an active warehouse section.");
        var rawIds = request.Lines
            .Select(item => item.RawStockItemId)
            .Distinct()
            .ToArray();
        if (rawIds.Length != request.Lines.Count ||
            await _context.RawStockItems.CountAsync(
                item => rawIds.Contains(item.RawStockItemId) && item.IsActive,
                cancellationToken) != rawIds.Length)
            throw new PhaseCException(
                400,
                "Supplier-order lines must reference unique active raw-stock items.");
    }

    private static IReadOnlyList<PaymentDto> MapPayments(
        IEnumerable<FinancialPayment> payments)
    {
        var result = new List<PaymentDto>();
        foreach (var group in payments.GroupBy(item => new
                 {
                     item.InvoiceId,
                     item.SupplierOrderId
                 }))
        {
            var ordered = group
                .OrderBy(item => item.PaymentDateUtc)
                .ThenBy(item => item.FinancialPaymentId)
                .ToArray();
            var total = ordered[0].Invoice?.TotalAmount ??
                        ordered[0].SupplierOrder?.TotalAmount ??
                        0;
            decimal effectivePayments = 0;
            foreach (var item in ordered)
            {
                var before = total - effectivePayments;
                if (item.Status == FinancialPaymentStatuses.Posted)
                    effectivePayments += item.Amount;
                var after = total - effectivePayments;

                result.Add(new PaymentDto
                {
                    FinancialPaymentId = item.FinancialPaymentId,
                    OriginalPaymentId = item.OriginalPaymentId,
                    PaymentNumber = item.PaymentNumber,
                    CounterpartyType = item.CounterpartyType,
                    CounterpartyName = item.Customer?.CustomerName ??
                                       item.Supplier?.SupplierName ??
                                       "Unknown",
                    CounterpartyNumber = item.Customer?.CustomerNumber ??
                                         item.Supplier?.SupplierCode,
                    DocumentNumber = item.Invoice?.InvoiceNumber ??
                                     item.SupplierOrder?.OrderNumber,
                    Reference = item.Reference,
                    OriginalPaymentNumber = item.OriginalPayment?.PaymentNumber,
                    Amount = item.Amount,
                    OutstandingBeforePosting = Math.Max(0, before),
                    OutstandingAfterPosting = Math.Max(0, after),
                    PaymentMethodCode = item.PaymentMethodCode,
                    Status = item.Status,
                    ReversalReason = item.ReversalReason,
                    CreatedByUserId = item.CreatedByUserId,
                    PaymentDateUtc = item.PaymentDateUtc,
                    RowVersion = Encode(item.RowVersion)
                });
            }
        }

        return result;
    }

    private async Task AuditAsync(
        string action,
        string operation,
        string module,
        string entityType,
        object entityId,
        string display,
        int userId,
        IReadOnlyDictionary<string, object?> details,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = module,
            OperationName = operation,
            Description = $"{operation}: {display}.",
            EntityType = entityType,
            EntityId = entityId.ToString(),
            EntityDisplay = display,
            UserId = userId,
            SafeDetails = details
        }, cancellationToken);

    private async Task SaveConcurrencyAsync(CancellationToken cancellationToken)
    {
        try
        {
            await _context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new PhaseCException(
                409,
                "This record changed since it was loaded. Reload and try again.");
        }
    }

    private static void ValidateVersion(byte[]? current, string? supplied)
    {
        if (current is null || string.IsNullOrWhiteSpace(supplied))
            return;
        try
        {
            if (!CryptographicOperations.FixedTimeEquals(
                    current,
                    Convert.FromBase64String(supplied)))
                throw new PhaseCException(
                    409,
                    "This record changed since it was loaded. Reload and try again.");
        }
        catch (FormatException)
        {
            throw new PhaseCException(400, "The concurrency token is invalid.");
        }
    }

    private static string Encode(byte[]? value) =>
        value is null ? string.Empty : Convert.ToBase64String(value);

    private static string Required(string value) =>
        string.IsNullOrWhiteSpace(value)
            ? throw new PhaseCException(400, "A required value is missing.")
            : value.Trim();

    private static string? Clean(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
