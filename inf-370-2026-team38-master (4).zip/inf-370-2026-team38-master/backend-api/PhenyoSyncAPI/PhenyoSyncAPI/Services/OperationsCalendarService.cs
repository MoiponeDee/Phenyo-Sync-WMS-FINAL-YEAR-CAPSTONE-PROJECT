using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IOperationsCalendarService
{
    Task<OperationsCalendarResponseDto> GetAsync(
        OperationsCalendarQueryDto query,
        int userId,
        string roleCode,
        CancellationToken cancellationToken);
}

/// <summary>Projects operational milestones into a read-only calendar without changing source workflows.</summary>
public sealed class OperationsCalendarService : IOperationsCalendarService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly ISystemSettingProvider _settings;

    public OperationsCalendarService(
        PhenyoSyncDbContext context,
        ISystemSettingProvider settings)
    {
        _context = context;
        _settings = settings;
    }

    public async Task<OperationsCalendarResponseDto> GetAsync(
        OperationsCalendarQueryDto query,
        int userId,
        string roleCode,
        CancellationToken cancellationToken)
    {
        var start = AsUtc(query.StartUtc);
        var end = AsUtc(query.EndUtc);
        if (start >= end)
            throw new PhaseBException(400, "Calendar start must be before its end.");
        var maximumDays = await _settings.GetIntAsync(
            SystemSettingKeys.CalendarMaximumDateRangeDays,
            cancellationToken);
        if (end - start > TimeSpan.FromDays(maximumDays))
            throw new PhaseBException(
                400,
                $"Calendar queries may span at most {maximumDays} days.");
        ValidateIds(query);
        var eventType = query.EventType?.Trim();
        if (!string.IsNullOrWhiteSpace(eventType) &&
            !new[] { "Delivery", "Order", "Expiry" }.Contains(
                eventType,
                StringComparer.OrdinalIgnoreCase))
            throw new PhaseBException(400, "Event type must be Delivery, Order, or Expiry.");

        int? forcedDriverId = null;
        if (Security.RoleCodes.Normalize(roleCode) == Security.RoleCodes.Driver)
        {
            forcedDriverId = await _context.Drivers.AsNoTracking()
                .Where(item => item.UserId == userId)
                .Select(item => (int?)item.DriverId)
                .SingleOrDefaultAsync(cancellationToken)
                ?? throw new PhaseBException(403, "The signed-in account is not linked to a Driver record.");
        }

        var events = new List<OperationsCalendarEventDto>();
        if (string.IsNullOrWhiteSpace(eventType) ||
            eventType.Equals("Delivery", StringComparison.OrdinalIgnoreCase))
        {
            var deliveries = _context.Deliveries.AsNoTracking()
                .Where(item =>
                    item.ScheduledStartUtc < end &&
                    item.ScheduledEndUtc >= start);
            var driverId = forcedDriverId ?? query.DriverId;
            if (driverId.HasValue)
                deliveries = deliveries.Where(item => item.DriverId == driverId.Value);
            if (query.CustomerId.HasValue)
                deliveries = deliveries.Where(item =>
                    item.SalesOrder.CustomerId == query.CustomerId.Value);
            if (!string.IsNullOrWhiteSpace(query.DeliveryStatus))
                deliveries = deliveries.Where(item => item.Status == query.DeliveryStatus);
            var rows = await deliveries
                .Select(item => new
                {
                    item.DeliveryId,
                    item.SalesOrderId,
                    item.ScheduledStartUtc,
                    item.ScheduledEndUtc,
                    item.Status,
                    item.DriverId,
                    item.SalesOrder.OrderNumber,
                    item.SalesOrder.Customer.CustomerName
                })
                .ToListAsync(cancellationToken);
            events.AddRange(rows.Select(item => new OperationsCalendarEventDto
            {
                EventId = $"delivery-{item.DeliveryId}",
                EventType = "Delivery",
                Title = $"{item.OrderNumber} · {item.CustomerName}",
                StartUtc = item.ScheduledStartUtc,
                EndUtc = item.ScheduledEndUtc,
                Status = item.Status,
                DetailRoute = $"/deliveries/{item.DeliveryId}",
                AccessibleLabel =
                    $"Delivery {item.OrderNumber} for {item.CustomerName}, {item.Status}, scheduled {item.ScheduledStartUtc:u}.",
                DeliveryId = item.DeliveryId,
                SalesOrderId = item.SalesOrderId,
                DriverId = item.DriverId
            }));
        }

        if (forcedDriverId is null &&
            (string.IsNullOrWhiteSpace(eventType) ||
             eventType.Equals("Order", StringComparison.OrdinalIgnoreCase)))
        {
            var orders = _context.SalesOrders.AsNoTracking()
                .Where(item =>
                    item.RequestedDeliveryDateUtc != null &&
                    item.RequestedDeliveryDateUtc >= start &&
                    item.RequestedDeliveryDateUtc < end);
            if (query.CustomerId.HasValue)
                orders = orders.Where(item => item.CustomerId == query.CustomerId.Value);
            var rows = await orders
                .Select(item => new
                {
                    item.SalesOrderId,
                    item.OrderNumber,
                    item.RequestedDeliveryDateUtc,
                    item.Status,
                    item.Customer.CustomerName
                })
                .ToListAsync(cancellationToken);
            events.AddRange(rows.Select(item => new OperationsCalendarEventDto
            {
                EventId = $"order-{item.SalesOrderId}",
                EventType = "Order",
                Title = $"Requested: {item.OrderNumber} · {item.CustomerName}",
                StartUtc = item.RequestedDeliveryDateUtc!.Value,
                EndUtc = item.RequestedDeliveryDateUtc.Value.AddHours(1),
                Status = item.Status,
                DetailRoute = $"/order-details/{item.SalesOrderId}",
                AccessibleLabel =
                    $"Requested delivery for order {item.OrderNumber}, customer {item.CustomerName}, {item.Status}.",
                SalesOrderId = item.SalesOrderId
            }));
        }

        if (forcedDriverId is null &&
            (string.IsNullOrWhiteSpace(eventType) ||
             eventType.Equals("Expiry", StringComparison.OrdinalIgnoreCase)))
        {
            var redHours = await _settings.GetIntAsync(
                SystemSettingKeys.ExpiryRedThresholdHours,
                cancellationToken);
            var yellowHours = await _settings.GetIntAsync(
                SystemSettingKeys.ExpiryYellowThresholdHours,
                cancellationToken);
            var batches = _context.ProductBatches.AsNoTracking()
                .Where(item =>
                    item.EffectiveExpiryAtUtc >= start &&
                    item.EffectiveExpiryAtUtc < end &&
                    item.QuantityRemainingKg > 0 &&
                    item.Status != ProductBatchStatuses.Consumed &&
                    item.Status != ProductBatchStatuses.WrittenOff);
            if (query.WarehouseSectionId.HasValue)
                batches = batches.Where(item =>
                    item.SectionId == query.WarehouseSectionId.Value);
            if (query.ProductCategoryId.HasValue)
                batches = batches.Where(item =>
                    item.Product.ProductCategoryId == query.ProductCategoryId.Value);
            var rows = await batches
                .Select(item => new
                {
                    item.ProductBatchId,
                    item.EffectiveExpiryAtUtc,
                    item.Status,
                    item.BatchCode,
                    item.Product.ProductName,
                    item.WarehouseSection.SectionName
                })
                .ToListAsync(cancellationToken);
            var now = DateTime.UtcNow;
            var expiryEvents = rows.Select(item =>
            {
                var risk = item.EffectiveExpiryAtUtc <= now
                    ? "Expired"
                    : item.EffectiveExpiryAtUtc <= now.AddHours(redHours)
                        ? "Red"
                        : item.EffectiveExpiryAtUtc <= now.AddHours(yellowHours)
                            ? "Yellow"
                            : "Normal";
                return new OperationsCalendarEventDto
                {
                    EventId = $"expiry-{item.ProductBatchId}",
                    EventType = "Expiry",
                    Title = $"{item.ProductName} · {item.BatchCode}",
                    StartUtc = item.EffectiveExpiryAtUtc,
                    EndUtc = item.EffectiveExpiryAtUtc.AddMinutes(30),
                    Status = item.Status,
                    RiskLevel = risk,
                    DetailRoute = $"/search-product?batchId={item.ProductBatchId}",
                    AccessibleLabel =
                        $"{risk} expiry event for {item.ProductName}, batch {item.BatchCode}, section {item.SectionName}, at {item.EffectiveExpiryAtUtc:u}.",
                    ProductBatchId = item.ProductBatchId
                };
            });
            if (!string.IsNullOrWhiteSpace(query.RiskLevel))
                expiryEvents = expiryEvents.Where(item =>
                    item.RiskLevel.Equals(query.RiskLevel, StringComparison.OrdinalIgnoreCase));
            events.AddRange(expiryEvents);
        }

        return new OperationsCalendarResponseDto
        {
            StartUtc = start,
            EndUtc = end,
            DefaultView = await _settings.GetStringAsync(
                SystemSettingKeys.CalendarDefaultView,
                cancellationToken),
            Events = events
                .OrderBy(item => item.StartUtc)
                .ThenBy(item => item.Title)
                .ToList()
        };
    }

    private static DateTime AsUtc(DateTime value) =>
        value.Kind == DateTimeKind.Utc ? value : value.ToUniversalTime();

    private static void ValidateIds(OperationsCalendarQueryDto query)
    {
        if (query.DriverId is < 1 ||
            query.CustomerId is < 1 ||
            query.WarehouseSectionId is < 1 ||
            query.ProductCategoryId is < 1)
            throw new PhaseBException(400, "Calendar filter IDs must be greater than zero.");
    }
}
