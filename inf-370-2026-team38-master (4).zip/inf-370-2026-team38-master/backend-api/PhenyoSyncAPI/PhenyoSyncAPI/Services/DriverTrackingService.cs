using System.Data;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IDriverTrackingService
{
    Task<TrackingSessionDto> StartAsync(
        int deliveryId,
        StartTrackingRequest request,
        int userId,
        bool manageAll,
        string correlationId,
        CancellationToken cancellationToken);

    Task<DriverLocationDto> AddLocationAsync(
        long sessionId,
        DriverLocationRequest request,
        int userId,
        bool manageAll,
        CancellationToken cancellationToken);

    Task<TrackingSessionDto> StopAsync(
        long sessionId,
        StopTrackingRequest request,
        int userId,
        bool manageAll,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<TrackingSessionDto>> ActiveAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<DriverLocationDto>> HistoryAsync(
        long sessionId,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);
}

/// <summary>
/// Records consented location updates for active deliveries. Ownership checks and
/// server-side time, accuracy, ordering and rate limits protect the tracking stream.
/// </summary>
public sealed class DriverTrackingService : IDriverTrackingService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _audit;

    public DriverTrackingService(
        PhenyoSyncDbContext context,
        IAuditService audit)
    {
        _context = context;
        _audit = audit;
    }

    public async Task<TrackingSessionDto> StartAsync(
        int deliveryId,
        StartTrackingRequest request,
        int userId,
        bool manageAll,
        string correlationId,
        CancellationToken cancellationToken)
    {
        // Consent and an assigned, in-transit delivery are hard prerequisites for collection.
        if (!request.ConsentConfirmed)
            throw new PhaseCException(
                400,
                "Location sharing requires explicit driver consent.");

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var delivery = await _context.Deliveries
            .Include(item => item.Driver).ThenInclude(driver => driver!.User)
            .SingleOrDefaultAsync(
                item => item.DeliveryId == deliveryId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Delivery not found.");
        if (delivery.Driver is null)
            throw new PhaseCException(409, "Assign a driver before tracking starts.");
        if (!manageAll && delivery.Driver.UserId != userId)
            throw new PhaseCException(403, "This delivery is not assigned to you.");
        if (delivery.Status != DeliveryStatuses.InTransit)
            throw new PhaseCException(
                409,
                "Start the assigned delivery before location sharing begins.");

        var existing = await _context.DriverTrackingSessions
            .Include(item => item.Driver).ThenInclude(driver => driver.User)
            .SingleOrDefaultAsync(
                item =>
                    item.DeliveryId == deliveryId &&
                    item.Status == TrackingSessionStatuses.Active,
                cancellationToken);
        if (existing is not null)
            return Map(existing, null);

        var now = DateTime.UtcNow;
        var session = new DriverTrackingSession
        {
            DeliveryId = deliveryId,
            DriverId = delivery.Driver.DriverId,
            StartedByUserId = userId,
            StartedAtUtc = now,
            ConsentConfirmedAtUtc = now,
            Status = TrackingSessionStatuses.Active,
            CorrelationId = correlationId
        };
        _context.DriverTrackingSessions.Add(session);
        await _context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.StatusChange,
            SystemModule = "MobileTracking",
            OperationName = "StartDriverTracking",
            EntityType = nameof(DriverTrackingSession),
            EntityId = session.DriverTrackingSessionId.ToString(),
            Description = "A consented delivery tracking session was started.",
            SafeDetails = new Dictionary<string, object?>
            {
                ["deliveryId"] = deliveryId,
                ["driverId"] = delivery.DriverId
            }
        }, cancellationToken);
        return Map(session, null, delivery.Driver.User);
    }

    public async Task<DriverLocationDto> AddLocationAsync(
        long sessionId,
        DriverLocationRequest request,
        int userId,
        bool manageAll,
        CancellationToken cancellationToken)
    {
        // Reject implausible client timestamps and unusable fixes before retaining coordinates.
        var now = DateTime.UtcNow;
        if (request.CapturedAtUtc == default ||
            request.CapturedAtUtc < now.AddHours(-24) ||
            request.CapturedAtUtc > now.AddMinutes(5))
            throw new PhaseCException(
                400,
                "The captured location timestamp is stale or in the future.");
        if (request.AccuracyMetres > 5000)
            throw new PhaseCException(
                400,
                "The reported location accuracy is not usable.");

        var session = await _context.DriverTrackingSessions
            .Include(item => item.Driver)
            .SingleOrDefaultAsync(
                item => item.DriverTrackingSessionId == sessionId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Tracking session not found.");
        if (session.Status != TrackingSessionStatuses.Active)
            throw new PhaseCException(409, "The tracking session is not active.");
        if (!manageAll && session.Driver.UserId != userId)
            throw new PhaseCException(403, "This tracking session is not yours.");

        // Idempotency prevents a reconnecting handset from duplicating the same GPS observation.
        var operationHash = MobileSecurity.Hash(request.OperationId);
        var existing = await _context.DriverLocationUpdates.AsNoTracking()
            .SingleOrDefaultAsync(
                item =>
                    item.DriverTrackingSessionId == sessionId &&
                    item.OperationKeyHash == operationHash,
                cancellationToken);
        if (existing is not null)
            return Map(existing);

        var latest = await _context.DriverLocationUpdates.AsNoTracking()
            .Where(item => item.DriverTrackingSessionId == sessionId)
            .OrderByDescending(item => item.CapturedAtUtc)
            .FirstOrDefaultAsync(cancellationToken);
        if (latest is not null &&
            request.CapturedAtUtc <= latest.CapturedAtUtc)
            throw new PhaseCException(
                409,
                "A newer location has already been received.");
        if (latest is not null &&
            (now - latest.ReceivedAtUtc).TotalSeconds < 5)
            throw new PhaseCException(
                429,
                "Location updates are arriving too quickly.");

        var location = new DriverLocationUpdate
        {
            DriverTrackingSessionId = sessionId,
            Latitude = request.Latitude,
            Longitude = request.Longitude,
            AccuracyMetres = request.AccuracyMetres,
            SpeedMetresPerSecond = request.SpeedMetresPerSecond,
            HeadingDegrees = request.HeadingDegrees,
            CapturedAtUtc = request.CapturedAtUtc,
            ReceivedAtUtc = now,
            Source = "Capacitor",
            OperationKeyHash = operationHash
        };
        _context.DriverLocationUpdates.Add(location);
        await _context.SaveChangesAsync(cancellationToken);
        return Map(location);
    }

    public async Task<TrackingSessionDto> StopAsync(
        long sessionId,
        StopTrackingRequest request,
        int userId,
        bool manageAll,
        CancellationToken cancellationToken)
    {
        var session = await _context.DriverTrackingSessions
            .Include(item => item.Driver).ThenInclude(driver => driver.User)
            .SingleOrDefaultAsync(
                item => item.DriverTrackingSessionId == sessionId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Tracking session not found.");
        if (!manageAll && session.Driver.UserId != userId)
            throw new PhaseCException(403, "This tracking session is not yours.");
        if (session.Status != TrackingSessionStatuses.Active)
            return Map(session, await LatestAsync(sessionId, cancellationToken));

        session.Status = TrackingSessionStatuses.Stopped;
        session.EndedAtUtc = DateTime.UtcNow;
        session.EndedReason = request.Reason.Trim();
        await _context.SaveChangesAsync(cancellationToken);
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.StatusChange,
            SystemModule = "MobileTracking",
            OperationName = "StopDriverTracking",
            EntityType = nameof(DriverTrackingSession),
            EntityId = sessionId.ToString(),
            Description = "A delivery tracking session was stopped.",
            SafeDetails = new Dictionary<string, object?>
            {
                ["deliveryId"] = session.DeliveryId,
                ["reason"] = session.EndedReason
            }
        }, cancellationToken);
        return Map(session, await LatestAsync(sessionId, cancellationToken));
    }

    public async Task<IReadOnlyList<TrackingSessionDto>> ActiveAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        // Non-management callers see only sessions attached to their driver account.
        var query = _context.DriverTrackingSessions.AsNoTracking()
            .Include(item => item.Driver).ThenInclude(driver => driver.User)
            .Where(item => item.Status == TrackingSessionStatuses.Active);
        if (!viewAll)
            query = query.Where(item => item.Driver.UserId == userId);

        var sessions = await query.OrderByDescending(item => item.StartedAtUtc)
            .ToListAsync(cancellationToken);
        var sessionIds = sessions.Select(item => item.DriverTrackingSessionId).ToArray();
        var locations = await _context.DriverLocationUpdates.AsNoTracking()
            .Where(item => sessionIds.Contains(item.DriverTrackingSessionId))
            .GroupBy(item => item.DriverTrackingSessionId)
            .Select(group => group
                .OrderByDescending(item => item.CapturedAtUtc)
                .First())
            .ToDictionaryAsync(
                item => item.DriverTrackingSessionId,
                cancellationToken);
        return sessions.Select(item => Map(
                item,
                locations.GetValueOrDefault(item.DriverTrackingSessionId)))
            .ToList();
    }

    public async Task<IReadOnlyList<DriverLocationDto>> HistoryAsync(
        long sessionId,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        var session = await _context.DriverTrackingSessions
            .AsNoTracking()
            .Include(item => item.Driver)
            .SingleOrDefaultAsync(
                item => item.DriverTrackingSessionId == sessionId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Tracking session not found.");

        if (!viewAll && session.Driver.UserId != userId)
            throw new PhaseCException(
                403,
                "This tracking session is not available to your account.");

        var locations = await _context.DriverLocationUpdates
            .AsNoTracking()
            .Where(item => item.DriverTrackingSessionId == sessionId)
            .OrderByDescending(item => item.CapturedAtUtc)
            .Take(250)
            .ToListAsync(cancellationToken);

        locations.Reverse();
        return locations.Select(Map).ToList();
    }

    private Task<DriverLocationUpdate?> LatestAsync(
        long sessionId,
        CancellationToken cancellationToken) =>
        _context.DriverLocationUpdates.AsNoTracking()
            .Where(item => item.DriverTrackingSessionId == sessionId)
            .OrderByDescending(item => item.CapturedAtUtc)
            .FirstOrDefaultAsync(cancellationToken);

    private static TrackingSessionDto Map(
        DriverTrackingSession item,
        DriverLocationUpdate? location,
        User? driverUser = null) =>
        new()
        {
            TrackingSessionId = item.DriverTrackingSessionId,
            DeliveryId = item.DeliveryId,
            DriverId = item.DriverId,
            DriverName = driverUser is null
                ? $"{item.Driver.User.FirstName} {item.Driver.User.LastName}".Trim()
                : $"{driverUser.FirstName} {driverUser.LastName}".Trim(),
            Status = item.Status,
            StartedAtUtc = item.StartedAtUtc,
            EndedAtUtc = item.EndedAtUtc,
            LatestLocation = location is null ? null : Map(location)
        };

    private static DriverLocationDto Map(DriverLocationUpdate item) =>
        new()
        {
            Latitude = item.Latitude,
            Longitude = item.Longitude,
            AccuracyMetres = item.AccuracyMetres,
            SpeedMetresPerSecond = item.SpeedMetresPerSecond,
            HeadingDegrees = item.HeadingDegrees,
            CapturedAtUtc = item.CapturedAtUtc,
            ReceivedAtUtc = item.ReceivedAtUtc
        };
}
