using System.Data;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public interface IMobileWriteOffService
{
    Task<IReadOnlyList<StockWriteOffDto>> ListAsync(
        bool approvalsOnly,
        CancellationToken cancellationToken);
    Task<StockWriteOffDto> GetAsync(long id, CancellationToken cancellationToken);
    Task<StockWriteOffDto> CreateAsync(
        CreateWriteOffRequest request,
        int userId,
        bool managementUser,
        CancellationToken cancellationToken);
    Task<StockWriteOffDto> UploadEvidenceAsync(
        long id,
        IFormFile file,
        string? caption,
        int userId,
        CancellationToken cancellationToken);
    Task<StockWriteOffDto> CompleteAsync(
        long id,
        ReasonRequest request,
        int userId,
        bool managementUser,
        CancellationToken cancellationToken);
    Task<StockWriteOffDto> DecideAsync(
        long id,
        ReasonRequest request,
        int userId,
        bool approved,
        CancellationToken cancellationToken);
}

/// <summary>Implements controlled stock write-off requests, thresholds and separation-of-duties approval.</summary>
public sealed class MobileWriteOffService : IMobileWriteOffService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly ISystemSettingProvider _settings;
    private readonly IProtectedFileStorage _files;
    private readonly IAuditService _audit;
    private readonly IOperationalNotificationService _notifications;

    public MobileWriteOffService(
        PhenyoSyncDbContext context,
        ISystemSettingProvider settings,
        IProtectedFileStorage files,
        IAuditService audit,
        IOperationalNotificationService notifications)
    {
        _context = context;
        _settings = settings;
        _files = files;
        _audit = audit;
        _notifications = notifications;
    }

    public async Task<IReadOnlyList<StockWriteOffDto>> ListAsync(
        bool approvalsOnly,
        CancellationToken cancellationToken)
    {
        var query = Query();
        if (approvalsOnly)
            query = query.Where(item => item.Status == WriteOffStatuses.PendingApproval);
        var items = await query.OrderByDescending(item => item.SubmittedAtUtc)
            .Take(250)
            .ToListAsync(cancellationToken);
        var thresholds = await ThresholdsAsync(cancellationToken);
        return items.Select(item => Map(item, thresholds)).ToList();
    }

    public async Task<StockWriteOffDto> GetAsync(
        long id,
        CancellationToken cancellationToken)
    {
        var item = await Query().SingleOrDefaultAsync(
                value => value.StockWriteOffId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Stock write-off not found.");
        return Map(item, await ThresholdsAsync(cancellationToken));
    }

    // Requested loss value is calculated from current stock data, not accepted from the handset.
    public async Task<StockWriteOffDto> CreateAsync(
        CreateWriteOffRequest request,
        int userId,
        bool managementUser,
        CancellationToken cancellationToken)
    {
        var duplicateHash = MobileSecurity.Hash($"{userId}:{request.OperationId}");
        var existing = await _context.MobileIdempotencyRecords.AsNoTracking()
            .FirstOrDefaultAsync(item =>
                item.UserId == userId &&
                item.OperationType == "CreateWriteOff" &&
                item.OperationKeyHash == MobileSecurity.Hash(request.OperationId),
                cancellationToken);
        if (existing is not null &&
            long.TryParse(existing.ResponseJson, out var existingId))
            return await GetAsync(existingId, cancellationToken);

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var batch = await _context.ProductBatches
            .Include(item => item.Product)
            .Include(item => item.WarehouseSection)
            .SingleOrDefaultAsync(
                item => item.ProductBatchId == request.ProductBatchId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Product batch not found.");
        var stock = await _context.Stocks
            .SingleOrDefaultAsync(
                item => item.ProductId == batch.ProductId &&
                        item.SectionId == batch.SectionId,
                cancellationToken)
            ?? throw new PhaseCException(409, "The batch has no matching warehouse stock record.");
        var reserved = await _context.OrderStockReservations
            .Where(item =>
                item.ProductBatchId == batch.ProductBatchId &&
                item.Status == OrderReservationStatuses.Active)
            .SumAsync(item => (decimal?)item.QuantityReservedKg, cancellationToken) ?? 0;
        var unreserved = Math.Max(
            0,
            Math.Min(batch.QuantityRemainingKg, stock.QuantityAvailableKg) - reserved);
        if (request.QuantityKg > unreserved)
            throw new PhaseCException(
                409,
                $"Only {unreserved:0.###} kg is available after active order reservations.");

        var thresholds = await ThresholdsAsync(cancellationToken);
        var loss = request.EstimatedUnitCost.HasValue
            ? request.QuantityKg * request.EstimatedUnitCost.Value
            : (decimal?)null;
        var requiresApproval =
            !loss.HasValue ||
            loss.Value > thresholds.ApprovalValue ||
            (!managementUser &&
             (loss.Value > thresholds.WarehouseManagerValue ||
              request.QuantityKg > thresholds.WarehouseManagerQuantity));
        var requiresPhoto =
            !loss.HasValue || loss.Value > thresholds.PhotoValue;
        var writeOff = new StockWriteOff
        {
            ProductBatchId = batch.ProductBatchId,
            SectionId = batch.SectionId,
            SubmittedByUserId = userId,
            QuantityKg = request.QuantityKg,
            EstimatedUnitCost = request.EstimatedUnitCost,
            EstimatedTotalLoss = loss,
            ReasonCode = request.ReasonCode.Trim(),
            Condition = Clean(request.Condition, 120),
            Notes = Clean(request.Notes, 1000),
            Status = requiresPhoto
                ? WriteOffStatuses.Draft
                : requiresApproval
                    ? WriteOffStatuses.PendingApproval
                    : WriteOffStatuses.Completed,
            SubmittedAtUtc = DateTime.UtcNow,
            CorrelationId = Guid.NewGuid().ToString("N")
        };
        _context.StockWriteOffs.Add(writeOff);
        if (writeOff.Status == WriteOffStatuses.Completed)
            ApplyStock(writeOff, batch, stock, userId);
        await _context.SaveChangesAsync(cancellationToken);
        _context.MobileIdempotencyRecords.Add(
            MobileSecurity.Receipt(
                userId,
                "CreateWriteOff",
                request.OperationId,
                duplicateHash,
                writeOff.StockWriteOffId.ToString()));
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            writeOff,
            writeOff.Status == WriteOffStatuses.Completed
                ? AuditActionTypes.WriteOff
                : AuditActionTypes.Create,
            "CreateMobileWriteOff",
            cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        await NotifyAsync(writeOff, batch, userId, cancellationToken);
        return await GetAsync(writeOff.StockWriteOffId, cancellationToken);
    }

    public async Task<StockWriteOffDto> UploadEvidenceAsync(
        long id,
        IFormFile file,
        string? caption,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await _context.StockWriteOffs.SingleOrDefaultAsync(
                value => value.StockWriteOffId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Stock write-off not found.");
        if (item.Status is WriteOffStatuses.Completed or WriteOffStatuses.Rejected)
            throw new PhaseCException(409, "Evidence cannot be changed after a final decision.");
        var maximumMb = await _settings.GetIntAsync(
            SystemSettingKeys.FilesProofImageMaximumMb,
            cancellationToken);
        StoredImageResult stored;
        try
        {
            stored = await _files.SaveProofImageAsync(
                file,
                userId,
                maximumMb,
                cancellationToken);
        }
        catch (ProtectedFileException exception)
        {
            throw new PhaseCException(400, exception.Message);
        }

        try
        {
            _context.StoredFiles.Add(stored.Image);
            _context.StockWriteOffEvidence.Add(new StockWriteOffEvidence
            {
                StockWriteOffId = id,
                StoredFile = stored.Image,
                UploadedByUserId = userId,
                UploadedAtUtc = DateTime.UtcNow,
                Caption = Clean(caption, 300)
            });
            await _context.SaveChangesAsync(cancellationToken);
            await _files.DeletePhysicalAsync(stored.Thumbnail, CancellationToken.None);
        }
        catch
        {
            await _files.DeletePhysicalAsync(stored.Image, CancellationToken.None);
            await _files.DeletePhysicalAsync(stored.Thumbnail, CancellationToken.None);
            throw;
        }
        return await GetAsync(id, cancellationToken);
    }

    // Low-risk requests may complete directly; threshold breaches remain pending for another user.
    public async Task<StockWriteOffDto> CompleteAsync(
        long id,
        ReasonRequest request,
        int userId,
        bool managementUser,
        CancellationToken cancellationToken)
    {
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var item = await MutableQuery().SingleOrDefaultAsync(
                value => value.StockWriteOffId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Stock write-off not found.");
        if (item.Status != WriteOffStatuses.Draft)
            throw new PhaseCException(409, "Only a draft write-off can be submitted.");
        var thresholds = await ThresholdsAsync(cancellationToken);
        if (item.EstimatedTotalLoss > thresholds.PhotoValue && item.Evidence.Count == 0)
            throw new PhaseCException(409, "Photo evidence is required for this write-off.");
        var requiresApproval =
            item.EstimatedTotalLoss > thresholds.ApprovalValue ||
            (!managementUser &&
             (item.EstimatedTotalLoss > thresholds.WarehouseManagerValue ||
              item.QuantityKg > thresholds.WarehouseManagerQuantity));
        item.Notes = Append(item.Notes, request.Reason);
        if (requiresApproval)
        {
            item.Status = WriteOffStatuses.PendingApproval;
        }
        else
        {
            var stock = await LoadStockAsync(item, cancellationToken);
            EnsureAvailable(item, stock);
            ApplyStock(item, item.ProductBatch, stock, userId);
        }
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            item,
            item.Status == WriteOffStatuses.Completed
                ? AuditActionTypes.WriteOff
                : AuditActionTypes.StatusChange,
            "SubmitMobileWriteOff",
            cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        await NotifyAsync(item, item.ProductBatch, userId, cancellationToken);
        return await GetAsync(id, cancellationToken);
    }

    // The requester cannot approve their own loss adjustment, enforcing separation of duties.
    public async Task<StockWriteOffDto> DecideAsync(
        long id,
        ReasonRequest request,
        int userId,
        bool approved,
        CancellationToken cancellationToken)
    {
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var item = await MutableQuery().SingleOrDefaultAsync(
                value => value.StockWriteOffId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Stock write-off not found.");
        if (item.Status != WriteOffStatuses.PendingApproval)
            throw new PhaseCException(409, "This write-off is not awaiting approval.");
        if (item.SubmittedByUserId == userId)
            throw new PhaseCException(409, "A different authorised manager must decide this write-off.");
        item.DecidedByUserId = userId;
        item.DecidedAtUtc = DateTime.UtcNow;
        item.DecisionReason = request.Reason.Trim();
        if (approved)
        {
            var stock = await LoadStockAsync(item, cancellationToken);
            EnsureAvailable(item, stock);
            ApplyStock(item, item.ProductBatch, stock, userId);
        }
        else
        {
            item.Status = WriteOffStatuses.Rejected;
        }
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            item,
            approved ? AuditActionTypes.WriteOff : AuditActionTypes.StatusChange,
            approved ? "ApproveMobileWriteOff" : "RejectMobileWriteOff",
            cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        await _notifications.PublishToUsersAsync(
            approved ? "WriteOffApproved" : "WriteOffRejected",
            approved ? "Success" : "Warning",
            approved ? "Write-off approved" : "Write-off rejected",
            $"Write-off {item.StockWriteOffId} was {(approved ? "approved" : "rejected")}.",
            new[] { item.SubmittedByUserId },
            nameof(StockWriteOff),
            id.ToString(),
            $"/write-offs/{id}",
            userId,
            item.CorrelationId,
            cancellationToken);
        return await GetAsync(id, cancellationToken);
    }

    private IQueryable<StockWriteOff> Query() =>
        MutableQuery().AsNoTracking();

    private IQueryable<StockWriteOff> MutableQuery() =>
        _context.StockWriteOffs
            .Include(item => item.ProductBatch).ThenInclude(item => item.Product)
            .Include(item => item.WarehouseSection)
            .Include(item => item.SubmittedByUser)
            .Include(item => item.DecidedByUser)
            .Include(item => item.Evidence);

    private async Task<Stock> LoadStockAsync(
        StockWriteOff item,
        CancellationToken cancellationToken) =>
        await _context.Stocks.SingleOrDefaultAsync(
            stock =>
                stock.ProductId == item.ProductBatch.ProductId &&
                stock.SectionId == item.SectionId,
            cancellationToken)
        ?? throw new PhaseCException(409, "The write-off stock record no longer exists.");

    private void EnsureAvailable(StockWriteOff item, Stock stock)
    {
        var reserved = _context.OrderStockReservations
            .Where(value =>
                value.ProductBatchId == item.ProductBatchId &&
                value.Status == OrderReservationStatuses.Active)
            .Sum(value => (decimal?)value.QuantityReservedKg) ?? 0;
        var unreserved = Math.Max(
            0,
            Math.Min(item.ProductBatch.QuantityRemainingKg, stock.QuantityAvailableKg) - reserved);
        if (item.QuantityKg > unreserved)
            throw new PhaseCException(
                409,
                "Available quantity changed after submission. Review the write-off again.");
    }

    private void ApplyStock(
        StockWriteOff item,
        ProductBatch batch,
        Stock stock,
        int userId)
    {
        batch.QuantityRemainingKg -= item.QuantityKg;
        batch.UpdatedAtUtc = DateTime.UtcNow;
        if (batch.QuantityRemainingKg == 0)
        {
            batch.Status = ProductBatchStatuses.WrittenOff;
            batch.AvailableQuantityRemovedAtUtc = DateTime.UtcNow;
        }
        stock.QuantityAvailableKg -= item.QuantityKg;
        stock.InventoryStatus = stock.QuantityAvailableKg > 0
            ? ProductBatchStatuses.Available
            : ProductBatchStatuses.Consumed;
        item.Status = WriteOffStatuses.Completed;
        item.CompletedAtUtc = DateTime.UtcNow;
        _context.StockMovements.Add(new StockMovement
        {
            ProductId = batch.ProductId,
            ProductBatchId = batch.ProductBatchId,
            SectionId = batch.SectionId,
            MovementType = StockMovementTypes.WriteOff,
            QuantityKg = item.QuantityKg,
            OccurredAtUtc = DateTime.UtcNow,
            CreatedByUserId = userId,
            Reason = $"{item.ReasonCode}: {item.Notes}".Trim().TrimEnd(':')
        });
    }

    private async Task NotifyAsync(
        StockWriteOff item,
        ProductBatch batch,
        int userId,
        CancellationToken cancellationToken)
    {
        var pending = item.Status == WriteOffStatuses.PendingApproval;
        await _notifications.PublishToRolesAsync(
            pending ? "WriteOffApprovalRequired" : "StockWrittenOff",
            pending ? "Critical" : "Warning",
            pending ? "Write-off approval required" : "Stock written off",
            $"{batch.Product.ProductName}, batch {batch.BatchCode}: {item.QuantityKg:0.###} kg.",
            new[]
            {
                RoleCodes.WarehouseManager,
                RoleCodes.OperationsManager
            },
            nameof(StockWriteOff),
            item.StockWriteOffId.ToString(),
            $"/write-offs/{item.StockWriteOffId}",
            userId,
            item.CorrelationId,
            cancellationToken);
    }

    private async Task<WriteOffThresholds> ThresholdsAsync(
        CancellationToken cancellationToken) =>
        new(
            await _settings.GetDecimalAsync(
                SystemSettingKeys.WriteOffWarehouseManagerMaximumValue,
                cancellationToken),
            await _settings.GetDecimalAsync(
                SystemSettingKeys.WriteOffWarehouseManagerMaximumQuantity,
                cancellationToken),
            await _settings.GetDecimalAsync(
                SystemSettingKeys.WriteOffRequirePhotoAboveValue,
                cancellationToken),
            await _settings.GetDecimalAsync(
                SystemSettingKeys.WriteOffRequireApprovalAboveValue,
                cancellationToken));

    private static StockWriteOffDto Map(
        StockWriteOff item,
        WriteOffThresholds thresholds) => new()
    {
        StockWriteOffId = item.StockWriteOffId,
        ProductBatchId = item.ProductBatchId,
        ProductName = item.ProductBatch.Product.ProductName,
        ProductCode = $"P-{item.ProductBatch.Product.ProductId:D6}",
        BatchCode = item.ProductBatch.BatchCode,
        WarehouseSection = item.WarehouseSection.SectionName,
        AvailableQuantityKg = item.ProductBatch.QuantityRemainingKg,
        QuantityKg = item.QuantityKg,
        EstimatedUnitCost = item.EstimatedUnitCost,
        EstimatedTotalLoss = item.EstimatedTotalLoss,
        ReasonCode = item.ReasonCode,
        Condition = item.Condition,
        Notes = item.Notes,
        Status = item.Status,
        SubmittedBy =
            $"{item.SubmittedByUser.FirstName} {item.SubmittedByUser.LastName}".Trim(),
        SubmittedAtUtc = item.SubmittedAtUtc,
        DecidedBy = item.DecidedByUser is null
            ? null
            : $"{item.DecidedByUser.FirstName} {item.DecidedByUser.LastName}".Trim(),
        DecidedAtUtc = item.DecidedAtUtc,
        EvidenceCount = item.Evidence.Count,
        RequiresPhoto = item.EstimatedTotalLoss > thresholds.PhotoValue,
        RequiresApproval =
            item.EstimatedTotalLoss > thresholds.ApprovalValue ||
            item.QuantityKg > thresholds.WarehouseManagerQuantity ||
            item.EstimatedTotalLoss > thresholds.WarehouseManagerValue,
        CorrelationId = item.CorrelationId,
        RowVersion = item.RowVersion is null
            ? string.Empty
            : Convert.ToBase64String(item.RowVersion)
    };

    private async Task AuditAsync(
        StockWriteOff item,
        string action,
        string operation,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = AuditModules.Stock,
            OperationName = operation,
            Description = $"Stock write-off {item.StockWriteOffId} is {item.Status}.",
            EntityType = nameof(StockWriteOff),
            EntityId = item.StockWriteOffId.ToString(),
            EntityDisplay = $"Stock write-off {item.StockWriteOffId}",
            SafeDetails = new Dictionary<string, object?>
            {
                ["productBatchId"] = item.ProductBatchId,
                ["quantityKg"] = item.QuantityKg,
                ["reasonCode"] = item.ReasonCode,
                ["status"] = item.Status,
                ["correlationId"] = item.CorrelationId
            }
        }, cancellationToken);

    private static string? Clean(string? value, int maximum)
    {
        var cleaned = value?.Trim();
        if (string.IsNullOrWhiteSpace(cleaned)) return null;
        return cleaned.Length <= maximum ? cleaned : cleaned[..maximum];
    }

    private static string Append(string? current, string addition) =>
        string.Join(
            Environment.NewLine,
            new[] { current, addition.Trim() }
                .Where(value => !string.IsNullOrWhiteSpace(value)));

    private sealed record WriteOffThresholds(
        decimal WarehouseManagerValue,
        decimal WarehouseManagerQuantity,
        decimal PhotoValue,
        decimal ApprovalValue);
}
