using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.BuyingLists;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public interface IBuyingListManagementService
{
    Task<BuyingListSearchResultDto> SearchAsync(
        BuyingListSearchRequest request,
        CancellationToken cancellationToken);

    Task<BuyingListDetailDto> GetAsync(
        int id,
        CancellationToken cancellationToken);

    Task<BuyingListOptionsDto> OptionsAsync(
        CancellationToken cancellationToken);

    Task<BuyingListDetailDto> CreateAsync(
        CreateBuyingListManagementRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken);

    Task<BuyingListDetailDto> UpdateHeaderAsync(
        int id,
        UpdateBuyingListHeaderRequest request,
        int actorUserId,
        CancellationToken cancellationToken);

    Task<BuyingListDetailDto> AddLineAsync(
        int id,
        SaveBuyingListLineRequest request,
        int actorUserId,
        CancellationToken cancellationToken);

    Task<BuyingListDetailDto> UpdateLineAsync(
        int id,
        int lineId,
        SaveBuyingListLineRequest request,
        int actorUserId,
        CancellationToken cancellationToken);

    Task<BuyingListDetailDto> RemoveLineAsync(
        int id,
        int lineId,
        BuyingListCommandRequest request,
        int actorUserId,
        CancellationToken cancellationToken);

    Task<BuyingListDetailDto> AssignAsync(
        int id,
        AssignBuyingListRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken);

    Task<BuyingListDetailDto> PublishAsync(
        int id,
        BuyingListCommandRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken);

    Task<BuyingListDetailDto> CancelAsync(
        int id,
        BuyingListCommandRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken);
}

/// <summary>
/// Owns the management-side Buying List lifecycle. Draft content remains editable,
/// while assignment and publication make the list actionable by an eligible buyer.
/// </summary>
public sealed class BuyingListManagementService : IBuyingListManagementService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _audit;
    private readonly IOperationalNotificationService _notifications;

    public BuyingListManagementService(
        PhenyoSyncDbContext context,
        IAuditService audit,
        IOperationalNotificationService notifications)
    {
        _context = context;
        _audit = audit;
        _notifications = notifications;
    }

    public async Task<BuyingListSearchResultDto> SearchAsync(
        BuyingListSearchRequest request,
        CancellationToken cancellationToken)
    {
        var query = SummaryQuery();
        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();
            query = query.Where(item =>
                item.ReferenceNumber.Contains(term) ||
                (item.Title != null && item.Title.Contains(term)) ||
                (item.AssignedBuyerUser != null &&
                 (item.AssignedBuyerUser.FirstName.Contains(term) ||
                  item.AssignedBuyerUser.LastName.Contains(term) ||
                  item.AssignedBuyerUser.Email.Contains(term))));
        }

        if (!string.IsNullOrWhiteSpace(request.Status))
        {
            var status = request.Status.Trim();
            if (!BuyingListStatuses.All.Contains(status))
                throw new PhaseCException(400, "Select a valid Buying List status.");
            query = query.Where(item => item.Status == status);
        }

        if (request.AssignedBuyerUserId.HasValue)
            query = query.Where(item =>
                item.AssignedBuyerUserId == request.AssignedBuyerUserId.Value);

        if (request.FromDateUtc.HasValue)
        {
            var from = request.FromDateUtc.Value.ToUniversalTime();
            query = query.Where(item => item.BuyingDateUtc >= from);
        }

        if (request.ToDateUtc.HasValue)
        {
            var to = request.ToDateUtc.Value.ToUniversalTime();
            query = query.Where(item => item.BuyingDateUtc <= to);
        }

        var total = await query.CountAsync(cancellationToken);
        var items = await query
            .OrderByDescending(item => item.UpdatedAtUtc)
            .ThenByDescending(item => item.BuyerProcurementId)
            .Skip((request.Page - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync(cancellationToken);

        return new BuyingListSearchResultDto
        {
            Items = items.Select(MapSummary).ToList(),
            Page = request.Page,
            PageSize = request.PageSize,
            Total = total
        };
    }

    public async Task<BuyingListDetailDto> GetAsync(
        int id,
        CancellationToken cancellationToken) =>
        MapDetail(await LoadAsync(id, false, cancellationToken));

    public async Task<BuyingListOptionsDto> OptionsAsync(
        CancellationToken cancellationToken)
    {
        var buyers = await _context.Users.AsNoTracking()
            .Where(user =>
                user.Status == ProductStatuses.Active &&
                user.Role != null &&
                user.Role.IsActive &&
                user.Role.RolePermissions.Any(mapping =>
                    mapping.Permission != null &&
                    mapping.Permission.IsActive &&
                    mapping.Permission.PermissionCode ==
                    Permissions.Mobile.BuyingListView))
            .OrderBy(user => user.FirstName)
            .ThenBy(user => user.LastName)
            .Select(user => new BuyingListBuyerOptionDto(
                user.UserId,
                (user.FirstName + " " + user.LastName).Trim(),
                user.Email))
            .ToListAsync(cancellationToken);

        var rawStock = await _context.RawStockItems.AsNoTracking()
            .Where(item => item.IsActive)
            .OrderBy(item => item.ItemName)
            .Select(item => new BuyingListRawStockOptionDto(
                item.RawStockItemId,
                item.ItemCode,
                item.ItemName,
                item.CategoryCode,
                item.DefaultUnitOfMeasure,
                item.Balances.Sum(balance => balance.QuantityOnHand)))
            .ToListAsync(cancellationToken);

        var suppliers = await _context.Suppliers.AsNoTracking()
            .Where(item => item.Status == ProductStatuses.Active)
            .OrderBy(item => item.SupplierName)
            .Select(item => new BuyingListSupplierOptionDto(
                item.SupplierId,
                item.SupplierName))
            .ToListAsync(cancellationToken);

        return new BuyingListOptionsDto
        {
            Statuses = BuyingListStatuses.All
                .OrderBy(StatusOrder)
                .Select(item => new BuyingListOptionDto(
                    item,
                    DisplayStatus(item)))
                .ToList(),
            Priorities = BuyingListPriorities.All
                .Select(item => new BuyingListOptionDto(item, item))
                .ToList(),
            Buyers = buyers,
            RawStockItems = rawStock,
            Suppliers = suppliers
        };
    }

    public async Task<BuyingListDetailDto> CreateAsync(
        CreateBuyingListManagementRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        // Validate the complete header-and-line aggregate before persisting any part of it.
        ValidatePriority(request.Priority);
        if (request.AssignedBuyerUserId.HasValue)
            await ValidateBuyerAsync(
                request.AssignedBuyerUserId.Value,
                cancellationToken);
        ValidateLineDuplicates(request.Items);
        await ValidateLinesAsync(request.Items, cancellationToken);

        var now = DateTime.UtcNow;
        var list = new BuyerProcurement
        {
            ReferenceNumber =
                $"BL-{now:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..6]}"
                    .ToUpperInvariant(),
            BuyingDateUtc = request.BuyingDateUtc == default
                ? now.Date
                : request.BuyingDateUtc.ToUniversalTime(),
            Title = Clean(request.Title, 160),
            Priority = request.Priority.Trim(),
            Status = BuyingListStatuses.Draft,
            Notes = Clean(request.Notes),
            AssignedBuyerUserId = request.AssignedBuyerUserId,
            CreatedByUserId = actorUserId,
            CreatedAtUtc = now,
            UpdatedAtUtc = now,
            CorrelationId = correlationId,
            Items = request.Items.Select(MapNewLine).ToList()
        };

        _context.BuyerProcurements.Add(list);
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Create,
            "Create Buying List",
            list,
            actorUserId,
            new Dictionary<string, object?>
            {
                ["reference"] = list.ReferenceNumber,
                ["assignedBuyerUserId"] = list.AssignedBuyerUserId,
                ["lineCount"] = list.Items.Count,
                ["status"] = list.Status
            },
            cancellationToken);
        return await GetAsync(list.BuyerProcurementId, cancellationToken);
    }

    public async Task<BuyingListDetailDto> UpdateHeaderAsync(
        int id,
        UpdateBuyingListHeaderRequest request,
        int actorUserId,
        CancellationToken cancellationToken)
    {
        ValidatePriority(request.Priority);
        var list = await LoadAsync(id, true, cancellationToken);
        EnsureDraft(list);
        ValidateVersion(list.RowVersion, request.RowVersion);
        var before = new
        {
            list.BuyingDateUtc,
            list.Title,
            list.Priority,
            list.Notes
        };
        list.BuyingDateUtc = request.BuyingDateUtc.ToUniversalTime();
        list.Title = Clean(request.Title, 160);
        list.Priority = request.Priority.Trim();
        list.Notes = Clean(request.Notes);
        list.UpdatedAtUtc = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Update,
            "Update Buying List header",
            list,
            actorUserId,
            new Dictionary<string, object?>
            {
                ["before"] = before,
                ["buyingDateUtc"] = list.BuyingDateUtc,
                ["title"] = list.Title,
                ["priority"] = list.Priority,
                ["notes"] = list.Notes
            },
            cancellationToken);
        return await GetAsync(id, cancellationToken);
    }

    public async Task<BuyingListDetailDto> AddLineAsync(
        int id,
        SaveBuyingListLineRequest request,
        int actorUserId,
        CancellationToken cancellationToken)
    {
        var list = await LoadAsync(id, true, cancellationToken);
        EnsureDraft(list);
        await ValidateLineAsync(request, cancellationToken);
        EnsureNoDuplicate(list, request, null);
        var line = MapNewLine(request);
        list.Items.Add(line);
        list.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Create,
            "Add required Buying List item",
            list,
            actorUserId,
            new Dictionary<string, object?>
            {
                ["lineId"] = line.BuyerProcurementItemId,
                ["rawStockItemId"] = line.RawStockItemId,
                ["requiredQuantity"] = line.RequiredQuantity,
                ["unitOfMeasure"] = line.UnitOfMeasure
            },
            cancellationToken);
        return await GetAsync(id, cancellationToken);
    }

    public async Task<BuyingListDetailDto> UpdateLineAsync(
        int id,
        int lineId,
        SaveBuyingListLineRequest request,
        int actorUserId,
        CancellationToken cancellationToken)
    {
        var list = await LoadAsync(id, true, cancellationToken);
        EnsureDraft(list);
        await ValidateLineAsync(request, cancellationToken);
        EnsureNoDuplicate(list, request, lineId);
        var line = list.Items.SingleOrDefault(item =>
                item.BuyerProcurementItemId == lineId)
            ?? throw new PhaseCException(404, "Buying List item not found.");
        ValidateVersion(line.RowVersion, request.RowVersion);
        var oldQuantity = line.RequiredQuantity;
        line.ProductId = request.ProductId;
        line.RawStockItemId = request.RawStockItemId;
        line.RecommendedQuantity = request.RecommendedQuantity;
        line.RequiredQuantity = request.RequiredQuantity;
        line.UnitOfMeasure = request.UnitOfMeasure.Trim().ToLowerInvariant();
        line.Priority = request.Priority.Trim();
        line.PreferredSupplierId = request.PreferredSupplierId;
        line.ManagementNotes = Clean(request.ManagementNotes);
        line.UpdatedAtUtc = DateTime.UtcNow;
        list.UpdatedAtUtc = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Update,
            "Update required Buying List item",
            list,
            actorUserId,
            new Dictionary<string, object?>
            {
                ["lineId"] = lineId,
                ["oldRequiredQuantity"] = oldQuantity,
                ["requiredQuantity"] = line.RequiredQuantity,
                ["rawStockItemId"] = line.RawStockItemId
            },
            cancellationToken);
        return await GetAsync(id, cancellationToken);
    }

    public async Task<BuyingListDetailDto> RemoveLineAsync(
        int id,
        int lineId,
        BuyingListCommandRequest request,
        int actorUserId,
        CancellationToken cancellationToken)
    {
        var list = await LoadAsync(id, true, cancellationToken);
        EnsureDraft(list);
        ValidateVersion(list.RowVersion, request.RowVersion);
        var line = list.Items.SingleOrDefault(item =>
                item.BuyerProcurementItemId == lineId)
            ?? throw new PhaseCException(404, "Buying List item not found.");
        _context.BuyerProcurementItems.Remove(line);
        list.UpdatedAtUtc = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Delete,
            "Remove required Buying List item",
            list,
            actorUserId,
            new Dictionary<string, object?>
            {
                ["lineId"] = lineId,
                ["rawStockItemId"] = line.RawStockItemId,
                ["reason"] = request.Reason.Trim()
            },
            cancellationToken);
        return await GetAsync(id, cancellationToken);
    }

    public async Task<BuyingListDetailDto> AssignAsync(
        int id,
        AssignBuyingListRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        // Eligibility is derived from active backend permissions, not a client-supplied role label.
        await ValidateBuyerAsync(request.AssignedBuyerUserId, cancellationToken);
        var list = await LoadAsync(id, true, cancellationToken);
        if (list.Status is not (BuyingListStatuses.Draft or BuyingListStatuses.Open))
            throw new PhaseCException(
                409,
                "The buyer can be changed only before purchasing begins.");
        ValidateVersion(list.RowVersion, request.RowVersion);
        var previousBuyer = list.AssignedBuyerUserId;
        list.AssignedBuyerUserId = request.AssignedBuyerUserId;
        list.UpdatedAtUtc = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Update,
            "Assign Buying List",
            list,
            actorUserId,
            new Dictionary<string, object?>
            {
                ["previousBuyerUserId"] = previousBuyer,
                ["assignedBuyerUserId"] = request.AssignedBuyerUserId,
                ["reason"] = request.Reason.Trim()
            },
            cancellationToken);

        if (list.Status == BuyingListStatuses.Open)
        {
            await _notifications.PublishToUsersAsync(
                "BuyingListAssigned",
                "Info",
                "Buying List assigned",
                $"{list.ReferenceNumber} is ready for purchasing.",
                [request.AssignedBuyerUserId],
                nameof(BuyerProcurement),
                list.BuyerProcurementId.ToString(),
                $"/buying-list/{list.BuyerProcurementId}",
                actorUserId,
                correlationId,
                cancellationToken);
        }

        return await GetAsync(id, cancellationToken);
    }

    public async Task<BuyingListDetailDto> PublishAsync(
        int id,
        BuyingListCommandRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        // Publication is the hand-off boundary: only complete, assigned drafts become buyer work.
        var list = await LoadAsync(id, true, cancellationToken);
        EnsureDraft(list);
        ValidateVersion(list.RowVersion, request.RowVersion);
        if (!list.AssignedBuyerUserId.HasValue)
            throw new PhaseCException(
                409,
                "Assign an eligible Market Buyer before publishing.");
        if (list.Items.Count == 0)
            throw new PhaseCException(
                409,
                "Add at least one required item before publishing.");
        if (list.Items.Any(item =>
                item.RequiredQuantity <= 0 ||
                string.IsNullOrWhiteSpace(item.UnitOfMeasure)))
            throw new PhaseCException(
                409,
                "Every Buying List item must be complete before publishing.");

        list.Status = BuyingListStatuses.Open;
        list.PublishedAtUtc = DateTime.UtcNow;
        list.UpdatedAtUtc = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.StatusChange,
            "Publish Buying List",
            list,
            actorUserId,
            new Dictionary<string, object?>
            {
                ["status"] = list.Status,
                ["assignedBuyerUserId"] = list.AssignedBuyerUserId,
                ["reason"] = request.Reason.Trim()
            },
            cancellationToken);
        await _notifications.PublishToUsersAsync(
            "BuyingListAssigned",
            "Info",
            "Buying List ready",
            $"{list.ReferenceNumber} has been published for purchasing.",
            [list.AssignedBuyerUserId.Value],
            nameof(BuyerProcurement),
            list.BuyerProcurementId.ToString(),
            $"/buying-list/{list.BuyerProcurementId}",
            actorUserId,
            correlationId,
            cancellationToken);
        return await GetAsync(id, cancellationToken);
    }

    public async Task<BuyingListDetailDto> CancelAsync(
        int id,
        BuyingListCommandRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        var list = await LoadAsync(id, true, cancellationToken);
        if (list.Status is BuyingListStatuses.Completed or BuyingListStatuses.Cancelled)
            throw new PhaseCException(
                409,
                "The Buying List can no longer be cancelled.");
        if (list.RawStockReceipts.Count > 0)
            throw new PhaseCException(
                409,
                "A Buying List with Stock Receipts cannot be cancelled.");
        ValidateVersion(list.RowVersion, request.RowVersion);
        list.Status = BuyingListStatuses.Cancelled;
        list.CancelledAtUtc = DateTime.UtcNow;
        list.CancelledByUserId = actorUserId;
        list.CancellationReason = request.Reason.Trim();
        list.UpdatedAtUtc = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.StatusChange,
            "Cancel Buying List",
            list,
            actorUserId,
            new Dictionary<string, object?>
            {
                ["status"] = list.Status,
                ["reason"] = request.Reason.Trim()
            },
            cancellationToken);

        if (list.AssignedBuyerUserId.HasValue)
        {
            await _notifications.PublishToUsersAsync(
                "BuyingListCancelled",
                "Warning",
                "Buying List cancelled",
                $"{list.ReferenceNumber} was cancelled and is no longer actionable.",
                [list.AssignedBuyerUserId.Value],
                nameof(BuyerProcurement),
                id.ToString(),
                $"/buying-list/{id}",
                actorUserId,
                correlationId,
                cancellationToken);
        }

        return await GetAsync(id, cancellationToken);
    }

    private IQueryable<BuyerProcurement> SummaryQuery() =>
        _context.BuyerProcurements.AsNoTracking()
            .Include(item => item.AssignedBuyerUser)
            .Include(item => item.Items);

    private IQueryable<BuyerProcurement> DetailQuery(bool tracked)
    {
        var query = tracked
            ? _context.BuyerProcurements.AsQueryable()
            : _context.BuyerProcurements.AsNoTracking();
        return query
            .Include(item => item.AssignedBuyerUser)
            .Include(item => item.CreatedByUser)
            .Include(item => item.RawStockReceipts)
            .Include(item => item.Items)
                .ThenInclude(item => item.Product)
                .ThenInclude(item => item!.ProductCategory)
            .Include(item => item.Items)
                .ThenInclude(item => item.Product)
                .ThenInclude(item => item!.Stocks)
            .Include(item => item.Items)
                .ThenInclude(item => item.RawStockItem)
                .ThenInclude(item => item!.Balances)
            .Include(item => item.Items)
                .ThenInclude(item => item.Supplier)
            .Include(item => item.Items)
                .ThenInclude(item => item.PreferredSupplier)
            .Include(item => item.Items)
                .ThenInclude(item => item.SubstituteRawStockItem);
    }

    private async Task<BuyerProcurement> LoadAsync(
        int id,
        bool tracked,
        CancellationToken cancellationToken) =>
        await DetailQuery(tracked).SingleOrDefaultAsync(
            item => item.BuyerProcurementId == id,
            cancellationToken)
        ?? throw new PhaseCException(404, "Buying List not found.");

    private async Task ValidateBuyerAsync(
        int userId,
        CancellationToken cancellationToken)
    {
        var eligible = await _context.Users.AsNoTracking().AnyAsync(
            user =>
                user.UserId == userId &&
                user.Status == ProductStatuses.Active &&
                user.Role != null &&
                user.Role.IsActive &&
                user.Role.RolePermissions.Any(mapping =>
                    mapping.Permission != null &&
                    mapping.Permission.IsActive &&
                    mapping.Permission.PermissionCode ==
                    Permissions.Mobile.BuyingListView),
            cancellationToken);
        if (!eligible)
            throw new PhaseCException(
                400,
                "Select an active user with Buying List mobile access.");
    }

    private async Task ValidateLinesAsync(
        IEnumerable<SaveBuyingListLineRequest> requests,
        CancellationToken cancellationToken)
    {
        foreach (var request in requests)
            await ValidateLineAsync(request, cancellationToken);
    }

    private async Task ValidateLineAsync(
        SaveBuyingListLineRequest request,
        CancellationToken cancellationToken)
    {
        ValidatePriority(request.Priority);
        if (request.ProductId.HasValue == request.RawStockItemId.HasValue)
            throw new PhaseCException(
                400,
                "Select exactly one active Raw Stock item or legacy Product.");

        if (request.RawStockItemId.HasValue)
        {
            var rawStock = await _context.RawStockItems.AsNoTracking()
                .SingleOrDefaultAsync(
                    item =>
                        item.RawStockItemId == request.RawStockItemId.Value &&
                        item.IsActive,
                    cancellationToken)
                ?? throw new PhaseCException(400, "Select an active Raw Stock item.");
            if (!string.Equals(
                    rawStock.DefaultUnitOfMeasure,
                    request.UnitOfMeasure.Trim(),
                    StringComparison.OrdinalIgnoreCase))
                throw new PhaseCException(
                    400,
                    $"The unit for {rawStock.ItemName} must be " +
                    $"{rawStock.DefaultUnitOfMeasure}.");
        }

        if (request.ProductId.HasValue &&
            !await _context.Products.AsNoTracking().AnyAsync(
                item =>
                    item.ProductId == request.ProductId.Value &&
                    item.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(400, "Select an active Product.");

        if (request.PreferredSupplierId.HasValue &&
            !await _context.Suppliers.AsNoTracking().AnyAsync(
                item =>
                    item.SupplierId == request.PreferredSupplierId.Value &&
                    item.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(400, "Select an active preferred Supplier.");
    }

    private static void ValidateLineDuplicates(
        IReadOnlyCollection<SaveBuyingListLineRequest> requests)
    {
        var duplicates = requests
            .GroupBy(ItemKey, StringComparer.OrdinalIgnoreCase)
            .Any(group => group.Count() > 1);
        if (duplicates)
            throw new PhaseCException(
                409,
                "A Raw Stock item may appear only once in a Buying List.");
    }

    private static void EnsureNoDuplicate(
        BuyerProcurement list,
        SaveBuyingListLineRequest request,
        int? excludedLineId)
    {
        var duplicate = list.Items.Any(item =>
            item.BuyerProcurementItemId != excludedLineId &&
            item.ProductId == request.ProductId &&
            item.RawStockItemId == request.RawStockItemId);
        if (duplicate)
            throw new PhaseCException(
                409,
                "This item is already present in the Buying List.");
    }

    private static BuyerProcurementItem MapNewLine(
        SaveBuyingListLineRequest request) =>
        new()
        {
            ProductId = request.ProductId,
            RawStockItemId = request.RawStockItemId,
            RecommendedQuantity = request.RecommendedQuantity,
            RequiredQuantity = request.RequiredQuantity,
            UnitOfMeasure = request.UnitOfMeasure.Trim().ToLowerInvariant(),
            Priority = request.Priority.Trim(),
            PreferredSupplierId = request.PreferredSupplierId,
            ManagementNotes = Clean(request.ManagementNotes),
            Status = BuyingItemStatuses.Pending,
            UpdatedAtUtc = DateTime.UtcNow
        };

    private static BuyingListSummaryDto MapSummary(BuyerProcurement list) =>
        new()
        {
            BuyerProcurementId = list.BuyerProcurementId,
            ReferenceNumber = list.ReferenceNumber,
            Title = list.Title,
            BuyingDateUtc = list.BuyingDateUtc,
            AssignedBuyerUserId = list.AssignedBuyerUserId,
            BuyerName = list.AssignedBuyerUser is null
                ? null
                : $"{list.AssignedBuyerUser.FirstName} " +
                  $"{list.AssignedBuyerUser.LastName}".Trim(),
            Priority = list.Priority,
            Status = list.Status,
            ItemCount = list.Items.Count,
            ResolvedItemCount = list.Items.Count(item =>
                item.Status != BuyingItemStatuses.Pending),
            RequiredQuantity = list.Items.Sum(item => item.RequiredQuantity),
            PurchasedQuantity = list.Items.Sum(item => item.ActualQuantity ?? 0),
            ReceivedQuantity = list.Items.Sum(item => item.ReceivedQuantity),
            UpdatedAtUtc = list.UpdatedAtUtc,
            RowVersion = Encode(list.RowVersion)
        };

    private static BuyingListDetailDto MapDetail(BuyerProcurement list)
    {
        var summary = MapSummary(list);
        return new BuyingListDetailDto
        {
            BuyerProcurementId = summary.BuyerProcurementId,
            ReferenceNumber = summary.ReferenceNumber,
            Title = summary.Title,
            BuyingDateUtc = summary.BuyingDateUtc,
            AssignedBuyerUserId = summary.AssignedBuyerUserId,
            BuyerName = summary.BuyerName,
            Priority = summary.Priority,
            Status = summary.Status,
            ItemCount = summary.ItemCount,
            ResolvedItemCount = summary.ResolvedItemCount,
            RequiredQuantity = summary.RequiredQuantity,
            PurchasedQuantity = summary.PurchasedQuantity,
            ReceivedQuantity = summary.ReceivedQuantity,
            UpdatedAtUtc = summary.UpdatedAtUtc,
            RowVersion = summary.RowVersion,
            Notes = list.Notes,
            CreatedAtUtc = list.CreatedAtUtc,
            PublishedAtUtc = list.PublishedAtUtc,
            SubmittedAtUtc = list.SubmittedAtUtc,
            CancelledAtUtc = list.CancelledAtUtc,
            CancellationReason = list.CancellationReason,
            CreatedByName = list.CreatedByUser == null
                ? "Legacy system record"
                : $"{list.CreatedByUser.FirstName} " +
                  $"{list.CreatedByUser.LastName}".Trim(),
            DocketStoredFileId = list.DocketStoredFileId,
            Items = list.Items
                .OrderBy(item =>
                    item.RawStockItem?.ItemName ?? item.Product?.ProductName)
                .Select(MapLine)
                .ToList()
        };
    }

    private static BuyingListLineDto MapLine(BuyerProcurementItem item)
    {
        var target = item.Status is BuyingItemStatuses.Purchased or
            BuyingItemStatuses.Substituted
            ? item.ActualQuantity ?? 0
            : 0;
        return new BuyingListLineDto
        {
            BuyerProcurementItemId = item.BuyerProcurementItemId,
            ProductId = item.ProductId,
            RawStockItemId = item.RawStockItemId,
            ItemCode = item.RawStockItem?.ItemCode ??
                item.Product?.QRCodeValue ??
                $"PRODUCT-{item.ProductId:D6}",
            ItemName = item.RawStockItem?.ItemName ??
                item.Product?.ProductName ??
                "Unavailable item",
            Category = item.RawStockItem?.CategoryCode ??
                item.Product?.ProductCategory?.ProductCategoryName ??
                string.Empty,
            UnitOfMeasure = item.UnitOfMeasure,
            CurrentStock = item.RawStockItem is not null
                ? item.RawStockItem.Balances.Sum(balance => balance.QuantityOnHand)
                : item.Product?.Stocks.Sum(stock => stock.QuantityAvailableKg) ?? 0,
            RecommendedQuantity = item.RecommendedQuantity,
            RequiredQuantity = item.RequiredQuantity,
            ActualQuantity = item.ActualQuantity,
            ActualUnitPrice = item.ActualUnitPrice,
            ReceivedQuantity = item.ReceivedQuantity,
            OutstandingQuantity = Math.Max(0, target - item.ReceivedQuantity),
            Priority = item.Priority,
            PreferredSupplierId = item.PreferredSupplierId,
            PreferredSupplierName = item.PreferredSupplier?.SupplierName,
            SupplierId = item.SupplierId,
            SupplierName = item.Supplier?.SupplierName,
            Status = item.Status,
            IsPromotionalItem = item.IsPromotionalItem,
            ManagementNotes = item.ManagementNotes,
            BuyerNotes = item.BuyerNotes,
            UnavailableReason = item.UnavailableReason,
            SubstituteRawStockItemId = item.SubstituteRawStockItemId,
            SubstituteItemName = item.SubstituteRawStockItem?.ItemName,
            SubstituteNotes = item.SubstituteNotes,
            RowVersion = Encode(item.RowVersion)
        };
    }

    private Task AuditAsync(
        string action,
        string operation,
        BuyerProcurement list,
        int actorUserId,
        IReadOnlyDictionary<string, object?> details,
        CancellationToken cancellationToken) =>
        _audit.RecordAsync(
            new AuditEvent
            {
                ActionType = action,
                SystemModule = AuditModules.BuyingList,
                OperationName = operation,
                Description = $"{operation}: {list.ReferenceNumber}.",
                EntityType = nameof(BuyerProcurement),
                EntityId = list.BuyerProcurementId.ToString(),
                EntityDisplay = list.ReferenceNumber,
                UserId = actorUserId,
                SafeDetails = details
            },
            cancellationToken);

    private async Task SaveConcurrencyAsync(
        CancellationToken cancellationToken)
    {
        try
        {
            await _context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new PhaseCException(
                409,
                "The Buying List changed while you were editing it. Refresh and try again.");
        }
    }

    private static void ValidateVersion(byte[]? current, string? supplied)
    {
        if (current is null || string.IsNullOrWhiteSpace(supplied))
            return;
        try
        {
            if (!current.SequenceEqual(Convert.FromBase64String(supplied)))
                throw new PhaseCException(
                    409,
                    "The Buying List changed while you were editing it. Refresh and try again.");
        }
        catch (FormatException)
        {
            throw new PhaseCException(400, "The concurrency value is invalid.");
        }
    }

    private static void EnsureDraft(BuyerProcurement list)
    {
        if (list.Status != BuyingListStatuses.Draft)
            throw new PhaseCException(
                409,
                "Only a draft Buying List can be changed by management.");
    }

    private static void ValidatePriority(string priority)
    {
        if (!BuyingListPriorities.All.Contains(priority))
            throw new PhaseCException(400, "Select a valid Buying List priority.");
    }

    private static string ItemKey(SaveBuyingListLineRequest item) =>
        item.RawStockItemId.HasValue
            ? $"RAW:{item.RawStockItemId.Value}"
            : $"PRODUCT:{item.ProductId!.Value}";

    private static string Encode(byte[]? value) =>
        value is null ? string.Empty : Convert.ToBase64String(value);

    private static string? Clean(string? value, int maximum = 1000)
    {
        var cleaned = value?.Trim();
        if (string.IsNullOrWhiteSpace(cleaned))
            return null;
        return cleaned.Length <= maximum ? cleaned : cleaned[..maximum];
    }

    private static int StatusOrder(string status) =>
        status switch
        {
            BuyingListStatuses.Draft => 1,
            BuyingListStatuses.Open => 2,
            BuyingListStatuses.InProgress => 3,
            BuyingListStatuses.Submitted => 4,
            BuyingListStatuses.PartiallyReceived => 5,
            BuyingListStatuses.Completed => 6,
            BuyingListStatuses.Cancelled => 7,
            _ => 99
        };

    private static string DisplayStatus(string status) =>
        status switch
        {
            BuyingListStatuses.InProgress => "In Progress",
            BuyingListStatuses.PartiallyReceived => "Partially Received",
            _ => status
        };
}
