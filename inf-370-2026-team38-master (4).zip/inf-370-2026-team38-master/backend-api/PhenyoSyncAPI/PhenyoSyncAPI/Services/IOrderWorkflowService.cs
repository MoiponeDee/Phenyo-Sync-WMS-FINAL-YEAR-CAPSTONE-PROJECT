using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;

// Defines the authoritative order state-machine operations.
namespace PhenyoSyncAPI.Services;

public interface IOrderWorkflowService
{
    Task<SalesOrderDetailDto> ApproveAsync(
        int orderId,
        OrderDecisionDto request,
        int userId,
        CancellationToken cancellationToken);
    Task<SalesOrderDetailDto> RejectAsync(
        int orderId,
        OrderDecisionDto request,
        int userId,
        CancellationToken cancellationToken);
    Task<SalesOrderDetailDto> CancelAsync(int orderId, CancelOrderDto request, int userId, CancellationToken cancellationToken);
    Task<SalesOrderDetailDto> TransitionAsync(int orderId, UpdateOrderStatusDto request, int userId, string role, CancellationToken cancellationToken);
    Task ApplyLogisticsTransitionAsync(
        SalesOrder order,
        string newStatus,
        int userId,
        string? reason,
        CancellationToken cancellationToken);
    Task<InvoiceDto> GetInvoiceAsync(int orderId, CancellationToken cancellationToken);
}
