using System.Data;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;

namespace PhenyoSyncAPI.Services;

/// <summary>
/// Creates, searches and edits the commercial order aggregate. Product prices
/// and customer details are copied into order snapshots so later master-data
/// changes do not rewrite an existing order's commercial history.
/// </summary>
public sealed class OrderService : IOrderService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly OrderManagementOptions _options;
    private readonly IProductPricingService _pricing;
    private readonly ISystemSettingProvider? _settings;

    public OrderService(
        PhenyoSyncDbContext context,
        IOptions<OrderManagementOptions> options,
        IProductPricingService pricing,
        ISystemSettingProvider? settings = null)
    {
        _context = context;
        _options = options.Value;
        _pricing = pricing;
        _settings = settings;
    }

    public async Task<SalesOrderDetailDto> CreateAsync(
        CreateSalesOrderDto request,
        int? createdByUserId,
        long? orderLinkId,
        CancellationToken cancellationToken)
    {
        // Resolve every product and its effective price on the server. A client
        // cannot choose its own price or create an unknown product through an order.
        IDbContextTransaction? ownedTransaction = null;
        if (_context.Database.CurrentTransaction is null)
        {
            ownedTransaction = await _context.Database.BeginTransactionAsync(
                IsolationLevel.Serializable,
                cancellationToken);
        }

        try
        {
            CustomerOrderLink? orderLink = null;
            if (orderLinkId.HasValue)
            {
                orderLink = await _context.CustomerOrderLinks
                    .FirstOrDefaultAsync(
                        link => link.CustomerOrderLinkId == orderLinkId.Value,
                        cancellationToken);
                EnsureLinkCanBeUsed(orderLink);
                request.CustomerId = orderLink!.CustomerId;
            }

            var order = await BuildOrderAsync(
                request,
                createdByUserId,
                orderLinkId,
                cancellationToken);
            _context.SalesOrders.Add(order);
            await _context.SaveChangesAsync(cancellationToken);

            if (orderLink is not null)
            {
                orderLink.UsedAtUtc = DateTime.UtcNow;
                orderLink.SalesOrderId = order.SalesOrderId;
            }

            await _context.SaveChangesAsync(cancellationToken);
            if (ownedTransaction is not null)
                await ownedTransaction.CommitAsync(cancellationToken);
            return await GetAsync(order.SalesOrderId, cancellationToken);
        }
        finally
        {
            if (ownedTransaction is not null)
                await ownedTransaction.DisposeAsync();
        }
    }

    public async Task<SalesOrderDetailDto> GetAsync(int orderId, CancellationToken cancellationToken)
    {
        var order = await _context.SalesOrders
            .AsNoTracking()
            .Include(item => item.Customer)
            .Include(item => item.Items)
            .Include(item => item.Invoice)
            .Include(item => item.StatusHistory)
                .ThenInclude(history => history.ChangedByUser)
            .Include(item => item.StockReservations)
                .ThenInclude(reservation => reservation.SalesOrderItem)
            .Include(item => item.StockReservations)
                .ThenInclude(reservation => reservation.ProductBatch)
                    .ThenInclude(batch => batch.WarehouseSection)
            .FirstOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
            ?? throw new OrderManagementException(404, "Sales order not found.");

        return MapDetail(order);
    }

    public async Task<PagedResultDto<SalesOrderSummaryDto>> SearchAsync(
        OrderSearchQueryDto request,
        CancellationToken cancellationToken)
    {
        var page = Math.Max(1, request.Page);
        var pageSize = Math.Clamp(
            request.PageSize <= 0 ? _options.DefaultPageSize : request.PageSize,
            1,
            _options.MaximumPageSize);

        var query = _context.SalesOrders.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(request.SearchTerm))
        {
            var term = request.SearchTerm.Trim();
            query = query.Where(order =>
                order.OrderNumber.Contains(term) ||
                order.Customer.CustomerName.Contains(term) ||
                order.Customer.Email.Contains(term) ||
                order.Items.Any(item => item.IsActive && item.ProductNameSnapshot.Contains(term)));
        }

        if (!string.IsNullOrWhiteSpace(request.Status))
        {
            query = request.Status == SalesOrderStatuses.Submitted
                ? query.Where(order =>
                    order.Status == SalesOrderStatuses.Submitted ||
                    order.Status == SalesOrderStatuses.LegacyPendingValidation)
                : query.Where(order => order.Status == request.Status);
        }
        if (!string.IsNullOrWhiteSpace(request.ValidationStatus))
            query = query.Where(order => order.ValidationStatus == request.ValidationStatus);
        if (request.FromDateUtc.HasValue)
            query = query.Where(order => order.OrderDateUtc >= request.FromDateUtc.Value);
        if (request.ToDateUtc.HasValue)
            query = query.Where(order => order.OrderDateUtc <= request.ToDateUtc.Value);
        if (request.DeliveryFromUtc.HasValue)
            query = query.Where(order => order.RequestedDeliveryDateUtc >= request.DeliveryFromUtc.Value);
        if (request.DeliveryToUtc.HasValue)
            query = query.Where(order => order.RequestedDeliveryDateUtc <= request.DeliveryToUtc.Value);

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await query
            .OrderByDescending(order => order.OrderDateUtc)
            .ThenByDescending(order => order.SalesOrderId)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(order => new SalesOrderSummaryDto
            {
                SalesOrderId = order.SalesOrderId,
                OrderNumber = order.OrderNumber,
                CustomerName = order.Customer.CustomerName,
                CustomerEmail = order.Customer.Email,
                OrderDateUtc = order.OrderDateUtc,
                RequestedDeliveryDateUtc = order.RequestedDeliveryDateUtc,
                Status = order.Status == SalesOrderStatuses.LegacyPendingValidation
                    ? SalesOrderStatuses.Submitted
                    : order.Status,
                ValidationStatus = order.ValidationStatus,
                ItemCount = order.Items.Count(item => item.IsActive),
                TotalAmount = order.TotalAmount,
                HasInvoice = order.Invoice != null,
                CanUpdate = order.Status == SalesOrderStatuses.Submitted ||
                    order.Status == SalesOrderStatuses.LegacyPendingValidation ||
                    order.Status == SalesOrderStatuses.Rejected ||
                    order.Status == SalesOrderStatuses.Approved ||
                    order.Status == SalesOrderStatuses.Confirmed,
                CanValidate = order.Status == SalesOrderStatuses.Submitted ||
                    order.Status == SalesOrderStatuses.LegacyPendingValidation,
                CanCancel = order.Status == SalesOrderStatuses.Approved ||
                    order.Status == SalesOrderStatuses.Confirmed ||
                    order.Status == SalesOrderStatuses.Packing,
                CanViewPackingList = order.Status == SalesOrderStatuses.Approved ||
                    order.Status == SalesOrderStatuses.Confirmed ||
                    order.Status == SalesOrderStatuses.Packing ||
                    order.Status == SalesOrderStatuses.Packed ||
                    order.Status == SalesOrderStatuses.ReadyForDispatch
            })
            .ToListAsync(cancellationToken);

        return new PagedResultDto<SalesOrderSummaryDto>
        {
            Items = items,
            Page = page,
            PageSize = pageSize,
            TotalCount = totalCount,
            TotalPages = totalCount == 0 ? 0 : (int)Math.Ceiling(totalCount / (double)pageSize)
        };
    }

    public async Task<SalesOrderDetailDto> UpdateAsync(
        int orderId,
        UpdateSalesOrderDto request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Only editable lifecycle states reach this block. Existing line state
        // is reconciled in one transaction and the row version rejects stale data.
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);

        var order = await _context.SalesOrders
            .Include(item => item.Items)
            .Include(item => item.StockReservations)
            .Include(item => item.Invoice)
            .FirstOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
            ?? throw new OrderManagementException(404, "Sales order not found.");

        var editableStatuses = new[]
        {
            SalesOrderStatuses.Submitted,
            SalesOrderStatuses.LegacyPendingValidation,
            SalesOrderStatuses.Rejected,
            SalesOrderStatuses.Approved,
            SalesOrderStatuses.Confirmed
        };
        if (!editableStatuses.Contains(order.Status))
            throw new OrderManagementException(409, $"An order in {order.Status} status cannot be materially updated.");

        if (!string.IsNullOrWhiteSpace(request.RowVersion) && order.RowVersion is not null)
        {
            byte[] supplied;
            try { supplied = Convert.FromBase64String(request.RowVersion); }
            catch (FormatException) { throw new OrderManagementException(400, "The order concurrency token is invalid."); }
            if (!CryptographicOperations.FixedTimeEquals(supplied, order.RowVersion))
                throw new OrderManagementException(409, "This order was changed by another user. Reload it before saving.");
        }

        var rebuilt = await BuildOrderAsync(request, order.CreatedByUserId, order.CreatedViaOrderLinkId, cancellationToken);
        var previousStatus = order.Status;
        foreach (var reservation in order.StockReservations.Where(item => item.Status == OrderReservationStatuses.Active))
        {
            reservation.Status = OrderReservationStatuses.Released;
            reservation.ReleasedAtUtc = DateTime.UtcNow;
        }

        foreach (var existingItem in order.Items.Where(item => item.IsActive))
            existingItem.IsActive = false;
        order.CustomerId = rebuilt.CustomerId;
        order.RequestedDeliveryDateUtc = rebuilt.RequestedDeliveryDateUtc;
        order.DeliveryAddressSnapshot = rebuilt.DeliveryAddressSnapshot;
        order.BillingAddressSnapshot = rebuilt.BillingAddressSnapshot;
        order.Notes = rebuilt.Notes;
        order.Subtotal = rebuilt.Subtotal;
        order.TaxRatePercent = rebuilt.TaxRatePercent;
        order.TaxAmount = rebuilt.TaxAmount;
        order.TotalAmount = rebuilt.TotalAmount;
        foreach (var replacementItem in rebuilt.Items)
            order.Items.Add(replacementItem);
        order.Status = SalesOrderStatuses.Submitted;
        order.ValidationStatus = OrderValidationStatuses.Pending;
        order.ValidationMessage = null;
        order.ValidatedAtUtc = null;
        order.ValidatedByUserId = null;
        order.UpdatedAtUtc = DateTime.UtcNow;

        if (order.Invoice is not null)
            order.Invoice.Status = InvoiceStatuses.Cancelled;

        order.StatusHistory.Add(new OrderStatusHistory
        {
            PreviousStatus = previousStatus,
            NewStatus = SalesOrderStatuses.Submitted,
            ChangedByUserId = userId,
            ChangedAtUtc = DateTime.UtcNow,
            Reason = "Material order details were updated; stock must be revalidated."
        });

        try
        {
            await _context.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new OrderManagementException(409, "This order was changed by another user. Reload it before saving.");
        }

        return await GetAsync(orderId, cancellationToken);
    }

    private async Task<SalesOrder> BuildOrderAsync(
        CreateSalesOrderDto request,
        int? createdByUserId,
        long? orderLinkId,
        CancellationToken cancellationToken)
    {
        var customer = await _context.Customers.AsNoTracking()
            .FirstOrDefaultAsync(item => item.CustomerId == request.CustomerId, cancellationToken);
        if (customer is null || customer.Status != CustomerStatuses.Active)
            throw new OrderManagementException(400, "Select a valid active customer.");
        if (request.RequestedDeliveryDateUtc.HasValue &&
            request.RequestedDeliveryDateUtc.Value < DateTime.UtcNow.AddMinutes(-5))
            throw new OrderManagementException(400, "Requested delivery date cannot be in the past.");
        if (request.Items.Count == 0)
            throw new OrderManagementException(400, "Add at least one order item.");

        var duplicateProductIds = request.Items
            .GroupBy(item => item.ProductId)
            .Where(group => group.Count() > 1)
            .Select(group => group.Key)
            .ToArray();
        if (duplicateProductIds.Length > 0)
            throw new OrderManagementException(
                400,
                "Each product may appear only once on an order. Combine duplicate quantities into one line.");

        var requestedItems = request.Items
            .Select(item => new
            {
                item.ProductId,
                item.QuantityUnits,
                item.QuantityKg,
                Notes = item.Notes?.Trim()
            })
            .ToList();
        if (requestedItems.Any(item =>
                item.ProductId <= 0 ||
                (item.QuantityUnits.HasValue && item.QuantityKg.HasValue) ||
                (!item.QuantityUnits.HasValue && !item.QuantityKg.HasValue) ||
                (item.QuantityUnits ?? item.QuantityKg) <= 0))
            throw new OrderManagementException(400, "Every order item requires a valid product and positive quantity.");

        var productIds = requestedItems.Select(item => item.ProductId).ToList();
        var products = await _context.Products.AsNoTracking()
            .Where(product => productIds.Contains(product.ProductId))
            .ToDictionaryAsync(product => product.ProductId, cancellationToken);
        if (products.Count != productIds.Count)
            throw new OrderManagementException(400, "One or more selected products do not exist.");

        var currentPrices = await _pricing.GetCurrentPricesForProductsAsync(
            productIds,
            cancellationToken);

        var order = new SalesOrder
        {
            OrderNumber = await CreateUniqueNumberAsync("SO", cancellationToken),
            CustomerId = customer.CustomerId,
            OrderDateUtc = DateTime.UtcNow,
            RequestedDeliveryDateUtc = request.RequestedDeliveryDateUtc?.ToUniversalTime(),
            DeliveryAddressSnapshot = request.DeliveryAddress.Trim(),
            BillingAddressSnapshot = request.BillingAddress.Trim(),
            Notes = request.Notes?.Trim(),
            CreatedByUserId = createdByUserId,
            CreatedViaOrderLinkId = orderLinkId,
            Status = SalesOrderStatuses.Submitted,
            ValidationStatus = OrderValidationStatuses.Pending,
            CreatedAtUtc = DateTime.UtcNow
        };

        foreach (var requested in requestedItems)
        {
            var product = products[requested.ProductId];
            if (product.Status != ProductStatuses.Active)
                throw new OrderManagementException(400, $"{product.ProductName} is inactive and cannot be ordered.");
            if (!currentPrices.TryGetValue(product.ProductId, out var currentPrice))
                throw new OrderManagementException(
                    409,
                    $"{product.ProductName} does not have a current valid price. Ask a pricing manager to create one.");
            var legacyKilogramInput = !requested.QuantityUnits.HasValue;
            var submittedQuantity = requested.QuantityUnits ?? requested.QuantityKg!.Value;
            if (!legacyKilogramInput && !product.IsVariableWeight && submittedQuantity != decimal.Truncate(submittedQuantity))
                throw new OrderManagementException(
                    400,
                    $"{product.ProductName} is sold by {product.SellingUnit}; enter a whole number of units.");
            var priceBasis = ProductPriceBases.IsValid(currentPrice.PriceBasis)
                ? currentPrice.PriceBasis
                : ProductPriceBases.PerKilogram;
            if (legacyKilogramInput && priceBasis == ProductPriceBases.PerSellableUnit)
                throw new OrderManagementException(
                    409,
                    $"{product.ProductName} is priced per {product.SellingUnit}; submit a sellable-unit quantity.");
            if (!legacyKilogramInput &&
                priceBasis == ProductPriceBases.PerKilogram &&
                !product.IsVariableWeight &&
                product.KilogramsPerUnit is null or <= 0)
                throw new OrderManagementException(
                    409,
                    $"{product.ProductName} needs kilograms per unit for per-kilogram pricing, or a per-unit price.");

            var kilogramsPerUnit = product.IsVariableWeight ? 1m : product.KilogramsPerUnit;
            decimal? quantityKg = legacyKilogramInput
                ? submittedQuantity
                : kilogramsPerUnit.HasValue
                    ? submittedQuantity * kilogramsPerUnit.Value
                    : null;
            var unitPrice = priceBasis == ProductPriceBases.PerSellableUnit
                ? currentPrice.SellingPrice
                : legacyKilogramInput || product.IsVariableWeight
                    ? currentPrice.SellingPrice
                    : currentPrice.SellingPrice * kilogramsPerUnit!.Value;
            var lineTotal = decimal.Round(submittedQuantity * unitPrice, 2);
            order.Items.Add(new SalesOrderItem
            {
                ProductId = product.ProductId,
                ProductPriceId = currentPrice.ProductPriceId,
                ProductNameSnapshot = product.ProductName,
                ProductSizeSnapshot = product.Size,
                QuantityKg = quantityKg ?? 0m,
                UnitPricePerKg = priceBasis == ProductPriceBases.PerKilogram
                    ? currentPrice.SellingPrice
                    : 0m,
                QuantityUnits = legacyKilogramInput ? null : submittedQuantity,
                SellingUnitSnapshot = legacyKilogramInput ? null : product.SellingUnit,
                KilogramsPerUnitSnapshot = legacyKilogramInput ? null : kilogramsPerUnit,
                UnitPrice = legacyKilogramInput ? null : decimal.Round(unitPrice, 2),
                PriceBasisSnapshot = priceBasis,
                LineTotal = lineTotal,
                Notes = string.IsNullOrWhiteSpace(requested.Notes) ? null : requested.Notes
            });
        }

        order.Subtotal = order.Items.Sum(item => item.LineTotal);
        var taxRate = _settings is null
            ? Math.Max(0, _options.TaxRatePercent)
            : await _settings.GetDecimalAsync(SystemSettingKeys.OrdersVatRatePercent, cancellationToken);
        order.TaxRatePercent = taxRate;
        order.TaxAmount = decimal.Round(order.Subtotal * taxRate / 100m, 2);
        order.TotalAmount = order.Subtotal + order.TaxAmount;
        order.StatusHistory.Add(new OrderStatusHistory
        {
            NewStatus = SalesOrderStatuses.Submitted,
            ChangedByUserId = createdByUserId,
            ChangedAtUtc = DateTime.UtcNow,
            Reason = orderLinkId.HasValue
                ? "Customer request was captured as an official order."
                : "Order submitted by an authorized user."
        });
        return order;
    }

    private async Task<string> CreateUniqueNumberAsync(string prefix, CancellationToken cancellationToken)
    {
        for (var attempt = 0; attempt < 20; attempt++)
        {
            var candidate = $"{prefix}-{DateTime.UtcNow:yyyyMM}-{RandomNumberGenerator.GetInt32(0, 1_000_000):D6}";
            var exists = prefix == "SO"
                ? await _context.SalesOrders.AnyAsync(item => item.OrderNumber == candidate, cancellationToken)
                : await _context.Invoices.AnyAsync(item => item.InvoiceNumber == candidate, cancellationToken);
            if (!exists) return candidate;
        }
        throw new OrderManagementException(409, $"Unable to allocate a unique {prefix} number. Try again.");
    }

    private static void EnsureLinkCanBeUsed(CustomerOrderLink? link)
    {
        if (link is null) throw new OrderManagementException(400, "The order link is invalid.");
        if (link.RevokedAtUtc.HasValue) throw new OrderManagementException(410, "The order link has been revoked.");
        if (link.ExpiresAtUtc <= DateTime.UtcNow) throw new OrderManagementException(410, "The order link has expired.");
        if (link.UsedAtUtc.HasValue || link.SalesOrderId.HasValue)
            throw new OrderManagementException(409, "The order link has already been used.");
    }

    private static SalesOrderDetailDto MapDetail(SalesOrder order) => new()
    {
        SalesOrderId = order.SalesOrderId,
        OrderNumber = order.OrderNumber,
        CustomerId = order.CustomerId,
        CustomerNumber = order.Customer.CustomerNumber,
        CustomerName = order.Customer.CustomerName,
        CustomerEmail = order.Customer.Email,
        OrderDateUtc = order.OrderDateUtc,
        RequestedDeliveryDateUtc = order.RequestedDeliveryDateUtc,
        DeliveryAddress = order.DeliveryAddressSnapshot,
        BillingAddress = order.BillingAddressSnapshot,
        Status = SalesOrderStatuses.Normalize(order.Status),
        ValidationStatus = order.ValidationStatus,
        ValidationMessage = order.ValidationMessage,
        Subtotal = order.Subtotal,
        TaxRatePercent = order.TaxRatePercent ?? 0,
        TaxAmount = order.TaxAmount,
        TotalAmount = order.TotalAmount,
        Notes = order.Notes,
        RowVersion = order.RowVersion is null ? string.Empty : Convert.ToBase64String(order.RowVersion),
        InvoiceId = order.Invoice?.InvoiceId,
        Items = order.Items.Where(item => item.IsActive).OrderBy(item => item.SalesOrderItemId).Select(item => new OrderItemDto
        {
            SalesOrderItemId = item.SalesOrderItemId,
            ProductId = item.ProductId,
            ProductPriceId = item.ProductPriceId,
            ProductName = item.ProductNameSnapshot,
            ProductSize = item.ProductSizeSnapshot,
            QuantityKg = item.QuantityUnits.HasValue &&
                !item.KilogramsPerUnitSnapshot.HasValue &&
                !string.Equals(item.SellingUnitSnapshot, "kg", StringComparison.OrdinalIgnoreCase)
                    ? null
                    : item.QuantityKg,
            UnitPricePerKg = item.PriceBasisSnapshot == ProductPriceBases.PerSellableUnit
                ? null
                : item.UnitPricePerKg,
            QuantityUnits = item.QuantityUnits ?? item.QuantityKg,
            SellingUnit = item.SellingUnitSnapshot ?? "kg",
            KilogramsPerUnit = item.KilogramsPerUnitSnapshot,
            UnitPrice = item.UnitPrice ?? item.UnitPricePerKg,
            PriceBasis = item.PriceBasisSnapshot ?? "LegacyPerKilogram",
            LineTotal = item.LineTotal,
            Notes = item.Notes
        }).ToList(),
        Reservations = order.StockReservations.OrderBy(item => item.ProductBatch.EffectiveExpiryAtUtc)
            .Select(item => new OrderReservationDto
            {
                OrderStockReservationId = item.OrderStockReservationId,
                SalesOrderItemId = item.SalesOrderItemId,
                ProductBatchId = item.ProductBatchId,
                ProductName = item.SalesOrderItem.ProductNameSnapshot,
                ProductSize = item.SalesOrderItem.ProductSizeSnapshot,
                BatchCode = item.ProductBatch.BatchCode,
                BatchQrValue = item.ProductBatch.QRCodeValue,
                SectionId = item.SectionId,
                SectionName = item.ProductBatch.WarehouseSection.SectionName,
                QuantityReservedKg = item.QuantityReservedKg,
                PackedAtUtc = item.ProductBatch.PackedAtUtc,
                EffectiveExpiryAtUtc = item.ProductBatch.EffectiveExpiryAtUtc,
                Status = item.Status
            }).ToList(),
        StatusHistory = order.StatusHistory.OrderByDescending(item => item.ChangedAtUtc)
            .Select(item => new OrderStatusHistoryDto
            {
                PreviousStatus = item.PreviousStatus,
                NewStatus = item.NewStatus,
                ChangedAtUtc = item.ChangedAtUtc,
                ChangedBy = item.ChangedByUser == null
                    ? "Customer"
                    : $"{item.ChangedByUser.FirstName} {item.ChangedByUser.LastName}",
                Reason = item.Reason
            }).ToList()
    };
}
