using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Operational;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IManagementDashboardService
{
    Task<ManagementDashboardDto> GetAsync(
        DateTime? fromUtc,
        DateTime? toUtc,
        CancellationToken cancellationToken);
}

/// <summary>Aggregates management KPIs from current operational state using read-only queries.</summary>
public sealed class ManagementDashboardService : IManagementDashboardService
{
    private readonly PhenyoSyncDbContext _context;

    public ManagementDashboardService(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    public async Task<ManagementDashboardDto> GetAsync(
        DateTime? fromUtc,
        DateTime? toUtc,
        CancellationToken cancellationToken)
    {
        var from = (fromUtc ?? DateTime.UtcNow.AddDays(-30)).ToUniversalTime();
        var to = (toUtc ?? DateTime.UtcNow).ToUniversalTime();
        if (from >= to || to - from > TimeSpan.FromDays(366))
            throw new PhaseCException(
                400,
                "Select a valid dashboard date range of no more than 366 days.");

        var wasteProduct = await _context.StockWriteOffs.AsNoTracking()
            .Where(item => item.SubmittedAtUtc >= from &&
                           item.SubmittedAtUtc <= to &&
                           item.Status == WriteOffStatuses.Completed &&
                           item.EstimatedTotalLoss.HasValue)
            .GroupBy(item => item.ReasonCode)
            .Select(group => new DashboardGraphPointDto
            {
                Label = group.Key,
                Value = group.Sum(item => item.EstimatedTotalLoss!.Value),
                Count = group.Count()
            })
            .ToListAsync(cancellationToken);
        var wasteRaw = await _context.RawStockWriteOffs.AsNoTracking()
            .Where(item => item.SubmittedAtUtc >= from &&
                           item.SubmittedAtUtc <= to &&
                           item.Status == WriteOffStatuses.Completed &&
                           item.EstimatedTotalLoss.HasValue)
            .GroupBy(item => item.OperationalReason.ReasonName)
            .Select(group => new DashboardGraphPointDto
            {
                Label = group.Key,
                Value = group.Sum(item => item.EstimatedTotalLoss!.Value),
                Count = group.Count()
            })
            .ToListAsync(cancellationToken);
        var waste = wasteProduct.Concat(wasteRaw)
            .GroupBy(item => item.Label, StringComparer.OrdinalIgnoreCase)
            .Select(group => new DashboardGraphPointDto
            {
                Label = group.Key,
                Value = group.Sum(item => item.Value),
                Count = group.Sum(item => item.Count)
            })
            .OrderByDescending(item => item.Value)
            .Take(8)
            .ToArray();

        var deliveryGraph = await _context.Deliveries.AsNoTracking()
            .Where(item => item.CreatedAtUtc >= from &&
                           item.CreatedAtUtc <= to)
            .GroupBy(item => item.Status)
            .Select(group => new DashboardGraphPointDto
            {
                Label = group.Key,
                Value = group.Count(),
                Count = group.Count()
            })
            .OrderByDescending(item => item.Count)
            .ToListAsync(cancellationToken);

        var expiryCutoff = DateTime.UtcNow.AddHours(24);
        return new ManagementDashboardDto
        {
            PendingDispatches = await _context.SalesOrders.CountAsync(
                item => item.Status == SalesOrderStatuses.ReadyForDispatch,
                cancellationToken),
            ActiveDeliveries = await _context.Deliveries.CountAsync(
                item => item.Status == DeliveryStatuses.Assigned ||
                        item.Status == DeliveryStatuses.InTransit,
                cancellationToken),
            PendingWriteOffApprovals =
                await _context.StockWriteOffs.CountAsync(
                    item => item.Status == WriteOffStatuses.PendingApproval,
                    cancellationToken) +
                await _context.RawStockWriteOffs.CountAsync(
                    item => item.Status == WriteOffStatuses.PendingApproval,
                    cancellationToken),
            PendingStockTakeApprovals =
                await _context.RawStockTakeSessions.CountAsync(
                    item => item.Status ==
                            RawStockTakeStatuses.PendingManagementApproval,
                    cancellationToken),
            CriticalExpiryAlerts =
                await _context.ProductBatches.CountAsync(
                    item => item.Status == ProductBatchStatuses.Available &&
                            item.EffectiveExpiryAtUtc <= expiryCutoff,
                    cancellationToken) +
                await _context.RawStockBatches.CountAsync(
                    item => item.Status == ProductBatchStatuses.Available &&
                            item.BestBeforeAtUtc != null &&
                            item.BestBeforeAtUtc <= expiryCutoff,
                    cancellationToken),
            BuyingListsAwaitingReceipt =
                await _context.BuyerProcurements.CountAsync(
                    item => item.Status == MobileOperationStatuses.Completed,
                    cancellationToken),
            WasteByReason = waste,
            DeliveriesByStatus = deliveryGraph
        };
    }
}
