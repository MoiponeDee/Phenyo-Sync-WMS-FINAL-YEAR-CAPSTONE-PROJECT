using System.Net;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;

namespace PhenyoSyncAPI.Services
{
    /// <summary>Sends application email through configured SMTP settings without exposing credentials.</summary>
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _configuration;

        public EmailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public Task SendPasswordResetEmailAsync(string recipientEmail, string resetLink)
        {
            var safeLink = WebUtility.HtmlEncode(resetLink);
            var html = $"""
                <div style="font-family:Arial,sans-serif;line-height:1.5">
                  <h2 style="color:#146c3c">PhenyoSync Password Reset</h2>
                  <p>A request was received to reset your PhenyoSync WMS password.</p>
                  <p><a href="{safeLink}" style="background:#168044;color:#fff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:bold">Reset Password</a></p>
                  <p>This link expires in 30 minutes. If you did not request it, ignore this email.</p>
                </div>
                """;

            return SendAsync(
                [recipientEmail],
                "Reset your PhenyoSync password",
                html,
                $"Reset your PhenyoSync password: {resetLink}\nThis link expires in 30 minutes.",
                CancellationToken.None);
        }

        public Task SendExpiryAlertEmailAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string reviewLink,
            CancellationToken cancellationToken = default)
        {
            var safeProduct = WebUtility.HtmlEncode(model.ProductName);
            var safeBatch = WebUtility.HtmlEncode(model.BatchCode);
            var safeSection = WebUtility.HtmlEncode(model.SectionName);
            var safeLevel = WebUtility.HtmlEncode(model.AlertLevel);
            var safeLink = WebUtility.HtmlEncode(reviewLink);
            var colour = model.AlertLevel == "Urgent" ? "#b91c1c" : "#a16207";
            var html = $"""
                <div style="font-family:Arial,sans-serif;line-height:1.5">
                  <h2 style="color:{colour}">{safeLevel}: Product batch expiry</h2>
                  <p><strong>Product:</strong> {safeProduct}</p>
                  <p><strong>Batch:</strong> {safeBatch}</p>
                  <p><strong>Section:</strong> {safeSection}</p>
                  <p><strong>Remaining:</strong> {model.QuantityRemainingKg:0.##} kg</p>
                  <p><strong>Packed:</strong> {model.PackedAtUtc:u}</p>
                  <p><strong>Effective expiry:</strong> {model.EffectiveExpiryAtUtc:u}</p>
                  <p><strong>Hours remaining:</strong> {Math.Max(0, model.RemainingHours):0.0}</p>
                  <p><a href="{safeLink}" style="background:#168044;color:#fff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:bold">Review batch</a></p>
                  <p>Sign in to PhenyoSync before approving a write-off or one-time two-day extension.</p>
                </div>
                """;

            var text = $"""
                {model.AlertLevel}: Product batch expiry
                Product: {model.ProductName}
                Batch: {model.BatchCode}
                Section: {model.SectionName}
                Remaining: {model.QuantityRemainingKg:0.##} kg
                Packed: {model.PackedAtUtc:u}
                Effective expiry: {model.EffectiveExpiryAtUtc:u}
                Hours remaining: {Math.Max(0, model.RemainingHours):0.0}
                Review: {reviewLink}
                """;

            return SendAsync(
                recipientEmails,
                $"{model.AlertLevel}: {model.ProductName} batch {model.BatchCode}",
                html,
                text,
                cancellationToken);
        }

        public Task SendExpiryDecisionConfirmationAsync(
            IReadOnlyCollection<string> recipientEmails,
            ExpiryEmailModel model,
            string decision,
            CancellationToken cancellationToken = default)
        {
            var safeDecision = WebUtility.HtmlEncode(decision);
            var safeProduct = WebUtility.HtmlEncode(model.ProductName);
            var safeBatch = WebUtility.HtmlEncode(model.BatchCode);
            var html = $"""
                <div style="font-family:Arial,sans-serif;line-height:1.5">
                  <h2 style="color:#146c3c">Expiry decision recorded</h2>
                  <p><strong>{safeDecision}</strong> was recorded for {safeProduct}, batch {safeBatch}.</p>
                  <p>Effective expiry: {model.EffectiveExpiryAtUtc:u}</p>
                </div>
                """;

            return SendAsync(
                recipientEmails,
                $"Expiry decision: {model.ProductName} batch {model.BatchCode}",
                html,
                $"{decision} was recorded for {model.ProductName}, batch {model.BatchCode}.",
                cancellationToken);
        }

        public Task SendCustomerOrderLinkEmailAsync(
            string recipientEmail,
            string customerName,
            string orderLink,
            DateTime expiresAtUtc,
            CancellationToken cancellationToken = default)
        {
            var safeCustomer = WebUtility.HtmlEncode(customerName);
            var safeLink = WebUtility.HtmlEncode(orderLink);
            var html = $"""
                <div style="font-family:Arial,sans-serif;line-height:1.5">
                  <h2 style="color:#146c3c">PhenyoSync customer order form</h2>
                  <p>Hello {safeCustomer},</p>
                  <p>Use the secure link below to submit your warehouse order.</p>
                  <p><a href="{safeLink}" style="background:#168044;color:#fff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:bold">Create Order</a></p>
                  <p>This one-time link expires at {expiresAtUtc:u}. If you were not expecting it, ignore this email.</p>
                </div>
                """;
            var text = $"""
                Hello {customerName},

                Use this one-time PhenyoSync order link: {orderLink}
                It expires at {expiresAtUtc:u}.
                """;
            return SendAsync(
                [recipientEmail],
                "Your secure PhenyoSync order form",
                html,
                text,
                cancellationToken);
        }

        public Task SendLoginOtpEmailAsync(
            string recipientEmail,
            string recipientName,
            string otp,
            DateTime expiresAtUtc,
            CancellationToken cancellationToken = default)
        {
            var safeName = WebUtility.HtmlEncode(recipientName);
            var safeOtp = WebUtility.HtmlEncode(otp);
            var html = $"""
                <div style="font-family:Arial,sans-serif;line-height:1.5">
                  <h2 style="color:#146c3c">PhenyoSync login verification</h2>
                  <p>Hello {safeName},</p>
                  <p>Enter this six-digit verification code to finish signing in:</p>
                  <p style="font-size:28px;letter-spacing:8px;font-weight:bold;color:#146c3c">{safeOtp}</p>
                  <p>The code expires at {expiresAtUtc:u} and can be used once.</p>
                  <p>If you did not try to sign in, reset your password and contact an administrator.</p>
                </div>
                """;
            return SendAsync(
                [recipientEmail],
                "Your PhenyoSync verification code",
                html,
                $"Hello {recipientName}, your PhenyoSync verification code is {otp}. It expires at {expiresAtUtc:u}.",
                cancellationToken);
        }

        public Task SendRecoveryCodeUsedNotificationAsync(
            string recipientEmail,
            string recipientName,
            DateTime usedAtUtc,
            CancellationToken cancellationToken = default)
        {
            var safeName = WebUtility.HtmlEncode(recipientName);
            var html = $"""
                <div style="font-family:Arial,sans-serif;line-height:1.5">
                  <h2 style="color:#146c3c">Recovery code used</h2>
                  <p>Hello {safeName},</p>
                  <p>A one-time recovery code was used to access your PhenyoSync account at {usedAtUtc:u}.</p>
                  <p>If this was not you, reset your password and contact an administrator immediately.</p>
                </div>
                """;
            return SendAsync(
                [recipientEmail],
                "PhenyoSync security notice",
                html,
                $"A PhenyoSync recovery code was used at {usedAtUtc:u}. If this was not you, reset your password.",
                cancellationToken);
        }

        private async Task SendAsync(
            IReadOnlyCollection<string> recipients,
            string subject,
            string htmlBody,
            string textBody,
            CancellationToken cancellationToken)
        {
            if (recipients.Count == 0)
            {
                return;
            }

            var settings = _configuration.GetSection("EmailSettings");
            var senderEmail = settings["SenderEmail"]
                ?? throw new InvalidOperationException("Sender email is not configured.");
            var smtpServer = settings["SmtpServer"]
                ?? throw new InvalidOperationException("SMTP server is not configured.");
            var username = settings["Username"]
                ?? throw new InvalidOperationException("SMTP username is not configured.");
            var password = settings["Password"]
                ?? throw new InvalidOperationException("SMTP password is not configured.");

            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(settings["SenderName"] ?? "PhenyoSync WMS", senderEmail));

            foreach (var address in recipients.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                message.To.Add(MailboxAddress.Parse(address));
            }

            message.Subject = subject;
            message.Body = new BodyBuilder { HtmlBody = htmlBody, TextBody = textBody }.ToMessageBody();

            using var client = new SmtpClient { Timeout = 15000 };
            var port = int.TryParse(settings["SmtpPort"], out var configuredPort)
                ? configuredPort
                : 587;

            await client.ConnectAsync(smtpServer, port, SecureSocketOptions.StartTls, cancellationToken);
            await client.AuthenticateAsync(username, password, cancellationToken);
            await client.SendAsync(message, cancellationToken);
            await client.DisconnectAsync(true, cancellationToken);
        }
    }
}
