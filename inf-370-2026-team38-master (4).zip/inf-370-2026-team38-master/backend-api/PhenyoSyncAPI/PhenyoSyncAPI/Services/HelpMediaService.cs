using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Help;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public sealed record HelpMediaReadResult(
    StoredFile StoredFile,
    FileStream Stream);

public interface IHelpMediaService
{
    Task<IReadOnlyList<HelpMediaDto>> ListAsync(
        bool includeUnpublished,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken);
    Task<HelpMediaDto> UploadAsync(
        IFormFile video,
        IFormFile? captions,
        UploadHelpMediaRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<HelpMediaDto> UpdateAsync(
        long id,
        UpdateHelpMediaRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<HelpMediaReadResult> OpenAsync(
        long id,
        bool captions,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken);
    Task RemoveAsync(
        long id,
        string reason,
        int userId,
        CancellationToken cancellationToken);
}

/// <summary>Validates protected help media and maintains its versioned metadata.</summary>
public sealed class HelpMediaService : IHelpMediaService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IProtectedFileStorage _storage;
    private readonly ISystemSettingProvider _settings;
    private readonly IAuditService _audit;

    public HelpMediaService(
        PhenyoSyncDbContext context,
        IProtectedFileStorage storage,
        ISystemSettingProvider settings,
        IAuditService audit)
    {
        _context = context;
        _storage = storage;
        _settings = settings;
        _audit = audit;
    }

    public async Task<IReadOnlyList<HelpMediaDto>> ListAsync(
        bool includeUnpublished,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken)
    {
        var query = _context.HelpMedia
            .AsNoTracking()
            .Include(item => item.HelpTopic)
            .Where(item => item.RemovedAtUtc == null);
        if (!includeUnpublished)
        {
            query = query.Where(item => item.IsPublished);
        }
        var rows = await query
            .OrderByDescending(item => item.IsFeatured)
            .ThenBy(item => item.SortOrder)
            .ThenByDescending(item => item.CreatedAtUtc)
            .ToListAsync(cancellationToken);
        return rows
            .Where(item =>
                includeUnpublished ||
                CanView(item, role, authenticated))
            .Select(Map)
            .ToList();
    }

    // Persist protected media only after type, size and metadata validation succeed.
    public async Task<HelpMediaDto> UploadAsync(
        IFormFile video,
        IFormFile? captions,
        UploadHelpMediaRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        if (request.HelpTopicId.HasValue &&
            !await _context.HelpTopics.AnyAsync(
                item => item.HelpTopicId == request.HelpTopicId.Value,
                cancellationToken))
        {
            throw new InvalidOperationException("Select a valid Help topic.");
        }
        var maximum = await _settings.GetIntAsync(
            SystemSettingKeys.FilesTrainingVideoMaximumMb,
            cancellationToken);
        StoredFile videoFile;
        StoredFile? captionFile = null;
        try
        {
            videoFile = await _storage.SaveTrainingVideoAsync(
                video,
                userId,
                maximum,
                cancellationToken);
            if (captions is not null)
            {
                captionFile = await _storage.SaveCaptionAsync(
                    captions,
                    userId,
                    cancellationToken);
            }
        }
        catch (ProtectedFileException exception)
        {
            throw new InvalidOperationException(exception.Message);
        }

        try
        {
            if (request.IsFeatured)
            {
                var featured = await _context.HelpMedia
                    .Where(item =>
                        item.IsFeatured &&
                        item.RemovedAtUtc == null)
                    .ToListAsync(cancellationToken);
                foreach (var item in featured)
                {
                    item.IsFeatured = false;
                }
            }
            _context.StoredFiles.Add(videoFile);
            if (captionFile is not null)
            {
                _context.StoredFiles.Add(captionFile);
            }
            var media = new HelpMedia
            {
                HelpTopicId = request.HelpTopicId,
                StoredFile = videoFile,
                CaptionStoredFile = captionFile,
                MediaType = "TrainingVideo",
                Title = request.Title.Trim(),
                Description = Clean(request.Description, 1000),
                Transcript = Clean(request.Transcript, 50000),
                IsFeatured = request.IsFeatured,
                IsPublished = request.IsPublished,
                SortOrder = request.SortOrder,
                CreatedAtUtc = DateTime.UtcNow,
                UploadedByUserId = userId
            };
            _context.HelpMedia.Add(media);
            await _context.SaveChangesAsync(cancellationToken);
            await AuditAsync(
                AuditActionTypes.Create,
                "UploadHelpTrainingMedia",
                media,
                userId,
                cancellationToken);
            return Map(media);
        }
        catch
        {
            await _storage.DeletePhysicalAsync(
                videoFile,
                CancellationToken.None);
            if (captionFile is not null)
            {
                await _storage.DeletePhysicalAsync(
                    captionFile,
                    CancellationToken.None);
            }
            throw;
        }
    }

    public async Task<HelpMediaDto> UpdateAsync(
        long id,
        UpdateHelpMediaRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        if (request.HelpTopicId.HasValue &&
            !await _context.HelpTopics.AnyAsync(
                item => item.HelpTopicId == request.HelpTopicId.Value,
                cancellationToken))
        {
            throw new InvalidOperationException("Select a valid Help topic.");
        }
        var media = await _context.HelpMedia
            .Include(item => item.CaptionStoredFile)
            .SingleOrDefaultAsync(
                item =>
                    item.HelpMediaId == id &&
                    item.RemovedAtUtc == null,
                cancellationToken)
            ?? throw new KeyNotFoundException("The training media was not found.");
        CheckVersion(media.RowVersion, request.RowVersion);
        if (request.IsFeatured)
        {
            var featured = await _context.HelpMedia
                .Where(item =>
                    item.HelpMediaId != id &&
                    item.IsFeatured &&
                    item.RemovedAtUtc == null)
                .ToListAsync(cancellationToken);
            foreach (var item in featured)
            {
                item.IsFeatured = false;
            }
        }
        media.HelpTopicId = request.HelpTopicId;
        media.Title = request.Title.Trim();
        media.Description = Clean(request.Description, 1000);
        media.Transcript = Clean(request.Transcript, 50000);
        media.IsFeatured = request.IsFeatured;
        media.IsPublished = request.IsPublished;
        media.SortOrder = request.SortOrder;
        media.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Update,
            "UpdateHelpTrainingMedia",
            media,
            userId,
            cancellationToken);
        return Map(media);
    }

    // Resolve the physical file through protected storage rather than returning a public path.
    public async Task<HelpMediaReadResult> OpenAsync(
        long id,
        bool captions,
        string? role,
        bool authenticated,
        CancellationToken cancellationToken)
    {
        var media = await _context.HelpMedia
            .AsNoTracking()
            .Include(item => item.HelpTopic)
            .Include(item => item.StoredFile)
            .Include(item => item.CaptionStoredFile)
            .SingleOrDefaultAsync(
                item =>
                    item.HelpMediaId == id &&
                    item.RemovedAtUtc == null,
                cancellationToken)
            ?? throw new KeyNotFoundException("The training media was not found.");
        if (!CanView(media, role, authenticated))
        {
            throw new UnauthorizedAccessException(
                "You do not have permission to view this training media.");
        }
        var stored = captions
            ? media.CaptionStoredFile
                ?? throw new KeyNotFoundException(
                    "Captions are not available for this video.")
            : media.StoredFile;
        if (stored.IsDeleted)
        {
            throw new KeyNotFoundException("The training media is unavailable.");
        }
        return new HelpMediaReadResult(stored, _storage.OpenRead(stored));
    }

    // Database state is updated before best-effort physical cleanup to keep authorization authoritative.
    public async Task RemoveAsync(
        long id,
        string reason,
        int userId,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(reason) || reason.Trim().Length < 5)
        {
            throw new InvalidOperationException(
                "Provide a meaningful removal reason.");
        }
        var media = await _context.HelpMedia.SingleOrDefaultAsync(
            item =>
                item.HelpMediaId == id &&
                item.RemovedAtUtc == null,
            cancellationToken)
            ?? throw new KeyNotFoundException("The training media was not found.");
        media.RemovedAtUtc = DateTime.UtcNow;
        media.RemovedByUserId = userId;
        media.RemovalReason = reason.Trim();
        media.IsPublished = false;
        media.IsFeatured = false;
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.SoftDelete,
            "RemoveHelpTrainingMedia",
            media,
            userId,
            cancellationToken);
    }

    private static bool CanView(
        HelpMedia media,
        string? role,
        bool authenticated)
    {
        if (!media.IsPublished || media.RemovedAtUtc is not null)
        {
            return false;
        }
        if (media.HelpTopic is null)
        {
            return authenticated;
        }
        if (media.HelpTopic.IsPublic)
        {
            return true;
        }
        if (!authenticated || string.IsNullOrWhiteSpace(role))
        {
            return false;
        }
        return string.IsNullOrWhiteSpace(media.HelpTopic.AudienceRolesCsv) ||
            media.HelpTopic.AudienceRolesCsv
                .Split(
                    ',',
                    StringSplitOptions.RemoveEmptyEntries |
                    StringSplitOptions.TrimEntries)
                .Contains(role, StringComparer.OrdinalIgnoreCase);
    }

    private async Task AuditAsync(
        string action,
        string operation,
        HelpMedia media,
        int userId,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = "Help",
            OperationName = operation,
            Description = "Protected Help training media was managed.",
            EntityType = nameof(HelpMedia),
            EntityId = media.HelpMediaId.ToString(),
            EntityDisplay = media.Title,
            UserId = userId,
            SafeDetails = new Dictionary<string, object?>
            {
                ["IsFeatured"] = media.IsFeatured,
                ["IsPublished"] = media.IsPublished,
                ["HasCaptions"] = media.CaptionStoredFileId.HasValue
            }
        }, cancellationToken);

    private static HelpMediaDto Map(HelpMedia item) =>
        new(
            item.HelpMediaId,
            item.HelpTopicId,
            item.Title,
            item.Description,
            item.Transcript,
            item.IsFeatured,
            item.IsPublished,
            item.SortOrder,
            item.CreatedAtUtc,
            item.CaptionStoredFileId.HasValue,
            item.RowVersion is null
                ? string.Empty
                : Convert.ToBase64String(item.RowVersion));

    private static string? Clean(string? value, int maximum)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }
        var clean = value.Trim()
            .Replace("<script", "&lt;script", StringComparison.OrdinalIgnoreCase);
        return clean.Length <= maximum ? clean : clean[..maximum];
    }

    private static void CheckVersion(byte[]? actual, string? supplied)
    {
        if (actual is null || string.IsNullOrWhiteSpace(supplied))
        {
            return;
        }
        byte[] expected;
        try
        {
            expected = Convert.FromBase64String(supplied);
        }
        catch (FormatException)
        {
            throw new InvalidOperationException("The row version is invalid.");
        }
        if (!actual.SequenceEqual(expected))
        {
            throw new DbUpdateConcurrencyException(
                "The training media changed. Refresh and try again.");
        }
    }
}
