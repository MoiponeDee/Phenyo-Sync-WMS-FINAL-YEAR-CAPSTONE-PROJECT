namespace PhenyoSyncAPI.Services;

public sealed class PricingException : Exception
{
    public int StatusCode { get; }
    public string Code { get; }

    public PricingException(
        int statusCode,
        string message,
        string code = "PRICING_ERROR")
        : base(message)
    {
        StatusCode = statusCode;
        Code = code;
    }
}
