using System.Data;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IProductHierarchyService
{
    Task<ProductHierarchyResponseDto> GetAsync(
        string? search,
        bool includeInactive,
        int? categoryId,
        int? typeId,
        CancellationToken cancellationToken);

    Task<int> CreateCategoryAsync(
        SaveHierarchyCategoryRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task UpdateCategoryAsync(
        int categoryId,
        SaveHierarchyCategoryRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task DeleteCategoryAsync(
        int categoryId,
        DeleteHierarchyNodeRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task<int> CreateTypeAsync(
        int categoryId,
        SaveHierarchyTypeRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task UpdateTypeAsync(
        int typeId,
        SaveHierarchyTypeRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task MoveTypeAsync(
        int productCategoryTypeId,
        MoveHierarchyTypeRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task DeleteTypeAsync(
        int typeId,
        DeleteHierarchyNodeRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task<int> CreateProductAsync(
        int categoryId,
        int typeId,
        CreateHierarchyProductRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task ReclassifyProductAsync(
        int productId,
        ReclassifyHierarchyProductRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task ChangeProductStatusAsync(
        int productId,
        ChangeHierarchyStatusRequest request,
        int userId,
        CancellationToken cancellationToken);
}

/// <summary>
/// Maintains the Category → Type → Product classification graph and blocks
/// destructive changes while active relationships still depend on a node.
/// </summary>
public sealed class ProductHierarchyService : IProductHierarchyService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _audit;

    public ProductHierarchyService(
        PhenyoSyncDbContext context,
        IAuditService audit)
    {
        _context = context;
        _audit = audit;
    }

    public async Task<ProductHierarchyResponseDto> GetAsync(
        string? search,
        bool includeInactive,
        int? categoryId,
        int? typeId,
        CancellationToken cancellationToken)
    {
        // Read the hierarchy as one presentation model so the UI does not need
        // to reconstruct category/type/product relationships from loose lists.
        if (categoryId is < 1 || typeId is < 1)
        {
            throw new PhaseBException(400, "Hierarchy filter IDs must be greater than zero.");
        }

        var term = search?.Trim();
        var associations = _context.ProductCategoryTypes
            .AsNoTracking()
            .Include(item => item.ProductCategory)
            .Include(item => item.ProductType)
            .AsQueryable();

        if (!includeInactive)
        {
            associations = associations.Where(item =>
                item.ProductCategory.Status == ProductStatuses.Active &&
                item.ProductType.Status == ProductStatuses.Active);
        }
        if (categoryId.HasValue)
            associations = associations.Where(item => item.ProductCategoryId == categoryId);
        if (typeId.HasValue)
            associations = associations.Where(item => item.ProductTypeId == typeId);
        if (!string.IsNullOrWhiteSpace(term))
        {
            associations = associations.Where(item =>
                item.ProductCategory.ProductCategoryName.Contains(term) ||
                item.ProductType.ProductTypeName.Contains(term) ||
                _context.Products.Any(product =>
                    product.ProductCategoryId == item.ProductCategoryId &&
                    product.ProductTypeId == item.ProductTypeId &&
                    (product.ProductName.Contains(term) ||
                     (product.QRCodeValue != null && product.QRCodeValue.Contains(term)))));
        }

        var links = await associations
            .OrderBy(item => item.ProductCategory.ProductCategoryName)
            .ThenBy(item => item.ProductType.ProductTypeName)
            .ToListAsync(cancellationToken);
        var categoryIds = links.Select(item => item.ProductCategoryId).Distinct().ToArray();
        var typeIds = links.Select(item => item.ProductTypeId).Distinct().ToArray();

        var products = _context.Products.AsNoTracking()
            .Where(product =>
                categoryIds.Contains(product.ProductCategoryId) &&
                typeIds.Contains(product.ProductTypeId));
        if (!includeInactive)
            products = products.Where(product => product.Status == ProductStatuses.Active);
        if (!string.IsNullOrWhiteSpace(term))
        {
            products = products.Where(product =>
                product.ProductName.Contains(term) ||
                (product.QRCodeValue != null && product.QRCodeValue.Contains(term)) ||
                product.ProductType!.ProductTypeName.Contains(term) ||
                product.ProductCategory!.ProductCategoryName.Contains(term));
        }

        var currentTime = DateTime.UtcNow;
        var productRows = await products
            .Select(product => new ProductHierarchyProductDto
            {
                ProductId = product.ProductId,
                ProductCode = product.QRCodeValue ?? string.Empty,
                Name = product.ProductName,
                Size = product.Size,
                ShelfLifeDays = product.ShelfLifeDays,
                Status = product.Status,
                CurrentSellingPrice = product.ProductPrices
                    .Where(price =>
                        !price.IsDeleted &&
                        price.EffectiveFromUtc <= currentTime &&
                        (price.EffectiveToUtc == null ||
                         price.EffectiveToUtc > currentTime))
                    .Select(price => (decimal?)price.SellingPrice)
                    .FirstOrDefault(),
                CurrentPriceBasis = product.ProductPrices
                    .Where(price =>
                        !price.IsDeleted &&
                        price.EffectiveFromUtc <= currentTime &&
                        (price.EffectiveToUtc == null || price.EffectiveToUtc > currentTime))
                    .OrderByDescending(price => price.EffectiveFromUtc)
                    .Select(price => price.PriceBasis)
                    .FirstOrDefault() ?? ProductPriceBases.PerKilogram,
                SellingUnit = product.SellingUnit,
                KilogramsPerUnit = product.KilogramsPerUnit,
                IsVariableWeight = product.IsVariableWeight,
                RowVersion = product.RowVersion == null
                    ? string.Empty
                    : Convert.ToBase64String(product.RowVersion)
            })
            .OrderBy(product => product.Name)
            .ThenBy(product => product.Size)
            .ToListAsync(cancellationToken);
        foreach (var product in productRows)
        {
            if (string.IsNullOrWhiteSpace(product.ProductCode))
                product.ProductCode = $"PRODUCT-{product.ProductId:D6}";
        }

        var categories = links
            .GroupBy(item => item.ProductCategoryId)
            .Select(group =>
            {
                var category = group.First().ProductCategory;
                return new ProductHierarchyCategoryDto
                {
                    ProductCategoryId = category.ProductCategoryId,
                    Name = category.ProductCategoryName,
                    Description = category.Description,
                    Status = category.Status,
                    RowVersion = Encode(category.RowVersion),
                    Types = group.Select(link => new ProductHierarchyTypeDto
                    {
                        ProductCategoryTypeId = link.ProductCategoryTypeId,
                        ProductTypeId = link.ProductTypeId,
                        Name = link.ProductType.ProductTypeName,
                        Description = link.ProductType.Description,
                        Status = link.ProductType.Status,
                        RowVersion = Encode(link.ProductType.RowVersion),
                        Products = []
                    }).ToList()
                };
            })
            .ToList();

        // Replace the small per-node predicate above with an in-memory key map.
        var productKeys = await _context.Products.AsNoTracking()
            .Where(product =>
                categoryIds.Contains(product.ProductCategoryId) &&
                typeIds.Contains(product.ProductTypeId))
            .Select(product => new
            {
                product.ProductId,
                product.ProductCategoryId,
                product.ProductTypeId
            })
            .ToListAsync(cancellationToken);
        var keyMap = productKeys.ToDictionary(item => item.ProductId);
        foreach (var category in categories)
        {
            foreach (var type in category.Types)
            {
                type.Products = productRows.Where(product =>
                    keyMap.TryGetValue(product.ProductId, out var key) &&
                    key.ProductCategoryId == category.ProductCategoryId &&
                    key.ProductTypeId == type.ProductTypeId).ToList();
            }
        }

        return new ProductHierarchyResponseDto
        {
            Categories = categories,
            CategoryCount = categories.Count,
            TypeCount = categories.Sum(item => item.Types.Count),
            ProductCount = categories.Sum(item =>
                item.Types.Sum(type => type.Products.Count))
        };
    }

    public async Task<int> CreateCategoryAsync(
        SaveHierarchyCategoryRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var name = CleanRequired(request.Name);
        if (await _context.ProductCategories.AnyAsync(
                item => item.ProductCategoryName.ToUpper() == name.ToUpper(),
                cancellationToken))
        {
            throw new PhaseBException(409, "A product category with this name already exists.");
        }
        var category = new ProductCategory
        {
            ProductCategoryName = name,
            Description = Clean(request.Description),
            Status = request.Status,
            CreatedAt = DateTime.UtcNow
        };
        _context.ProductCategories.Add(category);
        await _context.SaveChangesAsync(cancellationToken);
        await RecordAsync("Create category", "ProductCategory", category.ProductCategoryId,
            name, userId, null, cancellationToken);
        return category.ProductCategoryId;
    }

    public async Task UpdateCategoryAsync(
        int categoryId,
        SaveHierarchyCategoryRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var category = await _context.ProductCategories.FindAsync([categoryId], cancellationToken)
            ?? throw new PhaseBException(404, "Product category not found.");
        ValidateVersion(category.RowVersion, request.RowVersion);
        var name = CleanRequired(request.Name);
        if (await _context.ProductCategories.AnyAsync(
                item => item.ProductCategoryId != categoryId &&
                        item.ProductCategoryName.ToUpper() == name.ToUpper(),
                cancellationToken))
        {
            throw new PhaseBException(409, "A product category with this name already exists.");
        }
        category.ProductCategoryName = name;
        category.Description = Clean(request.Description);
        category.Status = request.Status;
        category.UpdatedAt = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await RecordAsync("Update category", "ProductCategory", categoryId, name, userId, null,
            cancellationToken);
    }

    public async Task DeleteCategoryAsync(
        int categoryId,
        DeleteHierarchyNodeRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var category = await _context.ProductCategories.FindAsync([categoryId], cancellationToken)
            ?? throw new PhaseBException(404, "Product category not found.");
        ValidateVersion(category.RowVersion, request.RowVersion);
        if (await _context.Products.AnyAsync(
                item => item.ProductCategoryId == categoryId,
                cancellationToken) ||
            await _context.ProductCategoryTypes.AnyAsync(
                item => item.ProductCategoryId == categoryId,
                cancellationToken))
        {
            throw new PhaseBException(
                409,
                "This category has dependent hierarchy records. Deactivate it instead.");
        }
        _context.ProductCategories.Remove(category);
        await SaveConcurrencyAsync(cancellationToken);
        await RecordAsync("Delete category", "ProductCategory", categoryId,
            category.ProductCategoryName, userId, request.Reason, cancellationToken);
    }

    public async Task<int> CreateTypeAsync(
        int categoryId,
        SaveHierarchyTypeRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        if (!await _context.ProductCategories.AnyAsync(
                item => item.ProductCategoryId == categoryId &&
                        item.Status == ProductStatuses.Active,
                cancellationToken))
        {
            throw new PhaseBException(400, "Select an active product category.");
        }
        var name = CleanRequired(request.Name);
        if (await _context.ProductTypes.AnyAsync(
                item => item.ProductTypeName.ToUpper() == name.ToUpper(),
                cancellationToken))
        {
            throw new PhaseBException(409, "A product type with this name already exists.");
        }

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var type = new ProductType
        {
            ProductTypeName = name,
            Description = Clean(request.Description),
            Status = request.Status,
            CreatedAt = DateTime.UtcNow
        };
        _context.ProductTypes.Add(type);
        await _context.SaveChangesAsync(cancellationToken);
        _context.ProductCategoryTypes.Add(new ProductCategoryType
        {
            ProductCategoryId = categoryId,
            ProductTypeId = type.ProductTypeId,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedByUserId = userId
        });
        await _context.SaveChangesAsync(cancellationToken);
        await RecordAsync("Create product type", "ProductType", type.ProductTypeId,
            name, userId, null, cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return type.ProductTypeId;
    }

    public async Task UpdateTypeAsync(
        int typeId,
        SaveHierarchyTypeRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var type = await _context.ProductTypes.FindAsync([typeId], cancellationToken)
            ?? throw new PhaseBException(404, "Product type not found.");
        ValidateVersion(type.RowVersion, request.RowVersion);
        var name = CleanRequired(request.Name);
        if (await _context.ProductTypes.AnyAsync(
                item => item.ProductTypeId != typeId &&
                        item.ProductTypeName.ToUpper() == name.ToUpper(),
                cancellationToken))
        {
            throw new PhaseBException(409, "A product type with this name already exists.");
        }
        type.ProductTypeName = name;
        type.Description = Clean(request.Description);
        type.Status = request.Status;
        type.UpdatedAt = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await RecordAsync("Update product type", "ProductType", typeId, name, userId, null,
            cancellationToken);
    }

    public async Task MoveTypeAsync(
        int productCategoryTypeId,
        MoveHierarchyTypeRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Moving an association changes classification links, not the Product
        // or ProductType identity. Row versions protect both source and target.
        var link = await _context.ProductCategoryTypes
            .Include(item => item.ProductType)
            .FirstOrDefaultAsync(
                item => item.ProductCategoryTypeId == productCategoryTypeId,
                cancellationToken)
            ?? throw new PhaseBException(404, "Hierarchy type association not found.");
        ValidateVersion(link.RowVersion, request.RowVersion);
        if (!await _context.ProductCategories.AnyAsync(
                item => item.ProductCategoryId == request.TargetCategoryId &&
                        item.Status == ProductStatuses.Active,
                cancellationToken))
        {
            throw new PhaseBException(400, "Select an active target category.");
        }
        if (await _context.Products.AnyAsync(
                item => item.ProductTypeId == link.ProductTypeId &&
                        item.ProductCategoryId == link.ProductCategoryId,
                cancellationToken))
        {
            throw new PhaseBException(
                409,
                "This type still has products in its current category. Reclassify them before moving the type.");
        }
        if (await _context.ProductCategoryTypes.AnyAsync(
                item => item.ProductCategoryId == request.TargetCategoryId &&
                        item.ProductTypeId == link.ProductTypeId,
                cancellationToken))
        {
            throw new PhaseBException(409, "This type is already linked to the target category.");
        }
        var previous = link.ProductCategoryId;
        link.ProductCategoryId = request.TargetCategoryId;
        await SaveConcurrencyAsync(cancellationToken);
        await RecordAsync("Move product type", "ProductCategoryType",
            productCategoryTypeId, link.ProductType.ProductTypeName, userId, request.Reason,
            cancellationToken, new Dictionary<string, object?>
            {
                ["previousCategoryId"] = previous,
                ["targetCategoryId"] = request.TargetCategoryId
            });
    }

    public async Task DeleteTypeAsync(
        int typeId,
        DeleteHierarchyNodeRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var type = await _context.ProductTypes.FindAsync([typeId], cancellationToken)
            ?? throw new PhaseBException(404, "Product type not found.");
        ValidateVersion(type.RowVersion, request.RowVersion);
        if (await _context.Products.AnyAsync(
                item => item.ProductTypeId == typeId,
                cancellationToken))
        {
            throw new PhaseBException(
                409,
                "This product type is in use. Deactivate it instead.");
        }
        await using var transaction = await _context.Database.BeginTransactionAsync(
            cancellationToken);
        var links = await _context.ProductCategoryTypes
            .Where(item => item.ProductTypeId == typeId)
            .ToListAsync(cancellationToken);
        _context.ProductCategoryTypes.RemoveRange(links);
        _context.ProductTypes.Remove(type);
        await SaveConcurrencyAsync(cancellationToken);
        await RecordAsync("Delete product type", "ProductType", typeId,
            type.ProductTypeName, userId, request.Reason, cancellationToken);
        await transaction.CommitAsync(cancellationToken);
    }

    public async Task<int> CreateProductAsync(
        int categoryId,
        int typeId,
        CreateHierarchyProductRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        if (!await _context.ProductCategoryTypes.AnyAsync(
                item => item.ProductCategoryId == categoryId &&
                        item.ProductTypeId == typeId,
                cancellationToken))
        {
            throw new PhaseBException(400, "The selected category and type are not linked.");
        }
        var name = CleanRequired(request.ProductName);
        var size = CleanRequired(request.Size);
        var sellingUnit = CleanRequired(request.SellingUnit);
        if (request.InitialSellingPrice.HasValue && request.InitialSellingPrice.Value <= 0)
            throw new PhaseBException(400, "Selling price must be greater than zero when supplied.");
        if (request.InitialSellingPrice.HasValue &&
            string.IsNullOrWhiteSpace(request.PriceReason))
            throw new PhaseBException(400, "Enter a reason when adding an initial selling price.");
        if (!ProductPriceBases.IsValid(request.InitialPriceBasis))
            throw new PhaseBException(400, "Price basis must be PerKilogram or PerSellableUnit.");
        if (!request.IsVariableWeight &&
            request.InitialPriceBasis == ProductPriceBases.PerKilogram &&
            request.KilogramsPerUnit is null or <= 0)
            throw new PhaseBException(
                400,
                "Enter kilograms per unit for a packaged product priced per kilogram, or price it per sellable unit.");
        if (request.IsVariableWeight && !sellingUnit.Equals("kg", StringComparison.OrdinalIgnoreCase))
            throw new PhaseBException(400, "Variable-weight products must use kg as the selling unit.");
        if (await _context.Products.AnyAsync(item =>
                item.ProductCategoryId == categoryId &&
                item.ProductTypeId == typeId &&
                item.ProductName.ToUpper() == name.ToUpper() &&
                item.Size.ToUpper() == size.ToUpper(),
                cancellationToken))
        {
            throw new PhaseBException(409, "This product already exists in the selected hierarchy.");
        }
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var now = DateTime.UtcNow;
        var product = new Product
        {
            ProductCategoryId = categoryId,
            ProductTypeId = typeId,
            ProductName = name,
            Size = size,
            ShelfLifeDays = request.ShelfLifeDays,
            SellingPricePerKg = request.InitialSellingPrice ?? 0,
            SellingUnit = sellingUnit,
            KilogramsPerUnit = request.IsVariableWeight ? null : request.KilogramsPerUnit,
            IsVariableWeight = request.IsVariableWeight,
            Status = request.Status,
            CreatedAt = now
        };
        _context.Products.Add(product);
        await _context.SaveChangesAsync(cancellationToken);
        product.QRCodeValue = $"PRODUCT-{product.ProductId:D6}";
        if (request.InitialSellingPrice.HasValue)
        {
            _context.ProductPrices.Add(new ProductPrice
            {
                ProductId = product.ProductId,
                SellingPrice = request.InitialSellingPrice.Value,
                PriceBasis = request.InitialPriceBasis,
                EffectiveFromUtc = now,
                IsCurrent = true,
                CreatedAtUtc = now,
                CreatedByUserId = userId,
                ChangeReason = CleanRequired(request.PriceReason!)
            });
        }
        await _context.SaveChangesAsync(cancellationToken);
        await RecordAsync("Create hierarchy product", "Product", product.ProductId,
            product.ProductName, userId, null, cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return product.ProductId;
    }

    public async Task ReclassifyProductAsync(
        int productId,
        ReclassifyHierarchyProductRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var product = await _context.Products.FindAsync([productId], cancellationToken)
            ?? throw new PhaseBException(404, "Product not found.");
        ValidateVersion(product.RowVersion, request.RowVersion);
        if (!await _context.ProductCategoryTypes.AnyAsync(
                item => item.ProductCategoryId == request.ProductCategoryId &&
                        item.ProductTypeId == request.ProductTypeId,
                cancellationToken))
        {
            throw new PhaseBException(400, "The target category and type are not linked.");
        }
        var duplicate = await _context.Products.AnyAsync(item =>
            item.ProductId != productId &&
            item.ProductCategoryId == request.ProductCategoryId &&
            item.ProductTypeId == request.ProductTypeId &&
            item.ProductName == product.ProductName &&
            item.Size == product.Size,
            cancellationToken);
        if (duplicate)
            throw new PhaseBException(409, "Reclassification would create a duplicate product.");
        var previousCategory = product.ProductCategoryId;
        var previousType = product.ProductTypeId;
        product.ProductCategoryId = request.ProductCategoryId;
        product.ProductTypeId = request.ProductTypeId;
        product.UpdatedAt = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await RecordAsync("Reclassify product", "Product", productId, product.ProductName,
            userId, request.Reason, cancellationToken, new Dictionary<string, object?>
            {
                ["previousCategoryId"] = previousCategory,
                ["previousTypeId"] = previousType,
                ["newCategoryId"] = request.ProductCategoryId,
                ["newTypeId"] = request.ProductTypeId
            });
    }

    public async Task ChangeProductStatusAsync(
        int productId,
        ChangeHierarchyStatusRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var product = await _context.Products.FindAsync([productId], cancellationToken)
            ?? throw new PhaseBException(404, "Product not found.");
        ValidateVersion(product.RowVersion, request.RowVersion);
        product.Status = request.Status;
        product.UpdatedAt = DateTime.UtcNow;
        await SaveConcurrencyAsync(cancellationToken);
        await RecordAsync("Change product status", "Product", productId,
            product.ProductName, userId, request.Reason, cancellationToken,
            new Dictionary<string, object?> { ["status"] = request.Status });
    }

    private async Task RecordAsync(
        string operation,
        string entityType,
        object entityId,
        string display,
        int userId,
        string? reason,
        CancellationToken cancellationToken,
        IReadOnlyDictionary<string, object?>? details = null)
    {
        var safe = new Dictionary<string, object?>(details ?? new Dictionary<string, object?>());
        if (!string.IsNullOrWhiteSpace(reason))
            safe["reason"] = reason.Trim();
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = operation.StartsWith("Delete", StringComparison.Ordinal)
                ? AuditActionTypes.Delete
                : operation.StartsWith("Create", StringComparison.Ordinal)
                    ? AuditActionTypes.Create
                    : AuditActionTypes.Update,
            SystemModule = AuditModules.ProductHierarchy,
            OperationName = operation,
            Description = $"{operation}: {display}.",
            EntityType = entityType,
            EntityId = entityId.ToString(),
            EntityDisplay = display,
            UserId = userId,
            SafeDetails = safe
        }, cancellationToken);
    }

    private async Task SaveConcurrencyAsync(CancellationToken cancellationToken)
    {
        try
        {
            await _context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new PhaseBException(
                409,
                "This hierarchy record changed since it was loaded. Reload the tree and try again.");
        }
    }

    private static void ValidateVersion(byte[]? current, string? supplied)
    {
        if (current is null || string.IsNullOrWhiteSpace(supplied))
            return;
        byte[] expected;
        try
        {
            expected = Convert.FromBase64String(supplied);
        }
        catch (FormatException)
        {
            throw new PhaseBException(400, "The hierarchy concurrency token is invalid.");
        }
        if (!CryptographicOperations.FixedTimeEquals(current, expected))
        {
            throw new PhaseBException(
                409,
                "This hierarchy record changed since it was loaded. Reload the tree and try again.");
        }
    }

    private static string Encode(byte[]? value) =>
        value is null ? string.Empty : Convert.ToBase64String(value);

    private static string CleanRequired(string value) => value.Trim();
    private static string? Clean(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
