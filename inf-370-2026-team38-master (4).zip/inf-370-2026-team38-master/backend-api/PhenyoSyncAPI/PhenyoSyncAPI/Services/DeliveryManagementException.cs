namespace PhenyoSyncAPI.Services;

public sealed class DeliveryManagementException : Exception
{
    public int StatusCode { get; }
    public object? Details { get; }

    public DeliveryManagementException(int statusCode, string message, object? details = null)
        : base(message)
    {
        StatusCode = statusCode;
        Details = details;
    }
}
