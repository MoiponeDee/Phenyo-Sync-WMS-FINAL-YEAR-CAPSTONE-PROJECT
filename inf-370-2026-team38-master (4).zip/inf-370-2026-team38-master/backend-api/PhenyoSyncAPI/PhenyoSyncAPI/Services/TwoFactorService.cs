using System.Data;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Auth;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface ITwoFactorService
{
    Task<TwoFactorChallengeResponse> CreateChallengeAsync(
        User user,
        string correlationId,
        string? ipAddress,
        string? userAgent,
        CancellationToken cancellationToken);

    Task<TwoFactorChallengeResponse> ResendAsync(
        string challengeToken,
        CancellationToken cancellationToken);

    Task<TwoFactorVerificationResult> VerifyOtpAsync(
        string challengeToken,
        string otp,
        bool trustDevice,
        string? deviceName,
        string? userAgent,
        CancellationToken cancellationToken);

    Task<TwoFactorVerificationResult> VerifyRecoveryCodeAsync(
        string challengeToken,
        string recoveryCode,
        bool trustDevice,
        string? deviceName,
        string? userAgent,
        CancellationToken cancellationToken);

    Task<TrustedLoginResult?> ValidateTrustedDeviceAsync(
        int userId,
        int securityVersion,
        string rawToken,
        string? userAgent,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<TrustedDeviceDto>> GetTrustedDevicesAsync(
        int userId,
        string? currentRawToken,
        CancellationToken cancellationToken);

    Task RevokeTrustedDeviceAsync(
        int userId,
        long trustedDeviceId,
        string reason,
        CancellationToken cancellationToken);

    Task RevokeAllTrustedDevicesAsync(
        int userId,
        string reason,
        CancellationToken cancellationToken);

    Task<(IReadOnlyList<string> Codes, RecoveryCodeStatusDto Status)>
        RegenerateRecoveryCodesAsync(
            User user,
            CancellationToken cancellationToken);

    Task<RecoveryCodeStatusDto> GetRecoveryCodeStatusAsync(
        int userId,
        CancellationToken cancellationToken);
}

public sealed record TwoFactorVerificationResult(
    User User,
    string? TrustedDeviceToken,
    DateTime? TrustedDeviceExpiresAtUtc,
    IReadOnlyList<string>? RecoveryCodes);

public sealed record TrustedLoginResult(
    string RotatedToken,
    DateTime ExpiresAtUtc);

public sealed class TwoFactorException : Exception
{
    public TwoFactorException(int statusCode, string message, string code)
        : base(message)
    {
        StatusCode = statusCode;
        Code = code;
    }

    public int StatusCode { get; }
    public string Code { get; }
}

/// <summary>Owns OTP, recovery-code and trusted-device verification with hashed, expiring secrets.</summary>
public sealed class TwoFactorService : ITwoFactorService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly ISystemSettingProvider _settings;
    private readonly IEmailService _email;
    private readonly IAuditService _audit;

    public TwoFactorService(
        PhenyoSyncDbContext context,
        ISystemSettingProvider settings,
        IEmailService email,
        IAuditService audit)
    {
        _context = context;
        _settings = settings;
        _email = email;
        _audit = audit;
    }

    // Persist the hashed challenge before sending an OTP so verification is independent of email state.
    public async Task<TwoFactorChallengeResponse> CreateChallengeAsync(
        User user,
        string correlationId,
        string? ipAddress,
        string? userAgent,
        CancellationToken cancellationToken)
    {
        var now = DateTime.UtcNow;
        var lifetime = await _settings.GetIntAsync(
            SystemSettingKeys.SecurityOtpLifetimeMinutes,
            cancellationToken);
        var maximumAttempts = await _settings.GetIntAsync(
            SystemSettingKeys.SecurityOtpMaximumAttempts,
            cancellationToken);
        var resendDelay = await _settings.GetIntAsync(
            SystemSettingKeys.SecurityOtpResendDelaySeconds,
            cancellationToken);

        var active = await _context.UserOtpChallenges
            .Where(item =>
                item.UserId == user.UserId &&
                item.Purpose == "Login" &&
                item.ConsumedAtUtc == null &&
                item.RevokedAtUtc == null)
            .ToListAsync(cancellationToken);
        foreach (var old in active)
        {
            old.RevokedAtUtc = now;
            old.FailureReason = "Replaced by a new login challenge.";
        }

        var rawChallenge = Base64Url(RandomNumberGenerator.GetBytes(32));
        var otp = RandomNumberGenerator.GetInt32(0, 1_000_000)
            .ToString("D6");
        var challenge = new UserOtpChallenge
        {
            UserId = user.UserId,
            ChallengeTokenHash = Sha256(rawChallenge),
            OtpHash = SaltedHash(otp),
            Purpose = "Login",
            CreatedAtUtc = now,
            ExpiresAtUtc = now.AddMinutes(lifetime),
            LastSentAtUtc = now,
            MaximumAttempts = maximumAttempts,
            IpAddressSummary = Bounded(ipAddress, 64),
            UserAgentSummary = Bounded(userAgent, 256),
            CorrelationId = Bounded(correlationId, 64) ?? Guid.NewGuid().ToString("N"),
            SecurityVersionSnapshot = user.SecurityVersion
        };
        _context.UserOtpChallenges.Add(challenge);
        await _context.SaveChangesAsync(cancellationToken);

        try
        {
            await _email.SendLoginOtpEmailAsync(
                user.Email,
                $"{user.FirstName} {user.LastName}".Trim(),
                otp,
                challenge.ExpiresAtUtc,
                cancellationToken);
        }
        catch
        {
            challenge.RevokedAtUtc = DateTime.UtcNow;
            challenge.FailureReason = "Verification email delivery failed.";
            await _context.SaveChangesAsync(cancellationToken);
            await AuditAsync(
                AuditActionTypes.SendEmail,
                "SendLoginOtp",
                user,
                false,
                "Verification email delivery failed.",
                cancellationToken);
            return ChallengeResponse(
                rawChallenge,
                user.Email,
                challenge,
                resendDelay,
                true,
                "The verification email could not be sent. Use a saved recovery code or sign in again to retry.");
        }

        await AuditAsync(
            AuditActionTypes.SendEmail,
            "SendLoginOtp",
            user,
            true,
            null,
            cancellationToken);
        return ChallengeResponse(
            rawChallenge,
            user.Email,
            challenge,
            resendDelay);
    }

    // Resends are rate-limited and rotate the code without extending attempts indefinitely.
    public async Task<TwoFactorChallengeResponse> ResendAsync(
        string challengeToken,
        CancellationToken cancellationToken)
    {
        var challenge = await LoadActiveChallengeAsync(
            challengeToken,
            false,
            cancellationToken);
        var now = DateTime.UtcNow;
        var delay = await _settings.GetIntAsync(
            SystemSettingKeys.SecurityOtpResendDelaySeconds,
            cancellationToken);
        var elapsed = (int)(now - challenge.LastSentAtUtc).TotalSeconds;
        if (elapsed < delay)
        {
            throw new TwoFactorException(
                429,
                $"Wait {delay - Math.Max(0, elapsed)} seconds before requesting another code.",
                "OTP_RESEND_DELAY");
        }

        var maximumPerHour = await _settings.GetIntAsync(
            SystemSettingKeys.SecurityOtpMaximumResendsPerHour,
            cancellationToken);
        var sentInHour = await _context.UserOtpChallenges
            .Where(item =>
                item.UserId == challenge.UserId &&
                item.CreatedAtUtc >= now.AddHours(-1))
            .SumAsync(item => item.ResendCount, cancellationToken);
        if (sentInHour >= maximumPerHour)
        {
            throw new TwoFactorException(
                429,
                "The hourly verification-email limit was reached. Try again later or use a recovery code.",
                "OTP_RESEND_LIMIT");
        }

        var lifetime = await _settings.GetIntAsync(
            SystemSettingKeys.SecurityOtpLifetimeMinutes,
            cancellationToken);
        var otp = RandomNumberGenerator.GetInt32(0, 1_000_000)
            .ToString("D6");
        challenge.OtpHash = SaltedHash(otp);
        challenge.ExpiresAtUtc = now.AddMinutes(lifetime);
        challenge.LastSentAtUtc = now;
        challenge.ResendCount++;
        challenge.AttemptCount = 0;
        await _context.SaveChangesAsync(cancellationToken);

        try
        {
            await _email.SendLoginOtpEmailAsync(
                challenge.User.Email,
                $"{challenge.User.FirstName} {challenge.User.LastName}".Trim(),
                otp,
                challenge.ExpiresAtUtc,
                cancellationToken);
        }
        catch
        {
            challenge.RevokedAtUtc = DateTime.UtcNow;
            challenge.FailureReason = "Verification email delivery failed.";
            await _context.SaveChangesAsync(cancellationToken);
            throw new TwoFactorException(
                503,
                "The verification email could not be sent. Use a saved recovery code or try again later.",
                "OTP_EMAIL_FAILED");
        }

        await AuditAsync(
            AuditActionTypes.SendEmail,
            "ResendLoginOtp",
            challenge.User,
            true,
            null,
            cancellationToken);
        return ChallengeResponse(
            challengeToken,
            challenge.User.Email,
            challenge,
            delay);
    }

    public Task<TwoFactorVerificationResult> VerifyOtpAsync(
        string challengeToken,
        string otp,
        bool trustDevice,
        string? deviceName,
        string? userAgent,
        CancellationToken cancellationToken) =>
        VerifyAsync(
            challengeToken,
            otp,
            false,
            trustDevice,
            deviceName,
            userAgent,
            cancellationToken);

    public Task<TwoFactorVerificationResult> VerifyRecoveryCodeAsync(
        string challengeToken,
        string recoveryCode,
        bool trustDevice,
        string? deviceName,
        string? userAgent,
        CancellationToken cancellationToken) =>
        VerifyAsync(
            challengeToken,
            recoveryCode,
            true,
            trustDevice,
            deviceName,
            userAgent,
            cancellationToken);

    public async Task<TrustedLoginResult?> ValidateTrustedDeviceAsync(
        int userId,
        int securityVersion,
        string rawToken,
        string? userAgent,
        CancellationToken cancellationToken)
    {
        var hash = Sha256(rawToken);
        var now = DateTime.UtcNow;
        var device = await _context.TrustedDevices
            .Include(item => item.User)
            .SingleOrDefaultAsync(
            item =>
                item.UserId == userId &&
                item.TokenHash == hash &&
                item.RevokedAtUtc == null,
            cancellationToken);
        if (device is null ||
            device.ExpiresAtUtc <= now ||
            device.SecurityVersionSnapshot != securityVersion)
        {
            return null;
        }

        var rotated = Base64Url(RandomNumberGenerator.GetBytes(32));
        device.TokenHash = Sha256(rotated);
        device.LastUsedAtUtc = now;
        device.UserAgentSummary = Bounded(userAgent, 256);
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.LoginSuccess,
            "UseTrustedDevice",
            device.User,
            true,
            null,
            cancellationToken);
        return new TrustedLoginResult(rotated, device.ExpiresAtUtc);
    }

    public async Task<IReadOnlyList<TrustedDeviceDto>> GetTrustedDevicesAsync(
        int userId,
        string? currentRawToken,
        CancellationToken cancellationToken)
    {
        var currentHash = string.IsNullOrWhiteSpace(currentRawToken)
            ? null
            : Sha256(currentRawToken);
        var now = DateTime.UtcNow;
        return await _context.TrustedDevices
            .AsNoTracking()
            .Where(item =>
                item.UserId == userId &&
                item.RevokedAtUtc == null &&
                item.ExpiresAtUtc > now)
            .OrderByDescending(item => item.LastUsedAtUtc)
            .Select(item => new TrustedDeviceDto(
                item.TrustedDeviceId,
                item.DeviceName,
                item.UserAgentSummary,
                item.CreatedAtUtc,
                item.LastUsedAtUtc,
                item.ExpiresAtUtc,
                currentHash != null && item.TokenHash == currentHash))
            .ToListAsync(cancellationToken);
    }

    public async Task RevokeTrustedDeviceAsync(
        int userId,
        long trustedDeviceId,
        string reason,
        CancellationToken cancellationToken)
    {
        var device = await _context.TrustedDevices.SingleOrDefaultAsync(
            item =>
                item.TrustedDeviceId == trustedDeviceId &&
                item.UserId == userId,
            cancellationToken)
            ?? throw new TwoFactorException(
                404,
                "The trusted device was not found.",
                "TRUSTED_DEVICE_NOT_FOUND");
        if (device.RevokedAtUtc is null)
        {
            device.RevokedAtUtc = DateTime.UtcNow;
            device.RevokedByUserId = userId;
            device.RevocationReason = Bounded(reason, 300);
            await _context.SaveChangesAsync(cancellationToken);
            var user = await _context.Users
                .Include(item => item.Role)
                .SingleAsync(
                    item => item.UserId == userId,
                    cancellationToken);
            await AuditAsync(
                AuditActionTypes.Delete,
                "RevokeTrustedDevice",
                user,
                true,
                null,
                cancellationToken);
        }
    }

    public async Task RevokeAllTrustedDevicesAsync(
        int userId,
        string reason,
        CancellationToken cancellationToken)
    {
        var now = DateTime.UtcNow;
        var devices = await _context.TrustedDevices
            .Where(item =>
                item.UserId == userId &&
                item.RevokedAtUtc == null)
            .ToListAsync(cancellationToken);
        foreach (var device in devices)
        {
            device.RevokedAtUtc = now;
            device.RevokedByUserId = userId;
            device.RevocationReason = Bounded(reason, 300);
        }
        await _context.SaveChangesAsync(cancellationToken);
        var user = await _context.Users
            .Include(item => item.Role)
            .SingleAsync(
                item => item.UserId == userId,
                cancellationToken);
        await AuditAsync(
            AuditActionTypes.Delete,
            "RevokeAllTrustedDevices",
            user,
            true,
            null,
            cancellationToken);
    }

    public async Task<(IReadOnlyList<string> Codes, RecoveryCodeStatusDto Status)>
        RegenerateRecoveryCodesAsync(
            User user,
            CancellationToken cancellationToken)
    {
        var now = DateTime.UtcNow;
        var active = await _context.UserRecoveryCodes
            .Where(item =>
                item.UserId == user.UserId &&
                item.UsedAtUtc == null &&
                item.RevokedAtUtc == null)
            .ToListAsync(cancellationToken);
        foreach (var code in active)
        {
            code.RevokedAtUtc = now;
        }

        var count = await _settings.GetIntAsync(
            SystemSettingKeys.SecurityRecoveryCodeCount,
            cancellationToken);
        var values = Enumerable.Range(1, count)
            .Select(_ => RecoveryCode())
            .ToArray();
        for (var index = 0; index < values.Length; index++)
        {
            _context.UserRecoveryCodes.Add(new UserRecoveryCode
            {
                UserId = user.UserId,
                CodeHash = SaltedHash(NormalizeRecoveryCode(values[index])),
                CodeOrder = index + 1,
                CreatedAtUtc = now,
                SecurityVersionSnapshot = user.SecurityVersion
            });
        }
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Update,
            "RegenerateRecoveryCodes",
            user,
            true,
            null,
            cancellationToken);
        return (
            values,
            new RecoveryCodeStatusDto(values.Length, now));
    }

    public async Task<RecoveryCodeStatusDto> GetRecoveryCodeStatusAsync(
        int userId,
        CancellationToken cancellationToken)
    {
        var rows = await _context.UserRecoveryCodes
            .AsNoTracking()
            .Where(item => item.UserId == userId)
            .ToListAsync(cancellationToken);
        return new RecoveryCodeStatusDto(
            rows.Count(item =>
                item.UsedAtUtc == null &&
                item.RevokedAtUtc == null),
            rows.Count == 0 ? null : rows.Max(item => item.CreatedAtUtc));
    }

    // Verification locks and counts failures server-side; the client never decides when a challenge passes.
    private async Task<TwoFactorVerificationResult> VerifyAsync(
        string challengeToken,
        string supplied,
        bool recovery,
        bool trustDevice,
        string? deviceName,
        string? userAgent,
        CancellationToken cancellationToken)
    {
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var challenge = await LoadActiveChallengeAsync(
            challengeToken,
            recovery,
            cancellationToken);
        if (challenge.User.SecurityVersion != challenge.SecurityVersionSnapshot ||
            !string.Equals(challenge.User.Status, "Active", StringComparison.OrdinalIgnoreCase))
        {
            challenge.RevokedAtUtc = DateTime.UtcNow;
            challenge.FailureReason = "The account security version changed.";
            await _context.SaveChangesAsync(cancellationToken);
            throw new TwoFactorException(
                401,
                "This verification request is no longer current. Sign in again.",
                "OTP_SECURITY_CHANGED");
        }

        UserRecoveryCode? recoveryRow = null;
        var valid = false;
        if (recovery)
        {
            var normalized = NormalizeRecoveryCode(supplied);
            var candidates = await _context.UserRecoveryCodes
                .Where(item =>
                    item.UserId == challenge.UserId &&
                    item.UsedAtUtc == null &&
                    item.RevokedAtUtc == null &&
                    item.SecurityVersionSnapshot == challenge.SecurityVersionSnapshot)
                .ToListAsync(cancellationToken);
            recoveryRow = candidates.FirstOrDefault(item =>
                VerifySaltedHash(normalized, item.CodeHash));
            valid = recoveryRow is not null;
        }
        else
        {
            valid = VerifySaltedHash(supplied, challenge.OtpHash);
        }

        if (!valid)
        {
            challenge.AttemptCount++;
            if (challenge.AttemptCount >= challenge.MaximumAttempts)
            {
                challenge.RevokedAtUtc = DateTime.UtcNow;
                challenge.FailureReason = "Maximum verification attempts reached.";
            }
            await _context.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
            await AuditAsync(
                AuditActionTypes.LoginFailure,
                recovery ? "VerifyRecoveryCode" : "VerifyLoginOtp",
                challenge.User,
                false,
                "Invalid verification value.",
                cancellationToken);
            throw new TwoFactorException(
                401,
                challenge.AttemptCount >= challenge.MaximumAttempts
                    ? "Too many failed attempts. Sign in again."
                    : "The verification value is incorrect.",
                challenge.AttemptCount >= challenge.MaximumAttempts
                    ? "OTP_ATTEMPT_LIMIT"
                    : "OTP_INVALID");
        }

        var now = DateTime.UtcNow;
        challenge.ConsumedAtUtc = now;
        if (recoveryRow is not null)
        {
            recoveryRow.UsedAtUtc = now;
        }
        var competing = await _context.UserOtpChallenges
            .Where(item =>
                item.UserId == challenge.UserId &&
                item.UserOtpChallengeId != challenge.UserOtpChallengeId &&
                item.ConsumedAtUtc == null &&
                item.RevokedAtUtc == null)
            .ToListAsync(cancellationToken);
        foreach (var item in competing)
        {
            item.RevokedAtUtc = now;
            item.FailureReason = "Another login challenge was completed.";
        }

        string? trustedToken = null;
        DateTime? trustedExpiry = null;
        if (trustDevice)
        {
            (trustedToken, trustedExpiry) = await CreateTrustedDeviceAsync(
                challenge.User,
                deviceName,
                userAgent,
                now,
                cancellationToken);
        }

        IReadOnlyList<string>? recoveryCodes = null;
        var hasAnyRecoverySet = await _context.UserRecoveryCodes
            .AnyAsync(item => item.UserId == challenge.UserId, cancellationToken);
        if (!hasAnyRecoverySet)
        {
            var generated = await RegenerateRecoveryCodesAsync(
                challenge.User,
                cancellationToken);
            recoveryCodes = generated.Codes;
        }

        await _context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        if (trustDevice)
        {
            await AuditAsync(
                AuditActionTypes.Create,
                "CreateTrustedDevice",
                challenge.User,
                true,
                null,
                cancellationToken);
        }
        await AuditAsync(
            AuditActionTypes.LoginSuccess,
            recovery ? "VerifyRecoveryCode" : "VerifyLoginOtp",
            challenge.User,
            true,
            null,
            cancellationToken);
        if (recovery)
        {
            try
            {
                await _email.SendRecoveryCodeUsedNotificationAsync(
                    challenge.User.Email,
                    $"{challenge.User.FirstName} {challenge.User.LastName}".Trim(),
                    now,
                    cancellationToken);
            }
            catch
            {
                // Authentication is complete; the security event remains audited.
            }
        }
        return new TwoFactorVerificationResult(
            challenge.User,
            trustedToken,
            trustedExpiry,
            recoveryCodes);
    }

    // Only the raw token leaves once; the database stores a hash that can be revoked or expired.
    private async Task<(string Token, DateTime ExpiresAtUtc)> CreateTrustedDeviceAsync(
        User user,
        string? deviceName,
        string? userAgent,
        DateTime now,
        CancellationToken cancellationToken)
    {
        var days = await _settings.GetIntAsync(
            SystemSettingKeys.SecurityTrustedDeviceDays,
            cancellationToken);
        var token = Base64Url(RandomNumberGenerator.GetBytes(32));
        var expiry = now.AddDays(days);
        _context.TrustedDevices.Add(new TrustedDevice
        {
            UserId = user.UserId,
            TokenHash = Sha256(token),
            DeviceName = Bounded(deviceName, 120) ?? "Trusted browser",
            UserAgentSummary = Bounded(userAgent, 256),
            CreatedAtUtc = now,
            LastUsedAtUtc = now,
            ExpiresAtUtc = expiry,
            SecurityVersionSnapshot = user.SecurityVersion
        });
        return (token, expiry);
    }

    private async Task<UserOtpChallenge> LoadActiveChallengeAsync(
        string rawToken,
        bool permitEmailFailureRecovery,
        CancellationToken cancellationToken)
    {
        var hash = Sha256(rawToken);
        var challenge = await _context.UserOtpChallenges
            .Include(item => item.User)
                .ThenInclude(user => user.Role)
            .SingleOrDefaultAsync(
                item => item.ChallengeTokenHash == hash,
                cancellationToken)
            ?? throw new TwoFactorException(
                401,
                "The verification request is invalid. Sign in again.",
                "OTP_CHALLENGE_INVALID");
        if (challenge.ConsumedAtUtc is not null ||
            (challenge.RevokedAtUtc is not null &&
             !(permitEmailFailureRecovery &&
               string.Equals(
                   challenge.FailureReason,
                   "Verification email delivery failed.",
                   StringComparison.Ordinal))))
        {
            throw new TwoFactorException(
                401,
                "The verification request has already been used or revoked. Sign in again.",
                "OTP_CHALLENGE_CLOSED");
        }
        if (challenge.ExpiresAtUtc <= DateTime.UtcNow)
        {
            challenge.RevokedAtUtc = DateTime.UtcNow;
            challenge.FailureReason = "Verification request expired.";
            await _context.SaveChangesAsync(cancellationToken);
            await AuditAsync(
                AuditActionTypes.LoginFailure,
                "ExpireLoginOtp",
                challenge.User,
                false,
                "Verification request expired.",
                cancellationToken);
            throw new TwoFactorException(
                401,
                "The verification code expired. Sign in again.",
                "OTP_EXPIRED");
        }
        if (challenge.AttemptCount >= challenge.MaximumAttempts)
        {
            throw new TwoFactorException(
                401,
                "Too many failed attempts. Sign in again.",
                "OTP_ATTEMPT_LIMIT");
        }
        return challenge;
    }

    private async Task AuditAsync(
        string action,
        string operation,
        User user,
        bool success,
        string? failureReason,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = AuditModules.Authentication,
            OperationName = operation,
            Description = success
                ? "A multi-factor security event completed successfully."
                : "A multi-factor security event was rejected.",
            EntityType = nameof(User),
            EntityId = user.UserId.ToString(),
            EntityDisplay = AuditSanitizer.MaskEmail(user.Email),
            Success = success,
            FailureReason = failureReason,
            UserId = success ? user.UserId : null,
            UserEmail = success ? user.Email : AuditSanitizer.MaskEmail(user.Email),
            ActorType = success ? AuditActorTypes.User : AuditActorTypes.Anonymous,
            EventSource = AuditEventSources.SecurityEvent
        }, cancellationToken);

    private static TwoFactorChallengeResponse ChallengeResponse(
        string rawChallenge,
        string email,
        UserOtpChallenge challenge,
        int resendDelay,
        bool emailDeliveryFailed = false,
        string? message = null) =>
        new(
            true,
            rawChallenge,
            MaskEmail(email),
            challenge.ExpiresAtUtc,
            resendDelay,
            Math.Max(0, challenge.MaximumAttempts - challenge.AttemptCount),
            emailDeliveryFailed,
            message);

    private static string MaskEmail(string email)
    {
        var parts = email.Split('@', 2);
        if (parts.Length != 2)
        {
            return "***";
        }
        var local = parts[0];
        var shown = local.Length <= 2
            ? local[..1]
            : local[..2];
        return $"{shown}***@{parts[1]}";
    }

    private static string RecoveryCode()
    {
        var value = Convert.ToHexString(RandomNumberGenerator.GetBytes(8));
        return $"{value[..4]}-{value[4..8]}-{value[8..12]}-{value[12..]}";
    }

    private static string NormalizeRecoveryCode(string value) =>
        value.Replace("-", string.Empty, StringComparison.Ordinal)
            .Replace(" ", string.Empty, StringComparison.Ordinal)
            .Trim()
            .ToUpperInvariant();

    private static string SaltedHash(string value)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = HMACSHA256.HashData(salt, Encoding.UTF8.GetBytes(value));
        return $"{Convert.ToHexString(salt)}:{Convert.ToHexString(hash)}";
    }

    private static bool VerifySaltedHash(string value, string encoded)
    {
        var parts = encoded.Split(':', 2);
        if (parts.Length != 2)
        {
            return false;
        }
        try
        {
            var salt = Convert.FromHexString(parts[0]);
            var expected = Convert.FromHexString(parts[1]);
            var actual = HMACSHA256.HashData(salt, Encoding.UTF8.GetBytes(value));
            return CryptographicOperations.FixedTimeEquals(expected, actual);
        }
        catch (FormatException)
        {
            return false;
        }
    }

    private static string Sha256(string value) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));

    private static string Base64Url(byte[] value) =>
        Convert.ToBase64String(value)
            .Replace("+", "-", StringComparison.Ordinal)
            .Replace("/", "_", StringComparison.Ordinal)
            .TrimEnd('=');

    private static string? Bounded(string? value, int length)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }
        var clean = value.Trim().Replace("\r", " ").Replace("\n", " ");
        return clean.Length <= length ? clean : clean[..length];
    }
}
