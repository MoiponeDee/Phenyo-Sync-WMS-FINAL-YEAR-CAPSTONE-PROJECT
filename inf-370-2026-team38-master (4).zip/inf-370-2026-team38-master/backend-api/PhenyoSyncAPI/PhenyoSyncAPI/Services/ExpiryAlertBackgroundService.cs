using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;

namespace PhenyoSyncAPI.Services
{
    /// <summary>Runs periodic expiry evaluation in a fresh service scope and records each outcome.</summary>
    public class ExpiryAlertBackgroundService : BackgroundService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly ExpiryAlertOptions _options;
        private readonly ISystemSettingProvider _settings;
        private readonly ILogger<ExpiryAlertBackgroundService> _logger;

        public ExpiryAlertBackgroundService(
            IServiceScopeFactory scopeFactory,
            IOptions<ExpiryAlertOptions> options,
            ISystemSettingProvider settings,
            ILogger<ExpiryAlertBackgroundService> logger)
        {
            _scopeFactory = scopeFactory;
            _options = options.Value;
            _settings = settings;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // Failures are logged per cycle so one transient error does not terminate future scans.
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using var scope = _scopeFactory.CreateScope();
                    var service = scope.ServiceProvider.GetRequiredService<IExpiryService>();
                    var result = await service.RunScanAsync(stoppingToken);
                    var audit = scope.ServiceProvider.GetRequiredService<IAuditService>();
                    await audit.RecordAsync(new AuditEvent
                    {
                        ActionType = AuditActionTypes.BackgroundJob,
                        SystemModule = AuditModules.ExpiryManagement,
                        OperationName = "ScheduledExpiryScan",
                        Description = "The scheduled expiry scan completed.",
                        Success = true,
                        ActorType = AuditActorTypes.BackgroundService,
                        EventSource = AuditEventSources.BackgroundService,
                        SafeDetails = new Dictionary<string, object?>
                        {
                            ["BatchesScanned"] = result.BatchesScanned,
                            ["MarkedExpired"] = result.MarkedExpired,
                            ["WarningEmailsSent"] = result.WarningEmailsSent,
                            ["UrgentEmailsSent"] = result.UrgentEmailsSent
                        }
                    }, stoppingToken);
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception exception)
                {
                    _logger.LogError(exception, "The scheduled expiry scan failed.");
                }

                var configuredInterval = await _settings.GetIntAsync(
                    SystemSettingKeys.ExpiryScanIntervalMinutes,
                    stoppingToken);
                // Clamp database configuration to prevent a zero-delay loop or impractically long pause.
                var safeInterval = Math.Clamp(
                    configuredInterval,
                    1,
                    1440);
                try
                {
                    await Task.Delay(
                        TimeSpan.FromMinutes(safeInterval),
                        stoppingToken);
                }
                catch (OperationCanceledException)
                    when (stoppingToken.IsCancellationRequested)
                {
                    break;
                }
            }
        }
    }
}
