using PhenyoSyncAPI.DTOs.Order;

namespace PhenyoSyncAPI.Services;

public interface IOrderService
{
    Task<SalesOrderDetailDto> CreateAsync(
        CreateSalesOrderDto request,
        int? createdByUserId,
        long? orderLinkId,
        CancellationToken cancellationToken);

    Task<SalesOrderDetailDto> GetAsync(int orderId, CancellationToken cancellationToken);
    Task<PagedResultDto<SalesOrderSummaryDto>> SearchAsync(OrderSearchQueryDto query, CancellationToken cancellationToken);
    Task<SalesOrderDetailDto> UpdateAsync(int orderId, UpdateSalesOrderDto request, int userId, CancellationToken cancellationToken);
}
