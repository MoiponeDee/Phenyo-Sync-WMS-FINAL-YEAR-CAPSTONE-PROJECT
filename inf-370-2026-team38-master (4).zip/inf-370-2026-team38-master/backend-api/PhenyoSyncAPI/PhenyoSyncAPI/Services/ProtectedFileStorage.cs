using System.Security.Cryptography;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Formats.Png;
using SixLabors.ImageSharp.Formats.Webp;
using SixLabors.ImageSharp.Processing;

namespace PhenyoSyncAPI.Services;

public sealed record StoredImageResult(
    StoredFile Image,
    StoredFile Thumbnail);

public interface IProtectedFileStorage
{
    Task<StoredImageResult> SaveProofImageAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        CancellationToken cancellationToken);

    Task<StoredImageResult> SaveDocketImageAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        CancellationToken cancellationToken);

    Task<StoredFile> SaveTrainingVideoAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        CancellationToken cancellationToken);

    Task<StoredFile> SaveCaptionAsync(
        IFormFile file,
        int uploadedByUserId,
        CancellationToken cancellationToken);

    FileStream OpenRead(StoredFile file);
    Task DeletePhysicalAsync(StoredFile file, CancellationToken cancellationToken);
}

public sealed class ProtectedFileException : Exception
{
    public ProtectedFileException(string message) : base(message)
    {
    }
}

/// <summary>Stores validated uploads outside public web roots and resolves them by controlled identifiers.</summary>
public sealed class ProtectedFileStorage : IProtectedFileStorage
{
    private readonly string _root;

    public ProtectedFileStorage(
        IOptions<ProtectedStorageOptions> options,
        IWebHostEnvironment environment)
    {
        var configured = options.Value.RootPath;
        _root = Path.GetFullPath(
            Path.IsPathRooted(configured)
                ? configured
                : Path.Combine(environment.ContentRootPath, configured));
        Directory.CreateDirectory(_root);
    }

    public async Task<StoredImageResult> SaveProofImageAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        CancellationToken cancellationToken) =>
        await SaveImageAsync(
            file,
            uploadedByUserId,
            maximumMegabytes,
            "delivery-proof",
            cancellationToken);

    public async Task<StoredImageResult> SaveDocketImageAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        CancellationToken cancellationToken) =>
        await SaveImageAsync(
            file,
            uploadedByUserId,
            maximumMegabytes,
            "business-docket",
            cancellationToken);

    // Decode and re-encode uploads to reject disguised content and strip untrusted image metadata.
    private async Task<StoredImageResult> SaveImageAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        string category,
        CancellationToken cancellationToken)
    {
        ValidateLength(file, maximumMegabytes);
        var expected = ValidateImageDeclaration(file);
        await using var source = file.OpenReadStream();
        using var image = await Image.LoadAsync(source, cancellationToken);
        var decoded = image.Metadata.DecodedImageFormat?.Name
            ?? throw new ProtectedFileException("The image format could not be identified.");
        if (!decoded.Equals(expected, StringComparison.OrdinalIgnoreCase))
        {
            throw new ProtectedFileException(
                "The image extension, content type and file signature do not match.");
        }

        image.Metadata.ExifProfile = null;
        image.Metadata.XmpProfile = null;
        image.Metadata.IccProfile = null;
        image.Mutate(context => context.AutoOrient());

        var extension = expected switch
        {
            "JPEG" => ".jpg",
            "PNG" => ".png",
            "WEBP" => ".webp",
            _ => throw new ProtectedFileException("The image format is not allowed.")
        };
        var contentType = expected switch
        {
            "JPEG" => "image/jpeg",
            "PNG" => "image/png",
            _ => "image/webp"
        };

        var imageFile = await SaveEncodedImageAsync(
            image,
            category,
            extension,
            contentType,
            file.FileName,
            uploadedByUserId,
            cancellationToken);

        using var thumbnail = image.Clone(context =>
            context.Resize(new ResizeOptions
            {
                Size = new Size(600, 600),
                Mode = ResizeMode.Max
            }));
        var thumbnailFile = await SaveEncodedImageAsync(
            thumbnail,
            $"{category}-thumbnail",
            ".jpg",
            "image/jpeg",
            Path.GetFileNameWithoutExtension(file.FileName) + "-thumbnail.jpg",
            uploadedByUserId,
            cancellationToken);

        return new StoredImageResult(imageFile, thumbnailFile);
    }

    public async Task<StoredFile> SaveTrainingVideoAsync(
        IFormFile file,
        int uploadedByUserId,
        int maximumMegabytes,
        CancellationToken cancellationToken)
    {
        ValidateLength(file, maximumMegabytes);
        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (extension is not ".mp4" and not ".webm")
        {
            throw new ProtectedFileException("Training videos must be MP4 or WebM files.");
        }
        var declared = file.ContentType.ToLowerInvariant();
        if ((extension == ".mp4" && declared != "video/mp4") ||
            (extension == ".webm" && declared != "video/webm"))
        {
            throw new ProtectedFileException(
                "The video extension and content type do not match.");
        }

        await using var source = file.OpenReadStream();
        var header = new byte[16];
        var read = await source.ReadAsync(header, cancellationToken);
        source.Position = 0;
        var valid = extension == ".mp4"
            ? read >= 12 &&
              header[4] == (byte)'f' &&
              header[5] == (byte)'t' &&
              header[6] == (byte)'y' &&
              header[7] == (byte)'p'
            : read >= 4 &&
              header[0] == 0x1A &&
              header[1] == 0x45 &&
              header[2] == 0xDF &&
              header[3] == 0xA3;
        if (!valid)
        {
            throw new ProtectedFileException(
                "The uploaded file is not a valid MP4 or WebM video.");
        }

        return await SaveStreamAsync(
            source,
            "training-video",
            extension,
            declared,
            file.FileName,
            uploadedByUserId,
            cancellationToken);
    }

    public async Task<StoredFile> SaveCaptionAsync(
        IFormFile file,
        int uploadedByUserId,
        CancellationToken cancellationToken)
    {
        ValidateLength(file, 2);
        if (!Path.GetExtension(file.FileName).Equals(
                ".vtt",
                StringComparison.OrdinalIgnoreCase))
        {
            throw new ProtectedFileException("Captions must use the WebVTT (.vtt) format.");
        }

        await using var source = file.OpenReadStream();
        using var reader = new StreamReader(
            source,
            detectEncodingFromByteOrderMarks: true,
            leaveOpen: true);
        var firstLine = await reader.ReadLineAsync(cancellationToken);
        if (!string.Equals(firstLine?.Trim(), "WEBVTT", StringComparison.Ordinal))
        {
            throw new ProtectedFileException("The caption file is not valid WebVTT.");
        }
        source.Position = 0;
        return await SaveStreamAsync(
            source,
            "training-caption",
            ".vtt",
            "text/vtt",
            file.FileName,
            uploadedByUserId,
            cancellationToken);
    }

    // Resolve stored names under the configured root to prevent path traversal outside protected storage.
    public FileStream OpenRead(StoredFile file)
    {
        var path = Resolve(file.StorageKey);
        if (!File.Exists(path))
        {
            throw new FileNotFoundException("The protected file is unavailable.");
        }
        return new FileStream(
            path,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            64 * 1024,
            FileOptions.Asynchronous | FileOptions.SequentialScan);
    }

    public Task DeletePhysicalAsync(
        StoredFile file,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var path = Resolve(file.StorageKey);
        if (File.Exists(path))
        {
            File.Delete(path);
        }
        return Task.CompletedTask;
    }

    private async Task<StoredFile> SaveEncodedImageAsync(
        Image image,
        string purpose,
        string extension,
        string contentType,
        string originalFileName,
        int uploadedByUserId,
        CancellationToken cancellationToken)
    {
        await using var stream = new MemoryStream();
        switch (extension)
        {
            case ".jpg":
                await image.SaveAsync(
                    stream,
                    new JpegEncoder { Quality = 88 },
                    cancellationToken);
                break;
            case ".png":
                await image.SaveAsync(
                    stream,
                    new PngEncoder(),
                    cancellationToken);
                break;
            case ".webp":
                await image.SaveAsync(
                    stream,
                    new WebpEncoder { Quality = 88 },
                    cancellationToken);
                break;
        }
        stream.Position = 0;
        return await SaveStreamAsync(
            stream,
            purpose,
            extension,
            contentType,
            originalFileName,
            uploadedByUserId,
            cancellationToken);
    }

    // Generate server-owned filenames; user-provided names are retained only as bounded metadata.
    private async Task<StoredFile> SaveStreamAsync(
        Stream source,
        string purpose,
        string extension,
        string contentType,
        string originalFileName,
        int uploadedByUserId,
        CancellationToken cancellationToken)
    {
        var date = DateTime.UtcNow;
        var key = Path.Combine(
            purpose,
            date.ToString("yyyy"),
            date.ToString("MM"),
            $"{Guid.NewGuid():N}{extension}")
            .Replace('\\', '/');
        var destination = Resolve(key);
        Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
        var temporary = destination + ".upload";
        try
        {
            await using (var output = new FileStream(
                temporary,
                FileMode.CreateNew,
                FileAccess.Write,
                FileShare.None,
                64 * 1024,
                FileOptions.Asynchronous))
            {
                await source.CopyToAsync(output, cancellationToken);
                await output.FlushAsync(cancellationToken);
            }
            File.Move(temporary, destination);
            await using var hashStream = new FileStream(
                destination,
                FileMode.Open,
                FileAccess.Read,
                FileShare.Read);
            var hash = Convert.ToHexString(
                await SHA256.HashDataAsync(hashStream, cancellationToken));
            var safeOriginal = Path.GetFileName(originalFileName);
            return new StoredFile
            {
                StorageKey = key,
                OriginalFileName = safeOriginal.Length > 255
                    ? safeOriginal[..255]
                    : safeOriginal,
                SafeDownloadName = SafeFileName(safeOriginal, extension),
                ContentType = contentType,
                Extension = extension,
                SizeBytes = new FileInfo(destination).Length,
                Sha256Hash = hash,
                UploadedAtUtc = date,
                UploadedByUserId = uploadedByUserId
            };
        }
        catch
        {
            if (File.Exists(temporary))
            {
                File.Delete(temporary);
            }
            if (File.Exists(destination))
            {
                File.Delete(destination);
            }
            throw;
        }
    }

    private string Resolve(string key)
    {
        var candidate = Path.GetFullPath(
            Path.Combine(_root, key.Replace('/', Path.DirectorySeparatorChar)));
        if (!candidate.StartsWith(
                _root + Path.DirectorySeparatorChar,
                StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("The protected storage key is invalid.");
        }
        return candidate;
    }

    private static void ValidateLength(IFormFile file, int maximumMegabytes)
    {
        if (file.Length <= 0)
        {
            throw new ProtectedFileException("Select a non-empty file.");
        }
        if (file.Length > maximumMegabytes * 1024L * 1024L)
        {
            throw new ProtectedFileException(
                $"The file exceeds the {maximumMegabytes} MB limit.");
        }
    }

    private static string ValidateImageDeclaration(IFormFile file)
    {
        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        var contentType = file.ContentType.ToLowerInvariant();
        return (extension, contentType) switch
        {
            (".jpg" or ".jpeg", "image/jpeg") => "JPEG",
            (".png", "image/png") => "PNG",
            (".webp", "image/webp") => "WEBP",
            _ => throw new ProtectedFileException(
                "Proof images must be matching JPEG, PNG or WebP files.")
        };
    }

    private static string SafeFileName(string original, string extension)
    {
        var stem = Path.GetFileNameWithoutExtension(original);
        var safe = new string(stem
            .Where(character =>
                char.IsLetterOrDigit(character) ||
                character is '-' or '_')
            .Take(100)
            .ToArray());
        return $"{(safe.Length == 0 ? "file" : safe)}{extension}";
    }
}
