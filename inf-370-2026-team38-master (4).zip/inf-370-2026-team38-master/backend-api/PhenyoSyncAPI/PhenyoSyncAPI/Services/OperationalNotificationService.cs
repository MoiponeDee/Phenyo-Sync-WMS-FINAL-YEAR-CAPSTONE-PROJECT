using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public interface IOperationalNotificationService
{
    Task PublishToRolesAsync(
        string type,
        string severity,
        string title,
        string message,
        IReadOnlyCollection<string> roleCodes,
        string? entityType,
        string? entityId,
        string? actionRoute,
        int? actorUserId,
        string correlationId,
        CancellationToken cancellationToken);

    Task PublishToUsersAsync(
        string type,
        string severity,
        string title,
        string message,
        IReadOnlyCollection<int> userIds,
        string? entityType,
        string? entityId,
        string? actionRoute,
        int? actorUserId,
        string correlationId,
        CancellationToken cancellationToken);

    Task<NotificationInboxDto> InboxAsync(
        int userId,
        bool unreadOnly,
        CancellationToken cancellationToken);

    Task MarkReadAsync(
        long recipientId,
        int userId,
        CancellationToken cancellationToken);

    Task MarkAllReadAsync(
        int userId,
        CancellationToken cancellationToken);

    Task<NotificationPreferenceDto> PreferencesAsync(
        int userId,
        CancellationToken cancellationToken);

    Task<NotificationPreferenceDto> UpdatePreferencesAsync(
        int userId,
        NotificationPreferenceDto request,
        CancellationToken cancellationToken);

    Task<MobileDeviceDto> RegisterDeviceAsync(
        int userId,
        RegisterMobileDeviceRequest request,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<MobileDeviceDto>> DevicesAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task RevokeDeviceAsync(
        long deviceId,
        int actorUserId,
        bool manageAll,
        string reason,
        CancellationToken cancellationToken);
}

public sealed class OperationalNotificationService : IOperationalNotificationService
{
    private readonly PhenyoSyncDbContext _context;

    public OperationalNotificationService(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    // Resolve recipients from current role permissions before creating per-user inbox/outbox rows.
    public async Task PublishToRolesAsync(
        string type,
        string severity,
        string title,
        string message,
        IReadOnlyCollection<string> roleCodes,
        string? entityType,
        string? entityId,
        string? actionRoute,
        int? actorUserId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        var normalized = roleCodes
            .Select(RoleCodes.Normalize)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var userIds = await _context.Users.AsNoTracking()
            .Where(item =>
                item.Status == ProductStatuses.Active &&
                item.Role != null &&
                item.Role.IsActive &&
                normalized.Contains(item.Role.RoleCode))
            .Select(item => item.UserId)
            .ToListAsync(cancellationToken);
        await PublishToUsersAsync(
            type,
            severity,
            title,
            message,
            userIds,
            entityType,
            entityId,
            actionRoute,
            actorUserId,
            correlationId,
            cancellationToken);
    }

    public async Task PublishToUsersAsync(
        string type,
        string severity,
        string title,
        string message,
        IReadOnlyCollection<int> userIds,
        string? entityType,
        string? entityId,
        string? actionRoute,
        int? actorUserId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        var recipients = userIds.Distinct().ToArray();
        if (recipients.Length == 0) return;
        var notification = new OperationalNotification
        {
            NotificationType = Clean(type, 80),
            Severity = Clean(severity, 20),
            Title = Clean(title, 180),
            Message = Clean(message, 1000),
            EntityType = CleanNullable(entityType, 100),
            EntityId = CleanNullable(entityId, 100),
            ActionRoute = CleanNullable(actionRoute, 300),
            CorrelationId = Clean(correlationId, 64),
            CreatedByUserId = actorUserId,
            CreatedAtUtc = DateTime.UtcNow,
            Recipients = recipients.Select(userId =>
                new OperationalNotificationRecipient
                {
                    UserId = userId,
                    PushStatus = NotificationDeliveryStatuses.Pending,
                    NextPushAttemptAtUtc = DateTime.UtcNow
                }).ToList()
        };
        _context.OperationalNotifications.Add(notification);
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task<NotificationInboxDto> InboxAsync(
        int userId,
        bool unreadOnly,
        CancellationToken cancellationToken)
    {
        var query = _context.OperationalNotificationRecipients.AsNoTracking()
            .Where(item =>
                item.UserId == userId &&
                item.DismissedAtUtc == null);
        if (unreadOnly) query = query.Where(item => item.ReadAtUtc == null);
        var unread = await _context.OperationalNotificationRecipients.AsNoTracking()
            .CountAsync(
                item =>
                    item.UserId == userId &&
                    item.ReadAtUtc == null &&
                    item.DismissedAtUtc == null,
                cancellationToken);
        var items = await query
            .OrderByDescending(item => item.Notification.CreatedAtUtc)
            .Take(100)
            .Select(item => new NotificationDto
            {
                NotificationRecipientId =
                    item.OperationalNotificationRecipientId,
                NotificationId = item.OperationalNotificationId,
                Type = item.Notification.NotificationType,
                Severity = item.Notification.Severity,
                Title = item.Notification.Title,
                Message = item.Notification.Message,
                ActionRoute = item.Notification.ActionRoute,
                CreatedAtUtc = item.Notification.CreatedAtUtc,
                ReadAtUtc = item.ReadAtUtc,
                PushStatus = item.PushStatus
            })
            .ToListAsync(cancellationToken);
        return new NotificationInboxDto
        {
            UnreadCount = unread,
            Items = items
        };
    }

    public async Task MarkReadAsync(
        long recipientId,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await _context.OperationalNotificationRecipients
            .SingleOrDefaultAsync(
                recipient =>
                    recipient.OperationalNotificationRecipientId == recipientId &&
                    recipient.UserId == userId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Notification not found.");
        item.ReadAtUtc ??= DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task MarkAllReadAsync(
        int userId,
        CancellationToken cancellationToken)
    {
        var items = await _context.OperationalNotificationRecipients
            .Where(item =>
                item.UserId == userId &&
                item.ReadAtUtc == null &&
                item.DismissedAtUtc == null)
            .ToListAsync(cancellationToken);
        var now = DateTime.UtcNow;
        foreach (var item in items) item.ReadAtUtc = now;
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task<NotificationPreferenceDto> PreferencesAsync(
        int userId,
        CancellationToken cancellationToken)
    {
        var preference = await _context.NotificationPreferences.AsNoTracking()
            .SingleOrDefaultAsync(item => item.UserId == userId, cancellationToken);
        return preference is null
            ? new NotificationPreferenceDto()
            : Map(preference);
    }

    public async Task<NotificationPreferenceDto> UpdatePreferencesAsync(
        int userId,
        NotificationPreferenceDto request,
        CancellationToken cancellationToken)
    {
        var preference = await _context.NotificationPreferences
            .SingleOrDefaultAsync(item => item.UserId == userId, cancellationToken);
        if (preference is null)
        {
            preference = new NotificationPreference { UserId = userId };
            _context.NotificationPreferences.Add(preference);
        }
        preference.PushEnabled = request.PushEnabled;
        preference.EmailFallbackEnabled = request.EmailFallbackEnabled;
        preference.CriticalAlertsEnabled = request.CriticalAlertsEnabled;
        preference.QuietHoursStart = request.QuietHoursStart;
        preference.QuietHoursEnd = request.QuietHoursEnd;
        preference.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
        return Map(preference);
    }

    // Device identifiers and push tokens are protected operational data and are never exposed in logs.
    public async Task<MobileDeviceDto> RegisterDeviceAsync(
        int userId,
        RegisterMobileDeviceRequest request,
        CancellationToken cancellationToken)
    {
        var identifierHash = MobileSecurity.Hash(request.DeviceIdentifier);
        var item = await _context.MobileDeviceRegistrations
            .SingleOrDefaultAsync(
                device =>
                    device.UserId == userId &&
                    device.DeviceIdentifierHash == identifierHash,
                cancellationToken);
        var now = DateTime.UtcNow;
        if (item is null)
        {
            item = new MobileDeviceRegistration
            {
                UserId = userId,
                DeviceIdentifierHash = identifierHash,
                RegisteredAtUtc = now
            };
            _context.MobileDeviceRegistrations.Add(item);
        }
        item.Platform = Clean(request.Platform, 30);
        item.DeviceName = CleanNullable(request.DeviceName, 120);
        item.AppVersion = CleanNullable(request.AppVersion, 40);
        item.PushToken = CleanNullable(request.PushToken, 2048);
        item.LastSeenAtUtc = now;
        item.IsActive = true;
        item.RevokedAtUtc = null;
        item.RevokedByUserId = null;
        item.RevocationReason = null;
        await _context.SaveChangesAsync(cancellationToken);
        return Map(item);
    }

    public async Task<IReadOnlyList<MobileDeviceDto>> DevicesAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        var items = await _context.MobileDeviceRegistrations.AsNoTracking()
            .Where(item => viewAll || item.UserId == userId)
            .OrderByDescending(item => item.IsActive)
            .ThenByDescending(item => item.LastSeenAtUtc)
            .ToListAsync(cancellationToken);
        return items.Select(Map).ToList();
    }

    public async Task RevokeDeviceAsync(
        long deviceId,
        int actorUserId,
        bool manageAll,
        string reason,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(reason) || reason.Trim().Length < 3)
            throw new PhaseCException(400, "A revocation reason is required.");
        var item = await _context.MobileDeviceRegistrations.SingleOrDefaultAsync(
                device => device.MobileDeviceRegistrationId == deviceId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Mobile device not found.");
        if (!manageAll && item.UserId != actorUserId)
            throw new PhaseCException(403, "You cannot revoke this device.");
        item.IsActive = false;
        item.PushToken = null;
        item.RevokedAtUtc = DateTime.UtcNow;
        item.RevokedByUserId = actorUserId;
        item.RevocationReason = Clean(reason, 300);
        await _context.SaveChangesAsync(cancellationToken);
    }

    private static NotificationPreferenceDto Map(NotificationPreference item) =>
        new()
        {
            PushEnabled = item.PushEnabled,
            EmailFallbackEnabled = item.EmailFallbackEnabled,
            CriticalAlertsEnabled = item.CriticalAlertsEnabled,
            QuietHoursStart = item.QuietHoursStart,
            QuietHoursEnd = item.QuietHoursEnd
        };

    private static MobileDeviceDto Map(MobileDeviceRegistration item) =>
        new()
        {
            MobileDeviceRegistrationId = item.MobileDeviceRegistrationId,
            Platform = item.Platform,
            DeviceName = item.DeviceName,
            AppVersion = item.AppVersion,
            RegisteredAtUtc = item.RegisteredAtUtc,
            LastSeenAtUtc = item.LastSeenAtUtc,
            IsActive = item.IsActive,
            RevokedAtUtc = item.RevokedAtUtc
        };

    private static string Clean(string? value, int maximum)
    {
        var cleaned = value?.Trim() ?? string.Empty;
        return cleaned.Length <= maximum ? cleaned : cleaned[..maximum];
    }

    private static string? CleanNullable(string? value, int maximum)
    {
        var cleaned = value?.Trim();
        if (string.IsNullOrWhiteSpace(cleaned)) return null;
        return cleaned.Length <= maximum ? cleaned : cleaned[..maximum];
    }
}

public sealed record PushChannelResult(
    string Status,
    string? SafeErrorCode = null,
    bool DeactivateToken = false);

public interface IPushNotificationChannel
{
    bool IsConfigured { get; }
    Task<PushChannelResult> SendAsync(
        string pushToken,
        OperationalNotification notification,
        CancellationToken cancellationToken);
}

public sealed class FirebasePushNotificationChannel : IPushNotificationChannel
{
    private readonly HttpClient _http;
    private readonly FirebaseMessagingOptions _options;
    private readonly SemaphoreSlim _tokenLock = new(1, 1);
    private string? _accessToken;
    private DateTime _accessTokenExpiresAtUtc;

    public FirebasePushNotificationChannel(
        HttpClient http,
        IOptions<FirebaseMessagingOptions> options)
    {
        _http = http;
        _options = options.Value;
        _http.Timeout = TimeSpan.FromSeconds(
            Math.Clamp(_options.TimeoutSeconds, 5, 60));
    }

    public bool IsConfigured => _options.IsConfigured;

    public async Task<PushChannelResult> SendAsync(
        string pushToken,
        OperationalNotification notification,
        CancellationToken cancellationToken)
    {
        if (!IsConfigured)
            return new PushChannelResult(NotificationDeliveryStatuses.Disabled);
        try
        {
            var accessToken = await AccessTokenAsync(cancellationToken);
            using var request = new HttpRequestMessage(
                HttpMethod.Post,
                $"https://fcm.googleapis.com/v1/projects/{Uri.EscapeDataString(_options.ProjectId!)}/messages:send");
            request.Headers.Authorization =
                new AuthenticationHeaderValue("Bearer", accessToken);
            request.Content = JsonContent.Create(new
            {
                message = new
                {
                    token = pushToken,
                    notification = new
                    {
                        title = notification.Title,
                        body = notification.Message
                    },
                    data = new Dictionary<string, string>
                    {
                        ["notificationId"] =
                            notification.OperationalNotificationId.ToString(),
                        ["type"] = notification.NotificationType,
                        ["severity"] = notification.Severity,
                        ["route"] = notification.ActionRoute ?? string.Empty
                    },
                    android = new
                    {
                        priority = notification.Severity is "Critical" or "Error"
                            ? "high"
                            : "normal",
                        notification = new { channelId = "phenyosync-operations" }
                    }
                }
            });
            using var response = await _http.SendAsync(request, cancellationToken);
            if (response.IsSuccessStatusCode)
                return new PushChannelResult(NotificationDeliveryStatuses.Sent);
            var status = (int)response.StatusCode;
            if (status is 400 or 404)
                return new PushChannelResult(
                    NotificationDeliveryStatuses.Failed,
                    "INVALID_REGISTRATION",
                    true);
            return new PushChannelResult(
                NotificationDeliveryStatuses.Failed,
                $"FCM_HTTP_{status}");
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return new PushChannelResult(
                NotificationDeliveryStatuses.Failed,
                "FCM_TIMEOUT");
        }
        catch (JsonException)
        {
            return new PushChannelResult(
                NotificationDeliveryStatuses.Failed,
                "FCM_CONFIGURATION_INVALID");
        }
        catch (CryptographicException)
        {
            return new PushChannelResult(
                NotificationDeliveryStatuses.Failed,
                "FCM_CREDENTIAL_INVALID");
        }
        catch (HttpRequestException)
        {
            return new PushChannelResult(
                NotificationDeliveryStatuses.Failed,
                "FCM_UNAVAILABLE");
        }
    }

    private async Task<string> AccessTokenAsync(CancellationToken cancellationToken)
    {
        if (_accessToken is not null &&
            _accessTokenExpiresAtUtc > DateTime.UtcNow.AddMinutes(2))
            return _accessToken;
        await _tokenLock.WaitAsync(cancellationToken);
        try
        {
            if (_accessToken is not null &&
                _accessTokenExpiresAtUtc > DateTime.UtcNow.AddMinutes(2))
                return _accessToken;
            using var account = JsonDocument.Parse(_options.ServiceAccountJson!);
            var root = account.RootElement;
            var email = root.GetProperty("client_email").GetString()
                ?? throw new JsonException();
            var privateKey = root.GetProperty("private_key").GetString()
                ?? throw new JsonException();
            var tokenUri = root.TryGetProperty("token_uri", out var uri)
                ? uri.GetString()
                : "https://oauth2.googleapis.com/token";
            var now = DateTimeOffset.UtcNow;
            var handler = new JwtSecurityTokenHandler();
            using var rsa = RSA.Create();
            rsa.ImportFromPem(privateKey);
            var jwt = handler.CreateEncodedJwt(new SecurityTokenDescriptor
            {
                Issuer = email,
                Audience = tokenUri,
                NotBefore = now.UtcDateTime,
                IssuedAt = now.UtcDateTime,
                Expires = now.AddMinutes(55).UtcDateTime,
                Subject = null,
                Claims = new Dictionary<string, object>
                {
                    ["scope"] =
                        "https://www.googleapis.com/auth/firebase.messaging"
                },
                SigningCredentials = new SigningCredentials(
                    new RsaSecurityKey(rsa),
                    SecurityAlgorithms.RsaSha256)
            });
            using var response = await _http.PostAsync(
                tokenUri,
                new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"] =
                        "urn:ietf:params:oauth:grant-type:jwt-bearer",
                    ["assertion"] = jwt
                }),
                cancellationToken);
            response.EnsureSuccessStatusCode();
            using var tokenDocument = JsonDocument.Parse(
                await response.Content.ReadAsStreamAsync(cancellationToken));
            _accessToken = tokenDocument.RootElement
                .GetProperty("access_token")
                .GetString()
                ?? throw new JsonException();
            var seconds = tokenDocument.RootElement
                .GetProperty("expires_in")
                .GetInt32();
            _accessTokenExpiresAtUtc = DateTime.UtcNow.AddSeconds(seconds);
            return _accessToken;
        }
        finally
        {
            _tokenLock.Release();
        }
    }
}

public sealed class NotificationOutboxProcessor : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IPushNotificationChannel _channel;

    public NotificationOutboxProcessor(
        IServiceScopeFactory scopeFactory,
        IPushNotificationChannel channel)
    {
        _scopeFactory = scopeFactory;
        _channel = channel;
    }

    // The outbox isolates business transactions from external push-provider availability.
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(15));
        do
        {
            try { await ProcessAsync(stoppingToken); }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch
            {
                // The next bounded polling cycle retries safe pending recipients.
            }
        } while (await timer.WaitForNextTickAsync(stoppingToken));
    }

    private async Task ProcessAsync(CancellationToken cancellationToken)
    {
        using var scope = _scopeFactory.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<PhenyoSyncDbContext>();
        var settings = scope.ServiceProvider.GetRequiredService<ISystemSettingProvider>();
        var pushEnabled = await settings.GetBooleanAsync(
            SystemSettingKeys.NotificationsPushEnabled,
            cancellationToken);
        var maximumAttempts = await settings.GetIntAsync(
            SystemSettingKeys.NotificationsMaximumRetryCount,
            cancellationToken);
        var retryDelay = await settings.GetIntAsync(
            SystemSettingKeys.NotificationsRetryDelaySeconds,
            cancellationToken);
        var now = DateTime.UtcNow;
        var recipients = await context.OperationalNotificationRecipients
            .Include(item => item.Notification)
            .Where(item =>
                item.PushSentAtUtc == null &&
                item.DismissedAtUtc == null &&
                item.PushAttemptCount < maximumAttempts &&
                (item.NextPushAttemptAtUtc == null ||
                 item.NextPushAttemptAtUtc <= now))
            .OrderBy(item => item.Notification.CreatedAtUtc)
            .Take(50)
            .ToListAsync(cancellationToken);
        foreach (var recipient in recipients)
        {
            var preference = await context.NotificationPreferences.AsNoTracking()
                .SingleOrDefaultAsync(
                    item => item.UserId == recipient.UserId,
                    cancellationToken);
            var devices = await context.MobileDeviceRegistrations
                .Where(item =>
                    item.UserId == recipient.UserId &&
                    item.IsActive &&
                    item.PushToken != null)
                .ToListAsync(cancellationToken);
            if (!pushEnabled ||
                preference?.PushEnabled == false ||
                devices.Count == 0 ||
                !_channel.IsConfigured)
            {
                recipient.PushStatus = NotificationDeliveryStatuses.Disabled;
                continue;
            }

            var sent = false;
            foreach (var device in devices)
            {
                var result = await _channel.SendAsync(
                    device.PushToken!,
                    recipient.Notification,
                    cancellationToken);
                recipient.PushAttemptCount++;
                context.NotificationDeliveryAttempts.Add(
                    new NotificationDeliveryAttempt
                    {
                        OperationalNotificationRecipientId =
                            recipient.OperationalNotificationRecipientId,
                        Channel = "Push",
                        Provider = "Firebase",
                        Status = result.Status,
                        AttemptNumber = recipient.PushAttemptCount,
                        AttemptedAtUtc = DateTime.UtcNow,
                        CompletedAtUtc = DateTime.UtcNow,
                        SafeErrorCode = result.SafeErrorCode
                    });
                if (result.DeactivateToken)
                {
                    device.IsActive = false;
                    device.PushToken = null;
                    device.RevokedAtUtc = DateTime.UtcNow;
                    device.RevocationReason =
                        "Push provider rejected the registration token.";
                }
                sent |= result.Status == NotificationDeliveryStatuses.Sent;
            }

            recipient.PushStatus = sent
                ? NotificationDeliveryStatuses.Sent
                : NotificationDeliveryStatuses.Failed;
            recipient.PushSentAtUtc = sent ? DateTime.UtcNow : null;
            recipient.SafePushErrorCode = sent ? null : "PUSH_DELIVERY_FAILED";
            recipient.NextPushAttemptAtUtc = sent
                ? null
                : DateTime.UtcNow.AddSeconds(
                    retryDelay * Math.Max(1, recipient.PushAttemptCount));
        }
        await context.SaveChangesAsync(cancellationToken);
    }
}
