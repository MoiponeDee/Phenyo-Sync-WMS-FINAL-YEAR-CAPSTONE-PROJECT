using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Operational;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public interface IRawStockService
{
    Task<PagedResult<RawStockSummaryDto>> SearchAsync(
        RawStockSearchRequest request,
        CancellationToken cancellationToken);
    Task<int> CreateAsync(
        CreateRawStockRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<PartyDeleteResult> DeleteAsync(
        int id,
        string reason,
        int userId,
        CancellationToken cancellationToken);
    Task ChangeStatusAsync(
        int id,
        ChangeRawStockStatusRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<RawStockReceiptDto> ReceiveAsync(
        CreateRawStockReceiptRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<RawStockReceiptDto>> RecentReceiptsAsync(
        CancellationToken cancellationToken);
    Task<PagedResult<OperationalReasonDto>> SearchReasonsAsync(
        OperationalReasonSearchRequest request,
        CancellationToken cancellationToken);
    Task<OperationalReasonDto> SaveReasonAsync(
        int? id,
        SaveOperationalReasonRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<ReconciliationGroupDto>> GetReconciliationGroupsAsync(
        CancellationToken cancellationToken);
    Task<ReconciliationGroupDto> SaveReconciliationGroupAsync(
        int? id,
        ReconciliationGroupRequest request,
        int userId,
        CancellationToken cancellationToken);
}

/// <summary>
/// Maintains raw-stock master data, receipts, balances, batches and movement history.
/// Quantity-changing operations keep their document, balance and ledger rows atomic.
/// </summary>
public sealed class RawStockService : IRawStockService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _audit;
    private readonly IOperationalNotificationService? _notifications;
    private readonly ILogger<RawStockService>? _logger;

    public RawStockService(
        PhenyoSyncDbContext context,
        IAuditService audit,
        IOperationalNotificationService? notifications = null,
        ILogger<RawStockService>? logger = null)
    {
        _context = context;
        _audit = audit;
        _notifications = notifications;
        _logger = logger;
    }

    public async Task<PagedResult<RawStockSummaryDto>> SearchAsync(
        RawStockSearchRequest request,
        CancellationToken cancellationToken)
    {
        var query = _context.RawStockBalances
            .AsNoTracking()
            .Include(item => item.RawStockItem)
            .Include(item => item.WarehouseSection)
            .AsQueryable();

        if (!request.IncludeInactive)
            query = query.Where(item => item.RawStockItem.IsActive);

        var term = request.Search?.Trim();
        if (!string.IsNullOrWhiteSpace(term))
        {
            query = query.Where(item =>
                item.RawStockItem.ItemCode.Contains(term) ||
                item.RawStockItem.ItemName.Contains(term));
        }

        if (!string.IsNullOrWhiteSpace(request.CategoryCode))
        {
            var category = request.CategoryCode.Trim();
            query = query.Where(item => item.RawStockItem.CategoryCode == category);
        }

        if (!string.IsNullOrWhiteSpace(request.UnitOfMeasure))
        {
            var unit = request.UnitOfMeasure.Trim();
            query = query.Where(item => item.UnitOfMeasure == unit);
        }

        if (request.WarehouseSectionId.HasValue)
            query = query.Where(item =>
                item.WarehouseSectionId == request.WarehouseSectionId.Value);

        var total = await query.CountAsync(cancellationToken);
        var items = await query
            .OrderBy(item => item.RawStockItem.ItemName)
            .ThenBy(item => item.WarehouseSection.SectionName)
            .Skip((request.Page - 1) * request.PageSize)
            .Take(request.PageSize)
            .Select(item => new RawStockSummaryDto
            {
                RawStockItemId = item.RawStockItemId,
                ItemCode = item.RawStockItem.ItemCode,
                ItemName = item.RawStockItem.ItemName,
                CategoryCode = item.RawStockItem.CategoryCode,
                UnitOfMeasure = item.UnitOfMeasure,
                IsProduce = item.RawStockItem.IsProduce,
                IsActive = item.RawStockItem.IsActive,
                RawStockBalanceId = item.RawStockBalanceId,
                WarehouseSectionId = item.WarehouseSectionId,
                WarehouseSection = item.WarehouseSection.SectionName,
                QuantityOnHand = item.QuantityOnHand,
                ReservedQuantity = item.ReservedQuantity,
                WeightedAverageUnitCost = item.WeightedAverageUnitCost,
                LastReceiptAtUtc = item.LastReceiptAtUtc,
                LastStockTakeAtUtc = item.LastStockTakeAtUtc,
                HasCriticalAlert = item.QuantityOnHand <= item.ReservedQuantity,
                CanDelete = !item.RawStockItem.Batches.Any() &&
                            !item.RawStockItem.Movements.Any() &&
                            !_context.RawStockReceiptLines.Any(value =>
                                value.RawStockItemId == item.RawStockItemId) &&
                            !_context.SupplierOrderLines.Any(value =>
                                value.RawStockItemId == item.RawStockItemId) &&
                            !_context.ProductRawStockRequirements.Any(value =>
                                value.RawStockItemId == item.RawStockItemId) &&
                            !_context.RawStockTakeLines.Any(value =>
                                value.RawStockItemId == item.RawStockItemId) &&
                            !_context.RawStockWriteOffs.Any(value =>
                                value.RawStockItemId == item.RawStockItemId) &&
                            !_context.BuyerProcurementItems.Any(value =>
                                value.RawStockItemId == item.RawStockItemId ||
                                value.SubstituteRawStockItemId == item.RawStockItemId) &&
                            !_context.Set<PackingConversionRawStock>().Any(value =>
                                value.RawStockItemId == item.RawStockItemId) &&
                            !_context.RawStockBalances.Any(value =>
                                value.RawStockItemId == item.RawStockItemId &&
                                (value.QuantityOnHand != 0 ||
                                 value.ReservedQuantity != 0)),
                CanDeactivate = item.RawStockItem.IsActive,
                RowVersion = Encode(item.RowVersion)
            })
            .ToListAsync(cancellationToken);

        return new PagedResult<RawStockSummaryDto>
        {
            Items = items,
            Page = request.Page,
            PageSize = request.PageSize,
            Total = total
        };
    }

    public async Task<int> CreateAsync(
        CreateRawStockRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var code = Required(request.ItemCode).ToUpperInvariant();
        var category = Required(request.CategoryCode);
        var unit = Required(request.UnitOfMeasure).ToLowerInvariant();

        if (!RawStockCategories.All.Contains(category))
            throw new PhaseCException(400, "Select a supported raw-stock category.");
        if (!RawStockUnits.All.Contains(unit))
            throw new PhaseCException(400, "Select a supported unit of measure.");
        if (request.BestBeforeAtUtc.HasValue && category != RawStockCategories.Produce)
            throw new PhaseCException(400, "Best-before dates are only valid for produce raw stock.");
        if (request.InitialQuantity > 0 &&
            (!request.InitialUnitCost.HasValue || request.InitialUnitCost <= 0))
            throw new PhaseCException(
                400,
                "A positive opening unit cost is required when opening quantity is entered.");
        if (await _context.RawStockItems.AnyAsync(
                item => item.ItemCode == code,
                cancellationToken))
            throw new PhaseCException(409, "A raw-stock item with this code already exists.");

        var warehouseExists = await _context.WarehouseSections.AnyAsync(
            item => item.SectionId == request.WarehouseSectionId &&
                    item.Status == "Active",
            cancellationToken);
        if (!warehouseExists)
            throw new PhaseCException(400, "Select an active warehouse section.");

        await using var transaction =
            await _context.Database.BeginTransactionAsync(cancellationToken);
        var now = DateTime.UtcNow;
        var correlationId = Guid.NewGuid().ToString("N");
        var item = new RawStockItem
        {
            ItemCode = code,
            ItemName = Required(request.ItemName),
            CategoryCode = category,
            DefaultUnitOfMeasure = unit,
            IsProduce = category == RawStockCategories.Produce,
            IsActive = true,
            CreatedAtUtc = now
        };
        _context.RawStockItems.Add(item);
        await _context.SaveChangesAsync(cancellationToken);

        var balance = new RawStockBalance
        {
            RawStockItemId = item.RawStockItemId,
            WarehouseSectionId = request.WarehouseSectionId,
            UnitOfMeasure = unit,
            QuantityOnHand = request.InitialQuantity,
            WeightedAverageUnitCost = request.InitialQuantity > 0
                ? request.InitialUnitCost
                : null
        };
        _context.RawStockBalances.Add(balance);
        await _context.SaveChangesAsync(cancellationToken);

        if (request.InitialQuantity > 0)
        {
            var batchCode = $"OPEN-{item.ItemCode}-{now:yyyyMMddHHmmss}";
            var batch = new RawStockBatch
            {
                RawStockItemId = item.RawStockItemId,
                RawStockBalanceId = balance.RawStockBalanceId,
                BatchCode = batchCode,
                QrCodeValue = $"PHENYO:RAW:{batchCode}",
                QuantityReceived = request.InitialQuantity,
                QuantityRemaining = request.InitialQuantity,
                UnitCost = request.InitialUnitCost!.Value,
                ReceivedAtUtc = now,
                BestBeforeAtUtc = request.BestBeforeAtUtc?.ToUniversalTime(),
                Status = ProductBatchStatuses.Available
            };
            _context.RawStockBatches.Add(batch);
            _context.RawStockMovements.Add(new RawStockMovement
            {
                RawStockItemId = item.RawStockItemId,
                RawStockBalanceId = balance.RawStockBalanceId,
                RawStockBatch = batch,
                CreatedByUserId = userId,
                MovementType = RawStockMovementTypes.OpeningBalance,
                QuantityChange = request.InitialQuantity,
                UnitCost = request.InitialUnitCost.Value,
                OccurredAtUtc = now,
                SourceType = nameof(RawStockItem),
                SourceId = item.RawStockItemId.ToString(),
                ReasonText = Required(request.Reason),
                CorrelationId = correlationId
            });
        }

        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Create,
            "Create raw stock",
            nameof(RawStockItem),
            item.RawStockItemId,
            item.ItemName,
            userId,
            new Dictionary<string, object?>
            {
                ["itemCode"] = item.ItemCode,
                ["category"] = category,
                ["initialQuantity"] = request.InitialQuantity,
                ["reason"] = request.Reason,
                ["correlationId"] = correlationId
            },
            cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return item.RawStockItemId;
    }

    public async Task<PartyDeleteResult> DeleteAsync(
        int id,
        string reason,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await _context.RawStockItems.SingleOrDefaultAsync(
                value => value.RawStockItemId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock item not found.");

        var hasHistory = await _context.RawStockBatches.AnyAsync(
                value => value.RawStockItemId == id,
                cancellationToken) ||
            await _context.RawStockMovements.AnyAsync(
                value => value.RawStockItemId == id,
                cancellationToken) ||
            await _context.RawStockReceiptLines.AnyAsync(
                value => value.RawStockItemId == id,
                cancellationToken) ||
            await _context.SupplierOrderLines.AnyAsync(
                value => value.RawStockItemId == id,
                cancellationToken) ||
            await _context.ProductRawStockRequirements.AnyAsync(
                value => value.RawStockItemId == id,
                cancellationToken) ||
            await _context.RawStockTakeLines.AnyAsync(
                value => value.RawStockItemId == id,
                cancellationToken) ||
            await _context.RawStockWriteOffs.AnyAsync(
                value => value.RawStockItemId == id,
                cancellationToken) ||
            await _context.BuyerProcurementItems.AnyAsync(
                value => value.RawStockItemId == id ||
                         value.SubstituteRawStockItemId == id,
                cancellationToken) ||
            await _context.Set<PackingConversionRawStock>().AnyAsync(
                value => value.RawStockItemId == id,
                cancellationToken);
        if (hasHistory)
        {
            return new PartyDeleteResult(
                false,
                "This raw-stock item has business history and cannot be permanently deleted.",
                "Receipts, recipes, stock movements, counts, write-offs, buying activity, or production history must be retained.",
                item.IsActive);
        }

        var balances = await _context.RawStockBalances
            .Where(value => value.RawStockItemId == id)
            .ToListAsync(cancellationToken);
        if (balances.Any(value =>
                value.QuantityOnHand != 0 || value.ReservedQuantity != 0))
        {
            return new PartyDeleteResult(
                false,
                "This raw-stock item still has a quantity balance.",
                "Reduce every on-hand and reserved quantity through the normal stock workflow first.",
                item.IsActive);
        }

        var groupLinks = await _context.RawStockReconciliationGroupItems
            .Where(value => value.RawStockItemId == id)
            .ToListAsync(cancellationToken);
        _context.RawStockReconciliationGroupItems.RemoveRange(groupLinks);
        _context.RawStockBalances.RemoveRange(balances);
        _context.RawStockItems.Remove(item);
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Delete,
            "Delete unused raw stock",
            nameof(RawStockItem),
            id,
            item.ItemName,
            userId,
            new Dictionary<string, object?> { ["reason"] = Required(reason) },
            cancellationToken);
        return new PartyDeleteResult(
            true,
            "Unused raw-stock item permanently deleted.",
            null,
            false);
    }

    public async Task ChangeStatusAsync(
        int id,
        ChangeRawStockStatusRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var item = await _context.RawStockItems.SingleOrDefaultAsync(
                value => value.RawStockItemId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock item not found.");
        item.IsActive = request.IsActive;
        item.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            request.IsActive ? AuditActionTypes.Activate : AuditActionTypes.Deactivate,
            request.IsActive ? "Activate raw stock" : "Deactivate raw stock",
            nameof(RawStockItem),
            id,
            item.ItemName,
            userId,
            new Dictionary<string, object?> { ["reason"] = Required(request.Reason) },
            cancellationToken);
    }

    public async Task<RawStockReceiptDto> ReceiveAsync(
        CreateRawStockReceiptRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Source documents are authoritative: every line must reconcile to the selected order/list.
        if (request.SourceType is not (
                RawStockReceiptSources.SupplierOrder or
                RawStockReceiptSources.BuyingList))
            throw new PhaseCException(
                400,
                "Receive Raw Stock from a Supplier Order or submitted Buying List.");
        if (request.Lines.Count == 0)
            throw new PhaseCException(400, "Add at least one receipt line.");
        if (request.Lines.Any(line =>
                line.AcceptedQuantity + line.RejectedQuantity != line.QuantityReceived))
            throw new PhaseCException(
                400,
                "Every receipt line must reconcile accepted and rejected quantities.");
        if (request.SourceType == RawStockReceiptSources.SupplierOrder &&
            !request.SupplierOrderId.HasValue)
            throw new PhaseCException(400, "A supplier order is required for this source.");
        if (request.SourceType == RawStockReceiptSources.SupplierOrder &&
            request.Lines.Any(item => !item.SupplierOrderLineId.HasValue))
            throw new PhaseCException(
                400,
                "Each Supplier Order receipt line must identify its source line.");
        if (request.SourceType == RawStockReceiptSources.BuyingList &&
            !request.BuyerProcurementId.HasValue)
            throw new PhaseCException(400, "A submitted buying list is required for this source.");
        if (request.SourceType == RawStockReceiptSources.BuyingList &&
            request.Lines.Any(item => !item.BuyerProcurementItemId.HasValue))
            throw new PhaseCException(
                400,
                "Each Buying List receipt line must identify its source item.");

        // A stable operation key makes a safe mobile retry return the committed receipt.
        var operationHash = Hash(request.OperationId);
        var existingId = await _context.RawStockReceipts
            .Where(item => item.OperationKeyHash == operationHash)
            .Select(item => (long?)item.RawStockReceiptId)
            .FirstOrDefaultAsync(cancellationToken);
        if (existingId.HasValue)
            return await ReceiptAsync(existingId.Value, cancellationToken);

        var warehouseExists = await _context.WarehouseSections.AnyAsync(
            item => item.SectionId == request.WarehouseSectionId &&
                    item.Status == "Active",
            cancellationToken);
        if (!warehouseExists)
            throw new PhaseCException(400, "Select an active warehouse section.");

        SupplierOrder? supplierOrder = null;
        int? derivedSupplierId = null;
        if (request.SupplierOrderId.HasValue)
        {
            supplierOrder = await _context.SupplierOrders
                .Include(item => item.Lines)
                .SingleOrDefaultAsync(
                    item => item.SupplierOrderId == request.SupplierOrderId,
                    cancellationToken);
            if (supplierOrder is null ||
                !SupplierOrderStatuses.Receivable.Contains(supplierOrder.Status))
                throw new PhaseCException(409, "The selected supplier order cannot be received.");
            derivedSupplierId = supplierOrder.SupplierId;

            foreach (var requestLine in request.Lines)
            {
                var orderLine = supplierOrder.Lines.SingleOrDefault(item =>
                        item.SupplierOrderLineId == requestLine.SupplierOrderLineId)
                    ?? throw new PhaseCException(
                        409,
                        "A receipt line is not part of the selected Supplier Order.");
                if (orderLine.RawStockItemId != requestLine.RawStockItemId)
                    throw new PhaseCException(
                        409,
                        "The received raw-stock item does not match its Supplier Order line.");
                if (!orderLine.UnitOfMeasure.Equals(
                        requestLine.UnitOfMeasure,
                        StringComparison.OrdinalIgnoreCase))
                    throw new PhaseCException(
                        409,
                        "The received unit of measure does not match the Supplier Order line.");
                if (orderLine.ReceivedQuantity + requestLine.AcceptedQuantity >
                    orderLine.OrderedQuantity)
                    throw new PhaseCException(
                        409,
                        "The receipt quantity exceeds the outstanding quantity for the selected Supplier Order line.");
            }
        }

        BuyerProcurement? buyingList = null;
        if (request.BuyerProcurementId.HasValue)
        {
            buyingList = await _context.BuyerProcurements
                .Include(item => item.Items)
                .SingleOrDefaultAsync(
                    item =>
                        item.BuyerProcurementId ==
                        request.BuyerProcurementId.Value,
                    cancellationToken);
            if (buyingList is null ||
                !BuyingListStatuses.Receivable.Contains(buyingList.Status))
                throw new PhaseCException(409, "The selected buying list is not submitted.");

            var sourceSupplierIds = request.Lines
                .Select(requestLine => buyingList.Items.SingleOrDefault(item =>
                    item.BuyerProcurementItemId == requestLine.BuyerProcurementItemId))
                .Where(item => item is not null)
                .Select(item => item!.SupplierId)
                .Distinct()
                .ToArray();
            if (sourceSupplierIds.Length > 1)
                throw new PhaseCException(
                    409,
                    "Receive Buying List lines from different suppliers as separate receipts.");
            derivedSupplierId = sourceSupplierIds.SingleOrDefault();

            foreach (var requestLine in request.Lines)
            {
                var sourceLine = buyingList.Items.SingleOrDefault(item =>
                        item.BuyerProcurementItemId ==
                        requestLine.BuyerProcurementItemId)
                    ?? throw new PhaseCException(
                        409,
                        "A receipt line is not part of the selected Buying List.");
                var receivedRawStockItemId =
                    sourceLine.SubstituteRawStockItemId ??
                    sourceLine.RawStockItemId;
                if (receivedRawStockItemId != requestLine.RawStockItemId)
                    throw new PhaseCException(
                        409,
                        "The receipt item does not match its Buying List line.");
                if (sourceLine.Status is not (
                        BuyingItemStatuses.Purchased or
                        BuyingItemStatuses.Substituted))
                    throw new PhaseCException(
                        409,
                        "Only purchased or substituted lines can be received.");
                var authorised = sourceLine.ActualQuantity ?? 0;
                if (sourceLine.ReceivedQuantity +
                    requestLine.AcceptedQuantity > authorised)
                    throw new PhaseCException(
                        409,
                        "The receipt exceeds the outstanding quantity for the selected Buying List line.");
            }
        }

        Supplier? supplier = null;
        if (derivedSupplierId.HasValue)
        {
            supplier = await _context.Suppliers.SingleOrDefaultAsync(
                item => item.SupplierId == derivedSupplierId.Value &&
                        item.Status == "Active",
                cancellationToken);
            if (supplier is null)
                throw new PhaseCException(400, "The source document references an unavailable supplier.");
        }
        else if (request.SourceType != RawStockReceiptSources.BuyingList)
        {
            throw new PhaseCException(400, "The selected source requires an active supplier.");
        }

        var rawStockIds = request.Lines
            .Select(item => item.RawStockItemId)
            .Distinct()
            .ToArray();
        var rawItems = await _context.RawStockItems
            .Where(item => rawStockIds.Contains(item.RawStockItemId) && item.IsActive)
            .ToDictionaryAsync(item => item.RawStockItemId, cancellationToken);
        if (rawItems.Count != rawStockIds.Length)
            throw new PhaseCException(400, "One or more raw-stock items are unavailable.");
        if (request.Lines.Any(line => line.UnitCost <= 0))
            throw new PhaseCException(
                400,
                "Every received stock line requires a positive unit cost.");

        // Receipt header, batches, balances, source progress and ledger entries commit together.
        await using var transaction =
            await _context.Database.BeginTransactionAsync(cancellationToken);
        var now = DateTime.UtcNow;
        var correlationId = Guid.NewGuid().ToString("N");
        var receipt = new RawStockReceipt
        {
            ReceiptNumber = $"RSR-{now:yyyyMMdd}-{Guid.NewGuid():N}"[..21].ToUpperInvariant(),
            SourceType = request.SourceType,
            SupplierId = derivedSupplierId,
            SupplierOrderId = request.SupplierOrderId,
            BuyerProcurementId = request.BuyerProcurementId,
            WarehouseSectionId = request.WarehouseSectionId,
            ReceivedByUserId = userId,
            DocketReference = Required(request.DocketReference),
            AdHocExplanation = Clean(request.AdHocExplanation),
            Notes = Clean(request.Notes),
            ReceivedAtUtc = request.ReceivedAtUtc == default
                ? now
                : request.ReceivedAtUtc.ToUniversalTime(),
            CreatedAtUtc = now,
            PostedAtUtc = now,
            Status = MobileOperationStatuses.Completed,
            CorrelationId = correlationId,
            OperationKeyHash = operationHash
        };
        _context.RawStockReceipts.Add(receipt);
        await _context.SaveChangesAsync(cancellationToken);

        foreach (var requestLine in request.Lines)
        {
            var rawItem = rawItems[requestLine.RawStockItemId];
            var unit = Required(requestLine.UnitOfMeasure).ToLowerInvariant();
            if (!RawStockUnits.All.Contains(unit) ||
                !unit.Equals(rawItem.DefaultUnitOfMeasure, StringComparison.OrdinalIgnoreCase))
                throw new PhaseCException(
                    400,
                    $"Unit of measure for {rawItem.ItemName} must be {rawItem.DefaultUnitOfMeasure}.");

            var balance = await _context.RawStockBalances.SingleOrDefaultAsync(
                item => item.RawStockItemId == rawItem.RawStockItemId &&
                        item.WarehouseSectionId == request.WarehouseSectionId,
                cancellationToken);
            if (balance is null)
            {
                balance = new RawStockBalance
                {
                    RawStockItemId = rawItem.RawStockItemId,
                    WarehouseSectionId = request.WarehouseSectionId,
                    UnitOfMeasure = unit
                };
                _context.RawStockBalances.Add(balance);
                await _context.SaveChangesAsync(cancellationToken);
            }

            var oldQuantity = balance.QuantityOnHand;
            var acceptedValue = requestLine.AcceptedQuantity * requestLine.UnitCost;
            balance.QuantityOnHand += requestLine.AcceptedQuantity;
            if (oldQuantity <= 0)
            {
                balance.WeightedAverageUnitCost = requestLine.UnitCost;
            }
            else if (balance.WeightedAverageUnitCost.HasValue)
            {
                var oldValue =
                    oldQuantity * balance.WeightedAverageUnitCost.Value;
                balance.WeightedAverageUnitCost =
                    (oldValue + acceptedValue) / balance.QuantityOnHand;
            }
            balance.LastReceiptAtUtc = receipt.ReceivedAtUtc;

            var line = new RawStockReceiptLine
            {
                RawStockReceiptId = receipt.RawStockReceiptId,
                RawStockItemId = rawItem.RawStockItemId,
                SupplierOrderLineId = requestLine.SupplierOrderLineId,
                BuyerProcurementItemId =
                    requestLine.BuyerProcurementItemId,
                QuantityReceived = requestLine.QuantityReceived,
                AcceptedQuantity = requestLine.AcceptedQuantity,
                RejectedQuantity = requestLine.RejectedQuantity,
                UnitCost = requestLine.UnitCost,
                UnitOfMeasure = unit,
                SupplierBatchReference = Clean(requestLine.SupplierBatchReference),
                BestBeforeAtUtc = requestLine.BestBeforeAtUtc?.ToUniversalTime(),
                Notes = Clean(requestLine.Notes)
            };
            _context.RawStockReceiptLines.Add(line);
            await _context.SaveChangesAsync(cancellationToken);

            if (requestLine.AcceptedQuantity > 0)
            {
                var batchCode =
                    $"RAW-{rawItem.ItemCode}-{receipt.RawStockReceiptId}-{line.RawStockReceiptLineId}";
                var batch = new RawStockBatch
                {
                    RawStockItemId = rawItem.RawStockItemId,
                    RawStockBalanceId = balance.RawStockBalanceId,
                    SupplierId = supplier?.SupplierId,
                    RawStockReceiptLineId = line.RawStockReceiptLineId,
                    BatchCode = batchCode,
                    QrCodeValue = $"PHENYO:RAW:{batchCode}",
                    QuantityReceived = requestLine.AcceptedQuantity,
                    QuantityRemaining = requestLine.AcceptedQuantity,
                    UnitCost = requestLine.UnitCost,
                    ReceivedAtUtc = receipt.ReceivedAtUtc,
                    BestBeforeAtUtc = requestLine.BestBeforeAtUtc?.ToUniversalTime(),
                    Status = ProductBatchStatuses.Available
                };
                _context.RawStockBatches.Add(batch);
                _context.RawStockMovements.Add(new RawStockMovement
                {
                    RawStockItemId = rawItem.RawStockItemId,
                    RawStockBalanceId = balance.RawStockBalanceId,
                    RawStockBatch = batch,
                    CreatedByUserId = userId,
                    MovementType = RawStockMovementTypes.Receipt,
                    QuantityChange = requestLine.AcceptedQuantity,
                    UnitCost = requestLine.UnitCost,
                    OccurredAtUtc = receipt.ReceivedAtUtc,
                    SourceType = nameof(RawStockReceipt),
                    SourceId = receipt.RawStockReceiptId.ToString(),
                    ReasonText = $"Received against {receipt.DocketReference}.",
                    CorrelationId = correlationId
                });
            }

            if (supplierOrder is not null)
            {
                var orderLine = supplierOrder.Lines.SingleOrDefault(item =>
                    item.SupplierOrderLineId == requestLine.SupplierOrderLineId)!;
                orderLine.ReceivedQuantity += requestLine.AcceptedQuantity;
            }

            if (buyingList is not null)
            {
                var sourceLine = buyingList.Items.Single(item =>
                    item.BuyerProcurementItemId ==
                    requestLine.BuyerProcurementItemId);
                sourceLine.ReceivedQuantity += requestLine.AcceptedQuantity;
                sourceLine.UpdatedAtUtc = now;
            }
        }

        if (supplierOrder is not null)
        {
            supplierOrder.Status = supplierOrder.Lines.All(item =>
                item.ReceivedQuantity >= item.OrderedQuantity)
                    ? SupplierOrderStatuses.FullyReceived
                    : SupplierOrderStatuses.PartiallyReceived;
        }

        if (buyingList is not null)
        {
            var receivable = buyingList.Items
                .Where(item =>
                    item.Status is BuyingItemStatuses.Purchased or
                        BuyingItemStatuses.Substituted)
                .ToList();
            buyingList.Status = receivable.All(item =>
                item.ReceivedQuantity >= (item.ActualQuantity ?? 0))
                    ? BuyingListStatuses.Completed
                    : BuyingListStatuses.PartiallyReceived;
            buyingList.UpdatedAtUtc = now;
        }

        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.IncreaseStock,
            "Receive raw stock",
            nameof(RawStockReceipt),
            receipt.RawStockReceiptId,
            receipt.ReceiptNumber,
            userId,
            new Dictionary<string, object?>
            {
                ["source"] = receipt.SourceType,
                ["supplierId"] = receipt.SupplierId,
                ["lineCount"] = request.Lines.Count,
                ["docketReference"] = receipt.DocketReference,
                ["correlationId"] = correlationId
            },
            cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        if (buyingList is not null && _notifications is not null)
        {
            var completed =
                buyingList.Status == BuyingListStatuses.Completed;
            try
            {
                await _notifications.PublishToRolesAsync(
                    completed
                        ? "BuyingListReceived"
                        : "BuyingListPartiallyReceived",
                    completed ? "Success" : "Info",
                    completed
                        ? "Buying List fully received"
                        : "Buying List partially received",
                    $"{buyingList.ReferenceNumber} was " +
                    (completed ? "fully received." : "partially received."),
                    [
                        RoleCodes.WarehouseManager,
                        RoleCodes.BusinessManager
                    ],
                    nameof(BuyerProcurement),
                    buyingList.BuyerProcurementId.ToString(),
                    $"/buying-lists/{buyingList.BuyerProcurementId}",
                    userId,
                    correlationId,
                    cancellationToken);
            }
            catch (Exception exception)
            {
                _logger?.LogWarning(
                    exception,
                    "Receipt {ReceiptNumber} committed, but its non-critical notification failed.",
                    receipt.ReceiptNumber);
            }
        }
        return await ReceiptAsync(receipt.RawStockReceiptId, cancellationToken);
    }

    public async Task<IReadOnlyList<RawStockReceiptDto>> RecentReceiptsAsync(
        CancellationToken cancellationToken)
    {
        var ids = await _context.RawStockReceipts.AsNoTracking()
            .OrderByDescending(item => item.ReceivedAtUtc)
            .Take(50)
            .Select(item => item.RawStockReceiptId)
            .ToListAsync(cancellationToken);
        var result = new List<RawStockReceiptDto>();
        foreach (var id in ids)
            result.Add(await ReceiptAsync(id, cancellationToken));
        return result;
    }

    public async Task<PagedResult<OperationalReasonDto>> SearchReasonsAsync(
        OperationalReasonSearchRequest request,
        CancellationToken cancellationToken)
    {
        var query = _context.OperationalReasons.AsNoTracking().AsQueryable();
        if (!request.IncludeInactive)
            query = query.Where(item => item.IsActive);
        if (!string.IsNullOrWhiteSpace(request.CategoryCode))
        {
            var category = request.CategoryCode.Trim();
            query = query.Where(item => item.CategoryCode == category);
        }
        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var term = request.Search.Trim();
            query = query.Where(item =>
                item.ReasonCode.Contains(term) ||
                item.ReasonName.Contains(term));
        }

        var total = await query.CountAsync(cancellationToken);
        var items = await query
            .OrderBy(item => item.CategoryCode)
            .ThenBy(item => item.ReasonName)
            .Skip((request.Page - 1) * request.PageSize)
            .Take(request.PageSize)
            .Select(item => new OperationalReasonDto
            {
                OperationalReasonId = item.OperationalReasonId,
                ReasonCode = item.ReasonCode,
                ReasonName = item.ReasonName,
                CategoryCode = item.CategoryCode,
                Description = item.Description,
                IsActive = item.IsActive,
                IsInUse = _context.RawStockMovements.Any(movement =>
                              movement.OperationalReasonId == item.OperationalReasonId) ||
                          _context.RawStockWriteOffs.Any(writeOff =>
                              writeOff.OperationalReasonId == item.OperationalReasonId),
                RowVersion = Encode(item.RowVersion)
            })
            .ToListAsync(cancellationToken);
        return new PagedResult<OperationalReasonDto>
        {
            Items = items,
            Page = request.Page,
            PageSize = request.PageSize,
            Total = total
        };
    }

    public async Task<OperationalReasonDto> SaveReasonAsync(
        int? id,
        SaveOperationalReasonRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Reasons are governed reference data; historical movements keep their original linkage.
        var code = Required(request.ReasonCode).ToUpperInvariant();
        var duplicate = await _context.OperationalReasons.AnyAsync(
            item => item.ReasonCode == code &&
                    (!id.HasValue || item.OperationalReasonId != id.Value),
            cancellationToken);
        if (duplicate)
            throw new PhaseCException(409, "An operational reason with this code already exists.");

        OperationalReason entity;
        if (id.HasValue)
        {
            entity = await _context.OperationalReasons.SingleOrDefaultAsync(
                    item => item.OperationalReasonId == id.Value,
                    cancellationToken)
                ?? throw new PhaseCException(404, "Operational reason not found.");
            ValidateVersion(entity.RowVersion, request.RowVersion);
            entity.UpdatedAtUtc = DateTime.UtcNow;
        }
        else
        {
            entity = new OperationalReason { CreatedAtUtc = DateTime.UtcNow };
            _context.OperationalReasons.Add(entity);
        }

        entity.ReasonCode = code;
        entity.ReasonName = Required(request.ReasonName);
        entity.CategoryCode = Required(request.CategoryCode);
        entity.Description = Clean(request.Description);
        entity.IsActive = request.IsActive;
        await SaveConcurrencyAsync(cancellationToken);
        await AuditAsync(
            id.HasValue ? AuditActionTypes.Update : AuditActionTypes.Create,
            id.HasValue ? "Update operational reason" : "Create operational reason",
            nameof(OperationalReason),
            entity.OperationalReasonId,
            entity.ReasonName,
            userId,
            new Dictionary<string, object?>
            {
                ["reasonCode"] = entity.ReasonCode,
                ["category"] = entity.CategoryCode,
                ["active"] = entity.IsActive
            },
            cancellationToken);

        return new OperationalReasonDto
        {
            OperationalReasonId = entity.OperationalReasonId,
            ReasonCode = entity.ReasonCode,
            ReasonName = entity.ReasonName,
            CategoryCode = entity.CategoryCode,
            Description = entity.Description,
            IsActive = entity.IsActive,
            IsInUse = false,
            RowVersion = Encode(entity.RowVersion)
        };
    }

    public async Task<IReadOnlyList<ReconciliationGroupDto>>
        GetReconciliationGroupsAsync(CancellationToken cancellationToken) =>
        await _context.RawStockReconciliationGroups
            .AsNoTracking()
            .Include(item => item.RawStockItems)
                .ThenInclude(item => item.RawStockItem)
            .Include(item => item.Products)
                .ThenInclude(item => item.Product)
            .OrderBy(item => item.GroupName)
            .Select(item => new ReconciliationGroupDto
            {
                RawStockReconciliationGroupId = item.RawStockReconciliationGroupId,
                GroupCode = item.GroupCode,
                GroupName = item.GroupName,
                RawStockItems = item.RawStockItems
                    .OrderBy(link => link.RawStockItem.ItemName)
                    .Select(link => link.RawStockItem.ItemName)
                    .ToArray(),
                Products = item.Products
                    .OrderBy(link => link.Product.ProductName)
                    .Select(link => link.Product.ProductName)
                    .ToArray()
            })
            .ToListAsync(cancellationToken);

    public async Task<ReconciliationGroupDto> SaveReconciliationGroupAsync(
        int? id,
        ReconciliationGroupRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Reconciliation groups define control thresholds only; they do not alter stock themselves.
        var rawIds = request.RawStockItemIds.Distinct().ToArray();
        var productIds = request.ProductIds.Distinct().ToArray();
        if (rawIds.Length == 0 || productIds.Length == 0)
            throw new PhaseCException(
                400,
                "A reconciliation group needs at least one raw-stock item and one finished product.");
        if (await _context.RawStockItems.CountAsync(
                item => rawIds.Contains(item.RawStockItemId) && item.IsActive,
                cancellationToken) != rawIds.Length ||
            await _context.Products.CountAsync(
                item => productIds.Contains(item.ProductId) &&
                        item.Status == ProductStatuses.Active,
                cancellationToken) != productIds.Length)
            throw new PhaseCException(400, "One or more reconciliation records are unavailable.");

        var code = Required(request.GroupCode).ToUpperInvariant();
        if (await _context.RawStockReconciliationGroups.AnyAsync(
                item => item.GroupCode == code &&
                        (!id.HasValue ||
                         item.RawStockReconciliationGroupId != id.Value),
                cancellationToken))
            throw new PhaseCException(409, "A reconciliation group with this code already exists.");

        await using var transaction =
            await _context.Database.BeginTransactionAsync(cancellationToken);
        RawStockReconciliationGroup group;
        if (id.HasValue)
        {
            group = await _context.RawStockReconciliationGroups
                .Include(item => item.RawStockItems)
                .Include(item => item.Products)
                .SingleOrDefaultAsync(
                    item => item.RawStockReconciliationGroupId == id.Value,
                    cancellationToken)
                ?? throw new PhaseCException(404, "Reconciliation group not found.");
            _context.RawStockReconciliationGroupItems.RemoveRange(group.RawStockItems);
            _context.ProductReconciliationMappings.RemoveRange(group.Products);
        }
        else
        {
            group = new RawStockReconciliationGroup();
            _context.RawStockReconciliationGroups.Add(group);
        }

        group.GroupCode = code;
        group.GroupName = Required(request.GroupName);
        group.Description = Clean(request.Description);
        group.IsActive = true;
        group.RawStockItems = rawIds.Select(rawId =>
            new RawStockReconciliationGroupItem
            {
                RawStockItemId = rawId
            }).ToList();
        group.Products = productIds.Select(productId =>
            new ProductReconciliationMapping
            {
                ProductId = productId
            }).ToList();
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            id.HasValue ? AuditActionTypes.Update : AuditActionTypes.Create,
            id.HasValue ? "Update reconciliation group" : "Create reconciliation group",
            nameof(RawStockReconciliationGroup),
            group.RawStockReconciliationGroupId,
            group.GroupName,
            userId,
            new Dictionary<string, object?>
            {
                ["rawStockItemIds"] = rawIds,
                ["productIds"] = productIds
            },
            cancellationToken);
        await transaction.CommitAsync(cancellationToken);

        return (await GetReconciliationGroupsAsync(cancellationToken))
            .Single(item =>
                item.RawStockReconciliationGroupId ==
                group.RawStockReconciliationGroupId);
    }

    private async Task<RawStockReceiptDto> ReceiptAsync(
        long id,
        CancellationToken cancellationToken)
    {
        var receipt = await _context.RawStockReceipts
            .AsNoTracking()
            .Include(item => item.Supplier)
            .Include(item => item.SupplierOrder)
            .Include(item => item.WarehouseSection)
            .Include(item => item.Lines)
                .ThenInclude(item => item.RawStockItem)
            .Include(item => item.Lines)
                .ThenInclude(item => item.Batch)
            .SingleOrDefaultAsync(
                item => item.RawStockReceiptId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Raw-stock receipt not found.");

        return new RawStockReceiptDto
        {
            RawStockReceiptId = receipt.RawStockReceiptId,
            ReceiptNumber = receipt.ReceiptNumber,
            SourceType = receipt.SourceType,
            SupplierName = receipt.Supplier?.SupplierName ??
                           "Market Purchase / Not applicable",
            SupplierOrderNumber = receipt.SupplierOrder?.OrderNumber,
            BuyerProcurementId = receipt.BuyerProcurementId,
            WarehouseSection = receipt.WarehouseSection.SectionName,
            DocketReference = receipt.DocketReference,
            Status = receipt.Status,
            ReceivedAtUtc = receipt.ReceivedAtUtc,
            PostedAtUtc = receipt.PostedAtUtc,
            CorrelationId = receipt.CorrelationId,
            Lines = receipt.Lines.OrderBy(item => item.RawStockItem.ItemName)
                .Select(item => new RawStockReceiptLineDto
                {
                    RawStockReceiptLineId = item.RawStockReceiptLineId,
                    RawStockItemId = item.RawStockItemId,
                    SupplierOrderLineId = item.SupplierOrderLineId,
                    BuyerProcurementItemId = item.BuyerProcurementItemId,
                    ItemCode = item.RawStockItem.ItemCode,
                    ItemName = item.RawStockItem.ItemName,
                    QuantityReceived = item.QuantityReceived,
                    AcceptedQuantity = item.AcceptedQuantity,
                    RejectedQuantity = item.RejectedQuantity,
                    UnitCost = item.UnitCost,
                    UnitOfMeasure = item.UnitOfMeasure,
                    BatchCode = item.Batch?.BatchCode,
                    QrCodeValue = item.Batch?.QrCodeValue
                })
                .ToArray()
        };
    }

    private async Task AuditAsync(
        string action,
        string operation,
        string entityType,
        object entityId,
        string display,
        int userId,
        IReadOnlyDictionary<string, object?> details,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = AuditModules.RawStock,
            OperationName = operation,
            Description = $"{operation}: {display}.",
            EntityType = entityType,
            EntityId = entityId.ToString(),
            EntityDisplay = display,
            UserId = userId,
            SafeDetails = details
        }, cancellationToken);

    private async Task SaveConcurrencyAsync(CancellationToken cancellationToken)
    {
        try
        {
            await _context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new PhaseCException(
                409,
                "This record changed since it was loaded. Reload and try again.");
        }
    }

    private static void ValidateVersion(byte[]? current, string? supplied)
    {
        if (current is null || string.IsNullOrWhiteSpace(supplied))
            return;
        try
        {
            if (!CryptographicOperations.FixedTimeEquals(
                    current,
                    Convert.FromBase64String(supplied)))
                throw new PhaseCException(
                    409,
                    "This record changed since it was loaded. Reload and try again.");
        }
        catch (FormatException)
        {
            throw new PhaseCException(400, "The concurrency token is invalid.");
        }
    }

    private static string Encode(byte[]? value) =>
        value is null ? string.Empty : Convert.ToBase64String(value);

    private static string Hash(string value) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Required(value))));

    private static string Required(string value) =>
        string.IsNullOrWhiteSpace(value)
            ? throw new PhaseCException(400, "A required value is missing.")
            : value.Trim();

    private static string? Clean(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
