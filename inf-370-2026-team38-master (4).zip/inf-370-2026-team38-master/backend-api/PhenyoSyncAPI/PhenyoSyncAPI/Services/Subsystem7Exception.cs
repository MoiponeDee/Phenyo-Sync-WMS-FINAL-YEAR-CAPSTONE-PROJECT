namespace PhenyoSyncAPI.Services
{
    public class Subsystem7Exception : Exception
    {
        public Subsystem7Exception(int statusCode, string message)
            : base(message)
        {
            StatusCode = statusCode;
        }

        public int StatusCode { get; }
    }
}
