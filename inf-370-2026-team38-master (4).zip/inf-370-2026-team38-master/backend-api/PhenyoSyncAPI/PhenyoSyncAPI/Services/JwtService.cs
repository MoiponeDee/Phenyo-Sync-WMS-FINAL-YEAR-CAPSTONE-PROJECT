﻿using Microsoft.IdentityModel.Tokens;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace PhenyoSyncAPI.Services
{
    /// <summary>Issues signed identity tokens; live account and permission state is rechecked per request.</summary>
    public class JwtService
    {
        public const string SecurityVersionClaim = "security_version";
        private readonly IConfiguration _config;

        public JwtService(IConfiguration config)
        {
            _config = config;
        }

        public string GenerateToken(User user)
        {
            var jwtKey = _config["Jwt:Key"]
                ?? throw new InvalidOperationException(
                    "JWT signing key configuration is required.");
            var key = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(jwtKey));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
            new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}".Trim()),
            new Claim(
                ClaimTypes.Role,
                RoleCodes.Normalize(user.Role?.RoleCode ?? user.Role?.RoleName)),
            new Claim(SecurityVersionClaim, user.SecurityVersion.ToString())
        };

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(2),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
