using PhenyoSyncAPI.DTOs.Expiry;

// Defines expiry review and one-time action operations.
namespace PhenyoSyncAPI.Services
{
    public interface IExpiryService
    {
        Task<ExpiryAlertSummaryDto> GetAlertsAsync(
            string? level,
            int? productId,
            int? categoryId,
            int? sectionId,
            CancellationToken cancellationToken);

        Task<ExpiryScanResult> RunScanAsync(CancellationToken cancellationToken);

        Task<ExpiryActionReviewDto> GetActionReviewAsync(
            string token,
            CancellationToken cancellationToken);

        Task<string> WriteOffAsync(
            string token,
            string reason,
            int userId,
            CancellationToken cancellationToken);

        Task<string> ExtendShelfLifeAsync(
            string token,
            string reason,
            DateTime newExpiryAtUtc,
            int userId,
            CancellationToken cancellationToken);
    }

    public record ExpiryScanResult(
        int BatchesScanned,
        int MarkedExpired,
        int WarningEmailsSent,
        int UrgentEmailsSent);
}
