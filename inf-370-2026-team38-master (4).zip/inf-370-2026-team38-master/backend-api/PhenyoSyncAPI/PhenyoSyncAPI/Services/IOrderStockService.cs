using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IOrderStockService
{
    Task<ValidateOrderResponseDto> ValidateAndReserveAsync(int orderId, int userId, CancellationToken cancellationToken);
    Task<ValidateOrderResponseDto> ValidateApprovedAndReserveAsync(
        int orderId,
        int userId,
        CancellationToken cancellationToken);
    Task<bool> CanFullyAllocateAsync(SalesOrder order, CancellationToken cancellationToken);
    Task EnsurePackableReservationsAsync(SalesOrder order, CancellationToken cancellationToken);
    Task ReleaseActiveReservationsAsync(SalesOrder order, CancellationToken cancellationToken);
    Task<PackingListDto> GetPackingListAsync(int orderId, CancellationToken cancellationToken);
    Task<List<SalesOrderSummaryDto>> GetPackingQueueAsync(string? searchTerm, CancellationToken cancellationToken);
}
