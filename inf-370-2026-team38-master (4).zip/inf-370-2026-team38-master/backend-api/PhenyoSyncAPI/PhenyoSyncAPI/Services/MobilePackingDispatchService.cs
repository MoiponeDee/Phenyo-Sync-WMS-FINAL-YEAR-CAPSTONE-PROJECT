using System.Data;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public interface IMobilePackingDispatchService
{
    Task<IReadOnlyList<PackingTaskDto>> PackingTasksAsync(
        CancellationToken cancellationToken);
    Task<PackingTaskDetailDto> PackingTaskAsync(
        int orderId,
        CancellationToken cancellationToken);
    Task<PackingTaskDetailDto> ScanAsync(
        int orderId,
        PackingScanRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<PackingTaskDetailDto> RemoveScanAsync(
        int orderId,
        long scanId,
        ReasonRequest request,
        int userId,
        CancellationToken cancellationToken);
    Task<PackingTaskDetailDto> CompletePackingAsync(
        int orderId,
        ReasonRequest request,
        int userId,
        string role,
        CancellationToken cancellationToken);
    Task<IReadOnlyList<DispatchOrderDto>> DispatchQueueAsync(
        CancellationToken cancellationToken);
    Task<DispatchOrderDto> ConfirmDispatchAsync(
        int orderId,
        ReasonRequest request,
        int userId,
        string role,
        CancellationToken cancellationToken);
}

/// <summary>
/// Coordinates the mobile packing and dispatch workflow. Every accepted scan must
/// resolve to real, unexpired, FEFO-allocated stock before an order can progress.
/// </summary>
public sealed class MobilePackingDispatchService : IMobilePackingDispatchService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IOrderWorkflowService _orders;
    private readonly IOrderStockService _stock;
    private readonly IAuditService _audit;
    private readonly IOperationalNotificationService _notifications;

    public MobilePackingDispatchService(
        PhenyoSyncDbContext context,
        IOrderWorkflowService orders,
        IOrderStockService stock,
        IAuditService audit,
        IOperationalNotificationService notifications)
    {
        _context = context;
        _orders = orders;
        _stock = stock;
        _audit = audit;
        _notifications = notifications;
    }

    public async Task<IReadOnlyList<PackingTaskDto>> PackingTasksAsync(
        CancellationToken cancellationToken)
    {
        // Approved orders remain visible even when production has not yet created enough batches.
        var candidates = await _context.SalesOrders.AsNoTracking()
            .Where(item =>
                item.Status == SalesOrderStatuses.Approved ||
                item.Status == SalesOrderStatuses.Confirmed ||
                item.Status == SalesOrderStatuses.Packing)
            .Where(item => item.ValidationStatus == OrderValidationStatuses.Approved)
            .Include(item => item.Customer)
            .Include(item => item.Items)
            .Include(item => item.PackingScans)
            .OrderBy(item => item.RequestedDeliveryDateUtc)
            .ThenBy(item => item.OrderNumber)
            .ToListAsync(cancellationToken);
        return candidates.Select(MapSummary).ToList();
    }

    public async Task<PackingTaskDetailDto> PackingTaskAsync(
        int orderId,
        CancellationToken cancellationToken)
    {
        var order = await LoadAsync(orderId, false, cancellationToken);
        if (order.Status is not (
                SalesOrderStatuses.Approved or
                SalesOrderStatuses.Confirmed or
                SalesOrderStatuses.Packing or
                SalesOrderStatuses.Packed))
            throw new PhaseCException(409, "This order is not available in the packing workflow.");
        return await MapAsync(order, cancellationToken);
    }

    public async Task<PackingTaskDetailDto> ScanAsync(
        int orderId,
        PackingScanRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Scope retry keys to the operator so a network retry returns the original result safely.
        var operationHash = MobileSecurity.Hash($"{userId}:{request.OperationId}");
        var duplicate = await _context.PackingScans.AsNoTracking()
            .FirstOrDefaultAsync(
                item => item.OperationKeyHash == operationHash,
                cancellationToken);
        if (duplicate is not null)
        {
            if (duplicate.SalesOrderId != orderId)
                throw new PhaseCException(409, "This scan retry belongs to a different packing task.");
            return await PackingTaskAsync(duplicate.SalesOrderId, cancellationToken);
        }

        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var order = await LoadAsync(orderId, true, cancellationToken);
        if (order.Status is not (
                SalesOrderStatuses.Approved or
                SalesOrderStatuses.Confirmed or
                SalesOrderStatuses.Packing) ||
            order.ValidationStatus != OrderValidationStatuses.Approved)
            throw new PhaseCException(409, "This order is not ready for packing.");

        // Manual fallback uses this same lookup; it never bypasses batch existence or stock checks.
        var code = request.Code.Trim();
        var batch = await _context.ProductBatches
            .Include(item => item.Product)
            .SingleOrDefaultAsync(item =>
                item.QRCodeValue == code || item.BatchCode == code,
                cancellationToken)
            ?? throw new PhaseCException(
                404,
                "This QR code does not match a PhenyoSync Product Batch.");
        if (batch.Status == ProductBatchStatuses.WrittenOff)
            throw new PhaseCException(409, "This Product Batch was written off and cannot be packed.");
        if (batch.EffectiveExpiryAtUtc <= DateTime.UtcNow ||
            batch.Status == ProductBatchStatuses.ExpiredPendingDecision)
            throw new PhaseCException(409, "This Product Batch has expired and cannot be packed.");
        if (batch.Status != ProductBatchStatuses.Available)
            throw new PhaseCException(409, "This Product Batch is not available for packing.");

        var orderLine = order.Items.SingleOrDefault(item =>
            item.IsActive && item.ProductId == batch.ProductId)
            ?? throw new PhaseCException(
                409,
                "This Product is not required for this packing order.");
        if (!orderLine.HasKnownFulfilmentWeight)
            throw new PhaseCException(
                409,
                "This order line has no warehouse weight conversion. Update the product and resave the order before scanning stock.");
        var linePacked = order.PackingScans
            .Where(item =>
                item.SalesOrderItemId == orderLine.SalesOrderItemId &&
                item.RemovedAtUtc == null)
            .Sum(item => item.QuantityPackedKg);
        var lineRemaining = orderLine.QuantityKg - linePacked;
        if (lineRemaining <= 0)
            throw new PhaseCException(409, "The required quantity for this Product has already been packed.");
        if (request.QuantityKg > lineRemaining)
        {
            var remainingUnitLabel = lineRemaining == 1m
                ? "unit remains"
                : "units remain";

            throw new PhaseCException(
                409,
                $"Only {lineRemaining:0.###} {remainingUnitLabel} for this Product.");
        }

        // Reservations are rebuilt from current FEFO availability immediately before allocation.
        await _stock.EnsurePackableReservationsAsync(order, cancellationToken);
        _context.ChangeTracker.Clear();
        order = await LoadAsync(orderId, true, cancellationToken);

        var reservation = order.StockReservations
            .Where(item =>
                item.SalesOrderItemId == orderLine.SalesOrderItemId &&
                item.ProductBatchId == batch.ProductBatchId &&
                item.Status == OrderReservationStatuses.Active)
            .OrderBy(item => item.OrderStockReservationId)
            .FirstOrDefault()
            ?? throw new PhaseCException(
                409,
                "Scan the earliest-expiring allocated Product Batch first.");
        var alreadyPacked = order.PackingScans
            .Where(item =>
                item.OrderStockReservationId == reservation.OrderStockReservationId &&
                item.RemovedAtUtc == null)
            .Sum(item => item.QuantityPackedKg);
        var remainingBatchQuantity = reservation.QuantityReservedKg - alreadyPacked;
        if (request.QuantityKg > remainingBatchQuantity)
        {
            var remainingUnitLabel = remainingBatchQuantity == 1m
                ? "unit remains"
                : "units remain";

            throw new PhaseCException(
                409,
                $"Only {remainingBatchQuantity:0.###} {remainingUnitLabel} on this batch allocation.");
        }

        _context.PackingScans.Add(new PackingScan
        {
            SalesOrderId = orderId,
            SalesOrderItemId = reservation.SalesOrderItemId,
            OrderStockReservationId = reservation.OrderStockReservationId,
            ProductBatchId = batch.ProductBatchId,
            ScannedByUserId = userId,
            QuantityPackedKg = request.QuantityKg,
            ScannedAtUtc = DateTime.UtcNow,
            OperationKeyHash = operationHash
        });
        if (order.Status is SalesOrderStatuses.Approved or SalesOrderStatuses.Confirmed)
        {
            var previous = order.Status;
            order.Status = SalesOrderStatuses.Packing;
            order.UpdatedAtUtc = DateTime.UtcNow;
            _context.OrderStatusHistory.Add(new OrderStatusHistory
            {
                SalesOrderId = orderId,
                PreviousStatus = previous,
                NewStatus = SalesOrderStatuses.Packing,
                ChangedByUserId = userId,
                ChangedAtUtc = DateTime.UtcNow,
                Reason = "Packing started with the first verified Product Batch scan."
            });
        }
        await _context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        await AuditAsync(
            "PackOrderScan",
            orderId,
            $"Scanned {request.QuantityKg:0.###} units from batch {batch.BatchCode}.",
            cancellationToken);
        return await PackingTaskAsync(orderId, cancellationToken);
    }

    public async Task<PackingTaskDetailDto> RemoveScanAsync(
        int orderId,
        long scanId,
        ReasonRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        var scan = await _context.PackingScans
            .SingleOrDefaultAsync(
                item => item.PackingScanId == scanId &&
                        item.SalesOrderId == orderId,
                cancellationToken)
            ?? throw new PhaseCException(404, "Packing scan not found.");
        if (scan.RemovedAtUtc.HasValue)
            return await PackingTaskAsync(orderId, cancellationToken);
        var orderStatus = await _context.SalesOrders
            .Where(item => item.SalesOrderId == orderId)
            .Select(item => item.Status)
            .SingleAsync(cancellationToken);
        if (orderStatus is SalesOrderStatuses.Packed or
            SalesOrderStatuses.ReadyForDispatch or
            SalesOrderStatuses.OutForDelivery or
            SalesOrderStatuses.Delivered)
            throw new PhaseCException(409, "Completed packing scans are read-only.");

        scan.RemovedAtUtc = DateTime.UtcNow;
        scan.RemovedByUserId = userId;
        scan.RemovalReason = request.Reason.Trim();
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            "RemovePackingScan",
            orderId,
            $"Removed packing scan {scanId}.",
            cancellationToken);
        return await PackingTaskAsync(orderId, cancellationToken);
    }

    public async Task<PackingTaskDetailDto> CompletePackingAsync(
        int orderId,
        ReasonRequest request,
        int userId,
        string role,
        CancellationToken cancellationToken)
    {
        // Recalculate from persisted, non-removed scans; the UI percentage is informational only.
        var order = await LoadAsync(orderId, false, cancellationToken);
        foreach (var line in order.Items.Where(item => item.IsActive))
        {
            if (!line.HasKnownFulfilmentWeight)
                throw new PhaseCException(
                    409,
                    $"{line.ProductNameSnapshot} has no warehouse weight conversion and cannot be completed for packing.");
            var scanned = order.PackingScans
                .Where(item =>
                    item.SalesOrderItemId == line.SalesOrderItemId &&
                    item.RemovedAtUtc == null)
                .Sum(item => item.QuantityPackedKg);
            if (scanned != line.QuantityKg)
                throw new PhaseCException(
                    409,
                    $"{line.ProductNameSnapshot} requires {line.QuantityKg:0.###} kg, but {scanned:0.###} kg is scanned.");
        }

        if (order.Status != SalesOrderStatuses.Packing)
            throw new PhaseCException(409, "At least one verified scan is required before packing can be completed.");
        await _orders.TransitionAsync(
            orderId,
                new UpdateOrderStatusDto
                {
                    NewStatus = SalesOrderStatuses.Packed,
                    Reason = request.Reason.Trim(),
                    OperationId = request.OperationId
                },
            userId,
            role,
            cancellationToken);
        await _notifications.PublishToRolesAsync(
            "OrderPacked",
            "Action",
            "Packing complete and awaiting warehouse review",
            $"{order.OrderNumber} is fully scanned. Confirm Ready for Dispatch after reviewing the packed lines.",
            [RoleCodes.WarehouseManager, RoleCodes.BusinessManager],
            nameof(SalesOrder),
            orderId.ToString(),
            $"/dispatch/{orderId}",
            userId,
            request.OperationId,
            cancellationToken);
        return await PackingTaskAsync(orderId, cancellationToken);
    }

    public async Task<IReadOnlyList<DispatchOrderDto>> DispatchQueueAsync(
        CancellationToken cancellationToken)
    {
        var orders = await DispatchQuery()
            .Where(item => item.Status == SalesOrderStatuses.ReadyForDispatch)
            .OrderBy(item => item.PackedAtUtc)
            .ToListAsync(cancellationToken);
        return orders.Select(MapDispatch).ToList();
    }

    public async Task<DispatchOrderDto> ConfirmDispatchAsync(
        int orderId,
        ReasonRequest request,
        int userId,
        string role,
        CancellationToken cancellationToken)
    {
        // Dispatch requires both warehouse readiness and a currently assigned delivery.
        var order = await DispatchQuery()
            .SingleOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
            ?? throw new PhaseCException(404, "Dispatch order not found.");
        if (order.Status != SalesOrderStatuses.ReadyForDispatch)
            throw new PhaseCException(409, "Only an order confirmed Ready for Dispatch can be dispatched.");
        if (order.Delivery is null)
            throw new PhaseCException(409, "Schedule and assign a delivery before dispatch.");
        if (order.Delivery.Status != DeliveryStatuses.Assigned)
            throw new PhaseCException(409, "The delivery must have an assigned driver.");

        await _orders.TransitionAsync(
            orderId,
            new UpdateOrderStatusDto
            {
                NewStatus = SalesOrderStatuses.OutForDelivery,
                Reason = request.Reason.Trim(),
                OperationId = request.OperationId
            },
            userId,
            role,
            cancellationToken);
        await _notifications.PublishToRolesAsync(
            "OrderDispatched",
            "Information",
            "Order dispatched",
            $"{order.OrderNumber} left the warehouse with its assigned driver.",
            [RoleCodes.WarehouseManager, RoleCodes.BusinessManager, RoleCodes.OperationsManager],
            nameof(SalesOrder),
            orderId.ToString(),
            $"/deliveries/{order.Delivery.DeliveryId}",
            userId,
            request.OperationId,
            cancellationToken);
        var updated = await DispatchQuery()
            .SingleAsync(item => item.SalesOrderId == orderId, cancellationToken);
        return MapDispatch(updated);
    }

    private IQueryable<SalesOrder> DispatchQuery() =>
        _context.SalesOrders.AsNoTracking()
            .Include(item => item.Customer)
            .Include(item => item.PackedByUser)
            .Include(item => item.PackingScans)
            .Include(item => item.Delivery).ThenInclude(item => item!.Driver)
                .ThenInclude(item => item!.User);

    private async Task<SalesOrder> LoadAsync(
        int orderId,
        bool tracking,
        CancellationToken cancellationToken)
    {
        IQueryable<SalesOrder> query = _context.SalesOrders;
        if (!tracking) query = query.AsNoTracking();
        return await query
            .Include(item => item.Customer)
            .Include(item => item.Items)
            .Include(item => item.PackingScans).ThenInclude(item => item.ProductBatch)
                .ThenInclude(item => item.Product)
            .Include(item => item.StockReservations).ThenInclude(item => item.ProductBatch)
                .ThenInclude(item => item.Product)
            .SingleOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
            ?? throw new PhaseCException(404, "Packing task not found.");
    }

    private static PackingTaskDto MapSummary(SalesOrder order)
    {
        var activeLines = order.Items.Where(item => item.IsActive).ToArray();
        var hasUnknownWeight = activeLines.Any(item => !item.HasKnownFulfilmentWeight);
        var required = activeLines.Sum(item => item.QuantityKg);
        var packed = order.PackingScans.Where(item => item.RemovedAtUtc == null)
            .Sum(item => item.QuantityPackedKg);
        return new PackingTaskDto
        {
            SalesOrderId = order.SalesOrderId,
            OrderNumber = order.OrderNumber,
            CustomerName = order.Customer.CustomerName,
            Status = order.Status,
            RequestedDeliveryDateUtc = order.RequestedDeliveryDateUtc,
            CompletionPercentage = required == 0 || hasUnknownWeight
                ? 0
                : Math.Round(Math.Min(100, packed / required * 100), 1),
            RemainingLineCount = activeLines.Count(item =>
                item.IsActive &&
                (!item.HasKnownFulfilmentWeight ||
                 order.PackingScans.Where(scan =>
                         scan.SalesOrderItemId == item.SalesOrderItemId &&
                         scan.RemovedAtUtc == null)
                     .Sum(scan => scan.QuantityPackedKg) < item.QuantityKg))
        };
    }

    private async Task<PackingTaskDetailDto> MapAsync(
        SalesOrder order,
        CancellationToken cancellationToken)
    {
        var productIds = order.Items
            .Where(item => item.IsActive)
            .Select(item => item.ProductId)
            .Distinct()
            .ToArray();
        var now = DateTime.UtcNow;
        var batches = await _context.ProductBatches
            .AsNoTracking()
            .Where(item =>
                productIds.Contains(item.ProductId) &&
                item.Status == ProductBatchStatuses.Available &&
                item.QuantityRemainingKg > 0m &&
                item.EffectiveExpiryAtUtc > now)
            .Select(item => new
            {
                item.ProductId,
                item.QuantityRemainingKg
            })
            .ToListAsync(cancellationToken);
        var reservationsForOtherOrders = await _context.OrderStockReservations
            .AsNoTracking()
            .Where(item =>
                productIds.Contains(item.ProductId) &&
                item.SalesOrderId != order.SalesOrderId &&
                item.Status == OrderReservationStatuses.Active)
            .Select(item => new
            {
                item.ProductId,
                item.QuantityReservedKg
            })
            .ToListAsync(cancellationToken);
        var availableByProduct = productIds.ToDictionary(
            productId => productId,
            productId => Math.Max(
                0m,
                batches
                    .Where(item => item.ProductId == productId)
                    .Sum(item => item.QuantityRemainingKg) -
                reservationsForOtherOrders
                    .Where(item => item.ProductId == productId)
                    .Sum(item => item.QuantityReservedKg)));

        return Map(order, availableByProduct);
    }

    private static PackingTaskDetailDto Map(
        SalesOrder order,
        IReadOnlyDictionary<int, decimal> availableByProduct) => new()
    {
        SalesOrderId = order.SalesOrderId,
        OrderNumber = order.OrderNumber,
        CustomerName = order.Customer.CustomerName,
        Status = order.Status,
        Lines = order.Items.Where(item => item.IsActive).Select(item =>
        {
            var packed = order.PackingScans.Where(scan =>
                    scan.SalesOrderItemId == item.SalesOrderItemId &&
                    scan.RemovedAtUtc == null)
                .Sum(scan => scan.QuantityPackedKg);
            return new PackingLineDto
            {
                SalesOrderItemId = item.SalesOrderItemId,
                ProductId = item.ProductId,
                ProductName = item.ProductNameSnapshot,
                ProductSize = item.ProductSizeSnapshot,
                OrderedQuantityUnits = item.QuantityUnits ?? item.QuantityKg,
                SellingUnit = item.SellingUnitSnapshot ?? "kg",
                KilogramsPerUnit = item.KilogramsPerUnitSnapshot,
                RequiredQuantityKg = item.HasKnownFulfilmentWeight ? item.QuantityKg : null,
                AvailableQuantityKg = availableByProduct.GetValueOrDefault(
                    item.ProductId),
                PackedQuantityKg = packed,
                RemainingQuantityKg = item.HasKnownFulfilmentWeight
                    ? Math.Max(0, item.QuantityKg - packed)
                    : null
            };
        }).ToList(),
        Scans = order.PackingScans.OrderByDescending(item => item.ScannedAtUtc)
            .Select(item => new PackingScanDto
            {
                PackingScanId = item.PackingScanId,
                ProductBatchId = item.ProductBatchId,
                BatchCode = item.ProductBatch.BatchCode,
                ProductName = item.ProductBatch.Product.ProductName,
                ProductSize = item.ProductBatch.Product.Size,
                BestBeforeAtUtc = item.ProductBatch.EffectiveExpiryAtUtc,
                AvailableQuantity = item.ProductBatch.QuantityRemainingKg,
                QuantityPackedKg = item.QuantityPackedKg,
                ScannedAtUtc = item.ScannedAtUtc,
                IsRemoved = item.RemovedAtUtc.HasValue
            }).ToList()
    };

    private static DispatchOrderDto MapDispatch(SalesOrder item) => new()
    {
        SalesOrderId = item.SalesOrderId,
        OrderNumber = item.OrderNumber,
        CustomerName = item.Customer.CustomerName,
        Status = item.Status,
        PackedAtUtc = item.PackedAtUtc,
        PackerName = item.PackedByUser is null
            ? null
            : $"{item.PackedByUser.FirstName} {item.PackedByUser.LastName}".Trim(),
        ScanCount = item.PackingScans.Count(scan => scan.RemovedAtUtc == null),
        PackedQuantityKg = item.PackingScans.Where(scan => scan.RemovedAtUtc == null)
            .Sum(scan => scan.QuantityPackedKg),
        DeliveryId = item.Delivery?.DeliveryId,
        DriverName = item.Delivery?.Driver is null
            ? null
            : $"{item.Delivery.Driver.User.FirstName} {item.Delivery.Driver.User.LastName}".Trim(),
        Vehicle = item.Delivery?.Driver?.VehicleAssigned
    };

    private async Task AuditAsync(
        string operation,
        int orderId,
        string description,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.Update,
            SystemModule = AuditModules.OrderManagement,
            OperationName = operation,
            Description = description,
            EntityType = nameof(SalesOrder),
            EntityId = orderId.ToString(),
            EntityDisplay = $"Sales order {orderId}"
        }, cancellationToken);
}
