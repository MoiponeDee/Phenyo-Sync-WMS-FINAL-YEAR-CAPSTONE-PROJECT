using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;

namespace PhenyoSyncAPI.Services;

/// <summary>Creates and resolves expiring public order links without exposing internal identifiers directly.</summary>
public sealed class OrderLinkService : IOrderLinkService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IEmailService _emailService;
    private readonly IOrderService _orderService;
    private readonly IConfiguration _configuration;
    private readonly OrderManagementOptions _options;
    private readonly IAuditService? _auditService;
    private readonly ISystemSettingProvider? _settings;

    public OrderLinkService(
        PhenyoSyncDbContext context,
        IEmailService emailService,
        IOrderService orderService,
        IConfiguration configuration,
        IOptions<OrderManagementOptions> options,
        IAuditService? auditService = null,
        ISystemSettingProvider? settings = null)
    {
        _context = context;
        _emailService = emailService;
        _orderService = orderService;
        _configuration = configuration;
        _options = options.Value;
        _auditService = auditService;
        _settings = settings;
    }

    // Store only a token hash and send the raw value once so database access cannot reveal active links.
    public async Task<OrderLinkDto> SendAsync(int customerId, int userId, CancellationToken cancellationToken)
    {
        var customer = await _context.Customers.FirstOrDefaultAsync(item => item.CustomerId == customerId, cancellationToken);
        if (customer is null || customer.Status != CustomerStatuses.Active)
            throw new OrderManagementException(400, "Select a valid active customer.");
        if (!new EmailAddressAttribute().IsValid(customer.Email))
            throw new OrderManagementException(400, "The selected customer does not have a valid email address.");

        var token = CreateToken();
        var lifetimeHours = _settings is null
            ? _options.OrderLinkLifetimeHours
            : await _settings.GetIntAsync(
                SystemSettingKeys.OrdersOrderLinkLifetimeHours,
                cancellationToken);
        var link = new CustomerOrderLink
        {
            CustomerId = customer.CustomerId,
            TokenHash = HashToken(token),
            CreatedByUserId = userId,
            CreatedAtUtc = DateTime.UtcNow,
            ExpiresAtUtc = DateTime.UtcNow.AddHours(
                Math.Clamp(lifetimeHours, 1, 168))
        };
        _context.CustomerOrderLinks.Add(link);
        await _context.SaveChangesAsync(cancellationToken);

        var frontendUrl = (_configuration["FrontendUrl"] ?? "http://localhost:4200").TrimEnd('/');
        var orderUrl = $"{frontendUrl}/customer-order?token={Uri.EscapeDataString(token)}";
        try
        {
            await _emailService.SendCustomerOrderLinkEmailAsync(
                customer.Email,
                customer.CustomerName,
                orderUrl,
                link.ExpiresAtUtc,
                cancellationToken);
            link.EmailSentAtUtc = DateTime.UtcNow;
            await _context.SaveChangesAsync(cancellationToken);
        }
        catch (Exception)
        {
            if (_auditService is not null)
            {
                await _auditService.RecordAsync(new AuditEvent
                {
                    ActionType = AuditActionTypes.SendEmail,
                    SystemModule = AuditModules.OrderLink,
                    OperationName = "SendCustomerOrderLink",
                    Description = "A secure customer order-link email could not be sent.",
                    EntityType = nameof(CustomerOrderLink),
                    EntityId = link.CustomerOrderLinkId.ToString(),
                    EntityDisplay = $"CustomerId={customer.CustomerId}",
                    UserId = userId,
                    Success = false,
                    FailureReason = "Email delivery failed.",
                    EventSource = AuditEventSources.BusinessEvent
                }, cancellationToken);
            }
            throw new OrderManagementException(
                502,
                "The secure order link was created but the email could not be sent. Use Resend after checking email settings.");
        }

        if (_auditService is not null)
        {
            await _auditService.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.SendEmail,
                SystemModule = AuditModules.OrderLink,
                OperationName = "SendCustomerOrderLink",
                Description = "A secure customer order link was generated and sent.",
                EntityType = nameof(CustomerOrderLink),
                EntityId = link.CustomerOrderLinkId.ToString(),
                EntityDisplay = $"CustomerId={customer.CustomerId}",
                UserId = userId,
                Success = true,
                EventSource = AuditEventSources.BusinessEvent,
                SafeDetails = new Dictionary<string, object?>
                {
                    ["CustomerId"] = customer.CustomerId,
                    ["ExpiresAtUtc"] = link.ExpiresAtUtc
                }
            }, cancellationToken);
        }
        return Map(link, customer);
    }

    public Task<List<OrderLinkDto>> ListAsync(CancellationToken cancellationToken) =>
        _context.CustomerOrderLinks.AsNoTracking()
            .Include(item => item.Customer)
            .OrderByDescending(item => item.CreatedAtUtc)
            .Take(200)
            .Select(item => new OrderLinkDto
            {
                CustomerOrderLinkId = item.CustomerOrderLinkId,
                CustomerId = item.CustomerId,
                CustomerNumber = item.Customer.CustomerNumber,
                CustomerName = item.Customer.CustomerName,
                CustomerEmail = item.Customer.Email,
                CreatedAtUtc = item.CreatedAtUtc,
                ExpiresAtUtc = item.ExpiresAtUtc,
                UsedAtUtc = item.UsedAtUtc,
                RevokedAtUtc = item.RevokedAtUtc,
                EmailSentAtUtc = item.EmailSentAtUtc,
                SalesOrderId = item.SalesOrderId,
                Status = item.UsedAtUtc != null ? "Used" :
                    item.RevokedAtUtc != null ? "Revoked" :
                    item.ExpiresAtUtc <= DateTime.UtcNow ? "Expired" :
                    item.EmailSentAtUtc == null ? "EmailFailed" : "Active"
            }).ToListAsync(cancellationToken);

    public async Task<OrderLinkDto> RevokeAsync(long linkId, CancellationToken cancellationToken)
    {
        var link = await _context.CustomerOrderLinks.Include(item => item.Customer)
            .FirstOrDefaultAsync(item => item.CustomerOrderLinkId == linkId, cancellationToken)
            ?? throw new OrderManagementException(404, "Order link not found.");
        if (link.UsedAtUtc.HasValue) throw new OrderManagementException(409, "A used order link cannot be revoked.");
        if (!link.RevokedAtUtc.HasValue)
        {
            link.RevokedAtUtc = DateTime.UtcNow;
            await _context.SaveChangesAsync(cancellationToken);
        }
        return Map(link, link.Customer);
    }

    public async Task<OrderLinkDto> ResendAsync(long linkId, int userId, CancellationToken cancellationToken)
    {
        var link = await _context.CustomerOrderLinks.FirstOrDefaultAsync(
            item => item.CustomerOrderLinkId == linkId,
            cancellationToken) ?? throw new OrderManagementException(404, "Order link not found.");
        if (link.UsedAtUtc.HasValue) throw new OrderManagementException(409, "A used order link cannot be resent.");
        link.RevokedAtUtc ??= DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
        return await SendAsync(link.CustomerId, userId, cancellationToken);
    }

    public async Task<PublicOrderLinkValidationDto> ValidateAsync(string token, CancellationToken cancellationToken)
    {
        var link = await GetValidLinkAsync(token, cancellationToken);
        var now = DateTime.UtcNow;
        var reservationRows = await _context.OrderStockReservations.AsNoTracking()
            .Where(item => item.Status == OrderReservationStatuses.Active)
            .Select(item => new { item.ProductBatchId, item.QuantityReservedKg })
            .ToListAsync(cancellationToken);
        var reservations = reservationRows
            .GroupBy(item => item.ProductBatchId)
            .ToDictionary(group => group.Key, group => group.Sum(item => item.QuantityReservedKg));
        var batches = await _context.ProductBatches.AsNoTracking()
            .Where(batch => batch.Product.Status == ProductStatuses.Active &&
                batch.Product.ProductPrices.Any(price =>
                    price.IsCurrent &&
                    !price.IsDeleted &&
                    price.SellingPrice > 0) &&
                batch.Status == ProductBatchStatuses.Available &&
                batch.QuantityRemainingKg > 0 &&
                batch.EffectiveExpiryAtUtc > now)
            .Select(batch => new
            {
                batch.ProductBatchId,
                batch.ProductId,
                batch.QuantityRemainingKg,
                batch.Product.ProductName,
                batch.Product.Size,
                batch.Product.SellingUnit,
                batch.Product.KilogramsPerUnit,
                batch.Product.IsVariableWeight,
                PriceBasis = batch.Product.ProductPrices
                    .Where(price => price.IsCurrent && !price.IsDeleted)
                    .Select(price => price.PriceBasis)
                    .Single(),
                ProductPriceId = batch.Product.ProductPrices
                    .Where(price => price.IsCurrent && !price.IsDeleted)
                    .Select(price => price.ProductPriceId)
                    .Single(),
                SellingPricePerKg = batch.Product.ProductPrices
                    .Where(price => price.IsCurrent && !price.IsDeleted)
                    .Select(price => price.SellingPrice)
                    .Single()
            }).ToListAsync(cancellationToken);
        var products = batches
            .Where(batch => batch.QuantityRemainingKg - reservations.GetValueOrDefault(batch.ProductBatchId) > 0)
            .GroupBy(batch => new
            {
                batch.ProductId,
                batch.ProductPriceId,
                batch.ProductName,
                batch.Size,
                batch.SellingUnit,
                batch.KilogramsPerUnit,
                batch.IsVariableWeight,
                batch.PriceBasis,
                batch.SellingPricePerKg
            })
            .Select(group => new PublicOrderProductDto
            {
                ProductId = group.Key.ProductId,
                ProductPriceId = group.Key.ProductPriceId,
                ProductName = group.Key.ProductName,
                Size = group.Key.Size,
                SellingPricePerKg = group.Key.SellingPricePerKg,
                PriceBasis = group.Key.PriceBasis,
                SellingUnit = group.Key.SellingUnit,
                KilogramsPerUnit = group.Key.KilogramsPerUnit,
                IsVariableWeight = group.Key.IsVariableWeight,
                SellingPricePerUnit = group.Key.PriceBasis == ProductPriceBases.PerSellableUnit
                    ? group.Key.SellingPricePerKg
                    : group.Key.IsVariableWeight
                        ? group.Key.SellingPricePerKg
                        : group.Key.KilogramsPerUnit.HasValue
                            ? group.Key.SellingPricePerKg * group.Key.KilogramsPerUnit.Value
                            : null
            }).OrderBy(item => item.ProductName).ThenBy(item => item.Size).ToList();

        return new PublicOrderLinkValidationDto
        {
            CustomerName = link.Customer.CustomerName,
            ExpiresAtUtc = link.ExpiresAtUtc,
            DeliveryAddress = link.Customer.DeliveryAddress ?? string.Empty,
            BillingAddress = link.Customer.BillingAddress ?? string.Empty,
            Products = products
        };
    }

    // Public submission is scoped to the linked customer; normal order validation/pricing still applies.
    public async Task<SalesOrderDetailDto> SubmitAsync(
        PublicCreateSalesOrderDto request,
        CancellationToken cancellationToken)
    {
        var link = await GetValidLinkAsync(request.Token, cancellationToken);
        return await _orderService.CreateAsync(new CreateSalesOrderDto
        {
            CustomerId = link.CustomerId,
            RequestedDeliveryDateUtc = request.RequestedDeliveryDateUtc,
            DeliveryAddress = request.DeliveryAddress,
            BillingAddress = request.BillingAddress,
            Notes = request.Notes,
            Items = request.Items
        }, null, link.CustomerOrderLinkId, cancellationToken);
    }

    private async Task<CustomerOrderLink> GetValidLinkAsync(string rawToken, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(rawToken))
            throw new OrderManagementException(400, "The secure order token is required.");
        var hash = HashToken(rawToken);
        var link = await _context.CustomerOrderLinks.AsNoTracking()
            .Include(item => item.Customer)
            .FirstOrDefaultAsync(item => item.TokenHash == hash, cancellationToken);
        if (link is null) throw new OrderManagementException(400, "The order link is invalid.");
        if (link.RevokedAtUtc.HasValue) throw new OrderManagementException(410, "The order link has been revoked.");
        if (link.ExpiresAtUtc <= DateTime.UtcNow) throw new OrderManagementException(410, "The order link has expired.");
        if (link.UsedAtUtc.HasValue || link.SalesOrderId.HasValue)
            throw new OrderManagementException(409, "The order link has already been used.");
        if (link.Customer.Status != CustomerStatuses.Active)
            throw new OrderManagementException(409, "This customer account is no longer active.");
        return link;
    }

    private static string CreateToken()
    {
        var value = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
        return value.Replace('+', '-').Replace('/', '_').TrimEnd('=');
    }

    internal static string HashToken(string token) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));

    private static OrderLinkDto Map(CustomerOrderLink link, Customer customer) => new()
    {
        CustomerOrderLinkId = link.CustomerOrderLinkId,
        CustomerId = link.CustomerId,
        CustomerNumber = customer.CustomerNumber,
        CustomerName = customer.CustomerName,
        CustomerEmail = customer.Email,
        CreatedAtUtc = link.CreatedAtUtc,
        ExpiresAtUtc = link.ExpiresAtUtc,
        UsedAtUtc = link.UsedAtUtc,
        RevokedAtUtc = link.RevokedAtUtc,
        EmailSentAtUtc = link.EmailSentAtUtc,
        SalesOrderId = link.SalesOrderId,
        Status = link.UsedAtUtc.HasValue ? "Used" :
            link.RevokedAtUtc.HasValue ? "Revoked" :
            link.ExpiresAtUtc <= DateTime.UtcNow ? "Expired" :
            link.EmailSentAtUtc.HasValue ? "Active" : "EmailFailed"
    };
}
