using System.Globalization;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Reports;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services.Reports;

public interface IFormalReportService
{
    Task<ReportOptionsDto> GetOptionsAsync(CancellationToken cancellationToken);

    Task<InventoryReportDto> InventoryAsync(
        InventoryReportCriteriaDto criteria,
        int userId,
        CancellationToken cancellationToken);

    Task<ExpiryWasteReportDto> ExpiryWasteAsync(
        ExpiryWasteReportCriteriaDto criteria,
        int userId,
        bool canViewCost,
        CancellationToken cancellationToken);

    Task<MarkupReportDto> MarkupAsync(
        MarkupReportCriteriaDto criteria,
        int userId,
        bool canViewCost,
        CancellationToken cancellationToken);

    Task<SalesReportDto> SalesAsync(
        SalesReportCriteriaDto criteria,
        int userId,
        CancellationToken cancellationToken);

    Task<StockMovementReportDto> StockMovementAsync(
        StockMovementReportCriteriaDto criteria,
        int userId,
        bool canViewCost,
        CancellationToken cancellationToken);

    Task<FinancialReportDto> FinancialAsync(
        FinancialReportCriteriaDto criteria,
        int userId,
        bool canViewCost,
        bool canViewReversalHistory,
        CancellationToken cancellationToken);

    Task<PricingReportDto> PricingAsync(
        PricingReportCriteriaDto criteria,
        int userId,
        CancellationToken cancellationToken);
}

/// <summary>
/// Builds read-only report projections from operational data. Criteria are validated
/// centrally, sensitive cost/reversal fields are permission-gated, and totals use the
/// same filtered row set returned to the report preview.
/// </summary>
public sealed class FormalReportService : IFormalReportService
{
    private const string SimpleListClassification = "Simple list report";
    private const string TransactionalClassification =
        "Transactional control-break report";
    private const string AdjustableClassification =
        "Adjustable-criteria report";
    private const string ManagementClassification =
        "Management graph report";

    private static readonly HashSet<string> QualifyingSalesStatuses =
        new(StringComparer.OrdinalIgnoreCase)
        {
            SalesOrderStatuses.Approved,
            SalesOrderStatuses.Confirmed,
            SalesOrderStatuses.Packing,
            SalesOrderStatuses.Packed,
            SalesOrderStatuses.ReadyForDispatch,
            SalesOrderStatuses.OutForDelivery,
            SalesOrderStatuses.Delivered
        };

    private readonly PhenyoSyncDbContext _context;

    public FormalReportService(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    public async Task<ReportOptionsDto> GetOptionsAsync(
        CancellationToken cancellationToken)
    {
        var products = await _context.Products
            .AsNoTracking()
            .OrderBy(item => item.ProductName)
            .Select(item => new ReportOptionDto(
                item.ProductId,
                item.ProductName))
            .ToListAsync(cancellationToken);
        var categories = await _context.ProductCategories
            .AsNoTracking()
            .OrderBy(item => item.ProductCategoryName)
            .Select(item => new ReportOptionDto(
                item.ProductCategoryId,
                item.ProductCategoryName))
            .ToListAsync(cancellationToken);
        var types = await _context.ProductTypes
            .AsNoTracking()
            .OrderBy(item => item.ProductTypeName)
            .Select(item => new ReportOptionDto(
                item.ProductTypeId,
                item.ProductTypeName))
            .ToListAsync(cancellationToken);
        var sections = await _context.WarehouseSections
            .AsNoTracking()
            .OrderBy(item => item.SectionName)
            .Select(item => new ReportOptionDto(
                item.SectionId,
                item.SectionName))
            .ToListAsync(cancellationToken);
        var customers = await _context.Customers
            .AsNoTracking()
            .OrderBy(item => item.CustomerName)
            .Select(item => new ReportOptionDto(
                item.CustomerId,
                item.CustomerName))
            .ToListAsync(cancellationToken);
        var suppliers = await _context.Suppliers
            .AsNoTracking()
            .OrderBy(item => item.SupplierName)
            .Select(item => new ReportOptionDto(
                item.SupplierId,
                item.SupplierName))
            .ToListAsync(cancellationToken);
        var methods = await _context.FinancialPayments
            .AsNoTracking()
            .Where(item => item.PaymentMethodCode != string.Empty)
            .Select(item => item.PaymentMethodCode)
            .Distinct()
            .OrderBy(item => item)
            .Select(item => new ReportCodeOptionDto(item, Friendly(item)))
            .ToListAsync(cancellationToken);
        var reasons = await _context.OperationalReasons
            .AsNoTracking()
            .Where(item => item.IsActive)
            .OrderBy(item => item.ReasonName)
            .Select(item => new ReportCodeOptionDto(
                item.ReasonCode,
                item.ReasonName))
            .ToListAsync(cancellationToken);

        return new ReportOptionsDto
        {
            Products = products,
            ProductCategories = categories,
            ProductTypes = types,
            WarehouseSections = sections,
            Customers = customers,
            Suppliers = suppliers,
            OrderStatuses = SalesOrderStatuses.All
                .OrderBy(item => item)
                .Select(item => new ReportCodeOptionDto(item, Friendly(item)))
                .ToArray(),
            DeliveryStatuses = DeliveryStatuses.All
                .OrderBy(item => item)
                .Select(item => new ReportCodeOptionDto(item, Friendly(item)))
                .ToArray(),
            PaymentStatuses =
            [
                Code(FinancialPaymentStatuses.Draft),
                Code(FinancialPaymentStatuses.Posted),
                Code(FinancialPaymentStatuses.PendingReversalApproval),
                Code(FinancialPaymentStatuses.Voided),
                Code(FinancialPaymentStatuses.Reversed),
                Code(FinancialPaymentStatuses.Rejected)
            ],
            PaymentMethods = methods,
            MovementTypes =
            [
                Code(StockMovementTypes.Increase),
                Code(StockMovementTypes.Decrease),
                Code(StockMovementTypes.WriteOff),
                Code(StockMovementTypes.Adjustment),
                Code(RawStockMovementTypes.OpeningBalance),
                Code(RawStockMovementTypes.Receipt),
                Code(RawStockMovementTypes.WriteOff),
                Code(RawStockMovementTypes.PositiveAdjustment),
                Code(RawStockMovementTypes.NegativeAdjustment),
                Code(RawStockMovementTypes.ProductionConversion)
            ],
            WriteOffReasons = reasons
        };
    }

    public async Task<InventoryReportDto> InventoryAsync(
        InventoryReportCriteriaDto criteria,
        int userId,
        CancellationToken cancellationToken)
    {
        // Compose filters in SQL first; paging is applied only after report totals are known.
        ValidatePaging(criteria);
        var stocksQuery = _context.Stocks
            .AsNoTracking()
            .Where(item =>
                criteria.ProductId == null ||
                item.ProductId == criteria.ProductId)
            .Where(item =>
                criteria.ProductCategoryId == null ||
                item.Product.ProductCategoryId == criteria.ProductCategoryId)
            .Where(item =>
                criteria.ProductTypeId == null ||
                item.Product.ProductTypeId == criteria.ProductTypeId)
            .Where(item =>
                criteria.WarehouseSectionId == null ||
                item.SectionId == criteria.WarehouseSectionId)
            .Where(item =>
                criteria.IncludeInactive ||
                item.Product.Status == "Active")
            .Where(item =>
                criteria.IncludeZeroQuantity ||
                item.QuantityAvailableKg > 0);

        if (!string.IsNullOrWhiteSpace(criteria.Search))
        {
            var search = criteria.Search.Trim();
            stocksQuery = stocksQuery.Where(item =>
                item.Product.ProductName.Contains(search) ||
                item.Product.ProductCategory!.ProductCategoryName.Contains(search) ||
                item.Product.ProductType!.ProductTypeName.Contains(search) ||
                item.WarehouseSection.SectionName.Contains(search));
        }

        if (!string.IsNullOrWhiteSpace(criteria.StockStatus))
        {
            stocksQuery = stocksQuery.Where(item =>
                item.InventoryStatus == criteria.StockStatus);
        }

        var stocks = await stocksQuery
            .Select(item => new InventoryStockProjection(
                item.StockId,
                item.ProductId,
                item.SectionId,
                item.Product.QRCodeValue ?? item.Product.ProductName,
                item.Product.ProductName,
                item.Product.ProductCategory != null
                    ? item.Product.ProductCategory.ProductCategoryName
                    : "Unclassified",
                item.Product.ProductType != null
                    ? item.Product.ProductType.ProductTypeName
                    : "Unclassified",
                item.WarehouseSection.SectionName,
                item.QuantityAvailableKg,
                item.ReorderLevelKg,
                item.InventoryStatus))
            .ToListAsync(cancellationToken);
        var productIds = stocks.Select(item => item.ProductId).Distinct().ToArray();
        var sectionIds = stocks.Select(item => item.SectionId).Distinct().ToArray();
        var batches = await _context.ProductBatches
            .AsNoTracking()
            .Where(item =>
                productIds.Contains(item.ProductId) &&
                sectionIds.Contains(item.SectionId))
            .Select(item => new InventoryBatchProjection(
                item.ProductBatchId,
                item.ProductId,
                item.SectionId,
                item.BatchCode,
                item.QuantityRemainingKg,
                item.EffectiveExpiryAtUtc,
                item.Status))
            .ToListAsync(cancellationToken);
        var batchIds = batches.Select(item => item.ProductBatchId).ToArray();
        var reservations = await _context.OrderStockReservations
            .AsNoTracking()
            .Where(item =>
                batchIds.Contains(item.ProductBatchId) &&
                item.Status == OrderReservationStatuses.Active)
            .GroupBy(item => item.ProductBatchId)
            .Select(group => new
            {
                ProductBatchId = group.Key,
                Quantity = group.Sum(item => item.QuantityReservedKg)
            })
            .ToDictionaryAsync(
                item => item.ProductBatchId,
                item => item.Quantity,
                cancellationToken);

        var rows = new List<InventoryReportRowDto>();
        foreach (var stock in stocks)
        {
            var stockBatches = batches
                .Where(item =>
                    item.ProductId == stock.ProductId &&
                    item.SectionId == stock.SectionId)
                .OrderBy(item => item.EffectiveExpiryAtUtc)
                .ToArray();
            if (stockBatches.Length == 0)
            {
                rows.Add(new InventoryReportRowDto(
                    stock.ProductCode,
                    stock.Product,
                    stock.Category,
                    stock.ProductType,
                    stock.Section,
                    stock.QuantityAvailableKg,
                    0,
                    stock.QuantityAvailableKg,
                    stock.ReorderLevelKg,
                    null,
                    stock.InventoryStatus));
                continue;
            }

            foreach (var batch in stockBatches)
            {
                var reserved = reservations.GetValueOrDefault(batch.ProductBatchId);
                var available = Math.Max(0, batch.QuantityRemainingKg - reserved);
                rows.Add(new InventoryReportRowDto(
                    stock.ProductCode,
                    stock.Product,
                    stock.Category,
                    stock.ProductType,
                    stock.Section,
                    available,
                    reserved,
                    batch.QuantityRemainingKg,
                    stock.ReorderLevelKg,
                    batch.EffectiveExpiryAtUtc,
                    batch.Status));
            }
        }

        rows = SortInventory(rows, criteria).ToList();
        var totalRecords = rows.Count;
        var pagedRows = Page(rows, criteria).ToArray();
        var metadata = await MetadataAsync(
            "inventory",
            "Inventory Position Report",
            SimpleListClassification,
            userId,
            Criteria(
                ("Search", criteria.Search),
                ("Stock status", criteria.StockStatus),
                ("Include inactive", YesNo(criteria.IncludeInactive)),
                ("Include zero quantity", YesNo(criteria.IncludeZeroQuantity))),
            totalRecords,
            cancellationToken);

        return new InventoryReportDto
        {
            Metadata = metadata,
            Rows = pagedRows,
            TotalRecords = totalRecords,
            TotalAvailableQuantityKg = rows.Sum(item => item.AvailableQuantityKg),
            TotalReservedQuantityKg = rows.Sum(item => item.ReservedQuantityKg)
        };
    }

    public async Task<ExpiryWasteReportDto> ExpiryWasteAsync(
        ExpiryWasteReportCriteriaDto criteria,
        int userId,
        bool canViewCost,
        CancellationToken cancellationToken)
    {
        // Cost joins are omitted entirely when the caller lacks cost-view permission.
        ValidatePaging(criteria);
        if (criteria.DaysToExpiryThreshold is < 0 or > 730)
        {
            throw new ReportValidationException(
                "Days to expiry must be between 0 and 730.");
        }

        var asOf = (criteria.AsOfDateUtc ?? DateTime.UtcNow).Date;
        if (asOf > DateTime.UtcNow.Date)
        {
            throw new ReportValidationException(
                "The as-of date cannot be in the future.");
        }
        var thresholdEnd = asOf.AddDays(criteria.DaysToExpiryThreshold + 1);
        var receiptCosts = canViewCost
            ? await _context.StockReceiptItems
                .AsNoTracking()
                .Where(item => item.ProductBatchId != null && item.UnitCost != null)
                .GroupBy(item => item.ProductBatchId!.Value)
                .Select(group => new
                {
                    ProductBatchId = group.Key,
                    Cost = group.Sum(item =>
                            item.AcceptedQuantityKg * item.UnitCost!.Value) /
                        group.Sum(item => item.AcceptedQuantityKg)
                })
                .ToDictionaryAsync(
                    item => item.ProductBatchId,
                    item => item.Cost,
                    cancellationToken)
            : new Dictionary<int, decimal>();
        var finishedBatches = await _context.ProductBatches
            .AsNoTracking()
            .Where(item =>
                item.EffectiveExpiryAtUtc < thresholdEnd ||
                item.Status == ProductBatchStatuses.WrittenOff ||
                item.Status == ProductBatchStatuses.ExpiredPendingDecision)
            .Where(item =>
                criteria.WarehouseSectionId == null ||
                item.SectionId == criteria.WarehouseSectionId)
            .Where(item =>
                criteria.ProductId == null ||
                item.ProductId == criteria.ProductId)
            .Where(item =>
                criteria.ProductCategoryId == null ||
                item.Product.ProductCategoryId == criteria.ProductCategoryId)
            .Select(item => new
            {
                item.ProductBatchId,
                item.ProductId,
                ProductCode = item.Product.QRCodeValue ?? item.Product.ProductName,
                Product = item.Product.ProductName,
                item.BatchCode,
                Section = item.WarehouseSection.SectionName,
                item.QuantityRemainingKg,
                item.EffectiveExpiryAtUtc,
                item.Status,
                item.CreatedAtUtc
            })
            .ToListAsync(cancellationToken);
        var rows = new List<ExpiryWasteReportRowDto>();
        rows.AddRange(finishedBatches.Select(item =>
        {
            var days = (int)Math.Floor(
                (item.EffectiveExpiryAtUtc.Date - asOf).TotalDays);
            var risk = RiskStatus(days, item.Status);
            decimal? cost = canViewCost
                ? receiptCosts.GetValueOrDefault(item.ProductBatchId)
                : null;
            var knownCost = cost is > 0;
            return new ExpiryWasteReportRowDto(
                "Expiry Risk",
                item.ProductCode,
                item.Product,
                item.Section,
                item.QuantityRemainingKg,
                "units",
                item.EffectiveExpiryAtUtc,
                days,
                risk,
                null,
                knownCost ? cost : null,
                knownCost ? cost * item.QuantityRemainingKg : null,
                "System expiry monitoring",
                item.CreatedAtUtc,
                canViewCost && knownCost ? "Available" : "N/A");
        }));

        var finishedWriteOffs = await _context.StockWriteOffs
            .AsNoTracking()
            .Where(item =>
                criteria.IncludeCompletedWriteOffs ||
                item.Status != WriteOffStatuses.Completed)
            .Where(item =>
                criteria.WarehouseSectionId == null ||
                item.SectionId == criteria.WarehouseSectionId)
            .Where(item =>
                criteria.ProductId == null ||
                item.ProductBatch.ProductId == criteria.ProductId)
            .Where(item =>
                criteria.ProductCategoryId == null ||
                item.ProductBatch.Product.ProductCategoryId ==
                    criteria.ProductCategoryId)
            .Where(item =>
                string.IsNullOrWhiteSpace(criteria.WriteOffReason) ||
                item.ReasonCode == criteria.WriteOffReason)
            .Select(item => new
            {
                item.ProductBatch.ProductId,
                ProductCode = item.ProductBatch.Product.QRCodeValue ??
                    item.ProductBatch.Product.ProductName,
                Product = item.ProductBatch.Product.ProductName,
                item.ProductBatch.BatchCode,
                Section = item.WarehouseSection.SectionName,
                item.QuantityKg,
                item.ProductBatch.EffectiveExpiryAtUtc,
                item.ReasonCode,
                item.EstimatedUnitCost,
                item.EstimatedTotalLoss,
                Responsible = item.SubmittedByUser.FirstName + " " +
                    item.SubmittedByUser.LastName,
                item.SubmittedAtUtc,
                item.Status
            })
            .ToListAsync(cancellationToken);
        rows.AddRange(finishedWriteOffs.Select(item =>
            new ExpiryWasteReportRowDto(
                "Product Write-Off",
                item.ProductCode,
                item.Product,
                item.Section,
                item.QuantityKg,
                "units",
                item.EffectiveExpiryAtUtc,
                (int)Math.Floor(
                    (item.EffectiveExpiryAtUtc.Date - asOf).TotalDays),
                item.Status,
                Friendly(item.ReasonCode),
                canViewCost &&
                item.EstimatedUnitCost.HasValue &&
                item.EstimatedUnitCost.Value > 0
                    ? item.EstimatedUnitCost
                    : null,
                canViewCost &&
                item.EstimatedUnitCost.HasValue &&
                item.EstimatedUnitCost.Value > 0
                    ? item.EstimatedTotalLoss
                    : null,
                item.Responsible.Trim(),
                item.SubmittedAtUtc,
                canViewCost &&
                item.EstimatedUnitCost.HasValue &&
                item.EstimatedUnitCost.Value > 0
                    ? "Available"
                    : "N/A")));

        var rawBatches = await _context.RawStockBatches
            .AsNoTracking()
            .Where(item =>
                item.BestBeforeAtUtc != null &&
                item.BestBeforeAtUtc < thresholdEnd)
            .Where(item =>
                criteria.WarehouseSectionId == null ||
                item.RawStockBalance.WarehouseSectionId ==
                    criteria.WarehouseSectionId)
            .Select(item => new
            {
                item.RawStockItemId,
                item.RawStockItem.ItemCode,
                Item = item.RawStockItem.ItemName,
                item.BatchCode,
                Section = item.RawStockBalance.WarehouseSection.SectionName,
                item.QuantityRemaining,
                item.RawStockBalance.UnitOfMeasure,
                item.BestBeforeAtUtc,
                item.Status,
                item.UnitCost,
                item.ReceivedAtUtc
            })
            .ToListAsync(cancellationToken);
        rows.AddRange(rawBatches.Select(item =>
        {
            var days = item.BestBeforeAtUtc.HasValue
                ? (int?)Math.Floor(
                    (item.BestBeforeAtUtc.Value.Date - asOf).TotalDays)
                : null;
            var knownCost =
                canViewCost && item.UnitCost.HasValue && item.UnitCost.Value > 0;
            return new ExpiryWasteReportRowDto(
                "Raw Stock Expiry Risk",
                item.ItemCode,
                item.Item,
                item.Section,
                item.QuantityRemaining,
                item.UnitOfMeasure,
                item.BestBeforeAtUtc,
                days,
                RiskStatus(days ?? int.MaxValue, item.Status),
                null,
                knownCost ? item.UnitCost : null,
                knownCost
                    ? item.UnitCost!.Value * item.QuantityRemaining
                    : null,
                "System expiry monitoring",
                item.ReceivedAtUtc,
                knownCost ? "Available" : "N/A");
        }));

        if (!string.IsNullOrWhiteSpace(criteria.RiskStatus))
        {
            rows = rows
                .Where(item => string.Equals(
                    item.RiskStatus,
                    criteria.RiskStatus,
                    StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        rows = SortExpiry(rows, criteria).ToList();
        var totalRecords = rows.Count;
        var pagedRows = Page(rows, criteria).ToArray();
        var metadata = await MetadataAsync(
            "expiry-waste",
            "Expiry and Waste Risk Report",
            SimpleListClassification,
            userId,
            Criteria(
                ("As-of date", asOf.ToString("dd MMM yyyy", CultureInfo.InvariantCulture)),
                ("Days-to-expiry threshold", criteria.DaysToExpiryThreshold.ToString()),
                ("Risk status", FriendlyCriterion(criteria.RiskStatus)),
                ("Write-off reason", FriendlyCriterion(criteria.WriteOffReason)),
                ("Include completed write-offs", YesNo(criteria.IncludeCompletedWriteOffs)),
                ("Cost visibility", canViewCost ? "Permitted" : "Restricted")),
            totalRecords,
            cancellationToken);

        var knownLosses = rows
            .Where(item => item.EstimatedLossValue.HasValue)
            .Select(item => item.EstimatedLossValue!.Value)
            .ToArray();
        return new ExpiryWasteReportDto
        {
            Metadata = metadata,
            Rows = pagedRows,
            TotalRecords = totalRecords,
            TotalQuantityAtRiskKg = rows.Sum(item => item.QuantityKg),
            TotalKnownLossValue = knownLosses.Length == 0
                ? null
                : knownLosses.Sum()
        };
    }

    public async Task<MarkupReportDto> MarkupAsync(
        MarkupReportCriteriaDto criteria,
        int userId,
        bool canViewCost,
        CancellationToken cancellationToken)
    {
        // Only commercially active order states contribute to revenue and margin.
        ValidatePaging(criteria);
        var (fromUtc, toExclusiveUtc) = ReportRange(
            criteria.FromUtc,
            criteria.ToUtc,
            365);
        var sales = await _context.SalesOrderItems
            .AsNoTracking()
            .Where(item =>
                item.IsActive &&
                item.SalesOrder.OrderDateUtc >= fromUtc &&
                item.SalesOrder.OrderDateUtc < toExclusiveUtc)
            .Where(item => QualifyingSalesStatuses.Contains(item.SalesOrder.Status))
            .Where(item =>
                criteria.ProductId == null ||
                item.ProductId == criteria.ProductId)
            .Where(item =>
                criteria.ProductCategoryId == null ||
                item.Product.ProductCategoryId == criteria.ProductCategoryId)
            .Select(item => new MarkupSaleProjection(
                item.SalesOrderItemId,
                item.ProductId,
                item.Product.QRCodeValue ?? item.Product.ProductName,
                item.ProductNameSnapshot,
                item.Product.ProductCategory != null
                    ? item.Product.ProductCategory.ProductCategoryName
                    : "Unclassified",
                item.QuantityKg,
                item.UnitPricePerKg))
            .ToListAsync(cancellationToken);
        var saleItemIds = sales.Select(item => item.SalesOrderItemId).ToArray();
        var scans = canViewCost
            ? await _context.PackingScans
                .AsNoTracking()
                .Where(item =>
                    saleItemIds.Contains(item.SalesOrderItemId) &&
                    item.RemovedAtUtc == null)
                .Select(item => new
                {
                    item.SalesOrderItemId,
                    item.ProductBatchId,
                    item.QuantityPackedKg
                })
                .ToListAsync(cancellationToken)
            : [];
        var batchIds = scans.Select(item => item.ProductBatchId).Distinct().ToArray();
        var batchCosts = canViewCost
            ? await _context.StockReceiptItems
                .AsNoTracking()
                .Where(item =>
                    item.ProductBatchId != null &&
                    batchIds.Contains(item.ProductBatchId.Value) &&
                    item.UnitCost != null &&
                    item.UnitCost > 0)
                .GroupBy(item => item.ProductBatchId!.Value)
                .Select(group => new
                {
                    ProductBatchId = group.Key,
                    Cost = group.Sum(item =>
                            item.AcceptedQuantityKg * item.UnitCost!.Value) /
                        group.Sum(item => item.AcceptedQuantityKg)
                })
                .ToDictionaryAsync(
                    item => item.ProductBatchId,
                    item => item.Cost,
                    cancellationToken)
            : new Dictionary<int, decimal>();
        var periodReceiptCosts = canViewCost
            ? await _context.StockReceiptItems
                .AsNoTracking()
                .Where(item =>
                    item.StockReceipt.Status == MobileOperationStatuses.Completed &&
                    item.ReceivedAtUtc >= fromUtc &&
                    item.ReceivedAtUtc < toExclusiveUtc &&
                    item.UnitCost != null &&
                    item.UnitCost > 0 &&
                    item.AcceptedQuantityKg > 0)
                .GroupBy(item => item.ProductId)
                .Select(group => new
                {
                    ProductId = group.Key,
                    Cost = group.Sum(item =>
                            item.AcceptedQuantityKg * item.UnitCost!.Value) /
                        group.Sum(item => item.AcceptedQuantityKg)
                })
                .ToDictionaryAsync(
                    item => item.ProductId,
                    item => item.Cost,
                    cancellationToken)
            : new Dictionary<int, decimal>();
        var allowPriorCost = canViewCost && await AllowPriorReceiptCostAsync(
            cancellationToken);
        var rows = new List<MarkupReportRowDto>();
        foreach (var productSales in sales.GroupBy(item => item.ProductId))
        {
            var totalQuantity = productSales.Sum(item => item.QuantityKg);
            if (totalQuantity <= 0)
            {
                continue;
            }

            var averageSellingPrice = productSales.Sum(item =>
                    item.QuantityKg * item.UnitPrice) /
                totalQuantity;
            decimal? averageCost = null;
            var costSource = "Unavailable";
            var productSaleIds = productSales
                .Select(item => item.SalesOrderItemId)
                .ToHashSet();
            var costedScans = scans
                .Where(item =>
                    productSaleIds.Contains(item.SalesOrderItemId) &&
                    batchCosts.ContainsKey(item.ProductBatchId))
                .ToArray();
            var costedQuantity = costedScans.Sum(item => item.QuantityPackedKg);
            if (costedQuantity > 0)
            {
                averageCost = costedScans.Sum(item =>
                        item.QuantityPackedKg * batchCosts[item.ProductBatchId]) /
                    costedQuantity;
                costSource = "Batch-Linked";
            }
            else if (periodReceiptCosts.TryGetValue(productSales.Key, out var receiptCost))
            {
                averageCost = receiptCost;
                costSource = "Weighted Receipt Fallback";
            }
            else if (allowPriorCost)
            {
                averageCost = await LatestPriorReceiptCostAsync(
                    productSales.Key,
                    fromUtc,
                    cancellationToken);
                if (averageCost.HasValue)
                {
                    costSource = "Prior Valid Receipt Fallback";
                }
            }

            var first = productSales.First();
            var validCost = averageCost is > 0;
            var validSellingPrice = averageSellingPrice > 0;
            var markupAmount = validCost
                ? averageSellingPrice - averageCost
                : null;
            var markupPercentage = validCost
                ? markupAmount / averageCost * 100m
                : null;
            var grossMarginPercentage = validCost && validSellingPrice
                ? markupAmount / averageSellingPrice * 100m
                : null;
            var quality = validCost && validSellingPrice
                ? "Complete"
                : validSellingPrice
                    ? "Cost unavailable"
                    : "Selling price unavailable";
            rows.Add(new MarkupReportRowDto(
                first.ProductCode,
                first.Product,
                first.Category,
                totalQuantity,
                averageSellingPrice,
                canViewCost ? averageCost : null,
                canViewCost ? costSource : "Restricted",
                canViewCost ? markupAmount : null,
                canViewCost ? markupPercentage : null,
                canViewCost ? grossMarginPercentage : null,
                quality));
        }

        if (!string.IsNullOrWhiteSpace(criteria.CostSource))
        {
            rows = rows
                .Where(item => string.Equals(
                    item.CostSource,
                    criteria.CostSource,
                    StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
        if (!string.IsNullOrWhiteSpace(criteria.DataQualityStatus))
        {
            rows = rows
                .Where(item => string.Equals(
                    item.DataQualityStatus,
                    criteria.DataQualityStatus,
                    StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        rows = SortMarkup(rows, criteria).ToList();
        var totalRecords = rows.Count;
        var metadata = await MetadataAsync(
            "markup",
            "Product Markup and Gross Margin Report",
            SimpleListClassification,
            userId,
            Criteria(
                ("From", DateLabel(fromUtc)),
                ("To", DateLabel(toExclusiveUtc.AddTicks(-1))),
                ("Cost source", FriendlyCriterion(criteria.CostSource)),
                ("Data-quality status", FriendlyCriterion(criteria.DataQualityStatus)),
                ("Cost visibility", canViewCost ? "Permitted" : "Restricted")),
            totalRecords,
            cancellationToken);
        return new MarkupReportDto
        {
            Metadata = metadata,
            Rows = Page(rows, criteria).ToArray(),
            TotalRecords = totalRecords
        };
    }

    public async Task<SalesReportDto> SalesAsync(
        SalesReportCriteriaDto criteria,
        int userId,
        CancellationToken cancellationToken)
    {
        // Use an exclusive upper bound so date-only filters include the complete final day.
        var (fromUtc, toExclusiveUtc) = ReportRange(
            criteria.FromUtc,
            criteria.ToUtc,
            365);
        var query = _context.SalesOrderItems
            .AsNoTracking()
            .Where(item =>
                item.IsActive &&
                item.SalesOrder.OrderDateUtc >= fromUtc &&
                item.SalesOrder.OrderDateUtc < toExclusiveUtc)
            .Where(item =>
                criteria.CustomerId == null ||
                item.SalesOrder.CustomerId == criteria.CustomerId)
            .Where(item =>
                criteria.ProductId == null ||
                item.ProductId == criteria.ProductId)
            .Where(item =>
                criteria.ProductCategoryId == null ||
                item.Product.ProductCategoryId == criteria.ProductCategoryId)
            .Where(item =>
                string.IsNullOrWhiteSpace(criteria.OrderStatus) ||
                item.SalesOrder.Status == criteria.OrderStatus)
            .Where(item =>
                string.IsNullOrWhiteSpace(criteria.DeliveryStatus) ||
                (item.SalesOrder.Delivery != null &&
                 item.SalesOrder.Delivery.Status == criteria.DeliveryStatus));
        var lines = await query
            .Select(item => new SalesLineProjection(
                item.SalesOrderItemId,
                item.SalesOrderId,
                item.SalesOrder.OrderDateUtc,
                item.SalesOrder.OrderNumber,
                item.SalesOrder.CustomerId,
                item.SalesOrder.Customer.CustomerName,
                item.SalesOrder.Invoice != null
                    ? item.SalesOrder.Invoice.InvoiceNumber
                    : "N/A",
                item.ProductNameSnapshot,
                item.Product.ProductCategory != null
                    ? item.Product.ProductCategory.ProductCategoryName
                    : "Unclassified",
                item.QuantityKg,
                item.UnitPricePerKg,
                item.LineTotal,
                item.SalesOrder.Status,
                item.SalesOrder.Delivery != null
                    ? item.SalesOrder.Delivery.Status
                    : "Not scheduled"))
            .ToListAsync(cancellationToken);
        var monthGroups = lines
            .GroupBy(item => new
            {
                item.OrderDateUtc.Year,
                item.OrderDateUtc.Month
            })
            .OrderBy(group => group.Key.Year)
            .ThenBy(group => group.Key.Month)
            .Select(month =>
            {
                var customers = month
                    .GroupBy(item => new { item.CustomerId, item.Customer })
                    .OrderBy(group => group.Key.Customer)
                    .Select(customer =>
                    {
                        var orders = customer
                            .GroupBy(item => new
                            {
                                item.SalesOrderId,
                                item.OrderNumber
                            })
                            .OrderBy(group => group.Key.OrderNumber)
                            .Select(order =>
                            {
                                var detail = order
                                    .Select(ToSalesLine)
                                    .OrderBy(item => item.Product)
                                    .ToArray();
                                return new SalesOrderReportGroupDto
                                {
                                    SalesOrderId = order.Key.SalesOrderId,
                                    OrderNumber = order.Key.OrderNumber,
                                    Lines = detail,
                                    OrderQuantitySubtotalKg = detail.Sum(
                                        item => item.QuantityKg),
                                    OrderValueSubtotal = detail.Sum(
                                        item => item.LineTotal)
                                };
                            })
                            .ToArray();
                        return new SalesCustomerReportGroupDto
                        {
                            CustomerId = customer.Key.CustomerId,
                            Customer = customer.Key.Customer,
                            Orders = orders,
                            CustomerQuantitySubtotalKg = orders.Sum(
                                item => item.OrderQuantitySubtotalKg),
                            CustomerValueSubtotal = orders.Sum(
                                item => item.OrderValueSubtotal)
                        };
                    })
                    .ToArray();
                var monthDate = new DateTime(
                    month.Key.Year,
                    month.Key.Month,
                    1,
                    0,
                    0,
                    0,
                    DateTimeKind.Utc);
                return new SalesMonthReportGroupDto
                {
                    MonthKey = monthDate.ToString("yyyy-MM", CultureInfo.InvariantCulture),
                    MonthLabel = monthDate.ToString("MMMM yyyy", CultureInfo.InvariantCulture),
                    Customers = customers,
                    MonthQuantitySubtotalKg = customers.Sum(
                        item => item.CustomerQuantitySubtotalKg),
                    MonthValueSubtotal = customers.Sum(
                        item => item.CustomerValueSubtotal)
                };
            })
            .ToList();
        if (string.Equals(
                criteria.SortOrder,
                "month-desc",
                StringComparison.OrdinalIgnoreCase))
        {
            monthGroups.Reverse();
        }

        var totalOrders = lines
            .Select(item => item.SalesOrderId)
            .Distinct()
            .Count();
        var grandValue = monthGroups.Sum(item => item.MonthValueSubtotal);
        var metadata = await MetadataAsync(
            "sales",
            "Sales by Customer and Product Report",
            TransactionalClassification,
            userId,
            Criteria(
                ("From", DateLabel(fromUtc)),
                ("To", DateLabel(toExclusiveUtc.AddTicks(-1))),
                ("Order status", FriendlyCriterion(criteria.OrderStatus)),
                ("Delivery status", FriendlyCriterion(criteria.DeliveryStatus)),
                ("Sort order", FriendlyCriterion(criteria.SortOrder))),
            lines.Count,
            cancellationToken);
        return new SalesReportDto
        {
            Metadata = metadata,
            Months = monthGroups,
            GrandQuantitySoldKg = monthGroups.Sum(
                item => item.MonthQuantitySubtotalKg),
            GrandSalesValue = grandValue,
            TotalOrders = totalOrders,
            AverageOrderValue = totalOrders == 0 ? 0 : grandValue / totalOrders
        };
    }

    public async Task<StockMovementReportDto> StockMovementAsync(
        StockMovementReportCriteriaDto criteria,
        int userId,
        bool canViewCost,
        CancellationToken cancellationToken)
    {
        // Finished- and raw-stock ledgers are normalized into one report domain after filtering.
        var (fromUtc, toExclusiveUtc) = ReportRange(
            criteria.FromUtc,
            criteria.ToUtc,
            365);
        var finished = await _context.StockMovements
            .AsNoTracking()
            .Where(item =>
                item.OccurredAtUtc >= fromUtc &&
                item.OccurredAtUtc < toExclusiveUtc)
            .Where(item =>
                criteria.ProductId == null ||
                item.ProductId == criteria.ProductId)
            .Where(item =>
                criteria.ProductCategoryId == null ||
                item.Product.ProductCategoryId == criteria.ProductCategoryId)
            .Where(item =>
                criteria.WarehouseSectionId == null ||
                item.SectionId == criteria.WarehouseSectionId)
            .Where(item =>
                string.IsNullOrWhiteSpace(criteria.MovementType) ||
                item.MovementType == criteria.MovementType)
            .Select(item => new FinishedMovementProjection(
                item.StockMovementId,
                item.ProductBatchId,
                item.OccurredAtUtc,
                item.MovementType,
                item.Product.ProductName,
                item.Product.ProductCategory != null
                    ? item.Product.ProductCategory.ProductCategoryName
                    : "Unclassified",
                item.ProductBatch.BatchCode,
                item.WarehouseSection.SectionName,
                item.QuantityKg,
                item.Reason,
                item.CreatedByUser != null
                    ? item.CreatedByUser.FirstName + " " + item.CreatedByUser.LastName
                    : "System",
                item.SalesOrderId,
                item.SalesOrder != null ? item.SalesOrder.OrderNumber : null,
                item.StockTakeSessionId))
            .ToListAsync(cancellationToken);
        var finishedBatchIds = finished
            .Select(item => item.ProductBatchId)
            .Distinct()
            .ToArray();
        var finishedCosts = canViewCost
            ? await _context.StockReceiptItems
                .AsNoTracking()
                .Where(item =>
                    item.ProductBatchId != null &&
                    finishedBatchIds.Contains(item.ProductBatchId.Value) &&
                    item.UnitCost != null &&
                    item.AcceptedQuantityKg > 0)
                .GroupBy(item => item.ProductBatchId!.Value)
                .Select(group => new
                {
                    BatchId = group.Key,
                    Cost = group.Sum(item =>
                            item.AcceptedQuantityKg * item.UnitCost!.Value) /
                        group.Sum(item => item.AcceptedQuantityKg)
                })
                .ToDictionaryAsync(
                    item => item.BatchId,
                    item => item.Cost,
                    cancellationToken)
            : new Dictionary<int, decimal>();
        var normalized = finished.Select(item =>
        {
            var signed = FinishedSignedQuantity(item.MovementType, item.QuantityKg);
            var cost = canViewCost && finishedCosts.TryGetValue(
                item.ProductBatchId,
                out var unitCost)
                    ? unitCost
                    : (decimal?)null;
            return new NormalizedMovement(
                "Finished Product",
                item.Category,
                item.Item,
                new StockMovementReportRowDto(
                    item.OccurredAtUtc,
                    Friendly(item.MovementType),
                    !string.IsNullOrWhiteSpace(item.SalesOrderNumber)
                        ? item.SalesOrderNumber
                        : item.StockTakeSessionId.HasValue
                            ? "Stock count adjustment"
                            : "Inventory movement",
                    item.Item,
                    item.Section,
                    signed > 0 ? signed : 0,
                    signed < 0 ? Math.Abs(signed) : 0,
                    signed,
                    "units",
                    cost,
                    cost * Math.Abs(signed),
                    item.Reason ?? "N/A",
                    item.Actor.Trim()));
        }).ToList();
        var raw = await _context.RawStockMovements
            .AsNoTracking()
            .Where(item =>
                item.OccurredAtUtc >= fromUtc &&
                item.OccurredAtUtc < toExclusiveUtc)
            .Where(item =>
                criteria.WarehouseSectionId == null ||
                item.RawStockBalance.WarehouseSectionId ==
                    criteria.WarehouseSectionId)
            .Where(item =>
                string.IsNullOrWhiteSpace(criteria.MovementType) ||
                item.MovementType == criteria.MovementType)
            .Select(item => new
            {
                item.RawStockMovementId,
                item.OccurredAtUtc,
                item.MovementType,
                Item = item.RawStockItem.ItemName,
                Category = item.RawStockItem.CategoryCode,
                Batch = item.RawStockBatch != null
                    ? item.RawStockBatch.BatchCode
                    : "N/A",
                Section = item.RawStockBalance.WarehouseSection.SectionName,
                item.RawStockBalance.UnitOfMeasure,
                item.QuantityChange,
                item.UnitCost,
                Reason = item.ReasonText,
                Actor = item.CreatedByUser.FirstName + " " +
                    item.CreatedByUser.LastName,
                item.SourceType,
                item.SourceId,
                item.CorrelationId
            })
            .ToListAsync(cancellationToken);
        normalized.AddRange(raw.Select(item =>
            new NormalizedMovement(
                "Raw Stock",
                Friendly(item.Category),
                item.Item,
                new StockMovementReportRowDto(
                    item.OccurredAtUtc,
                    Friendly(item.MovementType),
                    string.IsNullOrWhiteSpace(item.SourceType)
                        ? "Raw Stock movement"
                        : Friendly(item.SourceType),
                    item.Item,
                    item.Section,
                    item.QuantityChange > 0 ? item.QuantityChange : 0,
                    item.QuantityChange < 0 ? Math.Abs(item.QuantityChange) : 0,
                    item.QuantityChange,
                    item.UnitOfMeasure,
                    canViewCost &&
                    item.UnitCost.HasValue &&
                    item.UnitCost.Value > 0
                        ? item.UnitCost
                        : null,
                    canViewCost &&
                    item.UnitCost.HasValue &&
                    item.UnitCost.Value > 0
                        ? Math.Abs(item.QuantityChange) * item.UnitCost.Value
                        : null,
                    item.Reason ?? "N/A",
                    item.Actor.Trim()))));
        if (!string.IsNullOrWhiteSpace(criteria.StockDomain))
        {
            normalized = normalized
                .Where(item => string.Equals(
                    item.Domain,
                    criteria.StockDomain,
                    StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        var domains = normalized
            .GroupBy(item => item.Domain)
            .OrderBy(group => group.Key)
            .Select(domain =>
            {
                var categories = domain
                    .GroupBy(item => item.Category)
                    .OrderBy(group => group.Key)
                    .Select(category =>
                    {
                        var items = category
                            .GroupBy(item => item.Item)
                            .OrderBy(group => group.Key)
                            .Select(itemGroup =>
                            {
                                var movements = itemGroup
                                    .Select(item => item.Row)
                                    .OrderBy(item => item.MovementDateUtc)
                                    .ToArray();
                                return new StockMovementItemGroupDto
                                {
                                    Item = itemGroup.Key,
                                    Movements = movements,
                                    TotalInKg = movements.Sum(
                                        item => item.QuantityInKg),
                                    TotalOutKg = movements.Sum(
                                        item => item.QuantityOutKg),
                                    NetMovementKg = movements.Sum(
                                        item => item.NetMovementKg),
                                    MovementValue = KnownSum(
                                        movements.Select(item => item.MovementValue))
                                };
                            })
                            .ToArray();
                        return new StockMovementCategoryGroupDto
                        {
                            Category = category.Key,
                            Items = items,
                            TotalInKg = items.Sum(item => item.TotalInKg),
                            TotalOutKg = items.Sum(item => item.TotalOutKg),
                            NetMovementKg = items.Sum(item => item.NetMovementKg),
                            MovementValue = KnownSum(
                                items.Select(item => item.MovementValue))
                        };
                    })
                    .ToArray();
                return new StockMovementDomainGroupDto
                {
                    StockDomain = domain.Key,
                    Categories = categories,
                    TotalInKg = categories.Sum(item => item.TotalInKg),
                    TotalOutKg = categories.Sum(item => item.TotalOutKg),
                    NetMovementKg = categories.Sum(item => item.NetMovementKg),
                    MovementValue = KnownSum(
                        categories.Select(item => item.MovementValue))
                };
            })
            .ToArray();
        var metadata = await MetadataAsync(
            "stock-movement",
            "Stock Movement by Category and Item Report",
            TransactionalClassification,
            userId,
            Criteria(
                ("From", DateLabel(fromUtc)),
                ("To", DateLabel(toExclusiveUtc.AddTicks(-1))),
                ("Stock domain", FriendlyCriterion(criteria.StockDomain)),
                ("Movement type", FriendlyCriterion(criteria.MovementType)),
                ("Cost visibility", canViewCost ? "Permitted" : "Restricted")),
            normalized.Count,
            cancellationToken);
        return new StockMovementReportDto
        {
            Metadata = metadata,
            Domains = domains,
            GrandTotalInKg = domains.Sum(item => item.TotalInKg),
            GrandTotalOutKg = domains.Sum(item => item.TotalOutKg),
            GrandNetMovementKg = domains.Sum(item => item.NetMovementKg),
            GrandMovementValue = KnownSum(
                domains.Select(item => item.MovementValue))
        };
    }

    public async Task<FinancialReportDto> FinancialAsync(
        FinancialReportCriteriaDto criteria,
        int userId,
        bool canViewCost,
        bool canViewReversalHistory,
        CancellationToken cancellationToken)
    {
        // Reversed/voided history and cost detail remain independently permission-gated.
        ValidatePaging(criteria);
        if (criteria.IncludeReversedOrVoided && !canViewReversalHistory)
        {
            throw new ReportValidationException(
                "You do not have permission to include reversed or voided transactions.");
        }
        if (criteria.MinimumAmount.HasValue &&
            criteria.MaximumAmount.HasValue &&
            criteria.MinimumAmount > criteria.MaximumAmount)
        {
            throw new ReportValidationException(
                "The minimum amount cannot be greater than the maximum amount.");
        }

        var (fromUtc, toExclusiveUtc) = ReportRange(
            criteria.FromUtc,
            criteria.ToUtc,
            365);
        var requestedTypes = criteria.TransactionTypes
            .Where(item => !string.IsNullOrWhiteSpace(item))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var includeAll = requestedTypes.Count == 0;
        var rows = new List<FinancialReportRowDto>();
        if (includeAll || requestedTypes.Contains("Sale or Invoice"))
        {
            var invoices = await _context.Invoices
                .AsNoTracking()
                .Where(item =>
                    item.IssuedAtUtc >= fromUtc &&
                    item.IssuedAtUtc < toExclusiveUtc)
                .Where(item =>
                    criteria.CustomerId == null ||
                    item.SalesOrder.CustomerId == criteria.CustomerId)
                .Select(item => new FinancialReportRowDto(
                    item.IssuedAtUtc,
                    "Sale or Invoice",
                    item.InvoiceNumber,
                    item.CustomerNameSnapshot,
                    item.Status,
                    "N/A",
                    item.TotalAmount,
                    "Accrued",
                    item.SalesOrder.OrderNumber))
                .ToListAsync(cancellationToken);
            rows.AddRange(invoices);
        }

        var paymentStatuses = criteria.IncludeReversedOrVoided
            ? new[]
            {
                FinancialPaymentStatuses.Posted,
                FinancialPaymentStatuses.Reversed,
                FinancialPaymentStatuses.Voided
            }
            : new[] { FinancialPaymentStatuses.Posted };
        if (includeAll ||
            requestedTypes.Contains("Customer Payment") ||
            requestedTypes.Contains("Supplier Payment"))
        {
            var payments = await _context.FinancialPayments
                .AsNoTracking()
                .Where(item =>
                    item.PaymentDateUtc >= fromUtc &&
                    item.PaymentDateUtc < toExclusiveUtc &&
                    paymentStatuses.Contains(item.Status))
                .Where(item =>
                    criteria.CustomerId == null ||
                    item.CustomerId == criteria.CustomerId)
                .Where(item =>
                    criteria.SupplierId == null ||
                    item.SupplierId == criteria.SupplierId)
                .Where(item =>
                    string.IsNullOrWhiteSpace(criteria.PaymentMethod) ||
                    item.PaymentMethodCode == criteria.PaymentMethod)
                .Select(item => new FinancialReportRowDto(
                    item.PaymentDateUtc,
                    item.CounterpartyType == "Supplier"
                        ? "Supplier Payment"
                        : "Customer Payment",
                    item.PaymentNumber,
                    item.Customer != null
                        ? item.Customer.CustomerName
                        : item.Supplier != null
                            ? item.Supplier.SupplierName
                            : "Unassigned",
                    item.Status,
                    item.PaymentMethodCode,
                    item.Amount,
                    item.CounterpartyType == "Supplier" ? "Outflow" : "Inflow",
                    item.Reference ?? item.Notes ?? "N/A"))
                .ToListAsync(cancellationToken);
            rows.AddRange(payments.Where(item =>
                includeAll || requestedTypes.Contains(item.TransactionType)));
        }

        if ((includeAll || requestedTypes.Contains("Write-Off")) && canViewCost)
        {
            var productWriteOffs = await _context.StockWriteOffs
                .AsNoTracking()
                .Where(item =>
                    item.SubmittedAtUtc >= fromUtc &&
                    item.SubmittedAtUtc < toExclusiveUtc &&
                    item.Status == WriteOffStatuses.Completed)
                .Select(item => new FinancialReportRowDto(
                    item.CompletedAtUtc ?? item.SubmittedAtUtc,
                    "Write-Off",
                    $"WO-{item.StockWriteOffId}",
                    item.ProductBatch.Product.ProductName,
                    item.Status,
                    "N/A",
                    item.EstimatedTotalLoss,
                    "Loss",
                    Friendly(item.ReasonCode)))
                .ToListAsync(cancellationToken);
            var rawWriteOffs = await _context.RawStockWriteOffs
                .AsNoTracking()
                .Where(item =>
                    item.SubmittedAtUtc >= fromUtc &&
                    item.SubmittedAtUtc < toExclusiveUtc &&
                    item.Status == WriteOffStatuses.Completed)
                .Select(item => new FinancialReportRowDto(
                    item.CompletedAtUtc ?? item.SubmittedAtUtc,
                    "Write-Off",
                    $"RWO-{item.RawStockWriteOffId}",
                    item.RawStockItem.ItemName,
                    item.Status,
                    "N/A",
                    item.EstimatedTotalLoss,
                    "Loss",
                    item.OperationalReason.ReasonName))
                .ToListAsync(cancellationToken);
            rows.AddRange(productWriteOffs);
            rows.AddRange(rawWriteOffs);
        }

        rows = rows
            .Where(item =>
                string.IsNullOrWhiteSpace(criteria.TransactionStatus) ||
                string.Equals(
                    item.Status,
                    criteria.TransactionStatus,
                    StringComparison.OrdinalIgnoreCase))
            .Where(item =>
                !criteria.MinimumAmount.HasValue ||
                item.Amount.HasValue &&
                item.Amount.Value >= criteria.MinimumAmount.Value)
            .Where(item =>
                !criteria.MaximumAmount.HasValue ||
                item.Amount.HasValue &&
                item.Amount.Value <= criteria.MaximumAmount.Value)
            .ToList();
        rows = SortFinancial(rows, criteria).ToList();
        var fullRows = rows.ToArray();
        var postedCustomerReceipts = fullRows
            .Where(item =>
                item.TransactionType == "Customer Payment" &&
                item.Status == FinancialPaymentStatuses.Posted)
            .Sum(item => item.Amount ?? 0);
        var postedSupplierPayments = fullRows
            .Where(item =>
                item.TransactionType == "Supplier Payment" &&
                item.Status == FinancialPaymentStatuses.Posted)
            .Sum(item => item.Amount ?? 0);
        var salesValue = fullRows
            .Where(item => item.TransactionType == "Sale or Invoice")
            .Sum(item => item.Amount ?? 0);
        var writeOffRows = fullRows
            .Where(item => item.TransactionType == "Write-Off")
            .ToArray();
        var writeOffLoss = writeOffRows.Any(item => !item.Amount.HasValue)
            ? (decimal?)null
            : writeOffRows.Sum(item => item.Amount!.Value);
        var totalInvoiceValue = await _context.Invoices
            .AsNoTracking()
            .Where(item =>
                item.IssuedAtUtc >= fromUtc &&
                item.IssuedAtUtc < toExclusiveUtc &&
                (criteria.CustomerId == null ||
                 item.SalesOrder.CustomerId == criteria.CustomerId))
            .SumAsync(item => (decimal?)item.TotalAmount, cancellationToken) ?? 0;
        var totalSupplierOrders = await _context.SupplierOrders
            .AsNoTracking()
            .Where(item =>
                item.OrderDate >= fromUtc &&
                item.OrderDate < toExclusiveUtc &&
                item.Status != SupplierOrderStatuses.Draft &&
                item.Status != SupplierOrderStatuses.Cancelled &&
                (criteria.SupplierId == null ||
                 item.SupplierId == criteria.SupplierId))
            .SumAsync(item => (decimal?)item.TotalAmount, cancellationToken) ?? 0;
        var totalRecords = rows.Count;
        var metadata = await MetadataAsync(
            "financial",
            "Financial Activity and Cash Movement Report",
            AdjustableClassification,
            userId,
            Criteria(
                ("From", DateLabel(fromUtc)),
                ("To", DateLabel(toExclusiveUtc.AddTicks(-1))),
                ("Transaction types", requestedTypes.Count == 0
                    ? "All"
                    : string.Join(", ", requestedTypes
                        .OrderBy(item => item)
                        .Select(Friendly))),
                ("Status", FriendlyCriterion(criteria.TransactionStatus)),
                ("Payment method", FriendlyCriterion(criteria.PaymentMethod)),
                ("Group by", FriendlyCriterion(criteria.GroupBy)),
                ("Include reversed or voided", YesNo(criteria.IncludeReversedOrVoided)),
                ("Cost visibility", canViewCost ? "Permitted" : "Restricted")),
            totalRecords,
            cancellationToken);
        return new FinancialReportDto
        {
            Metadata = metadata,
            Summary = new FinancialReportSummaryDto(
                salesValue,
                postedCustomerReceipts,
                postedSupplierPayments,
                writeOffLoss,
                postedCustomerReceipts - postedSupplierPayments,
                Math.Max(0, totalInvoiceValue - postedCustomerReceipts),
                Math.Max(0, totalSupplierOrders - postedSupplierPayments)),
            Rows = Page(rows, criteria).ToArray(),
            TotalRecords = totalRecords
        };
    }

    public async Task<PricingReportDto> PricingAsync(
        PricingReportCriteriaDto criteria,
        int userId,
        CancellationToken cancellationToken)
    {
        // Pricing periods are closed at the current UTC month to avoid future projections.
        if (criteria.Year is < 2000 or > 2200)
        {
            throw new ReportValidationException("Select a valid reporting year.");
        }
        var annual = string.Equals(
            criteria.ViewMode,
            "annual",
            StringComparison.OrdinalIgnoreCase);
        if (!annual && criteria.Month is not (>= 1 and <= 12))
        {
            throw new ReportValidationException(
                "Select a month between January and December.");
        }
        var currentDate = DateTime.UtcNow.Date;
        if (criteria.Year > currentDate.Year ||
            (!annual &&
             criteria.Year == currentDate.Year &&
             criteria.Month > currentDate.Month))
        {
            throw new ReportValidationException(
                "Pricing reports cannot use a future reporting period.");
        }

        var fromUtc = annual
            ? new DateTime(criteria.Year, 1, 1, 0, 0, 0, DateTimeKind.Utc)
            : new DateTime(
                criteria.Year,
                criteria.Month!.Value,
                1,
                0,
                0,
                0,
                DateTimeKind.Utc);
        var toExclusiveUtc = annual
            ? fromUtc.AddYears(1)
            : fromUtc.AddMonths(1);
        var raw = await _context.SalesOrderItems
            .AsNoTracking()
            .Where(item =>
                item.IsActive &&
                item.SalesOrder.OrderDateUtc >= fromUtc &&
                item.SalesOrder.OrderDateUtc < toExclusiveUtc)
            .Where(item =>
                criteria.ProductId == null ||
                item.ProductId == criteria.ProductId)
            .Where(item =>
                criteria.ProductCategoryId == null ||
                item.Product.ProductCategoryId == criteria.ProductCategoryId)
            .Where(item =>
                criteria.CustomerId == null ||
                item.SalesOrder.CustomerId == criteria.CustomerId)
            .Where(item =>
                string.IsNullOrWhiteSpace(criteria.QualifyingSalesStatus) ||
                item.SalesOrder.Status == criteria.QualifyingSalesStatus)
            .Select(item => new PricingObservationProjection(
                item.SalesOrder.OrderDateUtc,
                item.ProductId,
                item.ProductNameSnapshot,
                item.SalesOrder.OrderNumber,
                item.SalesOrder.Invoice != null
                    ? item.SalesOrder.Invoice.InvoiceNumber
                    : "N/A",
                item.SalesOrder.Customer.CustomerName,
                item.QuantityUnits ?? item.QuantityKg,
                item.UnitPrice ?? item.UnitPricePerKg,
                item.LineTotal,
                item.SalesOrder.Status))
            .ToListAsync(cancellationToken);
        raw = raw
            .Where(item =>
                !string.IsNullOrWhiteSpace(criteria.QualifyingSalesStatus) ||
                QualifyingSalesStatuses.Contains(item.Status))
            .OrderBy(item => item.TransactionDateUtc)
            .ThenBy(item => item.Product)
            .ToList();
        var observations = raw.Select(item => new PricingObservationDto(
            item.TransactionDateUtc,
            item.ProductId,
            item.Product,
            item.OrderNumber,
            item.InvoiceNumber,
            item.Customer,
            item.QuantitySoldKg,
            item.StoredUnitPrice,
            item.LineTotal,
            item.Status)).ToArray();
        var productIds = raw.Select(item => item.ProductId).Distinct().ToArray();
        var currentTime = DateTime.UtcNow;
        var currentPrices = await _context.ProductPrices
            .AsNoTracking()
            .Where(item =>
                productIds.Contains(item.ProductId) &&
                !item.IsDeleted &&
                item.EffectiveFromUtc <= currentTime &&
                (item.EffectiveToUtc == null ||
                 item.EffectiveToUtc > currentTime))
            .ToDictionaryAsync(
                item => item.ProductId,
                item => item.SellingPrice,
                cancellationToken);
        var monthlySummaries = annual
            ? Array.Empty<MonthlyPricingSummaryDto>()
            : raw.GroupBy(item => new { item.ProductId, item.Product })
                .OrderBy(group => group.Key.Product)
                .Select(group =>
                {
                    var prices = group.Select(item => item.StoredUnitPrice).ToArray();
                    var totalQuantity = group.Sum(item => item.QuantitySoldKg);
                    var weightedAverage =
                        ReportStatistics.QuantityWeightedAverage(
                            group.Select(item =>
                                (
                                    item.QuantitySoldKg,
                                    item.StoredUnitPrice
                                ))) ?? 0;
                    var currentPrice = currentPrices.GetValueOrDefault(
                        group.Key.ProductId);
                    return new MonthlyPricingSummaryDto(
                        group.Key.ProductId,
                        group.Key.Product,
                        totalQuantity,
                        prices.Length,
                        prices.Min(),
                        prices.Max(),
                        ReportStatistics.Median(prices),
                        weightedAverage,
                        currentPrice > 0 ? currentPrice : null,
                        currentPrice > 0 ? currentPrice - weightedAverage : null,
                        ReportStatistics.Distribution(prices));
                })
                .ToArray();
        var annualSummaries = annual
            ? raw.GroupBy(item => new { item.ProductId, item.Product })
                .OrderBy(group => group.Key.Product)
                .Select(group =>
                {
                    var months = Enumerable.Range(1, 12)
                        .Select(month =>
                        {
                            var monthRows = group
                                .Where(item => item.TransactionDateUtc.Month == month)
                                .ToArray();
                            return monthRows.Length == 0
                                ? null
                                : ReportStatistics.QuantityWeightedAverage(
                                    monthRows.Select(item =>
                                        (
                                            item.QuantitySoldKg,
                                            item.StoredUnitPrice
                                        )));
                        })
                        .ToArray();
                    var available = months
                        .Where(item => item.HasValue)
                        .Select(item => item!.Value)
                        .ToArray();
                    return new AnnualPricingSummaryDto(
                        group.Key.ProductId,
                        group.Key.Product,
                        months,
                        available.Length,
                        12 - available.Length,
                        ReportStatistics.AnnualAverage(months),
                        available.Length == 0
                            ? null
                            : ReportStatistics.Distribution(available));
                })
                .ToArray()
            : Array.Empty<AnnualPricingSummaryDto>();
        var charts = annual
            ? AnnualPricingCharts(annualSummaries)
            : MonthlyPricingCharts(observations, monthlySummaries);
        var periodLabel = annual
            ? criteria.Year.ToString(CultureInfo.InvariantCulture)
            : fromUtc.ToString("MMMM yyyy", CultureInfo.InvariantCulture);
        var metadata = await MetadataAsync(
            "pricing",
            "Product Pricing Analysis Report",
            ManagementClassification,
            userId,
            Criteria(
                ("View", annual ? "Annual" : "Monthly"),
                ("Period", periodLabel),
                ("Qualifying sales status",
                    string.IsNullOrWhiteSpace(criteria.QualifyingSalesStatus)
                        ? "Approved operational sales"
                        : Friendly(criteria.QualifyingSalesStatus))),
            observations.Length,
            cancellationToken);
        return new PricingReportDto
        {
            Metadata = metadata,
            ViewMode = annual ? "annual" : "monthly",
            Observations = annual ? [] : observations,
            MonthlySummaries = monthlySummaries,
            AnnualSummaries = annualSummaries,
            Charts = charts
        };
    }

    private async Task<ReportMetadataDto> MetadataAsync(
        string reportKey,
        string title,
        string classification,
        int userId,
        IReadOnlyList<ReportCriterionDto> criteria,
        int recordCount,
        CancellationToken cancellationToken)
    {
        var user = await _context.Users
            .AsNoTracking()
            .Where(item => item.UserId == userId)
            .Select(item => new
            {
                item.FirstName,
                item.LastName,
                Role = item.Role != null ? item.Role.RoleName : string.Empty
            })
            .SingleOrDefaultAsync(cancellationToken);
        if (user is null)
        {
            throw new ReportValidationException(
                "The authenticated user could not be resolved.");
        }

        var name = $"{user.FirstName} {user.LastName}".Trim();
        return new ReportMetadataDto
        {
            ReportKey = reportKey,
            Title = title,
            Classification = classification,
            GeneratedAtUtc = DateTime.UtcNow,
            GeneratedBy = string.IsNullOrWhiteSpace(user.Role)
                ? name
                : $"{name} ({user.Role})",
            Criteria = criteria,
            RecordCount = recordCount
        };
    }

    private static (DateTime FromUtc, DateTime ToExclusiveUtc) ReportRange(
        DateTime? from,
        DateTime? to,
        int defaultDays)
    {
        var toDate = (to ?? DateTime.UtcNow).Date;
        var fromDate = (from ?? toDate.AddDays(-defaultDays)).Date;
        var today = DateTime.UtcNow.Date;
        if (fromDate > today || toDate > today)
        {
            throw new ReportValidationException(
                "Report date criteria cannot be in the future.");
        }
        if (fromDate > toDate)
        {
            throw new ReportValidationException(
                "The from date cannot be after the to date.");
        }

        if ((toDate - fromDate).TotalDays > 3660)
        {
            throw new ReportValidationException(
                "The selected report range is too large.");
        }

        return (
            DateTime.SpecifyKind(fromDate, DateTimeKind.Utc),
            DateTime.SpecifyKind(toDate.AddDays(1), DateTimeKind.Utc));
    }

    private static void ValidatePaging(PagedReportCriteriaDto criteria)
    {
        if (criteria.PageNumber < 1)
        {
            throw new ReportValidationException("Page number must be at least 1.");
        }
        if (criteria.PageSize is < 10 or > 500)
        {
            throw new ReportValidationException(
                "Page size must be between 10 and 500 records.");
        }
        if (!string.Equals(criteria.SortDirection, "asc", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(criteria.SortDirection, "desc", StringComparison.OrdinalIgnoreCase))
        {
            throw new ReportValidationException(
                "Sort direction must be ascending or descending.");
        }
    }

    private static IEnumerable<T> Page<T>(
        IEnumerable<T> source,
        PagedReportCriteriaDto criteria) =>
        source
            .Skip((criteria.PageNumber - 1) * criteria.PageSize)
            .Take(criteria.PageSize);

    private static IEnumerable<InventoryReportRowDto> SortInventory(
        IEnumerable<InventoryReportRowDto> rows,
        InventoryReportCriteriaDto criteria)
    {
        var descending = string.Equals(
            criteria.SortDirection,
            "desc",
            StringComparison.OrdinalIgnoreCase);
        return (criteria.SortBy?.ToLowerInvariant()) switch
        {
            "quantity" => descending
                ? rows.OrderByDescending(item => item.TotalQuantityKg)
                : rows.OrderBy(item => item.TotalQuantityKg),
            "expiry" => descending
                ? rows.OrderByDescending(item => item.BestBeforeDateUtc)
                : rows.OrderBy(item => item.BestBeforeDateUtc),
            "section" => descending
                ? rows.OrderByDescending(item => item.WarehouseSection)
                : rows.OrderBy(item => item.WarehouseSection),
            _ => descending
                ? rows.OrderByDescending(item => item.Product)
                : rows.OrderBy(item => item.Product)
        };
    }

    private static IEnumerable<ExpiryWasteReportRowDto> SortExpiry(
        IEnumerable<ExpiryWasteReportRowDto> rows,
        ExpiryWasteReportCriteriaDto criteria)
    {
        var descending = string.Equals(
            criteria.SortDirection,
            "desc",
            StringComparison.OrdinalIgnoreCase);
        return (criteria.SortBy?.ToLowerInvariant()) switch
        {
            "quantity" => descending
                ? rows.OrderByDescending(item => item.QuantityKg)
                : rows.OrderBy(item => item.QuantityKg),
            "loss" => descending
                ? rows.OrderByDescending(item => item.EstimatedLossValue)
                : rows.OrderBy(item => item.EstimatedLossValue),
            _ => descending
                ? rows.OrderByDescending(item => item.DaysRemaining)
                : rows.OrderBy(item => item.DaysRemaining)
        };
    }

    private static IEnumerable<MarkupReportRowDto> SortMarkup(
        IEnumerable<MarkupReportRowDto> rows,
        MarkupReportCriteriaDto criteria)
    {
        var descending = string.Equals(
            criteria.SortDirection,
            "desc",
            StringComparison.OrdinalIgnoreCase);
        return (criteria.SortBy?.ToLowerInvariant()) switch
        {
            "markup" => descending
                ? rows.OrderByDescending(item => item.MarkupPercentage)
                : rows.OrderBy(item => item.MarkupPercentage),
            "margin" => descending
                ? rows.OrderByDescending(item => item.GrossMarginPercentage)
                : rows.OrderBy(item => item.GrossMarginPercentage),
            _ => descending
                ? rows.OrderByDescending(item => item.Product)
                : rows.OrderBy(item => item.Product)
        };
    }

    private static IEnumerable<FinancialReportRowDto> SortFinancial(
        IEnumerable<FinancialReportRowDto> rows,
        FinancialReportCriteriaDto criteria)
    {
        var descending = string.Equals(
            criteria.SortDirection,
            "desc",
            StringComparison.OrdinalIgnoreCase);
        return (criteria.SortBy?.ToLowerInvariant()) switch
        {
            "amount" => descending
                ? rows.OrderByDescending(item => item.Amount)
                : rows.OrderBy(item => item.Amount),
            "transaction-type" => descending
                ? rows.OrderByDescending(item => item.TransactionType)
                    .ThenByDescending(item => item.TransactionDateUtc)
                : rows.OrderBy(item => item.TransactionType)
                    .ThenBy(item => item.TransactionDateUtc),
            _ => descending
                ? rows.OrderByDescending(item => item.TransactionDateUtc)
                : rows.OrderBy(item => item.TransactionDateUtc)
        };
    }

    private async Task<bool> AllowPriorReceiptCostAsync(
        CancellationToken cancellationToken)
    {
        var value = await _context.SystemSettings
            .AsNoTracking()
            .Where(item =>
                item.Key == "Reports.Markup.AllowPriorReceiptCostFallback" &&
                item.IsActive)
            .Select(item => item.Value)
            .SingleOrDefaultAsync(cancellationToken);
        return bool.TryParse(value, out var enabled) && enabled;
    }

    private async Task<decimal?> LatestPriorReceiptCostAsync(
        int productId,
        DateTime beforeUtc,
        CancellationToken cancellationToken) =>
        await _context.StockReceiptItems
            .AsNoTracking()
            .Where(item =>
                item.ProductId == productId &&
                item.StockReceipt.Status == MobileOperationStatuses.Completed &&
                item.ReceivedAtUtc < beforeUtc &&
                item.UnitCost != null &&
                item.UnitCost > 0)
            .OrderByDescending(item => item.ReceivedAtUtc)
            .Select(item => item.UnitCost)
            .FirstOrDefaultAsync(cancellationToken);

    private static decimal FinishedSignedQuantity(
        string movementType,
        decimal quantity)
    {
        var absolute = Math.Abs(quantity);
        if (string.Equals(
                movementType,
                StockMovementTypes.Increase,
                StringComparison.OrdinalIgnoreCase))
        {
            return absolute;
        }
        if (string.Equals(
                movementType,
                StockMovementTypes.Decrease,
                StringComparison.OrdinalIgnoreCase) ||
            string.Equals(
                movementType,
                StockMovementTypes.WriteOff,
                StringComparison.OrdinalIgnoreCase))
        {
            return -absolute;
        }
        return quantity;
    }

    private static string RiskStatus(int daysRemaining, string batchStatus)
    {
        if (string.Equals(
                batchStatus,
                ProductBatchStatuses.WrittenOff,
                StringComparison.OrdinalIgnoreCase))
        {
            return "Written Off";
        }
        if (daysRemaining < 0)
        {
            return "Expired";
        }
        if (daysRemaining <= 7)
        {
            return "Critical";
        }
        if (daysRemaining <= 30)
        {
            return "Warning";
        }
        return "Approaching";
    }

    private static decimal? KnownSum(IEnumerable<decimal?> values)
    {
        var known = values.Where(item => item.HasValue).Select(item => item!.Value).ToArray();
        return known.Length == 0 ? null : known.Sum();
    }

    private static IReadOnlyList<ReportChartDto> MonthlyPricingCharts(
        IReadOnlyList<PricingObservationDto> observations,
        IReadOnlyList<MonthlyPricingSummaryDto> summaries)
    {
        var lineSeries = observations
            .GroupBy(item => item.Product)
            .OrderBy(group => group.Key)
            .Select(group => new ReportChartSeriesDto
            {
                Name = group.Key,
                Points = group
                    .OrderBy(item => item.TransactionDateUtc)
                    .Select((item, index) => new ReportChartPointDto(
                        item.TransactionDateUtc.ToString(
                            "dd MMM",
                            CultureInfo.InvariantCulture),
                        item.StoredUnitPrice,
                        $"{item.Product}: {Money(item.StoredUnitPrice)} on {DateLabel(item.TransactionDateUtc)}",
                        index))
                    .ToArray()
            })
            .ToArray();
        var averageSeries = new ReportChartSeriesDto
        {
            Name = "Quantity-weighted monthly average",
            Points = summaries
                .Select((item, index) => new ReportChartPointDto(
                    item.Product,
                    item.QuantityWeightedMonthlyAverage,
                    $"{item.Product}: {Money(item.QuantityWeightedMonthlyAverage)}",
                    index))
                .ToArray()
        };
        return
        [
            new ReportChartDto
            {
                ChartType = "line",
                Title = "Actual selling-price observations",
                XAxisLabel = "Transaction date",
                YAxisLabel = "Stored unit price",
                Unit = "ZAR per unit",
                Series = lineSeries
            },
            new ReportChartDto
            {
                ChartType = "bar",
                Title = "Quantity-weighted monthly average by Product",
                XAxisLabel = "Product",
                YAxisLabel = "Weighted average selling price",
                Unit = "ZAR per unit",
                Series = [averageSeries]
            }
        ];
    }

    private static IReadOnlyList<ReportChartDto> AnnualPricingCharts(
        IReadOnlyList<AnnualPricingSummaryDto> summaries)
    {
        var monthNames = Enumerable.Range(1, 12)
            .Select(month => CultureInfo.InvariantCulture.DateTimeFormat
                .GetAbbreviatedMonthName(month))
            .ToArray();
        var lineSeries = summaries.Select(summary => new ReportChartSeriesDto
        {
            Name = summary.Product,
            Points = summary.MonthlyWeightedAverages
                .Select((value, index) => new ReportChartPointDto(
                    monthNames[index],
                    value,
                    value.HasValue
                        ? $"{summary.Product}, {monthNames[index]}: {Money(value.Value)}"
                        : $"{summary.Product}, {monthNames[index]}: N/A",
                    index))
                .ToArray()
        }).ToArray();
        var annualSeries = new ReportChartSeriesDto
        {
            Name = "Annual average of available monthly averages",
            Points = summaries
                .Select((item, index) => new ReportChartPointDto(
                    item.Product,
                    item.AnnualAverage,
                    item.AnnualAverage.HasValue
                        ? $"{item.Product}: {Money(item.AnnualAverage.Value)} from {item.MonthsWithData} months"
                        : $"{item.Product}: N/A",
                    index))
                .ToArray()
        };
        return
        [
            new ReportChartDto
            {
                ChartType = "line",
                Title = "Monthly weighted averages by Product",
                XAxisLabel = "Calendar month",
                YAxisLabel = "Monthly weighted average",
                Unit = "ZAR per unit",
                Series = lineSeries
            },
            new ReportChartDto
            {
                ChartType = "bar",
                Title = "Annual average by Product",
                XAxisLabel = "Product",
                YAxisLabel = "Average of available monthly averages",
                Unit = "ZAR per unit",
                Series = [annualSeries]
            }
        ];
    }

    private static SalesReportLineDto ToSalesLine(SalesLineProjection item) =>
        new(
            item.SalesOrderItemId,
            item.OrderDateUtc,
            item.OrderNumber,
            item.InvoiceNumber,
            item.Product,
            item.Category,
            item.QuantityKg,
            item.StoredUnitPrice,
            item.LineTotal,
            item.OrderStatus,
            item.DeliveryStatus);

    private static IReadOnlyList<ReportCriterionDto> Criteria(
        params (string Label, string? Value)[] values) =>
        values
            .Where(item => !string.IsNullOrWhiteSpace(item.Value))
            .Select(item => new ReportCriterionDto(
                item.Label,
                item.Value!.Trim()))
            .ToArray();

    private static ReportCodeOptionDto Code(string value) =>
        new(value, Friendly(value));

    private static string? FriendlyCriterion(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : Friendly(value);

    private static string YesNo(bool value) => value ? "Yes" : "No";

    private static string DateLabel(DateTime value) =>
        value.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);

    private static string Money(decimal value) =>
        value.ToString("C2", CultureInfo.GetCultureInfo("en-ZA"));

    private static string Friendly(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return "N/A";
        }

        var text = value.Trim();
        var characters = new List<char>(text.Length + 8);
        for (var index = 0; index < text.Length; index++)
        {
            if (index > 0 &&
                char.IsUpper(text[index]) &&
                !char.IsWhiteSpace(text[index - 1]) &&
                !char.IsUpper(text[index - 1]))
            {
                characters.Add(' ');
            }
            characters.Add(text[index] == '_' ? ' ' : text[index]);
        }
        return new string(characters.ToArray());
    }

    private sealed record InventoryStockProjection(
        int StockId,
        int ProductId,
        int SectionId,
        string ProductCode,
        string Product,
        string Category,
        string ProductType,
        string Section,
        decimal QuantityAvailableKg,
        decimal ReorderLevelKg,
        string InventoryStatus);

    private sealed record InventoryBatchProjection(
        int ProductBatchId,
        int ProductId,
        int SectionId,
        string BatchCode,
        decimal QuantityRemainingKg,
        DateTime EffectiveExpiryAtUtc,
        string Status);

    private sealed record MarkupSaleProjection(
        int SalesOrderItemId,
        int ProductId,
        string ProductCode,
        string Product,
        string Category,
        decimal QuantityKg,
        decimal UnitPrice);

    private sealed record SalesLineProjection(
        int SalesOrderItemId,
        int SalesOrderId,
        DateTime OrderDateUtc,
        string OrderNumber,
        int CustomerId,
        string Customer,
        string InvoiceNumber,
        string Product,
        string Category,
        decimal QuantityKg,
        decimal StoredUnitPrice,
        decimal LineTotal,
        string OrderStatus,
        string DeliveryStatus);

    private sealed record FinishedMovementProjection(
        long MovementId,
        int ProductBatchId,
        DateTime OccurredAtUtc,
        string MovementType,
        string Item,
        string Category,
        string Batch,
        string Section,
        decimal QuantityKg,
        string? Reason,
        string Actor,
        int? SalesOrderId,
        string? SalesOrderNumber,
        int? StockTakeSessionId);

    private sealed record NormalizedMovement(
        string Domain,
        string Category,
        string Item,
        StockMovementReportRowDto Row);

    private sealed record PricingObservationProjection(
        DateTime TransactionDateUtc,
        int ProductId,
        string Product,
        string OrderNumber,
        string InvoiceNumber,
        string Customer,
        decimal QuantitySoldKg,
        decimal StoredUnitPrice,
        decimal LineTotal,
        string Status);
}
