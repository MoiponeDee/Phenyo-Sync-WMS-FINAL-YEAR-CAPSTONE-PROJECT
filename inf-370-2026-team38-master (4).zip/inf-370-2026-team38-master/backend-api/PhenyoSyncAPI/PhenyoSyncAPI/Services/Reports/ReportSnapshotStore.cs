using System.Security.Cryptography;
using Microsoft.Extensions.Caching.Memory;

namespace PhenyoSyncAPI.Services.Reports;

public interface IReportSnapshotStore
{
    string Store<TReport>(int userId, string reportKey, TReport report)
        where TReport : class;

    TReport Get<TReport>(int userId, string reportKey, string token)
        where TReport : class;
}

/// <summary>Holds short-lived report previews so a PDF is generated from the reviewed snapshot.</summary>
public sealed class ReportSnapshotStore : IReportSnapshotStore
{
    private readonly IMemoryCache _cache;

    public ReportSnapshotStore(IMemoryCache cache)
    {
        _cache = cache;
    }

    public string Store<TReport>(int userId, string reportKey, TReport report)
        where TReport : class
    {
        var token = Convert.ToHexString(RandomNumberGenerator.GetBytes(24));
        _cache.Set(
            CacheKey(userId, reportKey, token),
            report,
            new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(30),
                Size = 1
            });
        return token;
    }

    public TReport Get<TReport>(int userId, string reportKey, string token)
        where TReport : class
    {
        if (string.IsNullOrWhiteSpace(token) ||
            !_cache.TryGetValue(
                CacheKey(userId, reportKey, token.Trim()),
                out TReport? report) ||
            report is null)
        {
            throw new ReportValidationException(
                "The report preview has expired. Generate the report again before downloading the PDF.");
        }

        return report;
    }

    private static string CacheKey(int userId, string reportKey, string token) =>
        $"report:{userId}:{reportKey}:{token}";
}

public sealed class ReportValidationException : Exception
{
    public int StatusCode => StatusCodes.Status400BadRequest;

    public ReportValidationException(string message)
        : base(message)
    {
    }
}
