using System.Globalization;
using System.Text;
using PhenyoSyncAPI.DTOs.Reports;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace PhenyoSyncAPI.Services.Reports;

public interface IReportPdfService
{
    GeneratedReportFile Generate(object report);
}

/// <summary>
/// Renders validated report DTOs into a common A4 landscape document. It performs no
/// database access, so the PDF always represents the exact preview snapshot supplied.
/// </summary>
public sealed class ReportPdfService : IReportPdfService
{
    private static readonly CultureInfo ReportNumberCulture =
        CultureInfo.GetCultureInfo("en-US");
    private const string Green = "#176b3a";
    private const string DarkGreen = "#173f29";
    private const string Mint = "#e9f7ed";
    private const string Border = "#d7e3da";
    private readonly byte[]? _logo;

    public ReportPdfService(IWebHostEnvironment environment)
    {
        _logo = FindLogo(environment);
    }

    // Keep dispatch exhaustive so an unsupported preview can never produce the wrong layout.
    public GeneratedReportFile Generate(object report) => report switch
    {
        InventoryReportDto value => File(
            value.Metadata,
            "inventory-position",
            column => Inventory(column, value)),
        ExpiryWasteReportDto value => File(
            value.Metadata,
            "expiry-waste-risk",
            column => ExpiryWaste(column, value)),
        MarkupReportDto value => File(
            value.Metadata,
            "product-markup-margin",
            column => Markup(column, value)),
        SalesReportDto value => File(
            value.Metadata,
            "sales-customer-product",
            column => Sales(column, value)),
        StockMovementReportDto value => File(
            value.Metadata,
            "stock-movement",
            column => StockMovement(column, value)),
        FinancialReportDto value => File(
            value.Metadata,
            "financial-activity",
            column => Financial(column, value)),
        PricingReportDto value => File(
            value.Metadata,
            "product-pricing-analysis",
            column => Pricing(column, value)),
        _ => throw new ReportValidationException(
            "The report preview type is not supported for PDF generation.")
    };

    private GeneratedReportFile File(
        ReportMetadataDto metadata,
        string fileStem,
        Action<ColumnDescriptor> content)
    {
        // Shared metadata, criteria and footer keep every formal report reviewable and traceable.
        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4.Landscape());
                page.Margin(24);
                page.DefaultTextStyle(style => style
                    .FontFamily(Fonts.Arial)
                    .FontSize(8)
                    .FontColor("#24382c"));
                page.Header().Element(header => Header(header, metadata));
                page.Content().PaddingVertical(12).Column(column =>
                {
                    column.Spacing(9);
                    AppliedCriteria(column, metadata);
                    content(column);
                });
                page.Footer().Row(row =>
                {
                    row.RelativeItem().Text(
                        "PhenyoSync WMS - Confidential internal business information")
                        .FontSize(7)
                        .FontColor(Colors.Grey.Darken1);
                    row.AutoItem()
                        .DefaultTextStyle(style => style.FontSize(7))
                        .Text(text =>
                        {
                            text.Span("Page ");
                            text.CurrentPageNumber();
                            text.Span(" of ");
                            text.TotalPages();
                        });
                });
            });
        });
        var name = $"PhenyoSync-{fileStem}-{metadata.GeneratedAtUtc:yyyyMMdd-HHmmss}.pdf";
        return new GeneratedReportFile(document.GeneratePdf(), name);
    }

    private void Header(IContainer container, ReportMetadataDto metadata)
    {
        container.BorderBottom(1).BorderColor(Green).PaddingBottom(9).Row(row =>
        {
            row.ConstantItem(52).Height(48).Element(logo =>
            {
                if (_logo is { Length: > 0 })
                {
                    logo.Image(_logo).FitArea();
                }
                else
                {
                    logo.Background(Green)
                        .AlignCenter()
                        .AlignMiddle()
                        .Text("PS")
                        .FontColor(Colors.White)
                        .FontSize(18)
                        .Bold();
                }
            });
            row.RelativeItem().PaddingLeft(12).Column(column =>
            {
                column.Item().Text("PhenyoSync WMS")
                    .FontSize(16)
                    .Bold()
                    .FontColor(Green);
                column.Item().Text(metadata.Title)
                    .FontSize(13)
                    .Bold()
                    .FontColor(DarkGreen);
                column.Item().Text(metadata.Classification)
                    .FontSize(8)
                    .FontColor(Colors.Grey.Darken1);
            });
            row.ConstantItem(250).AlignRight().Column(column =>
            {
                column.Item().Text(
                    $"Generated: {metadata.GeneratedAtUtc:dd MMM yyyy HH:mm} UTC");
                column.Item().Text($"Generated by: {metadata.GeneratedBy}");
                column.Item().Text($"Records: {metadata.RecordCount:N0}");
            });
        });
    }

    private static void AppliedCriteria(
        ColumnDescriptor column,
        ReportMetadataDto metadata)
    {
        column.Item().Background(Mint).Border(1).BorderColor(Border).Padding(8)
            .Column(criteria =>
            {
                criteria.Item().Text("Selected criteria").Bold().FontColor(Green);
                if (metadata.Criteria.Count == 0)
                {
                    criteria.Item().Text("All available records");
                    return;
                }
                criteria.Item().Text(string.Join(
                    "  |  ",
                    metadata.Criteria.Select(item =>
                        $"{item.Label}: {item.Value}")));
            });
    }

    private static void Inventory(
        ColumnDescriptor column,
        InventoryReportDto report)
    {
        column.Item().Text(
            $"Available: {Units(report.TotalAvailableQuantityKg)}  |  Reserved: {Units(report.TotalReservedQuantityKg)}")
            .Bold();
        column.Item().Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.ConstantColumn(55);
                columns.RelativeColumn(1.6f);
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
            });
            table.Header(header =>
            {
                HeaderCell(header, "Item code");
                HeaderCell(header, "Product");
                HeaderCell(header, "Category");
                HeaderCell(header, "Type");
                HeaderCell(header, "Section");
                HeaderCell(header, "Available units");
                HeaderCell(header, "Reserved units");
                HeaderCell(header, "Total units");
                HeaderCell(header, "Reorder units");
                HeaderCell(header, "Best before");
                HeaderCell(header, "Status");
            });
            foreach (var row in report.Rows)
            {
                Cell(table, row.ItemCode);
                Cell(table, row.Product);
                Cell(table, row.ProductCategory);
                Cell(table, row.ProductType);
                Cell(table, row.WarehouseSection);
                Cell(table, Number(row.AvailableQuantityKg));
                Cell(table, Number(row.ReservedQuantityKg));
                Cell(table, Number(row.TotalQuantityKg));
                Cell(table, Number(row.ReorderLevelKg));
                Cell(table, Date(row.BestBeforeDateUtc));
                Cell(table, Friendly(row.StockStatus));
            }
            FooterCell(table, "Page result total", 5);
            FooterCell(table, Number(report.Rows.Sum(item => item.AvailableQuantityKg)));
            FooterCell(table, Number(report.Rows.Sum(item => item.ReservedQuantityKg)));
            FooterCell(table, Number(report.Rows.Sum(item => item.TotalQuantityKg)));
            FooterCell(table, string.Empty);
            FooterCell(table, string.Empty);
            FooterCell(table, string.Empty);
        });
    }

    private static void ExpiryWaste(
        ColumnDescriptor column,
        ExpiryWasteReportDto report)
    {
        column.Item().Text(
            $"Quantity represented: {Number(report.TotalQuantityAtRiskKg)} across applicable units  |  Known loss value: {Money(report.TotalKnownLossValue)}")
            .Bold();
        column.Item().Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn();
                columns.ConstantColumn(52);
                columns.RelativeColumn(1.5f);
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
            });
            table.Header(header =>
            {
                HeaderCell(header, "Record type");
                HeaderCell(header, "Item code");
                HeaderCell(header, "Item");
                HeaderCell(header, "Section");
                HeaderCell(header, "Quantity");
                HeaderCell(header, "Best before");
                HeaderCell(header, "Days");
                HeaderCell(header, "Risk status");
                HeaderCell(header, "Write-off reason");
                HeaderCell(header, "Unit cost");
                HeaderCell(header, "Loss value");
                HeaderCell(header, "Responsible user");
                HeaderCell(header, "Recorded");
            });
            foreach (var row in report.Rows)
            {
                Cell(table, Friendly(row.RecordType));
                Cell(table, row.ItemCode);
                Cell(table, row.Item);
                Cell(table, row.WarehouseSection);
                Cell(table, $"{Number(row.QuantityKg)} {row.UnitOfMeasure}");
                Cell(table, Date(row.BestBeforeDateUtc));
                Cell(table, row.DaysRemaining?.ToString() ?? "N/A");
                Cell(table, Friendly(row.RiskStatus));
                Cell(table, row.WriteOffReason ?? "N/A");
                Cell(table, Money(row.EstimatedUnitCost));
                Cell(table, Money(row.EstimatedLossValue));
                Cell(table, row.ResponsibleUser);
                Cell(table, DateTimeLabel(row.RecordedAtUtc));
            }
        });
    }

    private static void Markup(
        ColumnDescriptor column,
        MarkupReportDto report)
    {
        column.Item().Text(
            "Markup compares selling price with cost; gross margin expresses the same difference as a percentage of selling price.")
            .Italic();
        column.Item().Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.ConstantColumn(58);
                columns.RelativeColumn(1.5f);
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn(1.2f);
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
            });
            table.Header(header =>
            {
                HeaderCell(header, "Product code");
                HeaderCell(header, "Product");
                HeaderCell(header, "Category");
                HeaderCell(header, "Qty sold units");
                HeaderCell(header, "Average selling price");
                HeaderCell(header, "Average cost");
                HeaderCell(header, "Cost source");
                HeaderCell(header, "Markup / unit");
                HeaderCell(header, "Markup %");
                HeaderCell(header, "Gross margin %");
                HeaderCell(header, "Data quality");
            });
            foreach (var row in report.Rows)
            {
                Cell(table, row.ProductCode);
                Cell(table, row.Product);
                Cell(table, row.ProductCategory);
                Cell(table, Number(row.TotalQuantitySoldKg));
                Cell(table, Money(row.AverageSellingPrice));
                Cell(table, Money(row.AverageCost));
                Cell(table, Friendly(row.CostSource));
                Cell(table, Money(row.MarkupAmountPerKg));
                Cell(table, Percentage(row.MarkupPercentage));
                Cell(table, Percentage(row.GrossMarginPercentage));
                Cell(table, Friendly(row.DataQualityStatus));
            }
        });
    }

    private static void Sales(ColumnDescriptor column, SalesReportDto report)
    {
        column.Item().Row(row =>
        {
            Summary(row, "Orders", report.TotalOrders.ToString("N0"));
            Summary(row, "Quantity sold", Units(report.GrandQuantitySoldKg));
            Summary(row, "Grand sales value", Money(report.GrandSalesValue));
            Summary(row, "Average order value", Money(report.AverageOrderValue));
        });
        foreach (var month in report.Months)
        {
            column.Item().PaddingTop(8).Background(DarkGreen).Padding(8).Row(row =>
            {
                row.RelativeItem().Text(month.MonthLabel)
                    .FontColor(Colors.White)
                    .FontSize(11)
                    .Bold();
                row.AutoItem().Text(
                    $"Month subtotal: {Units(month.MonthQuantitySubtotalKg)} | {Money(month.MonthValueSubtotal)}")
                    .FontColor(Colors.White)
                    .Bold();
            });
            foreach (var customer in month.Customers)
            {
                column.Item().Background(Mint).Padding(6).Row(row =>
                {
                    row.RelativeItem().Text(customer.Customer).Bold().FontColor(Green);
                    row.AutoItem().Text(
                        $"Customer subtotal: {Units(customer.CustomerQuantitySubtotalKg)} | {Money(customer.CustomerValueSubtotal)}")
                        .Bold();
                });
                column.Item().Table(table =>
                {
                    table.ColumnsDefinition(columns =>
                    {
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn(1.5f);
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                    });
                    table.Header(header =>
                    {
                        HeaderCell(header, "Order date");
                        HeaderCell(header, "Order");
                        HeaderCell(header, "Invoice");
                        HeaderCell(header, "Product");
                        HeaderCell(header, "Category");
                        HeaderCell(header, "Quantity units");
                        HeaderCell(header, "Stored unit price");
                        HeaderCell(header, "Line total");
                        HeaderCell(header, "Order status");
                        HeaderCell(header, "Delivery status");
                    });
                    foreach (var order in customer.Orders)
                    {
                        foreach (var line in order.Lines)
                        {
                            Cell(table, Date(line.OrderDateUtc));
                            Cell(table, line.OrderNumber);
                            Cell(table, line.InvoiceNumber);
                            Cell(table, line.Product);
                            Cell(table, line.ProductCategory);
                            Cell(table, Number(line.QuantityKg));
                            Cell(table, Money(line.StoredUnitPrice));
                            Cell(table, Money(line.LineTotal));
                            Cell(table, Friendly(line.OrderStatus));
                            Cell(table, Friendly(line.DeliveryStatus));
                        }
                        FooterCell(table, $"Order {order.OrderNumber} subtotal", 5);
                        FooterCell(table, Number(order.OrderQuantitySubtotalKg));
                        FooterCell(table, string.Empty);
                        FooterCell(table, Money(order.OrderValueSubtotal));
                        FooterCell(table, string.Empty);
                        FooterCell(table, string.Empty);
                    }
                });
            }
        }
        column.Item().Background(Green).Padding(9).Text(
            $"Grand total: {Units(report.GrandQuantitySoldKg)} | {Money(report.GrandSalesValue)}")
            .FontColor(Colors.White)
            .FontSize(11)
            .Bold();
    }

    private static void StockMovement(
        ColumnDescriptor column,
        StockMovementReportDto report)
    {
        column.Item().Row(row =>
        {
            Summary(row, "Quantity in (mixed units)", Number(report.GrandTotalInKg));
            Summary(row, "Quantity out (mixed units)", Number(report.GrandTotalOutKg));
            Summary(row, "Net movement (mixed units)", Number(report.GrandNetMovementKg));
            Summary(row, "Known movement value", Money(report.GrandMovementValue));
        });
        foreach (var domain in report.Domains)
        {
            column.Item().PaddingTop(8).Background(DarkGreen).Padding(8).Row(row =>
            {
                row.RelativeItem().Text(Friendly(domain.StockDomain))
                    .FontColor(Colors.White)
                    .FontSize(11)
                    .Bold();
                row.AutoItem().Text(
                    $"Domain subtotal: In {DomainQuantity(domain.TotalInKg, domain.StockDomain)} | Out {DomainQuantity(domain.TotalOutKg, domain.StockDomain)} | Net {DomainQuantity(domain.NetMovementKg, domain.StockDomain)} | {Money(domain.MovementValue)}")
                    .FontColor(Colors.White)
                    .Bold();
            });
            foreach (var category in domain.Categories)
            {
                column.Item().Background(Mint).Padding(6).Row(row =>
                {
                    row.RelativeItem().Text(category.Category).Bold().FontColor(Green);
                    row.AutoItem().Text(
                        $"Category subtotal: In {DomainQuantity(category.TotalInKg, domain.StockDomain)} | Out {DomainQuantity(category.TotalOutKg, domain.StockDomain)} | Net {DomainQuantity(category.NetMovementKg, domain.StockDomain)}")
                        .Bold();
                });
                column.Item().Table(table =>
                {
                    table.ColumnsDefinition(columns =>
                    {
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn(1.4f);
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                    });
                    table.Header(header =>
                    {
                        HeaderCell(header, "Date/time");
                        HeaderCell(header, "Movement type");
                        HeaderCell(header, "Reference");
                        HeaderCell(header, "Item");
                        HeaderCell(header, "Section");
                        HeaderCell(header, $"In {DomainUnit(domain.StockDomain)}");
                        HeaderCell(header, $"Out {DomainUnit(domain.StockDomain)}");
                        HeaderCell(header, $"Net {DomainUnit(domain.StockDomain)}");
                        HeaderCell(header, "Unit cost");
                        HeaderCell(header, "Value");
                        HeaderCell(header, "Reason");
                        HeaderCell(header, "Actor");
                    });
                    foreach (var item in category.Items)
                    {
                        foreach (var movement in item.Movements)
                        {
                            Cell(table, DateTimeLabel(movement.MovementDateUtc));
                            Cell(table, Friendly(movement.MovementType));
                            Cell(table, movement.Reference);
                            Cell(table, movement.Item);
                            Cell(table, movement.WarehouseSection);
                            Cell(table, $"{Number(movement.QuantityInKg)} {movement.UnitOfMeasure}");
                            Cell(table, $"{Number(movement.QuantityOutKg)} {movement.UnitOfMeasure}");
                            Cell(table, $"{Number(movement.NetMovementKg)} {movement.UnitOfMeasure}");
                            Cell(table, Money(movement.UnitCost));
                            Cell(table, Money(movement.MovementValue));
                            Cell(table, movement.Reason);
                            Cell(table, movement.Actor);
                        }
                        FooterCell(table, $"{item.Item} subtotal", 5);
                        var itemUnit = item.Movements.FirstOrDefault()?.UnitOfMeasure
                            ?? DomainUnit(domain.StockDomain);
                        FooterCell(table, $"{Number(item.TotalInKg)} {itemUnit}");
                        FooterCell(table, $"{Number(item.TotalOutKg)} {itemUnit}");
                        FooterCell(table, $"{Number(item.NetMovementKg)} {itemUnit}");
                        FooterCell(table, string.Empty);
                        FooterCell(table, Money(item.MovementValue));
                        FooterCell(table, string.Empty);
                        FooterCell(table, string.Empty);
                    }
                });
            }
        }
        column.Item().Background(Green).Padding(9).Text(
            $"Grand total across stock domains: In {Number(report.GrandTotalInKg)} | Out {Number(report.GrandTotalOutKg)} | Net {Number(report.GrandNetMovementKg)} | {Money(report.GrandMovementValue)}")
            .FontColor(Colors.White)
            .FontSize(11)
            .Bold();
    }

    private static void Financial(
        ColumnDescriptor column,
        FinancialReportDto report)
    {
        column.Item().Row(row =>
        {
            Summary(row, "Sales value", Money(report.Summary.SalesValue));
            Summary(row, "Customer receipts", Money(report.Summary.CustomerReceipts));
            Summary(row, "Supplier payments", Money(report.Summary.SupplierPayments));
            Summary(row, "Net cash movement", Money(report.Summary.NetCashMovement));
        });
        column.Item().Row(row =>
        {
            Summary(row, "Write-off loss", Money(report.Summary.WriteOffLoss));
            Summary(row, "Customer outstanding", Money(report.Summary.CustomerOutstandingBalance));
            Summary(row, "Supplier outstanding", Money(report.Summary.SupplierOutstandingBalance));
            Summary(row, "Transactions", report.TotalRecords.ToString("N0"));
        });
        column.Item().Text(
            "Net cash movement is posted customer receipts less posted supplier payments. This is not a profit-and-loss statement.")
            .Italic();
        column.Item().Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn(1.4f);
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn();
                columns.RelativeColumn(1.5f);
            });
            table.Header(header =>
            {
                HeaderCell(header, "Date");
                HeaderCell(header, "Transaction type");
                HeaderCell(header, "Reference");
                HeaderCell(header, "Counterparty");
                HeaderCell(header, "Status");
                HeaderCell(header, "Payment method");
                HeaderCell(header, "Amount");
                HeaderCell(header, "Direction");
                HeaderCell(header, "Notes");
            });
            foreach (var row in report.Rows)
            {
                Cell(table, Date(row.TransactionDateUtc));
                Cell(table, Friendly(row.TransactionType));
                Cell(table, row.Reference);
                Cell(table, row.Counterparty);
                Cell(table, Friendly(row.Status));
                Cell(table, Friendly(row.PaymentMethod));
                Cell(table, Money(row.Amount));
                Cell(table, Friendly(row.Direction));
                Cell(table, row.Notes);
            }
        });
    }

    private static void Pricing(
        ColumnDescriptor column,
        PricingReportDto report)
    {
        column.Item().Text(
            "Monthly values are quantity weighted per Product. Annual values are the arithmetic mean of available monthly weighted averages; N/A months are excluded.")
            .Italic();
        for (var chartIndex = 0;
             chartIndex < report.Charts.Count;
             chartIndex++)
        {
            var chart = report.Charts[chartIndex];
            if (chartIndex > 0)
            {
                column.Item().PageBreak();
            }

            column.Item().PaddingTop(8).Text(chart.Title)
                .FontSize(11)
                .Bold()
                .FontColor(Green);
            column.Item().Height(220).Svg(ChartSvg(chart));
            ChartDataTable(column, chart);
        }

        if (report.ViewMode == "monthly")
        {
            column.Item().PaddingTop(8).Text("Monthly Product summary")
                .FontSize(11)
                .Bold();
            column.Item().Table(table =>
            {
                table.ColumnsDefinition(columns =>
                {
                    columns.ConstantColumn(126);
                    columns.ConstantColumn(64);
                    columns.ConstantColumn(48);
                    columns.ConstantColumn(76);
                    columns.ConstantColumn(76);
                    columns.ConstantColumn(76);
                    columns.ConstantColumn(76);
                    columns.ConstantColumn(76);
                    columns.ConstantColumn(76);
                });
                table.Header(header =>
                {
                    HeaderCell(header, "Product");
                    HeaderCell(header, "Quantity sold units");
                    HeaderCell(header, "Observations");
                    HeaderCell(header, "Minimum");
                    HeaderCell(header, "Maximum");
                    HeaderCell(header, "Median");
                    HeaderCell(header, "Weighted average");
                    HeaderCell(header, "Current price");
                    HeaderCell(header, "Current difference");
                });
                foreach (var row in report.MonthlySummaries)
                {
                    Cell(table, row.Product);
                    NumericCell(table, Number(row.TotalQuantitySoldKg));
                    NumericCell(table, row.PriceObservationCount.ToString("N0"));
                    NumericCell(table, Money(row.MinimumPrice));
                    NumericCell(table, Money(row.MaximumPrice));
                    NumericCell(table, Money(row.MedianPrice));
                    NumericCell(table, Money(row.QuantityWeightedMonthlyAverage));
                    NumericCell(table, Money(row.CurrentActivePrice));
                    NumericCell(table, Money(row.DifferenceFromCurrentPrice));
                }
            });
            column.Item().PaddingTop(8).Text("Full monthly price observations")
                .FontSize(11)
                .Bold();
            column.Item().Table(table =>
            {
                table.ColumnsDefinition(columns =>
                {
                    columns.ConstantColumn(62);
                    columns.ConstantColumn(120);
                    columns.ConstantColumn(64);
                    columns.ConstantColumn(60);
                    columns.ConstantColumn(105);
                    columns.ConstantColumn(56);
                    columns.ConstantColumn(70);
                    columns.ConstantColumn(70);
                    columns.ConstantColumn(70);
                });
                table.Header(header =>
                {
                    HeaderCell(header, "Transaction date");
                    HeaderCell(header, "Product");
                    HeaderCell(header, "Order");
                    HeaderCell(header, "Invoice");
                    HeaderCell(header, "Customer");
                    HeaderCell(header, "Quantity units");
                    HeaderCell(header, "Stored unit price");
                    HeaderCell(header, "Line total");
                    HeaderCell(header, "Status");
                });
                foreach (var row in report.Observations)
                {
                    Cell(table, Date(row.TransactionDateUtc));
                    Cell(table, row.Product);
                    Cell(table, row.OrderNumber);
                    Cell(table, row.InvoiceNumber);
                    Cell(table, row.Customer);
                    NumericCell(table, Number(row.QuantitySoldKg));
                    NumericCell(table, Money(row.StoredUnitPrice));
                    NumericCell(table, Money(row.LineTotal));
                    Cell(table, Friendly(row.QualifyingStatus));
                }
            });
        }
        else
        {
            column.Item().PaddingTop(8).Text("Annual Product summary")
                .FontSize(11)
                .Bold();
            column.Item().Table(table =>
            {
                table.ColumnsDefinition(columns =>
                {
                    columns.ConstantColumn(110);
                    for (var index = 0; index < 12; index++)
                    {
                        columns.ConstantColumn(38);
                    }
                    columns.ConstantColumn(60);
                    columns.ConstantColumn(60);
                    columns.ConstantColumn(70);
                });
                table.Header(header =>
                {
                    HeaderCell(header, "Product");
                    foreach (var month in Enumerable.Range(1, 12))
                    {
                        HeaderCell(
                            header,
                            CultureInfo.InvariantCulture.DateTimeFormat
                                .GetAbbreviatedMonthName(month),
                            6);
                    }
                    HeaderCell(header, "Months with data");
                    HeaderCell(header, "Months without data");
                    HeaderCell(header, "Annual average");
                });
                foreach (var row in report.AnnualSummaries)
                {
                    Cell(table, row.Product);
                    foreach (var month in row.MonthlyWeightedAverages)
                    {
                        NumericCell(table, Money(month));
                    }
                    NumericCell(table, row.MonthsWithData.ToString());
                    NumericCell(table, row.MonthsWithoutData.ToString());
                    NumericCell(table, Money(row.AnnualAverage));
                }
            });
        }
    }

    private static void ChartDataTable(
        ColumnDescriptor column,
        ReportChartDto chart)
    {
        column.Item().Text(
            $"Supporting data table - {chart.YAxisLabel} ({chart.Unit})")
            .Bold();
        column.Item().Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn();
                columns.RelativeColumn(2);
                columns.RelativeColumn();
                columns.RelativeColumn(2);
            });
            table.Header(header =>
            {
                HeaderCell(header, chart.ChartType == "box" ? "Product" : "Series");
                HeaderCell(header, chart.ChartType == "box" ? "Distribution" : "Point");
                HeaderCell(header, "Value");
                HeaderCell(header, "Exact detail");
            });
            if (chart.ChartType == "box")
            {
                foreach (var box in chart.BoxPlots)
                {
                    Cell(table, box.Label);
                    Cell(table, box.Distribution.IsReliable
                        ? "Minimum / Q1 / Median / Q3 / Maximum"
                        : "Insufficient observations");
                    Cell(table, box.Distribution.IsReliable
                        ? string.Join(" / ",
                            new[]
                            {
                                box.Distribution.Minimum,
                                box.Distribution.Q1,
                                box.Distribution.Median,
                                box.Distribution.Q3,
                                box.Distribution.Maximum
                            }.Select(Money))
                        : "N/A");
                    Cell(table, box.Distribution.Message);
                }
                return;
            }
            foreach (var series in chart.Series)
            {
                foreach (var point in series.Points)
                {
                    Cell(table, series.Name);
                    Cell(table, point.Label);
                    Cell(table, FormatChartValue(point.Value, chart.Unit));
                    Cell(table, point.Tooltip);
                }
            }
        });
    }

    private static string ChartSvg(ReportChartDto chart)
    {
        const decimal left = 70;
        const decimal top = 55;
        const decimal plotWidth = 850;
        const decimal plotHeight = 145;
        var values = chart.Series
            .SelectMany(item => item.Points)
            .Where(item => item.Value.HasValue)
            .Select(item => item.Value!.Value)
            .Concat(chart.BoxPlots
                .Where(item => item.Distribution.IsReliable)
                .SelectMany(item => new[]
                {
                    item.Distribution.Minimum,
                    item.Distribution.Maximum
                }))
            .ToArray();
        var maximum = values.Length == 0 ? 1 : Math.Max(1, values.Max());
        var minimum = values.Length == 0 ? 0 : Math.Min(0, values.Min());
        var range = Math.Max(1, maximum - minimum);
        decimal Y(decimal value) =>
            top + plotHeight - (value - minimum) / range * plotHeight;
        var builder = new StringBuilder();
        builder.Append("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 960 300'>");
        builder.Append("<rect width='960' height='300' fill='white'/>");
        var legendColours = new[]
        {
            "#176b3a",
            "#e08b2d",
            "#2e6fb0",
            "#8a4f9e"
        };
        for (var legendIndex = 0;
             legendIndex < chart.Series.Count;
             legendIndex++)
        {
            var legendX = left + legendIndex * 210;
            builder.Append(
                $"<rect x='{legendX}' y='16' width='11' height='11' " +
                $"rx='2' fill='{legendColours[legendIndex % legendColours.Length]}'/>");
            builder.Append(
                $"<text x='{legendX + 17}' y='26' font-size='10' " +
                $"fill='#385045'>{Escape(Short(chart.Series[legendIndex].Name, 28))}</text>");
        }
        builder.Append($"<line x1='{left}' y1='{top}' x2='{left}' y2='{top + plotHeight}' stroke='#52705e'/>");
        builder.Append($"<line x1='{left}' y1='{top + plotHeight}' x2='{left + plotWidth}' y2='{top + plotHeight}' stroke='#52705e'/>");
        builder.Append(
            $"<text x='14' y='{top + plotHeight / 2}' text-anchor='middle' " +
            $"transform='rotate(-90 14 {top + plotHeight / 2})' " +
            $"font-size='11' fill='#385045'>{Escape(chart.YAxisLabel)}</text>");
        builder.Append(
            $"<text x='{left + plotWidth / 2}' y='285' text-anchor='middle' " +
            $"font-size='11' fill='#385045'>{Escape(chart.XAxisLabel)}</text>");
        if (chart.ChartType == "bar")
        {
            var points = chart.Series.SelectMany(item => item.Points).ToArray();
            var barWidth = points.Length == 0
                ? plotWidth
                : Math.Max(12, plotWidth / points.Length * 0.62m);
            for (var index = 0; index < points.Length; index++)
            {
                var point = points[index];
                if (!point.Value.HasValue)
                {
                    continue;
                }
                var x = left + (index + 0.5m) * plotWidth / points.Length;
                var y = Y(point.Value.Value);
                var zeroY = Y(0);
                builder.Append($"<rect x='{x - barWidth / 2}' y='{Math.Min(y, zeroY)}' width='{barWidth}' height='{Math.Max(2, Math.Abs(zeroY - y))}' rx='3' fill='#2f7d4a'/>");
                builder.Append($"<text x='{x}' y='{top + plotHeight + 15}' text-anchor='middle' font-size='8' fill='#385045'>{Escape(Short(point.Label, 14))}</text>");
            }
        }
        else if (chart.ChartType == "line")
        {
            var colours = new[] { "#176b3a", "#e08b2d", "#2e6fb0", "#8a4f9e" };
            for (var seriesIndex = 0; seriesIndex < chart.Series.Count; seriesIndex++)
            {
                var series = chart.Series[seriesIndex];
                var count = Math.Max(1, series.Points.Count - 1);
                var segments = new List<List<string>>
                {
                    new()
                };
                for (var index = 0; index < series.Points.Count; index++)
                {
                    var point = series.Points[index];
                    if (!point.Value.HasValue)
                    {
                        if (segments[^1].Count > 0)
                        {
                            segments.Add(new List<string>());
                        }
                        continue;
                    }
                    var x = left + index * plotWidth / count;
                    segments[^1].Add($"{x},{Y(point.Value.Value)}");
                }
                foreach (var segment in segments.Where(item => item.Count > 1))
                {
                    builder.Append(
                        $"<polyline points='{string.Join(' ', segment)}' " +
                        $"fill='none' " +
                        $"stroke='{colours[seriesIndex % colours.Length]}' " +
                        "stroke-width='3'/>");
                }
            }
        }
        else
        {
            var reliable = chart.BoxPlots
                .Where(item => item.Distribution.IsReliable)
                .ToArray();
            for (var index = 0; index < reliable.Length; index++)
            {
                var box = reliable[index];
                var x = left + (index + 0.5m) * plotWidth / reliable.Length;
                var distribution = box.Distribution;
                builder.Append(
                    $"<line x1='{x}' y1='{Y(distribution.Minimum)}' " +
                    $"x2='{x}' y2='{Y(distribution.Maximum)}' " +
                    "stroke='#176b3a' stroke-width='2'/>");
                builder.Append(
                    $"<rect x='{x - 24}' y='{Y(distribution.Q3)}' " +
                    $"width='48' height='{Math.Max(
                        3,
                        Y(distribution.Q1) - Y(distribution.Q3))}' " +
                    "fill='#dff5e8' stroke='#176b3a' stroke-width='2'/>");
                builder.Append(
                    $"<line x1='{x - 24}' y1='{Y(distribution.Median)}' " +
                    $"x2='{x + 24}' y2='{Y(distribution.Median)}' " +
                    "stroke='#e08b2d' stroke-width='3'/>");
                builder.Append(
                    $"<text x='{x}' y='{top + plotHeight + 15}' " +
                    "text-anchor='middle' font-size='8' fill='#385045'>" +
                    $"{Escape(Short(box.Label, 14))}</text>");
            }
            if (reliable.Length == 0)
            {
                builder.Append(
                    "<text x='480' y='120' text-anchor='middle' " +
                    "font-size='14' fill='#6b746e'>" +
                    "Not enough price observations to calculate a reliable " +
                    "distribution.</text>");
            }
        }
        builder.Append("</svg>");
        return builder.ToString();
    }

    private static void HeaderCell(
        TableCellDescriptor header,
        string text,
        float fontSize = 7) =>
        header.Cell().Background(DarkGreen).Padding(5).Text(text)
            .FontColor(Colors.White)
            .FontSize(fontSize)
            .Bold();

    private static void Cell(TableDescriptor table, string text) =>
        table.Cell().BorderBottom(0.5f).BorderColor(Border).Padding(4).Text(text)
            .FontSize(7);

    private static void NumericCell(TableDescriptor table, string text) =>
        table.Cell().BorderBottom(0.5f).BorderColor(Border).Padding(4)
            .AlignRight().Text(text).FontSize(7);

    private static void FooterCell(
        TableDescriptor table,
        string text,
        uint columnSpan = 1) =>
        table.Cell().ColumnSpan(columnSpan).Background(Mint).Padding(4).Text(text)
            .FontSize(7)
            .Bold();

    private static void Summary(RowDescriptor row, string label, string value)
    {
        row.RelativeItem().PaddingRight(6).Border(1).BorderColor(Border)
            .Background(Mint).Padding(7).Column(column =>
            {
                column.Item().Text(label).FontSize(7).FontColor(Colors.Grey.Darken1);
                column.Item().Text(value).FontSize(10).Bold().FontColor(Green);
            });
    }

    private static byte[]? FindLogo(IWebHostEnvironment environment)
    {
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "Assets", "logo.png"),
            Path.Combine(environment.ContentRootPath, "Assets", "logo.png"),
            Path.GetFullPath(Path.Combine(
                environment.ContentRootPath,
                "..",
                "..",
                "..",
                "frontend",
                "phenyosync",
                "src",
                "assets",
                "logo.png"))
        };
        var path = candidates.FirstOrDefault(System.IO.File.Exists);
        return path is null ? null : System.IO.File.ReadAllBytes(path);
    }

    private static string Money(decimal? value) =>
        value.HasValue
            ? $"R {value.Value.ToString("N2", ReportNumberCulture)}"
            : "N/A";

    private static string Money(decimal value) =>
        $"R {value.ToString("N2", ReportNumberCulture)}";

    private static string Percentage(decimal? value) =>
        value.HasValue ? $"{value.Value:N2}%" : "N/A";

    private static string Number(decimal value) =>
        value.ToString("N2", ReportNumberCulture);

    private static string Kg(decimal value) => $"{Number(value)} kg";

    private static string Units(decimal value) => $"{Number(value)} units";

    private static string DomainUnit(string stockDomain) =>
        stockDomain.Contains("Raw", StringComparison.OrdinalIgnoreCase)
            ? "configured units"
            : "units";

    private static string DomainQuantity(decimal value, string stockDomain) =>
        $"{Number(value)} {DomainUnit(stockDomain)}";

    private static string FormatChartValue(decimal? value, string unit)
    {
        if (!value.HasValue)
        {
            return "N/A";
        }

        if (unit.StartsWith("ZAR", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(unit, "R", StringComparison.OrdinalIgnoreCase))
        {
            return Money(value.Value);
        }

        if (string.Equals(unit, "%", StringComparison.OrdinalIgnoreCase))
        {
            return Percentage(value.Value);
        }

        return $"{Number(value.Value)} {unit}".Trim();
    }

    private static string Friendly(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return "N/A";
        }

        var spaced = System.Text.RegularExpressions.Regex.Replace(
            value.Trim().Replace('_', ' ').Replace('-', ' '),
            "(?<=[a-z0-9])(?=[A-Z])",
            " ");
        return System.Text.RegularExpressions.Regex.Replace(
            spaced,
            @"\s+",
            " ");
    }

    private static string Date(DateTime? value) =>
        value.HasValue ? value.Value.ToString("dd MMM yyyy") : "N/A";

    private static string DateTimeLabel(DateTime value) =>
        value.ToString("dd MMM yyyy HH:mm") + " UTC";

    private static string Escape(string value) =>
        value.Replace("&", "&amp;", StringComparison.Ordinal)
            .Replace("<", "&lt;", StringComparison.Ordinal)
            .Replace(">", "&gt;", StringComparison.Ordinal)
            .Replace("'", "&apos;", StringComparison.Ordinal)
            .Replace("\"", "&quot;", StringComparison.Ordinal);

    private static string Short(string value, int length) =>
        value.Length <= length ? value : value[..(length - 1)] + "…";
}
