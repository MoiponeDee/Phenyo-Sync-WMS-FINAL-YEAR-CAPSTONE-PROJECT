using PhenyoSyncAPI.DTOs.Reports;

namespace PhenyoSyncAPI.Services.Reports;

/// <summary>Contains deterministic statistical helpers shared by formal report projections.</summary>
public static class ReportStatistics
{
    public static decimal? QuantityWeightedAverage(
        IEnumerable<(decimal Quantity, decimal Value)> observations)
    {
        var rows = observations.ToArray();
        var totalQuantity = rows.Sum(item => item.Quantity);
        if (totalQuantity <= 0)
        {
            return null;
        }

        return rows.Sum(item => item.Quantity * item.Value) /
            totalQuantity;
    }

    public static decimal? AnnualAverage(
        IEnumerable<decimal?> monthlyWeightedAverages)
    {
        var availableMonths = monthlyWeightedAverages
            .Where(value => value.HasValue)
            .Select(value => value!.Value)
            .ToArray();
        return availableMonths.Length == 0
            ? null
            : availableMonths.Average();
    }

    public static PriceDistributionDto Distribution(
        IEnumerable<decimal> observations,
        int minimumReliableObservations = 5)
    {
        var ordered = observations.OrderBy(value => value).ToArray();
        if (ordered.Length == 0)
        {
            return new PriceDistributionDto(
                0,
                0,
                0,
                0,
                0,
                0,
                [],
                0,
                false,
                "No price observations are available.");
        }

        var minimum = ordered[0];
        var maximum = ordered[^1];
        var q1 = Percentile(ordered, 0.25m);
        var median = Percentile(ordered, 0.50m);
        var q3 = Percentile(ordered, 0.75m);
        var iqr = q3 - q1;
        var lowerBoundary = q1 - 1.5m * iqr;
        var upperBoundary = q3 + 1.5m * iqr;
        var outliers = ordered
            .Where(value =>
                value < lowerBoundary ||
                value > upperBoundary)
            .ToArray();
        var reliable = ordered.Length >= minimumReliableObservations;

        return new PriceDistributionDto(
            minimum,
            q1,
            median,
            q3,
            maximum,
            iqr,
            reliable ? outliers : [],
            ordered.Length,
            reliable,
            reliable
                ? "Distribution uses linear-interpolated quartiles and the 1.5 x IQR outlier rule."
                : "Not enough price observations to calculate a reliable distribution.");
    }

    public static decimal Median(IEnumerable<decimal> values)
    {
        var ordered = values.OrderBy(value => value).ToArray();
        return ordered.Length == 0
            ? 0
            : Percentile(ordered, 0.50m);
    }

    private static decimal Percentile(
        decimal[] ordered,
        decimal percentile)
    {
        if (ordered.Length == 1)
        {
            return ordered[0];
        }

        var position = (ordered.Length - 1) * percentile;
        var lower = (int)Math.Floor(position);
        var upper = (int)Math.Ceiling(position);
        if (lower == upper)
        {
            return ordered[lower];
        }

        var fraction = position - lower;
        return ordered[lower] +
            (ordered[upper] - ordered[lower]) * fraction;
    }
}
