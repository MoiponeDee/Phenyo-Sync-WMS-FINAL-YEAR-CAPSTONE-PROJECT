using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public interface IQrResolutionService
{
    Task<ProductBatchQrResultDto> ResolveAsync(
        string value,
        int userId,
        CancellationToken cancellationToken);
}

/// <summary>Resolves supported QR payloads to existing domain records; it never creates stock from a scan.</summary>
public sealed class QrResolutionService : IQrResolutionService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly ISystemSettingProvider _settings;
    private readonly IAuditService _audit;

    public QrResolutionService(
        PhenyoSyncDbContext context,
        ISystemSettingProvider settings,
        IAuditService audit)
    {
        _context = context;
        _settings = settings;
        _audit = audit;
    }

    public async Task<ProductBatchQrResultDto> ResolveAsync(
        string value,
        int userId,
        CancellationToken cancellationToken)
    {
        var raw = value?.Trim() ?? string.Empty;
        if (raw.Length is < 5 or > 500)
            throw new PhaseBException(400, "The scanned QR value has an invalid format.");
        var batchCode = raw.StartsWith(
                "PHENYOSYNC:BATCH:",
                StringComparison.OrdinalIgnoreCase)
            ? raw["PHENYOSYNC:BATCH:".Length..]
            : raw;
        var batch = await _context.ProductBatches.AsNoTracking()
            .Where(item =>
                item.QRCodeValue == raw ||
                item.BatchCode == batchCode)
            .Select(item => new
            {
                item.ProductBatchId,
                item.ProductId,
                ProductCode = item.Product.QRCodeValue ??
                    ("PRODUCT-" + item.ProductId),
                item.Product.ProductName,
                CategoryName = item.Product.ProductCategory!.ProductCategoryName,
                TypeName = item.Product.ProductType!.ProductTypeName,
                item.BatchCode,
                item.QRCodeValue,
                item.PackedAtUtc,
                item.EffectiveExpiryAtUtc,
                BatchStatus = item.Status,
                ProductStatus = item.Product.Status,
                item.QuantityRemainingKg,
                item.SectionId,
                item.WarehouseSection.SectionName
            })
            .SingleOrDefaultAsync(cancellationToken)
            ?? throw new PhaseBException(404, "No Product Batch matches the scanned QR code.");
        var now = DateTime.UtcNow;
        var redHours = await _settings.GetIntAsync(
            SystemSettingKeys.ExpiryRedThresholdHours,
            cancellationToken);
        var yellowHours = await _settings.GetIntAsync(
            SystemSettingKeys.ExpiryYellowThresholdHours,
            cancellationToken);
        var risk = batch.EffectiveExpiryAtUtc <= now
            ? "Expired"
            : batch.EffectiveExpiryAtUtc <= now.AddHours(redHours)
                ? "Red"
                : batch.EffectiveExpiryAtUtc <= now.AddHours(yellowHours)
                    ? "Yellow"
                    : "Normal";
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.Scan,
            SystemModule = AuditModules.QrScanning,
            OperationName = "Resolve Product Batch QR",
            Description = $"Resolved Product Batch {batch.BatchCode} from a camera or manual scan.",
            EntityType = "ProductBatch",
            EntityId = batch.ProductBatchId.ToString(),
            EntityDisplay = batch.BatchCode,
            UserId = userId,
            SafeDetails = new Dictionary<string, object?>
            {
                ["batchStatus"] = batch.BatchStatus,
                ["productStatus"] = batch.ProductStatus,
                ["expiryRisk"] = risk
            }
        }, cancellationToken);
        return new ProductBatchQrResultDto
        {
            ProductBatchId = batch.ProductBatchId,
            ProductId = batch.ProductId,
            ProductCode = batch.ProductCode,
            ProductName = batch.ProductName,
            CategoryName = batch.CategoryName,
            ProductTypeName = batch.TypeName,
            BatchCode = batch.BatchCode,
            QrSummary = batch.QRCodeValue.Length <= 12
                ? batch.QRCodeValue
                : $"…{batch.QRCodeValue[^12..]}",
            PackedAtUtc = batch.PackedAtUtc,
            EffectiveExpiryAtUtc = batch.EffectiveExpiryAtUtc,
            ExpiryRisk = risk,
            BatchStatus = batch.BatchStatus,
            ProductStatus = batch.ProductStatus,
            AvailableQuantityKg = batch.QuantityRemainingKg,
            WarehouseSectionId = batch.SectionId,
            WarehouseSectionName = batch.SectionName
        };
    }
}
