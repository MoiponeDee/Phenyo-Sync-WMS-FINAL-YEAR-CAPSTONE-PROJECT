using System.Data;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Delivery;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Configuration;

namespace PhenyoSyncAPI.Services;

/// <summary>
/// Owns delivery scheduling, conflict-safe assignment, execution and proof of delivery.
/// Delivery and sales-order state changes are kept consistent inside database transactions.
/// </summary>
public sealed class DeliveryService : IDeliveryService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IOrderWorkflowService _orderWorkflow;
    private readonly IAuditService _audit;
    private readonly ISystemSettingProvider? _settings;
    private readonly IOperationalNotificationService? _notifications;
    private readonly ILogger<DeliveryService>? _logger;

    public DeliveryService(
        PhenyoSyncDbContext context,
        IOrderWorkflowService orderWorkflow,
        IAuditService audit,
        ISystemSettingProvider? settings = null,
        IOperationalNotificationService? notifications = null,
        ILogger<DeliveryService>? logger = null)
    {
        _context = context;
        _orderWorkflow = orderWorkflow;
        _audit = audit;
        _settings = settings;
        _notifications = notifications;
        _logger = logger;
    }

    public async Task<DeliveryPagedResultDto> SearchAsync(
        DeliverySearchQueryDto query,
        CancellationToken cancellationToken)
    {
        ValidateSearch(query);
        var deliveries = _context.Deliveries.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(query.SearchTerm))
        {
            var term = query.SearchTerm.Trim();
            deliveries = deliveries.Where(item =>
                item.SalesOrder.OrderNumber.Contains(term) ||
                item.SalesOrder.Customer.CustomerName.Contains(term) ||
                item.DeliveryAddressSnapshot.Contains(term) ||
                (item.Driver != null &&
                 (item.Driver.User.FirstName + " " + item.Driver.User.LastName).Contains(term)));
        }
        if (query.DriverId.HasValue)
            deliveries = deliveries.Where(item => item.DriverId == query.DriverId);
        if (!string.IsNullOrWhiteSpace(query.Status))
            deliveries = deliveries.Where(item => item.Status == query.Status);
        if (query.ScheduledFromUtc.HasValue)
            deliveries = deliveries.Where(item => item.ScheduledEndUtc >= query.ScheduledFromUtc.Value);
        if (query.ScheduledToUtc.HasValue)
            deliveries = deliveries.Where(item => item.ScheduledStartUtc <= query.ScheduledToUtc.Value);
        if (query.Assigned.HasValue)
            deliveries = query.Assigned.Value
                ? deliveries.Where(item => item.DriverId != null)
                : deliveries.Where(item => item.DriverId == null);
        if (query.Completed.HasValue)
            deliveries = query.Completed.Value
                ? deliveries.Where(item => item.Status == DeliveryStatuses.Completed)
                : deliveries.Where(item => item.Status != DeliveryStatuses.Completed);

        var total = await deliveries.CountAsync(cancellationToken);
        var items = await deliveries
            .OrderBy(item => item.ScheduledStartUtc)
            .ThenBy(item => item.DeliveryId)
            .Skip((query.Page - 1) * query.PageSize)
            .Take(query.PageSize)
            .Select(item => new DeliveryListItemDto
            {
                DeliveryId = item.DeliveryId,
                SalesOrderId = item.SalesOrderId,
                OrderNumber = item.SalesOrder.OrderNumber,
                CustomerName = item.SalesOrder.Customer.CustomerName,
                DeliveryAddress = item.DeliveryAddressSnapshot,
                ScheduledStartUtc = item.ScheduledStartUtc,
                ScheduledEndUtc = item.ScheduledEndUtc,
                Status = item.Status,
                DriverId = item.DriverId,
                DriverName = item.Driver == null
                    ? null
                    : item.Driver.User.FirstName + " " + item.Driver.User.LastName,
                CompletedAtUtc = item.CompletedAtUtc,
                CanAssign = item.Status == DeliveryStatuses.Scheduled ||
                            item.Status == DeliveryStatuses.Assigned,
                CanStart = item.Status == DeliveryStatuses.Assigned,
                CanComplete = item.Status == DeliveryStatuses.InTransit,
                RowVersion = item.RowVersion == null ? string.Empty : Convert.ToBase64String(item.RowVersion)
            })
            .ToListAsync(cancellationToken);

        return new DeliveryPagedResultDto
        {
            Items = items,
            Page = query.Page,
            PageSize = query.PageSize,
            TotalCount = total,
            TotalPages = total == 0 ? 0 : (int)Math.Ceiling(total / (double)query.PageSize)
        };
    }

    public async Task<DeliveryDetailDto> GetAsync(
        int deliveryId,
        int userId,
        string role,
        CancellationToken cancellationToken)
    {
        var delivery = await LoadDetailAsync(deliveryId, cancellationToken);
        EnsureDriverCanAccess(delivery, userId, role);
        return MapDetail(delivery);
    }

    public async Task<DeliveryDetailDto> ScheduleAsync(
        ScheduleDeliveryDto request,
        int userId,
        CancellationToken cancellationToken)
    {
        // The server supplies the configured default window so clients cannot diverge by platform.
        var endValue = request.ScheduledEndUtc;
        if (!endValue.HasValue)
        {
            var durationMinutes = _settings is null
                ? 120
                : await _settings.GetIntAsync(
                    SystemSettingKeys.DeliveryDefaultDurationMinutes,
                    cancellationToken);
            endValue = request.ScheduledStartUtc.AddMinutes(
                Math.Clamp(durationMinutes, 15, 1440));
        }
        var (start, end) = ValidWindow(
            request.ScheduledStartUtc,
            endValue.Value);
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);

        var order = await _context.SalesOrders
            .Include(item => item.Customer)
            .FirstOrDefaultAsync(item => item.SalesOrderId == request.SalesOrderId, cancellationToken)
            ?? throw new DeliveryManagementException(404, "Sales order not found.");

        if (order.Status != SalesOrderStatuses.ReadyForDispatch)
            throw new DeliveryManagementException(
                409,
                "Only orders confirmed Ready for Dispatch can be scheduled for delivery.");
        if (await _context.Deliveries.AnyAsync(
                item => item.SalesOrderId == order.SalesOrderId,
                cancellationToken))
            throw new DeliveryManagementException(
                409,
                "A delivery already exists for this sales order.");

        var delivery = new Delivery
        {
            SalesOrderId = order.SalesOrderId,
            DeliveryAddressSnapshot = order.DeliveryAddressSnapshot,
            ScheduledStartUtc = start,
            ScheduledEndUtc = end,
            Status = DeliveryStatuses.Scheduled,
            CreatedAtUtc = DateTime.UtcNow
        };
        delivery.StatusHistory.Add(History(
            null,
            DeliveryStatuses.Scheduled,
            userId,
            "Delivery scheduled.",
            "ScheduleDelivery"));
        _context.Deliveries.Add(delivery);
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.Create,
            "ScheduleDelivery",
            delivery,
            $"Delivery scheduled for order {order.OrderNumber}.",
            new Dictionary<string, object?>
            {
                ["SalesOrderId"] = order.SalesOrderId,
                ["ScheduledStartUtc"] = start,
                ["ScheduledEndUtc"] = end
            },
            cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return await GetManagementDetailAsync(delivery.DeliveryId, cancellationToken);
    }

    public async Task<IReadOnlyList<AvailableDriverDto>> AvailableDriversAsync(
        int deliveryId,
        CancellationToken cancellationToken)
    {
        var delivery = await _context.Deliveries
            .AsNoTracking()
            .Include(item => item.SalesOrder)
            .FirstOrDefaultAsync(item => item.DeliveryId == deliveryId, cancellationToken)
            ?? throw new DeliveryManagementException(404, "Delivery not found.");
        EnsureAssignable(delivery);
        var (start, end) = ValidWindow(delivery.ScheduledStartUtc, delivery.ScheduledEndUtc);

        return await _context.Drivers
            .AsNoTracking()
            .Where(driver =>
                driver.User.Status == "Active" &&
                driver.User.Role != null &&
                driver.User.Role.RoleName == "Driver" &&
                driver.AvailabilityStatus == "Available" &&
                (!driver.LicenseExpiryDate.HasValue ||
                 driver.LicenseExpiryDate.Value >= end) &&
                !_context.Deliveries.Any(other =>
                    other.DeliveryId != deliveryId &&
                    other.DriverId == driver.DriverId &&
                    (other.Status == DeliveryStatuses.Assigned ||
                     other.Status == DeliveryStatuses.InTransit) &&
                    other.ScheduledStartUtc < end &&
                    other.ScheduledEndUtc > start))
            .OrderBy(driver => driver.User.FirstName)
            .ThenBy(driver => driver.User.LastName)
            .Select(driver => new AvailableDriverDto
            {
                DriverId = driver.DriverId,
                DriverName = driver.User.FirstName + " " + driver.User.LastName,
                AvailabilityStatus = driver.AvailabilityStatus,
                LicenseExpiryDate = driver.LicenseExpiryDate,
                LicenseValidForWindow = !driver.LicenseExpiryDate.HasValue ||
                    driver.LicenseExpiryDate.Value >= end,
                VehicleAssigned = driver.VehicleAssigned
            })
            .ToListAsync(cancellationToken);
    }

    public async Task<DeliveryDetailDto> AssignDriverAsync(
        int deliveryId,
        AssignDriverDto request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Serializable isolation closes the gap between availability checking and assignment.
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        try
        {
            var delivery = await _context.Deliveries
                .Include(item => item.SalesOrder)
                .Include(item => item.DriverAssignments.Where(assignment => assignment.IsCurrent))
                .FirstOrDefaultAsync(item => item.DeliveryId == deliveryId, cancellationToken)
                ?? throw new DeliveryManagementException(404, "Delivery not found.");
            EnsureAssignable(delivery);
            CheckRowVersion(delivery, request.RowVersion);
            var (start, end) = ValidWindow(delivery.ScheduledStartUtc, delivery.ScheduledEndUtc);

            var driver = await _context.Drivers
                .Include(item => item.User).ThenInclude(user => user.Role)
                .FirstOrDefaultAsync(item => item.DriverId == request.DriverId, cancellationToken)
                ?? throw new DeliveryManagementException(404, "Driver not found.");
            ValidateDriver(driver, end);

            if (delivery.DriverId == request.DriverId &&
                delivery.DriverAssignments.SingleOrDefault(item => item.IsCurrent) is not null)
            {
                await transaction.CommitAsync(cancellationToken);
                return await GetManagementDetailAsync(deliveryId, cancellationToken);
            }

            if (delivery.DriverId.HasValue &&
                string.IsNullOrWhiteSpace(request.ReassignmentReason))
                throw new DeliveryManagementException(
                    400,
                    "A meaningful reassignment reason is required when replacing a driver.");

            var overlaps = await _context.Deliveries.AnyAsync(other =>
                other.DeliveryId != deliveryId &&
                other.DriverId == driver.DriverId &&
                (other.Status == DeliveryStatuses.Assigned ||
                 other.Status == DeliveryStatuses.InTransit) &&
                other.ScheduledStartUtc < end &&
                other.ScheduledEndUtc > start,
                cancellationToken);
            if (overlaps)
                throw new DeliveryManagementException(
                    409,
                    "The selected driver is no longer available for the complete scheduled window.");

            var now = DateTime.UtcNow;
            var current = delivery.DriverAssignments.SingleOrDefault(item => item.IsCurrent);
            if (current is not null)
            {
                current.IsCurrent = false;
                current.UnassignedAtUtc = now;
                current.UnassignedByUserId = userId;
                current.ReassignmentReason = request.ReassignmentReason!.Trim();
            }

            var previousStatus = delivery.Status;
            delivery.DriverId = driver.DriverId;
            delivery.AssignedAtUtc = now;
            delivery.AssignedByUserId = userId;
            delivery.Status = DeliveryStatuses.Assigned;
            delivery.UpdatedAtUtc = now;
            delivery.DriverAssignments.Add(new DeliveryDriverAssignment
            {
                DriverId = driver.DriverId,
                AssignedAtUtc = now,
                AssignedByUserId = userId,
                AssignmentNotes = Clean(request.AssignmentNotes),
                ReassignmentReason = Clean(request.ReassignmentReason),
                IsCurrent = true,
                CreatedAtUtc = now
            });
            if (previousStatus != DeliveryStatuses.Assigned)
                delivery.StatusHistory.Add(History(
                    previousStatus,
                    DeliveryStatuses.Assigned,
                    userId,
                    current is null ? "Driver assigned." : request.ReassignmentReason,
                    current is null ? "AssignDriver" : "ReassignDriver"));

            await _context.SaveChangesAsync(cancellationToken);
            await AuditAsync(
                AuditActionTypes.StatusChange,
                current is null ? "AssignDriver" : "ReassignDriver",
                delivery,
                current is null
                    ? "A driver was assigned to a scheduled delivery."
                    : "A scheduled delivery was reassigned to another driver.",
                new Dictionary<string, object?>
                {
                    ["DriverId"] = driver.DriverId,
                    ["Reassignment"] = current is not null,
                    ["ScheduledStartUtc"] = start,
                    ["ScheduledEndUtc"] = end
                },
                cancellationToken);
            await transaction.CommitAsync(cancellationToken);
            return await GetManagementDetailAsync(deliveryId, cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new DeliveryManagementException(
                409,
                "The delivery changed while it was being assigned. Refresh and try again.");
        }
        catch (DbUpdateException exception) when (IsAssignmentConstraint(exception))
        {
            throw new DeliveryManagementException(
                409,
                "The delivery or driver assignment changed concurrently. Refresh and try again.");
        }
    }

    public async Task<DeliveryDetailDto> UnassignDriverAsync(
        int deliveryId,
        UnassignDriverDto request,
        int userId,
        CancellationToken cancellationToken)
    {
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var delivery = await _context.Deliveries
            .Include(item => item.DriverAssignments.Where(assignment => assignment.IsCurrent))
            .FirstOrDefaultAsync(item => item.DeliveryId == deliveryId, cancellationToken)
            ?? throw new DeliveryManagementException(404, "Delivery not found.");
        if (delivery.Status != DeliveryStatuses.Assigned || !delivery.DriverId.HasValue)
            throw new DeliveryManagementException(409, "Only an assigned delivery can be unassigned.");
        CheckRowVersion(delivery, request.RowVersion);
        var current = delivery.DriverAssignments.SingleOrDefault(item => item.IsCurrent)
            ?? throw new DeliveryManagementException(409, "The current assignment record is missing.");
        var now = DateTime.UtcNow;
        current.IsCurrent = false;
        current.UnassignedAtUtc = now;
        current.UnassignedByUserId = userId;
        current.ReassignmentReason = request.Reason.Trim();
        delivery.DriverId = null;
        delivery.AssignedAtUtc = null;
        delivery.AssignedByUserId = null;
        delivery.Status = DeliveryStatuses.Scheduled;
        delivery.UpdatedAtUtc = now;
        delivery.StatusHistory.Add(History(
            DeliveryStatuses.Assigned,
            DeliveryStatuses.Scheduled,
            userId,
            request.Reason,
            "UnassignDriver"));
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.StatusChange,
            "UnassignDriver",
            delivery,
            "The current driver assignment was closed.",
            new Dictionary<string, object?> { ["Reason"] = request.Reason.Trim() },
            cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return await GetManagementDetailAsync(deliveryId, cancellationToken);
    }

    public async Task<IReadOnlyList<DeliveryListItemDto>> MyDeliveriesAsync(
        int userId,
        string? status,
        DateTime? fromUtc,
        DateTime? toUtc,
        CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(status) && !DeliveryStatuses.All.Contains(status))
            throw new DeliveryManagementException(400, "The delivery status filter is invalid.");
        if (fromUtc.HasValue && toUtc.HasValue && fromUtc > toUtc)
            throw new DeliveryManagementException(400, "The from date must be before the to date.");

        var driver = await _context.Drivers.AsNoTracking()
            .SingleOrDefaultAsync(item => item.UserId == userId, cancellationToken)
            ?? throw new DeliveryManagementException(
                403,
                "The authenticated user is not linked to a Driver profile.");
        var query = _context.Deliveries.AsNoTracking()
            .Where(item => item.DriverId == driver.DriverId);
        if (!string.IsNullOrWhiteSpace(status))
            query = query.Where(item => item.Status == status);
        if (fromUtc.HasValue)
            query = query.Where(item => item.ScheduledEndUtc >= fromUtc.Value);
        if (toUtc.HasValue)
            query = query.Where(item => item.ScheduledStartUtc <= toUtc.Value);

        return await query
            .OrderBy(item => item.Status == DeliveryStatuses.Completed)
            .ThenBy(item => item.ScheduledStartUtc)
            .Select(item => new DeliveryListItemDto
            {
                DeliveryId = item.DeliveryId,
                SalesOrderId = item.SalesOrderId,
                OrderNumber = item.SalesOrder.OrderNumber,
                CustomerName = item.SalesOrder.Customer.CustomerName,
                DeliveryAddress = item.DeliveryAddressSnapshot,
                ScheduledStartUtc = item.ScheduledStartUtc,
                ScheduledEndUtc = item.ScheduledEndUtc,
                Status = item.Status,
                DriverId = item.DriverId,
                DriverName = item.Driver!.User.FirstName + " " + item.Driver.User.LastName,
                CompletedAtUtc = item.CompletedAtUtc,
                CanAssign = false,
                CanStart = item.Status == DeliveryStatuses.Assigned,
                CanComplete = item.Status == DeliveryStatuses.InTransit,
                RowVersion = item.RowVersion == null ? string.Empty : Convert.ToBase64String(item.RowVersion)
            })
            .ToListAsync(cancellationToken);
    }

    public async Task<DeliveryDetailDto> StartAsync(
        int deliveryId,
        int userId,
        string role,
        CancellationToken cancellationToken)
    {
        // A driver can start only their current assignment after warehouse dispatch.
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var delivery = await _context.Deliveries
            .Include(item => item.Driver).ThenInclude(driver => driver!.User)
            .Include(item => item.SalesOrder).ThenInclude(order => order.StatusHistory)
            .Include(item => item.StatusHistory)
            .FirstOrDefaultAsync(item => item.DeliveryId == deliveryId, cancellationToken)
            ?? throw new DeliveryManagementException(404, "Delivery not found.");
        EnsureOwnOrManagement(delivery, userId, role, false, null);
        if (delivery.Status != DeliveryStatuses.Assigned)
            throw new DeliveryManagementException(409, "Only an assigned delivery can be started.");
        if (delivery.SalesOrder.Status != SalesOrderStatuses.OutForDelivery)
            throw new DeliveryManagementException(
                409,
                "The order has not been dispatched by the warehouse.");

        var now = DateTime.UtcNow;
        delivery.Status = DeliveryStatuses.InTransit;
        delivery.StartedAtUtc = now;
        delivery.StartedByUserId = userId;
        delivery.UpdatedAtUtc = now;
        delivery.StatusHistory.Add(History(
            DeliveryStatuses.Assigned,
            DeliveryStatuses.InTransit,
            userId,
            "Delivery started.",
            "StartDelivery"));
        await _context.SaveChangesAsync(cancellationToken);
        await AuditAsync(
            AuditActionTypes.StatusChange,
            "StartDelivery",
            delivery,
            "The assigned delivery was started.",
            null,
            cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        return await GetManagementDetailAsync(deliveryId, cancellationToken);
    }

    public async Task<DeliveryProofDto> CompleteAsync(
        int deliveryId,
        CompleteDeliveryDto request,
        int userId,
        string role,
        CancellationToken cancellationToken)
    {
        // Proof rules, delivery completion and the Delivered order transition form one unit of work.
        ValidateCompletion(request);
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        try
        {
            var delivery = await _context.Deliveries
                .Include(item => item.Driver).ThenInclude(driver => driver!.User)
                .Include(item => item.SalesOrder).ThenInclude(order => order.StatusHistory)
                .Include(item => item.StatusHistory)
                .Include(item => item.CompletionRecord)
                .Include(item => item.ProofImages)
                .FirstOrDefaultAsync(item => item.DeliveryId == deliveryId, cancellationToken)
                ?? throw new DeliveryManagementException(404, "Delivery not found.");
            CheckRowVersion(delivery, request.RowVersion);
            if (!delivery.DriverId.HasValue)
                throw new DeliveryManagementException(409, "An unassigned delivery cannot be completed.");

            var ownDriver = delivery.Driver?.UserId == userId;
            EnsureOwnOrManagement(
                delivery,
                userId,
                role,
                true,
                request.ManagementOverrideReason);
            if (delivery.CompletionRecord is not null ||
                delivery.Status == DeliveryStatuses.Completed)
            {
                await transaction.CommitAsync(cancellationToken);
                return await GetProofInternalAsync(deliveryId, cancellationToken);
            }
            if (delivery.Status != DeliveryStatuses.InTransit)
                throw new DeliveryManagementException(
                    409,
                    "The delivery must be In Transit before it can be completed.");
            if (delivery.SalesOrder.Status != SalesOrderStatuses.OutForDelivery)
                throw new DeliveryManagementException(
                    409,
                    "The associated order is not Out For Delivery.");

            var requireProof = _settings is not null &&
                await _settings.GetBooleanAsync(
                    SystemSettingKeys.DeliveryRequireProofImageForCompletion,
                    cancellationToken);
            var hasProof = delivery.ProofImages.Any(item =>
                item.RemovedAtUtc == null);
            if (requireProof && !hasProof && ownDriver)
                throw new DeliveryManagementException(
                    409,
                    "Upload at least one valid proof image before completing this delivery.");
            if (requireProof &&
                !hasProof &&
                !ownDriver &&
                string.IsNullOrWhiteSpace(request.ManagementOverrideReason))
                throw new DeliveryManagementException(
                    400,
                    "Overriding the required proof image requires a meaningful management reason.");
            if (hasProof &&
                !delivery.ProofImages.Any(item =>
                    item.RemovedAtUtc == null &&
                    item.IsPrimary))
            {
                delivery.ProofImages
                    .Where(item => item.RemovedAtUtc == null)
                    .OrderBy(item => item.UploadedAtUtc)
                    .First()
                    .IsPrimary = true;
            }

            var now = DateTime.UtcNow;
            await _orderWorkflow.ApplyLogisticsTransitionAsync(
                delivery.SalesOrder,
                SalesOrderStatuses.Delivered,
                userId,
                "Delivery completed with proof of delivery.",
                cancellationToken);
            var completion = new DeliveryCompletionRecord
            {
                DeliveryId = delivery.DeliveryId,
                CompletedAtUtc = now,
                CompletedByUserId = userId,
                CompletedByDriverId = ownDriver ? delivery.DriverId : null,
                CompletedOnBehalfOfDriver = !ownDriver,
                ManagementOverrideReason = ownDriver
                    ? null
                    : request.ManagementOverrideReason!.Trim(),
                RecipientName = request.RecipientName.Trim(),
                RecipientConfirmed = request.RecipientConfirmed,
                FulfillmentConfirmed = request.FulfillmentConfirmed,
                Notes = Clean(request.Notes),
                ProofReference = Clean(request.ProofReference),
                CreatedAtUtc = now
            };
            delivery.CompletionRecord = completion;
            delivery.Status = DeliveryStatuses.Completed;
            delivery.CompletedAtUtc = now;
            delivery.CompletedByUserId = userId;
            delivery.UpdatedAtUtc = now;
            delivery.StatusHistory.Add(History(
                DeliveryStatuses.InTransit,
                DeliveryStatuses.Completed,
                userId,
                ownDriver
                    ? "Delivery fulfilled and recipient confirmed."
                    : request.ManagementOverrideReason,
                ownDriver ? "CompleteOwnDelivery" : "CompleteDeliveryOverride"));

            // Closing active tracking here prevents location collection after fulfilment ends.
            var trackingSessions = await _context.DriverTrackingSessions
                .Where(item =>
                    item.DeliveryId == deliveryId &&
                    item.Status == TrackingSessionStatuses.Active)
                .ToListAsync(cancellationToken);
            foreach (var session in trackingSessions)
            {
                session.Status = TrackingSessionStatuses.Completed;
                session.EndedAtUtc = now;
                session.EndedReason = "Delivery completed.";
            }

            await _context.SaveChangesAsync(cancellationToken);
            await AuditAsync(
                AuditActionTypes.StatusChange,
                ownDriver ? "CompleteOwnDelivery" : "CompleteDeliveryOverride",
                delivery,
                ownDriver
                    ? "The assigned driver completed a delivery with proof."
                    : "Authorized management completed a delivery on behalf of the driver.",
                new Dictionary<string, object?>
                {
                    ["CompletedAtUtc"] = now,
                    ["CompletedOnBehalfOfDriver"] = !ownDriver,
                    ["RecipientConfirmed"] = request.RecipientConfirmed,
                    ["FulfillmentConfirmed"] = request.FulfillmentConfirmed,
                    ["SalesOrderStatus"] = SalesOrderStatuses.Delivered,
                    ["ProofImageCount"] = delivery.ProofImages.Count(item =>
                        item.RemovedAtUtc == null),
                    ["MissingProofOverridden"] = requireProof && !hasProof
                },
                cancellationToken);
            await transaction.CommitAsync(cancellationToken);
            await PublishCompletionNotificationAsync(
                delivery,
                request.RecipientName,
                userId,
                cancellationToken);
            return await GetProofInternalAsync(deliveryId, cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw new DeliveryManagementException(
                409,
                "The delivery changed while it was being completed. Refresh and try again.");
        }
        catch (DbUpdateException exception) when (IsCompletionConstraint(exception))
        {
            throw new DeliveryManagementException(409, "This delivery has already been completed.");
        }
    }

    private async Task PublishCompletionNotificationAsync(
        Delivery delivery,
        string recipientName,
        int actorUserId,
        CancellationToken cancellationToken)
    {
        if (_notifications is null) return;

        try
        {
            await _notifications.PublishToRolesAsync(
                "DeliveryCompleted",
                "Success",
                $"Delivery for {delivery.SalesOrder.OrderNumber} completed",
                $"{delivery.SalesOrder.OrderNumber} was delivered and accepted by {recipientName.Trim()}. Proof of delivery is available.",
                [RoleCodes.BusinessManager, RoleCodes.OperationsManager],
                nameof(Delivery),
                delivery.DeliveryId.ToString(),
                "/deliveries",
                actorUserId,
                $"delivery-completed-{delivery.DeliveryId}",
                cancellationToken);
        }
        catch (Exception exception)
        {
            _logger?.LogWarning(
                exception,
                "Delivery {DeliveryId} completed, but its operational notification could not be queued.",
                delivery.DeliveryId);
        }
    }

    public async Task<DeliveryProofDto> GetProofAsync(
        int deliveryId,
        int userId,
        string role,
        CancellationToken cancellationToken)
    {
        var delivery = await _context.Deliveries
            .AsNoTracking()
            .Include(item => item.Driver)
            .FirstOrDefaultAsync(item => item.DeliveryId == deliveryId, cancellationToken)
            ?? throw new DeliveryManagementException(404, "Delivery not found.");
        EnsureDriverCanAccess(delivery, userId, role);
        return await GetProofInternalAsync(deliveryId, cancellationToken);
    }

    private async Task<DeliveryProofDto> GetProofInternalAsync(
        int deliveryId,
        CancellationToken cancellationToken) =>
        await _context.DeliveryCompletionRecords
            .AsNoTracking()
            .Where(item => item.DeliveryId == deliveryId)
            .Select(item => new DeliveryProofDto
            {
                DeliveryCompletionRecordId = item.DeliveryCompletionRecordId,
                DeliveryId = item.DeliveryId,
                OrderNumber = item.Delivery.SalesOrder.OrderNumber,
                CompletedAtUtc = item.CompletedAtUtc,
                CompletedBy = item.CompletedByUser == null
                    ? "System"
                    : item.CompletedByUser.FirstName + " " + item.CompletedByUser.LastName,
                AssignedDriver = item.Delivery.Driver == null
                    ? null
                    : item.Delivery.Driver.User.FirstName + " " +
                      item.Delivery.Driver.User.LastName,
                CompletedOnBehalfOfDriver = item.CompletedOnBehalfOfDriver,
                ManagementOverrideReason = item.ManagementOverrideReason,
                RecipientName = item.RecipientName,
                RecipientConfirmed = item.RecipientConfirmed,
                FulfillmentConfirmed = item.FulfillmentConfirmed,
                Notes = item.Notes,
                ProofReference = item.ProofReference
            })
            .SingleOrDefaultAsync(cancellationToken)
        ?? throw new DeliveryManagementException(
            404,
            "Proof of delivery is not available because the delivery is not completed.");

    private async Task<Delivery> LoadDetailAsync(
        int deliveryId,
        CancellationToken cancellationToken) =>
        await _context.Deliveries.AsNoTracking()
            .Include(item => item.SalesOrder).ThenInclude(order => order.Customer)
            .Include(item => item.Driver).ThenInclude(driver => driver!.User)
            .Include(item => item.DriverAssignments).ThenInclude(assignment => assignment.Driver).ThenInclude(driver => driver.User)
            .Include(item => item.DriverAssignments).ThenInclude(assignment => assignment.AssignedByUser)
            .Include(item => item.DriverAssignments).ThenInclude(assignment => assignment.UnassignedByUser)
            .Include(item => item.StatusHistory).ThenInclude(history => history.ChangedByUser)
            .FirstOrDefaultAsync(item => item.DeliveryId == deliveryId, cancellationToken)
        ?? throw new DeliveryManagementException(404, "Delivery not found.");

    private async Task<DeliveryDetailDto> GetManagementDetailAsync(
        int deliveryId,
        CancellationToken cancellationToken) =>
        MapDetail(await LoadDetailAsync(deliveryId, cancellationToken));

    private static DeliveryDetailDto MapDetail(Delivery delivery) => new()
    {
        DeliveryId = delivery.DeliveryId,
        SalesOrderId = delivery.SalesOrderId,
        OrderNumber = delivery.SalesOrder.OrderNumber,
        CustomerName = delivery.SalesOrder.Customer.CustomerName,
        CustomerNumber = delivery.SalesOrder.Customer.CustomerNumber,
        DeliveryAddress = delivery.DeliveryAddressSnapshot,
        RequestedDeliveryDateUtc = delivery.SalesOrder.RequestedDeliveryDateUtc,
        ScheduledStartUtc = delivery.ScheduledStartUtc,
        ScheduledEndUtc = delivery.ScheduledEndUtc,
        Status = delivery.Status,
        OrderStatus = delivery.SalesOrder.Status,
        DriverId = delivery.DriverId,
        DriverName = delivery.Driver == null
            ? null
            : delivery.Driver.User.FirstName + " " + delivery.Driver.User.LastName,
        AssignedAtUtc = delivery.AssignedAtUtc,
        StartedAtUtc = delivery.StartedAtUtc,
        CompletedAtUtc = delivery.CompletedAtUtc,
        CanAssign = delivery.Status is DeliveryStatuses.Scheduled or DeliveryStatuses.Assigned,
        CanStart = delivery.Status == DeliveryStatuses.Assigned,
        CanComplete = delivery.Status == DeliveryStatuses.InTransit,
        RowVersion = delivery.RowVersion == null ? string.Empty : Convert.ToBase64String(delivery.RowVersion),
        AssignmentHistory = delivery.DriverAssignments
            .OrderByDescending(item => item.AssignedAtUtc)
            .Select(item => new DeliveryAssignmentHistoryDto
            {
                DeliveryDriverAssignmentId = item.DeliveryDriverAssignmentId,
                DriverId = item.DriverId,
                DriverName = item.Driver.User.FirstName + " " + item.Driver.User.LastName,
                AssignedAtUtc = item.AssignedAtUtc,
                AssignedBy = Display(item.AssignedByUser),
                UnassignedAtUtc = item.UnassignedAtUtc,
                UnassignedBy = Display(item.UnassignedByUser),
                AssignmentNotes = item.AssignmentNotes,
                ReassignmentReason = item.ReassignmentReason,
                IsCurrent = item.IsCurrent
            })
            .ToList(),
        StatusHistory = delivery.StatusHistory
            .OrderByDescending(item => item.ChangedAtUtc)
            .Select(item => new DeliveryStatusHistoryDto
            {
                PreviousStatus = item.PreviousStatus,
                NewStatus = item.NewStatus,
                ChangedAtUtc = item.ChangedAtUtc,
                ChangedBy = Display(item.ChangedByUser),
                Reason = item.Reason,
                Source = item.Source
            })
            .ToList()
    };

    private static void ValidateSearch(DeliverySearchQueryDto query)
    {
        if (!string.IsNullOrWhiteSpace(query.Status) &&
            !DeliveryStatuses.All.Contains(query.Status))
            throw new DeliveryManagementException(400, "The delivery status filter is invalid.");
        if (query.ScheduledFromUtc.HasValue &&
            query.ScheduledToUtc.HasValue &&
            query.ScheduledFromUtc > query.ScheduledToUtc)
            throw new DeliveryManagementException(400, "The scheduled from date must be before the to date.");
    }

    private static (DateTime Start, DateTime End) ValidWindow(DateTime start, DateTime end)
    {
        start = Utc(start);
        end = Utc(end);
        if (start == default || end == default)
            throw new DeliveryManagementException(400, "Both scheduled start and end times are required.");
        if (end <= start)
            throw new DeliveryManagementException(400, "Scheduled end time must be later than the start time.");
        return (start, end);
    }

    private static void EnsureAssignable(Delivery delivery)
    {
        if (delivery.Status is DeliveryStatuses.Completed or DeliveryStatuses.Cancelled or DeliveryStatuses.InTransit)
            throw new DeliveryManagementException(
                409,
                $"A {delivery.Status} delivery cannot be assigned.");
        if (delivery.SalesOrder.Status != SalesOrderStatuses.ReadyForDispatch)
            throw new DeliveryManagementException(
                409,
                "Only a delivery whose order is Ready for Dispatch can be assigned.");
    }

    private static void ValidateDriver(Driver driver, DateTime scheduledEndUtc)
    {
        if (driver.User.Status != "Active" ||
            driver.User.Role?.RoleName != "Driver" ||
            driver.AvailabilityStatus != "Available")
            throw new DeliveryManagementException(409, "The selected driver is not active and available.");
        if (driver.LicenseExpiryDate.HasValue &&
            driver.LicenseExpiryDate.Value < scheduledEndUtc)
            throw new DeliveryManagementException(
                409,
                "The selected driver's licence is not valid for the complete delivery window.");
    }

    private static void ValidateCompletion(CompleteDeliveryDto request)
    {
        if (string.IsNullOrWhiteSpace(request.RecipientName))
            throw new DeliveryManagementException(400, "Recipient name is required.");
        if (!request.RecipientConfirmed)
            throw new DeliveryManagementException(400, "Recipient confirmation is required.");
        if (!request.FulfillmentConfirmed)
            throw new DeliveryManagementException(
                400,
                "Successful-fulfillment confirmation is required.");
    }

    private static void EnsureOwnOrManagement(
        Delivery delivery,
        int userId,
        string role,
        bool completion,
        string? overrideReason)
    {
        var own = delivery.Driver?.UserId == userId;
        if (own) return;
        var allowed = completion
            ? DeliveryRoles.CompleteAny.Split(',').Contains(role, StringComparer.Ordinal)
            : DeliveryRoles.Managers.Split(',').Contains(role, StringComparer.Ordinal);
        if (!allowed)
            throw new DeliveryManagementException(
                403,
                "Only the assigned driver or specifically authorized management may perform this action.");
        if (completion && string.IsNullOrWhiteSpace(overrideReason))
            throw new DeliveryManagementException(
                400,
                "Management completion on behalf of a driver requires a meaningful override reason.");
    }

    private static void EnsureDriverCanAccess(Delivery delivery, int userId, string role)
    {
        if (role != "Driver") return;
        if (delivery.Driver?.UserId != userId)
            throw new DeliveryManagementException(
                403,
                "Drivers may view only their own assigned deliveries.");
    }

    private static void CheckRowVersion(Delivery delivery, string? encoded)
    {
        if (string.IsNullOrWhiteSpace(encoded)) return;
        byte[] expected;
        try { expected = Convert.FromBase64String(encoded); }
        catch (FormatException)
        {
            throw new DeliveryManagementException(400, "The delivery row version is invalid.");
        }
        if (delivery.RowVersion is null || !expected.SequenceEqual(delivery.RowVersion))
            throw new DeliveryManagementException(
                409,
                "The delivery changed since it was loaded. Refresh and try again.");
    }

    private static DeliveryStatusHistory History(
        string? previous,
        string next,
        int userId,
        string? reason,
        string source) => new()
    {
        PreviousStatus = previous,
        NewStatus = next,
        ChangedByUserId = userId,
        ChangedAtUtc = DateTime.UtcNow,
        Reason = Clean(reason),
        Source = source
    };

    private async Task AuditAsync(
        string action,
        string operation,
        Delivery delivery,
        string description,
        IReadOnlyDictionary<string, object?>? details,
        CancellationToken cancellationToken) =>
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = AuditModules.DeliveryLogistics,
            OperationName = operation,
            Description = description,
            EntityType = nameof(Delivery),
            EntityId = delivery.DeliveryId.ToString(),
            EntityDisplay = $"Delivery {delivery.DeliveryId}",
            SafeDetails = details
        }, cancellationToken);

    private static string? Display(User? user) =>
        user is null ? null : $"{user.FirstName} {user.LastName}".Trim();

    private static string? Clean(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private static DateTime Utc(DateTime value) => value.Kind switch
    {
        DateTimeKind.Utc => value,
        DateTimeKind.Local => value.ToUniversalTime(),
        _ => DateTime.SpecifyKind(value, DateTimeKind.Utc)
    };

    private static bool IsAssignmentConstraint(DbUpdateException exception) =>
        exception.InnerException?.Message.Contains(
            "UX_DeliveryDriverAssignments_Current",
            StringComparison.OrdinalIgnoreCase) == true;

    private static bool IsCompletionConstraint(DbUpdateException exception) =>
        exception.InnerException?.Message.Contains(
            "DeliveryCompletionRecords",
            StringComparison.OrdinalIgnoreCase) == true;
}
