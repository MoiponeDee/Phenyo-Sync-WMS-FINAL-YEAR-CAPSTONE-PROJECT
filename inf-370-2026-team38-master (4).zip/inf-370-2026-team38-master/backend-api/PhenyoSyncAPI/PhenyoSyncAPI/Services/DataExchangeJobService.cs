using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public sealed record StagedDataExchange(
    DataExchangeJob Job,
    string ValidationToken);

public interface IDataExchangeJobService
{
    Task<StagedDataExchange> StageAsync<T>(
        string exchangeType,
        string originalFileName,
        byte[] sourceBytes,
        T payload,
        int totalRows,
        int validRows,
        int warningRows,
        int invalidRows,
        int userId,
        string correlationId,
        CancellationToken cancellationToken);

    Task<DataExchangeJob> GetValidatedAsync(
        string token,
        string exchangeType,
        int userId,
        CancellationToken cancellationToken);

    Task<DataExchangeJob> GetResultAsync(
        string token,
        string exchangeType,
        int userId,
        CancellationToken cancellationToken);
}

/// <summary>Stores short-lived validation jobs and one-time result files for data exchanges.</summary>
public sealed class DataExchangeJobService : IDataExchangeJobService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly ISystemSettingProvider _settings;

    public DataExchangeJobService(
        PhenyoSyncDbContext context,
        ISystemSettingProvider settings)
    {
        _context = context;
        _settings = settings;
    }

    public async Task<StagedDataExchange> StageAsync<T>(
        string exchangeType,
        string originalFileName,
        byte[] sourceBytes,
        T payload,
        int totalRows,
        int validRows,
        int warningRows,
        int invalidRows,
        int userId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        var rawToken = Convert.ToBase64String(
                RandomNumberGenerator.GetBytes(32))
            .Replace("+", "-", StringComparison.Ordinal)
            .Replace("/", "_", StringComparison.Ordinal)
            .TrimEnd('=');
        var lifetime = await _settings.GetIntAsync(
            Configuration.SystemSettingKeys.DataExchangeValidationLifetimeMinutes,
            cancellationToken);
        var now = DateTime.UtcNow;
        var job = new DataExchangeJob
        {
            ValidationTokenHash = Hash(rawToken),
            ExchangeType = exchangeType,
            Status = DataExchangeStatuses.Validated,
            OriginalFileName = SafeName(originalFileName),
            ContentSha256 = Convert.ToHexString(SHA256.HashData(sourceBytes)),
            StagedPayloadJson = JsonSerializer.Serialize(payload),
            TotalRows = totalRows,
            ValidRows = validRows,
            WarningRows = warningRows,
            InvalidRows = invalidRows,
            CreatedByUserId = userId,
            CreatedAtUtc = now,
            ExpiresAtUtc = now.AddMinutes(lifetime),
            CorrelationId = string.IsNullOrWhiteSpace(correlationId)
                ? Guid.NewGuid().ToString("N")
                : correlationId[..Math.Min(64, correlationId.Length)]
        };
        _context.DataExchangeJobs.Add(job);
        await _context.SaveChangesAsync(cancellationToken);
        return new StagedDataExchange(job, rawToken);
    }

    public Task<DataExchangeJob> GetValidatedAsync(
        string token,
        string exchangeType,
        int userId,
        CancellationToken cancellationToken) =>
        GetAsync(token, exchangeType, userId, requireApplied: false, cancellationToken);

    public Task<DataExchangeJob> GetResultAsync(
        string token,
        string exchangeType,
        int userId,
        CancellationToken cancellationToken) =>
        GetAsync(token, exchangeType, userId, requireApplied: true, cancellationToken);

    private async Task<DataExchangeJob> GetAsync(
        string token,
        string exchangeType,
        int userId,
        bool requireApplied,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(token) || token.Length > 200)
            throw new PhaseBException(400, "The validation token is invalid.");
        var hash = Hash(token);
        var job = await _context.DataExchangeJobs.FirstOrDefaultAsync(item =>
                item.ValidationTokenHash == hash &&
                item.ExchangeType == exchangeType &&
                item.CreatedByUserId == userId,
            cancellationToken)
            ?? throw new PhaseBException(404, "The validation session was not found.");

        if (job.ExpiresAtUtc <= DateTime.UtcNow &&
            job.Status == DataExchangeStatuses.Validated)
        {
            job.Status = DataExchangeStatuses.Expired;
            await _context.SaveChangesAsync(cancellationToken);
        }
        if (job.Status == DataExchangeStatuses.Expired)
            throw new PhaseBException(410, "The validation session expired. Validate the file again.");
        if (requireApplied && job.Status != DataExchangeStatuses.Applied)
            throw new PhaseBException(409, "The import result is not available yet.");
        if (!requireApplied && job.Status != DataExchangeStatuses.Validated)
            throw new PhaseBException(409, "This validation session has already been used.");
        return job;
    }

    private static string Hash(string token) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));

    private static string SafeName(string value)
    {
        var name = Path.GetFileName(value);
        return name.Length <= 255 ? name : name[..255];
    }
}
