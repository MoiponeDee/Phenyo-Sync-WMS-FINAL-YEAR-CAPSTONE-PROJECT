using System.Data;
using System.Globalization;
using System.Text.Json;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public sealed record GeneratedExchangeFile(
    byte[] Content,
    string ContentType,
    string FileName);

public interface IProductExcelExchangeService
{
    Task<GeneratedExchangeFile> TemplateAsync(
        int userId,
        CancellationToken cancellationToken);

    Task<GeneratedExchangeFile> ExportAsync(
        ProductExcelExportQueryDto query,
        int userId,
        CancellationToken cancellationToken);

    Task<DataExchangeValidationResponseDto> ValidateAsync(
        IFormFile file,
        int userId,
        string correlationId,
        CancellationToken cancellationToken);

    Task<DataExchangeApplyResponseDto> ImportAsync(
        string validationToken,
        ApplyDataExchangeRequest request,
        int userId,
        CancellationToken cancellationToken);

    Task<GeneratedExchangeFile> ResultAsync(
        string resultToken,
        int userId,
        CancellationToken cancellationToken);
}

/// <summary>
/// Generates, validates and applies the reviewed Products and Prices workbook.
/// Validation and import are separate so no row is written before the complete
/// workbook has been checked and bound to a short-lived validation job.
/// </summary>
public sealed class ProductExcelExchangeService : IProductExcelExchangeService
{
    public const string ContentType =
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private const string TemplateVersion = "2.1";
    private const string DataSheetName = "Products and Prices";
    private const string InstructionsSheetName = "Instructions";
    private const int HeaderRow = 6;

    private static readonly string[] Headers =
    [
        "ProductId", "ProductCode", "ProductName", "CategoryCode",
        "CategoryName", "ProductTypeCode", "ProductTypeName", "Size",
        "UnitOfMeasure", "SellingUnit", "KilogramsPerUnit", "IsVariableWeight",
        "ShelfLifeDays", "ProductStatus", "PriceBasis",
        "CurrentSellingPrice", "PriceEffectiveFromUtc", "PriceChangeReason"
    ];

    private readonly PhenyoSyncDbContext _context;
    private readonly IDataExchangeJobService _jobs;
    private readonly ISystemSettingProvider _settings;
    private readonly IAuditService _audit;

    public ProductExcelExchangeService(
        PhenyoSyncDbContext context,
        IDataExchangeJobService jobs,
        ISystemSettingProvider settings,
        IAuditService audit)
    {
        _context = context;
        _jobs = jobs;
        _settings = settings;
        _audit = audit;
    }

    public async Task<GeneratedExchangeFile> TemplateAsync(
        int userId,
        CancellationToken cancellationToken)
    {
        var user = await UserDisplayNameAsync(userId, cancellationToken);
        using var workbook = CreateWorkbook(
            user,
            "Blank import template",
            ["Complete the Products and Prices worksheet and validate it before import."]);
        WriteDataHeader(workbook.Worksheet(DataSheetName));
        return ToFile(
            workbook,
            $"PhenyoSync-Product-Price-Template-v{TemplateVersion}.xlsx");
    }

    public async Task<GeneratedExchangeFile> ExportAsync(
        ProductExcelExportQueryDto query,
        int userId,
        CancellationToken cancellationToken)
    {
        // Apply server-side filters before materialising data. Exported prices
        // are selected at one effective instant for a consistent workbook.
        ValidateExportQuery(query);
        var products = _context.Products.AsNoTracking().AsQueryable();
        if (query.ProductCategoryId.HasValue)
            products = products.Where(item => item.ProductCategoryId == query.ProductCategoryId);
        if (query.ProductTypeId.HasValue)
            products = products.Where(item => item.ProductTypeId == query.ProductTypeId);
        if (!query.IncludeInactive)
            products = products.Where(item => item.Status == ProductStatuses.Active);
        if (!string.IsNullOrWhiteSpace(query.ProductStatus))
            products = products.Where(item => item.Status == query.ProductStatus);

        var effectiveAt = query.EffectiveAtUtc?.ToUniversalTime() ?? DateTime.UtcNow;
        var rows = await products
            .Select(product => new
            {
                product.ProductId,
                ProductCode = product.QRCodeValue ?? $"PRODUCT-{product.ProductId:D6}",
                product.ProductName,
                product.ProductCategoryId,
                CategoryName = product.ProductCategory!.ProductCategoryName,
                product.ProductTypeId,
                ProductTypeName = product.ProductType!.ProductTypeName,
                product.Size,
                product.SellingUnit,
                product.KilogramsPerUnit,
                product.IsVariableWeight,
                product.ShelfLifeDays,
                product.Status,
                Price = product.ProductPrices
                    .Where(price =>
                        !price.IsDeleted &&
                        price.EffectiveFromUtc <= effectiveAt &&
                        (price.EffectiveToUtc == null || price.EffectiveToUtc > effectiveAt))
                    .OrderByDescending(price => price.EffectiveFromUtc)
                    .Select(price => new
                    {
                        price.SellingPrice,
                        price.PriceBasis,
                        price.EffectiveFromUtc,
                        price.ChangeReason,
                        price.IsCurrent
                    })
                    .FirstOrDefault()
            })
            .OrderBy(item => item.CategoryName)
            .ThenBy(item => item.ProductTypeName)
            .ThenBy(item => item.ProductName)
            .ToListAsync(cancellationToken);

        if (query.PriceStatus?.Equals("Priced", StringComparison.OrdinalIgnoreCase) == true)
            rows = rows.Where(item => item.Price is not null).ToList();
        if (query.PriceStatus?.Equals("Unpriced", StringComparison.OrdinalIgnoreCase) == true)
            rows = rows.Where(item => item.Price is null).ToList();

        var user = await UserDisplayNameAsync(userId, cancellationToken);
        var filters = new[]
        {
            $"Category: {query.ProductCategoryId?.ToString() ?? "All"}",
            $"Product type: {query.ProductTypeId?.ToString() ?? "All"}",
            $"Product status: {query.ProductStatus ?? (query.IncludeInactive ? "All" : "Active")}",
            $"Price status: {query.PriceStatus ?? "All"}",
            $"Price effective at (UTC): {effectiveAt:O}"
        };
        using var workbook = CreateWorkbook(user, "Product and Price catalogue export", filters);
        var sheet = workbook.Worksheet(DataSheetName);
        WriteDataHeader(sheet);
        var row = HeaderRow + 1;
        foreach (var item in rows)
        {
            sheet.Cell(row, 1).Value = item.ProductId;
            sheet.Cell(row, 2).Value = item.ProductCode;
            sheet.Cell(row, 3).Value = item.ProductName;
            sheet.Cell(row, 4).Value = CategoryCode(item.ProductCategoryId);
            sheet.Cell(row, 5).Value = item.CategoryName;
            sheet.Cell(row, 6).Value = TypeCode(item.ProductTypeId);
            sheet.Cell(row, 7).Value = item.ProductTypeName;
            sheet.Cell(row, 8).Value = item.Size;
            sheet.Cell(row, 9).Value = "KG";
            sheet.Cell(row, 10).Value = item.SellingUnit;
            if (item.KilogramsPerUnit.HasValue)
                sheet.Cell(row, 11).Value = item.KilogramsPerUnit.Value;
            sheet.Cell(row, 12).Value = item.IsVariableWeight;
            sheet.Cell(row, 13).Value = item.ShelfLifeDays;
            sheet.Cell(row, 14).Value = item.Status;
            if (item.Price is not null)
            {
                sheet.Cell(row, 15).Value = item.Price.PriceBasis;
                sheet.Cell(row, 16).Value = item.Price.SellingPrice;
                sheet.Cell(row, 17).Value = item.Price.EffectiveFromUtc;
                sheet.Cell(row, 18).Value = item.Price.ChangeReason ?? string.Empty;
            }
            else
                sheet.Cell(row, 15).Value = ProductPriceBases.PerKilogram;
            row++;
        }
        FormatDataRows(sheet, row - 1);
        await AuditAsync(
            AuditActionTypes.Export,
            "Export Product and Price workbook",
            userId,
            $"Exported {rows.Count} product rows.",
            new Dictionary<string, object?> { ["rowCount"] = rows.Count },
            cancellationToken);
        return ToFile(
            workbook,
            $"PhenyoSync-Product-Price-Catalogue-{DateTime.UtcNow:yyyy-MM-dd}.xlsx");
    }

    public async Task<DataExchangeValidationResponseDto> ValidateAsync(
        IFormFile file,
        int userId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        // The uploaded workbook is parsed into candidate rows and errors only.
        // The validation stage deliberately performs no product/price writes.
        var bytes = await ReadAndValidateFileAsync(file, cancellationToken);
        var maximumRows = await _settings.GetIntAsync(
            SystemSettingKeys.DataExchangeMaximumRows,
            cancellationToken);
        ProductExcelStagedPayload payload;
        try
        {
            using var stream = new MemoryStream(bytes);
            using var workbook = new XLWorkbook(stream);
            payload = await ParseAsync(workbook, maximumRows, cancellationToken);
        }
        catch (PhaseBException)
        {
            throw;
        }
        catch (Exception exception) when (
            exception is not OperationCanceledException)
        {
            throw new PhaseBException(
                400,
                "The workbook could not be read. Use the current PhenyoSync Excel template.");
        }

        var valid = payload.Rows.Count(item => item.ValidationStatus == "Valid");
        var warnings = payload.Rows.Count(item => item.ValidationStatus == "Warning");
        var invalid = payload.Rows.Count(item => item.ValidationStatus == "Invalid");
        var staged = await _jobs.StageAsync(
            DataExchangeTypes.ProductExcel,
            file.FileName,
            bytes,
            payload,
            payload.Rows.Count,
            valid,
            warnings,
            invalid,
            userId,
            correlationId,
            cancellationToken);
        await AuditAsync(
            AuditActionTypes.ValidateImport,
            "Validate Product and Price workbook",
            userId,
            $"Validated {payload.Rows.Count} workbook rows.",
            new Dictionary<string, object?>
            {
                ["validRows"] = valid,
                ["warningRows"] = warnings,
                ["invalidRows"] = invalid,
                ["jobId"] = staged.Job.DataExchangeJobId
            },
            cancellationToken);
        return new DataExchangeValidationResponseDto
        {
            ValidationToken = staged.ValidationToken,
            ExpiresAtUtc = staged.Job.ExpiresAtUtc,
            TotalRows = payload.Rows.Count,
            ValidRows = valid,
            WarningRows = warnings,
            InvalidRows = invalid,
            Rows = payload.Rows.Select(item => new DataExchangePreviewRowDto
            {
                RowNumber = item.RowNumber,
                Status = item.ValidationStatus,
                Action = item.Action,
                RecordKey = string.IsNullOrWhiteSpace(item.ProductCode)
                    ? item.ProductName
                    : item.ProductCode,
                Messages = item.Messages
            }).ToList()
        };
    }

    public async Task<DataExchangeApplyResponseDto> ImportAsync(
        string validationToken,
        ApplyDataExchangeRequest request,
        int userId,
        CancellationToken cancellationToken)
    {
        // Import consumes the server-side validation job rather than trusting
        // rows re-posted by the browser. The transaction makes the apply atomic.
        var job = await _jobs.GetValidatedAsync(
            validationToken,
            DataExchangeTypes.ProductExcel,
            userId,
            cancellationToken);
        if (job.InvalidRows > 0)
            throw new PhaseBException(409, "Resolve all invalid workbook rows before importing.");
        var payload = JsonSerializer.Deserialize<ProductExcelStagedPayload>(
                job.StagedPayloadJson)
            ?? throw new PhaseBException(409, "The staged workbook data is unavailable.");
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var created = 0;
        var updated = 0;
        var resultRows = new List<DataExchangePreviewRowDto>();
        try
        {
            foreach (var row in payload.Rows)
            {
                var categoryId = ParseCode(row.CategoryCode, "CATEGORY");
                var typeId = ParseCode(row.ProductTypeCode, "TYPE");
                if (!await _context.ProductCategoryTypes.AnyAsync(
                        item => item.ProductCategoryId == categoryId &&
                                item.ProductTypeId == typeId,
                        cancellationToken))
                {
                    throw new PhaseBException(
                        409,
                        $"Row {row.RowNumber}: the category/type relationship changed after validation.");
                }

                var now = DateTime.UtcNow;
                var product = row.ProductId.HasValue
                    ? await _context.Products
                        .Include(item => item.ProductPrices.Where(price =>
                            !price.IsDeleted &&
                            price.EffectiveFromUtc <= now &&
                            (price.EffectiveToUtc == null || price.EffectiveToUtc > now)))
                        .FirstOrDefaultAsync(
                            item => item.ProductId == row.ProductId.Value,
                            cancellationToken)
                    : await _context.Products
                        .Include(item => item.ProductPrices.Where(price =>
                            !price.IsDeleted &&
                            price.EffectiveFromUtc <= now &&
                            (price.EffectiveToUtc == null || price.EffectiveToUtc > now)))
                        .FirstOrDefaultAsync(
                            item => item.QRCodeValue == row.ProductCode,
                            cancellationToken);
                if (product is null)
                {
                    product = new Product
                    {
                        ProductName = row.ProductName,
                        ProductCategoryId = categoryId,
                        ProductTypeId = typeId,
                        Size = row.Size,
                        ShelfLifeDays = row.ShelfLifeDays,
                        SellingPricePerKg = row.CurrentSellingPrice,
                        SellingUnit = row.SellingUnit,
                        KilogramsPerUnit = row.IsVariableWeight ? null : row.KilogramsPerUnit,
                        IsVariableWeight = row.IsVariableWeight,
                        Status = row.ProductStatus,
                        CreatedAt = now,
                        QRCodeValue = string.IsNullOrWhiteSpace(row.ProductCode)
                            ? null
                            : row.ProductCode
                    };
                    _context.Products.Add(product);
                    await _context.SaveChangesAsync(cancellationToken);
                    product.QRCodeValue ??= $"PRODUCT-{product.ProductId:D6}";
                    created++;
                }
                else
                {
                    product.ProductName = row.ProductName;
                    product.ProductCategoryId = categoryId;
                    product.ProductTypeId = typeId;
                    product.Size = row.Size;
                    product.ShelfLifeDays = row.ShelfLifeDays;
                    product.SellingUnit = row.SellingUnit;
                    product.KilogramsPerUnit = row.IsVariableWeight ? null : row.KilogramsPerUnit;
                    product.IsVariableWeight = row.IsVariableWeight;
                    product.Status = row.ProductStatus;
                    product.UpdatedAt = now;
                    updated++;
                }

                var currentPrice = product.ProductPrices
                    .OrderByDescending(price => price.EffectiveFromUtc)
                    .FirstOrDefault();
                if (row.CurrentSellingPrice > 0 &&
                    (currentPrice is null ||
                     currentPrice.SellingPrice != row.CurrentSellingPrice ||
                     currentPrice.PriceBasis != row.PriceBasis))
                {
                    if (currentPrice is not null)
                    {
                        currentPrice.IsCurrent = false;
                        currentPrice.EffectiveToUtc = now;
                    }
                    _context.ProductPrices.Add(new ProductPrice
                    {
                        ProductId = product.ProductId,
                        SellingPrice = row.CurrentSellingPrice,
                        PriceBasis = row.PriceBasis,
                        EffectiveFromUtc = now,
                        IsCurrent = true,
                        CreatedAtUtc = now,
                        CreatedByUserId = userId,
                        ChangeReason = row.PriceChangeReason
                    });
                    product.SellingPricePerKg = row.CurrentSellingPrice;
                }
                resultRows.Add(new DataExchangePreviewRowDto
                {
                    RowNumber = row.RowNumber,
                    Status = "Applied",
                    Action = row.Action,
                    RecordKey = product.QRCodeValue ?? $"PRODUCT-{product.ProductId:D6}",
                    Messages = [$"Product ID {product.ProductId} applied successfully."]
                });
            }

            job.Status = DataExchangeStatuses.Applied;
            job.AppliedAtUtc = DateTime.UtcNow;
            job.ApplyReason = request.Reason.Trim();
            job.ResultPayloadJson = JsonSerializer.Serialize(resultRows);
            await _context.SaveChangesAsync(cancellationToken);
            await AuditAsync(
                AuditActionTypes.Import,
                "Import Product and Price workbook",
                userId,
                $"Applied {payload.Rows.Count} validated workbook rows.",
                new Dictionary<string, object?>
                {
                    ["created"] = created,
                    ["updated"] = updated,
                    ["jobId"] = job.DataExchangeJobId,
                    ["reason"] = request.Reason.Trim()
                },
                cancellationToken);
            await transaction.CommitAsync(cancellationToken);
        }
        catch
        {
            await transaction.RollbackAsync(cancellationToken);
            throw;
        }

        return new DataExchangeApplyResponseDto
        {
            Message = "The validated Product and Price workbook was imported transactionally.",
            ResultToken = validationToken,
            CreatedCount = created,
            UpdatedCount = updated,
            CorrelationId = job.CorrelationId
        };
    }

    public async Task<GeneratedExchangeFile> ResultAsync(
        string resultToken,
        int userId,
        CancellationToken cancellationToken)
    {
        var job = await _jobs.GetResultAsync(
            resultToken,
            DataExchangeTypes.ProductExcel,
            userId,
            cancellationToken);
        var rows = JsonSerializer.Deserialize<List<DataExchangePreviewRowDto>>(
                job.ResultPayloadJson ?? "[]") ?? [];
        var user = await UserDisplayNameAsync(userId, cancellationToken);
        using var workbook = CreateWorkbook(
            user,
            "Product and Price import result",
            [$"Correlation ID: {job.CorrelationId}", $"Applied at (UTC): {job.AppliedAtUtc:O}"]);
        var sheet = workbook.Worksheet(DataSheetName);
        var headers = new[] { "RowNumber", "Status", "Action", "RecordKey", "Message" };
        for (var column = 1; column <= headers.Length; column++)
            sheet.Cell(HeaderRow, column).Value = headers[column - 1];
        StyleHeader(sheet.Range(HeaderRow, 1, HeaderRow, headers.Length));
        var row = HeaderRow + 1;
        foreach (var item in rows)
        {
            sheet.Cell(row, 1).Value = item.RowNumber;
            sheet.Cell(row, 2).Value = item.Status;
            sheet.Cell(row, 3).Value = item.Action;
            sheet.Cell(row, 4).Value = item.RecordKey;
            sheet.Cell(row, 5).Value = string.Join("; ", item.Messages);
            row++;
        }
        sheet.Columns().AdjustToContents(8, 50);
        return ToFile(
            workbook,
            $"PhenyoSync-Product-Price-Import-Result-{job.DataExchangeJobId}.xlsx");
    }

    private async Task<ProductExcelStagedPayload> ParseAsync(
        XLWorkbook workbook,
        int maximumRows,
        CancellationToken cancellationToken)
    {
        if (!workbook.TryGetWorksheet(InstructionsSheetName, out var instructions) ||
            !workbook.TryGetWorksheet(DataSheetName, out var sheet))
        {
            throw new PhaseBException(
                400,
                $"The workbook must contain '{InstructionsSheetName}' and '{DataSheetName}' worksheets.");
        }
        var version = instructions.Cell("B2").GetString().Trim();
        if (version != TemplateVersion)
            throw new PhaseBException(400, "The workbook template version is not supported.");
        for (var column = 1; column <= Headers.Length; column++)
        {
            if (!sheet.Cell(HeaderRow, column).GetString()
                    .Trim()
                    .Equals(Headers[column - 1], StringComparison.Ordinal))
            {
                throw new PhaseBException(
                    400,
                    $"Required column '{Headers[column - 1]}' is missing or out of order.");
            }
        }
        var lastRow = sheet.LastRowUsed()?.RowNumber() ?? HeaderRow;
        var count = Math.Max(0, lastRow - HeaderRow);
        if (count == 0)
            throw new PhaseBException(400, "The workbook contains no Product and Price rows.");
        if (count > maximumRows)
            throw new PhaseBException(400, $"The workbook exceeds the {maximumRows}-row limit.");

        var categories = await _context.ProductCategories.AsNoTracking()
            .ToDictionaryAsync(item => CategoryCode(item.ProductCategoryId), cancellationToken);
        var types = await _context.ProductTypes.AsNoTracking()
            .ToDictionaryAsync(item => TypeCode(item.ProductTypeId), cancellationToken);
        var associations = await _context.ProductCategoryTypes.AsNoTracking()
            .Select(item => new AssociationKey(
                item.ProductCategoryId,
                item.ProductTypeId))
            .ToListAsync(cancellationToken);
        var existingProducts = await _context.Products.AsNoTracking()
            .Select(item => new ExistingProductKey(
                item.ProductId,
                item.QRCodeValue ?? $"PRODUCT-{item.ProductId:D6}"))
            .ToListAsync(cancellationToken);
        var codeSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var productIdSet = new HashSet<int>();
        var payload = new ProductExcelStagedPayload();
        for (var rowNumber = HeaderRow + 1; rowNumber <= lastRow; rowNumber++)
        {
            var row = new ProductExcelStagedRow
            {
                RowNumber = rowNumber,
                ProductId = ReadNullableInt(sheet.Cell(rowNumber, 1)),
                ProductCode = Text(sheet.Cell(rowNumber, 2)),
                ProductName = Text(sheet.Cell(rowNumber, 3)),
                CategoryCode = Text(sheet.Cell(rowNumber, 4)).ToUpperInvariant(),
                ProductTypeCode = Text(sheet.Cell(rowNumber, 6)).ToUpperInvariant(),
                Size = Text(sheet.Cell(rowNumber, 8)),
                UnitOfMeasure = Text(sheet.Cell(rowNumber, 9)).ToUpperInvariant(),
                SellingUnit = Text(sheet.Cell(rowNumber, 10)),
                KilogramsPerUnit = ReadNullableDecimal(sheet.Cell(rowNumber, 11)),
                IsVariableWeight = ReadBoolean(sheet.Cell(rowNumber, 12)),
                ShelfLifeDays = ReadInt(sheet.Cell(rowNumber, 13)),
                ProductStatus = Text(sheet.Cell(rowNumber, 14)),
                PriceBasis = Text(sheet.Cell(rowNumber, 15)),
                CurrentSellingPrice = ReadDecimal(sheet.Cell(rowNumber, 16)),
                PriceEffectiveFromUtc = ReadNullableDate(sheet.Cell(rowNumber, 17)),
                PriceChangeReason = Text(sheet.Cell(rowNumber, 18))
            };
            ValidateRow(
                row,
                categories,
                types,
                associations,
                existingProducts,
                codeSet,
                productIdSet);
            payload.Rows.Add(row);
        }
        return payload;
    }

    private static void ValidateRow(
        ProductExcelStagedRow row,
        IReadOnlyDictionary<string, ProductCategory> categories,
        IReadOnlyDictionary<string, ProductType> types,
        IReadOnlyCollection<AssociationKey> associations,
        IReadOnlyCollection<ExistingProductKey> existingProducts,
        ISet<string> codeSet,
        ISet<int> productIdSet)
    {
        if (string.IsNullOrWhiteSpace(row.ProductName))
            row.Messages.Add("ProductName is required.");
        if (string.IsNullOrWhiteSpace(row.Size))
            row.Messages.Add("Size is required.");
        if (!categories.TryGetValue(row.CategoryCode, out var category) ||
            category.Status != ProductStatuses.Active)
            row.Messages.Add("CategoryCode must identify an active category.");
        if (!types.TryGetValue(row.ProductTypeCode, out var type) ||
            type.Status != ProductStatuses.Active)
            row.Messages.Add("ProductTypeCode must identify an active type.");
        if (category is not null && type is not null &&
            !associations.Any(item =>
                item.ProductCategoryId == category.ProductCategoryId &&
                item.ProductTypeId == type.ProductTypeId))
            row.Messages.Add("The selected category and type are not linked.");
        if (row.UnitOfMeasure != "KG")
            row.Messages.Add("UnitOfMeasure must be KG for the current stock model.");
        if (string.IsNullOrWhiteSpace(row.SellingUnit))
            row.Messages.Add("SellingUnit is required.");
        if (row.IsVariableWeight && !row.SellingUnit.Equals("kg", StringComparison.OrdinalIgnoreCase))
            row.Messages.Add("Variable-weight products must use kg as SellingUnit.");
        if (!ProductPriceBases.IsValid(row.PriceBasis))
            row.Messages.Add("PriceBasis must be PerKilogram or PerSellableUnit.");
        if (!row.IsVariableWeight && row.PriceBasis == ProductPriceBases.PerKilogram &&
            (row.KilogramsPerUnit is null or <= 0))
            row.Messages.Add("KilogramsPerUnit must be positive for a packaged product priced per kilogram.");
        if (row.IsVariableWeight && row.PriceBasis != ProductPriceBases.PerKilogram)
            row.Messages.Add("Variable-weight products must use PerKilogram pricing.");
        if (row.ShelfLifeDays is < 1 or > 3650)
            row.Messages.Add("ShelfLifeDays must be between 1 and 3650.");
        if (row.ProductStatus is not ProductStatuses.Active and not ProductStatuses.Inactive)
            row.Messages.Add("ProductStatus must be Active or Inactive.");
        if (row.CurrentSellingPrice < 0 ||
            decimal.Round(row.CurrentSellingPrice, 2) != row.CurrentSellingPrice)
            row.Messages.Add("CurrentSellingPrice must be non-negative with at most two decimals.");
        if (row.CurrentSellingPrice > 0 &&
            string.IsNullOrWhiteSpace(row.PriceChangeReason))
            row.Messages.Add("PriceChangeReason is required when a positive price is supplied.");
        if (!string.IsNullOrWhiteSpace(row.ProductCode) && !codeSet.Add(row.ProductCode))
            row.Messages.Add("ProductCode is duplicated in the workbook.");
        if (row.ProductId.HasValue && !productIdSet.Add(row.ProductId.Value))
            row.Messages.Add("ProductId is duplicated in the workbook.");

        var existingById = row.ProductId.HasValue
            ? existingProducts.FirstOrDefault(item => item.ProductId == row.ProductId.Value)
            : null;
        var existingByCode = string.IsNullOrWhiteSpace(row.ProductCode)
            ? null
            : existingProducts.FirstOrDefault(item =>
                item.Code.Equals(row.ProductCode, StringComparison.OrdinalIgnoreCase));
        if (row.ProductId.HasValue && existingById is null)
            row.Messages.Add("ProductId does not identify an existing product.");
        if (existingById is not null &&
            existingByCode is not null &&
            existingById.ProductId != existingByCode.ProductId)
            row.Messages.Add("ProductId and ProductCode identify different products.");
        var existing = existingById ?? existingByCode;
        row.Action = existing is null ? "Create" : "Update";
        row.ValidationStatus = row.Messages.Count == 0 ? "Valid" : "Invalid";
    }

    private async Task<byte[]> ReadAndValidateFileAsync(
        IFormFile file,
        CancellationToken cancellationToken)
    {
        var maximumMb = await _settings.GetIntAsync(
            SystemSettingKeys.FilesExcelImportMaximumMb,
            cancellationToken);
        if (file.Length <= 0)
            throw new PhaseBException(400, "Select a non-empty Excel workbook.");
        if (file.Length > maximumMb * 1024L * 1024L)
            throw new PhaseBException(400, $"The workbook exceeds the {maximumMb} MB limit.");
        if (!Path.GetExtension(file.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
            throw new PhaseBException(400, "Product and Price imports must use .xlsx files.");
        if (!file.ContentType.Equals(ContentType, StringComparison.OrdinalIgnoreCase) &&
            !file.ContentType.Equals("application/octet-stream", StringComparison.OrdinalIgnoreCase))
            throw new PhaseBException(400, "The uploaded file does not declare an Excel content type.");
        await using var stream = new MemoryStream();
        await file.CopyToAsync(stream, cancellationToken);
        var bytes = stream.ToArray();
        if (bytes.Length < 4 ||
            bytes[0] != 0x50 || bytes[1] != 0x4B ||
            bytes[2] != 0x03 || bytes[3] != 0x04)
            throw new PhaseBException(400, "The uploaded file does not have a valid XLSX signature.");
        return bytes;
    }

    private static XLWorkbook CreateWorkbook(
        string user,
        string purpose,
        IReadOnlyCollection<string> details)
    {
        var workbook = new XLWorkbook();
        var instructions = workbook.AddWorksheet(InstructionsSheetName);
        instructions.Cell("A1").Value = "PhenyoSync WMS Product and Price Data Exchange";
        instructions.Cell("A1").Style.Font.Bold = true;
        instructions.Cell("A1").Style.Font.FontSize = 16;
        instructions.Cell("A2").Value = "Template version";
        instructions.Cell("B2").Value = TemplateVersion;
        instructions.Cell("A3").Value = "Purpose";
        instructions.Cell("B3").Value = purpose;
        instructions.Cell("A4").Value = "Generated at (UTC)";
        instructions.Cell("B4").Value = DateTime.UtcNow;
        instructions.Cell("A5").Value = "Generated by";
        instructions.Cell("B5").Value = user;
        instructions.Cell("A7").Value =
            "Validate the workbook in PhenyoSync before confirming an import. Do not add, remove, or reorder columns.";
        instructions.Cell("A8").Value =
            "Example: a 10 kg bag priced per kg uses SellingUnit 'bag', KilogramsPerUnit 10 and PriceBasis PerKilogram. A box priced as one box may use PerSellableUnit without a weight.";
        var row = 9;
        foreach (var detail in details)
            instructions.Cell(row++, 1).Value = detail;
        instructions.Columns().AdjustToContents(8, 80);
        workbook.AddWorksheet(DataSheetName);
        return workbook;
    }

    private static void WriteDataHeader(IXLWorksheet sheet)
    {
        sheet.Cell("A1").Value = "PhenyoSync Product and Price Catalogue";
        sheet.Cell("A1").Style.Font.Bold = true;
        sheet.Cell("A1").Style.Font.FontSize = 16;
        sheet.Cell("A2").Value = $"Generated at (UTC): {DateTime.UtcNow:O}";
        sheet.Cell("A3").Value =
            "Required import columns include Product identity, hierarchy, stock unit, selling unit, pack weight, shelf life and status.";
        for (var column = 1; column <= Headers.Length; column++)
            sheet.Cell(HeaderRow, column).Value = Headers[column - 1];
        StyleHeader(sheet.Range(HeaderRow, 1, HeaderRow, Headers.Length));
        sheet.SheetView.FreezeRows(HeaderRow);
        sheet.Range(HeaderRow, 1, HeaderRow, Headers.Length).SetAutoFilter();
        AddTemplateValidation(sheet);
    }

    private static void AddTemplateValidation(IXLWorksheet sheet)
    {
        const int firstDataRow = HeaderRow + 1;
        const int lastTemplateRow = HeaderRow + 1000;
        AddListValidation(sheet.Range(firstDataRow, 9, lastTemplateRow, 9), "KG");
        AddListValidation(sheet.Range(firstDataRow, 10, lastTemplateRow, 10),
            "kg,bag,box,pack,unit,crate,punnet,bunch,tray,each");
        AddListValidation(sheet.Range(firstDataRow, 12, lastTemplateRow, 12), "TRUE,FALSE");
        AddListValidation(sheet.Range(firstDataRow, 14, lastTemplateRow, 14), "Active,Inactive");
        AddListValidation(sheet.Range(firstDataRow, 15, lastTemplateRow, 15),
            "PerKilogram,PerSellableUnit");
    }

    private static void AddListValidation(IXLRange range, string values)
    {
        var validation = range.CreateDataValidation();
        validation.List($"\"{values}\"");
        validation.IgnoreBlanks = true;
        validation.InCellDropdown = true;
        validation.ShowErrorMessage = true;
        validation.ErrorTitle = "Choose a supported value";
        validation.ErrorMessage = "Select a value from the supplied PhenyoSync list.";
    }

    private static void FormatDataRows(IXLWorksheet sheet, int lastRow)
    {
        if (lastRow > HeaderRow)
        {
            sheet.Range(HeaderRow + 1, 16, lastRow, 16).Style.NumberFormat.Format =
                "R #,##0.00";
            sheet.Range(HeaderRow + 1, 17, lastRow, 17).Style.DateFormat.Format =
                "yyyy-mm-dd hh:mm:ss";
            for (var row = HeaderRow + 1; row <= lastRow; row += 2)
                sheet.Range(row, 1, row, Headers.Length).Style.Fill.BackgroundColor =
                    XLColor.FromHtml("#F2F8F4");
        }
        sheet.Columns().AdjustToContents(8, 45);
    }

    private static void StyleHeader(IXLRange range)
    {
        range.Style.Font.Bold = true;
        range.Style.Font.FontColor = XLColor.White;
        range.Style.Fill.BackgroundColor = XLColor.FromHtml("#146C3C");
    }

    private static GeneratedExchangeFile ToFile(
        XLWorkbook workbook,
        string fileName)
    {
        using var stream = new MemoryStream();
        workbook.SaveAs(stream);
        return new GeneratedExchangeFile(stream.ToArray(), ContentType, fileName);
    }

    private async Task<string> UserDisplayNameAsync(
        int userId,
        CancellationToken cancellationToken) =>
        await _context.Users.AsNoTracking()
            .Where(item => item.UserId == userId)
            .Select(item => item.FirstName + " " + item.LastName)
            .SingleOrDefaultAsync(cancellationToken) ?? $"User {userId}";

    private Task AuditAsync(
        string action,
        string operation,
        int userId,
        string description,
        IReadOnlyDictionary<string, object?> details,
        CancellationToken cancellationToken) =>
        _audit.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = AuditModules.DataExchange,
            OperationName = operation,
            Description = description,
            EntityType = "DataExchangeJob",
            UserId = userId,
            SafeDetails = details
        }, cancellationToken);

    private static string CategoryCode(int id) => $"CATEGORY-{id:D4}";
    private static string TypeCode(int id) => $"TYPE-{id:D4}";

    private static int ParseCode(string value, string prefix)
    {
        var normalized = value.Trim().ToUpperInvariant();
        var part = normalized.StartsWith(prefix + "-", StringComparison.Ordinal)
            ? normalized[(prefix.Length + 1)..]
            : string.Empty;
        if (!int.TryParse(part, NumberStyles.Integer, CultureInfo.InvariantCulture, out var id))
            throw new PhaseBException(409, $"The staged {prefix.ToLowerInvariant()} code is invalid.");
        return id;
    }

    private static string Text(IXLCell cell) => cell.GetString().Trim();
    private static int ReadInt(IXLCell cell) =>
        cell.TryGetValue<int>(out var value) ? value : 0;
    private static int? ReadNullableInt(IXLCell cell) =>
        cell.IsEmpty() ? null : cell.TryGetValue<int>(out var value) ? value : -1;
    private static decimal ReadDecimal(IXLCell cell) =>
        cell.IsEmpty() ? 0 : cell.TryGetValue<decimal>(out var value) ? value : -1;
    private static decimal? ReadNullableDecimal(IXLCell cell) =>
        cell.IsEmpty() ? null : cell.TryGetValue<decimal>(out var value) ? value : -1;
    private static bool ReadBoolean(IXLCell cell) =>
        cell.TryGetValue<bool>(out var value)
            ? value
            : bool.TryParse(cell.GetString(), out var parsed) && parsed;
    private static DateTime? ReadNullableDate(IXLCell cell) =>
        cell.IsEmpty()
            ? null
            : cell.TryGetValue<DateTime>(out var value)
                ? DateTime.SpecifyKind(value, DateTimeKind.Utc)
                : null;

    private static void ValidateExportQuery(ProductExcelExportQueryDto query)
    {
        if (query.ProductCategoryId is < 1 || query.ProductTypeId is < 1)
            throw new PhaseBException(400, "Product filter IDs must be greater than zero.");
        if (!string.IsNullOrWhiteSpace(query.ProductStatus) &&
            query.ProductStatus is not ProductStatuses.Active and not ProductStatuses.Inactive)
            throw new PhaseBException(400, "Product status must be Active or Inactive.");
        if (!string.IsNullOrWhiteSpace(query.PriceStatus) &&
            !new[] { "Priced", "Unpriced", "All" }.Contains(
                query.PriceStatus,
                StringComparer.OrdinalIgnoreCase))
            throw new PhaseBException(400, "Price status must be Priced, Unpriced, or All.");
    }

    private sealed record AssociationKey(
        int ProductCategoryId,
        int ProductTypeId);

    private sealed record ExistingProductKey(
        int ProductId,
        string Code);
}
