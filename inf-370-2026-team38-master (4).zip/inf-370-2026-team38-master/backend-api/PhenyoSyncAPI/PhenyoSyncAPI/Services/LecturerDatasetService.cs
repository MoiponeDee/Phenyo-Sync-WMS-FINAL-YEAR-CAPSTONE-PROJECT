using System.Data;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public enum LecturerDatasetMode
{
    DryRun,
    Seed,
    Verify
}

public sealed record LecturerDatasetResult(
    bool Success,
    string Mode,
    string Marker,
    IReadOnlyList<string> Messages,
    IReadOnlyDictionary<string, int> Counts);

public interface ILecturerDatasetService
{
    Task<LecturerDatasetResult> ExecuteAsync(
        LecturerDatasetMode mode,
        CancellationToken cancellationToken = default);
}

public sealed class LecturerDatasetService : ILecturerDatasetService
{
    public const string Marker = "LECTURER-DATASET-2026";
    public const string RequiredMigration =
        "20260811200929_PreserveUnknownStockCosts";

    private readonly PhenyoSyncDbContext _db;

    public LecturerDatasetService(PhenyoSyncDbContext db)
    {
        _db = db;
    }

    public async Task<LecturerDatasetResult> ExecuteAsync(
        LecturerDatasetMode mode,
        CancellationToken cancellationToken = default)
    {
        if (!await _db.Database.CanConnectAsync(cancellationToken))
        {
            return Failure(mode, "The configured database cannot be reached.");
        }

        var migrationApplied = (await _db.Database
                .GetAppliedMigrationsAsync(cancellationToken))
            .Contains(RequiredMigration, StringComparer.Ordinal);
        if (!migrationApplied)
        {
            return Failure(
                mode,
                $"Apply {RequiredMigration} before using the lecturer dataset commands.");
        }

        return mode switch
        {
            LecturerDatasetMode.DryRun => await DryRunAsync(cancellationToken),
            LecturerDatasetMode.Seed => await SeedAsync(cancellationToken),
            LecturerDatasetMode.Verify => await VerifyAsync(cancellationToken),
            _ => Failure(mode, "Unsupported lecturer dataset command.")
        };
    }

    private async Task<LecturerDatasetResult> DryRunAsync(
        CancellationToken cancellationToken)
    {
        var exists = await _db.Customers
            .AsNoTracking()
            .AnyAsync(
                item => item.CustomerNumber.StartsWith("LECTURER-2026-"),
                cancellationToken);

        var messages = new List<string>
        {
            "Dry run only: no rows were inserted, updated or deleted.",
            exists
                ? "The dataset marker already exists; seed mode will verify and leave it unchanged."
                : "Seed mode will create the isolated demonstration dataset in one transaction.",
            "The dataset includes customers, suppliers, raw and finished stock, batches, expiry examples, orders, invoices, payments, reversals and deliveries.",
            "Demonstration users use zafarsuliman+lecturer-...@gmail.com and the requested training password. Change those passwords outside a classroom environment."
        };

        return new LecturerDatasetResult(
            true,
            LecturerDatasetMode.DryRun.ToString(),
            Marker,
            messages,
            await ReadCountsAsync(cancellationToken));
    }

    private async Task<LecturerDatasetResult> SeedAsync(
        CancellationToken cancellationToken)
    {
        var alreadyExists = await _db.Customers
            .AnyAsync(
                item => item.CustomerNumber.StartsWith("LECTURER-2026-"),
                cancellationToken);
        if (alreadyExists)
        {
            var existing = await VerifyAsync(cancellationToken);
            return existing with
            {
                Mode = LecturerDatasetMode.Seed.ToString(),
                Messages = existing.Messages
                    .Prepend("The marker already existed; seed mode made no changes.")
                    .ToArray()
            };
        }

        await using var transaction = await _db.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);

        var businessManager = await EnsureUserAsync(
            RoleCodes.BusinessManager,
            "zafarsuliman+lecturer-businessmanager@gmail.com",
            "Lecturer",
            "Business Manager",
            cancellationToken);
        var operationsManager = await EnsureUserAsync(
            RoleCodes.OperationsManager,
            "zafarsuliman+lecturer-operationsmanager@gmail.com",
            "Lecturer",
            "Operations Manager",
            cancellationToken);
        var warehouseManager = await EnsureUserAsync(
            RoleCodes.WarehouseManager,
            "zafarsuliman+lecturer-warehousemanager@gmail.com",
            "Lecturer",
            "Warehouse Manager",
            cancellationToken);

        var section = new WarehouseSection
        {
            SectionCode = "LECT-2026",
            SectionName = "Lecturer Demonstration Storage",
            Description = Marker,
            Status = "Active",
            CreatedAtUtc = DateTime.UtcNow
        };
        var category = new ProductCategory
        {
            ProductCategoryName = "Lecturer Fresh Produce",
            Description = Marker,
            Status = "Active",
            CreatedAt = DateTime.UtcNow
        };
        var productType = new ProductType
        {
            ProductTypeName = "Lecturer Packed Produce",
            Description = Marker,
            Status = "Active",
            CreatedAt = DateTime.UtcNow
        };
        _db.AddRange(section, category, productType);
        await _db.SaveChangesAsync(cancellationToken);

        _db.ProductCategoryTypes.Add(new ProductCategoryType
        {
            ProductCategoryId = category.ProductCategoryId,
            ProductTypeId = productType.ProductTypeId,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedByUserId = businessManager.UserId
        });

        var products = new[]
        {
            Product("Lecturer Carrot Pack", "LECT-CARROT-QR", 7, 28, "Active"),
            Product("Lecturer Potato Pack", "LECT-POTATO-QR", 14, 22, "Active"),
            Product("Lecturer Pepper Pack", "LECT-PEPPER-QR", 10, 35, "Active"),
            Product("Lecturer Cost Unknown Pack", "LECT-UNKNOWN-COST-QR", 5, 18, "Active"),
            Product("Lecturer Inactive Product", "LECT-INACTIVE-QR", 5, 15, "Inactive")
        };
        foreach (var product in products)
        {
            product.ProductCategoryId = category.ProductCategoryId;
            product.ProductTypeId = productType.ProductTypeId;
        }
        _db.Products.AddRange(products);

        var customers = new[]
        {
            Customer("LECTURER-2026-C01", "Mahlangu Family Market", 1),
            Customer("LECTURER-2026-C02", "Ubuntu Community Kitchen", 2),
            Customer("LECTURER-2026-C03", "Green Valley Café", 3)
        };
        var suppliers = new[]
        {
            Supplier("LECTURER-2026-S01", "Pretoria Fresh Produce Agency", 1),
            Supplier("LECTURER-2026-S02", "Gauteng Packaging Cooperative", 2)
        };
        _db.Customers.AddRange(customers);
        _db.Suppliers.AddRange(suppliers);
        await _db.SaveChangesAsync(cancellationToken);

        var priceStart = new DateTime(2026, 1, 1, 6, 0, 0, DateTimeKind.Utc);
        var prices = new List<ProductPrice>();
        foreach (var product in products.Take(4))
        {
            prices.Add(new ProductPrice
            {
                ProductId = product.ProductId,
                SellingPrice = product.SellingPricePerKg - 2,
                EffectiveFromUtc = priceStart,
                EffectiveToUtc = new DateTime(2026, 3, 31, 23, 59, 59, DateTimeKind.Utc),
                IsCurrent = false,
                CreatedAtUtc = priceStart,
                CreatedByUserId = businessManager.UserId,
                ChangeReason = Marker + " historical price"
            });
            prices.Add(new ProductPrice
            {
                ProductId = product.ProductId,
                SellingPrice = product.SellingPricePerKg,
                EffectiveFromUtc = new DateTime(2026, 4, 1, 0, 0, 0, DateTimeKind.Utc),
                IsCurrent = true,
                CreatedAtUtc = new DateTime(2026, 4, 1, 0, 0, 0, DateTimeKind.Utc),
                CreatedByUserId = businessManager.UserId,
                ChangeReason = Marker + " current price"
            });
        }
        _db.ProductPrices.AddRange(prices);

        var now = DateTime.UtcNow;
        var batches = new[]
        {
            Batch(products[0], section, "LECT-BATCH-CARROT-A", now.AddDays(-4), now.AddDays(3), 80),
            Batch(products[0], section, "LECT-BATCH-CARROT-B", now.AddDays(-2), now.AddDays(12), 60),
            Batch(products[1], section, "LECT-BATCH-POTATO-A", now.AddDays(-8), now.AddDays(-1), 25, ProductBatchStatuses.ExpiredPendingDecision),
            Batch(products[1], section, "LECT-BATCH-POTATO-B", now.AddDays(-1), now.AddDays(13), 90),
            Batch(products[2], section, "LECT-BATCH-PEPPER-A", now.AddDays(-2), now.AddDays(2), 70),
            Batch(products[3], section, "LECT-BATCH-UNKNOWN-A", now.AddDays(-1), now.AddDays(4), 30)
        };
        _db.ProductBatches.AddRange(batches);
        await _db.SaveChangesAsync(cancellationToken);

        var stocks = products.Take(4).Select(product => new Stock
        {
            ProductId = product.ProductId,
            SectionId = section.SectionId,
            QuantityAvailableKg = batches
                .Where(batch => batch.ProductId == product.ProductId &&
                    batch.Status == ProductBatchStatuses.Available)
                .Sum(batch => batch.QuantityRemainingKg),
            ReorderLevelKg = 20,
            InventoryStatus = "Available"
        }).ToArray();
        _db.Stocks.AddRange(stocks);
        await _db.SaveChangesAsync(cancellationToken);

        foreach (var batch in batches)
        {
            _db.StockMovements.Add(new StockMovement
            {
                ProductId = batch.ProductId,
                ProductBatchId = batch.ProductBatchId,
                SectionId = section.SectionId,
                MovementType = StockMovementTypes.Increase,
                QuantityKg = batch.QuantityProducedKg,
                OccurredAtUtc = batch.PackedAtUtc,
                CreatedByUserId = warehouseManager.UserId,
                Reason = Marker + " opening finished stock"
            });
        }

        await SeedRawStockAsync(
            section,
            products[0],
            suppliers[0],
            warehouseManager,
            operationsManager,
            cancellationToken);

        await SeedOrdersAsync(
            customers,
            products,
            prices,
            batches,
            stocks,
            businessManager,
            operationsManager,
            cancellationToken);

        await _db.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);

        var verification = await VerifyAsync(cancellationToken);
        return verification with
        {
            Mode = LecturerDatasetMode.Seed.ToString(),
            Messages = verification.Messages
                .Prepend("The lecturer dataset was created in one committed transaction.")
                .ToArray()
        };
    }

    private async Task SeedRawStockAsync(
        WarehouseSection section,
        Product mappedProduct,
        Supplier supplier,
        User warehouseManager,
        User operationsManager,
        CancellationToken cancellationToken)
    {
        var known = new RawStockItem
        {
            ItemCode = "LECT-RAW-CARROT",
            ItemName = "Lecturer Loose Carrots",
            CategoryCode = RawStockCategories.Produce,
            DefaultUnitOfMeasure = RawStockUnits.Kilogram,
            Description = Marker + " known-cost material",
            IsProduce = true,
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        var unknown = new RawStockItem
        {
            ItemCode = "LECT-RAW-UNKNOWN",
            ItemName = "Lecturer Material Awaiting Cost",
            CategoryCode = RawStockCategories.General,
            DefaultUnitOfMeasure = RawStockUnits.Unit,
            Description = Marker + " unknown-cost example: empty balance awaiting first receipt",
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        _db.RawStockItems.AddRange(known, unknown);
        await _db.SaveChangesAsync(cancellationToken);

        var balance = new RawStockBalance
        {
            RawStockItemId = known.RawStockItemId,
            WarehouseSectionId = section.SectionId,
            UnitOfMeasure = RawStockUnits.Kilogram,
            QuantityOnHand = 95,
            WeightedAverageUnitCost = 8.50m,
            LastReceiptAtUtc = DateTime.UtcNow.AddDays(-7),
            LastStockTakeAtUtc = DateTime.UtcNow.AddDays(-1)
        };
        var unknownBalance = new RawStockBalance
        {
            RawStockItemId = unknown.RawStockItemId,
            WarehouseSectionId = section.SectionId,
            UnitOfMeasure = RawStockUnits.Unit,
            QuantityOnHand = 0,
            WeightedAverageUnitCost = null
        };
        _db.RawStockBalances.AddRange(balance, unknownBalance);
        await _db.SaveChangesAsync(cancellationToken);

        var receipt = new RawStockReceipt
        {
            ReceiptNumber = "LECT-RSR-2026-001",
            SourceType = RawStockReceiptSources.AdHocSupplier,
            SupplierId = supplier.SupplierId,
            WarehouseSectionId = section.SectionId,
            ReceivedByUserId = warehouseManager.UserId,
            DocketReference = "LECT-DOCKET-001",
            AdHocExplanation = "Lecturer dataset receipt",
            Notes = Marker,
            ReceivedAtUtc = DateTime.UtcNow.AddDays(-7),
            CreatedAtUtc = DateTime.UtcNow.AddDays(-7),
            PostedAtUtc = DateTime.UtcNow.AddDays(-7),
            Status = MobileOperationStatuses.Completed,
            CorrelationId = "lecturer-raw-receipt-2026",
            OperationKeyHash = "LECTURER-DATASET-2026-RAW-RECEIPT-KEY"
        };
        var line = new RawStockReceiptLine
        {
            Receipt = receipt,
            RawStockItemId = known.RawStockItemId,
            QuantityReceived = 100,
            AcceptedQuantity = 100,
            UnitCost = 8.50m,
            UnitOfMeasure = RawStockUnits.Kilogram,
            SupplierBatchReference = "LECT-RAW-BATCH-001",
            BestBeforeAtUtc = DateTime.UtcNow.AddDays(10),
            Notes = Marker
        };
        receipt.Lines.Add(line);
        _db.RawStockReceipts.Add(receipt);
        await _db.SaveChangesAsync(cancellationToken);

        var batch = new RawStockBatch
        {
            RawStockItemId = known.RawStockItemId,
            RawStockBalanceId = balance.RawStockBalanceId,
            SupplierId = supplier.SupplierId,
            RawStockReceiptLineId = line.RawStockReceiptLineId,
            BatchCode = "LECT-RAW-BATCH-001",
            QrCodeValue = "PHENYOSYNC:LECTURER:RAW:001",
            QuantityReceived = 100,
            QuantityRemaining = 95,
            UnitCost = 8.50m,
            ReceivedAtUtc = receipt.ReceivedAtUtc,
            BestBeforeAtUtc = DateTime.UtcNow.AddDays(10),
            Status = ProductBatchStatuses.Available
        };
        _db.RawStockBatches.Add(batch);
        await _db.SaveChangesAsync(cancellationToken);

        _db.RawStockMovements.Add(new RawStockMovement
        {
            RawStockItemId = known.RawStockItemId,
            RawStockBalanceId = balance.RawStockBalanceId,
            RawStockBatchId = batch.RawStockBatchId,
            CreatedByUserId = warehouseManager.UserId,
            MovementType = RawStockMovementTypes.Receipt,
            QuantityChange = 100,
            UnitCost = 8.50m,
            OccurredAtUtc = receipt.ReceivedAtUtc,
            SourceType = nameof(RawStockReceipt),
            SourceId = receipt.RawStockReceiptId.ToString(),
            ReasonText = Marker,
            CorrelationId = receipt.CorrelationId
        });

        var reason = new OperationalReason
        {
            ReasonCode = "LECT-SPOILED",
            ReasonName = "Lecturer spoiled-stock example",
            CategoryCode = "WriteOff",
            Description = Marker,
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        _db.OperationalReasons.Add(reason);
        await _db.SaveChangesAsync(cancellationToken);

        _db.RawStockWriteOffs.AddRange(
            new RawStockWriteOff
            {
                RawStockItemId = known.RawStockItemId,
                RawStockBalanceId = balance.RawStockBalanceId,
                RawStockBatchId = batch.RawStockBatchId,
                OperationalReasonId = reason.OperationalReasonId,
                SubmittedByUserId = warehouseManager.UserId,
                Quantity = 2,
                EstimatedUnitCost = 8.50m,
                EstimatedTotalLoss = 17,
                Condition = "Spoiled",
                Notes = Marker + " pending approval",
                Status = WriteOffStatuses.PendingApproval,
                SubmittedAtUtc = DateTime.UtcNow.AddHours(-2),
                CorrelationId = "lecturer-writeoff-pending-2026"
            },
            new RawStockWriteOff
            {
                RawStockItemId = known.RawStockItemId,
                RawStockBalanceId = balance.RawStockBalanceId,
                RawStockBatchId = batch.RawStockBatchId,
                OperationalReasonId = reason.OperationalReasonId,
                SubmittedByUserId = warehouseManager.UserId,
                DecidedByUserId = operationsManager.UserId,
                Quantity = 5,
                EstimatedUnitCost = 8.50m,
                EstimatedTotalLoss = 42.50m,
                Condition = "Spoiled",
                Notes = Marker + " approved example",
                Status = WriteOffStatuses.Completed,
                DecisionReason = "Approved for lecturer demonstration",
                SubmittedAtUtc = DateTime.UtcNow.AddDays(-1),
                DecidedAtUtc = DateTime.UtcNow.AddDays(-1).AddMinutes(10),
                CompletedAtUtc = DateTime.UtcNow.AddDays(-1).AddMinutes(11),
                CorrelationId = "lecturer-writeoff-approved-2026"
            });

        var take = new RawStockTakeSession
        {
            WarehouseSectionId = section.SectionId,
            CreatedByUserId = warehouseManager.UserId,
            ReviewedByUserId = operationsManager.UserId,
            DecidedByUserId = operationsManager.UserId,
            PeriodStartUtc = DateTime.UtcNow.AddDays(-2),
            PeriodEndUtc = DateTime.UtcNow.AddDays(-1),
            CreatedAtUtc = DateTime.UtcNow.AddDays(-1),
            SubmittedAtUtc = DateTime.UtcNow.AddDays(-1),
            ReviewedAtUtc = DateTime.UtcNow.AddDays(-1),
            DecidedAtUtc = DateTime.UtcNow.AddDays(-1),
            ClosedAtUtc = DateTime.UtcNow.AddDays(-1),
            Status = RawStockTakeStatuses.Closed,
            Notes = Marker,
            ManagementApprovalRequired = false,
            CorrelationId = "lecturer-stocktake-2026"
        };
        take.Lines.Add(new RawStockTakeLine
        {
            RawStockItemId = known.RawStockItemId,
            RawStockBalanceId = balance.RawStockBalanceId,
            OpeningRawStock = 100,
            RecordedRawStockWriteOffs = 5,
            EstimatedRawStockRemaining = 95,
            PhysicalStockCount = 95,
            UnexplainedStockDifference = 0,
            EstimatedFinancialImpact = 0,
            IsMapped = true
        });
        _db.RawStockTakeSessions.Add(take);

        var group = new RawStockReconciliationGroup
        {
            GroupCode = "LECT-CARROT-GROUP",
            GroupName = "Lecturer Carrot Cost Group",
            Description = Marker,
            IsActive = true
        };
        group.RawStockItems.Add(new RawStockReconciliationGroupItem
        {
            RawStockItemId = known.RawStockItemId
        });
        group.Products.Add(new ProductReconciliationMapping
        {
            ProductId = mappedProduct.ProductId
        });
        _db.RawStockReconciliationGroups.Add(group);
    }

    private async Task SeedOrdersAsync(
        Customer[] customers,
        Product[] products,
        List<ProductPrice> prices,
        ProductBatch[] batches,
        Stock[] stocks,
        User businessManager,
        User operationsManager,
        CancellationToken cancellationToken)
    {
        var orders = new[]
        {
            Order("LECT-ORDER-2026-001", customers[0], SalesOrderStatuses.Submitted, new DateTime(2026, 1, 15, 8, 0, 0, DateTimeKind.Utc), products[..3], prices, businessManager, 2),
            Order("LECT-ORDER-2026-002", customers[1], SalesOrderStatuses.Approved, new DateTime(2026, 2, 18, 8, 0, 0, DateTimeKind.Utc), products[..2], prices, businessManager, 3),
            Order("LECT-ORDER-2026-003", customers[2], SalesOrderStatuses.Packed, new DateTime(2026, 4, 10, 8, 0, 0, DateTimeKind.Utc), products[..3], prices, businessManager, 1),
            Order("LECT-ORDER-2026-004", customers[0], SalesOrderStatuses.Delivered, new DateTime(2026, 6, 12, 8, 0, 0, DateTimeKind.Utc), products[..2], prices, businessManager, 2),
            Order("LECT-ORDER-2026-005", customers[1], SalesOrderStatuses.Packed, new DateTime(2026, 6, 22, 8, 0, 0, DateTimeKind.Utc), products[..2], prices, businessManager, 1)
        };
        _db.SalesOrders.AddRange(orders);
        await _db.SaveChangesAsync(cancellationToken);

        var reservedOrder = orders[1];
        foreach (var item in reservedOrder.Items)
        {
            var stock = stocks.Single(value => value.ProductId == item.ProductId);
            var batch = batches
                .Where(value => value.ProductId == item.ProductId &&
                    value.Status == ProductBatchStatuses.Available)
                .OrderBy(value => value.EffectiveExpiryAtUtc)
                .First();
            _db.OrderStockReservations.Add(new OrderStockReservation
            {
                SalesOrderId = reservedOrder.SalesOrderId,
                SalesOrderItemId = item.SalesOrderItemId,
                ProductId = item.ProductId,
                StockId = stock.StockId,
                SectionId = stock.SectionId,
                ProductBatchId = batch.ProductBatchId,
                QuantityReservedKg = item.QuantityKg,
                Status = OrderReservationStatuses.Active,
                ReservedAtUtc = reservedOrder.OrderDateUtc.AddHours(1)
            });
        }

        var invoicePartial = Invoice(orders[2], "LECT-INV-2026-001");
        var invoicePaid = Invoice(orders[3], "LECT-INV-2026-002");
        var invoiceReversal = Invoice(orders[4], "LECT-INV-2026-003");
        _db.Invoices.AddRange(invoicePartial, invoicePaid, invoiceReversal);
        await _db.SaveChangesAsync(cancellationToken);

        var partialAmount = Math.Round(invoicePartial.TotalAmount / 2, 2);
        var fullAmount = invoicePaid.TotalAmount;
        var reversalAmount = Math.Min(50, invoiceReversal.TotalAmount);
        var partialPayment = Payment(
            "LECT-PAY-2026-001",
            customers[2],
            invoicePartial,
            partialAmount,
            businessManager,
            new DateTime(2026, 4, 11, 9, 0, 0, DateTimeKind.Utc));
        var fullPayment = Payment(
            "LECT-PAY-2026-002",
            customers[0],
            invoicePaid,
            fullAmount,
            businessManager,
            new DateTime(2026, 6, 13, 9, 0, 0, DateTimeKind.Utc));
        var reversalOriginal = Payment(
            "LECT-PAY-2026-003",
            customers[1],
            invoiceReversal,
            reversalAmount,
            businessManager,
            new DateTime(2026, 6, 23, 9, 0, 0, DateTimeKind.Utc));
        _db.FinancialPayments.AddRange(
            partialPayment,
            fullPayment,
            reversalOriginal);
        await _db.SaveChangesAsync(cancellationToken);

        _db.FinancialPayments.AddRange(
            new FinancialPayment
            {
                PaymentNumber = "LECT-REV-2026-001",
                CounterpartyType = "Customer",
                CustomerId = customers[1].CustomerId,
                InvoiceId = invoiceReversal.InvoiceId,
                OriginalPaymentId = reversalOriginal.FinancialPaymentId,
                Amount = -reversalAmount,
                PaymentDateUtc = reversalOriginal.PaymentDateUtc.AddDays(1),
                PaymentMethodCode = "Adjustment",
                Reference = Marker,
                Notes = "Approved linked reversal",
                Status = FinancialPaymentStatuses.Posted,
                ReversalReason = "Lecturer approved reversal example",
                CreatedByUserId = businessManager.UserId,
                PostedByUserId = operationsManager.UserId,
                DecidedByUserId = operationsManager.UserId,
                CreatedAtUtc = reversalOriginal.PaymentDateUtc.AddDays(1),
                PostedAtUtc = reversalOriginal.PaymentDateUtc.AddDays(1),
                DecidedAtUtc = reversalOriginal.PaymentDateUtc.AddDays(1),
                CorrelationId = "lecturer-reversal-approved-2026"
            },
            new FinancialPayment
            {
                PaymentNumber = "LECT-REV-2026-002",
                CounterpartyType = "Customer",
                CustomerId = customers[2].CustomerId,
                InvoiceId = invoicePartial.InvoiceId,
                OriginalPaymentId = partialPayment.FinancialPaymentId,
                Amount = -Math.Min(25, partialAmount),
                PaymentDateUtc = partialPayment.PaymentDateUtc.AddDays(1),
                PaymentMethodCode = "Adjustment",
                Reference = Marker,
                Notes = "Pending linked reversal request",
                Status = FinancialPaymentStatuses.PendingReversalApproval,
                ReversalReason = "Lecturer pending reversal example",
                CreatedByUserId = businessManager.UserId,
                CreatedAtUtc = partialPayment.PaymentDateUtc.AddDays(1),
                CorrelationId = "lecturer-reversal-pending-2026"
            });

        var delivery = new Delivery
        {
            SalesOrderId = orders[3].SalesOrderId,
            DeliveryAddressSnapshot = orders[3].DeliveryAddressSnapshot,
            ScheduledStartUtc = orders[3].OrderDateUtc.AddDays(1),
            ScheduledEndUtc = orders[3].OrderDateUtc.AddDays(1).AddHours(2),
            Status = DeliveryStatuses.Completed,
            StartedAtUtc = orders[3].OrderDateUtc.AddDays(1),
            StartedByUserId = businessManager.UserId,
            CompletedAtUtc = orders[3].OrderDateUtc.AddDays(1).AddHours(1),
            CompletedByUserId = businessManager.UserId,
            CreatedAtUtc = orders[3].OrderDateUtc
        };
        delivery.CompletionRecord = new DeliveryCompletionRecord
        {
            CompletedAtUtc = delivery.CompletedAtUtc!.Value,
            CompletedByUserId = businessManager.UserId,
            CompletedOnBehalfOfDriver = true,
            ManagementOverrideReason = Marker,
            RecipientName = "Lecturer Recipient",
            RecipientConfirmed = true,
            FulfillmentConfirmed = true,
            Notes = Marker,
            CreatedAtUtc = delivery.CompletedAtUtc.Value
        };
        _db.Deliveries.Add(delivery);
    }

    private async Task<LecturerDatasetResult> VerifyAsync(
        CancellationToken cancellationToken)
    {
        var counts = await ReadCountsAsync(cancellationToken);
        var checks = new Dictionary<string, bool>
        {
            ["multiple customers"] = counts["Customers"] >= 3,
            ["multiple suppliers"] = counts["Suppliers"] >= 2,
            ["active and inactive products"] = counts["Products"] >= 5,
            ["historical and active prices"] = counts["Prices"] >= 8,
            ["multiple batches and expiry examples"] = counts["Batches"] >= 6,
            ["three-item order"] = counts["ThreeItemOrders"] >= 1,
            ["submitted, validated and packed orders"] = counts["Orders"] >= 5,
            ["invoices and payment examples"] = counts["Invoices"] >= 3 &&
                counts["Payments"] >= 5,
            ["linked payment reversals"] = counts["Reversals"] >= 2,
            ["raw-stock receipt, take and write-offs"] =
                counts["RawReceipts"] >= 1 &&
                counts["RawStockTakes"] >= 1 &&
                counts["RawWriteOffs"] >= 2,
            ["completed delivery"] = counts["CompletedDeliveries"] >= 1
        };
        var failed = checks.Where(item => !item.Value).Select(item => item.Key).ToArray();
        var messages = checks
            .Select(item => $"{(item.Value ? "PASS" : "FAIL")}: {item.Key}")
            .ToList();
        messages.Add(failed.Length == 0
            ? "All lecturer dataset verification checks passed."
            : "Missing evidence: " + string.Join(", ", failed));

        return new LecturerDatasetResult(
            failed.Length == 0,
            LecturerDatasetMode.Verify.ToString(),
            Marker,
            messages,
            counts);
    }

    private async Task<Dictionary<string, int>> ReadCountsAsync(
        CancellationToken cancellationToken)
    {
        var customerIds = await _db.Customers
            .AsNoTracking()
            .Where(item => item.CustomerNumber.StartsWith("LECTURER-2026-"))
            .Select(item => item.CustomerId)
            .ToArrayAsync(cancellationToken);
        var orderIds = await _db.SalesOrders
            .AsNoTracking()
            .Where(item => item.OrderNumber.StartsWith("LECT-ORDER-2026-"))
            .Select(item => item.SalesOrderId)
            .ToArrayAsync(cancellationToken);

        return new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
        {
            ["Customers"] = customerIds.Length,
            ["Suppliers"] = await _db.Suppliers.CountAsync(
                item => item.SupplierCode.StartsWith("LECTURER-2026-"),
                cancellationToken),
            ["Products"] = await _db.Products.CountAsync(
                item => item.ProductName.StartsWith("Lecturer "),
                cancellationToken),
            ["Prices"] = await _db.ProductPrices.CountAsync(
                item => item.ChangeReason != null && item.ChangeReason.Contains(Marker),
                cancellationToken),
            ["Batches"] = await _db.ProductBatches.CountAsync(
                item => item.BatchCode.StartsWith("LECT-BATCH-"),
                cancellationToken),
            ["Orders"] = orderIds.Length,
            ["ThreeItemOrders"] = await _db.SalesOrders
                .Where(item => orderIds.Contains(item.SalesOrderId))
                .CountAsync(item => item.Items.Count >= 3, cancellationToken),
            ["Invoices"] = await _db.Invoices.CountAsync(
                item => item.InvoiceNumber.StartsWith("LECT-INV-2026-"),
                cancellationToken),
            ["Payments"] = await _db.FinancialPayments.CountAsync(
                item => item.PaymentNumber.StartsWith("LECT-"),
                cancellationToken),
            ["Reversals"] = await _db.FinancialPayments.CountAsync(
                item => item.PaymentNumber.StartsWith("LECT-REV-2026-"),
                cancellationToken),
            ["RawReceipts"] = await _db.RawStockReceipts.CountAsync(
                item => item.ReceiptNumber.StartsWith("LECT-RSR-2026-"),
                cancellationToken),
            ["RawStockTakes"] = await _db.RawStockTakeSessions.CountAsync(
                item => item.CorrelationId == "lecturer-stocktake-2026",
                cancellationToken),
            ["RawWriteOffs"] = await _db.RawStockWriteOffs.CountAsync(
                item => item.CorrelationId.StartsWith("lecturer-writeoff-"),
                cancellationToken),
            ["CompletedDeliveries"] = await _db.Deliveries.CountAsync(
                item => orderIds.Contains(item.SalesOrderId) &&
                    item.Status == DeliveryStatuses.Completed,
                cancellationToken)
        };
    }

    private async Task<User> EnsureUserAsync(
        string roleCode,
        string email,
        string firstName,
        string lastName,
        CancellationToken cancellationToken)
    {
        var normalized = email.Trim().ToUpperInvariant();
        var existing = await _db.Users.SingleOrDefaultAsync(
            item => item.NormalizedEmail == normalized,
            cancellationToken);
        if (existing is not null)
        {
            return existing;
        }

        var role = await _db.Roles.SingleOrDefaultAsync(
            item => item.RoleCode == roleCode && item.IsActive,
            cancellationToken) ?? throw new InvalidOperationException(
            $"The required active role {roleCode} does not exist.");
        var user = new User
        {
            Email = email,
            NormalizedEmail = normalized,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("12345678"),
            FirstName = firstName,
            LastName = lastName,
            RoleId = role.RoleId,
            Status = "Active",
            CreatedDate = DateTime.UtcNow,
            SecurityVersion = 1
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync(cancellationToken);
        return user;
    }

    private static Product Product(
        string name,
        string qr,
        int shelfLifeDays,
        decimal price,
        string status) => new()
        {
            ProductName = name,
            Size = "1 kg",
            ShelfLifeDays = shelfLifeDays,
            SellingPricePerKg = price,
            QRCodeValue = qr,
            Status = status,
            CreatedAt = DateTime.UtcNow
        };

    private static Customer Customer(string number, string name, int index)
    {
        var email = $"zafarsuliman+lecturer-customer{index}@gmail.com";
        return new Customer
        {
            CustomerNumber = number,
            CustomerName = name,
            Email = email,
            NormalizedEmail = email.ToUpperInvariant(),
            ContactPerson = $"Lecturer Contact {index}",
            PhoneNumber = $"+27 71 000 00{index:00}",
            BillingAddress = $"{index} Lecturer Avenue, Pretoria",
            DeliveryAddress = $"{index} Demonstration Road, Pretoria",
            Status = CustomerStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
    }

    private static Supplier Supplier(string code, string name, int index)
    {
        var email = $"zafarsuliman+lecturer-supplier{index}@gmail.com";
        return new Supplier
        {
            SupplierCode = code,
            SupplierName = name,
            SupplierTypeCode = "ProduceAgency",
            ContactPerson = $"Lecturer Supplier Contact {index}",
            Email = email,
            NormalizedEmail = email.ToUpperInvariant(),
            Phone = $"+27 72 000 00{index:00}",
            Address = $"{index} Market Road, Pretoria",
            Status = "Active",
            CreatedAtUtc = DateTime.UtcNow
        };
    }

    private static ProductBatch Batch(
        Product product,
        WarehouseSection section,
        string code,
        DateTime packed,
        DateTime expiry,
        decimal quantity,
        string status = ProductBatchStatuses.Available) => new()
        {
            ProductId = product.ProductId,
            SectionId = section.SectionId,
            BatchCode = code,
            QRCodeValue = $"PHENYOSYNC:LECTURER:{code}",
            QuantityProducedKg = quantity,
            QuantityRemainingKg = quantity,
            PackedAtUtc = packed,
            OriginalExpiryAtUtc = expiry,
            EffectiveExpiryAtUtc = expiry,
            Status = status,
            CreatedAtUtc = packed
        };

    private static SalesOrder Order(
        string number,
        Customer customer,
        string status,
        DateTime date,
        Product[] products,
        IReadOnlyCollection<ProductPrice> prices,
        User createdBy,
        decimal quantity)
    {
        var order = new SalesOrder
        {
            OrderNumber = number,
            CustomerId = customer.CustomerId,
            Customer = customer,
            OrderDateUtc = date,
            RequestedDeliveryDateUtc = date.AddDays(1),
            DeliveryAddressSnapshot = customer.DeliveryAddress!,
            BillingAddressSnapshot = customer.BillingAddress!,
            Status = status,
            ValidationStatus = status == SalesOrderStatuses.Submitted
                ? OrderValidationStatuses.Pending
                : OrderValidationStatuses.Approved,
            ValidationMessage = Marker,
            Notes = Marker,
            CreatedByUserId = createdBy.UserId,
            ValidatedByUserId = status == SalesOrderStatuses.Submitted
                ? null
                : createdBy.UserId,
            ValidatedAtUtc = status == SalesOrderStatuses.Submitted
                ? null
                : date.AddHours(1),
            PackedByUserId = status is SalesOrderStatuses.Packed or
                SalesOrderStatuses.Delivered
                ? createdBy.UserId
                : null,
            PackedAtUtc = status is SalesOrderStatuses.Packed or
                SalesOrderStatuses.Delivered
                ? date.AddHours(3)
                : null,
            CreatedAtUtc = date
        };
        foreach (var product in products)
        {
            var price = prices
                .Where(item => item.ProductId == product.ProductId &&
                    item.EffectiveFromUtc <= date &&
                    (item.EffectiveToUtc == null || item.EffectiveToUtc > date))
                .OrderByDescending(item => item.EffectiveFromUtc)
                .First();
            order.Items.Add(new SalesOrderItem
            {
                ProductId = product.ProductId,
                ProductPriceId = price.ProductPriceId,
                ProductNameSnapshot = product.ProductName,
                ProductSizeSnapshot = product.Size,
                QuantityKg = quantity,
                UnitPricePerKg = price.SellingPrice,
                LineTotal = quantity * price.SellingPrice,
                Notes = Marker
            });
        }
        order.Subtotal = order.Items.Sum(item => item.LineTotal);
        order.TotalAmount = order.Subtotal;
        order.StatusHistory.Add(new OrderStatusHistory
        {
            NewStatus = status,
            ChangedAtUtc = date,
            ChangedByUserId = createdBy.UserId,
            Reason = Marker
        });
        return order;
    }

    private static Invoice Invoice(SalesOrder order, string number) => new()
    {
        InvoiceNumber = number,
        SalesOrderId = order.SalesOrderId,
        IssuedAtUtc = order.OrderDateUtc.AddHours(4),
        CustomerNameSnapshot = order.Customer.CustomerName,
        CustomerEmailSnapshot = order.Customer.Email,
        BillingAddressSnapshot = order.BillingAddressSnapshot,
        Subtotal = order.Subtotal,
        TaxAmount = order.TaxAmount,
        TotalAmount = order.TotalAmount,
        Status = InvoiceStatuses.Issued
    };

    private static FinancialPayment Payment(
        string number,
        Customer customer,
        Invoice invoice,
        decimal amount,
        User actor,
        DateTime date) => new()
        {
            PaymentNumber = number,
            CounterpartyType = "Customer",
            CustomerId = customer.CustomerId,
            InvoiceId = invoice.InvoiceId,
            Amount = amount,
            PaymentDateUtc = date,
            PaymentMethodCode = "EFT",
            Reference = Marker,
            Notes = Marker,
            Status = FinancialPaymentStatuses.Posted,
            CreatedByUserId = actor.UserId,
            PostedByUserId = actor.UserId,
            CreatedAtUtc = date,
            PostedAtUtc = date,
            CorrelationId = $"lecturer-payment-{number.ToLowerInvariant()}"
        };

    private static LecturerDatasetResult Failure(
        LecturerDatasetMode mode,
        string message) => new(
            false,
            mode.ToString(),
            Marker,
            [message],
            new Dictionary<string, int>());
}
