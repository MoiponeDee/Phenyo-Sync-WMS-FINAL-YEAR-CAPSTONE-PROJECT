﻿using System.Data;
using System.Globalization;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;

namespace PhenyoSyncAPI.Services;

public interface IGoogleOrderIntakeService
{
    Task<GoogleOrderSyncResultDto> SyncAsync(
        int actorUserId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<ExternalOrderSubmissionDto>> RecentAsync(
        int take,
        CancellationToken cancellationToken);
}

/// <summary>
/// Imports Google Form response rows into normal customer/order workflows.
/// Source response ids are persisted so repeated synchronisation is idempotent.
/// </summary>
public sealed class GoogleOrderIntakeService : IGoogleOrderIntakeService
{
    private const string Source = "GoogleForms";
    private readonly HttpClient _httpClient;
    private readonly PhenyoSyncDbContext _context;
    private readonly IOrderService _orders;
    private readonly IAuditService _audit;
    private readonly GoogleOrderIntakeOptions _options;

    public GoogleOrderIntakeService(
        HttpClient httpClient,
        PhenyoSyncDbContext context,
        IOrderService orders,
        IAuditService audit,
        IOptions<GoogleOrderIntakeOptions> options)
    {
        _httpClient = httpClient;
        _context = context;
        _orders = orders;
        _audit = audit;
        _options = options.Value;
    }

    public async Task<GoogleOrderSyncResultDto> SyncAsync(
        int actorUserId,
        CancellationToken cancellationToken)
    {
        // Validate key names/identifiers before sending any provider request.
        // Configuration values are read from configuration/User Secrets and
        // are never added to audit details or exception messages.
        ValidateConfiguration();
        await AuditSyncAsync(
            actorUserId,
            "Start manual Google Form synchronisation",
            "Manual Google Form response synchronisation started.",
            AuditActionTypes.Import,
            null,
            cancellationToken);
        var url =
            $"https://sheets.googleapis.com/v4/spreadsheets/{Uri.EscapeDataString(_options.SpreadsheetId.Trim())}/values/{Uri.EscapeDataString(_options.Range.Trim())}?majorDimension=ROWS";
        GoogleSheetValuesResponse response;
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("X-Goog-Api-Key", _options.ApiKey.Trim());
            using var providerResponse = await _httpClient.SendAsync(
                request,
                HttpCompletionOption.ResponseHeadersRead,
                cancellationToken);
            providerResponse.EnsureSuccessStatusCode();
            response = await providerResponse.Content
                .ReadFromJsonAsync<GoogleSheetValuesResponse>(
                    cancellationToken: cancellationToken)
                ?? new GoogleSheetValuesResponse();
        }
        catch (HttpRequestException exception)
        {
            await AuditSyncFailureAsync(
                actorUserId,
                "Fail Google Form synchronisation",
                "Google Sheets could not be read during manual synchronisation.",
                cancellationToken);
            throw new OrderManagementException(
                502,
                $"Google Sheets could not be read: {SafeProviderMessage(exception)}");
        }

        var rows = response.Values ?? [];
        if (rows.Count == 0)
            return new GoogleOrderSyncResultDto { SyncedAtUtc = DateTime.UtcNow };

        // Header aliases are normalised once so column order changes and the
        // approved contact/WhatsApp wording do not shift customer fields.
        var headers = BuildHeaderMap(rows[0]);
        RequireHeaders(headers);
        var products = await _context.Products
            .AsNoTracking()
            .Where(item => item.Status == ProductStatuses.Active)
            .Select(item => new
            {
                item.ProductId,
                item.QRCodeValue,
                item.ProductName,
                item.Size,
                ProductTypeName = item.ProductType == null
                    ? string.Empty
                    : item.ProductType.ProductTypeName,
                ProductCategoryName = item.ProductCategory == null
                    ? string.Empty
                    : item.ProductCategory.ProductCategoryName
            })
            .ToListAsync(cancellationToken);
        // Build exact canonical lookups from active master products. Ambiguous
        // names/codes are rejected; intake never silently creates a product.
        var productCodes = products
            .Where(item => !string.IsNullOrWhiteSpace(item.QRCodeValue))
            .GroupBy(item => NormalizeProductValue(item.QRCodeValue!))
            .ToDictionary(
                group => group.Key,
                group => group.Select(item => item.ProductId).ToArray(),
                StringComparer.Ordinal);
        var productDescriptions = products
            .SelectMany(item => ProductDescriptions(
                item.ProductId,
                item.ProductName,
                item.ProductTypeName,
                item.ProductCategoryName,
                item.Size))
            .GroupBy(item => item.Description, StringComparer.Ordinal)
            .ToDictionary(
                group => group.Key,
                group => group.Select(item => item.ProductId).Distinct().ToArray(),
                StringComparer.Ordinal);

        var result = new GoogleOrderSyncResultDto
        {
            RowsRead = Math.Max(0, rows.Count - 1),
            SyncedAtUtc = DateTime.UtcNow
        };
        foreach (var row in rows.Skip(1))
        {
            if (row.All(string.IsNullOrWhiteSpace))
                continue;
            var payloadHash = Hash(string.Join('\u001f', row));
            var externalKey = Cell(row, headers, "responseid").Trim();
            if (string.IsNullOrWhiteSpace(externalKey))
                externalKey = payloadHash;

            if (await _context.ExternalOrderSubmissions.AsNoTracking().AnyAsync(
                    item => item.Source == Source &&
                            item.ExternalSourceKey == externalKey,
                    cancellationToken))
            {
                result.SkippedAsDuplicate++;
                await AuditSyncAsync(
                    actorUserId,
                    "Ignore duplicate Google Form response",
                    "An already tracked Google Form response was ignored.",
                    AuditActionTypes.Import,
                    new Dictionary<string, object?>
                    {
                        ["result"] = "DuplicateIgnored"
                    },
                    cancellationToken);
                continue;
            }

            var parsed = await ParseAsync(
                row,
                headers,
                productCodes,
                productDescriptions,
                cancellationToken);
            if (parsed.Issues.Count > 0)
            {
                var attention = NewSubmission(
                    actorUserId,
                    externalKey,
                    payloadHash,
                    parsed.SubmittedAtUtc,
                    ExternalOrderSubmissionStatuses.NeedsAttention,
                    string.Join(" ", parsed.Issues));
                _context.ExternalOrderSubmissions.Add(attention);
                await _context.SaveChangesAsync(cancellationToken);
                result.NeedsAttention++;
                result.Submissions.Add(Map(attention, null));
                await AuditSyncAsync(
                    actorUserId,
                    "Flag Google Form response for attention",
                    "A Google Form response failed controlled business validation and was retained for review.",
                    AuditActionTypes.Import,
                    new Dictionary<string, object?>
                    {
                        ["externalOrderSubmissionId"] =
                            attention.ExternalOrderSubmissionId,
                        ["result"] = "NeedsAttention"
                    },
                    cancellationToken);
                continue;
            }

            await using var transaction = await _context.Database
                .BeginTransactionAsync(
                    IsolationLevel.Serializable,
                    cancellationToken);
            try
            {
                var submission = NewSubmission(
                    actorUserId,
                    externalKey,
                    payloadHash,
                    parsed.SubmittedAtUtc,
                    ExternalOrderSubmissionStatuses.Processing,
                    null);
                _context.ExternalOrderSubmissions.Add(submission);
                await _context.SaveChangesAsync(cancellationToken);

                var order = await _orders.CreateAsync(
                    parsed.Order!,
                    actorUserId,
                    null,
                    cancellationToken);
                submission.SalesOrderId = order.SalesOrderId;
                submission.Status = ExternalOrderSubmissionStatuses.Imported;
                await _context.SaveChangesAsync(cancellationToken);
                await _audit.RecordAsync(new AuditEvent
                {
                    ActionType = AuditActionTypes.Import,
                    SystemModule = AuditModules.OrderManagement,
                    OperationName = "Synchronise Google Form order",
                    Description =
                        "A Google Form response was converted into a Pending Validation sales order.",
                    EntityType = nameof(ExternalOrderSubmission),
                    EntityId = submission.ExternalOrderSubmissionId.ToString(),
                    EntityDisplay = order.OrderNumber,
                    UserId = actorUserId,
                    Success = true,
                    EventSource = AuditEventSources.BusinessEvent,
                    SafeDetails = new Dictionary<string, object?>
                    {
                        ["source"] = Source,
                        ["salesOrderId"] = order.SalesOrderId,
                        ["orderNumber"] = order.OrderNumber
                    }
                }, cancellationToken);
                await transaction.CommitAsync(cancellationToken);
                result.Imported++;
                result.Submissions.Add(Map(submission, order.OrderNumber));
            }
            catch (Exception exception)
            {
                await transaction.RollbackAsync(cancellationToken);
                _context.ChangeTracker.Clear();
                var failure = NewSubmission(
                    actorUserId,
                    externalKey,
                    payloadHash,
                    parsed.SubmittedAtUtc,
                    ExternalOrderSubmissionStatuses.Failed,
                    SafeBusinessMessage(exception));
                _context.ExternalOrderSubmissions.Add(failure);
                await _context.SaveChangesAsync(cancellationToken);
                result.Failed++;
                result.Submissions.Add(Map(failure, null));
                await AuditSyncFailureAsync(
                    actorUserId,
                    "Fail Google Form response import",
                    "A Google Form response could not be converted into an order.",
                    cancellationToken);
            }
        }

        return result;
    }

    private Task AuditSyncAsync(
        int actorUserId,
        string operation,
        string description,
        string actionType,
        IReadOnlyDictionary<string, object?>? details,
        CancellationToken cancellationToken) =>
        _audit.RecordAsync(new AuditEvent
        {
            ActionType = actionType,
            SystemModule = AuditModules.OrderManagement,
            OperationName = operation,
            Description = description,
            EntityType = nameof(ExternalOrderSubmission),
            UserId = actorUserId,
            Success = true,
            EventSource = AuditEventSources.BusinessEvent,
            SafeDetails = details
        }, cancellationToken);

    private Task AuditSyncFailureAsync(
        int actorUserId,
        string operation,
        string description,
        CancellationToken cancellationToken) =>
        _audit.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.Import,
            SystemModule = AuditModules.OrderManagement,
            OperationName = operation,
            Description = description,
            EntityType = nameof(ExternalOrderSubmission),
            UserId = actorUserId,
            Success = false,
            EventSource = AuditEventSources.BusinessEvent
        }, cancellationToken);

    public async Task<IReadOnlyList<ExternalOrderSubmissionDto>> RecentAsync(
        int take,
        CancellationToken cancellationToken) =>
        await _context.ExternalOrderSubmissions
            .AsNoTracking()
            .OrderByDescending(item => item.ImportedAtUtc)
            .ThenByDescending(item => item.ExternalOrderSubmissionId)
            .Take(Math.Clamp(take, 1, 100))
            .Select(item => new ExternalOrderSubmissionDto
            {
                ExternalOrderSubmissionId = item.ExternalOrderSubmissionId,
                Source = item.Source,
                ExternalSourceKey = item.ExternalSourceKey,
                Status = item.Status,
                SafeIssueSummary = item.SafeIssueSummary,
                SubmittedAtUtc = item.SubmittedAtUtc,
                ImportedAtUtc = item.ImportedAtUtc,
                SalesOrderId = item.SalesOrderId,
                OrderNumber = item.SalesOrder != null
                    ? item.SalesOrder.OrderNumber
                    : null
            })
            .ToListAsync(cancellationToken);

    private async Task<ParsedRow> ParseAsync(
        IReadOnlyList<string> row,
        IReadOnlyDictionary<string, int> headers,
        IReadOnlyDictionary<string, int[]> productCodes,
        IReadOnlyDictionary<string, int[]> productDescriptions,
        CancellationToken cancellationToken)
    {
        var issues = new List<string>();
        var email = CellAny(row, headers, "emailaddress", "customeremail").Trim();
        var customerNumber = CellAny(
            row,
            headers,
            "customeraccountreferencenumber",
            "customeraccountreference").Trim();
        var phone = CellAny(row, headers, "phonewhatsappnumber", "phonenumber").Trim();
        var activeCustomers = await _context.Customers
            .AsNoTracking()
            .Where(item => item.Status == CustomerStatuses.Active)
            .ToListAsync(cancellationToken);
        var customer = ResolveCustomer(
            activeCustomers,
            email,
            customerNumber,
            phone,
            issues);
        if (customer is null)
            issues.Add(
                "The email address, customer account/reference number, or phone number does not uniquely match an active customer.");

        var items = new List<OrderItemRequestDto>();
        for (var index = 1; index <= 6; index++)
        {
            var submittedProduct = index == 1
                ? CellAny(row, headers, "productitem1", "product").Trim()
                : Cell(row, headers, $"productitem{index}").Trim();
            var submittedQuantity = index == 1
                ? CellAny(row, headers, "quantity1", "quantity").Trim()
                : Cell(row, headers, $"quantity{index}").Trim();
            if (string.IsNullOrWhiteSpace(submittedProduct) &&
                string.IsNullOrWhiteSpace(submittedQuantity))
                continue;
            if (string.IsNullOrWhiteSpace(submittedProduct))
            {
                issues.Add($"Product / Item {index} is required when Quantity {index} is supplied.");
                continue;
            }
            if (string.IsNullOrWhiteSpace(submittedQuantity))
            {
                issues.Add($"Quantity {index} is required for '{submittedProduct}'.");
                continue;
            }

            var key = NormalizeProductValue(submittedProduct);
            int[]? matches = null;
            if (productCodes.TryGetValue(key, out var codeMatches))
                matches = codeMatches;
            else if (productDescriptions.TryGetValue(key, out var descriptionMatches))
                matches = descriptionMatches;
            if (matches is null || matches.Length != 1)
            {
                issues.Add(
                    $"Product / Item {index} '{submittedProduct}' is unknown or ambiguous.");
                continue;
            }
            if (!decimal.TryParse(
                    submittedQuantity,
                    NumberStyles.Number,
                    CultureInfo.InvariantCulture,
                    out var quantity) ||
                quantity <= 0)
            {
                issues.Add($"Quantity {index} '{submittedQuantity}' is invalid.");
                continue;
            }
            items.Add(new OrderItemRequestDto
            {
                ProductId = matches[0],
                QuantityUnits = quantity
            });
        }
        if (items.Count == 0)
            issues.Add("At least one valid Product / Item and Quantity pair is required.");

        var additionalProducts = Cell(
            row,
            headers,
            "additionalproductsquantities").Trim();
        if (!string.IsNullOrWhiteSpace(additionalProducts))
            issues.Add(
                $"Additional Products / Quantities requires review: {Truncate(additionalProducts, 240)}");

        var fulfilment = CellAny(
            row,
            headers,
            "howwouldyouliketoreceiveyourorder",
            "fulfilment").Trim();
        var isCollection = fulfilment.Contains(
            "collection",
            StringComparison.OrdinalIgnoreCase);
        var isDelivery = fulfilment.Contains(
            "delivery",
            StringComparison.OrdinalIgnoreCase);
        if (!isCollection && !isDelivery)
            issues.Add("Select Delivery or Collection as the fulfilment method.");
        var deliveryAddress = Cell(row, headers, "deliveryaddress").Trim();
        deliveryAddress = string.IsNullOrWhiteSpace(deliveryAddress)
            ? customer?.DeliveryAddress ?? string.Empty
            : deliveryAddress;
        var billingAddress = customer?.BillingAddress ?? string.Empty;
        if (isCollection && string.IsNullOrWhiteSpace(deliveryAddress))
            deliveryAddress = "Collection";
        if (isDelivery && string.IsNullOrWhiteSpace(deliveryAddress))
            issues.Add("A delivery address is required for Delivery orders.");
        if (string.IsNullOrWhiteSpace(billingAddress))
            issues.Add("The matched customer requires a billing address before the order can be imported.");

        DateTime? requestedDelivery = null;
        var requestedText = CellAny(
            row,
            headers,
            "requesteddeliverycollectiondate",
            "requesteddate");
        if (!string.IsNullOrWhiteSpace(requestedText))
        {
            if (DateTimeOffset.TryParse(
                    requestedText,
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.AssumeLocal,
                    out var parsedDelivery))
                requestedDelivery = parsedDelivery.UtcDateTime;
            else
                issues.Add("The requested delivery date is invalid.");
        }

        DateTime? submittedAt = null;
        var timestamp = Cell(row, headers, "timestamp");
        if (DateTimeOffset.TryParse(
                timestamp,
                CultureInfo.InvariantCulture,
                DateTimeStyles.AssumeLocal,
                out var parsedTimestamp))
            submittedAt = parsedTimestamp.UtcDateTime;

        return new ParsedRow(
            issues,
            submittedAt,
            issues.Count == 0
                ? new CreateSalesOrderDto
                {
                    CustomerId = customer!.CustomerId,
                    RequestedDeliveryDateUtc = requestedDelivery,
                    DeliveryAddress = deliveryAddress,
                    BillingAddress = billingAddress,
                    Notes = BuildOrderNotes(row, headers, additionalProducts),
                    Items = items
                }
                : null);
    }

    private void ValidateConfiguration()
    {
        if (string.IsNullOrWhiteSpace(_options.SpreadsheetId) ||
            string.IsNullOrWhiteSpace(_options.Range) ||
            string.IsNullOrWhiteSpace(_options.ApiKey))
            throw new OrderManagementException(
                503,
                "Google order intake is not configured. Configure SpreadsheetId, Range, and ApiKey outside source control.");
    }

    private static Dictionary<string, int> BuildHeaderMap(
        IReadOnlyList<string> headers) =>
        headers
            .Select((header, index) => new { Header = NormalizeHeader(header), index })
            .Where(item => !string.IsNullOrEmpty(item.Header))
            .GroupBy(item => item.Header)
            .ToDictionary(group => group.Key, group => group.First().index);

    private static void RequireHeaders(IReadOnlyDictionary<string, int> headers)
    {
        var missing = new List<string>();
        if (!HasAny(headers, "emailaddress", "customeremail") &&
            !HasAny(headers, "customeraccountreferencenumber", "customeraccountreference"))
            missing.Add("Customer Email or Customer Account Reference");
        if (!HasAny(headers, "howwouldyouliketoreceiveyourorder", "fulfilment"))
            missing.Add("Fulfilment");
        if (!HasAny(headers, "productitem1", "product"))
            missing.Add("Product");
        if (!HasAny(headers, "quantity1", "quantity"))
            missing.Add("Quantity");
        if (missing.Count > 0)
            throw new OrderManagementException(
                400,
                $"The Google Sheet is missing required columns: {string.Join(", ", missing)}.");
    }

    private static string Cell(
        IReadOnlyList<string> row,
        IReadOnlyDictionary<string, int> headers,
        string header) =>
        headers.TryGetValue(header, out var index) && index < row.Count
            ? row[index] ?? string.Empty
            : string.Empty;

    private static string CellAny(
        IReadOnlyList<string> row,
        IReadOnlyDictionary<string, int> headers,
        params string[] names)
    {
        foreach (var name in names)
        {
            if (headers.TryGetValue(name, out var index) && index < row.Count)
                return row[index] ?? string.Empty;
        }
        return string.Empty;
    }

    private static bool HasAny(
        IReadOnlyDictionary<string, int> headers,
        params string[] names) => names.Any(headers.ContainsKey);

    private static string NormalizeHeader(string value) =>
        new(value
            .Where(char.IsLetterOrDigit)
            .Select(char.ToLowerInvariant)
            .ToArray());

    private static string NormalizeProductValue(string value) =>
        new(value
            .Normalize(NormalizationForm.FormKC)
            .Where(char.IsLetterOrDigit)
            .Select(char.ToLowerInvariant)
            .ToArray());

    private static IEnumerable<ProductDescription> ProductDescriptions(
        int productId,
        string productName,
        string productTypeName,
        string productCategoryName,
        string size)
    {
        var candidates = new[]
        {
            productName,
            $"{productName} {size}",
            $"{productName} {productTypeName}",
            $"{productName} {productTypeName} {size}",
            $"{productCategoryName} {productName}",
            $"{productCategoryName} {productName} {productTypeName} {size}"
        };
        return candidates
            .Select(NormalizeProductValue)
            .Where(value => value.Length > 0)
            .Distinct(StringComparer.Ordinal)
            .Select(value => new ProductDescription(productId, value));
    }

    private static Customer? ResolveCustomer(
        IReadOnlyCollection<Customer> customers,
        string email,
        string customerNumber,
        string phone,
        ICollection<string> issues)
    {
        var resolved = new List<Customer>();
        if (!string.IsNullOrWhiteSpace(email))
        {
            var normalizedEmail = email.Trim().ToUpperInvariant();
            var matches = customers
                .Where(item => item.NormalizedEmail == normalizedEmail)
                .ToArray();
            if (matches.Length == 1)
                resolved.Add(matches[0]);
            else if (matches.Length > 1)
                issues.Add("The supplied email address matches more than one active customer.");
        }
        if (!string.IsNullOrWhiteSpace(customerNumber))
        {
            var matches = customers
                .Where(item => string.Equals(
                    item.CustomerNumber,
                    customerNumber,
                    StringComparison.OrdinalIgnoreCase))
                .ToArray();
            if (matches.Length == 1)
                resolved.Add(matches[0]);
            else if (matches.Length > 1)
                issues.Add("The customer account/reference number is ambiguous.");
        }
        if (resolved.Count == 0 && !string.IsNullOrWhiteSpace(phone))
        {
            var normalizedPhone = NormalizePhone(phone);
            if (normalizedPhone.Length >= 9)
            {
                var matches = customers
                    .Where(item => NormalizePhone(item.PhoneNumber ?? string.Empty) ==
                                   normalizedPhone)
                    .ToArray();
                if (matches.Length == 1)
                    resolved.Add(matches[0]);
                else if (matches.Length > 1)
                    issues.Add("The supplied phone number matches more than one active customer.");
            }
        }
        var distinct = resolved.DistinctBy(item => item.CustomerId).ToArray();
        if (distinct.Length > 1)
        {
            issues.Add("The supplied customer identifiers refer to different customers.");
            return null;
        }
        return distinct.SingleOrDefault();
    }

    private static string NormalizePhone(string value)
    {
        var digits = new string(value.Where(char.IsDigit).ToArray());
        if (digits.StartsWith("27", StringComparison.Ordinal) && digits.Length == 11)
            return $"0{digits[2..]}";
        return digits;
    }

    private static string BuildOrderNotes(
        IReadOnlyList<string> row,
        IReadOnlyDictionary<string, int> headers,
        string additionalProducts)
    {
        var lines = new[]
        {
            ("External business/customer", Cell(row, headers, "businesscustomername").Trim()),
            ("Order contact", Cell(row, headers, "contactperson").Trim()),
            ("Contact phone / WhatsApp", CellAny(row, headers, "phonewhatsappnumber", "phonenumber").Trim()),
            ("Fulfilment", CellAny(row, headers, "howwouldyouliketoreceiveyourorder", "fulfilment").Trim()),
            ("Purchase order / customer reference", Cell(row, headers, "purchaseordercustomerreference").Trim()),
            ("Special instructions", CellAny(row, headers, "specialinstructionsnotes", "notes").Trim()),
            (
                "WhatsApp contact preference",
                CellAny(
                    row,
                    headers,
                    "maywecontactyouonwhatsappaboutthisorder",
                    "whatsapppreference",
                    "contactwhatsapppreference").Trim()),
            ("Order request confirmation", Cell(row, headers, "orderrequestconfirmation").Trim()),
            ("Additional products / quantities", additionalProducts)
        };
        return string.Join(
            Environment.NewLine,
            lines.Where(item => !string.IsNullOrWhiteSpace(item.Item2))
                .Select(item => $"{item.Item1}: {item.Item2}"));
    }

    private static string Truncate(string value, int length) =>
        value.Length <= length ? value : $"{value[..length]}â€¦";

    private static string Hash(string value) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));

    private static ExternalOrderSubmission NewSubmission(
        int actorUserId,
        string externalKey,
        string payloadHash,
        DateTime? submittedAtUtc,
        string status,
        string? issue) =>
        new()
        {
            Source = Source,
            ExternalSourceKey = externalKey[..Math.Min(externalKey.Length, 180)],
            PayloadHash = payloadHash,
            Status = status,
            SafeIssueSummary = issue?[..Math.Min(issue.Length, 1000)],
            SubmittedAtUtc = submittedAtUtc,
            ImportedAtUtc = DateTime.UtcNow,
            ImportedByUserId = actorUserId,
            CorrelationId = Guid.NewGuid().ToString("N")
        };

    private static ExternalOrderSubmissionDto Map(
        ExternalOrderSubmission item,
        string? orderNumber) =>
        new()
        {
            ExternalOrderSubmissionId = item.ExternalOrderSubmissionId,
            Source = item.Source,
            ExternalSourceKey = item.ExternalSourceKey,
            Status = item.Status,
            SafeIssueSummary = item.SafeIssueSummary,
            SubmittedAtUtc = item.SubmittedAtUtc,
            ImportedAtUtc = item.ImportedAtUtc,
            SalesOrderId = item.SalesOrderId,
            OrderNumber = orderNumber
        };

    private static string SafeBusinessMessage(Exception exception) =>
        exception switch
        {
            OrderManagementException order => order.Message,
            PricingException pricing => pricing.Message,
            _ => "The response could not be imported. Review the server log and correct the source data."
        };

    private static string SafeProviderMessage(HttpRequestException exception) =>
        exception.StatusCode.HasValue
            ? $"provider returned HTTP {(int)exception.StatusCode.Value}."
            : "the provider connection failed.";

    private sealed class GoogleSheetValuesResponse
    {
        public List<List<string>> Values { get; set; } = [];
    }

    private sealed record ParsedRow(
        List<string> Issues,
        DateTime? SubmittedAtUtc,
        CreateSalesOrderDto? Order);

    private sealed record ProductDescription(int ProductId, string Description);
}
