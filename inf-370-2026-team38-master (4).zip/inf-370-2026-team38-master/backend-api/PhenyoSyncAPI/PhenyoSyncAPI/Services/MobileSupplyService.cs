using System.Data;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public interface IMobileBuyingListService
{
    Task<BuyingListDto> CreateAsync(
        CreateBuyingListRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<BuyingListDto>> ListAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task<BuyingListDto> GetAsync(
        int id,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task<BuyingListDto> UpdateItemAsync(
        int id,
        int itemId,
        UpdateBuyingListItemRequest request,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task<BuyingListDto> AddItemAsync(
        int id,
        AddBuyingListItemRequest request,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task<BuyingListDto> SubmitAsync(
        int id,
        ReasonRequest request,
        int userId,
        bool viewAll,
        string correlationId,
        CancellationToken cancellationToken);

    Task<BuyingListDto> UploadDocketAsync(
        int id,
        IFormFile file,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);
}

public interface IMobileStockReceiptService
{
    Task<StockReceiptDto> CreateAsync(
        CreateStockReceiptRequest request,
        int userId,
        string correlationId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<StockReceiptDto>> ListAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task<StockReceiptDto> GetAsync(
        int id,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task<StockReceiptDto> AddItemAsync(
        int id,
        StockReceiptItemRequest request,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken);

    Task<StockReceiptDto> SubmitAsync(
        int id,
        ReasonRequest request,
        int userId,
        bool viewAll,
        string correlationId,
        CancellationToken cancellationToken);
}

/// <summary>Executes assigned buyer line actions with idempotent mobile operation keys.</summary>
public sealed class MobileBuyingListService : IMobileBuyingListService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IOperationalNotificationService _notifications;
    private readonly ISystemSettingProvider _settings;
    private readonly IProtectedFileStorage _files;
    private readonly IAuditService _audit;

    public MobileBuyingListService(
        PhenyoSyncDbContext context,
        IOperationalNotificationService notifications,
        ISystemSettingProvider settings,
        IProtectedFileStorage files,
        IAuditService audit)
    {
        _context = context;
        _notifications = notifications;
        _settings = settings;
        _files = files;
        _audit = audit;
    }

    public async Task<BuyingListDto> CreateAsync(
        CreateBuyingListRequest request,
        int actorUserId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        if (request.Items.Count == 0)
            throw new PhaseCException(400, "Add at least one buying-list item.");
        if (request.Items.Any(item =>
                item.ProductId.HasValue == item.RawStockItemId.HasValue))
            throw new PhaseCException(
                400,
                "Each buying-list line must reference either Raw Stock or a legacy Product.");
        if (request.Items
            .GroupBy(ItemKey)
            .Any(group => group.Count() > 1))
            throw new PhaseCException(
                400,
                "An item may appear only once in a buying list.");
        var buyerIsEligible = await _context.Users.AsNoTracking()
            .AnyAsync(
                item =>
                    item.UserId == request.AssignedBuyerUserId &&
                    item.Status == ProductStatuses.Active &&
                    item.Role != null &&
                    item.Role.IsActive &&
                    item.Role.RolePermissions.Any(mapping =>
                        mapping.Permission != null &&
                        mapping.Permission.IsActive &&
                        mapping.Permission.PermissionCode ==
                        Permissions.Mobile.BuyingListView),
                cancellationToken);
        if (!buyerIsEligible)
            throw new PhaseCException(
                400,
                "The assigned user does not have Buying List mobile access.");
        var productIds = request.Items
            .Where(item => item.ProductId.HasValue)
            .Select(item => item.ProductId!.Value)
            .ToArray();
        var activeProductIds = await _context.Products.AsNoTracking()
            .Where(item =>
                productIds.Contains(item.ProductId) &&
                item.Status == ProductStatuses.Active)
            .Select(item => item.ProductId)
            .ToListAsync(cancellationToken);
        var missingProducts = productIds.Except(activeProductIds).ToArray();
        if (missingProducts.Length > 0)
            throw new PhaseCException(
                400,
                "One or more buying-list products are unavailable.",
                new { productIds = missingProducts });
        var rawStockItemIds = request.Items
            .Where(item => item.RawStockItemId.HasValue)
            .Select(item => item.RawStockItemId!.Value)
            .ToArray();
        var activeRawStockIds = await _context.RawStockItems.AsNoTracking()
            .Where(item =>
                rawStockItemIds.Contains(item.RawStockItemId) &&
                item.IsActive)
            .Select(item => item.RawStockItemId)
            .ToListAsync(cancellationToken);
        var missingRawStock = rawStockItemIds.Except(activeRawStockIds).ToArray();
        if (missingRawStock.Length > 0)
            throw new PhaseCException(
                400,
                "One or more Raw Stock items are unavailable.",
                new { rawStockItemIds = missingRawStock });

        var list = new BuyerProcurement
        {
            ReferenceNumber =
                $"BL-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..6]}"
                    .ToUpperInvariant(),
            BuyingDateUtc = request.BuyingDateUtc == default
                ? DateTime.UtcNow.Date
                : request.BuyingDateUtc.ToUniversalTime(),
            AssignedBuyerUserId = request.AssignedBuyerUserId,
            Priority = BuyingListPriorities.Standard,
            Status = BuyingListStatuses.Draft,
            Notes = Clean(request.Notes),
            CreatedByUserId = actorUserId,
            CreatedAtUtc = DateTime.UtcNow,
            UpdatedAtUtc = DateTime.UtcNow,
            CorrelationId = correlationId,
            Items = request.Items.Select(item => new BuyerProcurementItem
            {
                ProductId = item.ProductId,
                RawStockItemId = item.RawStockItemId,
                RecommendedQuantity = item.RecommendedQuantity,
                RequiredQuantity = item.RequiredQuantity,
                UnitOfMeasure = item.UnitOfMeasure.Trim(),
                Status = BuyingItemStatuses.Pending,
                Priority = BuyingListPriorities.Standard,
                UpdatedAtUtc = DateTime.UtcNow
            }).ToList()
        };
        _context.BuyerProcurements.Add(list);
        await _context.SaveChangesAsync(cancellationToken);
        return await GetAsync(
            list.BuyerProcurementId,
            actorUserId,
            true,
            cancellationToken);
    }

    public async Task<IReadOnlyList<BuyingListDto>> ListAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        var query = Query();
        if (!viewAll)
            query = query.Where(item =>
                item.AssignedBuyerUserId == userId &&
                BuyingListStatuses.BuyerVisible.Contains(item.Status));
        var items = await query.OrderByDescending(item => item.BuyingDateUtc)
            .Take(50)
            .ToListAsync(cancellationToken);
        return items.Select(Map).ToList();
    }

    public async Task<BuyingListDto> GetAsync(
        int id,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken) =>
        Map(await LoadAsync(id, userId, viewAll, cancellationToken));

    // Item updates verify assignment, lifecycle state and retry identity before changing buyer progress.
    public async Task<BuyingListDto> UpdateItemAsync(
        int id,
        int itemId,
        UpdateBuyingListItemRequest request,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        if (!BuyingItemStatuses.All.Contains(request.Status))
            throw new PhaseCException(400, "The buying-item status is invalid.");
        var list = await LoadAsync(id, userId, viewAll, cancellationToken, false);
        EnsureBuyerEditable(list);
        var item = list.Items.SingleOrDefault(
                candidate => candidate.BuyerProcurementItemId == itemId)
            ?? throw new PhaseCException(404, "Buying-list item not found.");
        var operationHash = MobileSecurity.Hash(request.OperationId);
        if (await IsDuplicateAsync(
                userId,
                "UpdateBuyingItem",
                operationHash,
                cancellationToken))
            return await GetAsync(id, userId, viewAll, cancellationToken);
        if (request.Status is BuyingItemStatuses.Purchased or BuyingItemStatuses.Substituted)
        {
            if (request.ActualQuantity is null or <= 0)
                throw new PhaseCException(
                    400,
                    "Enter the actual quantity purchased.");
            if (request.ActualUnitPrice is null or < 0)
                throw new PhaseCException(400, "Enter the actual unit price.");
            if (!request.SupplierId.HasValue)
                throw new PhaseCException(
                    400,
                    "Select the external Supplier or market agency.");
        }
        if (request.Status == BuyingItemStatuses.Unavailable &&
            string.IsNullOrWhiteSpace(request.UnavailableReason))
            throw new PhaseCException(
                400,
                "Explain why the item was unavailable.");
        if (request.Status == BuyingItemStatuses.Substituted)
        {
            if (!request.SubstituteRawStockItemId.HasValue)
                throw new PhaseCException(400, "Select the substitute Raw Stock item.");
            if (request.SubstituteRawStockItemId == item.RawStockItemId)
                throw new PhaseCException(
                    400,
                    "The substitute must differ from the requested item.");
            if (string.IsNullOrWhiteSpace(request.SubstituteNotes))
                throw new PhaseCException(400, "Explain the substitution.");
            if (!await _context.RawStockItems.AsNoTracking().AnyAsync(
                    candidate =>
                        candidate.RawStockItemId ==
                        request.SubstituteRawStockItemId.Value &&
                        candidate.IsActive,
                    cancellationToken))
                throw new PhaseCException(400, "The substitute Raw Stock item is invalid.");
        }
        if (request.SupplierId.HasValue &&
            !await _context.Suppliers.AsNoTracking().AnyAsync(
                supplier =>
                    supplier.SupplierId == request.SupplierId &&
                    supplier.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(400, "The selected supplier is invalid.");

        item.Status = request.Status;
        item.ActualQuantity = request.ActualQuantity;
        item.ActualUnitPrice = request.ActualUnitPrice;
        item.SupplierId = request.SupplierId;
        item.BuyerNotes = Clean(request.BuyerNotes);
        item.UnavailableReason = Clean(request.UnavailableReason, 500);
        item.SubstituteRawStockItemId =
            request.Status == BuyingItemStatuses.Substituted
                ? request.SubstituteRawStockItemId
                : null;
        item.SubstituteNotes =
            request.Status == BuyingItemStatuses.Substituted
                ? Clean(request.SubstituteNotes, 500)
                : null;
        item.UpdatedAtUtc = DateTime.UtcNow;
        list.Status = BuyingListStatuses.InProgress;
        list.UpdatedAtUtc = DateTime.UtcNow;
        _context.MobileIdempotencyRecords.Add(
            MobileSecurity.Receipt(
                userId,
                "UpdateBuyingItem",
                request.OperationId,
                $"{id}|{itemId}|{request.Status}|{request.ActualQuantity}",
                "{\"updated\":true}"));
        await _context.SaveChangesAsync(cancellationToken);
        await RecordBuyerAuditAsync(
            AuditActionTypes.Update,
            "Update Buying List purchase item",
            list,
            userId,
            new Dictionary<string, object?>
            {
                ["lineId"] = itemId,
                ["status"] = item.Status,
                ["actualQuantity"] = item.ActualQuantity,
                ["actualUnitPrice"] = item.ActualUnitPrice,
                ["supplierId"] = item.SupplierId
            },
            cancellationToken);
        return await GetAsync(id, userId, viewAll, cancellationToken);
    }

    public async Task<BuyingListDto> AddItemAsync(
        int id,
        AddBuyingListItemRequest request,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        var list = await LoadAsync(id, userId, viewAll, cancellationToken, false);
        EnsureBuyerEditable(list);
        if (request.ProductId.HasValue == request.RawStockItemId.HasValue)
            throw new PhaseCException(
                400,
                "Select either Raw Stock or a legacy Product.");
        if (list.Items.Any(item =>
                item.ProductId == request.ProductId &&
                item.RawStockItemId == request.RawStockItemId))
            throw new PhaseCException(
                409,
                "This item is already on the buying list.");
        if (request.ProductId.HasValue &&
            !await _context.Products.AsNoTracking().AnyAsync(
                item =>
                    item.ProductId == request.ProductId.Value &&
                    item.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(404, "Product not found.");
        if (request.RawStockItemId.HasValue &&
            !await _context.RawStockItems.AsNoTracking().AnyAsync(
                item =>
                    item.RawStockItemId == request.RawStockItemId.Value &&
                    item.IsActive,
                cancellationToken))
            throw new PhaseCException(404, "Raw Stock item not found.");
        if (!await _context.Suppliers.AsNoTracking().AnyAsync(
                item =>
                    item.SupplierId == request.SupplierId &&
                    item.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(400, "Select an active Supplier.");
        list.Items.Add(new BuyerProcurementItem
        {
            ProductId = request.ProductId,
            RawStockItemId = request.RawStockItemId,
            RequiredQuantity = request.RequiredQuantity,
            RecommendedQuantity = request.RequiredQuantity,
            ActualQuantity = request.ActualQuantity,
            ActualUnitPrice = request.ActualUnitPrice,
            SupplierId = request.SupplierId,
            UnitOfMeasure = request.UnitOfMeasure.Trim(),
            Status = BuyingItemStatuses.Purchased,
            IsPromotionalItem = true,
            Priority = BuyingListPriorities.Standard,
            BuyerNotes = Clean(request.Notes),
            UpdatedAtUtc = DateTime.UtcNow
        });
        list.Status = BuyingListStatuses.InProgress;
        list.UpdatedAtUtc = DateTime.UtcNow;
        _context.MobileIdempotencyRecords.Add(
            MobileSecurity.Receipt(
                userId,
                "AddBuyingItem",
                request.OperationId,
                $"{id}|{request.ProductId}|{request.RawStockItemId}|" +
                $"{request.RequiredQuantity}",
                "{\"added\":true}"));
        await _context.SaveChangesAsync(cancellationToken);
        await RecordBuyerAuditAsync(
            AuditActionTypes.Create,
            "Add promotional Buying List item",
            list,
            userId,
            new Dictionary<string, object?>
            {
                ["rawStockItemId"] = request.RawStockItemId,
                ["productId"] = request.ProductId,
                ["actualQuantity"] = request.ActualQuantity,
                ["supplierId"] = request.SupplierId
            },
            cancellationToken);
        return await GetAsync(id, userId, viewAll, cancellationToken);
    }

    // Submission freezes the actionable list only after every required line is completed and evidenced.
    public async Task<BuyingListDto> SubmitAsync(
        int id,
        ReasonRequest request,
        int userId,
        bool viewAll,
        string correlationId,
        CancellationToken cancellationToken)
    {
        var list = await LoadAsync(id, userId, viewAll, cancellationToken, false);
        if (list.Status == BuyingListStatuses.Submitted)
            return await GetAsync(id, userId, viewAll, cancellationToken);
        EnsureBuyerEditable(list);
        if (list.Items.Count == 0 ||
            list.Items.Any(item => item.Status == BuyingItemStatuses.Pending))
            throw new PhaseCException(
                409,
                "Resolve every buying-list item before submission.");
        var operationHash = MobileSecurity.Hash(request.OperationId);
        if (await IsDuplicateAsync(
                userId,
                "SubmitBuyingList",
                operationHash,
                cancellationToken))
            return await GetAsync(id, userId, viewAll, cancellationToken);
        list.Status = BuyingListStatuses.Submitted;
        list.SubmittedAtUtc = DateTime.UtcNow;
        list.UpdatedAtUtc = DateTime.UtcNow;
        list.Notes = string.Join(
            Environment.NewLine,
            new[] { list.Notes, request.Reason.Trim() }
                .Where(value => !string.IsNullOrWhiteSpace(value)));
        _context.MobileIdempotencyRecords.Add(
            MobileSecurity.Receipt(
                userId,
                "SubmitBuyingList",
                request.OperationId,
                $"{id}|{list.RowVersion}|{request.Reason}",
                "{\"submitted\":true}"));
        await _context.SaveChangesAsync(cancellationToken);
        await RecordBuyerAuditAsync(
            AuditActionTypes.StatusChange,
            "Submit Buying List",
            list,
            userId,
            new Dictionary<string, object?>
            {
                ["status"] = list.Status,
                ["lineCount"] = list.Items.Count,
                ["reason"] = request.Reason.Trim()
            },
            cancellationToken);
        await _notifications.PublishToRolesAsync(
            "BuyingListSubmitted",
            "Success",
            "Buying list submitted",
            "A completed buying list is ready for stock receiving.",
            [RoleCodes.BusinessManager, RoleCodes.OperationsManager],
            nameof(BuyerProcurement),
            id.ToString(),
            $"/buying-list/{id}",
            userId,
            correlationId,
            cancellationToken);
        return await GetAsync(id, userId, viewAll, cancellationToken);
    }

    public async Task<BuyingListDto> UploadDocketAsync(
        int id,
        IFormFile file,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        var list = await LoadAsync(
            id,
            userId,
            viewAll,
            cancellationToken,
            false);
        EnsureBuyerEditable(list);
        var maximumMb = await _settings.GetIntAsync(
            SystemSettingKeys.MobileDocketMaximumMb,
            cancellationToken);
        StoredImageResult stored;
        try
        {
            stored = await _files.SaveDocketImageAsync(
                file,
                userId,
                maximumMb,
                cancellationToken);
        }
        catch (ProtectedFileException exception)
        {
            throw new PhaseCException(400, exception.Message);
        }

        try
        {
            _context.StoredFiles.Add(stored.Image);
            list.DocketStoredFile = stored.Image;
            list.UpdatedAtUtc = DateTime.UtcNow;
            await _context.SaveChangesAsync(cancellationToken);
            await _files.DeletePhysicalAsync(
                stored.Thumbnail,
                CancellationToken.None);
        }
        catch
        {
            await _files.DeletePhysicalAsync(
                stored.Image,
                CancellationToken.None);
            await _files.DeletePhysicalAsync(
                stored.Thumbnail,
                CancellationToken.None);
            throw;
        }

        await _audit.RecordAsync(
            new AuditEvent
            {
                ActionType = AuditActionTypes.Update,
                SystemModule = AuditModules.BuyingList,
                OperationName = "Upload Buying List docket",
                Description =
                    $"A docket was uploaded for {list.ReferenceNumber}.",
                EntityType = nameof(BuyerProcurement),
                EntityId = list.BuyerProcurementId.ToString(),
                EntityDisplay = list.ReferenceNumber,
                UserId = userId,
                SafeDetails = new Dictionary<string, object?>
                {
                    ["storedFileId"] = stored.Image.StoredFileId,
                    ["contentType"] = stored.Image.ContentType,
                    ["sizeBytes"] = stored.Image.SizeBytes
                }
            },
            cancellationToken);
        return await GetAsync(id, userId, viewAll, cancellationToken);
    }

    private IQueryable<BuyerProcurement> Query() =>
        _context.BuyerProcurements.AsNoTracking()
            // The projection needs several independent collections (items,
            // product stock and Raw Stock balances). A single joined query
            // multiplies those rows and stalls the live buyer endpoint once
            // WMS_DB contains realistic stock history.
            .AsSplitQuery()
            .Include(item => item.AssignedBuyerUser)
            .Include(item => item.Items).ThenInclude(item => item.Product)
                .ThenInclude(product => product!.ProductCategory)
            .Include(item => item.Items).ThenInclude(item => item.Product)
                .ThenInclude(product => product!.Stocks)
            .Include(item => item.Items).ThenInclude(item => item.RawStockItem)
                .ThenInclude(rawStock => rawStock!.Balances)
            .Include(item => item.Items).ThenInclude(item => item.Supplier)
            .Include(item => item.Items).ThenInclude(item => item.PreferredSupplier)
            .Include(item => item.Items).ThenInclude(item => item.SubstituteRawStockItem);

    private async Task<BuyerProcurement> LoadAsync(
        int id,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken,
        bool noTracking = true)
    {
        var query = noTracking ? Query() : _context.BuyerProcurements
            .AsSplitQuery()
            .Include(item => item.AssignedBuyerUser)
            .Include(item => item.Items).ThenInclude(item => item.Product)
                .ThenInclude(product => product!.ProductCategory)
            .Include(item => item.Items).ThenInclude(item => item.Product)
                .ThenInclude(product => product!.Stocks)
            .Include(item => item.Items).ThenInclude(item => item.RawStockItem)
                .ThenInclude(rawStock => rawStock!.Balances)
            .Include(item => item.Items).ThenInclude(item => item.Supplier)
            .Include(item => item.Items).ThenInclude(item => item.PreferredSupplier)
            .Include(item => item.Items).ThenInclude(item => item.SubstituteRawStockItem);
        var list = await query.SingleOrDefaultAsync(
                item => item.BuyerProcurementId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Buying list not found.");
        if (!viewAll && list.AssignedBuyerUserId != userId)
            throw new PhaseCException(403, "This buying list is not assigned to you.");
        return list;
    }

    private static void EnsureBuyerEditable(BuyerProcurement list)
    {
        if (list.Status is not (
                BuyingListStatuses.Open or
                BuyingListStatuses.InProgress))
            throw new PhaseCException(
                409,
                "This Buying List is not open for buyer changes.");
    }

    private Task<bool> IsDuplicateAsync(
        int userId,
        string operationType,
        string operationHash,
        CancellationToken cancellationToken) =>
        _context.MobileIdempotencyRecords.AsNoTracking().AnyAsync(
            item =>
                item.UserId == userId &&
                item.OperationType == operationType &&
                item.OperationKeyHash == operationHash,
            cancellationToken);

    private Task RecordBuyerAuditAsync(
        string action,
        string operation,
        BuyerProcurement list,
        int userId,
        IReadOnlyDictionary<string, object?> details,
        CancellationToken cancellationToken) =>
        _audit.RecordAsync(
            new AuditEvent
            {
                ActionType = action,
                SystemModule = AuditModules.BuyingList,
                OperationName = operation,
                Description = $"{operation}: {list.ReferenceNumber}.",
                EntityType = nameof(BuyerProcurement),
                EntityId = list.BuyerProcurementId.ToString(),
                EntityDisplay = list.ReferenceNumber,
                UserId = userId,
                SafeDetails = details
            },
            cancellationToken);

    private static BuyingListDto Map(BuyerProcurement list) =>
        new()
        {
            BuyerProcurementId = list.BuyerProcurementId,
            ReferenceNumber = list.ReferenceNumber,
            Title = list.Title,
            BuyingDateUtc = list.BuyingDateUtc,
            AssignedBuyerUserId = list.AssignedBuyerUserId,
            BuyerName = list.AssignedBuyerUser is null
                ? "Unassigned"
                : $"{list.AssignedBuyerUser.FirstName} " +
                  $"{list.AssignedBuyerUser.LastName}".Trim(),
            Priority = list.Priority,
            Status = list.Status,
            Notes = list.Notes,
            PublishedAtUtc = list.PublishedAtUtc,
            SubmittedAtUtc = list.SubmittedAtUtc,
            DocketStoredFileId = list.DocketStoredFileId,
            RowVersion = list.RowVersion is null
                ? string.Empty
                : Convert.ToBase64String(list.RowVersion),
            Items = list.Items.OrderBy(item =>
                    item.RawStockItem != null
                        ? item.RawStockItem.ItemName
                        : item.Product!.ProductName)
                .Select(item => new BuyingListItemDto
                {
                    BuyerProcurementItemId = item.BuyerProcurementItemId,
                    ProductId = item.ProductId,
                    RawStockItemId = item.RawStockItemId,
                    ProductCode = item.RawStockItem != null
                        ? item.RawStockItem.ItemCode
                        : item.Product!.QRCodeValue ??
                          $"PRODUCT-{item.ProductId!.Value:D6}",
                    ProductName = item.RawStockItem?.ItemName ??
                        item.Product!.ProductName,
                    CategoryName = item.RawStockItem?.CategoryCode ??
                        item.Product!.ProductCategory?.ProductCategoryName ??
                        string.Empty,
                    CurrentStockKg = item.RawStockItem != null
                        ? item.RawStockItem.Balances.Sum(
                            balance => balance.QuantityOnHand)
                        : item.Product!.Stocks.Sum(
                            stock => stock.QuantityAvailableKg),
                    RecommendedQuantity = item.RecommendedQuantity,
                    RequiredQuantity = item.RequiredQuantity,
                    ActualQuantity = item.ActualQuantity,
                    ActualUnitPrice = item.ActualUnitPrice,
                    ReceivedQuantity = item.ReceivedQuantity,
                    OutstandingQuantity = Math.Max(
                        0,
                        (item.ActualQuantity ?? 0) - item.ReceivedQuantity),
                    SupplierId = item.SupplierId,
                    SupplierName = item.Supplier?.SupplierName,
                    PreferredSupplierId = item.PreferredSupplierId,
                    PreferredSupplierName = item.PreferredSupplier?.SupplierName,
                    UnitOfMeasure = item.UnitOfMeasure,
                    Priority = item.Priority,
                    Status = item.Status,
                    IsPromotionalItem = item.IsPromotionalItem,
                    ManagementNotes = item.ManagementNotes,
                    BuyerNotes = item.BuyerNotes,
                    UnavailableReason = item.UnavailableReason,
                    SubstituteRawStockItemId = item.SubstituteRawStockItemId,
                    SubstituteItemName = item.SubstituteRawStockItem?.ItemName,
                    SubstituteNotes = item.SubstituteNotes,
                    RowVersion = item.RowVersion is null
                        ? string.Empty
                        : Convert.ToBase64String(item.RowVersion)
                })
                .ToList()
        };

    private static string ItemKey(CreateBuyingListItemRequest item) =>
        item.RawStockItemId.HasValue
            ? $"RAW:{item.RawStockItemId.Value}"
            : $"PRODUCT:{item.ProductId!.Value}";

    private static string? Clean(string? value, int maximum = 1000)
    {
        var cleaned = value?.Trim();
        if (string.IsNullOrWhiteSpace(cleaned)) return null;
        return cleaned.Length <= maximum ? cleaned : cleaned[..maximum];
    }
}

/// <summary>Captures mobile finished-stock receipts and posts their batch and ledger effects atomically.</summary>
public sealed class MobileStockReceiptService : IMobileStockReceiptService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IOperationalNotificationService _notifications;

    public MobileStockReceiptService(
        PhenyoSyncDbContext context,
        IOperationalNotificationService notifications)
    {
        _context = context;
        _notifications = notifications;
    }

    public async Task<StockReceiptDto> CreateAsync(
        CreateStockReceiptRequest request,
        int userId,
        string correlationId,
        CancellationToken cancellationToken)
    {
        if (!await _context.Suppliers.AsNoTracking().AnyAsync(
                item =>
                    item.SupplierId == request.SupplierId &&
                    item.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(400, "The supplier is invalid or inactive.");
        if (!await _context.WarehouseSections.AsNoTracking().AnyAsync(
                item =>
                    item.SectionId == request.WarehouseSectionId &&
                    item.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(
                400,
                "The warehouse section is invalid or inactive.");
        if (request.SupplierOrderId.HasValue &&
            !await _context.SupplierOrders.AsNoTracking().AnyAsync(
                item =>
                    item.SupplierOrderId == request.SupplierOrderId &&
                    item.SupplierId == request.SupplierId,
                cancellationToken))
            throw new PhaseCException(
                400,
                "The supplier order does not match the selected supplier.");

        var receipt = new StockReceipt
        {
            SupplierId = request.SupplierId,
            SupplierOrderId = request.SupplierOrderId,
            WarehouseSectionId = request.WarehouseSectionId,
            ReceivedByUserId = userId,
            ReceiptNumber =
                $"GRN-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid():N}"[..29]
                    .ToUpperInvariant(),
            SupplierDocketNumber = Clean(request.SupplierDocketNumber, 100),
            PurchaseDateUtc = request.PurchaseDateUtc == default
                ? DateTime.UtcNow
                : request.PurchaseDateUtc.ToUniversalTime(),
            Status = MobileOperationStatuses.Draft,
            Notes = Clean(request.Notes),
            CreatedAtUtc = DateTime.UtcNow,
            CorrelationId = correlationId
        };
        _context.StockReceipts.Add(receipt);
        await _context.SaveChangesAsync(cancellationToken);
        return await GetAsync(
            receipt.StockReceiptId,
            userId,
            true,
            cancellationToken);
    }

    public async Task<IReadOnlyList<StockReceiptDto>> ListAsync(
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        var query = Query();
        if (!viewAll) query = query.Where(item => item.ReceivedByUserId == userId);
        var items = await query.OrderByDescending(item => item.CreatedAtUtc)
            .Take(50)
            .ToListAsync(cancellationToken);
        return items.Select(Map).ToList();
    }

    public async Task<StockReceiptDto> GetAsync(
        int id,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken) =>
        Map(await LoadAsync(id, userId, viewAll, cancellationToken));

    // The backend resolves a real product/batch and never trusts client-calculated stock effects.
    public async Task<StockReceiptDto> AddItemAsync(
        int id,
        StockReceiptItemRequest request,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken)
    {
        if (!request.UnitCost.HasValue || request.UnitCost.Value <= 0)
            throw new PhaseCException(
                400,
                "A positive unit cost is required for received stock.");
        if (request.AcceptedQuantityKg + request.RejectedQuantityKg !=
            request.QuantityReceivedKg)
            throw new PhaseCException(
                400,
                "Accepted and rejected quantities must equal the received quantity.");
        if (request.BestBeforeAtUtc <= request.ReceivedAtUtc)
            throw new PhaseCException(
                400,
                "The best-before date must be after the received date.");
        var receipt = await LoadAsync(
            id,
            userId,
            viewAll,
            cancellationToken,
            false);
        EnsureDraft(receipt);
        if (!await _context.Products.AsNoTracking().AnyAsync(
                item =>
                    item.ProductId == request.ProductId &&
                    item.Status == ProductStatuses.Active,
                cancellationToken))
            throw new PhaseCException(404, "Product not found.");
        if (receipt.Items.Any(item =>
                item.ProductId == request.ProductId &&
                string.Equals(
                    item.BatchReference,
                    request.BatchReference,
                    StringComparison.OrdinalIgnoreCase)))
            throw new PhaseCException(
                409,
                "This Product and Batch reference is already on the receipt.");

        receipt.Items.Add(new StockReceiptItem
        {
            ProductId = request.ProductId,
            QuantityReceivedKg = request.QuantityReceivedKg,
            AcceptedQuantityKg = request.AcceptedQuantityKg,
            RejectedQuantityKg = request.RejectedQuantityKg,
            UnitCost = request.UnitCost,
            ContainerCount = request.ContainerCount,
            ContainerType = Clean(request.ContainerType, 30),
            BatchReference = Clean(request.BatchReference, 80),
            ReceivedAtUtc = request.ReceivedAtUtc.ToUniversalTime(),
            BestBeforeAtUtc = request.BestBeforeAtUtc.ToUniversalTime(),
            QualityStatus = request.QualityStatus.Trim(),
            Notes = Clean(request.Notes)
        });
        await _context.SaveChangesAsync(cancellationToken);
        return await GetAsync(id, userId, viewAll, cancellationToken);
    }

    // Posting creates batches, balances and movements together, then returns the committed document.
    public async Task<StockReceiptDto> SubmitAsync(
        int id,
        ReasonRequest request,
        int userId,
        bool viewAll,
        string correlationId,
        CancellationToken cancellationToken)
    {
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);
        var receipt = await LoadAsync(
            id,
            userId,
            viewAll,
            cancellationToken,
            false);
        if (receipt.Status == MobileOperationStatuses.Completed)
            return Map(receipt);
        EnsureDraft(receipt);
        if (receipt.Items.Count == 0)
            throw new PhaseCException(
                409,
                "Add at least one receipt line before submission.");
        var now = DateTime.UtcNow;
        foreach (var item in receipt.Items)
        {
            if (item.AcceptedQuantityKg <= 0) continue;
            var batchCode =
                $"RCV-{item.ProductId:D6}-{now:yyyyMMddHHmmss}-{Guid.NewGuid():N}"[..43]
                    .ToUpperInvariant();
            var batch = new ProductBatch
            {
                ProductId = item.ProductId,
                SectionId = receipt.WarehouseSectionId,
                BatchCode = batchCode,
                QRCodeValue = $"PHENYOSYNC:BATCH:{batchCode}",
                QuantityProducedKg = item.AcceptedQuantityKg,
                QuantityRemainingKg = item.AcceptedQuantityKg,
                PackedAtUtc = item.ReceivedAtUtc,
                OriginalExpiryAtUtc = item.BestBeforeAtUtc,
                EffectiveExpiryAtUtc = item.BestBeforeAtUtc,
                Status = ProductBatchStatuses.Available,
                CreatedAtUtc = now
            };
            _context.ProductBatches.Add(batch);
            var stock = await _context.Stocks.SingleOrDefaultAsync(
                candidate =>
                    candidate.ProductId == item.ProductId &&
                    candidate.SectionId == receipt.WarehouseSectionId,
                cancellationToken);
            if (stock is null)
            {
                stock = new Stock
                {
                    ProductId = item.ProductId,
                    SectionId = receipt.WarehouseSectionId,
                    QuantityAvailableKg = 0,
                    ReorderLevelKg = 0
                };
                _context.Stocks.Add(stock);
            }
            stock.QuantityAvailableKg += item.AcceptedQuantityKg;
            stock.InventoryStatus = ProductBatchStatuses.Available;
            await _context.SaveChangesAsync(cancellationToken);
            item.ProductBatchId = batch.ProductBatchId;
            _context.StockMovements.Add(new StockMovement
            {
                ProductId = item.ProductId,
                ProductBatchId = batch.ProductBatchId,
                SectionId = receipt.WarehouseSectionId,
                MovementType = StockMovementTypes.Increase,
                QuantityKg = item.AcceptedQuantityKg,
                OccurredAtUtc = now,
                CreatedByUserId = userId,
                Reason = $"Stock receipt {receipt.ReceiptNumber}: {request.Reason.Trim()}"
            });
        }
        receipt.Status = MobileOperationStatuses.Completed;
        receipt.SubmittedAtUtc = now;
        await _context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);
        await _notifications.PublishToRolesAsync(
            "StockReceiptCompleted",
            "Success",
            "Bulk stock receipt completed",
            $"{receipt.ReceiptNumber} was received and stock movements were recorded.",
            [RoleCodes.WarehouseManager, RoleCodes.BusinessManager],
            nameof(StockReceipt),
            receipt.StockReceiptId.ToString(),
            $"/stock-receipts/{receipt.StockReceiptId}",
            userId,
            correlationId,
            cancellationToken);
        return await GetAsync(id, userId, viewAll, cancellationToken);
    }

    private IQueryable<StockReceipt> Query() =>
        _context.StockReceipts.AsNoTracking()
            .Include(item => item.Supplier)
            .Include(item => item.WarehouseSection)
            .Include(item => item.ReceivedByUser)
            .Include(item => item.Items).ThenInclude(item => item.Product);

    private async Task<StockReceipt> LoadAsync(
        int id,
        int userId,
        bool viewAll,
        CancellationToken cancellationToken,
        bool noTracking = true)
    {
        var query = noTracking ? Query() : _context.StockReceipts
            .Include(item => item.Supplier)
            .Include(item => item.WarehouseSection)
            .Include(item => item.ReceivedByUser)
            .Include(item => item.Items).ThenInclude(item => item.Product);
        var receipt = await query.SingleOrDefaultAsync(
                item => item.StockReceiptId == id,
                cancellationToken)
            ?? throw new PhaseCException(404, "Stock receipt not found.");
        if (!viewAll && receipt.ReceivedByUserId != userId)
            throw new PhaseCException(403, "This stock receipt is not yours.");
        return receipt;
    }

    private static void EnsureDraft(StockReceipt receipt)
    {
        if (receipt.Status != MobileOperationStatuses.Draft)
            throw new PhaseCException(409, "A submitted stock receipt is read-only.");
    }

    private static StockReceiptDto Map(StockReceipt item) =>
        new()
        {
            StockReceiptId = item.StockReceiptId,
            ReceiptNumber = item.ReceiptNumber,
            SupplierName = item.Supplier.SupplierName,
            WarehouseSection = item.WarehouseSection.SectionName,
            ReceiverName =
                $"{item.ReceivedByUser.FirstName} {item.ReceivedByUser.LastName}".Trim(),
            Status = item.Status,
            PurchaseDateUtc = item.PurchaseDateUtc,
            SubmittedAtUtc = item.SubmittedAtUtc,
            CorrelationId = item.CorrelationId,
            RowVersion = item.RowVersion is null
                ? string.Empty
                : Convert.ToBase64String(item.RowVersion),
            Items = item.Items.Select(line => new StockReceiptLineDto
            {
                StockReceiptItemId = line.StockReceiptItemId,
                ProductId = line.ProductId,
                ProductName = line.Product.ProductName,
                QuantityReceivedKg = line.QuantityReceivedKg,
                AcceptedQuantityKg = line.AcceptedQuantityKg,
                RejectedQuantityKg = line.RejectedQuantityKg,
                UnitCost = line.UnitCost,
                BatchReference = line.BatchReference,
                BestBeforeAtUtc = line.BestBeforeAtUtc,
                QualityStatus = line.QualityStatus
            }).ToList()
        };

    private static string? Clean(string? value, int maximum = 1000)
    {
        var cleaned = value?.Trim();
        if (string.IsNullOrWhiteSpace(cleaned)) return null;
        return cleaned.Length <= maximum ? cleaned : cleaned[..maximum];
    }
}
