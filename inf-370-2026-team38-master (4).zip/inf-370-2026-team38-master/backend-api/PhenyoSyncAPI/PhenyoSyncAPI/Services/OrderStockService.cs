using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Configuration;

namespace PhenyoSyncAPI.Services;

/// <summary>
/// Calculates FEFO finished-stock allocation and owns active order reservations.
/// Commercial approval and warehouse availability are separate decisions: an
/// approved shortage remains approved and visible until stock can be allocated.
/// </summary>
public sealed class OrderStockService : IOrderStockService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly OrderManagementOptions _options;
    private readonly ISystemSettingProvider? _settings;

    public OrderStockService(
        PhenyoSyncDbContext context,
        IOptions<OrderManagementOptions> options,
        ISystemSettingProvider? settings = null)
    {
        _context = context;
        _options = options.Value;
        _settings = settings;
    }

    public async Task<ValidateOrderResponseDto> ValidateAndReserveAsync(
        int orderId,
        int userId,
        CancellationToken cancellationToken) =>
        await ValidateAndReserveInternalAsync(
            orderId,
            userId,
            requireCommercialApproval: false,
            cancellationToken);

    public async Task<ValidateOrderResponseDto> ValidateApprovedAndReserveAsync(
        int orderId,
        int userId,
        CancellationToken cancellationToken) =>
        await ValidateAndReserveInternalAsync(
            orderId,
            userId,
            requireCommercialApproval: true,
            cancellationToken);

    private async Task<ValidateOrderResponseDto> ValidateAndReserveInternalAsync(
        int orderId,
        int userId,
        bool requireCommercialApproval,
        CancellationToken cancellationToken)
    {
        // Serializable isolation prevents two orders from allocating the same
        // remaining batch quantity at the same time.
        await using var transaction = await _context.Database.BeginTransactionAsync(
            IsolationLevel.Serializable,
            cancellationToken);

        var order = await LoadOrderForStockAsync(orderId, cancellationToken);
        if (requireCommercialApproval &&
            order.Status != SalesOrderStatuses.Approved)
        {
            throw new OrderManagementException(
                409,
                "Commercial approval is required before warehouse stock readiness can be assessed.");
        }

        if (order.Status is SalesOrderStatuses.Packed or SalesOrderStatuses.OutForDelivery or
            SalesOrderStatuses.Delivered or SalesOrderStatuses.Cancelled or SalesOrderStatuses.Packing)
            throw new OrderManagementException(409, $"An order in {order.Status} status cannot be validated.");

        await ReleaseActiveReservationsAsync(order, cancellationToken);
        // Rebuild from current batches so expired, consumed or separately
        // reserved stock is never carried forward as available.
        await _context.SaveChangesAsync(cancellationToken);

        var allocation = await BuildAllocationsAsync(order, cancellationToken);
        var previousStatus = order.Status;
        var now = DateTime.UtcNow;

        if (allocation.Shortages.Count > 0)
        {
            // A finished-stock shortage is operational information, not a reason
            // to reverse a completed commercial approval.
            var commerciallyApproved = previousStatus == SalesOrderStatuses.Approved;
            order.Status = commerciallyApproved
                ? SalesOrderStatuses.Approved
                : SalesOrderStatuses.Rejected;
            order.ValidationStatus = commerciallyApproved
                ? OrderValidationStatuses.Approved
                : OrderValidationStatuses.Rejected;
            order.ValidationMessage = string.Join(" ", allocation.Shortages.Select(item =>
                $"{item.ProductName}: shortage {item.ShortageQuantityKg:0.##} kg."));
            order.ValidatedByUserId = userId;
            order.ValidatedAtUtc = now;
            order.UpdatedAtUtc = now;
            if (!commerciallyApproved)
                order.StatusHistory.Add(History(
                    order.SalesOrderId,
                    previousStatus,
                    order.Status,
                    userId,
                    order.ValidationMessage));
            await _context.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
            return new ValidateOrderResponseDto
            {
                Message = commerciallyApproved
                    ? "The order remains commercially approved, but the warehouse cannot mark it ready until the listed shortages are resolved."
                    : "Order rejected because available, non-expired stock is insufficient.",
                Approved = false,
                Shortages = allocation.Shortages
            };
        }

        _context.OrderStockReservations.AddRange(allocation.Reservations);
        order.Status = SalesOrderStatuses.Approved;
        order.ValidationStatus = OrderValidationStatuses.Approved;
        order.ValidationMessage = "All order details and batch stock were validated successfully.";
        order.ValidatedByUserId = userId;
        order.ValidatedAtUtc = now;
        order.UpdatedAtUtc = now;
        order.StatusHistory.Add(History(order.SalesOrderId, previousStatus, order.Status, userId, order.ValidationMessage));
        await _context.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);

        return new ValidateOrderResponseDto
        {
            Message = "Order approved and FEFO stock reservations created.",
            Approved = true,
            Reservations = await ReservationDtos(orderId, cancellationToken)
        };
    }

    public async Task EnsurePackableReservationsAsync(SalesOrder order, CancellationToken cancellationToken)
    {
        // Revalidate immediately before packing completion because stock or
        // expiry state may have changed after the original reservation.
        EnsureKnownFulfilmentWeights(order);
        var active = await _context.OrderStockReservations
            .Include(item => item.ProductBatch)
            .Where(item => item.SalesOrderId == order.SalesOrderId && item.Status == OrderReservationStatuses.Active)
            .ToListAsync(cancellationToken);
        var safetyPoint = await SafetyPointAsync(order, cancellationToken);
        var allActiveReservationQuantities = await _context.OrderStockReservations
            .AsNoTracking()
            .Where(item => item.Status == OrderReservationStatuses.Active)
            .Select(item => new { item.ProductBatchId, item.QuantityReservedKg })
            .ToListAsync(cancellationToken);
        var reservedByBatch = allActiveReservationQuantities
            .GroupBy(item => item.ProductBatchId)
            .ToDictionary(group => group.Key, group => group.Sum(item => item.QuantityReservedKg));

        var valid = active.Count > 0 && order.Items.Where(item => item.IsActive).All(item =>
                active.Where(reservation => reservation.SalesOrderItemId == item.SalesOrderItemId)
                    .Sum(reservation => reservation.QuantityReservedKg) == item.QuantityKg) &&
            active.All(item =>
                item.ProductBatch.Status == ProductBatchStatuses.Available &&
                item.ProductBatch.EffectiveExpiryAtUtc > safetyPoint &&
                item.ProductBatch.QuantityRemainingKg >= reservedByBatch.GetValueOrDefault(item.ProductBatchId));

        if (valid) return;

        // Release and rebuild as a controlled correction. Failure reports a
        // shortage instead of allowing scans against invalid stock.
        foreach (var reservation in active)
        {
            reservation.Status = OrderReservationStatuses.Released;
            reservation.ReleasedAtUtc = DateTime.UtcNow;
        }
        await _context.SaveChangesAsync(cancellationToken);
        var rebuilt = await BuildAllocationsAsync(order, cancellationToken);
        if (rebuilt.Shortages.Count > 0)
            throw new OrderManagementException(
                409,
                "Reserved stock is no longer packable and FEFO reallocation could not satisfy the order.",
                rebuilt.Shortages);
        _context.OrderStockReservations.AddRange(rebuilt.Reservations);
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task<bool> CanFullyAllocateAsync(
        SalesOrder order,
        CancellationToken cancellationToken)
    {
        if (order.Status is not (
                SalesOrderStatuses.Approved or
                SalesOrderStatuses.Confirmed or
                SalesOrderStatuses.Packing))
            return false;

        if (order.ValidationStatus != OrderValidationStatuses.Approved)
            return false;

        if (order.Items.Any(item => item.IsActive && !item.HasKnownFulfilmentWeight))
            return false;

        var allocation = await BuildAllocationsAsync(order, cancellationToken);
        return allocation.Shortages.Count == 0;
    }

    public Task ReleaseActiveReservationsAsync(SalesOrder order, CancellationToken cancellationToken)
    {
        foreach (var reservation in order.StockReservations.Where(item => item.Status == OrderReservationStatuses.Active))
        {
            reservation.Status = OrderReservationStatuses.Released;
            reservation.ReleasedAtUtc = DateTime.UtcNow;
        }
        return Task.CompletedTask;
    }

    public async Task<PackingListDto> GetPackingListAsync(int orderId, CancellationToken cancellationToken)
    {
        var order = await _context.SalesOrders.AsNoTracking()
            .Include(item => item.Customer)
            .Include(item => item.Items)
            .Include(item => item.PackingScans)
            .Include(item => item.StockReservations.Where(reservation =>
                reservation.Status == OrderReservationStatuses.Active ||
                reservation.Status == OrderReservationStatuses.Consumed))
                .ThenInclude(reservation => reservation.SalesOrderItem)
            .Include(item => item.StockReservations)
                .ThenInclude(reservation => reservation.ProductBatch)
                    .ThenInclude(batch => batch.WarehouseSection)
            .FirstOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
            ?? throw new OrderManagementException(404, "Sales order not found.");
        if (order.Status is not (
                SalesOrderStatuses.Approved or
                SalesOrderStatuses.Confirmed or
                SalesOrderStatuses.Packing or
                SalesOrderStatuses.Packed or
                SalesOrderStatuses.ReadyForDispatch))
            throw new OrderManagementException(409, "A packing list is not available for this order status.");

        var activeItems = order.Items.Where(item => item.IsActive).ToList();
        var productIds = activeItems.Select(item => item.ProductId).Distinct().ToList();
        var now = DateTime.UtcNow;
        var availableBatches = await _context.ProductBatches.AsNoTracking()
            .Where(batch =>
                productIds.Contains(batch.ProductId) &&
                batch.Status == ProductBatchStatuses.Available &&
                batch.QuantityRemainingKg > 0m &&
                batch.EffectiveExpiryAtUtc > now)
            .Select(batch => new { batch.ProductId, batch.QuantityRemainingKg })
            .ToListAsync(cancellationToken);
        var otherOrderReservations = await _context.OrderStockReservations.AsNoTracking()
            .Where(reservation =>
                productIds.Contains(reservation.ProductId) &&
                reservation.SalesOrderId != order.SalesOrderId &&
                reservation.Status == OrderReservationStatuses.Active)
            .Select(reservation => new { reservation.ProductId, reservation.QuantityReservedKg })
            .ToListAsync(cancellationToken);
        var availableByProduct = productIds.ToDictionary(
            productId => productId,
            productId => Math.Max(
                0m,
                availableBatches
                    .Where(batch => batch.ProductId == productId)
                    .Sum(batch => batch.QuantityRemainingKg) -
                otherOrderReservations
                    .Where(reservation => reservation.ProductId == productId)
                    .Sum(reservation => reservation.QuantityReservedKg)));

        return new PackingListDto
        {
            SalesOrderId = order.SalesOrderId,
            OrderNumber = order.OrderNumber,
            CustomerName = order.Customer.CustomerName,
            DeliveryAddress = order.DeliveryAddressSnapshot,
            RequestedDeliveryDateUtc = order.RequestedDeliveryDateUtc,
            Status = order.Status,
            Lines = activeItems.Select(item =>
            {
                var packed = order.PackingScans
                    .Where(scan =>
                        scan.SalesOrderItemId == item.SalesOrderItemId &&
                        scan.RemovedAtUtc == null)
                    .Sum(scan => scan.QuantityPackedKg);
                return new PackingWorkloadLineDto
                {
                    SalesOrderItemId = item.SalesOrderItemId,
                    ProductName = item.ProductNameSnapshot,
                    ProductSize = item.ProductSizeSnapshot,
                    OrderedQuantityUnits = item.QuantityUnits ?? item.QuantityKg,
                    SellingUnit = item.SellingUnitSnapshot ?? "kg",
                    RequiredQuantityKg = item.HasKnownFulfilmentWeight ? item.QuantityKg : null,
                    AvailableQuantityKg = availableByProduct.GetValueOrDefault(item.ProductId),
                    PackedQuantityKg = packed,
                    RemainingQuantityKg = item.HasKnownFulfilmentWeight
                        ? Math.Max(0m, item.QuantityKg - packed)
                        : null
                };
            }).ToList(),
            Allocations = order.StockReservations.OrderBy(item => item.SalesOrderItemId)
                .ThenBy(item => item.ProductBatch.EffectiveExpiryAtUtc)
                .Select(MapReservation).ToList()
        };
    }

    public async Task<List<SalesOrderSummaryDto>> GetPackingQueueAsync(
        string? searchTerm,
        CancellationToken cancellationToken)
    {
        IQueryable<SalesOrder> query = _context.SalesOrders.AsNoTracking()
            .Where(order =>
                order.ValidationStatus == OrderValidationStatuses.Approved &&
                (order.Status == SalesOrderStatuses.Approved ||
                 order.Status == SalesOrderStatuses.Confirmed ||
                 order.Status == SalesOrderStatuses.Packing))
            .Include(order => order.Customer)
            .Include(order => order.Items)
            .Include(order => order.Invoice);
        if (!string.IsNullOrWhiteSpace(searchTerm))
        {
            var term = searchTerm.Trim();
            query = query.Where(order => order.OrderNumber.Contains(term) || order.Customer.CustomerName.Contains(term));
        }
        var candidates = await query
            .OrderBy(order => order.RequestedDeliveryDateUtc ?? DateTime.MaxValue)
            .ThenBy(order => order.OrderDateUtc)
            .ToListAsync(cancellationToken);
        return candidates.Select(order => new SalesOrderSummaryDto
            {
                SalesOrderId = order.SalesOrderId,
                OrderNumber = order.OrderNumber,
                CustomerName = order.Customer.CustomerName,
                CustomerEmail = order.Customer.Email,
                OrderDateUtc = order.OrderDateUtc,
                RequestedDeliveryDateUtc = order.RequestedDeliveryDateUtc,
                Status = order.Status,
                ValidationStatus = order.ValidationStatus,
                ItemCount = order.Items.Count(item => item.IsActive),
                TotalAmount = order.TotalAmount,
                HasInvoice = order.Invoice != null,
                CanViewPackingList = true
            }).ToList();
    }

    private async Task<SalesOrder> LoadOrderForStockAsync(int orderId, CancellationToken cancellationToken) =>
        await _context.SalesOrders
            .Include(item => item.Items)
            .Include(item => item.StockReservations)
            .Include(item => item.StatusHistory)
            .FirstOrDefaultAsync(item => item.SalesOrderId == orderId, cancellationToken)
        ?? throw new OrderManagementException(404, "Sales order not found.");

    private async Task<AllocationBuildResult> BuildAllocationsAsync(
        SalesOrder order,
        CancellationToken cancellationToken)
    {
        var result = new AllocationBuildResult();
        var safetyPoint = await SafetyPointAsync(order, cancellationToken);
        var activeOrderItems = order.Items.Where(item => item.IsActive).ToList();
        EnsureKnownFulfilmentWeights(order);
        var productIds = activeOrderItems.Select(item => item.ProductId).Distinct().ToList();
        var batches = await _context.ProductBatches.AsNoTracking()
            .Where(batch => productIds.Contains(batch.ProductId) &&
                batch.Product.Status == ProductStatuses.Active &&
                batch.Status == ProductBatchStatuses.Available &&
                batch.QuantityRemainingKg > 0 &&
                batch.EffectiveExpiryAtUtc > safetyPoint)
            .OrderBy(batch => batch.EffectiveExpiryAtUtc)
            .ThenBy(batch => batch.ProductBatchId)
            .ToListAsync(cancellationToken);
        var stocks = await _context.Stocks.AsNoTracking()
            .Where(stock => productIds.Contains(stock.ProductId) && stock.QuantityAvailableKg > 0)
            .ToDictionaryAsync(stock => (stock.ProductId, stock.SectionId), cancellationToken);
        var reservedOtherRows = await _context.OrderStockReservations.AsNoTracking()
            .Where(item => item.Status == OrderReservationStatuses.Active &&
                item.SalesOrderId != order.SalesOrderId &&
                productIds.Contains(item.ProductId))
            .Select(item => new { item.ProductBatchId, item.StockId, item.QuantityReservedKg })
            .ToListAsync(cancellationToken);
        var reservedOther = reservedOtherRows
            .GroupBy(item => item.ProductBatchId)
            .ToDictionary(group => group.Key, group => group.Sum(item => item.QuantityReservedKg));
        var reservedOtherByStock = reservedOtherRows
            .GroupBy(item => item.StockId)
            .ToDictionary(group => group.Key, group => group.Sum(item => item.QuantityReservedKg));

        foreach (var item in activeOrderItems)
        {
            var remaining = item.QuantityKg;
            decimal availableTotal = 0;
            foreach (var batch in batches.Where(candidate => candidate.ProductId == item.ProductId))
            {
                if (!stocks.TryGetValue((batch.ProductId, batch.SectionId), out var stock)) continue;
                var availableInBatch = Math.Max(
                    0,
                    batch.QuantityRemainingKg - reservedOther.GetValueOrDefault(batch.ProductBatchId));
                var availableInAggregateStock = Math.Max(
                    0,
                    stock.QuantityAvailableKg - reservedOtherByStock.GetValueOrDefault(stock.StockId));
                var available = Math.Min(availableInBatch, availableInAggregateStock);
                availableTotal += available;
                if (remaining <= 0 || available <= 0) continue;
                var allocated = Math.Min(remaining, available);
                result.Reservations.Add(new OrderStockReservation
                {
                    SalesOrderId = order.SalesOrderId,
                    SalesOrderItemId = item.SalesOrderItemId,
                    ProductId = item.ProductId,
                    StockId = stock.StockId,
                    SectionId = batch.SectionId,
                    ProductBatchId = batch.ProductBatchId,
                    QuantityReservedKg = allocated,
                    Status = OrderReservationStatuses.Active,
                    ReservedAtUtc = DateTime.UtcNow
                });
                reservedOther[batch.ProductBatchId] = reservedOther.GetValueOrDefault(batch.ProductBatchId) + allocated;
                reservedOtherByStock[stock.StockId] = reservedOtherByStock.GetValueOrDefault(stock.StockId) + allocated;
                remaining -= allocated;
            }
            if (remaining > 0)
            {
                result.Shortages.Add(new OrderShortageDto
                {
                    ProductId = item.ProductId,
                    ProductName = item.ProductNameSnapshot,
                    RequestedQuantityKg = item.QuantityKg,
                    AvailableQuantityKg = Math.Min(item.QuantityKg, availableTotal),
                    ShortageQuantityKg = remaining
                });
            }
        }
        if (result.Shortages.Count > 0) result.Reservations.Clear();
        return result;
    }

    private static void EnsureKnownFulfilmentWeights(SalesOrder order)
    {
        var missing = order.Items.FirstOrDefault(item =>
            item.IsActive && !item.HasKnownFulfilmentWeight);
        if (missing is not null)
            throw new OrderManagementException(
                409,
                $"{missing.ProductNameSnapshot} has a valid sellable quantity, but its warehouse weight conversion is not configured. Update the product and resave the order before allocation or packing.");
    }

    private async Task<DateTime> SafetyPointAsync(
        SalesOrder order,
        CancellationToken cancellationToken)
    {
        var requested = order.RequestedDeliveryDateUtc ?? DateTime.UtcNow;
        var point = requested > DateTime.UtcNow ? requested : DateTime.UtcNow;
        var safetyHours = _settings is null
            ? _options.DeliverySafetyHours
            : await _settings.GetIntAsync(
                SystemSettingKeys.OrdersDeliverySafetyHours,
                cancellationToken);
        return point.AddHours(Math.Max(0, safetyHours));
    }

    private async Task<List<OrderReservationDto>> ReservationDtos(int orderId, CancellationToken cancellationToken)
    {
        var reservations = await _context.OrderStockReservations.AsNoTracking()
            .Where(item => item.SalesOrderId == orderId && item.Status == OrderReservationStatuses.Active)
            .Include(item => item.SalesOrderItem)
            .Include(item => item.ProductBatch).ThenInclude(batch => batch.WarehouseSection)
            .OrderBy(item => item.ProductBatch.EffectiveExpiryAtUtc)
            .ToListAsync(cancellationToken);
        return reservations.Select(MapReservation).ToList();
    }

    private static OrderReservationDto MapReservation(OrderStockReservation item) => new()
    {
        OrderStockReservationId = item.OrderStockReservationId,
        SalesOrderItemId = item.SalesOrderItemId,
        ProductBatchId = item.ProductBatchId,
        ProductName = item.SalesOrderItem.ProductNameSnapshot,
        ProductSize = item.SalesOrderItem.ProductSizeSnapshot,
        BatchCode = item.ProductBatch.BatchCode,
        BatchQrValue = item.ProductBatch.QRCodeValue,
        SectionId = item.SectionId,
        SectionName = item.ProductBatch.WarehouseSection.SectionName,
        QuantityReservedKg = item.QuantityReservedKg,
        PackedAtUtc = item.ProductBatch.PackedAtUtc,
        EffectiveExpiryAtUtc = item.ProductBatch.EffectiveExpiryAtUtc,
        Status = item.Status
    };

    private static OrderStatusHistory History(
        int orderId,
        string previous,
        string next,
        int userId,
        string? reason) => new()
    {
        SalesOrderId = orderId,
        PreviousStatus = previous,
        NewStatus = next,
        ChangedByUserId = userId,
        ChangedAtUtc = DateTime.UtcNow,
        Reason = reason
    };

    private sealed class AllocationBuildResult
    {
        public List<OrderStockReservation> Reservations { get; } = [];
        public List<OrderShortageDto> Shortages { get; } = [];
    }
}
