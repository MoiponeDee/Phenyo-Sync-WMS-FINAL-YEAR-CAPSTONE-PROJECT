using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Audit;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Services;

public sealed class AuditQueryException : Exception
{
    public AuditQueryException(int statusCode, string message) : base(message)
    {
        StatusCode = statusCode;
    }

    public int StatusCode { get; }
}

public interface IAuditLogQueryService
{
    Task<AuditLogPageDto> SearchAsync(
        AuditLogSearchDto filters,
        CancellationToken cancellationToken);

    Task<AuditLogDetailDto> GetAsync(
        long id,
        CancellationToken cancellationToken);

    Task<AuditLogMetadataDto> GetMetadataAsync(
        CancellationToken cancellationToken);
}

/// <summary>Provides permission-filtered, read-only audit search and export projections.</summary>
public sealed class AuditLogQueryService : IAuditLogQueryService
{
    private static readonly System.Linq.Expressions.Expression<
        Func<AuditLog, AuditLogListItemDto>> ListProjection =
        item => new AuditLogListItemDto
        {
            AuditLogId = item.AuditLogId,
            OccurredAtUtc = item.OccurredAtUtc,
            UserId = item.UserId,
            UserEmail = item.UserEmailSnapshot,
            UserDisplayName = item.UserDisplayNameSnapshot,
            UserRole = item.UserRoleSnapshot,
            ActorType = item.ActorType,
            ActionType = item.ActionType,
            SystemModule = item.SystemModule,
            OperationName = item.OperationName,
            EntityType = item.EntityType,
            EntityId = item.EntityId,
            EntityDisplay = item.EntityDisplay,
            Description = item.Description,
            Success = item.Success,
            CorrelationId = item.CorrelationId
        };

    private readonly PhenyoSyncDbContext _context;

    public AuditLogQueryService(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    // Apply all filters before paging so counts and exported review results use the same scope.
    public async Task<AuditLogPageDto> SearchAsync(
        AuditLogSearchDto filters,
        CancellationToken cancellationToken)
    {
        Validate(filters);
        var query = _context.AuditLogs.AsNoTracking().AsQueryable();

        if (filters.UserId.HasValue)
        {
            query = query.Where(item => item.UserId == filters.UserId);
        }

        var userSearch = Normalize(filters.UserSearch, 200);
        if (userSearch is not null)
        {
            query = query.Where(item =>
                (item.UserDisplayNameSnapshot != null &&
                 item.UserDisplayNameSnapshot.Contains(userSearch)) ||
                (item.UserEmailSnapshot != null &&
                 item.UserEmailSnapshot.Contains(userSearch)));
        }

        if (filters.DateFromUtc.HasValue)
        {
            var from = AsUtc(filters.DateFromUtc.Value);
            query = query.Where(item => item.OccurredAtUtc >= from);
        }

        if (filters.DateToUtc.HasValue)
        {
            var to = AsUtc(filters.DateToUtc.Value);
            query = query.Where(item => item.OccurredAtUtc <= to);
        }

        query = FilterExact(query, filters.ActionType, item => item.ActionType);
        query = FilterExact(query, filters.SystemModule, item => item.SystemModule);
        query = FilterExact(query, filters.OperationName, item => item.OperationName);
        query = FilterExact(query, filters.EntityType, item => item.EntityType!);
        query = FilterExact(query, filters.EntityId, item => item.EntityId!);
        query = FilterExact(query, filters.CorrelationId, item => item.CorrelationId);

        if (filters.Success.HasValue)
        {
            query = query.Where(item => item.Success == filters.Success.Value);
        }

        var searchTerm = Normalize(filters.SearchTerm, 200);
        if (searchTerm is not null)
        {
            query = query.Where(item =>
                item.Description.Contains(searchTerm) ||
                (item.EntityDisplay != null && item.EntityDisplay.Contains(searchTerm)) ||
                (item.EntityId != null && item.EntityId.Contains(searchTerm)));
        }

        var totalCount = await query.LongCountAsync(cancellationToken);
        var totalPages = totalCount == 0
            ? 0
            : (int)Math.Ceiling(totalCount / (double)filters.PageSize);
        var orderedQuery = query
            // AuditLogId is immutable and monotonic, so it preserves newest-first
            // paging while letting SQL Server use the clustered primary key instead
            // of sorting the complete live audit history before applying TOP/OFFSET.
            .OrderByDescending(item => item.AuditLogId);
        var pageQuery = filters.PageNumber == 1
            ? orderedQuery.Take(filters.PageSize)
            : orderedQuery
                .Skip((filters.PageNumber - 1) * filters.PageSize)
                .Take(filters.PageSize);
        var items = await pageQuery
            .Select(ListProjection)
            .ToListAsync(cancellationToken);

        return new AuditLogPageDto
        {
            Items = items,
            PageNumber = filters.PageNumber,
            PageSize = filters.PageSize,
            TotalCount = totalCount,
            TotalPages = totalPages,
            HasPreviousPage = filters.PageNumber > 1,
            HasNextPage = filters.PageNumber < totalPages
        };
    }

    // Detail access is a sensitive read and is itself captured as a business audit event.
    public async Task<AuditLogDetailDto> GetAsync(
        long id,
        CancellationToken cancellationToken)
    {
        if (id < 1)
        {
            throw new AuditQueryException(400, "Audit log ID must be greater than zero.");
        }

        var item = await _context.AuditLogs
            .AsNoTracking()
            .Where(log => log.AuditLogId == id)
            .Select(log => new AuditLogDetailDto
            {
                AuditLogId = log.AuditLogId,
                OccurredAtUtc = log.OccurredAtUtc,
                UserId = log.UserId,
                UserEmail = log.UserEmailSnapshot,
                UserDisplayName = log.UserDisplayNameSnapshot,
                UserRole = log.UserRoleSnapshot,
                ActorType = log.ActorType,
                ActionType = log.ActionType,
                SystemModule = log.SystemModule,
                OperationName = log.OperationName,
                EntityType = log.EntityType,
                EntityId = log.EntityId,
                EntityDisplay = log.EntityDisplay,
                Description = log.Description,
                Success = log.Success,
                CorrelationId = log.CorrelationId,
                BeforeValuesJson = log.BeforeValuesJson,
                AfterValuesJson = log.AfterValuesJson,
                ChangedFieldsJson = log.ChangedFieldsJson,
                FailureReason = log.FailureReason,
                RequestPath = log.RequestPath,
                HttpMethod = log.HttpMethod,
                IpAddress = log.IpAddress,
                UserAgent = log.UserAgent,
                EventSource = log.EventSource
            })
            .FirstOrDefaultAsync(cancellationToken)
            ?? throw new AuditQueryException(404, "Audit log record not found.");

        item.RelatedLogs = await _context.AuditLogs
            .AsNoTracking()
            .Where(log =>
                log.CorrelationId == item.CorrelationId &&
                log.AuditLogId != item.AuditLogId)
            .OrderBy(log => log.OccurredAtUtc)
            .ThenBy(log => log.AuditLogId)
            .Take(20)
            .Select(ListProjection)
            .ToListAsync(cancellationToken);

        return item;
    }

    public async Task<AuditLogMetadataDto> GetMetadataAsync(
        CancellationToken cancellationToken)
    {
        var storedActions = await _context.AuditLogs
            .AsNoTracking()
            .Select(item => item.ActionType)
            .Distinct()
            .ToListAsync(cancellationToken);
        var storedModules = await _context.AuditLogs
            .AsNoTracking()
            .Select(item => item.SystemModule)
            .Distinct()
            .ToListAsync(cancellationToken);
        var entityTypes = await _context.AuditLogs
            .AsNoTracking()
            .Where(item => item.EntityType != null)
            .Select(item => item.EntityType!)
            .Distinct()
            .OrderBy(item => item)
            .ToListAsync(cancellationToken);
        var users = await _context.Users
            .AsNoTracking()
            .OrderBy(item => item.FirstName)
            .ThenBy(item => item.LastName)
            .Select(item => new AuditUserOptionDto
            {
                UserId = item.UserId,
                DisplayName = item.FirstName + " " + item.LastName,
                Email = item.Email
            })
            .ToListAsync(cancellationToken);

        return new AuditLogMetadataDto
        {
            ActionTypes = AuditActionTypes.All
                .Concat(storedActions)
                .Distinct(StringComparer.Ordinal)
                .OrderBy(item => item)
                .ToList(),
            SystemModules = AuditModules.All
                .Concat(storedModules)
                .Distinct(StringComparer.Ordinal)
                .OrderBy(item => item)
                .ToList(),
            EntityTypes = entityTypes,
            Users = users
        };
    }

    private static IQueryable<AuditLog> FilterExact(
        IQueryable<AuditLog> query,
        string? value,
        System.Linq.Expressions.Expression<Func<AuditLog, string>> selector)
    {
        var normalized = Normalize(value, 160);
        return normalized is null
            ? query
            : query.Where(BuildEquality(selector, normalized));
    }

    private static System.Linq.Expressions.Expression<Func<AuditLog, bool>> BuildEquality(
        System.Linq.Expressions.Expression<Func<AuditLog, string>> selector,
        string value)
    {
        var body = System.Linq.Expressions.Expression.Equal(
            selector.Body,
            System.Linq.Expressions.Expression.Constant(value));
        return System.Linq.Expressions.Expression.Lambda<Func<AuditLog, bool>>(
            body,
            selector.Parameters);
    }

    private static string? Normalize(string? value, int maximumLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        var normalized = value.Trim();
        if (normalized.Length > maximumLength)
        {
            throw new AuditQueryException(
                400,
                $"A search value exceeds the maximum length of {maximumLength} characters.");
        }

        return normalized;
    }

    private static void Validate(AuditLogSearchDto filters)
    {
        if (filters.PageNumber < 1)
        {
            throw new AuditQueryException(400, "Page number must be at least 1.");
        }

        if (filters.PageSize is < 1 or > 100)
        {
            throw new AuditQueryException(400, "Page size must be between 1 and 100.");
        }

        if (filters.DateFromUtc.HasValue &&
            filters.DateToUtc.HasValue &&
            AsUtc(filters.DateFromUtc.Value) > AsUtc(filters.DateToUtc.Value))
        {
            throw new AuditQueryException(
                400,
                "The start date cannot be after the end date.");
        }

        var now = DateTime.UtcNow;
        if ((filters.DateFromUtc.HasValue &&
             AsUtc(filters.DateFromUtc.Value) > now) ||
            (filters.DateToUtc.HasValue &&
             AsUtc(filters.DateToUtc.Value) > now))
        {
            throw new AuditQueryException(
                400,
                "Audit searches cannot use future dates.");
        }
    }

    private static DateTime AsUtc(DateTime value) => value.Kind switch
    {
        DateTimeKind.Utc => value,
        DateTimeKind.Local => value.ToUniversalTime(),
        _ => DateTime.SpecifyKind(value, DateTimeKind.Utc)
    };
}
