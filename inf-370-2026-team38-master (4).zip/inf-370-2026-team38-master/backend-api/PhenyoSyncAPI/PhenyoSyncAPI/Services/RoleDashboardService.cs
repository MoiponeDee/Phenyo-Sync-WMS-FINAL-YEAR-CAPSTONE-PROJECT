using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Dashboard;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Services;

public interface IRoleDashboardService
{
    Task<RoleDashboardDto> GetAsync(
        int userId,
        string roleCode,
        DateTime? fromUtc,
        DateTime? toUtc,
        CancellationToken cancellationToken);
}

/// <summary>Builds dashboard cards and actions from the caller's effective backend permissions.</summary>
public sealed class RoleDashboardService : IRoleDashboardService
{
    private readonly PhenyoSyncDbContext _context;

    public RoleDashboardService(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    // Select presentation by normalized persisted role while card actions remain permission-filtered.
    public async Task<RoleDashboardDto> GetAsync(
        int userId,
        string roleCode,
        DateTime? fromUtc,
        DateTime? toUtc,
        CancellationToken cancellationToken)
    {
        var from = (fromUtc ?? DateTime.UtcNow.AddDays(-29)).ToUniversalTime();
        var to = (toUtc ?? DateTime.UtcNow).ToUniversalTime();
        if (from >= to || to - from > TimeSpan.FromDays(366))
            throw new PhaseCException(
                400,
                "Select a valid dashboard period of no more than 366 days.");

        return RoleCodes.Normalize(roleCode) switch
        {
            RoleCodes.Admin => await AdministratorAsync(from, to, cancellationToken),
            RoleCodes.BusinessManager => await BusinessManagerAsync(from, to, cancellationToken),
            RoleCodes.WarehouseManager => await WarehouseManagerAsync(from, to, cancellationToken),
            RoleCodes.OperationsManager => await OperationsManagerAsync(from, to, cancellationToken),
            RoleCodes.Packer => await PackerAsync(userId, from, to, cancellationToken),
            RoleCodes.Driver => await DriverAsync(userId, from, to, cancellationToken),
            RoleCodes.MarketBuyer => await MarketBuyerAsync(userId, from, to, cancellationToken),
            _ => Empty(roleCode, from, to)
        };
    }

    private async Task<RoleDashboardDto> AdministratorAsync(
        DateTime from,
        DateTime to,
        CancellationToken cancellationToken)
    {
        var orderStatusRows = await _context.SalesOrders.AsNoTracking()
            .GroupBy(item => item.Status)
            .Select(group => new
            {
                Label = group.Key,
                Count = group.Count()
            })
            .OrderByDescending(item => item.Count)
            .ToListAsync(cancellationToken);
        var orderStatus = orderStatusRows
            .Select(item => new RoleDashboardPointDto(
                item.Label,
                item.Count,
                item.Count))
            .ToList();
        var orderTrendRows = await _context.SalesOrders.AsNoTracking()
            .Where(item => item.OrderDateUtc >= from && item.OrderDateUtc <= to)
            .Select(item => item.OrderDateUtc)
            .ToListAsync(cancellationToken);
        var orderTrend = orderTrendRows
            .GroupBy(item => item.Date)
            .OrderBy(group => group.Key)
            .Select(group => new RoleDashboardPointDto(
                group.Key.ToString("yyyy-MM-dd"),
                group.Count(),
                group.Count()))
            .ToList();

        var awaitingDecision = await _context.SalesOrders.CountAsync(
            item => item.Status == SalesOrderStatuses.Submitted ||
                    item.Status == SalesOrderStatuses.LegacyPendingValidation,
            cancellationToken);
        var activeCustomers = await _context.Customers.CountAsync(
            item => item.Status == CustomerStatuses.Active,
            cancellationToken);
        var productsWithoutPrice = await ProductsWithoutPrice(cancellationToken);
        var activeUsers = await _context.Users.CountAsync(
            item => item.Status == "Active",
            cancellationToken);
        var openBuyingLists = await _context.BuyerProcurements.CountAsync(
            item => item.Status != BuyingListStatuses.Completed &&
                    item.Status != BuyingListStatuses.Cancelled,
            cancellationToken);
        var deliveriesAwaitingAssignment = await _context.Deliveries.CountAsync(
            item => item.Status == DeliveryStatuses.Scheduled && item.DriverId == null,
            cancellationToken);
        var recentActivity = await _context.AuditLogs.AsNoTracking()
            .Where(item => item.OccurredAtUtc >= from && item.OccurredAtUtc <= to)
            .OrderByDescending(item => item.OccurredAtUtc)
            .Take(5)
            .Select(item => new RoleDashboardActivityDto(
                item.AuditLogId,
                item.OccurredAtUtc,
                item.OperationName,
                item.SystemModule,
                item.EntityDisplay,
                item.UserDisplayNameSnapshot,
                item.Success))
            .ToListAsync(cancellationToken);

        return Dashboard(
            RoleCodes.Admin,
            "Administrator dashboard",
            "Prioritise customer orders, pricing, procurement and administration from live system data.",
            from,
            to,
            [
                Metric("Awaiting order decision", awaitingDecision,
                    "number", "Submitted customer orders requiring review.", "/order-management"),
                Metric("Active customers", activeCustomers,
                    "number", "Customer accounts available for new business.", "/customers"),
                Metric("Products without a current price", productsWithoutPrice,
                    "number", "Products requiring pricing attention.", "/pricing"),
                Metric("Active users", activeUsers,
                    "number", "Enabled user accounts.", "/manage-users")
            ],
            Chart("Customer orders by status", "Current order workflow position.", "number", orderStatus),
            Chart("Customer orders", "Orders created during the selected period.", "number", orderTrend),
            [
                Attention("Orders awaiting a decision", awaitingDecision,
                    "Review submitted customer orders.", "/order-management", "warning"),
                Attention("Products without a current price", productsWithoutPrice,
                    "Publish a valid price before customers order these products.", "/pricing", "critical"),
                Attention("Open buying lists", openBuyingLists,
                    "Keep procurement work moving.", "/buying-lists", "warning"),
                Attention("Deliveries awaiting assignment", deliveriesAwaitingAssignment,
                    "Assign a driver to scheduled delivery work.", "/deliveries", "critical")
            ],
            recentActivity);
    }

    private async Task<RoleDashboardDto> BusinessManagerAsync(
        DateTime from,
        DateTime to,
        CancellationToken cancellationToken)
    {
        var statusRows = await _context.SalesOrders.AsNoTracking()
            .GroupBy(item => item.Status)
            .Select(group => new
            {
                Label = group.Key,
                Count = group.Count()
            })
            .OrderByDescending(item => item.Count)
            .ToListAsync(cancellationToken);
        var status = statusRows
            .Select(item => new RoleDashboardPointDto(
                item.Label,
                item.Count,
                item.Count))
            .ToList();
        var trendRows = await _context.SalesOrders.AsNoTracking()
            .Where(item => item.OrderDateUtc >= from && item.OrderDateUtc <= to)
            .Select(item => new
            {
                item.OrderDateUtc,
                item.TotalAmount
            })
            .ToListAsync(cancellationToken);
        var trend = trendRows
            .GroupBy(item => item.OrderDateUtc.Date)
            .OrderBy(group => group.Key)
            .Select(group => new RoleDashboardPointDto(
                group.Key.ToString("yyyy-MM-dd"),
                group.Sum(item => item.TotalAmount),
                group.Count()))
            .ToList();

        return Dashboard(
            RoleCodes.BusinessManager,
            "Business Manager dashboard",
            "Sales orders, procurement and Buying List coordination.",
            from,
            to,
            [
                Metric("Orders awaiting validation", await _context.SalesOrders.CountAsync(
                item => item.Status == SalesOrderStatuses.Submitted ||
                        item.Status == SalesOrderStatuses.LegacyPendingValidation,
                    cancellationToken), "number", "Orders needing business review.", "/search-orders"),
                Metric("Open supplier orders", await _context.SupplierOrders.CountAsync(
                    item => item.Status != SupplierOrderStatuses.FullyReceived &&
                            item.Status != SupplierOrderStatuses.Cancelled,
                    cancellationToken), "number", "Supplier orders still in progress.", "/suppliers"),
                Metric("Active Buying Lists", await _context.BuyerProcurements.CountAsync(
                    item => item.Status != BuyingListStatuses.Completed &&
                            item.Status != BuyingListStatuses.Cancelled,
                    cancellationToken), "number", "Lists requiring buyer or management action.", "/buying-lists")
            ],
            Chart("Sales orders by status", "Current Sales Order workflow position.", "number", status),
            Chart("Order value trend", "Trusted server-calculated order totals by day.", "currency", trend));
    }

    private async Task<RoleDashboardDto> WarehouseManagerAsync(
        DateTime from,
        DateTime to,
        CancellationToken cancellationToken)
    {
        var stockSource = await _context.Stocks.AsNoTracking()
            .Select(item => new
            {
                item.Product.ProductName,
                item.QuantityAvailableKg
            })
            .ToListAsync(cancellationToken);
        // Aggregate decimal quantities after projection so the dashboard works
        // consistently with SQL Server and the SQLite regression-test provider.
        var stock = stockSource
            .GroupBy(item => item.ProductName)
            .Select(group => new RoleDashboardPointDto(
                group.Key,
                group.Sum(item => item.QuantityAvailableKg),
                group.Count()))
            .OrderByDescending(item => item.Value)
            .Take(8)
            .ToList();
        var movementRows = await _context.StockMovements.AsNoTracking()
            .Where(item => item.OccurredAtUtc >= from && item.OccurredAtUtc <= to)
            .Select(item => new
            {
                item.OccurredAtUtc,
                item.MovementType,
                item.QuantityKg
            })
            .ToListAsync(cancellationToken);
        var movements = movementRows
            .GroupBy(item => item.OccurredAtUtc.Date)
            .OrderBy(group => group.Key)
            .Select(group => new RoleDashboardPointDto(
                group.Key.ToString("yyyy-MM-dd"),
                group.Sum(item => item.MovementType == StockMovementTypes.Increase
                    ? item.QuantityKg
                    : -item.QuantityKg),
                group.Count()))
            .ToList();

        var rawStockItems = await _context.RawStockItems.CountAsync(
            item => item.IsActive,
            cancellationToken);
        var lowRawStock = await _context.RawStockBalances.CountAsync(
            item => item.RawStockItem.IsActive &&
                    item.QuantityOnHand - item.ReservedQuantity <= 0,
            cancellationToken);
        var expiringRawBatches = await _context.RawStockBatches.CountAsync(
            item => item.Status == ProductBatchStatuses.Available &&
                    item.QuantityRemaining > 0 &&
                    item.BestBeforeAtUtc != null &&
                    item.BestBeforeAtUtc <= DateTime.UtcNow.AddDays(7),
            cancellationToken);
        var pendingStockTakes = await _context.RawStockTakeSessions.CountAsync(
            item => item.Status != RawStockTakeStatuses.Closed &&
                    item.Status != RawStockTakeStatuses.Rejected,
            cancellationToken);
        var packingWorkload = await _context.SalesOrders.CountAsync(
            item => item.Status == SalesOrderStatuses.Approved ||
                    item.Status == SalesOrderStatuses.Confirmed ||
                    item.Status == SalesOrderStatuses.Packing,
            cancellationToken);
        var receiptsAwaitingAction = await _context.SupplierOrders.CountAsync(
            item => item.Status == SupplierOrderStatuses.Ordered ||
                    item.Status == SupplierOrderStatuses.PartiallyReceived,
            cancellationToken);
        var openWriteOffs = await _context.RawStockWriteOffs.CountAsync(
            item => item.Status == WriteOffStatuses.PendingApproval,
            cancellationToken);
        var recentActivity = await RecentActivityAsync(
            from,
            to,
            [AuditModules.RawStock, AuditModules.RawStockTake,
                AuditModules.Stock, AuditModules.Packing,
                AuditModules.ExpiryManagement],
            cancellationToken);

        return Dashboard(
            RoleCodes.WarehouseManager,
            "Warehouse Manager dashboard",
            "Stock availability, expiry, receiving, packing and dispatch control.",
            from,
            to,
            [
                Metric("Raw-stock items", rawStockItems, "number",
                    "Active raw-stock master records.", "/raw-stock"),
                Metric("Low raw stock", lowRawStock, "number",
                    "Balances with no unreserved quantity.", "/raw-stock"),
                Metric("Expiring soon", expiringRawBatches, "number",
                    "Available raw-stock batches expiring within seven days.", "/raw-stock"),
                Metric("Pending stock takes", pendingStockTakes, "number",
                    "Open reconciliation sessions.", "/raw-stock"),
                Metric("Packing workload", packingWorkload, "number",
                    "Approved or active packing orders.", "/view-pick-list"),
                Metric("Receipts awaiting action", receiptsAwaitingAction, "number",
                    "Supplier orders still awaiting full receipt.", "/raw-stock")
            ],
            Chart("Available stock by product", "Top sellable quantities from live Stock records.", "kilograms", stock),
            Chart("Net stock movement", "Daily increases less decreases during the selected period.", "kilograms", movements),
            [
                Attention("raw-stock balances need replenishment", lowRawStock,
                    "Investigate balances with no unreserved stock.", "/raw-stock", "critical"),
                Attention("raw-stock batches expire soon", expiringRawBatches,
                    "Review expiring batches and take appropriate action.", "/raw-stock", "warning"),
                Attention("stock takes remain open", pendingStockTakes,
                    "Complete or review current reconciliations.", "/raw-stock", "warning"),
                Attention("write-offs await approval", openWriteOffs,
                    "An authorised manager must decide these requests.", "/raw-stock", "critical"),
                Attention("orders are in the packing workload", packingWorkload,
                    "Keep approved fulfilment work moving.", "/view-pick-list", "warning")
            ],
            recentActivity);
    }

    private async Task<RoleDashboardDto> OperationsManagerAsync(
        DateTime from,
        DateTime to,
        CancellationToken cancellationToken)
    {
        var paymentRows = await _context.FinancialPayments.AsNoTracking()
            .Where(item => item.Status == FinancialPaymentStatuses.Posted)
            .Select(item => new
            {
                item.CounterpartyType,
                item.Amount
            })
            .ToListAsync(cancellationToken);
        var payments = paymentRows
            .GroupBy(item => item.CounterpartyType)
            .Select(group => new RoleDashboardPointDto(
                group.Key,
                group.Sum(item => item.Amount),
                group.Count()))
            .OrderByDescending(item => item.Value)
            .ToList();
        var trendRows = await _context.FinancialPayments.AsNoTracking()
            .Where(item => item.Status == FinancialPaymentStatuses.Posted &&
                           item.PaymentDateUtc >= from && item.PaymentDateUtc <= to)
            .Select(item => new
            {
                item.PaymentDateUtc,
                item.CounterpartyType,
                item.Amount
            })
            .ToListAsync(cancellationToken);
        var trend = trendRows
            .GroupBy(item => item.PaymentDateUtc.Date)
            .OrderBy(group => group.Key)
            .Select(group => new RoleDashboardPointDto(
                group.Key.ToString("yyyy-MM-dd"),
                group.Sum(item => item.Amount),
                group.Count()))
            .ToList();

        var periodOrders = await _context.SalesOrders.CountAsync(
            item => item.OrderDateUtc >= from && item.OrderDateUtc <= to,
            cancellationToken);
        var ordersNeedingAttention = await _context.SalesOrders.CountAsync(
            item => item.Status == SalesOrderStatuses.Submitted ||
                    item.Status == SalesOrderStatuses.LegacyPendingValidation ||
                    item.Status == SalesOrderStatuses.Rejected,
            cancellationToken);
        var activeDeliveries = await _context.Deliveries.CountAsync(
            item => item.Status == DeliveryStatuses.Assigned ||
                    item.Status == DeliveryStatuses.InTransit,
            cancellationToken);
        var pendingWriteOffs = await _context.RawStockWriteOffs.CountAsync(
            item => item.Status == WriteOffStatuses.PendingApproval,
            cancellationToken);
        var customerReceipts = trendRows
            .Where(item => item.CounterpartyType == "Customer")
            .Sum(item => item.Amount);
        var supplierPayments = trendRows
            .Where(item => item.CounterpartyType == "Supplier")
            .Sum(item => item.Amount);
        var pendingReversals = await _context.FinancialPayments.CountAsync(
            item => item.Status == FinancialPaymentStatuses.PendingReversalApproval,
            cancellationToken);
        var pendingStockTakeApprovals = await _context.RawStockTakeSessions.CountAsync(
            item => item.Status == RawStockTakeStatuses.PendingManagementApproval,
            cancellationToken);
        var deliveryExceptions = await _context.Deliveries.CountAsync(
            item => item.Status == DeliveryStatuses.Scheduled && item.DriverId == null,
            cancellationToken);
        var recentActivity = await RecentActivityAsync(
            from,
            to,
            [AuditModules.OrderManagement, AuditModules.DeliveryLogistics,
                AuditModules.Payments, AuditModules.RawStockTake,
                AuditModules.RawStock, AuditModules.BuyingList],
            cancellationToken);

        return Dashboard(
            RoleCodes.OperationsManager,
            "Operations Manager dashboard",
            "Financial, delivery, waste and operational exception oversight.",
            from,
            to,
            [
                Metric("Orders this period", periodOrders, "number",
                    "Customer orders created in the selected period.", "/search-orders"),
                Metric("Orders needing attention", ordersNeedingAttention, "number",
                    "Submitted or rejected orders requiring follow-up.", "/search-orders"),
                Metric("Deliveries in progress", activeDeliveries, "number",
                    "Deliveries assigned or in transit.", "/deliveries"),
                Metric("Pending stock-take approvals", pendingStockTakeApprovals, "number",
                    "Reviewed reconciliations awaiting an independent decision.", "/raw-stock/approvals?tab=takes"),
                Metric("Pending write-off approvals", pendingWriteOffs, "number",
                    "Raw-stock loss decisions pending.", "/raw-stock/approvals?tab=writeoffs"),
                Metric("Customer receipts", customerReceipts, "currency",
                    "Posted customer payments in this period.", "/payments"),
                Metric("Supplier payments", supplierPayments, "currency",
                    "Posted supplier payments in this period.", "/payments")
            ],
            Chart("Posted payment value", "Posted values split by counterparty type.", "currency", payments),
            Chart("Payment trend", "Posted payment value by day for the selected period.", "currency", trend),
            [
                Attention("stock takes await approval", pendingStockTakeApprovals,
                    "Review submitted warehouse reconciliation discrepancies.", "/raw-stock/approvals?tab=takes", "critical"),
                Attention("payment reversals await approval", pendingReversals,
                    "Review controlled payment reversals.", "/payments", "critical"),
                Attention("write-offs await approval", pendingWriteOffs,
                    "Complete independent write-off decisions.", "/raw-stock/approvals?tab=writeoffs", "critical"),
                Attention("orders need management follow-up", ordersNeedingAttention,
                    "Review submitted or rejected customer orders.", "/search-orders", "warning"),
                Attention("deliveries need assignment", deliveryExceptions,
                    "Assign a driver to scheduled delivery work.", "/deliveries", "warning")
            ],
            recentActivity);
    }

    private async Task<RoleDashboardDto> PackerAsync(
        int userId,
        DateTime from,
        DateTime to,
        CancellationToken cancellationToken)
    {
        var queueRows = await _context.SalesOrders.AsNoTracking()
            .Where(item => item.Status == SalesOrderStatuses.Approved ||
                           item.Status == SalesOrderStatuses.Confirmed ||
                           item.Status == SalesOrderStatuses.Packing)
            .GroupBy(item => item.Status)
            .Select(group => new
            {
                Label = group.Key,
                Count = group.Count()
            })
            .ToListAsync(cancellationToken);
        var queue = queueRows
            .Select(item => new RoleDashboardPointDto(
                item.Label,
                item.Count,
                item.Count))
            .ToList();
        var trendRows = await _context.SalesOrders.AsNoTracking()
            .Where(item => item.PackedByUserId == userId &&
                           item.PackedAtUtc >= from && item.PackedAtUtc <= to)
            .Select(item => new
            {
                PackedAtUtc = item.PackedAtUtc!.Value,
                QuantityKg = item.Items
                    .Where(line => line.IsActive)
                    .Sum(line => line.QuantityKg)
            })
            .ToListAsync(cancellationToken);
        var trend = trendRows
            .GroupBy(item => item.PackedAtUtc.Date)
            .OrderBy(group => group.Key)
            .Select(group => new RoleDashboardPointDto(
                group.Key.ToString("yyyy-MM-dd"),
                group.Sum(item => item.QuantityKg),
                group.Count()))
            .ToList();

        return Dashboard(
            RoleCodes.Packer,
            "Packer dashboard",
            "Assigned packing work, scanned quantities and personal throughput.",
            from,
            to,
            [
                Metric("Packing tasks", queue.Sum(item => item.Count), "number",
                    "Confirmed and active packing tasks.", null),
                Metric("My packed orders", await _context.SalesOrders.CountAsync(
                    item => item.PackedByUserId == userId && item.PackedAtUtc >= from && item.PackedAtUtc <= to,
                    cancellationToken), "number", "Orders completed by you in this period.", null)
            ],
            Chart("Packing queue", "Current packable orders by status.", "number", queue),
            Chart("My packed kilograms", "Your completed packed quantity by day.", "kilograms", trend));
    }

    private async Task<RoleDashboardDto> DriverAsync(
        int userId,
        DateTime from,
        DateTime to,
        CancellationToken cancellationToken)
    {
        var driverId = await _context.Drivers.AsNoTracking()
            .Where(item => item.UserId == userId)
            .Select(item => (int?)item.DriverId)
            .SingleOrDefaultAsync(cancellationToken);
        var deliveryQuery = _context.Deliveries.AsNoTracking()
            .Where(item => driverId != null && item.DriverId == driverId);
        var statusRows = await deliveryQuery
            .GroupBy(item => item.Status)
            .Select(group => new
            {
                Label = group.Key,
                Count = group.Count()
            })
            .ToListAsync(cancellationToken);
        var status = statusRows
            .Select(item => new RoleDashboardPointDto(
                item.Label,
                item.Count,
                item.Count))
            .ToList();
        var trendRows = await deliveryQuery
            .Where(item => item.CompletedAtUtc >= from && item.CompletedAtUtc <= to)
            .Select(item => item.CompletedAtUtc!.Value)
            .ToListAsync(cancellationToken);
        var trend = trendRows
            .GroupBy(item => item.Date)
            .OrderBy(group => group.Key)
            .Select(group => new RoleDashboardPointDto(
                group.Key.ToString("yyyy-MM-dd"),
                group.Count(),
                group.Count()))
            .ToList();

        return Dashboard(
            RoleCodes.Driver,
            "Driver dashboard",
            "Your assigned deliveries, completion progress and proof status.",
            from,
            to,
            [
                Metric("Assigned deliveries", await deliveryQuery.CountAsync(
                    item => item.Status == DeliveryStatuses.Assigned,
                    cancellationToken), "number", "Deliveries ready for you to start.", null),
                Metric("In transit", await deliveryQuery.CountAsync(
                    item => item.Status == DeliveryStatuses.InTransit,
                    cancellationToken), "number", "Your deliveries currently underway.", null)
            ],
            Chart("My deliveries by status", "Only deliveries assigned to your driver profile.", "number", status),
            Chart("My completed deliveries", "Deliveries you completed by day.", "number", trend));
    }

    private async Task<RoleDashboardDto> MarketBuyerAsync(
        int userId,
        DateTime from,
        DateTime to,
        CancellationToken cancellationToken)
    {
        var listQuery = _context.BuyerProcurements.AsNoTracking()
            .Where(item => item.AssignedBuyerUserId == userId);
        var statusRows = await listQuery
            .GroupBy(item => item.Status)
            .Select(group => new
            {
                Label = group.Key,
                Count = group.Count()
            })
            .ToListAsync(cancellationToken);
        var status = statusRows
            .Select(item => new RoleDashboardPointDto(
                item.Label,
                item.Count,
                item.Count))
            .ToList();
        var trendRows = await _context.BuyerProcurementItems.AsNoTracking()
            .Where(item => item.BuyerProcurement.AssignedBuyerUserId == userId &&
                           item.BuyerProcurement.BuyingDateUtc >= from &&
                           item.BuyerProcurement.BuyingDateUtc <= to &&
                           item.ActualQuantity != null && item.ActualUnitPrice != null)
            .Select(item => new
            {
                item.BuyerProcurement.BuyingDateUtc,
                ActualQuantity = item.ActualQuantity!.Value,
                ActualUnitPrice = item.ActualUnitPrice!.Value
            })
            .ToListAsync(cancellationToken);
        var trend = trendRows
            .GroupBy(item => item.BuyingDateUtc.Date)
            .OrderBy(group => group.Key)
            .Select(group => new RoleDashboardPointDto(
                group.Key.ToString("yyyy-MM-dd"),
                group.Sum(item => item.ActualQuantity * item.ActualUnitPrice),
                group.Count()))
            .ToList();

        return Dashboard(
            RoleCodes.MarketBuyer,
            "Market Buyer dashboard",
            "Your assigned Buying Lists, item progress and recorded purchase value.",
            from,
            to,
            [
                Metric("Assigned lists", await listQuery.CountAsync(
                    item => item.Status != BuyingListStatuses.Completed &&
                            item.Status != BuyingListStatuses.Cancelled,
                    cancellationToken), "number", "Lists still requiring your attention.", null),
                Metric("Pending items", await _context.BuyerProcurementItems.CountAsync(
                    item => item.BuyerProcurement.AssignedBuyerUserId == userId &&
                            item.Status == BuyingItemStatuses.Pending,
                    cancellationToken), "number", "Items not yet purchased or resolved.", null)
            ],
            Chart("My Buying Lists", "Your lists grouped by their current status.", "number", status),
            Chart("Recorded purchase value", "Actual quantity multiplied by actual unit price by day.", "currency", trend));
    }

    private Task<int> ProductsWithoutPrice(CancellationToken cancellationToken)
    {
        var now = DateTime.UtcNow;
        return _context.Products.CountAsync(
            product => product.Status == ProductStatuses.Active &&
                       !product.ProductPrices.Any(price =>
                           !price.IsDeleted &&
                           price.EffectiveFromUtc <= now &&
                           (price.EffectiveToUtc == null || price.EffectiveToUtc > now)),
            cancellationToken);
    }

    private Task<List<RoleDashboardActivityDto>> RecentActivityAsync(
        DateTime from,
        DateTime to,
        string[] modules,
        CancellationToken cancellationToken) =>
        _context.AuditLogs.AsNoTracking()
            .Where(item => item.OccurredAtUtc >= from &&
                           item.OccurredAtUtc <= to &&
                           modules.Contains(item.SystemModule))
            .OrderByDescending(item => item.OccurredAtUtc)
            .Take(6)
            .Select(item => new RoleDashboardActivityDto(
                item.AuditLogId,
                item.OccurredAtUtc,
                item.OperationName,
                item.SystemModule,
                item.EntityDisplay,
                item.UserDisplayNameSnapshot,
                item.Success))
            .ToListAsync(cancellationToken);

    private static RoleDashboardDto Dashboard(
        string roleCode,
        string title,
        string subtitle,
        DateTime from,
        DateTime to,
        IReadOnlyList<RoleDashboardMetricDto> metrics,
        RoleDashboardChartDto bar,
        RoleDashboardChartDto line,
        IReadOnlyList<RoleDashboardAttentionDto>? attentionItems = null,
        IReadOnlyList<RoleDashboardActivityDto>? recentActivity = null) =>
        new()
        {
            RoleCode = roleCode,
            Title = title,
            Subtitle = subtitle,
            FromUtc = from,
            ToUtc = to,
            Metrics = metrics,
            BarChart = bar,
            LineChart = line,
            AttentionItems = attentionItems ?? [],
            RecentActivity = recentActivity ?? []
        };

    private static RoleDashboardDto Empty(string roleCode, DateTime from, DateTime to) =>
        Dashboard(
            roleCode,
            "Operations dashboard",
            "Your account has no role-specific dashboard configuration.",
            from,
            to,
            [],
            Chart("Current activity", "No role-scoped activity is available.", "number", []),
            Chart("Activity trend", "No role-scoped trend is available.", "number", []));

    private static RoleDashboardMetricDto Metric(
        string label,
        decimal value,
        string kind,
        string detail,
        string? route) => new(label, value, kind, detail, route);

    private static RoleDashboardAttentionDto Attention(
        string label,
        decimal value,
        string detail,
        string route,
        string severity) => new(label, value, detail, route, severity);

    private static RoleDashboardChartDto Chart(
        string title,
        string description,
        string kind,
        IReadOnlyList<RoleDashboardPointDto> points) =>
        new(title, description, kind, points);

}
