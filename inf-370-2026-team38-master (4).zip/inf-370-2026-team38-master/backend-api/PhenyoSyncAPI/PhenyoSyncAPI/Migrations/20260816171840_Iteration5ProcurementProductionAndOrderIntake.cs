﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class Iteration5ProcurementProductionAndOrderIntake : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "RequireTwoFactorOnNextWebLogin",
                table: "Users",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "ExternalOrderSubmissions",
                columns: table => new
                {
                    ExternalOrderSubmissionId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Source = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    ExternalSourceKey = table.Column<string>(type: "nvarchar(180)", maxLength: 180, nullable: false),
                    PayloadHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    SafeIssueSummary = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    SubmittedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ImportedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SalesOrderId = table.Column<int>(type: "int", nullable: true),
                    ImportedByUserId = table.Column<int>(type: "int", nullable: false),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ExternalOrderSubmissions", x => x.ExternalOrderSubmissionId);
                    table.ForeignKey(
                        name: "FK_ExternalOrderSubmissions_SalesOrders_SalesOrderId",
                        column: x => x.SalesOrderId,
                        principalTable: "SalesOrders",
                        principalColumn: "SalesOrderId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ExternalOrderSubmissions_Users_ImportedByUserId",
                        column: x => x.ImportedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PackingConversions",
                columns: table => new
                {
                    PackingConversionId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    ProductBatchId = table.Column<int>(type: "int", nullable: false),
                    WarehouseSectionId = table.Column<int>(type: "int", nullable: false),
                    QuantityProduced = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    PackedByUserId = table.Column<int>(type: "int", nullable: false),
                    PackedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PackingConversions", x => x.PackingConversionId);
                    table.ForeignKey(
                        name: "FK_PackingConversions_ProductBatches_ProductBatchId",
                        column: x => x.ProductBatchId,
                        principalTable: "ProductBatches",
                        principalColumn: "ProductBatchId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingConversions_Product_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingConversions_Users_PackedByUserId",
                        column: x => x.PackedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingConversions_WarehouseSections_WarehouseSectionId",
                        column: x => x.WarehouseSectionId,
                        principalTable: "WarehouseSections",
                        principalColumn: "SectionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PackingConversionRawStock",
                columns: table => new
                {
                    PackingConversionRawStockId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PackingConversionId = table.Column<long>(type: "bigint", nullable: false),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false),
                    RawStockBalanceId = table.Column<int>(type: "int", nullable: false),
                    RawStockBatchId = table.Column<long>(type: "bigint", nullable: false),
                    QuantityConsumed = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    UnitOfMeasure = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    BalanceBefore = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    BalanceAfter = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    BatchBefore = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    BatchAfter = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    UnitCost = table.Column<decimal>(type: "decimal(18,4)", precision: 18, scale: 4, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PackingConversionRawStock", x => x.PackingConversionRawStockId);
                    table.ForeignKey(
                        name: "FK_PackingConversionRawStock_PackingConversions_PackingConversionId",
                        column: x => x.PackingConversionId,
                        principalTable: "PackingConversions",
                        principalColumn: "PackingConversionId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingConversionRawStock_RawStockBalances_RawStockBalanceId",
                        column: x => x.RawStockBalanceId,
                        principalTable: "RawStockBalances",
                        principalColumn: "RawStockBalanceId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingConversionRawStock_RawStockBatches_RawStockBatchId",
                        column: x => x.RawStockBatchId,
                        principalTable: "RawStockBatches",
                        principalColumn: "RawStockBatchId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingConversionRawStock_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 2,
                columns: new[] { "BodyContent", "Summary" },
                values: new object[] { "# Login and email verification\nEnter your email and password. Normal web and mobile sign-in opens the permitted dashboard without an email code.\n\nAfter a successful password reset or account-owner password change, the next web login requires one email verification challenge. Mobile login remains available and does not clear this requirement. The requirement is cleared only after the web code or recovery code is verified successfully.\n\nThe code expires after five minutes and is attempt limited. Never share a password or verification code. If email is delayed, check junk mail, confirm the masked destination, wait for the resend timer and request one fresh code.", "Sign in normally and understand the one-time web verification required after a password reset." });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 3,
                columns: new[] { "BodyContent", "Summary" },
                values: new object[] { "# Trusted devices\nNormal sign-in no longer uses a trusted-device token to decide whether verification is required. Existing device records remain visible for accountability and can be revoked.\n\nOpen Account Security to review device names, last use and expiry. Revoke an unfamiliar device immediately. Password reset, account deactivation, role changes and security-session revocation invalidate trusted devices.", "Review and revoke legacy trusted-device records safely." });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 8,
                columns: new[] { "BodyContent", "Keywords", "Summary" },
                values: new object[] { "# Make products\nSelect a warehouse section, then select an existing active Product whose Raw Stock requirements are configured and currently available. The readiness card shows adjusted input quantities and maximum packable output.\n\nConfirming production consumes eligible Raw Stock batches in expiry and FIFO order, writes negative Raw Stock movements, creates one finished Product batch and stock increase, and links the records through one conversion and correlation ID. The transaction rolls back when any input is insufficient or changes concurrently. Product master creation and order barcode packing remain separate workflows.", "make product raw stock conversion recipe trace batch", "Convert mapped Raw Stock into an existing Product and trace both sides of production." });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 18,
                columns: new[] { "BodyContent", "Keywords", "Summary" },
                values: new object[] { "# Customer order form\nOpen the configured Google Form from Order Management and share it with the customer. When responses are ready, an authorised user selects Synchronise responses. PhenyoSync reads the configured Google Sheet through the backend and never exposes the provider key to the browser.\n\nEach response has a stable external key, so repeated syncs cannot create duplicate orders. Valid responses use the existing Product codes and active Customer, apply authoritative server-side prices, and enter the system as Submitted with Pending Validation. Unknown customers, Products, malformed quantities and incomplete addresses remain in Needs Attention instead of silently creating records.", "customer google sheet order sync duplicate pending validation", "Share the configured Google Form and manually synchronise controlled order requests." });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 33,
                column: "BodyContent",
                value: "# Formal reports\nChoose a report, set its criteria and select Preview. The preview is the authoritative dataset for the PDF. If any criterion changes, preview the report again before downloading.\n\nInventory Availability, Expiry and Waste, and Markup Analysis are simple flat reports. Sales and Stock Movement reports use visible control breaks, subtotals and grand totals. Currency is displayed in South African rand and timestamps are shown consistently with the selected criteria.\n\nAccess to costs, reversals and exports is controlled independently. Future dates and future pricing periods are rejected in both the page and API. An empty report means no records matched the selected criteria; it is not a failure. Every preview and PDF export is audited.");

            migrationBuilder.InsertData(
                table: "HelpTopics",
                columns: new[] { "HelpTopicId", "AudienceRolesCsv", "BodyContent", "CreatedAtUtc", "HelpCategoryId", "IsPublic", "IsPublished", "Keywords", "Slug", "SortOrder", "Summary", "Title", "UpdatedAtUtc", "UpdatedByUserId" },
                values: new object[,]
                {
                    { 36, "OperationsManager,BusinessManager,Admin,WarehouseManager", "# Product and price data exchange\nUse the same filters for the presentation-ready Excel workbook and stable, indented JSON catalogue. Both formats show the Product master and price effective at the selected business date. Excel includes instructions, metadata, filters and typed columns; JSON includes a schema version and deterministic Product ordering.\n\nImport remains an Excel-only controlled workflow: upload the current template, review valid, warning and invalid rows, enter a business reason, confirm, and apply the exact staged content. Existing prices are versioned instead of overwritten. JSON catalogue export never imports or mutates records.", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), 3, false, true, "excel json product price catalogue template validate import export", "product-data-exchange", 40, "Export professional Excel or readable JSON and apply only validated Excel imports.", "Product and price data exchange", null, null },
                    { 37, "OperationsManager,BusinessManager,Admin,WarehouseManager", "# Procurement shortages\nShortage planning starts with approved, confirmed and active fulfilment demand. Submitted customer or Google Form requests are excluded until validation succeeds. Active finished-stock reservations are subtracted before the Product shortage is calculated.\n\nProduct shortages are translated through active Product-to-Raw-Stock requirements, including configured yield and waste. Available Raw Stock, outstanding supplier orders and open buying-list quantities are then subtracted. Negative values are clamped per line before aggregation so one over-supplied line cannot hide another shortage.", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), 3, false, true, "procurement demand shortage reservation raw stock buying list", "procurement-shortages", 50, "Understand how validated demand becomes Product and Raw Stock buying requirements.", "Demand-driven procurement shortages", null, null }
                });

            migrationBuilder.InsertData(
                table: "HelpContextMappings",
                columns: new[] { "HelpContextMappingId", "ComponentKey", "HelpTopicId", "IsActive", "Priority", "RoutePattern" },
                values: new object[,]
                {
                    { 41, "ProductDataExchange", 36, true, 100, "/product-data-exchange" },
                    { 42, "BuyingLists", 37, true, 100, "/buying-lists" },
                    { 43, "RawStock", 37, true, 90, "/raw-stock" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_ExternalOrderSubmissions_CorrelationId",
                table: "ExternalOrderSubmissions",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_ExternalOrderSubmissions_ImportedByUserId",
                table: "ExternalOrderSubmissions",
                column: "ImportedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ExternalOrderSubmissions_SalesOrderId",
                table: "ExternalOrderSubmissions",
                column: "SalesOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_ExternalOrderSubmissions_Status_ImportedAtUtc",
                table: "ExternalOrderSubmissions",
                columns: new[] { "Status", "ImportedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "UX_ExternalOrderSubmissions_Source_Key",
                table: "ExternalOrderSubmissions",
                columns: new[] { "Source", "ExternalSourceKey" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PackingConversionRawStock_PackingConversionId_RawStockItemId",
                table: "PackingConversionRawStock",
                columns: new[] { "PackingConversionId", "RawStockItemId" });

            migrationBuilder.CreateIndex(
                name: "IX_PackingConversionRawStock_RawStockBalanceId",
                table: "PackingConversionRawStock",
                column: "RawStockBalanceId");

            migrationBuilder.CreateIndex(
                name: "IX_PackingConversionRawStock_RawStockBatchId",
                table: "PackingConversionRawStock",
                column: "RawStockBatchId");

            migrationBuilder.CreateIndex(
                name: "IX_PackingConversionRawStock_RawStockItemId",
                table: "PackingConversionRawStock",
                column: "RawStockItemId");

            migrationBuilder.CreateIndex(
                name: "IX_PackingConversions_CorrelationId",
                table: "PackingConversions",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_PackingConversions_PackedByUserId",
                table: "PackingConversions",
                column: "PackedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_PackingConversions_ProductId_PackedAtUtc",
                table: "PackingConversions",
                columns: new[] { "ProductId", "PackedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_PackingConversions_WarehouseSectionId",
                table: "PackingConversions",
                column: "WarehouseSectionId");

            migrationBuilder.CreateIndex(
                name: "UX_PackingConversions_ProductBatch",
                table: "PackingConversions",
                column: "ProductBatchId",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ExternalOrderSubmissions");

            migrationBuilder.DropTable(
                name: "PackingConversionRawStock");

            migrationBuilder.DropTable(
                name: "PackingConversions");

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 41);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 42);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 43);

            migrationBuilder.DeleteData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 36);

            migrationBuilder.DeleteData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 37);

            migrationBuilder.DropColumn(
                name: "RequireTwoFactorOnNextWebLogin",
                table: "Users");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 2,
                columns: new[] { "BodyContent", "Summary" },
                values: new object[] { "# Login and email verification\nEnter your email and password. A new or untrusted session receives a six-digit code by email before business access is granted.\n\nThe code expires after five minutes, allows five attempts and can be resent after the displayed countdown. A new resend invalidates the previous code. Never share a password or verification code.\n\nIf email is delayed, check junk mail, confirm the masked destination, wait for the resend timer and request a fresh code.", "Sign in with a password, verify a new session by email, and understand OTP limits." });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 3,
                columns: new[] { "BodyContent", "Summary" },
                values: new object[] { "# Trusted devices\nSelecting Trust this device after OTP stores a protected HttpOnly device token. It bypasses OTP for up to 30 days but never bypasses the password.\n\nOpen Account Security to review device names, last use and expiry. Revoke an unfamiliar device immediately. Password reset, account deactivation, role changes and security-session revocation invalidate trusted devices.", "Understand the 30-day trusted-device option and revoke devices safely." });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 8,
                columns: new[] { "BodyContent", "Keywords", "Summary" },
                values: new object[] { "# Make products\nSelect an existing product identity or enter name, type, category and size. Enter the produced quantity, warehouse section and packed date.\n\nPhenyoSync reuses an exact matching product identity and always creates a separate physical batch. The batch increases available stock, records a stock movement and calculates expiry from the product shelf life.", "make product batch quantity stock increase", "Create or reuse a product and record a new physical batch as stock increase." });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 18,
                columns: new[] { "BodyContent", "Keywords", "Summary" },
                values: new object[] { "# Customer order form\nOpen the configured Google Form from Order Management and share it with the customer. The response is an intake aid only. An authorised staff member must review it and capture the official multi-line order in PhenyoSync, where server-side prices and stock rules are applied.\n\nCustomer Form responses never create or price an order automatically.", "customer google form intake capture official order", "Open or share the configured Google Form, then capture the official order." });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 33,
                column: "BodyContent",
                value: "# Formal reports\nChoose a report, set its criteria and select Preview. The preview is the authoritative dataset for the PDF. If any criterion changes, preview the report again before downloading.\n\nInventory Availability, Expiry and Waste, and Markup Analysis are simple flat reports. Sales and Stock Movement reports use visible control breaks, subtotals and grand totals. Currency is displayed in South African rand and timestamps are shown consistently with the selected criteria.\n\nAccess to costs, reversals and exports is controlled independently. An empty report means no records matched the selected criteria; it is not a failure. Every preview and PDF export is audited.");
        }
    }
}
