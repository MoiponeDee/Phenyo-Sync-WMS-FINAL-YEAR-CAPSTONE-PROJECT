﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class FormalReportingSubsystem : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "SystemSettings",
                columns: new[] { "SystemSettingId", "AllowedValuesJson", "Category", "DefaultValue", "Description", "DisplayName", "IsActive", "IsSensitive", "IsSystemSetting", "Key", "MaximumValue", "MinimumValue", "RequiresRestart", "Unit", "UpdatedAtUtc", "UpdatedByUserId", "Value", "ValueType" },
                values: new object[,]
                {
                    { 54, null, "Reports", "50", "Rows shown when a paged report does not specify a page size.", "Default page size", true, false, true, "Reports.DefaultPageSize", "500", "10", false, "rows", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "50", "Integer" },
                    { 55, null, "Reports", "500", "Largest row count accepted for one paged report preview.", "Maximum page size", true, false, true, "Reports.MaximumPageSize", "2000", "50", false, "rows", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "500", "Integer" },
                    { 56, null, "Reports", "30", "Minutes an authenticated preview remains available for matching PDF export.", "Preview lifetime", true, false, true, "Reports.PreviewLifetimeMinutes", "120", "5", false, "minutes", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "30", "TimeSpanMinutes" },
                    { 57, null, "Reports", "365", "Maximum date range accepted by transactional and adjustable reports.", "Maximum date range", true, false, true, "Reports.MaximumDateRangeDays", "1095", "31", false, "days", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "365", "Integer" },
                    { 58, null, "Reports", "false", "Allow markup analysis to use a prior receipt cost when no direct or current receipt cost is available.", "Allow prior receipt cost fallback", true, false, true, "Reports.Markup.AllowPriorReceiptCostFallback", null, null, false, null, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "false", "Boolean" },
                    { 59, null, "Reports", "5", "Minimum historical price observations required before a box plot is reliable.", "Minimum box-plot observations", true, false, true, "Reports.Pricing.MinimumBoxPlotObservations", "30", "5", false, "observations", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "5", "Integer" }
                });

            migrationBuilder.Sql(
                """
                DECLARE @ReportPermissions TABLE
                (
                    PermissionCode nvarchar(100) NOT NULL,
                    DisplayName nvarchar(120) NOT NULL
                );

                INSERT INTO @ReportPermissions VALUES
                    (N'Reports.View', N'Open Reports and Analytics'),
                    (N'Reports.Inventory.View', N'View the Inventory Position Report'),
                    (N'Reports.Inventory.ExportPdf', N'Export the Inventory Position Report PDF'),
                    (N'Reports.Sales.View', N'View the Sales by Customer and Product Report'),
                    (N'Reports.Sales.ExportPdf', N'Export the Sales Report PDF'),
                    (N'Reports.Financial.View', N'View the Financial Activity Report'),
                    (N'Reports.Financial.ViewCost', N'View financial report cost values'),
                    (N'Reports.Financial.ExportPdf', N'Export the Financial Activity Report PDF'),
                    (N'Reports.Financial.ViewReversalHistory', N'View reversed and voided financial activity'),
                    (N'Reports.StockMovement.View', N'View the Stock Movement Report'),
                    (N'Reports.StockMovement.ViewCost', N'View stock movement cost values'),
                    (N'Reports.StockMovement.ExportPdf', N'Export the Stock Movement Report PDF'),
                    (N'Reports.ExpiryWaste.View', N'View the Expiry and Waste Risk Report'),
                    (N'Reports.ExpiryWaste.ViewCost', N'View expiry and waste cost values'),
                    (N'Reports.ExpiryWaste.ExportPdf', N'Export the Expiry and Waste Report PDF'),
                    (N'Reports.Pricing.View', N'View the Product Pricing Analysis Report'),
                    (N'Reports.Pricing.ExportPdf', N'Export the Product Pricing Analysis Report PDF'),
                    (N'Reports.Markup.View', N'View the Product Markup and Gross Margin Report'),
                    (N'Reports.Markup.ViewCost', N'View markup report cost values'),
                    (N'Reports.Markup.ExportPdf', N'Export the Product Markup and Gross Margin Report PDF');

                INSERT INTO dbo.Permissions
                (
                    PermissionName,
                    PermissionCode,
                    DisplayName,
                    Module,
                    IsSystemPermission,
                    IsActive,
                    CreatedAtUtc
                )
                SELECT
                    seed.PermissionCode,
                    seed.PermissionCode,
                    seed.DisplayName,
                    N'Reports',
                    1,
                    1,
                    SYSUTCDATETIME()
                FROM @ReportPermissions seed
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.Permissions existing
                    WHERE existing.PermissionCode = seed.PermissionCode
                );

                UPDATE permission
                SET permission.PermissionName = seed.PermissionCode,
                    permission.DisplayName = seed.DisplayName,
                    permission.Module = N'Reports',
                    permission.IsSystemPermission = 1,
                    permission.IsActive = 1,
                    permission.UpdatedAtUtc = SYSUTCDATETIME()
                FROM dbo.Permissions permission
                JOIN @ReportPermissions seed
                  ON seed.PermissionCode = permission.PermissionCode;

                DECLARE @ReportRolePermissions TABLE
                (
                    RoleCode nvarchar(100) NOT NULL,
                    PermissionCode nvarchar(100) NOT NULL
                );

                INSERT INTO @ReportRolePermissions
                SELECT N'OperationsManager', PermissionCode
                FROM @ReportPermissions;

                INSERT INTO @ReportRolePermissions VALUES
                    (N'Admin', N'Reports.View'),
                    (N'Admin', N'Reports.Inventory.View'),
                    (N'Admin', N'Reports.Inventory.ExportPdf'),
                    (N'Admin', N'Reports.Pricing.View'),
                    (N'Admin', N'Reports.Pricing.ExportPdf'),
                    (N'Admin', N'Reports.Markup.View'),
                    (N'Admin', N'Reports.Markup.ViewCost'),
                    (N'Admin', N'Reports.Markup.ExportPdf'),
                    (N'BusinessManager', N'Reports.View'),
                    (N'BusinessManager', N'Reports.Inventory.View'),
                    (N'BusinessManager', N'Reports.Inventory.ExportPdf'),
                    (N'BusinessManager', N'Reports.Sales.View'),
                    (N'BusinessManager', N'Reports.Sales.ExportPdf'),
                    (N'BusinessManager', N'Reports.Pricing.View'),
                    (N'BusinessManager', N'Reports.Pricing.ExportPdf'),
                    (N'WarehouseManager', N'Reports.View'),
                    (N'WarehouseManager', N'Reports.Inventory.View'),
                    (N'WarehouseManager', N'Reports.Inventory.ExportPdf'),
                    (N'WarehouseManager', N'Reports.StockMovement.View'),
                    (N'WarehouseManager', N'Reports.StockMovement.ViewCost'),
                    (N'WarehouseManager', N'Reports.StockMovement.ExportPdf'),
                    (N'WarehouseManager', N'Reports.ExpiryWaste.View'),
                    (N'WarehouseManager', N'Reports.ExpiryWaste.ViewCost'),
                    (N'WarehouseManager', N'Reports.ExpiryWaste.ExportPdf');

                INSERT INTO dbo.RolePermissions
                (
                    RoleId,
                    PermissionId,
                    AssignedAtUtc
                )
                SELECT
                    role.RoleId,
                    permission.PermissionId,
                    SYSUTCDATETIME()
                FROM @ReportRolePermissions seed
                JOIN dbo.Roles role
                  ON role.RoleCode = seed.RoleCode
                JOIN dbo.Permissions permission
                  ON permission.PermissionCode = seed.PermissionCode
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.RolePermissions existing
                    WHERE existing.RoleId = role.RoleId
                      AND existing.PermissionId = permission.PermissionId
                );
                """);

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffs_ReportCompletedStatus",
                table: "StockWriteOffs",
                columns: new[] { "CompletedAtUtc", "Status" });

            migrationBuilder.CreateIndex(
                name: "IX_StockMovements_ReportDateTypeProduct",
                table: "StockMovements",
                columns: new[] { "OccurredAtUtc", "MovementType", "ProductId" });

            migrationBuilder.CreateIndex(
                name: "IX_SalesOrders_ReportDateCustomerStatus",
                table: "SalesOrders",
                columns: new[] { "OrderDateUtc", "CustomerId", "Status" });

            migrationBuilder.CreateIndex(
                name: "IX_RawStockMovements_ReportDateTypeItem",
                table: "RawStockMovements",
                columns: new[] { "OccurredAtUtc", "MovementType", "RawStockItemId" });

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_ReportDateCounterpartyStatus",
                table: "FinancialPayments",
                columns: new[] { "PaymentDateUtc", "CounterpartyType", "Status" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                DELETE mapping
                FROM dbo.RolePermissions mapping
                JOIN dbo.Permissions permission
                  ON permission.PermissionId = mapping.PermissionId
                WHERE permission.PermissionCode LIKE N'Reports.%';

                DELETE FROM dbo.Permissions
                WHERE PermissionCode LIKE N'Reports.%';
                """);

            migrationBuilder.DropIndex(
                name: "IX_StockWriteOffs_ReportCompletedStatus",
                table: "StockWriteOffs");

            migrationBuilder.DropIndex(
                name: "IX_StockMovements_ReportDateTypeProduct",
                table: "StockMovements");

            migrationBuilder.DropIndex(
                name: "IX_SalesOrders_ReportDateCustomerStatus",
                table: "SalesOrders");

            migrationBuilder.DropIndex(
                name: "IX_RawStockMovements_ReportDateTypeItem",
                table: "RawStockMovements");

            migrationBuilder.DropIndex(
                name: "IX_FinancialPayments_ReportDateCounterpartyStatus",
                table: "FinancialPayments");

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 54);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 55);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 56);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 57);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 58);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 59);
        }
    }
}
