﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class FinalPresentationStabilisation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "HelpTopics",
                columns: new[] { "HelpTopicId", "AudienceRolesCsv", "BodyContent", "CreatedAtUtc", "HelpCategoryId", "IsPublic", "IsPublished", "Keywords", "Slug", "SortOrder", "Summary", "Title", "UpdatedAtUtc", "UpdatedByUserId" },
                values: new object[,]
                {
                    { 38, "OperationsManager,BusinessManager,Admin,WarehouseManager", "# Product creation and production\nOpen Product Hierarchy and select Add Product. Choose a compatible Category and Product Type, enter the pack Size, shelf life, initial selling price and status, then save. PhenyoSync prevents duplicate Product names within the same hierarchy and creates the first versioned price.\n\nSelect Configure Raw Stock Recipe after creation. A recipe describes the Raw Stock needed for one sellable Product unit. For example, one Granny Smith Apples 3 KG Product unit consumes 3 kg of Loose Granny Smith Apples. Make Product multiplies that recipe by the number of units and records Raw Stock movements and a traceable Product Batch.\n\nPermanently delete only unused master data. If a Product, Customer, Supplier, Raw Stock item, Category or Type has operational history, PhenyoSync blocks deletion and offers deactivation so history remains intact.", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), 3, false, true, "add product hierarchy recipe make product unit price safe delete deactivate", "product-production-lifecycle", 60, "Create a sellable Product, configure its Raw Stock recipe and produce traceable batches.", "Add, configure and make Products", null, null },
                    { 39, "OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer", "# Mobile scanning and delivery tracking\nPackers can scan a Product Batch QR with the Android camera or a laptop webcam. If live scanning is unavailable, enter the printed code manually. The server always verifies the Product, batch, order, expiry, available quantity and duplicate-scan rules before progress changes.\n\nDrivers start a dispatched delivery before sharing location. While the delivery page remains open, PhenyoSync sends a first browser or device location immediately and retries foreground updates at a controlled interval. The driver and authorised management maps show the latest timestamp, accuracy, stale state and route trail. For a presentation, browser developer tools may simulate movement; this is test evidence, not physical GPS evidence.\n\nTake or select a delivery proof photo, wait for the successful upload message, name the recipient and confirm the handover before completing the delivery. Google Maps remains available for turn-by-turn navigation.", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), 7, false, true, "packing qr webcam manual scan driver location leaflet map simulated proof", "mobile-scanning-and-tracking", 70, "Use browser or mobile scanning, live foreground tracking and protected proof capture.", "Scan, track and complete deliveries", null, null },
                    { 40, "OperationsManager,BusinessManager,Admin,WarehouseManager", "# Controlled offline data exchange\nProduct and Price offline work uses Excel. Download the current workbook, preserve its template version, validate it, review the staged rows and confirm the exact validated import.\n\nStocktake offline work uses the dedicated JSON package. It contains operational count fields and excludes prices, costs and normal user-facing internal identifiers. Always review the variance preview and business reason before applying a stock count.", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), 4, false, true, "excel product price stocktake json offline validate import export", "offline-data-exchange", 80, "Use the correct controlled Excel and JSON workflow for offline operational data.", "Controlled offline data exchange", null, null }
                });

            migrationBuilder.InsertData(
                table: "HelpContextMappings",
                columns: new[] { "HelpContextMappingId", "ComponentKey", "HelpTopicId", "IsActive", "Priority", "RoutePattern" },
                values: new object[,]
                {
                    { 44, "ProductHierarchy", 38, true, 100, "/product-hierarchy" },
                    { 46, "ProductBatchScanner", 39, true, 100, "/scan-product-batch" },
                    { 47, "MobileOperationsControl", 39, true, 100, "/mobile-operations-control" },
                    { 49, "StockCountDataExchange", 40, true, 100, "/stock-count-data-exchange" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 44);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 46);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 47);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 49);

            migrationBuilder.DeleteData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 38);

            migrationBuilder.DeleteData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 39);

            migrationBuilder.DeleteData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 40);
        }
    }
}
