﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class Subsystem15LogisticsDelivery : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Drivers_Users_UserId",
                table: "Drivers");

            migrationBuilder.RenameIndex(
                name: "IX_Drivers_UserId",
                table: "Drivers",
                newName: "UX_Drivers_UserId");

            migrationBuilder.AlterColumn<string>(
                name: "AvailabilityStatus",
                table: "Drivers",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.CreateTable(
                name: "Deliveries",
                columns: table => new
                {
                    DeliveryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SalesOrderId = table.Column<int>(type: "int", nullable: false),
                    DeliveryAddressSnapshot = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ScheduledStartUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ScheduledEndUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DriverId = table.Column<int>(type: "int", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    AssignedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AssignedByUserId = table.Column<int>(type: "int", nullable: true),
                    StartedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    StartedByUserId = table.Column<int>(type: "int", nullable: true),
                    CompletedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CompletedByUserId = table.Column<int>(type: "int", nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Deliveries", x => x.DeliveryId);
                    table.CheckConstraint("CK_Deliveries_ScheduleWindow", "[ScheduledEndUtc] > [ScheduledStartUtc]");
                    table.CheckConstraint("CK_Deliveries_Status", "[Status] IN ('Scheduled','Assigned','InTransit','Completed','Cancelled')");
                    table.ForeignKey(
                        name: "FK_Deliveries_Drivers_DriverId",
                        column: x => x.DriverId,
                        principalTable: "Drivers",
                        principalColumn: "DriverId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Deliveries_SalesOrders_SalesOrderId",
                        column: x => x.SalesOrderId,
                        principalTable: "SalesOrders",
                        principalColumn: "SalesOrderId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Deliveries_Users_AssignedByUserId",
                        column: x => x.AssignedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Deliveries_Users_CompletedByUserId",
                        column: x => x.CompletedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Deliveries_Users_StartedByUserId",
                        column: x => x.StartedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryCompletionRecords",
                columns: table => new
                {
                    DeliveryCompletionRecordId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DeliveryId = table.Column<int>(type: "int", nullable: false),
                    CompletedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CompletedByUserId = table.Column<int>(type: "int", nullable: true),
                    CompletedByDriverId = table.Column<int>(type: "int", nullable: true),
                    CompletedOnBehalfOfDriver = table.Column<bool>(type: "bit", nullable: false),
                    ManagementOverrideReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RecipientName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    RecipientConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    FulfillmentConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ProofReference = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryCompletionRecords", x => x.DeliveryCompletionRecordId);
                    table.ForeignKey(
                        name: "FK_DeliveryCompletionRecords_Deliveries_DeliveryId",
                        column: x => x.DeliveryId,
                        principalTable: "Deliveries",
                        principalColumn: "DeliveryId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryCompletionRecords_Drivers_CompletedByDriverId",
                        column: x => x.CompletedByDriverId,
                        principalTable: "Drivers",
                        principalColumn: "DriverId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryCompletionRecords_Users_CompletedByUserId",
                        column: x => x.CompletedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryDriverAssignments",
                columns: table => new
                {
                    DeliveryDriverAssignmentId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DeliveryId = table.Column<int>(type: "int", nullable: false),
                    DriverId = table.Column<int>(type: "int", nullable: false),
                    AssignedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AssignedByUserId = table.Column<int>(type: "int", nullable: true),
                    UnassignedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UnassignedByUserId = table.Column<int>(type: "int", nullable: true),
                    AssignmentNotes = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ReassignmentReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IsCurrent = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryDriverAssignments", x => x.DeliveryDriverAssignmentId);
                    table.ForeignKey(
                        name: "FK_DeliveryDriverAssignments_Deliveries_DeliveryId",
                        column: x => x.DeliveryId,
                        principalTable: "Deliveries",
                        principalColumn: "DeliveryId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryDriverAssignments_Drivers_DriverId",
                        column: x => x.DriverId,
                        principalTable: "Drivers",
                        principalColumn: "DriverId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryDriverAssignments_Users_AssignedByUserId",
                        column: x => x.AssignedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryDriverAssignments_Users_UnassignedByUserId",
                        column: x => x.UnassignedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryStatusHistory",
                columns: table => new
                {
                    DeliveryStatusHistoryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DeliveryId = table.Column<int>(type: "int", nullable: false),
                    PreviousStatus = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    NewStatus = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    ChangedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ChangedByUserId = table.Column<int>(type: "int", nullable: true),
                    Reason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Source = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryStatusHistory", x => x.DeliveryStatusHistoryId);
                    table.ForeignKey(
                        name: "FK_DeliveryStatusHistory_Deliveries_DeliveryId",
                        column: x => x.DeliveryId,
                        principalTable: "Deliveries",
                        principalColumn: "DeliveryId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryStatusHistory_Users_ChangedByUserId",
                        column: x => x.ChangedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Drivers_AvailabilityStatus",
                table: "Drivers",
                column: "AvailabilityStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Deliveries_AssignedByUserId",
                table: "Deliveries",
                column: "AssignedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Deliveries_CompletedByUserId",
                table: "Deliveries",
                column: "CompletedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Deliveries_Driver_Window",
                table: "Deliveries",
                columns: new[] { "DriverId", "Status", "ScheduledStartUtc", "ScheduledEndUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_Deliveries_ScheduledEndUtc",
                table: "Deliveries",
                column: "ScheduledEndUtc");

            migrationBuilder.CreateIndex(
                name: "IX_Deliveries_ScheduledStartUtc",
                table: "Deliveries",
                column: "ScheduledStartUtc");

            migrationBuilder.CreateIndex(
                name: "IX_Deliveries_StartedByUserId",
                table: "Deliveries",
                column: "StartedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Deliveries_Status",
                table: "Deliveries",
                column: "Status");

            migrationBuilder.CreateIndex(
                name: "UX_Deliveries_SalesOrderId",
                table: "Deliveries",
                column: "SalesOrderId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryCompletionRecords_CompletedAtUtc",
                table: "DeliveryCompletionRecords",
                column: "CompletedAtUtc");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryCompletionRecords_CompletedByDriverId",
                table: "DeliveryCompletionRecords",
                column: "CompletedByDriverId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryCompletionRecords_CompletedByUserId",
                table: "DeliveryCompletionRecords",
                column: "CompletedByUserId");

            migrationBuilder.CreateIndex(
                name: "UX_DeliveryCompletionRecords_DeliveryId",
                table: "DeliveryCompletionRecords",
                column: "DeliveryId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryDriverAssignments_AssignedByUserId",
                table: "DeliveryDriverAssignments",
                column: "AssignedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryDriverAssignments_DeliveryId",
                table: "DeliveryDriverAssignments",
                column: "DeliveryId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryDriverAssignments_DriverId_IsCurrent_AssignedAtUtc",
                table: "DeliveryDriverAssignments",
                columns: new[] { "DriverId", "IsCurrent", "AssignedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryDriverAssignments_UnassignedByUserId",
                table: "DeliveryDriverAssignments",
                column: "UnassignedByUserId");

            migrationBuilder.CreateIndex(
                name: "UX_DeliveryDriverAssignments_Current",
                table: "DeliveryDriverAssignments",
                columns: new[] { "DeliveryId", "IsCurrent" },
                unique: true,
                filter: "[IsCurrent] = 1");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryStatusHistory_ChangedByUserId",
                table: "DeliveryStatusHistory",
                column: "ChangedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryStatusHistory_DeliveryId_ChangedAtUtc",
                table: "DeliveryStatusHistory",
                columns: new[] { "DeliveryId", "ChangedAtUtc" });

            migrationBuilder.AddForeignKey(
                name: "FK_Drivers_Users_UserId",
                table: "Drivers",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Drivers_Users_UserId",
                table: "Drivers");

            migrationBuilder.DropTable(
                name: "DeliveryCompletionRecords");

            migrationBuilder.DropTable(
                name: "DeliveryDriverAssignments");

            migrationBuilder.DropTable(
                name: "DeliveryStatusHistory");

            migrationBuilder.DropTable(
                name: "Deliveries");

            migrationBuilder.DropIndex(
                name: "IX_Drivers_AvailabilityStatus",
                table: "Drivers");

            migrationBuilder.RenameIndex(
                name: "UX_Drivers_UserId",
                table: "Drivers",
                newName: "IX_Drivers_UserId");

            migrationBuilder.AlterColumn<string>(
                name: "AvailabilityStatus",
                table: "Drivers",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AddForeignKey(
                name: "FK_Drivers_Users_UserId",
                table: "Drivers",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
