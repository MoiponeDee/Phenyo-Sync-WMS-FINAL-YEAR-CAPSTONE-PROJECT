﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class Subsystem11Pricing : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ProductPriceId",
                table: "SalesOrderItems",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ProductPrices",
                columns: table => new
                {
                    ProductPriceId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    SellingPrice = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    EffectiveFromUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EffectiveToUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsCurrent = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedByUserId = table.Column<int>(type: "int", nullable: true),
                    ChangeReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    DeletedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedByUserId = table.Column<int>(type: "int", nullable: true),
                    DeleteReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductPrices", x => x.ProductPriceId);
                    table.ForeignKey(
                        name: "FK_ProductPrices_Product_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductPrices_Users_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductPrices_Users_DeletedByUserId",
                        column: x => x.DeletedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.Sql(
                """
                INSERT INTO [ProductPrices]
                    ([ProductId], [SellingPrice], [EffectiveFromUtc], [EffectiveToUtc],
                     [IsCurrent], [IsDeleted], [CreatedAtUtc], [CreatedByUserId],
                     [ChangeReason], [DeletedAtUtc], [DeletedByUserId], [DeleteReason])
                SELECT
                    [ProductId],
                    [SellingPricePerKg],
                    COALESCE([UpdatedAt], [CreatedAt], SYSUTCDATETIME()),
                    NULL,
                    1,
                    0,
                    SYSUTCDATETIME(),
                    NULL,
                    N'Migrated from the legacy Product selling price.',
                    NULL,
                    NULL,
                    NULL
                FROM [Product]
                WHERE [SellingPricePerKg] > 0;

                UPDATE orderItem
                SET [ProductPriceId] = price.[ProductPriceId]
                FROM [SalesOrderItems] AS orderItem
                INNER JOIN [ProductPrices] AS price
                    ON price.[ProductId] = orderItem.[ProductId]
                   AND price.[IsCurrent] = 1
                   AND price.[IsDeleted] = 0;
                """);

            migrationBuilder.CreateIndex(
                name: "IX_SalesOrderItems_ProductPriceId",
                table: "SalesOrderItems",
                column: "ProductPriceId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductPrices_CreatedByUserId",
                table: "ProductPrices",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductPrices_DeletedByUserId",
                table: "ProductPrices",
                column: "DeletedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductPrices_EffectiveFromUtc",
                table: "ProductPrices",
                column: "EffectiveFromUtc");

            migrationBuilder.CreateIndex(
                name: "IX_ProductPrices_EffectiveToUtc",
                table: "ProductPrices",
                column: "EffectiveToUtc");

            migrationBuilder.CreateIndex(
                name: "IX_ProductPrices_ProductId",
                table: "ProductPrices",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductPrices_SellingPrice",
                table: "ProductPrices",
                column: "SellingPrice");

            migrationBuilder.CreateIndex(
                name: "UX_ProductPrices_Current",
                table: "ProductPrices",
                columns: new[] { "ProductId", "IsCurrent", "IsDeleted" },
                unique: true,
                filter: "[IsCurrent] = 1 AND [IsDeleted] = 0");

            migrationBuilder.AddForeignKey(
                name: "FK_SalesOrderItems_ProductPrices_ProductPriceId",
                table: "SalesOrderItems",
                column: "ProductPriceId",
                principalTable: "ProductPrices",
                principalColumn: "ProductPriceId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SalesOrderItems_ProductPrices_ProductPriceId",
                table: "SalesOrderItems");

            migrationBuilder.DropTable(
                name: "ProductPrices");

            migrationBuilder.DropIndex(
                name: "IX_SalesOrderItems_ProductPriceId",
                table: "SalesOrderItems");

            migrationBuilder.DropColumn(
                name: "ProductPriceId",
                table: "SalesOrderItems");
        }
    }
}
