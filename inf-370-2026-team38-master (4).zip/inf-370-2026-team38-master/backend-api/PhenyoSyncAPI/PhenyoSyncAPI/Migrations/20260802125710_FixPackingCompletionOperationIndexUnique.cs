using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using PhenyoSyncAPI.Data;

#nullable disable

namespace PhenyoSyncAPI.Migrations;

[DbContext(typeof(PhenyoSyncDbContext))]
[Migration("20260802125710_FixPackingCompletionOperationIndexUnique")]
public partial class FixPackingCompletionOperationIndexUnique : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex(
            name: "IX_SalesOrders_PackingCompletionOperationKeyHash",
            table: "SalesOrders");

        migrationBuilder.CreateIndex(
            name: "IX_SalesOrders_PackingCompletionOperationKeyHash",
            table: "SalesOrders",
            column: "PackingCompletionOperationKeyHash",
            unique: true,
            filter: "[PackingCompletionOperationKeyHash] IS NOT NULL");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex(
            name: "IX_SalesOrders_PackingCompletionOperationKeyHash",
            table: "SalesOrders");

        migrationBuilder.CreateIndex(
            name: "IX_SalesOrders_PackingCompletionOperationKeyHash",
            table: "SalesOrders",
            column: "PackingCompletionOperationKeyHash",
            filter: "[PackingCompletionOperationKeyHash] IS NOT NULL");
    }
}
