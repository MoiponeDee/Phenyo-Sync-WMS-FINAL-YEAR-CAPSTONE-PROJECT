﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class PhaseBDataExchangeHierarchyCalendarQr : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CorrelationId",
                table: "StockTakeSessions",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "StockTakeSessionId",
                table: "StockMovements",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<byte[]>(
                name: "RowVersion",
                table: "ProductType",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.AddColumn<byte[]>(
                name: "RowVersion",
                table: "ProductCategory",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.AddColumn<byte[]>(
                name: "RowVersion",
                table: "Product",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.Sql(
                """
                UPDATE dbo.StockTakeSessions
                SET CorrelationId = CONCAT('legacy-stocktake-', SessionId)
                WHERE CorrelationId IS NULL
                   OR LTRIM(RTRIM(CorrelationId)) = '';
                """);

            migrationBuilder.CreateTable(
                name: "DataExchangeJobs",
                columns: table => new
                {
                    DataExchangeJobId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValidationTokenHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    ExchangeType = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    OriginalFileName = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    ContentSha256 = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    StagedPayloadJson = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ResultPayloadJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TotalRows = table.Column<int>(type: "int", nullable: false),
                    ValidRows = table.Column<int>(type: "int", nullable: false),
                    WarningRows = table.Column<int>(type: "int", nullable: false),
                    InvalidRows = table.Column<int>(type: "int", nullable: false),
                    CreatedByUserId = table.Column<int>(type: "int", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExpiresAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AppliedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ApplyReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DataExchangeJobs", x => x.DataExchangeJobId);
                    table.ForeignKey(
                        name: "FK_DataExchangeJobs_Users_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProductCategoryTypes",
                columns: table => new
                {
                    ProductCategoryTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductCategoryId = table.Column<int>(type: "int", nullable: false),
                    ProductTypeId = table.Column<int>(type: "int", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedByUserId = table.Column<int>(type: "int", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductCategoryTypes", x => x.ProductCategoryTypeId);
                    table.ForeignKey(
                        name: "FK_ProductCategoryTypes_ProductCategory_ProductCategoryId",
                        column: x => x.ProductCategoryId,
                        principalTable: "ProductCategory",
                        principalColumn: "ProductCategoryId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductCategoryTypes_ProductType_ProductTypeId",
                        column: x => x.ProductTypeId,
                        principalTable: "ProductType",
                        principalColumn: "ProductTypeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductCategoryTypes_Users_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.Sql(
                """
                INSERT INTO dbo.ProductCategoryTypes
                    (ProductCategoryId, ProductTypeId, CreatedAtUtc, CreatedByUserId)
                SELECT
                    product.ProductCategoryId,
                    product.ProductTypeId,
                    MIN(product.CreatedAt),
                    NULL
                FROM dbo.Product product
                WHERE product.ProductCategoryId IS NOT NULL
                  AND product.ProductTypeId IS NOT NULL
                GROUP BY
                    product.ProductCategoryId,
                    product.ProductTypeId;
                """);

            migrationBuilder.InsertData(
                table: "SystemSettings",
                columns: new[] { "SystemSettingId", "AllowedValuesJson", "Category", "DefaultValue", "Description", "DisplayName", "IsActive", "IsSensitive", "IsSystemSetting", "Key", "MaximumValue", "MinimumValue", "RequiresRestart", "Unit", "UpdatedAtUtc", "UpdatedByUserId", "Value", "ValueType" },
                values: new object[,]
                {
                    { 19, null, "Files", "10", "Maximum accepted Product and Price Excel workbook size.", "Excel import maximum size", true, false, true, "Files.ExcelImportMaximumMb", "50", "1", false, "MB", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "10", "Integer" },
                    { 20, null, "Files", "5", "Maximum accepted Stock Count JSON package size.", "JSON import maximum size", true, false, true, "Files.JsonImportMaximumMb", "25", "1", false, "MB", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "5", "Integer" },
                    { 21, null, "Data exchange", "2000", "Maximum number of rows accepted in one validated import.", "Maximum import rows", true, false, true, "DataExchange.MaximumRows", "10000", "1", false, "rows", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "2000", "Integer" },
                    { 22, null, "Data exchange", "30", "Minutes a validated import remains available for confirmation.", "Validation lifetime", true, false, true, "DataExchange.ValidationLifetimeMinutes", "120", "5", false, "minutes", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "30", "TimeSpanMinutes" },
                    { 23, null, "QR scanning", "3", "Seconds during which a repeated camera scan is ignored.", "Duplicate scan delay", true, false, true, "Qr.DuplicateDelaySeconds", "30", "1", false, "seconds", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "3", "Integer" },
                    { 24, "[\"month\",\"week\",\"day\",\"agenda\"]", "Calendar", "month", "Initial view used by the Operations Calendar.", "Default calendar view", true, false, true, "Calendar.DefaultView", null, null, false, null, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "month", "String" },
                    { 25, null, "Calendar", "93", "Maximum number of days returned by one Operations Calendar query.", "Maximum date range", true, false, true, "Calendar.MaximumDateRangeDays", "366", "7", false, "days", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "93", "Integer" }
                });

            migrationBuilder.Sql(
                """
                DECLARE @PhaseBPermissionSeed TABLE
                (
                    PermissionCode nvarchar(100) NOT NULL,
                    DisplayName nvarchar(120) NOT NULL,
                    Module nvarchar(80) NOT NULL
                );

                INSERT INTO @PhaseBPermissionSeed VALUES
                    ('ProductHierarchy.View', 'View the product hierarchy', 'Product'),
                    ('ProductHierarchy.Manage', 'Manage the product hierarchy', 'Product'),
                    ('ProductDataExchange.Export', 'Export Product and Price workbooks', 'DataExchange'),
                    ('ProductDataExchange.Import', 'Validate and import Product and Price workbooks', 'DataExchange'),
                    ('StockCountExchange.Export', 'Export Stock Count JSON packages', 'DataExchange'),
                    ('StockCountExchange.Import', 'Validate and import Stock Count JSON packages', 'DataExchange'),
                    ('OperationsCalendar.View', 'View the Operations Calendar', 'Operations'),
                    ('ProductBatchScanner.View', 'Resolve Product Batch QR codes', 'Product');

                INSERT INTO dbo.Permissions
                    (PermissionName, PermissionCode, DisplayName, Module,
                     IsSystemPermission, IsActive, CreatedAtUtc)
                SELECT
                    seed.PermissionCode,
                    seed.PermissionCode,
                    seed.DisplayName,
                    seed.Module,
                    1,
                    1,
                    SYSUTCDATETIME()
                FROM @PhaseBPermissionSeed seed
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.Permissions existing
                    WHERE existing.PermissionCode = seed.PermissionCode
                );

                UPDATE permission
                SET
                    permission.PermissionName = seed.PermissionCode,
                    permission.DisplayName = seed.DisplayName,
                    permission.Module = seed.Module,
                    permission.IsSystemPermission = 1,
                    permission.IsActive = 1,
                    permission.UpdatedAtUtc = SYSUTCDATETIME()
                FROM dbo.Permissions permission
                JOIN @PhaseBPermissionSeed seed
                  ON seed.PermissionCode = permission.PermissionCode;

                DECLARE @PhaseBRoleAssignments TABLE
                (
                    RoleCode nvarchar(50) NOT NULL,
                    PermissionCode nvarchar(100) NOT NULL
                );

                INSERT INTO @PhaseBRoleAssignments VALUES
                    ('Admin', 'ProductHierarchy.View'),
                    ('Admin', 'ProductHierarchy.Manage'),
                    ('Admin', 'ProductDataExchange.Export'),
                    ('Admin', 'ProductDataExchange.Import'),
                    ('Admin', 'OperationsCalendar.View'),
                    ('Admin', 'ProductBatchScanner.View'),
                    ('Packer', 'ProductHierarchy.View'),
                    ('Packer', 'OperationsCalendar.View'),
                    ('Packer', 'ProductBatchScanner.View'),
                    ('StockTaker', 'ProductHierarchy.View'),
                    ('StockTaker', 'StockCountExchange.Export'),
                    ('StockTaker', 'StockCountExchange.Import'),
                    ('StockTaker', 'OperationsCalendar.View'),
                    ('StockTaker', 'ProductBatchScanner.View'),
                    ('Driver', 'OperationsCalendar.View');

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT
                    role.RoleId,
                    permission.PermissionId,
                    SYSUTCDATETIME()
                FROM dbo.Roles role
                CROSS JOIN dbo.Permissions permission
                WHERE role.RoleCode IN ('CEO', 'COO', 'BusinessManager')
                  AND permission.PermissionCode IN
                  (
                      'ProductHierarchy.View',
                      'ProductHierarchy.Manage',
                      'ProductDataExchange.Export',
                      'ProductDataExchange.Import',
                      'StockCountExchange.Export',
                      'StockCountExchange.Import',
                      'OperationsCalendar.View',
                      'ProductBatchScanner.View'
                  )
                  AND NOT EXISTS
                  (
                      SELECT 1
                      FROM dbo.RolePermissions existing
                      WHERE existing.RoleId = role.RoleId
                        AND existing.PermissionId = permission.PermissionId
                  );

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT
                    role.RoleId,
                    permission.PermissionId,
                    SYSUTCDATETIME()
                FROM @PhaseBRoleAssignments assignment
                JOIN dbo.Roles role
                  ON role.RoleCode = assignment.RoleCode
                JOIN dbo.Permissions permission
                  ON permission.PermissionCode = assignment.PermissionCode
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.RolePermissions existing
                    WHERE existing.RoleId = role.RoleId
                      AND existing.PermissionId = permission.PermissionId
                );
                """);

            migrationBuilder.CreateIndex(
                name: "UX_StockTakeSessions_CorrelationId",
                table: "StockTakeSessions",
                column: "CorrelationId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_StockMovements_StockTakeSessionId",
                table: "StockMovements",
                column: "StockTakeSessionId");

            migrationBuilder.CreateIndex(
                name: "IX_DataExchangeJobs_CreatedByUserId_ExchangeType_Status_ExpiresAtUtc",
                table: "DataExchangeJobs",
                columns: new[] { "CreatedByUserId", "ExchangeType", "Status", "ExpiresAtUtc" });

            migrationBuilder.CreateIndex(
                name: "UX_DataExchangeJobs_ValidationTokenHash",
                table: "DataExchangeJobs",
                column: "ValidationTokenHash",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProductCategoryTypes_CreatedByUserId",
                table: "ProductCategoryTypes",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductCategoryTypes_ProductTypeId",
                table: "ProductCategoryTypes",
                column: "ProductTypeId");

            migrationBuilder.CreateIndex(
                name: "UX_ProductCategoryTypes_Category_Type",
                table: "ProductCategoryTypes",
                columns: new[] { "ProductCategoryId", "ProductTypeId" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_StockMovements_StockTakeSessions_StockTakeSessionId",
                table: "StockMovements",
                column: "StockTakeSessionId",
                principalTable: "StockTakeSessions",
                principalColumn: "SessionId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                DELETE mapping
                FROM dbo.RolePermissions mapping
                JOIN dbo.Permissions permission
                  ON permission.PermissionId = mapping.PermissionId
                WHERE permission.PermissionCode IN
                (
                    'ProductHierarchy.View',
                    'ProductHierarchy.Manage',
                    'ProductDataExchange.Export',
                    'ProductDataExchange.Import',
                    'StockCountExchange.Export',
                    'StockCountExchange.Import',
                    'OperationsCalendar.View',
                    'ProductBatchScanner.View'
                );

                DELETE FROM dbo.Permissions
                WHERE PermissionCode IN
                (
                    'ProductHierarchy.View',
                    'ProductHierarchy.Manage',
                    'ProductDataExchange.Export',
                    'ProductDataExchange.Import',
                    'StockCountExchange.Export',
                    'StockCountExchange.Import',
                    'OperationsCalendar.View',
                    'ProductBatchScanner.View'
                );
                """);

            migrationBuilder.DropForeignKey(
                name: "FK_StockMovements_StockTakeSessions_StockTakeSessionId",
                table: "StockMovements");

            migrationBuilder.DropTable(
                name: "DataExchangeJobs");

            migrationBuilder.DropTable(
                name: "ProductCategoryTypes");

            migrationBuilder.DropIndex(
                name: "UX_StockTakeSessions_CorrelationId",
                table: "StockTakeSessions");

            migrationBuilder.DropIndex(
                name: "IX_StockMovements_StockTakeSessionId",
                table: "StockMovements");

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 21);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 22);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 23);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 24);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 25);

            migrationBuilder.DropColumn(
                name: "CorrelationId",
                table: "StockTakeSessions");

            migrationBuilder.DropColumn(
                name: "StockTakeSessionId",
                table: "StockMovements");

            migrationBuilder.DropColumn(
                name: "RowVersion",
                table: "ProductType");

            migrationBuilder.DropColumn(
                name: "RowVersion",
                table: "ProductCategory");

            migrationBuilder.DropColumn(
                name: "RowVersion",
                table: "Product");
        }
    }
}
