﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class SellableUnitsAndVatSetting : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "TaxRatePercent",
                table: "SalesOrders",
                type: "decimal(5,2)",
                precision: 5,
                scale: 2,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "KilogramsPerUnitSnapshot",
                table: "SalesOrderItems",
                type: "decimal(18,3)",
                precision: 18,
                scale: 3,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PriceBasisSnapshot",
                table: "SalesOrderItems",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "QuantityUnits",
                table: "SalesOrderItems",
                type: "decimal(18,2)",
                precision: 18,
                scale: 2,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SellingUnitSnapshot",
                table: "SalesOrderItems",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "UnitPrice",
                table: "SalesOrderItems",
                type: "decimal(18,2)",
                precision: 18,
                scale: 2,
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsVariableWeight",
                table: "Product",
                type: "bit",
                nullable: false,
                defaultValue: true);

            migrationBuilder.AddColumn<decimal>(
                name: "KilogramsPerUnit",
                table: "Product",
                type: "decimal(18,3)",
                precision: 18,
                scale: 3,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SellingUnit",
                table: "Product",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: false,
                defaultValue: "kg");

            // Existing products and order lines remain explicitly kilogram based.
            // No pack weight is inferred from the legacy free-text Size field.

            migrationBuilder.InsertData(
                table: "SystemSettings",
                columns: new[] { "SystemSettingId", "AllowedValuesJson", "Category", "DefaultValue", "Description", "DisplayName", "IsActive", "IsSensitive", "IsSystemSetting", "Key", "MaximumValue", "MinimumValue", "RequiresRestart", "Unit", "UpdatedAtUtc", "UpdatedByUserId", "Value", "ValueType" },
                values: new object[] { 61, null, "Orders", "0", "VAT percentage applied when a new or editable customer order is calculated.", "VAT rate (%)", true, false, true, "Orders.VatRatePercent", "100", "0", false, "percent", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "0", "Decimal" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 61);

            migrationBuilder.DropColumn(
                name: "TaxRatePercent",
                table: "SalesOrders");

            migrationBuilder.DropColumn(
                name: "KilogramsPerUnitSnapshot",
                table: "SalesOrderItems");

            migrationBuilder.DropColumn(
                name: "PriceBasisSnapshot",
                table: "SalesOrderItems");

            migrationBuilder.DropColumn(
                name: "QuantityUnits",
                table: "SalesOrderItems");

            migrationBuilder.DropColumn(
                name: "SellingUnitSnapshot",
                table: "SalesOrderItems");

            migrationBuilder.DropColumn(
                name: "UnitPrice",
                table: "SalesOrderItems");

            migrationBuilder.DropColumn(
                name: "IsVariableWeight",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "KilogramsPerUnit",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "SellingUnit",
                table: "Product");
        }
    }
}
