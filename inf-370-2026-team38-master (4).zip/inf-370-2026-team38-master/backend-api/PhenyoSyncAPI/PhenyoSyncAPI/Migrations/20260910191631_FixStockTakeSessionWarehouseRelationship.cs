﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class FixStockTakeSessionWarehouseRelationship : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // The convention-created FK was the authoritative relationship in
            // existing databases. Preserve it in the explicit business column
            // before removing the redundant shadow column.
            migrationBuilder.Sql(
                "UPDATE [StockTakeSessions] " +
                "SET [SectionId] = [WarehouseSectionSectionId];");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTakeSessions_WarehouseSections_WarehouseSectionSectionId",
                table: "StockTakeSessions");

            migrationBuilder.DropIndex(
                name: "IX_StockTakeSessions_WarehouseSectionSectionId",
                table: "StockTakeSessions");

            migrationBuilder.DropColumn(
                name: "WarehouseSectionSectionId",
                table: "StockTakeSessions");

            migrationBuilder.CreateIndex(
                name: "IX_StockTakeSessions_SectionId",
                table: "StockTakeSessions",
                column: "SectionId");

            migrationBuilder.AddForeignKey(
                name: "FK_StockTakeSessions_WarehouseSections_SectionId",
                table: "StockTakeSessions",
                column: "SectionId",
                principalTable: "WarehouseSections",
                principalColumn: "SectionId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_StockTakeSessions_WarehouseSections_SectionId",
                table: "StockTakeSessions");

            migrationBuilder.DropIndex(
                name: "IX_StockTakeSessions_SectionId",
                table: "StockTakeSessions");

            migrationBuilder.AddColumn<int>(
                name: "WarehouseSectionSectionId",
                table: "StockTakeSessions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.Sql(
                "UPDATE [StockTakeSessions] " +
                "SET [WarehouseSectionSectionId] = [SectionId];");

            migrationBuilder.CreateIndex(
                name: "IX_StockTakeSessions_WarehouseSectionSectionId",
                table: "StockTakeSessions",
                column: "WarehouseSectionSectionId");

            migrationBuilder.AddForeignKey(
                name: "FK_StockTakeSessions_WarehouseSections_WarehouseSectionSectionId",
                table: "StockTakeSessions",
                column: "WarehouseSectionSectionId",
                principalTable: "WarehouseSections",
                principalColumn: "SectionId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
