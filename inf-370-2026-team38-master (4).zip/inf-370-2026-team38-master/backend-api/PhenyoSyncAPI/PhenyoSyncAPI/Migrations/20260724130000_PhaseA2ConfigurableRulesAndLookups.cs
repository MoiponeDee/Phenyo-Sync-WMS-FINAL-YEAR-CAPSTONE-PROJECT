﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class PhaseA2ConfigurableRulesAndLookups : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "WarehouseSections",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "SectionName",
                table: "WarehouseSections",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "WarehouseSections",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                table: "WarehouseSections",
                type: "datetime2",
                nullable: false,
                defaultValueSql: "SYSUTCDATETIME()");

            migrationBuilder.AddColumn<byte[]>(
                name: "RowVersion",
                table: "WarehouseSections",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SectionCode",
                table: "WarehouseSections",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "UpdatedAtUtc",
                table: "WarehouseSections",
                type: "datetime2",
                nullable: true);

            migrationBuilder.Sql(
                """
                UPDATE dbo.WarehouseSections
                SET SectionCode = CONCAT('SECTION-', RIGHT(CONCAT('000000', SectionId), 6))
                WHERE SectionCode IS NULL OR LTRIM(RTRIM(SectionCode)) = '';
                """);

            migrationBuilder.AlterColumn<string>(
                name: "SectionCode",
                table: "WarehouseSections",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(40)",
                oldMaxLength: 40,
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "LookupTypes",
                columns: table => new
                {
                    LookupTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SystemCode = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    DisplayName = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IsSystemType = table.Column<bool>(type: "bit", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LookupTypes", x => x.LookupTypeId);
                });

            migrationBuilder.CreateTable(
                name: "SystemSettings",
                columns: table => new
                {
                    SystemSettingId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    Category = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    DisplayName = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ValueType = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Value = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                    DefaultValue = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                    Unit = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: true),
                    MinimumValue = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    MaximumValue = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AllowedValuesJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsSensitive = table.Column<bool>(type: "bit", nullable: false),
                    IsSystemSetting = table.Column<bool>(type: "bit", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    RequiresRestart = table.Column<bool>(type: "bit", nullable: false),
                    UpdatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedByUserId = table.Column<int>(type: "int", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SystemSettings", x => x.SystemSettingId);
                    table.ForeignKey(
                        name: "FK_SystemSettings_Users_UpdatedByUserId",
                        column: x => x.UpdatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "LookupValues",
                columns: table => new
                {
                    LookupValueId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LookupTypeId = table.Column<int>(type: "int", nullable: false),
                    SystemCode = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    DisplayName = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    SortOrder = table.Column<int>(type: "int", nullable: false),
                    IsSystemValue = table.Column<bool>(type: "bit", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LookupValues", x => x.LookupValueId);
                    table.ForeignKey(
                        name: "FK_LookupValues_LookupTypes_LookupTypeId",
                        column: x => x.LookupTypeId,
                        principalTable: "LookupTypes",
                        principalColumn: "LookupTypeId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SystemSettingHistory",
                columns: table => new
                {
                    SystemSettingHistoryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SystemSettingId = table.Column<int>(type: "int", nullable: false),
                    PreviousValue = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                    NewValue = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                    ChangedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ChangedByUserId = table.Column<int>(type: "int", nullable: true),
                    Reason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    AppliedSuccessfully = table.Column<bool>(type: "bit", nullable: false),
                    FailureReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SystemSettingHistory", x => x.SystemSettingHistoryId);
                    table.ForeignKey(
                        name: "FK_SystemSettingHistory_SystemSettings_SystemSettingId",
                        column: x => x.SystemSettingId,
                        principalTable: "SystemSettings",
                        principalColumn: "SystemSettingId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SystemSettingHistory_Users_ChangedByUserId",
                        column: x => x.ChangedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "LookupValueHistory",
                columns: table => new
                {
                    LookupValueHistoryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LookupValueId = table.Column<int>(type: "int", nullable: false),
                    ChangeType = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    BeforeValuesJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AfterValuesJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ChangedByUserId = table.Column<int>(type: "int", nullable: true),
                    ChangedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Reason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LookupValueHistory", x => x.LookupValueHistoryId);
                    table.ForeignKey(
                        name: "FK_LookupValueHistory_LookupValues_LookupValueId",
                        column: x => x.LookupValueId,
                        principalTable: "LookupValues",
                        principalColumn: "LookupValueId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LookupValueHistory_Users_ChangedByUserId",
                        column: x => x.ChangedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "LookupTypes",
                columns: new[] { "LookupTypeId", "CreatedAtUtc", "Description", "DisplayName", "IsActive", "IsSystemType", "SystemCode", "UpdatedAtUtc" },
                values: new object[,]
                {
                    { 1, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Reasons recorded when stock is adjusted or moved.", "Stock movement reasons", true, true, "STOCK_MOVEMENT_REASON", null },
                    { 2, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Approved reasons for final stock write-off.", "Write-off reasons", true, true, "WRITE_OFF_REASON", null },
                    { 3, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Reasons used when a sales order is cancelled.", "Order cancellation reasons", true, true, "ORDER_CANCELLATION_REASON", null },
                    { 4, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Reasons used when an order is rejected during validation.", "Order rejection reasons", true, true, "ORDER_REJECTION_REASON", null },
                    { 5, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Reasons recorded when a delivery cannot be fulfilled.", "Delivery failure reasons", true, true, "DELIVERY_FAILURE_REASON", null },
                    { 6, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Approved customer and supplier payment methods.", "Payment methods", true, true, "PAYMENT_METHOD", null },
                    { 7, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Customer classifications used by operational forms.", "Customer types", true, true, "CUSTOMER_TYPE", null },
                    { 8, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Supplier classifications used by operational forms.", "Supplier types", true, true, "SUPPLIER_TYPE", null },
                    { 9, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Units available for quantities and packaging.", "Units of measure", true, true, "UNIT_OF_MEASURE", null }
                });

            migrationBuilder.InsertData(
                table: "SystemSettings",
                columns: new[] { "SystemSettingId", "AllowedValuesJson", "Category", "DefaultValue", "Description", "DisplayName", "IsActive", "IsSensitive", "IsSystemSetting", "Key", "MaximumValue", "MinimumValue", "RequiresRestart", "Unit", "UpdatedAtUtc", "UpdatedByUserId", "Value", "ValueType" },
                values: new object[,]
                {
                    { 1, null, "Expiry", "72", "Hours before expiry when a batch becomes a yellow warning.", "Yellow warning threshold", true, false, true, "Expiry.YellowThresholdHours", "720", "2", false, "hours", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "72", "TimeSpanHours" },
                    { 2, null, "Expiry", "24", "Hours before expiry when a batch becomes urgent.", "Red urgent threshold", true, false, true, "Expiry.RedThresholdHours", "168", "1", false, "hours", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "24", "TimeSpanHours" },
                    { 3, null, "Expiry", "60", "Minutes between automatic expiry scans.", "Expiry scan interval", true, false, true, "Expiry.ScanIntervalMinutes", "1440", "1", false, "minutes", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "60", "TimeSpanMinutes" },
                    { 4, null, "Expiry", "2", "Days added by a permitted one-time shelf-life extension.", "Shelf-life extension", true, false, true, "Expiry.ShelfLifeExtensionDays", "14", "1", false, "days", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "2", "Integer" },
                    { 5, null, "Expiry", "48", "Hours before a newly generated expiry decision link expires.", "Expiry action-link lifetime", true, false, true, "Expiry.ActionTokenLifetimeHours", "168", "1", false, "hours", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "48", "TimeSpanHours" },
                    { 6, null, "Expiry", "[\"BusinessManager\",\"CEO\",\"COO\",\"StockTaker\"]", "Active role codes that receive new expiry-alert emails.", "Expiry recipient roles", true, false, true, "Expiry.RecipientRoleCodes", null, null, false, null, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "[\"BusinessManager\",\"CEO\",\"COO\",\"StockTaker\"]", "StringArray" },
                    { 7, null, "Orders", "72", "Hours before a newly created customer order link expires.", "Customer order-link lifetime", true, false, true, "Orders.OrderLinkLifetimeHours", "168", "1", false, "hours", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "72", "TimeSpanHours" },
                    { 8, null, "Orders", "0", "Extra hours beyond requested delivery time that reserved batches must remain valid.", "Delivery stock-safety window", true, false, true, "Orders.DeliverySafetyHours", "168", "0", false, "hours", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "0", "TimeSpanHours" },
                    { 9, null, "Delivery", "120", "Duration used for a new schedule when no end time is supplied.", "Default delivery duration", true, false, true, "Delivery.DefaultDurationMinutes", "1440", "15", false, "minutes", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "120", "TimeSpanMinutes" }
                });

            migrationBuilder.InsertData(
                table: "LookupValues",
                columns: new[] { "LookupValueId", "CreatedAtUtc", "Description", "DisplayName", "IsActive", "IsSystemValue", "LookupTypeId", "SortOrder", "SystemCode", "UpdatedAtUtc" },
                values: new object[,]
                {
                    { 1, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Production increase", true, true, 1, 10, "PRODUCTION_INCREASE", null },
                    { 2, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Packing decrease", true, true, 1, 20, "PACKING_DECREASE", null },
                    { 3, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Stock adjustment", true, true, 1, 30, "STOCK_ADJUSTMENT", null },
                    { 4, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Expired stock", true, true, 2, 10, "EXPIRED", null },
                    { 5, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Damaged stock", true, true, 2, 20, "DAMAGED", null },
                    { 6, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Quality inspection failure", true, true, 2, 30, "QUALITY_FAILURE", null },
                    { 7, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Customer request", true, true, 3, 10, "CUSTOMER_REQUEST", null },
                    { 8, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Duplicate order", true, true, 3, 20, "DUPLICATE_ORDER", null },
                    { 9, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Stock unavailable", true, true, 3, 30, "STOCK_UNAVAILABLE", null },
                    { 10, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Insufficient stock", true, true, 4, 10, "INSUFFICIENT_STOCK", null },
                    { 11, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Invalid order details", true, true, 4, 20, "INVALID_DETAILS", null },
                    { 12, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Customer unavailable", true, true, 5, 10, "CUSTOMER_UNAVAILABLE", null },
                    { 13, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Address not found", true, true, 5, 20, "ADDRESS_NOT_FOUND", null },
                    { 14, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Vehicle issue", true, true, 5, 30, "VEHICLE_ISSUE", null },
                    { 15, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Electronic funds transfer", true, true, 6, 10, "EFT", null },
                    { 16, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Card", true, true, 6, 20, "CARD", null },
                    { 17, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Cash", true, true, 6, 30, "CASH", null },
                    { 18, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Retail", true, true, 7, 10, "RETAIL", null },
                    { 19, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Wholesale", true, true, 7, 20, "WHOLESALE", null },
                    { 20, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Distributor", true, true, 7, 30, "DISTRIBUTOR", null },
                    { 21, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Producer", true, true, 8, 10, "PRODUCER", null },
                    { 22, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Distributor", true, true, 8, 20, "DISTRIBUTOR", null },
                    { 23, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Service provider", true, true, 8, 30, "SERVICE_PROVIDER", null },
                    { 24, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Kilogram (kg)", true, true, 9, 10, "KG", null },
                    { 25, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Gram (g)", true, true, 9, 20, "G", null },
                    { 26, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Litre (L)", true, true, 9, 30, "L", null },
                    { 27, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "Unit", true, true, 9, 40, "UNIT", null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_WarehouseSections_Status_SectionName",
                table: "WarehouseSections",
                columns: new[] { "Status", "SectionName" });

            migrationBuilder.CreateIndex(
                name: "UX_WarehouseSections_SectionCode",
                table: "WarehouseSections",
                column: "SectionCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_LookupTypes_IsActive_DisplayName",
                table: "LookupTypes",
                columns: new[] { "IsActive", "DisplayName" });

            migrationBuilder.CreateIndex(
                name: "UX_LookupTypes_SystemCode",
                table: "LookupTypes",
                column: "SystemCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_LookupValueHistory_ChangedByUserId",
                table: "LookupValueHistory",
                column: "ChangedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_LookupValueHistory_LookupValueId_ChangedAtUtc",
                table: "LookupValueHistory",
                columns: new[] { "LookupValueId", "ChangedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_LookupValues_LookupTypeId_IsActive_SortOrder_DisplayName",
                table: "LookupValues",
                columns: new[] { "LookupTypeId", "IsActive", "SortOrder", "DisplayName" });

            migrationBuilder.CreateIndex(
                name: "UX_LookupValues_Type_SystemCode",
                table: "LookupValues",
                columns: new[] { "LookupTypeId", "SystemCode" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_SystemSettingHistory_ChangedByUserId",
                table: "SystemSettingHistory",
                column: "ChangedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SystemSettingHistory_SystemSettingId_ChangedAtUtc",
                table: "SystemSettingHistory",
                columns: new[] { "SystemSettingId", "ChangedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_SystemSettings_Category_IsActive",
                table: "SystemSettings",
                columns: new[] { "Category", "IsActive" });

            migrationBuilder.CreateIndex(
                name: "IX_SystemSettings_UpdatedByUserId",
                table: "SystemSettings",
                column: "UpdatedByUserId");

            migrationBuilder.CreateIndex(
                name: "UX_SystemSettings_Key",
                table: "SystemSettings",
                column: "Key",
                unique: true);

            migrationBuilder.Sql(
                """
                DECLARE @A2PermissionSeed TABLE
                (
                    PermissionCode nvarchar(100) NOT NULL,
                    DisplayName nvarchar(120) NOT NULL
                );
                INSERT INTO @A2PermissionSeed VALUES
                    ('Lookups.View','View operational lookup values'),
                    ('Lookups.Manage','Manage operational lookup values'),
                    ('WarehouseSections.View','View warehouse sections'),
                    ('WarehouseSections.Manage','Manage warehouse sections'),
                    ('SystemSettings.View','View configurable business rules'),
                    ('SystemSettings.Manage','Manage configurable business rules');

                INSERT INTO dbo.Permissions
                    (PermissionName, PermissionCode, DisplayName, Module,
                     IsSystemPermission, IsActive, CreatedAtUtc)
                SELECT seed.PermissionCode, seed.PermissionCode,
                       seed.DisplayName, 'Configuration', 1, 1, SYSUTCDATETIME()
                FROM @A2PermissionSeed seed
                WHERE NOT EXISTS (
                    SELECT 1 FROM dbo.Permissions existing
                    WHERE existing.PermissionCode = seed.PermissionCode);

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
                FROM dbo.Roles role
                JOIN dbo.Permissions permission
                  ON permission.PermissionCode IN
                     ('Lookups.View','Lookups.Manage',
                      'WarehouseSections.View','WarehouseSections.Manage',
                      'SystemSettings.View','SystemSettings.Manage')
                WHERE role.RoleCode IN ('CEO','COO','BusinessManager')
                  AND NOT EXISTS (
                      SELECT 1 FROM dbo.RolePermissions mapping
                      WHERE mapping.RoleId = role.RoleId
                        AND mapping.PermissionId = permission.PermissionId);

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
                FROM dbo.Roles role
                JOIN dbo.Permissions permission
                  ON permission.PermissionCode IN
                     ('Lookups.View','WarehouseSections.View')
                WHERE role.RoleCode IN ('Admin','Packer','StockTaker')
                  AND NOT EXISTS (
                      SELECT 1 FROM dbo.RolePermissions mapping
                      WHERE mapping.RoleId = role.RoleId
                        AND mapping.PermissionId = permission.PermissionId);

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
                FROM dbo.Roles role
                JOIN dbo.Permissions permission
                  ON permission.PermissionCode = 'Lookups.View'
                WHERE role.RoleCode = 'Driver'
                  AND NOT EXISTS (
                      SELECT 1 FROM dbo.RolePermissions mapping
                      WHERE mapping.RoleId = role.RoleId
                        AND mapping.PermissionId = permission.PermissionId);
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LookupValueHistory");

            migrationBuilder.DropTable(
                name: "SystemSettingHistory");

            migrationBuilder.DropTable(
                name: "LookupValues");

            migrationBuilder.DropTable(
                name: "SystemSettings");

            migrationBuilder.DropTable(
                name: "LookupTypes");

            migrationBuilder.DropIndex(
                name: "IX_WarehouseSections_Status_SectionName",
                table: "WarehouseSections");

            migrationBuilder.DropIndex(
                name: "UX_WarehouseSections_SectionCode",
                table: "WarehouseSections");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                table: "WarehouseSections");

            migrationBuilder.DropColumn(
                name: "RowVersion",
                table: "WarehouseSections");

            migrationBuilder.DropColumn(
                name: "SectionCode",
                table: "WarehouseSections");

            migrationBuilder.DropColumn(
                name: "UpdatedAtUtc",
                table: "WarehouseSections");

            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "WarehouseSections",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(20)",
                oldMaxLength: 20);

            migrationBuilder.AlterColumn<string>(
                name: "SectionName",
                table: "WarehouseSections",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "WarehouseSections",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);
        }
    }
}
