﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class ProcurementIntegrationSuperAdminProfileCharts : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "SupplierOrderLineId",
                table: "RawStockReceiptLines",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ProductRawStockRequirements",
                columns: table => new
                {
                    ProductRawStockRequirementId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false),
                    RawQuantityPerProductUnit = table.Column<decimal>(type: "decimal(18,4)", precision: 18, scale: 4, nullable: false),
                    UnitOfMeasure = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    WastePercentage = table.Column<decimal>(type: "decimal(8,4)", precision: 8, scale: 4, nullable: false),
                    YieldPercentage = table.Column<decimal>(type: "decimal(8,4)", precision: 8, scale: 4, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedByUserId = table.Column<int>(type: "int", nullable: false),
                    UpdatedByUserId = table.Column<int>(type: "int", nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductRawStockRequirements", x => x.ProductRawStockRequirementId);
                    table.ForeignKey(
                        name: "FK_ProductRawStockRequirements_Product_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductRawStockRequirements_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductRawStockRequirements_Users_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductRawStockRequirements_Users_UpdatedByUserId",
                        column: x => x.UpdatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceiptLines_SupplierOrderLineId",
                table: "RawStockReceiptLines",
                column: "SupplierOrderLineId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductRawStockRequirements_CreatedByUserId",
                table: "ProductRawStockRequirements",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductRawStockRequirements_RawStockItemId_IsActive",
                table: "ProductRawStockRequirements",
                columns: new[] { "RawStockItemId", "IsActive" });

            migrationBuilder.CreateIndex(
                name: "IX_ProductRawStockRequirements_UpdatedByUserId",
                table: "ProductRawStockRequirements",
                column: "UpdatedByUserId");

            migrationBuilder.CreateIndex(
                name: "UX_ProductRawStockRequirements_Product_RawStock",
                table: "ProductRawStockRequirements",
                columns: new[] { "ProductId", "RawStockItemId" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_RawStockReceiptLines_SupplierOrderLines_SupplierOrderLineId",
                table: "RawStockReceiptLines",
                column: "SupplierOrderLineId",
                principalTable: "SupplierOrderLines",
                principalColumn: "SupplierOrderLineId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.Sql(
                """
                UPDATE dbo.SupplierOrders
                SET Status = CASE
                    WHEN Status IN ('Approved', 'PendingApproval') THEN 'Ordered'
                    ELSE Status
                END
                WHERE Status IN ('Approved', 'PendingApproval');

                DECLARE @AdminRoleId int =
                    (SELECT TOP (1) RoleId FROM dbo.Roles WHERE RoleCode = 'Admin');
                DECLARE @BusinessManagerRoleId int =
                    (SELECT TOP (1) RoleId FROM dbo.Roles WHERE RoleCode = 'BusinessManager');
                DECLARE @ConflictingSuperAdminRoleId int =
                    (SELECT TOP (1) RoleId
                     FROM dbo.Roles
                     WHERE RoleName = 'Super Admin'
                       AND RoleCode <> 'Admin');

                IF @AdminRoleId IS NOT NULL
                BEGIN
                    IF @ConflictingSuperAdminRoleId IS NOT NULL
                    BEGIN
                        INSERT INTO dbo.RolePermissions
                            (RoleId, PermissionId, AssignedAtUtc, AssignedByUserId)
                        SELECT @AdminRoleId, conflicting.PermissionId,
                               SYSUTCDATETIME(), conflicting.AssignedByUserId
                        FROM dbo.RolePermissions conflicting
                        WHERE conflicting.RoleId = @ConflictingSuperAdminRoleId
                          AND NOT EXISTS
                          (
                              SELECT 1
                              FROM dbo.RolePermissions existing
                              WHERE existing.RoleId = @AdminRoleId
                                AND existing.PermissionId = conflicting.PermissionId
                          );

                        UPDATE dbo.Users
                        SET RoleId = @AdminRoleId,
                            UpdatedAtUtc = SYSUTCDATETIME()
                        WHERE RoleId = @ConflictingSuperAdminRoleId;

                        UPDATE dbo.Roles
                        SET RoleName = CONCAT('Legacy Super Admin ', RoleId),
                            Description = 'Retired role retained for migration history. Use Super Admin.',
                            IsActive = 0,
                            IsSystemRole = 0,
                            UpdatedAtUtc = SYSUTCDATETIME()
                        WHERE RoleId = @ConflictingSuperAdminRoleId;
                    END;

                    IF @BusinessManagerRoleId IS NOT NULL AND
                       @BusinessManagerRoleId <> @AdminRoleId
                    BEGIN
                        INSERT INTO dbo.RolePermissions
                            (RoleId, PermissionId, AssignedAtUtc, AssignedByUserId)
                        SELECT @AdminRoleId, legacy.PermissionId,
                               SYSUTCDATETIME(), legacy.AssignedByUserId
                        FROM dbo.RolePermissions legacy
                        WHERE legacy.RoleId = @BusinessManagerRoleId
                          AND NOT EXISTS
                          (
                              SELECT 1
                              FROM dbo.RolePermissions existing
                              WHERE existing.RoleId = @AdminRoleId
                                AND existing.PermissionId = legacy.PermissionId
                          );

                        UPDATE dbo.Users
                        SET RoleId = @AdminRoleId,
                            UpdatedAtUtc = SYSUTCDATETIME()
                        WHERE RoleId = @BusinessManagerRoleId;

                        UPDATE dbo.Roles
                        SET RoleName = 'Legacy Business Manager',
                            Description = 'Retired role retained for migration history. Use Super Admin.',
                            IsActive = 0,
                            IsSystemRole = 0,
                            UpdatedAtUtc = SYSUTCDATETIME()
                        WHERE RoleId = @BusinessManagerRoleId;
                    END;

                    UPDATE dbo.Roles
                    SET RoleName = 'Super Admin',
                        Description = 'Master-data and controlled business-administration role.',
                        IsActive = 1,
                        IsSystemRole = 1,
                        UpdatedAtUtc = SYSUTCDATETIME()
                    WHERE RoleId = @AdminRoleId;

                    INSERT INTO dbo.RolePermissions
                        (RoleId, PermissionId, AssignedAtUtc, AssignedByUserId)
                    SELECT @AdminRoleId, permission.PermissionId,
                           SYSUTCDATETIME(), NULL
                    FROM dbo.Permissions permission
                    WHERE permission.PermissionCode IN
                    (
                        'Customers.View', 'Customers.Manage',
                        'Suppliers.View', 'Suppliers.Manage',
                        'SupplierOrders.View', 'SupplierOrders.Manage',
                        'BuyingList.View', 'BuyingList.ViewAll',
                        'BuyingList.Create', 'BuyingList.UpdateDraft',
                        'BuyingList.DeleteDraft', 'BuyingList.Assign',
                        'BuyingList.Publish', 'BuyingList.Cancel',
                        'Products.View', 'Products.Make', 'Products.Update',
                        'Products.Delete', 'Products.ChangeStatus',
                        'ProductTypes.View', 'ProductTypes.Manage',
                        'ProductCategories.View', 'ProductCategories.Manage',
                        'ProductHierarchy.View', 'ProductHierarchy.Manage',
                        'ProductDataExchange.Export', 'ProductDataExchange.Import',
                        'Orders.View', 'Orders.Create', 'Orders.Update',
                        'Orders.Cancel',
                        'Orders.SendLink', 'Pricing.View', 'Pricing.Create',
                        'Pricing.Cancel', 'Pricing.ViewHistory', 'Pricing.Manage',
                        'Lookups.View', 'Lookups.Manage',
                        'SystemSettings.View', 'SystemSettings.Manage'
                    )
                      AND NOT EXISTS
                      (
                          SELECT 1
                          FROM dbo.RolePermissions existing
                          WHERE existing.RoleId = @AdminRoleId
                            AND existing.PermissionId = permission.PermissionId
                      );
                END;

                DELETE rolePermission
                FROM dbo.RolePermissions rolePermission
                JOIN dbo.Roles role ON role.RoleId = rolePermission.RoleId
                JOIN dbo.Permissions permission
                  ON permission.PermissionId = rolePermission.PermissionId
                WHERE role.RoleCode = 'WarehouseManager'
                  AND permission.PermissionCode IN
                  (
                      'Products.Make', 'Products.Update', 'Products.Delete',
                      'Products.ChangeStatus', 'ProductTypes.Manage',
                      'ProductCategories.Manage', 'ProductHierarchy.Manage',
                      'ProductDataExchange.Export', 'ProductDataExchange.Import'
                  );

                DECLARE @OperationsManagerRoleId int =
                    (SELECT TOP (1) RoleId
                     FROM dbo.Roles
                     WHERE RoleCode = 'OperationsManager');
                IF @OperationsManagerRoleId IS NOT NULL
                BEGIN
                    INSERT INTO dbo.RolePermissions
                        (RoleId, PermissionId, AssignedAtUtc, AssignedByUserId)
                    SELECT @OperationsManagerRoleId, permission.PermissionId,
                           SYSUTCDATETIME(), NULL
                    FROM dbo.Permissions permission
                    WHERE permission.PermissionCode IN
                        ('Orders.Validate', 'Orders.Confirm')
                      AND NOT EXISTS
                      (
                          SELECT 1
                          FROM dbo.RolePermissions existing
                          WHERE existing.RoleId = @OperationsManagerRoleId
                            AND existing.PermissionId = permission.PermissionId
                      );
                END;
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RawStockReceiptLines_SupplierOrderLines_SupplierOrderLineId",
                table: "RawStockReceiptLines");

            migrationBuilder.DropTable(
                name: "ProductRawStockRequirements");

            migrationBuilder.DropIndex(
                name: "IX_RawStockReceiptLines_SupplierOrderLineId",
                table: "RawStockReceiptLines");

            migrationBuilder.DropColumn(
                name: "SupplierOrderLineId",
                table: "RawStockReceiptLines");
        }
    }
}
