using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <summary>
    /// Reconciles the EF model with installations where the populated singular
    /// Product/ProductType/ProductCategory tables predate the migration snapshot.
    /// The embedded deployment is idempotent and never recreates those tables.
    /// </summary>
    public partial class Subsystem7Completion : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            const string resourceName = "PhenyoSyncAPI.Database.Subsystem7Completion.sql";
            using var stream = typeof(Subsystem7Completion).Assembly
                .GetManifestResourceStream(resourceName)
                ?? throw new InvalidOperationException($"Embedded SQL resource '{resourceName}' was not found.");
            using var reader = new StreamReader(stream);
            migrationBuilder.Sql(reader.ReadToEnd(), suppressTransaction: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            throw new NotSupportedException(
                "Subsystem 7 contains inventory audit data. Automatic rollback is intentionally disabled; use an approved data-retention rollback plan.");
        }
    }
}
