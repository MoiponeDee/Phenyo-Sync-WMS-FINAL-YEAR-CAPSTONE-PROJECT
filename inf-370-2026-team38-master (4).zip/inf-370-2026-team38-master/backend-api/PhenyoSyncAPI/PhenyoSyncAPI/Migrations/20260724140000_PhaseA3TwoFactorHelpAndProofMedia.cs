using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using Microsoft.EntityFrameworkCore.Migrations.Operations.Builders;
using PhenyoSyncAPI.Data;

#nullable enable
#pragma warning disable CS8625

namespace PhenyoSyncAPI.Migrations;

[DbContext(typeof(PhenyoSyncDbContext))]
[Migration("20260724140000_PhaseA3TwoFactorHelpAndProofMedia")]
public class PhaseA3TwoFactorHelpAndProofMedia : Migration
{
	protected override void Up(MigrationBuilder migrationBuilder)
	{
		migrationBuilder.Sql("IF EXISTS (\n    SELECT NormalizedEmail\n    FROM dbo.Users\n    GROUP BY NormalizedEmail\n    HAVING COUNT(*) > 1)\n    THROW 51003,\n        'Duplicate user email addresses must be resolved before Phase A3 can be applied.',\n        1;");
		migrationBuilder.CreateTable("HelpCategories", delegate(ColumnsBuilder table)
		{
			OperationBuilder<AddColumnOperation> helpCategoryId = table.Column<int>("int").Annotation("SqlServer:Identity", "1, 1");
			int? maxLength = 80;
			OperationBuilder<AddColumnOperation> systemCode = table.Column<string>("nvarchar(80)", null, maxLength);
			maxLength = 120;
			OperationBuilder<AddColumnOperation> displayName = table.Column<string>("nvarchar(120)", null, maxLength);
			maxLength = 500;
			return new
			{
				HelpCategoryId = helpCategoryId,
				SystemCode = systemCode,
				DisplayName = displayName,
				Description = table.Column<string>("nvarchar(500)", null, maxLength, rowVersion: false, null, nullable: true),
				SortOrder = table.Column<int>("int"),
				IsActive = table.Column<bool>("bit"),
				CreatedAtUtc = table.Column<DateTime>("datetime2"),
				UpdatedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true),
				RowVersion = table.Column<byte[]>("rowversion", null, null, rowVersion: true, null, nullable: true)
			};
		}, null, table =>
		{
			table.PrimaryKey("PK_HelpCategories", x => x.HelpCategoryId);
		});
		migrationBuilder.CreateTable("StoredFiles", delegate(ColumnsBuilder table)
		{
			OperationBuilder<AddColumnOperation> storedFileId = table.Column<long>("bigint").Annotation("SqlServer:Identity", "1, 1");
			int? maxLength = 40;
			OperationBuilder<AddColumnOperation> storageProvider = table.Column<string>("nvarchar(40)", null, maxLength);
			maxLength = 300;
			OperationBuilder<AddColumnOperation> storageKey = table.Column<string>("nvarchar(300)", null, maxLength);
			maxLength = 255;
			OperationBuilder<AddColumnOperation> originalFileName = table.Column<string>("nvarchar(255)", null, maxLength);
			maxLength = 255;
			OperationBuilder<AddColumnOperation> safeDownloadName = table.Column<string>("nvarchar(255)", null, maxLength);
			maxLength = 120;
			OperationBuilder<AddColumnOperation> contentType = table.Column<string>("nvarchar(120)", null, maxLength);
			maxLength = 16;
			OperationBuilder<AddColumnOperation> extension = table.Column<string>("nvarchar(16)", null, maxLength);
			OperationBuilder<AddColumnOperation> sizeBytes = table.Column<long>("bigint");
			maxLength = 64;
			return new
			{
				StoredFileId = storedFileId,
				StorageProvider = storageProvider,
				StorageKey = storageKey,
				OriginalFileName = originalFileName,
				SafeDownloadName = safeDownloadName,
				ContentType = contentType,
				Extension = extension,
				SizeBytes = sizeBytes,
				Sha256Hash = table.Column<string>("nvarchar(64)", null, maxLength),
				UploadedAtUtc = table.Column<DateTime>("datetime2"),
				UploadedByUserId = table.Column<int>("int"),
				IsDeleted = table.Column<bool>("bit"),
				DeletedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true),
				DeletedByUserId = table.Column<int>("int", null, null, rowVersion: false, null, nullable: true),
				RowVersion = table.Column<byte[]>("rowversion", null, null, rowVersion: true, null, nullable: true)
			};
		}, null, table =>
		{
			table.PrimaryKey("PK_StoredFiles", x => x.StoredFileId);
			table.ForeignKey("FK_StoredFiles_Users_DeletedByUserId", x => x.DeletedByUserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_StoredFiles_Users_UploadedByUserId", x => x.UploadedByUserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
		});
		migrationBuilder.CreateTable("TrustedDevices", delegate(ColumnsBuilder table)
		{
			OperationBuilder<AddColumnOperation> trustedDeviceId = table.Column<long>("bigint").Annotation("SqlServer:Identity", "1, 1");
			OperationBuilder<AddColumnOperation> userId = table.Column<int>("int");
			int? maxLength = 64;
			OperationBuilder<AddColumnOperation> tokenHash = table.Column<string>("nvarchar(64)", null, maxLength);
			maxLength = 120;
			OperationBuilder<AddColumnOperation> deviceName = table.Column<string>("nvarchar(120)", null, maxLength);
			maxLength = 256;
			OperationBuilder<AddColumnOperation> userAgentSummary = table.Column<string>("nvarchar(256)", null, maxLength, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> createdAtUtc = table.Column<DateTime>("datetime2");
			OperationBuilder<AddColumnOperation> lastUsedAtUtc = table.Column<DateTime>("datetime2");
			OperationBuilder<AddColumnOperation> expiresAtUtc = table.Column<DateTime>("datetime2");
			OperationBuilder<AddColumnOperation> revokedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> revokedByUserId = table.Column<int>("int", null, null, rowVersion: false, null, nullable: true);
			maxLength = 300;
			return new
			{
				TrustedDeviceId = trustedDeviceId,
				UserId = userId,
				TokenHash = tokenHash,
				DeviceName = deviceName,
				UserAgentSummary = userAgentSummary,
				CreatedAtUtc = createdAtUtc,
				LastUsedAtUtc = lastUsedAtUtc,
				ExpiresAtUtc = expiresAtUtc,
				RevokedAtUtc = revokedAtUtc,
				RevokedByUserId = revokedByUserId,
				RevocationReason = table.Column<string>("nvarchar(300)", null, maxLength, rowVersion: false, null, nullable: true),
				SecurityVersionSnapshot = table.Column<int>("int"),
				RowVersion = table.Column<byte[]>("rowversion", null, null, rowVersion: true, null, nullable: true)
			};
		}, null, table =>
		{
			table.PrimaryKey("PK_TrustedDevices", x => x.TrustedDeviceId);
			table.ForeignKey("FK_TrustedDevices_Users_RevokedByUserId", x => x.RevokedByUserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_TrustedDevices_Users_UserId", x => x.UserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
		});
		migrationBuilder.CreateTable("UserOtpChallenges", delegate(ColumnsBuilder table)
		{
			OperationBuilder<AddColumnOperation> userOtpChallengeId = table.Column<long>("bigint").Annotation("SqlServer:Identity", "1, 1");
			OperationBuilder<AddColumnOperation> userId = table.Column<int>("int");
			int? maxLength = 64;
			OperationBuilder<AddColumnOperation> challengeTokenHash = table.Column<string>("nvarchar(64)", null, maxLength);
			maxLength = 256;
			OperationBuilder<AddColumnOperation> otpHash = table.Column<string>("nvarchar(256)", null, maxLength);
			maxLength = 40;
			OperationBuilder<AddColumnOperation> purpose = table.Column<string>("nvarchar(40)", null, maxLength);
			OperationBuilder<AddColumnOperation> createdAtUtc = table.Column<DateTime>("datetime2");
			OperationBuilder<AddColumnOperation> expiresAtUtc = table.Column<DateTime>("datetime2");
			OperationBuilder<AddColumnOperation> lastSentAtUtc = table.Column<DateTime>("datetime2");
			OperationBuilder<AddColumnOperation> attemptCount = table.Column<int>("int");
			OperationBuilder<AddColumnOperation> maximumAttempts = table.Column<int>("int");
			OperationBuilder<AddColumnOperation> resendCount = table.Column<int>("int");
			OperationBuilder<AddColumnOperation> consumedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> revokedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true);
			maxLength = 160;
			OperationBuilder<AddColumnOperation> failureReason = table.Column<string>("nvarchar(160)", null, maxLength, rowVersion: false, null, nullable: true);
			maxLength = 64;
			OperationBuilder<AddColumnOperation> ipAddressSummary = table.Column<string>("nvarchar(64)", null, maxLength, rowVersion: false, null, nullable: true);
			maxLength = 256;
			OperationBuilder<AddColumnOperation> userAgentSummary = table.Column<string>("nvarchar(256)", null, maxLength, rowVersion: false, null, nullable: true);
			maxLength = 64;
			return new
			{
				UserOtpChallengeId = userOtpChallengeId,
				UserId = userId,
				ChallengeTokenHash = challengeTokenHash,
				OtpHash = otpHash,
				Purpose = purpose,
				CreatedAtUtc = createdAtUtc,
				ExpiresAtUtc = expiresAtUtc,
				LastSentAtUtc = lastSentAtUtc,
				AttemptCount = attemptCount,
				MaximumAttempts = maximumAttempts,
				ResendCount = resendCount,
				ConsumedAtUtc = consumedAtUtc,
				RevokedAtUtc = revokedAtUtc,
				FailureReason = failureReason,
				IpAddressSummary = ipAddressSummary,
				UserAgentSummary = userAgentSummary,
				CorrelationId = table.Column<string>("nvarchar(64)", null, maxLength),
				SecurityVersionSnapshot = table.Column<int>("int"),
				RowVersion = table.Column<byte[]>("rowversion", null, null, rowVersion: true, null, nullable: true)
			};
		}, null, table =>
		{
			table.PrimaryKey("PK_UserOtpChallenges", x => x.UserOtpChallengeId);
			table.ForeignKey("FK_UserOtpChallenges_Users_UserId", x => x.UserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
		});
		migrationBuilder.CreateTable("UserRecoveryCodes", delegate(ColumnsBuilder table)
		{
			OperationBuilder<AddColumnOperation> userRecoveryCodeId = table.Column<long>("bigint").Annotation("SqlServer:Identity", "1, 1");
			OperationBuilder<AddColumnOperation> userId = table.Column<int>("int");
			int? maxLength = 256;
			return new
			{
				UserRecoveryCodeId = userRecoveryCodeId,
				UserId = userId,
				CodeHash = table.Column<string>("nvarchar(256)", null, maxLength),
				CodeOrder = table.Column<int>("int"),
				CreatedAtUtc = table.Column<DateTime>("datetime2"),
				UsedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true),
				RevokedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true),
				SecurityVersionSnapshot = table.Column<int>("int")
			};
		}, null, table =>
		{
			table.PrimaryKey("PK_UserRecoveryCodes", x => x.UserRecoveryCodeId);
			table.ForeignKey("FK_UserRecoveryCodes_Users_UserId", x => x.UserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
		});
		migrationBuilder.CreateTable("HelpTopics", delegate(ColumnsBuilder table)
		{
			OperationBuilder<AddColumnOperation> helpTopicId = table.Column<int>("int").Annotation("SqlServer:Identity", "1, 1");
			OperationBuilder<AddColumnOperation> helpCategoryId = table.Column<int>("int");
			int? maxLength = 160;
			OperationBuilder<AddColumnOperation> slug = table.Column<string>("nvarchar(160)", null, maxLength);
			maxLength = 180;
			OperationBuilder<AddColumnOperation> title = table.Column<string>("nvarchar(180)", null, maxLength);
			maxLength = 600;
			OperationBuilder<AddColumnOperation> summary = table.Column<string>("nvarchar(600)", null, maxLength);
			OperationBuilder<AddColumnOperation> bodyContent = table.Column<string>("nvarchar(max)");
			maxLength = 800;
			OperationBuilder<AddColumnOperation> keywords = table.Column<string>("nvarchar(800)", null, maxLength, rowVersion: false, null, nullable: true);
			maxLength = 500;
			return new
			{
				HelpTopicId = helpTopicId,
				HelpCategoryId = helpCategoryId,
				Slug = slug,
				Title = title,
				Summary = summary,
				BodyContent = bodyContent,
				Keywords = keywords,
				AudienceRolesCsv = table.Column<string>("nvarchar(500)", null, maxLength, rowVersion: false, null, nullable: true),
				IsPublic = table.Column<bool>("bit"),
				IsPublished = table.Column<bool>("bit"),
				SortOrder = table.Column<int>("int"),
				CreatedAtUtc = table.Column<DateTime>("datetime2"),
				UpdatedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true),
				UpdatedByUserId = table.Column<int>("int", null, null, rowVersion: false, null, nullable: true),
				RowVersion = table.Column<byte[]>("rowversion", null, null, rowVersion: true, null, nullable: true)
			};
		}, null, table =>
		{
			table.PrimaryKey("PK_HelpTopics", x => x.HelpTopicId);
			table.ForeignKey("FK_HelpTopics_HelpCategories_HelpCategoryId", x => x.HelpCategoryId, "HelpCategories", "HelpCategoryId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_HelpTopics_Users_UpdatedByUserId", x => x.UpdatedByUserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
		});
		migrationBuilder.CreateTable("DeliveryProofImages", delegate(ColumnsBuilder table)
		{
			OperationBuilder<AddColumnOperation> deliveryProofImageId = table.Column<long>("bigint").Annotation("SqlServer:Identity", "1, 1");
			OperationBuilder<AddColumnOperation> deliveryId = table.Column<int>("int");
			OperationBuilder<AddColumnOperation> storedFileId = table.Column<long>("bigint");
			OperationBuilder<AddColumnOperation> thumbnailStoredFileId = table.Column<long>("bigint", null, null, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> uploadedAtUtc = table.Column<DateTime>("datetime2");
			OperationBuilder<AddColumnOperation> uploadedByUserId = table.Column<int>("int");
			OperationBuilder<AddColumnOperation> uploadedByDriverId = table.Column<int>("int", null, null, rowVersion: false, null, nullable: true);
			int? maxLength = 300;
			OperationBuilder<AddColumnOperation> caption = table.Column<string>("nvarchar(300)", null, maxLength, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> isPrimary = table.Column<bool>("bit");
			OperationBuilder<AddColumnOperation> removedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> removedByUserId = table.Column<int>("int", null, null, rowVersion: false, null, nullable: true);
			maxLength = 500;
			return new
			{
				DeliveryProofImageId = deliveryProofImageId,
				DeliveryId = deliveryId,
				StoredFileId = storedFileId,
				ThumbnailStoredFileId = thumbnailStoredFileId,
				UploadedAtUtc = uploadedAtUtc,
				UploadedByUserId = uploadedByUserId,
				UploadedByDriverId = uploadedByDriverId,
				Caption = caption,
				IsPrimary = isPrimary,
				RemovedAtUtc = removedAtUtc,
				RemovedByUserId = removedByUserId,
				RemovalReason = table.Column<string>("nvarchar(500)", null, maxLength, rowVersion: false, null, nullable: true),
				RowVersion = table.Column<byte[]>("rowversion", null, null, rowVersion: true, null, nullable: true)
			};
		}, null, table =>
		{
			table.PrimaryKey("PK_DeliveryProofImages", x => x.DeliveryProofImageId);
			table.ForeignKey("FK_DeliveryProofImages_Deliveries_DeliveryId", x => x.DeliveryId, "Deliveries", "DeliveryId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_DeliveryProofImages_Drivers_UploadedByDriverId", x => x.UploadedByDriverId, "Drivers", "DriverId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_DeliveryProofImages_StoredFiles_StoredFileId", x => x.StoredFileId, "StoredFiles", "StoredFileId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_DeliveryProofImages_StoredFiles_ThumbnailStoredFileId", x => x.ThumbnailStoredFileId, "StoredFiles", "StoredFileId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_DeliveryProofImages_Users_RemovedByUserId", x => x.RemovedByUserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_DeliveryProofImages_Users_UploadedByUserId", x => x.UploadedByUserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
		});
		migrationBuilder.CreateTable("HelpContextMappings", delegate(ColumnsBuilder table)
		{
			OperationBuilder<AddColumnOperation> helpContextMappingId = table.Column<int>("int").Annotation("SqlServer:Identity", "1, 1");
			OperationBuilder<AddColumnOperation> helpTopicId = table.Column<int>("int");
			int? maxLength = 240;
			OperationBuilder<AddColumnOperation> routePattern = table.Column<string>("nvarchar(240)", null, maxLength);
			maxLength = 120;
			return new
			{
				HelpContextMappingId = helpContextMappingId,
				HelpTopicId = helpTopicId,
				RoutePattern = routePattern,
				ComponentKey = table.Column<string>("nvarchar(120)", null, maxLength, rowVersion: false, null, nullable: true),
				Priority = table.Column<int>("int"),
				IsActive = table.Column<bool>("bit")
			};
		}, null, table =>
		{
			table.PrimaryKey("PK_HelpContextMappings", x => x.HelpContextMappingId);
			table.ForeignKey("FK_HelpContextMappings_HelpTopics_HelpTopicId", x => x.HelpTopicId, "HelpTopics", "HelpTopicId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
		});
		migrationBuilder.CreateTable("HelpMedia", delegate(ColumnsBuilder table)
		{
			OperationBuilder<AddColumnOperation> helpMediaId = table.Column<long>("bigint").Annotation("SqlServer:Identity", "1, 1");
			OperationBuilder<AddColumnOperation> helpTopicId = table.Column<int>("int", null, null, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> storedFileId = table.Column<long>("bigint");
			OperationBuilder<AddColumnOperation> captionStoredFileId = table.Column<long>("bigint", null, null, rowVersion: false, null, nullable: true);
			int? maxLength = 40;
			OperationBuilder<AddColumnOperation> mediaType = table.Column<string>("nvarchar(40)", null, maxLength);
			maxLength = 180;
			OperationBuilder<AddColumnOperation> title = table.Column<string>("nvarchar(180)", null, maxLength);
			maxLength = 1000;
			OperationBuilder<AddColumnOperation> description = table.Column<string>("nvarchar(1000)", null, maxLength, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> transcript = table.Column<string>("nvarchar(max)", null, null, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> isFeatured = table.Column<bool>("bit");
			OperationBuilder<AddColumnOperation> isPublished = table.Column<bool>("bit");
			OperationBuilder<AddColumnOperation> sortOrder = table.Column<int>("int");
			OperationBuilder<AddColumnOperation> createdAtUtc = table.Column<DateTime>("datetime2");
			OperationBuilder<AddColumnOperation> updatedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> uploadedByUserId = table.Column<int>("int");
			OperationBuilder<AddColumnOperation> removedAtUtc = table.Column<DateTime>("datetime2", null, null, rowVersion: false, null, nullable: true);
			OperationBuilder<AddColumnOperation> removedByUserId = table.Column<int>("int", null, null, rowVersion: false, null, nullable: true);
			maxLength = 500;
			return new
			{
				HelpMediaId = helpMediaId,
				HelpTopicId = helpTopicId,
				StoredFileId = storedFileId,
				CaptionStoredFileId = captionStoredFileId,
				MediaType = mediaType,
				Title = title,
				Description = description,
				Transcript = transcript,
				IsFeatured = isFeatured,
				IsPublished = isPublished,
				SortOrder = sortOrder,
				CreatedAtUtc = createdAtUtc,
				UpdatedAtUtc = updatedAtUtc,
				UploadedByUserId = uploadedByUserId,
				RemovedAtUtc = removedAtUtc,
				RemovedByUserId = removedByUserId,
				RemovalReason = table.Column<string>("nvarchar(500)", null, maxLength, rowVersion: false, null, nullable: true),
				RowVersion = table.Column<byte[]>("rowversion", null, null, rowVersion: true, null, nullable: true)
			};
		}, null, table =>
		{
			table.PrimaryKey("PK_HelpMedia", x => x.HelpMediaId);
			table.ForeignKey("FK_HelpMedia_HelpTopics_HelpTopicId", x => x.HelpTopicId, "HelpTopics", "HelpTopicId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_HelpMedia_StoredFiles_CaptionStoredFileId", x => x.CaptionStoredFileId, "StoredFiles", "StoredFileId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_HelpMedia_StoredFiles_StoredFileId", x => x.StoredFileId, "StoredFiles", "StoredFileId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_HelpMedia_Users_RemovedByUserId", x => x.RemovedByUserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
			table.ForeignKey("FK_HelpMedia_Users_UploadedByUserId", x => x.UploadedByUserId, "Users", "UserId", null, ReferentialAction.NoAction, ReferentialAction.Restrict);
		});
		migrationBuilder.InsertData("HelpCategories", new string[8] { "HelpCategoryId", "CreatedAtUtc", "Description", "DisplayName", "IsActive", "SortOrder", "SystemCode", "UpdatedAtUtc" }, new object[8, 8]
		{
			{
				1,
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				"Sign-in, security, navigation and account recovery.",
				"Getting started",
				true,
				10,
				"GETTING_STARTED",
				null
			},
			{
				2,
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				"User, role, permission and security administration.",
				"Users and security",
				true,
				20,
				"SECURITY_ADMIN",
				null
			},
			{
				3,
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				"Product, batch, stock, expiry and label workflows.",
				"Products and stock",
				true,
				30,
				"PRODUCT_STOCK",
				null
			},
			{
				4,
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				"Lookups, warehouse sections and runtime business settings.",
				"Configuration",
				true,
				40,
				"CONFIGURATION",
				null
			},
			{
				5,
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				"Customers, orders, reservations, packing and invoices.",
				"Customers and orders",
				true,
				50,
				"ORDERS",
				null
			},
			{
				6,
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				"Price history and audit-log workflows.",
				"Pricing and accountability",
				true,
				60,
				"PRICING_AUDIT",
				null
			},
			{
				7,
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				"Driver assignment, delivery completion and proof images.",
				"Logistics and delivery",
				true,
				70,
				"DELIVERY",
				null
			},
			{
				8,
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				"Common validation, access, email and file problems.",
				"Troubleshooting",
				true,
				80,
				"TROUBLESHOOTING",
				null
			}
		});
		migrationBuilder.InsertData("SystemSettings", new string[18]
		{
			"SystemSettingId", "AllowedValuesJson", "Category", "DefaultValue", "Description", "DisplayName", "IsActive", "IsSensitive", "IsSystemSetting", "Key",
			"MaximumValue", "MinimumValue", "RequiresRestart", "Unit", "UpdatedAtUtc", "UpdatedByUserId", "Value", "ValueType"
		}, new object[9, 18]
		{
			{
				10,
				null,
				"Security",
				"5",
				"Minutes before a login verification code expires.",
				"OTP lifetime",
				true,
				false,
				true,
				"Security.OtpLifetimeMinutes",
				"15",
				"2",
				false,
				"minutes",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				null,
				"5",
				"TimeSpanMinutes"
			},
			{
				11,
				null,
				"Security",
				"5",
				"Failed verification attempts allowed before a challenge is locked.",
				"OTP maximum attempts",
				true,
				false,
				true,
				"Security.OtpMaximumAttempts",
				"10",
				"3",
				false,
				"attempts",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				null,
				"5",
				"Integer"
			},
			{
				12,
				null,
				"Security",
				"60",
				"Seconds before another verification code may be sent.",
				"OTP resend delay",
				true,
				false,
				true,
				"Security.OtpResendDelaySeconds",
				"300",
				"30",
				false,
				"seconds",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				null,
				"60",
				"Integer"
			},
			{
				13,
				null,
				"Security",
				"5",
				"Verification emails allowed for one account in a rolling hour.",
				"OTP hourly resend limit",
				true,
				false,
				true,
				"Security.OtpMaximumResendsPerHour",
				"10",
				"1",
				false,
				"resends",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				null,
				"5",
				"Integer"
			},
			{
				14,
				null,
				"Security",
				"30",
				"Days before a trusted-device token expires.",
				"Trusted-device lifetime",
				true,
				false,
				true,
				"Security.TrustedDeviceDays",
				"90",
				"1",
				false,
				"days",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				null,
				"30",
				"Integer"
			},
			{
				15,
				null,
				"Security",
				"10",
				"One-time recovery codes generated for a user.",
				"Recovery-code count",
				true,
				false,
				true,
				"Security.RecoveryCodeCount",
				"10",
				"10",
				false,
				"codes",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				null,
				"10",
				"Integer"
			},
			{
				16,
				null,
				"Files",
				"10",
				"Maximum upload size for a delivery proof image.",
				"Proof-image maximum size",
				true,
				false,
				true,
				"Files.ProofImageMaximumMb",
				"25",
				"1",
				false,
				"MB",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				null,
				"10",
				"Integer"
			},
			{
				17,
				null,
				"Files",
				"250",
				"Maximum upload size for a training video.",
				"Training-video maximum size",
				true,
				false,
				true,
				"Files.TrainingVideoMaximumMb",
				"500",
				"10",
				false,
				"MB",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				null,
				"250",
				"Integer"
			},
			{
				18,
				null,
				"Delivery",
				"true",
				"Require an active delivery proof image before final completion.",
				"Require proof image",
				true,
				false,
				true,
				"Delivery.RequireProofImageForCompletion",
				null,
				null,
				false,
				null,
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				null,
				"true",
				"Boolean"
			}
		});
		migrationBuilder.InsertData("HelpTopics", new string[14]
		{
			"HelpTopicId", "AudienceRolesCsv", "BodyContent", "CreatedAtUtc", "HelpCategoryId", "IsPublic", "IsPublished", "Keywords", "Slug", "SortOrder",
			"Summary", "Title", "UpdatedAtUtc", "UpdatedByUserId"
		}, new object[32, 14]
		{
			{
				1,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# Getting started\nSign in with the email address assigned to your user account. PhenyoSync opens the dashboard and actions permitted by your role and permissions.\n\nUse the persistent Help action for guidance on the page you are viewing. Navigation cards and side menus only show authorized workflows. Always sign out when leaving a shared device.\n\nManagement users administer users and configuration. Admin handles operational administration. Packers prepare products and orders, Stock Takers control stock and expiry, and Drivers access only their assigned deliveries.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				1,
				false,
				true,
				"start navigation dashboard sign out role",
				"getting-started",
				10,
				"Learn the main navigation, role dashboards and safe sign-out workflow.",
				"Getting started with PhenyoSync",
				null,
				null
			},
			{
				2,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# Login and email verification\nEnter your email and password. A new or untrusted session receives a six-digit code by email before business access is granted.\n\nThe code expires after five minutes, allows five attempts and can be resent after the displayed countdown. A new resend invalidates the previous code. Never share a password or verification code.\n\nIf email is delayed, check junk mail, confirm the masked destination, wait for the resend timer and request a fresh code.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				1,
				true,
				true,
				"login otp code two factor email resend",
				"login-and-otp",
				20,
				"Sign in with a password, verify a new session by email, and understand OTP limits.",
				"Login and email verification",
				null,
				null
			},
			{
				3,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# Trusted devices\nSelecting Trust this device after OTP stores a protected HttpOnly device token. It bypasses OTP for up to 30 days but never bypasses the password.\n\nOpen Account Security to review device names, last use and expiry. Revoke an unfamiliar device immediately. Password reset, account deactivation, role changes and security-session revocation invalidate trusted devices.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				1,
				false,
				true,
				"trusted device revoke thirty days security",
				"trusted-devices",
				30,
				"Understand the 30-day trusted-device option and revoke devices safely.",
				"Trusted devices",
				null,
				null
			},
			{
				4,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# Recovery codes\nAfter the first successful OTP, PhenyoSync displays ten one-time recovery codes. Save or print them immediately; they cannot be shown again.\n\nUse one code from the login verification screen only when email verification is unavailable. Each code works once. Regenerating codes revokes every unused code from the previous set and requires your current password.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				1,
				false,
				true,
				"recovery code regenerate download print",
				"recovery-codes",
				40,
				"Save, use and regenerate one-time recovery codes.",
				"Recovery codes",
				null,
				null
			},
			{
				5,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# Password reset\nSelect Forgot Password on the login page and enter your account email. For privacy, the same confirmation appears whether or not an account exists.\n\nOpen the email link within 30 minutes, enter matching passwords of at least eight characters and submit once. A successful reset invalidates previous sessions and trusted devices.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				1,
				true,
				true,
				"forgot password reset email expired link",
				"password-reset",
				50,
				"Request and use the secure, expiring password-reset email.",
				"Reset a forgotten password",
				null,
				null
			},
			{
				6,
				"CEO,COO,BusinessManager,Admin",
				"# Manage users\nAuthorized management can search users, create accounts with unique real email addresses, update identity details, assign roles and deactivate or reactivate accounts.\n\nDeactivation blocks new and current sessions without deleting history. Historical users must remain linked to their audit and operational records. Trigger password-reset email instead of setting a password manually.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				2,
				false,
				true,
				"users create update deactivate role password reset",
				"manage-users",
				10,
				"Create, search, update, deactivate and reactivate users safely.",
				"Manage users",
				null,
				null
			},
			{
				7,
				"CEO,COO,BusinessManager,Admin",
				"# Roles and permissions\nRoles group permissions by business responsibility. Create or update custom roles, assign permission checkboxes and inspect a user's effective permissions before changing access.\n\nSystem role codes and system permission codes are protected because APIs depend on them. Unused custom roles may be deactivated or deleted; roles with users or historical references must remain.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				2,
				false,
				true,
				"role permission create assign effective access",
				"roles-and-permissions",
				20,
				"Maintain roles, permission assignments and effective access.",
				"Roles and permissions",
				null,
				null
			},
			{
				8,
				"CEO,COO,BusinessManager,Admin,Packer",
				"# Make products\nSelect an existing product identity or enter name, type, category and size. Enter the produced quantity, warehouse section and packed date.\n\nPhenyoSync reuses an exact matching product identity and always creates a separate physical batch. The batch increases available stock, records a stock movement and calculates expiry from the product shelf life.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				3,
				false,
				true,
				"make product batch quantity stock increase",
				"make-products",
				10,
				"Create or reuse a product and record a new physical batch as stock increase.",
				"Make products and batches",
				null,
				null
			},
			{
				9,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker",
				"# Search and update products\nSearch by product name, type, category, status or QR value. Select a result to view or update it.\n\nProduct changes affect future production, not historical batch snapshots. Use Inactive when a product must stay in history but should not be available for new operations.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				3,
				false,
				true,
				"search product update qr inactive",
				"search-update-products",
				20,
				"Find products by details or QR value and edit valid master data.",
				"Search and update products",
				null,
				null
			},
			{
				10,
				"CEO,COO,BusinessManager,Admin",
				"# Product types and categories\nManagement pages maintain the database values shown in product forms. Names are unique and active entries are available for new products.\n\nA type or category linked to products cannot be permanently removed. Deactivate it instead so history remains valid.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				3,
				false,
				true,
				"product type category crud deactivate",
				"product-types-categories",
				30,
				"Create, edit, activate and dependency-check product classifications.",
				"Product types and categories",
				null,
				null
			},
			{
				11,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker",
				"# QR codes and labels\nEach physical batch receives a scannable QR value. The printable label identifies the product, batch code, packed date and expiry date.\n\nAttach the label to the matching physical stock. Scanning should open or identify that exact batch, not just the product master record.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				3,
				false,
				true,
				"qr code label print batch",
				"qr-labels",
				40,
				"Generate, download and use batch-specific QR labels.",
				"QR codes and labels",
				null,
				null
			},
			{
				12,
				"CEO,COO,BusinessManager,StockTaker",
				"# Stock takes\nStart a stock-take session, capture observed quantities and review discrepancies before posting.\n\nAdjustments require an approved reason and create immutable stock movements. Never edit aggregate stock directly; batch and movement records are the accountability source.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				3,
				false,
				true,
				"stock take adjustment movement discrepancy",
				"stock-take",
				50,
				"Count physical stock and record controlled adjustments.",
				"Stock takes and adjustments",
				null,
				null
			},
			{
				13,
				"CEO,COO,BusinessManager,StockTaker",
				"# Expiry management\nYellow warnings identify batches approaching expiry. Red urgent warnings appear when 24 hours or less remain.\n\nAuthorized users may write off remaining stock or approve the one-time two-day extension after inspection and with a reason. Expired, consumed and written-off batches are excluded from available stock.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				3,
				false,
				true,
				"expiry yellow red urgent write off extension",
				"expiry-actions",
				60,
				"Respond to yellow and urgent expiry alerts safely.",
				"Expiry warnings, write-off and extension",
				null,
				null
			},
			{
				14,
				"CEO,COO,BusinessManager,Admin",
				"# Operational lookups\nLookup values supply controlled options for stock movements, write-offs, order cancellation, delivery failures, payment methods, customer and supplier types, and units of measure.\n\nDisplay names and active status are editable. Protected system codes remain immutable because workflow logic and reporting use them.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				4,
				false,
				true,
				"lookup reason payment method customer supplier unit",
				"operational-lookups",
				10,
				"Maintain approved reasons, payment methods, customer types and units.",
				"Operational lookups",
				null,
				null
			},
			{
				15,
				"CEO,COO,BusinessManager,Admin",
				"# Warehouse sections\nCreate a unique section code, display name and description. Active sections appear in product and stock workflows.\n\nDeactivate a location that should no longer receive stock. Do not delete a section referenced by stock, batches or movements.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				4,
				false,
				true,
				"warehouse section location create deactivate",
				"warehouse-sections",
				20,
				"Maintain warehouse locations without breaking historical stock.",
				"Warehouse sections",
				null,
				null
			},
			{
				16,
				"CEO,COO,BusinessManager,Admin",
				"# System settings\nAuthorized management can edit expiry thresholds, scanning intervals, order-link lifetime, delivery duration, OTP limits and file limits.\n\nValues are type-checked and range-checked. Changes apply immediately through cache invalidation and retain a history with actor, time and reason.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				4,
				false,
				true,
				"settings timers threshold history configuration",
				"system-settings",
				30,
				"Change validated business timers and thresholds immediately.",
				"System settings and history",
				null,
				null
			},
			{
				17,
				"CEO,COO,BusinessManager,Admin",
				"# Customers, suppliers and payments\nUse unique contact details and active classifications when maintaining customers and suppliers. Orders must link to valid customers.\n\nAdmin and authorized management capture and confirm payments. Amounts must be positive and cannot exceed the outstanding invoice. Reversal requires a reason and audit record.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				5,
				false,
				true,
				"customer supplier payment invoice confirm reverse",
				"customers-suppliers-payments",
				10,
				"Maintain parties and capture authorized payments.",
				"Customers, suppliers and payments",
				null,
				null
			},
			{
				18,
				"CEO,COO,BusinessManager,Admin",
				"# Customer order links\nSelect a valid customer, confirm the email address and send the secure order link. The link expires according to the configured lifetime and can be used once.\n\nThe public form exposes only active products with current valid prices. A submitted link cannot be reused.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				5,
				false,
				true,
				"order link customer email one time expiry",
				"order-links",
				20,
				"Generate and email a unique, expiring, one-time order form.",
				"Send customer order links",
				null,
				null
			},
			{
				19,
				"CEO,COO,BusinessManager,Admin",
				"# Create and validate orders\nSelect a customer and add products with positive quantities. Prices are read from the current server-side price record and snapshotted onto order lines.\n\nValidation checks details and uses FEFO to reserve eligible batches atomically. An order cannot be confirmed when stock is insufficient.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				5,
				false,
				true,
				"create order validate stock reserve fefo price",
				"create-validate-orders",
				30,
				"Capture order lines and reserve sufficient eligible stock.",
				"Create and validate orders",
				null,
				null
			},
			{
				20,
				"CEO,COO,BusinessManager,Admin",
				"# Order status and cancellation\nOrders move through the controlled sequence from pending validation to confirmed, packed, out for delivery and delivered.\n\nCancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				5,
				false,
				true,
				"order status cancel reservation release",
				"order-status-cancel",
				40,
				"Follow the valid status sequence and release reservations on cancellation.",
				"Order status and cancellation",
				null,
				null
			},
			{
				21,
				"CEO,COO,BusinessManager,Admin,Packer",
				"# Packing and invoices\nPackers open the packing queue, verify each allocated batch and quantity, then confirm packing once.\n\nPacking decreases stock with movements and creates the order's invoice snapshot. The invoice remains linked to the order and later price changes do not alter it.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				5,
				false,
				true,
				"packing list batch invoice stock decrease",
				"packing-invoices",
				50,
				"Pack allocated batches and view the immutable invoice snapshot.",
				"Packing lists and invoices",
				null,
				null
			},
			{
				22,
				"CEO,COO,BusinessManager,Admin",
				"# Pricing\nA price must be greater than zero and belong to a valid product. Updating a price closes the previous record and creates a new current version.\n\nSoft deletion removes a price from future ordering but preserves its history. Existing order items and invoices retain their snapshotted unit prices.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				6,
				false,
				true,
				"price create update history soft delete current",
				"pricing",
				10,
				"Create current product prices while preserving historical versions.",
				"Pricing and price history",
				null,
				null
			},
			{
				23,
				"CEO,COO,BusinessManager",
				"# Audit logs\nSearch by user, date, action, module, entity, success state, correlation ID or text. Open a result to inspect sanitized before-and-after details.\n\nAudit logs are read-only and retained for accountability. A correlation ID groups changes and security events from the same request or workflow.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				6,
				false,
				true,
				"audit log search correlation activity readonly",
				"audit-logs",
				20,
				"Find read-only accountability records and use correlation IDs.",
				"Search audit logs",
				null,
				null
			},
			{
				24,
				"CEO,COO,BusinessManager,Admin",
				"# Assign drivers\nA packed order may be scheduled for a delivery window. Select an active available driver whose licence covers the full window.\n\nPhenyoSync prevents overlapping assignments and records assignment, reassignment and unassignment history.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				7,
				false,
				true,
				"delivery schedule assign driver availability overlap",
				"assign-drivers",
				10,
				"Schedule deliveries and prevent overlapping driver assignments.",
				"Assign drivers",
				null,
				null
			},
			{
				25,
				"Driver",
				"# My Deliveries\nDrivers see only currently assigned deliveries. Open a record for the schedule, customer, address and order details.\n\nStart the delivery only when it is Assigned. This moves the delivery and order into their in-transit states.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				7,
				false,
				true,
				"driver my deliveries assigned start",
				"my-deliveries",
				20,
				"Review and start only deliveries assigned to your driver account.",
				"Driver: My Deliveries",
				null,
				null
			},
			{
				26,
				"CEO,COO,BusinessManager,Admin,Driver",
				"# Complete a delivery\nUpload one or more JPEG, PNG or WebP proof images, add a useful caption and select the primary image. Confirm the recipient and successful fulfillment.\n\nProof is required by default. The assigned Driver may complete their own in-transit delivery. Authorized management can complete on behalf of a driver or override missing proof only with an explicit reason.\n\nCompletion is final: proof becomes read-only, the delivery records a UTC completion time and the order becomes Delivered.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				7,
				false,
				true,
				"delivery proof image upload complete recipient override",
				"complete-delivery-proof",
				30,
				"Upload protected proof images before final delivery completion.",
				"Complete delivery with proof images",
				null,
				null
			},
			{
				27,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# Validation and server errors\nRead the friendly message and correct every highlighted field. Refresh when a row-version conflict says the record changed.\n\nIf an unexpected server error persists, note the displayed trace ID and the time of the action. Do not send passwords, OTPs or recovery codes to support.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				8,
				true,
				true,
				"validation error trace id conflict support",
				"validation-errors",
				10,
				"Resolve highlighted fields and provide a trace ID when support is needed.",
				"Validation messages and trace IDs",
				null,
				null
			},
			{
				28,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# Permission denied\nMenus and APIs are controlled by database permissions. A denied action means the signed-in role does not currently have that permission.\n\nAsk authorized management to review your effective permissions. Sign out and in again after a role change so the session uses the new security version.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				8,
				false,
				true,
				"permission denied role access 403",
				"permission-denied",
				20,
				"Understand why a page or action is unavailable.",
				"Permission denied",
				null,
				null
			},
			{
				29,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# Expired links\nSecurity links are time-limited and often one-time. Request a new password-reset link, customer order link or expiry review link from the appropriate workflow.\n\nDo not edit tokens in the address bar or share links. A used link cannot be reactivated.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				8,
				true,
				true,
				"expired link used token password order expiry",
				"expired-links",
				30,
				"Recover from password, order or expiry-action links that no longer work.",
				"Expired or used links",
				null,
				null
			},
			{
				30,
				"CEO,COO,BusinessManager,Admin",
				"# Unavailable drivers\nA driver is unavailable when inactive, not marked Available, missing a valid driver-user link, holding an expired licence or already assigned to an overlapping window.\n\nAdjust the schedule, update legitimate driver details or select a different available driver. Do not bypass overlap protection.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				8,
				false,
				true,
				"driver unavailable overlap licence schedule",
				"unavailable-drivers",
				40,
				"Resolve licence, status and schedule conflicts during assignment.",
				"Unavailable drivers",
				null,
				null
			},
			{
				31,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# OTP email not received\nConfirm the masked email destination, check spam, wait for the resend countdown and request one fresh code. Only the newest code is valid.\n\nIf email remains unavailable, use a saved recovery code. Contact management to correct the account email; never create duplicate shared addresses.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				8,
				true,
				true,
				"otp email not received resend recovery",
				"otp-not-received",
				50,
				"Use safe recovery steps when the verification email is delayed.",
				"OTP email not received",
				null,
				null
			},
			{
				32,
				"CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				"# File rejected\nProof images must be genuine JPEG, PNG or WebP files within the configured limit. Training media must be a genuine MP4 or WebM; captions must be WEBVTT.\n\nRenaming an extension does not convert a file. Export the file in an allowed format and retry. Executable, SVG, HTML, polyglot and mismatched files are blocked.",
				new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				8,
				false,
				true,
				"file rejected image video size mime extension",
				"file-rejected",
				60,
				"Resolve protected-file validation failures without weakening security.",
				"A proof image or training video was rejected",
				null,
				null
			}
		});
		migrationBuilder.InsertData("HelpContextMappings", new string[6] { "HelpContextMappingId", "ComponentKey", "HelpTopicId", "IsActive", "Priority", "RoutePattern" }, new object[32, 6]
		{
			{ 1, "AdminDashboard", 1, true, 100, "/admin-dashboard" },
			{ 2, "PackerDashboard", 1, true, 100, "/packer-dashboard" },
			{ 3, "StockTakerDashboard", 1, true, 100, "/stocktaker-dashboard" },
			{ 4, "DriverDashboard", 25, true, 100, "/driver-dashboard" },
			{ 5, "Login", 2, true, 100, "/login" },
			{ 6, "ResetPassword", 5, true, 100, "/reset-password" },
			{ 7, "ManageUsers", 6, true, 100, "/manage-users" },
			{ 8, "ManageRoles", 7, true, 100, "/manage-roles" },
			{ 9, "ManagePermissions", 7, true, 100, "/manage-permissions" },
			{ 10, "MakeProduct", 8, true, 100, "/make-product" },
			{ 11, "SearchProduct", 9, true, 100, "/search-product" },
			{ 12, "UpdateProduct", 9, true, 100, "/update-product" },
			{ 13, "ManageProductTypes", 10, true, 100, "/manage-product-types" },
			{ 14, "ManageProductCategories", 10, true, 100, "/manage-product-categories" },
			{ 15, "StockTake", 12, true, 100, "/stock-take" },
			{ 16, "ExpiryAlerts", 13, true, 100, "/expiry-alerts" },
			{ 17, "ManageLookups", 14, true, 100, "/manage-lookups" },
			{ 18, "WarehouseSections", 15, true, 100, "/manage-warehouse-sections" },
			{ 19, "SystemSettings", 16, true, 100, "/manage-system-settings" },
			{ 20, "SendOrderLink", 18, true, 100, "/send-order-link" },
			{ 21, "OrderEditor", 19, true, 100, "/create-order" },
			{ 22, "OrderDetails", 20, true, 100, "/order-details/:id" },
			{ 23, "PackingOrders", 21, true, 100, "/view-pick-list" },
			{ 24, "OrderInvoice", 21, true, 100, "/order-invoice/:id" },
			{ 25, "PricingManagement", 22, true, 100, "/pricing-management" },
			{ 26, "AuditLogs", 23, true, 100, "/audit-logs" },
			{ 27, "DeliveryManagement", 24, true, 100, "/deliveries" },
			{ 28, "MyDeliveries", 25, true, 100, "/my-deliveries" },
			{ 29, "CompleteDelivery", 26, true, 100, "/deliveries/:id/complete" },
			{ 30, "DeliveryProof", 26, true, 100, "/deliveries/:id/proof" },
			{ 31, "AccountSecurity", 3, true, 100, "/account-security" },
			{ 32, "HelpCenter", 1, true, 50, "/help" }
		});
		migrationBuilder.CreateIndex("IX_DeliveryProofImages_DeliveryId_RemovedAtUtc_UploadedAtUtc", "DeliveryProofImages", new string[3] { "DeliveryId", "RemovedAtUtc", "UploadedAtUtc" });
		migrationBuilder.CreateIndex("IX_DeliveryProofImages_RemovedByUserId", "DeliveryProofImages", "RemovedByUserId");
		migrationBuilder.CreateIndex("IX_DeliveryProofImages_StoredFileId", "DeliveryProofImages", "StoredFileId", null, unique: true);
		migrationBuilder.CreateIndex("IX_DeliveryProofImages_ThumbnailStoredFileId", "DeliveryProofImages", "ThumbnailStoredFileId");
		migrationBuilder.CreateIndex("IX_DeliveryProofImages_UploadedByDriverId", "DeliveryProofImages", "UploadedByDriverId");
		migrationBuilder.CreateIndex("IX_DeliveryProofImages_UploadedByUserId", "DeliveryProofImages", "UploadedByUserId");
		migrationBuilder.CreateIndex("UX_DeliveryProofImages_Primary", "DeliveryProofImages", new string[2] { "DeliveryId", "IsPrimary" }, null, unique: true, "[IsPrimary] = 1 AND [RemovedAtUtc] IS NULL");
		migrationBuilder.CreateIndex("IX_HelpCategories_IsActive_SortOrder_DisplayName", "HelpCategories", new string[3] { "IsActive", "SortOrder", "DisplayName" });
		migrationBuilder.CreateIndex("IX_HelpCategories_SystemCode", "HelpCategories", "SystemCode", null, unique: true);
		migrationBuilder.CreateIndex("IX_HelpContextMappings_HelpTopicId", "HelpContextMappings", "HelpTopicId");
		migrationBuilder.CreateIndex("IX_HelpContextMappings_RoutePattern_ComponentKey_IsActive_Priority", "HelpContextMappings", new string[4] { "RoutePattern", "ComponentKey", "IsActive", "Priority" });
		migrationBuilder.CreateIndex("IX_HelpMedia_CaptionStoredFileId", "HelpMedia", "CaptionStoredFileId");
		migrationBuilder.CreateIndex("IX_HelpMedia_HelpTopicId", "HelpMedia", "HelpTopicId");
		migrationBuilder.CreateIndex("IX_HelpMedia_IsPublished_IsFeatured_SortOrder", "HelpMedia", new string[3] { "IsPublished", "IsFeatured", "SortOrder" });
		migrationBuilder.CreateIndex("IX_HelpMedia_RemovedByUserId", "HelpMedia", "RemovedByUserId");
		migrationBuilder.CreateIndex("IX_HelpMedia_StoredFileId", "HelpMedia", "StoredFileId");
		migrationBuilder.CreateIndex("IX_HelpMedia_UploadedByUserId", "HelpMedia", "UploadedByUserId");
		migrationBuilder.CreateIndex("IX_HelpTopics_HelpCategoryId_IsPublished_SortOrder", "HelpTopics", new string[3] { "HelpCategoryId", "IsPublished", "SortOrder" });
		migrationBuilder.CreateIndex("IX_HelpTopics_Slug", "HelpTopics", "Slug", null, unique: true);
		migrationBuilder.CreateIndex("IX_HelpTopics_UpdatedByUserId", "HelpTopics", "UpdatedByUserId");
		migrationBuilder.CreateIndex("IX_StoredFiles_DeletedByUserId", "StoredFiles", "DeletedByUserId");
		migrationBuilder.CreateIndex("IX_StoredFiles_IsDeleted_UploadedAtUtc", "StoredFiles", new string[2] { "IsDeleted", "UploadedAtUtc" });
		migrationBuilder.CreateIndex("IX_StoredFiles_UploadedByUserId", "StoredFiles", "UploadedByUserId");
		migrationBuilder.CreateIndex("UX_StoredFiles_StorageKey", "StoredFiles", "StorageKey", null, unique: true);
		migrationBuilder.CreateIndex("IX_TrustedDevices_RevokedByUserId", "TrustedDevices", "RevokedByUserId");
		migrationBuilder.CreateIndex("IX_TrustedDevices_UserId_RevokedAtUtc_ExpiresAtUtc", "TrustedDevices", new string[3] { "UserId", "RevokedAtUtc", "ExpiresAtUtc" });
		migrationBuilder.CreateIndex("UX_TrustedDevices_TokenHash", "TrustedDevices", "TokenHash", null, unique: true);
		migrationBuilder.CreateIndex("IX_UserOtpChallenges_UserId_Purpose_ExpiresAtUtc", "UserOtpChallenges", new string[3] { "UserId", "Purpose", "ExpiresAtUtc" });
		migrationBuilder.CreateIndex("UX_UserOtpChallenges_ChallengeHash", "UserOtpChallenges", "ChallengeTokenHash", null, unique: true);
		migrationBuilder.CreateIndex("IX_UserRecoveryCodes_UserId_CodeOrder_CreatedAtUtc", "UserRecoveryCodes", new string[3] { "UserId", "CodeOrder", "CreatedAtUtc" });
		migrationBuilder.Sql("DECLARE @PhaseA3PermissionSeed TABLE\n(\n    PermissionCode nvarchar(100) NOT NULL,\n    DisplayName nvarchar(120) NOT NULL,\n    Module nvarchar(80) NOT NULL\n);\n\nINSERT INTO @PhaseA3PermissionSeed VALUES\n    ('Help.View', 'View Help content', 'Help'),\n    ('Help.Manage', 'Manage Help content', 'Help'),\n    ('HelpMedia.Manage', 'Manage training media', 'Help');\n\nINSERT INTO dbo.Permissions\n    (PermissionName, PermissionCode, DisplayName, Module,\n     IsSystemPermission, IsActive, CreatedAtUtc)\nSELECT seed.PermissionCode, seed.PermissionCode,\n       seed.DisplayName, seed.Module, 1, 1, SYSUTCDATETIME()\nFROM @PhaseA3PermissionSeed seed\nWHERE NOT EXISTS (\n    SELECT 1\n    FROM dbo.Permissions existing\n    WHERE existing.PermissionCode = seed.PermissionCode);\n\nUPDATE permission\nSET permission.PermissionName = seed.PermissionCode,\n    permission.DisplayName = seed.DisplayName,\n    permission.Module = seed.Module,\n    permission.IsSystemPermission = 1,\n    permission.IsActive = 1,\n    permission.UpdatedAtUtc = SYSUTCDATETIME()\nFROM dbo.Permissions permission\nJOIN @PhaseA3PermissionSeed seed\n  ON seed.PermissionCode = permission.PermissionCode;\n\nINSERT INTO dbo.RolePermissions\n    (RoleId, PermissionId, AssignedAtUtc)\nSELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()\nFROM dbo.Roles role\nJOIN dbo.Permissions permission\n  ON permission.PermissionCode IN\n     ('Help.View', 'Help.Manage', 'HelpMedia.Manage')\nWHERE role.RoleCode IN ('CEO', 'COO', 'BusinessManager')\n  AND NOT EXISTS (\n      SELECT 1 FROM dbo.RolePermissions existing\n      WHERE existing.RoleId = role.RoleId\n        AND existing.PermissionId = permission.PermissionId);\n\nINSERT INTO dbo.RolePermissions\n    (RoleId, PermissionId, AssignedAtUtc)\nSELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()\nFROM dbo.Roles role\nJOIN dbo.Permissions permission\n  ON permission.PermissionCode IN\n     ('Help.View', 'Help.Manage', 'HelpMedia.Manage')\nWHERE role.RoleCode = 'Admin'\n  AND NOT EXISTS (\n      SELECT 1 FROM dbo.RolePermissions existing\n      WHERE existing.RoleId = role.RoleId\n        AND existing.PermissionId = permission.PermissionId);\n\nINSERT INTO dbo.RolePermissions\n    (RoleId, PermissionId, AssignedAtUtc)\nSELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()\nFROM dbo.Roles role\nJOIN dbo.Permissions permission\n  ON permission.PermissionCode = 'Help.View'\nWHERE role.RoleCode IN ('Packer', 'StockTaker', 'Driver')\n  AND NOT EXISTS (\n      SELECT 1 FROM dbo.RolePermissions existing\n      WHERE existing.RoleId = role.RoleId\n        AND existing.PermissionId = permission.PermissionId);");
	}

	protected override void Down(MigrationBuilder migrationBuilder)
	{
		migrationBuilder.Sql("DELETE mapping\nFROM dbo.RolePermissions mapping\nJOIN dbo.Permissions permission\n  ON permission.PermissionId = mapping.PermissionId\nWHERE permission.PermissionCode IN\n    ('Help.View', 'Help.Manage', 'HelpMedia.Manage');\n\nDELETE FROM dbo.Permissions\nWHERE PermissionCode IN\n    ('Help.View', 'Help.Manage', 'HelpMedia.Manage');");
		migrationBuilder.DropTable("DeliveryProofImages");
		migrationBuilder.DropTable("HelpContextMappings");
		migrationBuilder.DropTable("HelpMedia");
		migrationBuilder.DropTable("TrustedDevices");
		migrationBuilder.DropTable("UserOtpChallenges");
		migrationBuilder.DropTable("UserRecoveryCodes");
		migrationBuilder.DropTable("HelpTopics");
		migrationBuilder.DropTable("StoredFiles");
		migrationBuilder.DropTable("HelpCategories");
		migrationBuilder.DeleteData("SystemSettings", "SystemSettingId", 10);
		migrationBuilder.DeleteData("SystemSettings", "SystemSettingId", 11);
		migrationBuilder.DeleteData("SystemSettings", "SystemSettingId", 12);
		migrationBuilder.DeleteData("SystemSettings", "SystemSettingId", 13);
		migrationBuilder.DeleteData("SystemSettings", "SystemSettingId", 14);
		migrationBuilder.DeleteData("SystemSettings", "SystemSettingId", 15);
		migrationBuilder.DeleteData("SystemSettings", "SystemSettingId", 16);
		migrationBuilder.DeleteData("SystemSettings", "SystemSettingId", 17);
		migrationBuilder.DeleteData("SystemSettings", "SystemSettingId", 18);
	}

	protected override void BuildTargetModel(ModelBuilder modelBuilder)
	{
		modelBuilder.HasAnnotation("ProductVersion", "8.0.0").HasAnnotation("Relational:MaxIdentifierLength", 128);
		modelBuilder.UseIdentityColumns(1L);
		modelBuilder.Entity("PhenyoSyncAPI.Entities.AuditLog", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("AuditLogId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("AuditLogId").UseIdentityColumn(1L);
			b.Property<string>("ActionType").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<string>("ActorType").IsRequired().HasMaxLength(32)
				.HasColumnType("nvarchar(32)");
			b.Property<string>("AfterValuesJson").HasColumnType("nvarchar(max)");
			b.Property<string>("BeforeValuesJson").HasColumnType("nvarchar(max)");
			b.Property<string>("ChangedFieldsJson").HasColumnType("nvarchar(max)");
			b.Property<string>("CorrelationId").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<string>("Description").IsRequired().HasMaxLength(1000)
				.HasColumnType("nvarchar(1000)");
			b.Property<string>("EntityDisplay").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("EntityId").HasMaxLength(256).HasColumnType("nvarchar(256)");
			b.Property<string>("EntityType").HasMaxLength(128).HasColumnType("nvarchar(128)");
			b.Property<string>("EventSource").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<string>("FailureReason").HasMaxLength(1000).HasColumnType("nvarchar(1000)");
			b.Property<string>("HttpMethod").HasMaxLength(10).HasColumnType("nvarchar(10)");
			b.Property<string>("IpAddress").HasMaxLength(64).HasColumnType("nvarchar(64)");
			b.Property<DateTime>("OccurredAtUtc").HasPrecision(7).HasColumnType("datetime2(7)");
			b.Property<string>("OperationName").IsRequired().HasMaxLength(160)
				.HasColumnType("nvarchar(160)");
			b.Property<string>("RequestPath").HasMaxLength(512).HasColumnType("nvarchar(512)");
			b.Property<bool>("Success").HasColumnType("bit");
			b.Property<string>("SystemModule").IsRequired().HasMaxLength(80)
				.HasColumnType("nvarchar(80)");
			b.Property<string>("UserAgent").HasMaxLength(512).HasColumnType("nvarchar(512)");
			b.Property<string>("UserDisplayNameSnapshot").HasMaxLength(200).HasColumnType("nvarchar(200)");
			b.Property<string>("UserEmailSnapshot").HasMaxLength(320).HasColumnType("nvarchar(320)");
			b.Property<int?>("UserId").HasColumnType("int");
			b.Property<string>("UserRoleSnapshot").HasMaxLength(100).HasColumnType("nvarchar(100)");
			b.HasKey("AuditLogId");
			b.HasIndex("CorrelationId").HasDatabaseName("IX_AuditLogs_CorrelationId");
			b.HasIndex("OccurredAtUtc").IsDescending().HasDatabaseName("IX_AuditLogs_OccurredAtUtc");
			b.HasIndex("ActionType", "OccurredAtUtc").IsDescending(false, true).HasDatabaseName("IX_AuditLogs_Action_OccurredAtUtc");
			b.HasIndex("EntityType", "EntityId").HasDatabaseName("IX_AuditLogs_Entity");
			b.HasIndex("Success", "OccurredAtUtc").IsDescending(false, true).HasDatabaseName("IX_AuditLogs_Success_OccurredAtUtc");
			b.HasIndex("SystemModule", "OccurredAtUtc").IsDescending(false, true).HasDatabaseName("IX_AuditLogs_Module_OccurredAtUtc");
			b.HasIndex("UserId", "OccurredAtUtc").IsDescending(false, true).HasDatabaseName("IX_AuditLogs_User_OccurredAtUtc");
			b.ToTable("AuditLogs", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Businessmanager", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("BusinessManagerId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("BusinessManagerId").UseIdentityColumn(1L);
			b.Property<string>("Department").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<DateTime?>("EmploymentDate").HasColumnType("datetime2");
			b.Property<string>("ManagedSection").HasColumnType("nvarchar(max)");
			b.Property<string>("OfficeNumber").HasColumnType("nvarchar(max)");
			b.Property<int>("UserId").HasColumnType("int");
			b.HasKey("BusinessManagerId");
			b.HasIndex("UserId");
			b.ToTable("BusinessManagers");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.CEO", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("CEOId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("CEOId").UseIdentityColumn(1L);
			b.Property<DateTime?>("AppointmentDate").HasColumnType("datetime2");
			b.Property<string>("OfficeNumber").HasColumnType("nvarchar(max)");
			b.Property<int>("UserId").HasColumnType("int");
			b.HasKey("CEOId");
			b.HasIndex("UserId");
			b.ToTable("CEOs");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.COO", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("COOId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("COOId").UseIdentityColumn(1L);
			b.Property<DateTime?>("AppointmentDate").HasColumnType("datetime2");
			b.Property<string>("OfficeNumber").HasColumnType("nvarchar(max)");
			b.Property<int>("UserId").HasColumnType("int");
			b.HasKey("COOId");
			b.HasIndex("UserId");
			b.ToTable("COOs");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Customer", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("CustomerId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("CustomerId").UseIdentityColumn(1L);
			b.Property<string>("BillingAddress").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("CustomerName").IsRequired().HasMaxLength(150)
				.HasColumnType("nvarchar(150)");
			b.Property<string>("CustomerNumber").IsRequired().HasMaxLength(30)
				.HasColumnType("nvarchar(30)");
			b.Property<string>("DeliveryAddress").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("Email").IsRequired().HasMaxLength(254)
				.HasColumnType("nvarchar(254)");
			b.Property<string>("PhoneNumber").HasMaxLength(30).HasColumnType("nvarchar(30)");
			b.Property<string>("Status").IsRequired().HasMaxLength(20)
				.HasColumnType("nvarchar(20)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.HasKey("CustomerId");
			b.HasIndex("CustomerNumber").IsUnique();
			b.HasIndex("Email");
			b.HasIndex("Status", "CustomerName");
			b.ToTable("Customers", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.CustomerOrderLink", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("CustomerOrderLinkId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("CustomerOrderLinkId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<int>("CreatedByUserId").HasColumnType("int");
			b.Property<int>("CustomerId").HasColumnType("int");
			b.Property<DateTime?>("EmailSentAtUtc").HasColumnType("datetime2");
			b.Property<DateTime>("ExpiresAtUtc").HasColumnType("datetime2");
			b.Property<DateTime?>("RevokedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("SalesOrderId").HasColumnType("int");
			b.Property<string>("TokenHash").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<DateTime?>("UsedAtUtc").HasColumnType("datetime2");
			b.HasKey("CustomerOrderLinkId");
			b.HasIndex("CreatedByUserId");
			b.HasIndex("ExpiresAtUtc");
			b.HasIndex("SalesOrderId").IsUnique().HasFilter("[SalesOrderId] IS NOT NULL");
			b.HasIndex("TokenHash").IsUnique();
			b.HasIndex("CustomerId", "CreatedAtUtc");
			b.ToTable("CustomerOrderLinks", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Delivery", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("DeliveryId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("DeliveryId").UseIdentityColumn(1L);
			b.Property<DateTime?>("AssignedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("AssignedByUserId").HasColumnType("int");
			b.Property<DateTime?>("CompletedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("CompletedByUserId").HasColumnType("int");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("DeliveryAddressSnapshot").IsRequired().HasMaxLength(500)
				.HasColumnType("nvarchar(500)");
			b.Property<int?>("DriverId").HasColumnType("int");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<int>("SalesOrderId").HasColumnType("int");
			b.Property<DateTime>("ScheduledEndUtc").HasColumnType("datetime2");
			b.Property<DateTime>("ScheduledStartUtc").HasColumnType("datetime2");
			b.Property<DateTime?>("StartedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("StartedByUserId").HasColumnType("int");
			b.Property<string>("Status").IsRequired().HasMaxLength(30)
				.HasColumnType("nvarchar(30)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.HasKey("DeliveryId");
			b.HasIndex("AssignedByUserId");
			b.HasIndex("CompletedByUserId");
			b.HasIndex("SalesOrderId").IsUnique().HasDatabaseName("UX_Deliveries_SalesOrderId");
			b.HasIndex("ScheduledEndUtc");
			b.HasIndex("ScheduledStartUtc");
			b.HasIndex("StartedByUserId");
			b.HasIndex("Status");
			b.HasIndex("DriverId", "Status", "ScheduledStartUtc", "ScheduledEndUtc").HasDatabaseName("IX_Deliveries_Driver_Window");
			b.ToTable("Deliveries", null, delegate(TableBuilder t)
			{
				t.HasCheckConstraint("CK_Deliveries_ScheduleWindow", "[ScheduledEndUtc] > [ScheduledStartUtc]");
				t.HasCheckConstraint("CK_Deliveries_Status", "[Status] IN ('Scheduled','Assigned','InTransit','Completed','Cancelled')");
			});
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.DeliveryCompletionRecord", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("DeliveryCompletionRecordId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("DeliveryCompletionRecordId").UseIdentityColumn(1L);
			b.Property<DateTime>("CompletedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("CompletedByDriverId").HasColumnType("int");
			b.Property<int?>("CompletedByUserId").HasColumnType("int");
			b.Property<bool>("CompletedOnBehalfOfDriver").HasColumnType("bit");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<int>("DeliveryId").HasColumnType("int");
			b.Property<bool>("FulfillmentConfirmed").HasColumnType("bit");
			b.Property<string>("ManagementOverrideReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("Notes").HasMaxLength(1000).HasColumnType("nvarchar(1000)");
			b.Property<string>("ProofReference").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<bool>("RecipientConfirmed").HasColumnType("bit");
			b.Property<string>("RecipientName").IsRequired().HasMaxLength(200)
				.HasColumnType("nvarchar(200)");
			b.HasKey("DeliveryCompletionRecordId");
			b.HasIndex("CompletedAtUtc");
			b.HasIndex("CompletedByDriverId");
			b.HasIndex("CompletedByUserId");
			b.HasIndex("DeliveryId").IsUnique().HasDatabaseName("UX_DeliveryCompletionRecords_DeliveryId");
			b.ToTable("DeliveryCompletionRecords", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.DeliveryDriverAssignment", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("DeliveryDriverAssignmentId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("DeliveryDriverAssignmentId").UseIdentityColumn(1L);
			b.Property<DateTime>("AssignedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("AssignedByUserId").HasColumnType("int");
			b.Property<string>("AssignmentNotes").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<int>("DeliveryId").HasColumnType("int");
			b.Property<int>("DriverId").HasColumnType("int");
			b.Property<bool>("IsCurrent").HasColumnType("bit");
			b.Property<string>("ReassignmentReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<DateTime?>("UnassignedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("UnassignedByUserId").HasColumnType("int");
			b.HasKey("DeliveryDriverAssignmentId");
			b.HasIndex("AssignedByUserId");
			b.HasIndex("DeliveryId");
			b.HasIndex("UnassignedByUserId");
			b.HasIndex("DeliveryId", "IsCurrent").IsUnique().HasDatabaseName("UX_DeliveryDriverAssignments_Current")
				.HasFilter("[IsCurrent] = 1");
			b.HasIndex("DriverId", "IsCurrent", "AssignedAtUtc");
			b.ToTable("DeliveryDriverAssignments", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.DeliveryProofImage", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("DeliveryProofImageId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("DeliveryProofImageId").UseIdentityColumn(1L);
			b.Property<string>("Caption").HasMaxLength(300).HasColumnType("nvarchar(300)");
			b.Property<int>("DeliveryId").HasColumnType("int");
			b.Property<bool>("IsPrimary").HasColumnType("bit");
			b.Property<string>("RemovalReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<DateTime?>("RemovedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("RemovedByUserId").HasColumnType("int");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<long>("StoredFileId").HasColumnType("bigint");
			b.Property<long?>("ThumbnailStoredFileId").HasColumnType("bigint");
			b.Property<DateTime>("UploadedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("UploadedByDriverId").HasColumnType("int");
			b.Property<int>("UploadedByUserId").HasColumnType("int");
			b.HasKey("DeliveryProofImageId");
			b.HasIndex("RemovedByUserId");
			b.HasIndex("StoredFileId").IsUnique();
			b.HasIndex("ThumbnailStoredFileId");
			b.HasIndex("UploadedByDriverId");
			b.HasIndex("UploadedByUserId");
			b.HasIndex("DeliveryId", "IsPrimary").IsUnique().HasDatabaseName("UX_DeliveryProofImages_Primary")
				.HasFilter("[IsPrimary] = 1 AND [RemovedAtUtc] IS NULL");
			b.HasIndex("DeliveryId", "RemovedAtUtc", "UploadedAtUtc");
			b.ToTable("DeliveryProofImages", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.DeliveryStatusHistory", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("DeliveryStatusHistoryId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("DeliveryStatusHistoryId").UseIdentityColumn(1L);
			b.Property<DateTime>("ChangedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("ChangedByUserId").HasColumnType("int");
			b.Property<int>("DeliveryId").HasColumnType("int");
			b.Property<string>("NewStatus").IsRequired().HasMaxLength(30)
				.HasColumnType("nvarchar(30)");
			b.Property<string>("PreviousStatus").HasMaxLength(30).HasColumnType("nvarchar(30)");
			b.Property<string>("Reason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("Source").IsRequired().HasMaxLength(80)
				.HasColumnType("nvarchar(80)");
			b.HasKey("DeliveryStatusHistoryId");
			b.HasIndex("ChangedByUserId");
			b.HasIndex("DeliveryId", "ChangedAtUtc");
			b.ToTable("DeliveryStatusHistory", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Driver", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("DriverId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("DriverId").UseIdentityColumn(1L);
			b.Property<string>("AvailabilityStatus").IsRequired().HasMaxLength(100)
				.HasColumnType("nvarchar(100)");
			b.Property<DateTime?>("LicenseExpiryDate").HasColumnType("datetime2");
			b.Property<string>("LicenseNumber").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<int>("UserId").HasColumnType("int");
			b.Property<string>("VehicleAssigned").HasColumnType("nvarchar(max)");
			b.HasKey("DriverId");
			b.HasIndex("AvailabilityStatus");
			b.HasIndex("UserId").IsUnique().HasDatabaseName("UX_Drivers_UserId");
			b.ToTable("Drivers", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ExpiryActionToken", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("ExpiryActionTokenId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("ExpiryActionTokenId").UseIdentityColumn(1L);
			b.Property<string>("AlertLevel").IsRequired().HasMaxLength(30)
				.HasColumnType("nvarchar(30)");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<DateTime>("ExpiresAtUtc").HasColumnType("datetime2");
			b.Property<DateTime?>("InvalidatedAtUtc").HasColumnType("datetime2");
			b.Property<int>("ProductBatchId").HasColumnType("int");
			b.Property<string>("TokenHash").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<DateTime?>("UsedAtUtc").HasColumnType("datetime2");
			b.HasKey("ExpiryActionTokenId");
			b.HasIndex("TokenHash").IsUnique();
			b.HasIndex("ProductBatchId", "ExpiresAtUtc", "UsedAtUtc", "InvalidatedAtUtc");
			b.ToTable("ExpiryActionTokens", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.HelpCategory", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("HelpCategoryId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("HelpCategoryId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("Description").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("DisplayName").IsRequired().HasMaxLength(120)
				.HasColumnType("nvarchar(120)");
			b.Property<bool>("IsActive").HasColumnType("bit");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<int>("SortOrder").HasColumnType("int");
			b.Property<string>("SystemCode").IsRequired().HasMaxLength(80)
				.HasColumnType("nvarchar(80)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.HasKey("HelpCategoryId");
			b.HasIndex("SystemCode").IsUnique();
			b.HasIndex("IsActive", "SortOrder", "DisplayName");
			b.ToTable("HelpCategories", (string?)null);
			b.HasData(new
			{
				HelpCategoryId = 1,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Sign-in, security, navigation and account recovery.",
				DisplayName = "Getting started",
				IsActive = true,
				SortOrder = 10,
				SystemCode = "GETTING_STARTED"
			}, new
			{
				HelpCategoryId = 2,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "User, role, permission and security administration.",
				DisplayName = "Users and security",
				IsActive = true,
				SortOrder = 20,
				SystemCode = "SECURITY_ADMIN"
			}, new
			{
				HelpCategoryId = 3,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Product, batch, stock, expiry and label workflows.",
				DisplayName = "Products and stock",
				IsActive = true,
				SortOrder = 30,
				SystemCode = "PRODUCT_STOCK"
			}, new
			{
				HelpCategoryId = 4,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Lookups, warehouse sections and runtime business settings.",
				DisplayName = "Configuration",
				IsActive = true,
				SortOrder = 40,
				SystemCode = "CONFIGURATION"
			}, new
			{
				HelpCategoryId = 5,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Customers, orders, reservations, packing and invoices.",
				DisplayName = "Customers and orders",
				IsActive = true,
				SortOrder = 50,
				SystemCode = "ORDERS"
			}, new
			{
				HelpCategoryId = 6,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Price history and audit-log workflows.",
				DisplayName = "Pricing and accountability",
				IsActive = true,
				SortOrder = 60,
				SystemCode = "PRICING_AUDIT"
			}, new
			{
				HelpCategoryId = 7,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Driver assignment, delivery completion and proof images.",
				DisplayName = "Logistics and delivery",
				IsActive = true,
				SortOrder = 70,
				SystemCode = "DELIVERY"
			}, new
			{
				HelpCategoryId = 8,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Common validation, access, email and file problems.",
				DisplayName = "Troubleshooting",
				IsActive = true,
				SortOrder = 80,
				SystemCode = "TROUBLESHOOTING"
			});
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.HelpContextMapping", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("HelpContextMappingId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("HelpContextMappingId").UseIdentityColumn(1L);
			b.Property<string>("ComponentKey").HasMaxLength(120).HasColumnType("nvarchar(120)");
			b.Property<int>("HelpTopicId").HasColumnType("int");
			b.Property<bool>("IsActive").HasColumnType("bit");
			b.Property<int>("Priority").HasColumnType("int");
			b.Property<string>("RoutePattern").IsRequired().HasMaxLength(240)
				.HasColumnType("nvarchar(240)");
			b.HasKey("HelpContextMappingId");
			b.HasIndex("HelpTopicId");
			b.HasIndex("RoutePattern", "ComponentKey", "IsActive", "Priority");
			b.ToTable("HelpContextMappings", (string?)null);
			b.HasData(new
			{
				HelpContextMappingId = 1,
				ComponentKey = "AdminDashboard",
				HelpTopicId = 1,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/admin-dashboard"
			}, new
			{
				HelpContextMappingId = 2,
				ComponentKey = "PackerDashboard",
				HelpTopicId = 1,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/packer-dashboard"
			}, new
			{
				HelpContextMappingId = 3,
				ComponentKey = "StockTakerDashboard",
				HelpTopicId = 1,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/stocktaker-dashboard"
			}, new
			{
				HelpContextMappingId = 4,
				ComponentKey = "DriverDashboard",
				HelpTopicId = 25,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/driver-dashboard"
			}, new
			{
				HelpContextMappingId = 5,
				ComponentKey = "Login",
				HelpTopicId = 2,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/login"
			}, new
			{
				HelpContextMappingId = 6,
				ComponentKey = "ResetPassword",
				HelpTopicId = 5,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/reset-password"
			}, new
			{
				HelpContextMappingId = 7,
				ComponentKey = "ManageUsers",
				HelpTopicId = 6,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/manage-users"
			}, new
			{
				HelpContextMappingId = 8,
				ComponentKey = "ManageRoles",
				HelpTopicId = 7,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/manage-roles"
			}, new
			{
				HelpContextMappingId = 9,
				ComponentKey = "ManagePermissions",
				HelpTopicId = 7,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/manage-permissions"
			}, new
			{
				HelpContextMappingId = 10,
				ComponentKey = "MakeProduct",
				HelpTopicId = 8,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/make-product"
			}, new
			{
				HelpContextMappingId = 11,
				ComponentKey = "SearchProduct",
				HelpTopicId = 9,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/search-product"
			}, new
			{
				HelpContextMappingId = 12,
				ComponentKey = "UpdateProduct",
				HelpTopicId = 9,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/update-product"
			}, new
			{
				HelpContextMappingId = 13,
				ComponentKey = "ManageProductTypes",
				HelpTopicId = 10,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/manage-product-types"
			}, new
			{
				HelpContextMappingId = 14,
				ComponentKey = "ManageProductCategories",
				HelpTopicId = 10,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/manage-product-categories"
			}, new
			{
				HelpContextMappingId = 15,
				ComponentKey = "StockTake",
				HelpTopicId = 12,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/stock-take"
			}, new
			{
				HelpContextMappingId = 16,
				ComponentKey = "ExpiryAlerts",
				HelpTopicId = 13,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/expiry-alerts"
			}, new
			{
				HelpContextMappingId = 17,
				ComponentKey = "ManageLookups",
				HelpTopicId = 14,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/manage-lookups"
			}, new
			{
				HelpContextMappingId = 18,
				ComponentKey = "WarehouseSections",
				HelpTopicId = 15,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/manage-warehouse-sections"
			}, new
			{
				HelpContextMappingId = 19,
				ComponentKey = "SystemSettings",
				HelpTopicId = 16,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/manage-system-settings"
			}, new
			{
				HelpContextMappingId = 20,
				ComponentKey = "SendOrderLink",
				HelpTopicId = 18,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/send-order-link"
			}, new
			{
				HelpContextMappingId = 21,
				ComponentKey = "OrderEditor",
				HelpTopicId = 19,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/create-order"
			}, new
			{
				HelpContextMappingId = 22,
				ComponentKey = "OrderDetails",
				HelpTopicId = 20,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/order-details/:id"
			}, new
			{
				HelpContextMappingId = 23,
				ComponentKey = "PackingOrders",
				HelpTopicId = 21,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/view-pick-list"
			}, new
			{
				HelpContextMappingId = 24,
				ComponentKey = "OrderInvoice",
				HelpTopicId = 21,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/order-invoice/:id"
			}, new
			{
				HelpContextMappingId = 25,
				ComponentKey = "PricingManagement",
				HelpTopicId = 22,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/pricing-management"
			}, new
			{
				HelpContextMappingId = 26,
				ComponentKey = "AuditLogs",
				HelpTopicId = 23,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/audit-logs"
			}, new
			{
				HelpContextMappingId = 27,
				ComponentKey = "DeliveryManagement",
				HelpTopicId = 24,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/deliveries"
			}, new
			{
				HelpContextMappingId = 28,
				ComponentKey = "MyDeliveries",
				HelpTopicId = 25,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/my-deliveries"
			}, new
			{
				HelpContextMappingId = 29,
				ComponentKey = "CompleteDelivery",
				HelpTopicId = 26,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/deliveries/:id/complete"
			}, new
			{
				HelpContextMappingId = 30,
				ComponentKey = "DeliveryProof",
				HelpTopicId = 26,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/deliveries/:id/proof"
			}, new
			{
				HelpContextMappingId = 31,
				ComponentKey = "AccountSecurity",
				HelpTopicId = 3,
				IsActive = true,
				Priority = 100,
				RoutePattern = "/account-security"
			}, new
			{
				HelpContextMappingId = 32,
				ComponentKey = "HelpCenter",
				HelpTopicId = 1,
				IsActive = true,
				Priority = 50,
				RoutePattern = "/help"
			});
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.HelpMedia", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("HelpMediaId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("HelpMediaId").UseIdentityColumn(1L);
			b.Property<long?>("CaptionStoredFileId").HasColumnType("bigint");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("Description").HasMaxLength(1000).HasColumnType("nvarchar(1000)");
			b.Property<int?>("HelpTopicId").HasColumnType("int");
			b.Property<bool>("IsFeatured").HasColumnType("bit");
			b.Property<bool>("IsPublished").HasColumnType("bit");
			b.Property<string>("MediaType").IsRequired().HasMaxLength(40)
				.HasColumnType("nvarchar(40)");
			b.Property<string>("RemovalReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<DateTime?>("RemovedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("RemovedByUserId").HasColumnType("int");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<int>("SortOrder").HasColumnType("int");
			b.Property<long>("StoredFileId").HasColumnType("bigint");
			b.Property<string>("Title").IsRequired().HasMaxLength(180)
				.HasColumnType("nvarchar(180)");
			b.Property<string>("Transcript").HasColumnType("nvarchar(max)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.Property<int>("UploadedByUserId").HasColumnType("int");
			b.HasKey("HelpMediaId");
			b.HasIndex("CaptionStoredFileId");
			b.HasIndex("HelpTopicId");
			b.HasIndex("RemovedByUserId");
			b.HasIndex("StoredFileId");
			b.HasIndex("UploadedByUserId");
			b.HasIndex("IsPublished", "IsFeatured", "SortOrder");
			b.ToTable("HelpMedia", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.HelpTopic", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("HelpTopicId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("HelpTopicId").UseIdentityColumn(1L);
			b.Property<string>("AudienceRolesCsv").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("BodyContent").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<int>("HelpCategoryId").HasColumnType("int");
			b.Property<bool>("IsPublic").HasColumnType("bit");
			b.Property<bool>("IsPublished").HasColumnType("bit");
			b.Property<string>("Keywords").HasMaxLength(800).HasColumnType("nvarchar(800)");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<string>("Slug").IsRequired().HasMaxLength(160)
				.HasColumnType("nvarchar(160)");
			b.Property<int>("SortOrder").HasColumnType("int");
			b.Property<string>("Summary").IsRequired().HasMaxLength(600)
				.HasColumnType("nvarchar(600)");
			b.Property<string>("Title").IsRequired().HasMaxLength(180)
				.HasColumnType("nvarchar(180)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("UpdatedByUserId").HasColumnType("int");
			b.HasKey("HelpTopicId");
			b.HasIndex("Slug").IsUnique();
			b.HasIndex("UpdatedByUserId");
			b.HasIndex("HelpCategoryId", "IsPublished", "SortOrder");
			b.ToTable("HelpTopics", (string?)null);
			b.HasData(new
			{
				HelpTopicId = 1,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# Getting started\nSign in with the email address assigned to your user account. PhenyoSync opens the dashboard and actions permitted by your role and permissions.\n\nUse the persistent Help action for guidance on the page you are viewing. Navigation cards and side menus only show authorized workflows. Always sign out when leaving a shared device.\n\nManagement users administer users and configuration. Admin handles operational administration. Packers prepare products and orders, Stock Takers control stock and expiry, and Drivers access only their assigned deliveries.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 1,
				IsPublic = false,
				IsPublished = true,
				Keywords = "start navigation dashboard sign out role",
				Slug = "getting-started",
				SortOrder = 10,
				Summary = "Learn the main navigation, role dashboards and safe sign-out workflow.",
				Title = "Getting started with PhenyoSync"
			}, new
			{
				HelpTopicId = 2,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# Login and email verification\nEnter your email and password. A new or untrusted session receives a six-digit code by email before business access is granted.\n\nThe code expires after five minutes, allows five attempts and can be resent after the displayed countdown. A new resend invalidates the previous code. Never share a password or verification code.\n\nIf email is delayed, check junk mail, confirm the masked destination, wait for the resend timer and request a fresh code.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 1,
				IsPublic = true,
				IsPublished = true,
				Keywords = "login otp code two factor email resend",
				Slug = "login-and-otp",
				SortOrder = 20,
				Summary = "Sign in with a password, verify a new session by email, and understand OTP limits.",
				Title = "Login and email verification"
			}, new
			{
				HelpTopicId = 3,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# Trusted devices\nSelecting Trust this device after OTP stores a protected HttpOnly device token. It bypasses OTP for up to 30 days but never bypasses the password.\n\nOpen Account Security to review device names, last use and expiry. Revoke an unfamiliar device immediately. Password reset, account deactivation, role changes and security-session revocation invalidate trusted devices.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 1,
				IsPublic = false,
				IsPublished = true,
				Keywords = "trusted device revoke thirty days security",
				Slug = "trusted-devices",
				SortOrder = 30,
				Summary = "Understand the 30-day trusted-device option and revoke devices safely.",
				Title = "Trusted devices"
			}, new
			{
				HelpTopicId = 4,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# Recovery codes\nAfter the first successful OTP, PhenyoSync displays ten one-time recovery codes. Save or print them immediately; they cannot be shown again.\n\nUse one code from the login verification screen only when email verification is unavailable. Each code works once. Regenerating codes revokes every unused code from the previous set and requires your current password.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 1,
				IsPublic = false,
				IsPublished = true,
				Keywords = "recovery code regenerate download print",
				Slug = "recovery-codes",
				SortOrder = 40,
				Summary = "Save, use and regenerate one-time recovery codes.",
				Title = "Recovery codes"
			}, new
			{
				HelpTopicId = 5,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# Password reset\nSelect Forgot Password on the login page and enter your account email. For privacy, the same confirmation appears whether or not an account exists.\n\nOpen the email link within 30 minutes, enter matching passwords of at least eight characters and submit once. A successful reset invalidates previous sessions and trusted devices.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 1,
				IsPublic = true,
				IsPublished = true,
				Keywords = "forgot password reset email expired link",
				Slug = "password-reset",
				SortOrder = 50,
				Summary = "Request and use the secure, expiring password-reset email.",
				Title = "Reset a forgotten password"
			}, new
			{
				HelpTopicId = 6,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Manage users\nAuthorized management can search users, create accounts with unique real email addresses, update identity details, assign roles and deactivate or reactivate accounts.\n\nDeactivation blocks new and current sessions without deleting history. Historical users must remain linked to their audit and operational records. Trigger password-reset email instead of setting a password manually.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 2,
				IsPublic = false,
				IsPublished = true,
				Keywords = "users create update deactivate role password reset",
				Slug = "manage-users",
				SortOrder = 10,
				Summary = "Create, search, update, deactivate and reactivate users safely.",
				Title = "Manage users"
			}, new
			{
				HelpTopicId = 7,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Roles and permissions\nRoles group permissions by business responsibility. Create or update custom roles, assign permission checkboxes and inspect a user's effective permissions before changing access.\n\nSystem role codes and system permission codes are protected because APIs depend on them. Unused custom roles may be deactivated or deleted; roles with users or historical references must remain.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 2,
				IsPublic = false,
				IsPublished = true,
				Keywords = "role permission create assign effective access",
				Slug = "roles-and-permissions",
				SortOrder = 20,
				Summary = "Maintain roles, permission assignments and effective access.",
				Title = "Roles and permissions"
			}, new
			{
				HelpTopicId = 8,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer",
				BodyContent = "# Make products\nSelect an existing product identity or enter name, type, category and size. Enter the produced quantity, warehouse section and packed date.\n\nPhenyoSync reuses an exact matching product identity and always creates a separate physical batch. The batch increases available stock, records a stock movement and calculates expiry from the product shelf life.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 3,
				IsPublic = false,
				IsPublished = true,
				Keywords = "make product batch quantity stock increase",
				Slug = "make-products",
				SortOrder = 10,
				Summary = "Create or reuse a product and record a new physical batch as stock increase.",
				Title = "Make products and batches"
			}, new
			{
				HelpTopicId = 9,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker",
				BodyContent = "# Search and update products\nSearch by product name, type, category, status or QR value. Select a result to view or update it.\n\nProduct changes affect future production, not historical batch snapshots. Use Inactive when a product must stay in history but should not be available for new operations.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 3,
				IsPublic = false,
				IsPublished = true,
				Keywords = "search product update qr inactive",
				Slug = "search-update-products",
				SortOrder = 20,
				Summary = "Find products by details or QR value and edit valid master data.",
				Title = "Search and update products"
			}, new
			{
				HelpTopicId = 10,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Product types and categories\nManagement pages maintain the database values shown in product forms. Names are unique and active entries are available for new products.\n\nA type or category linked to products cannot be permanently removed. Deactivate it instead so history remains valid.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 3,
				IsPublic = false,
				IsPublished = true,
				Keywords = "product type category crud deactivate",
				Slug = "product-types-categories",
				SortOrder = 30,
				Summary = "Create, edit, activate and dependency-check product classifications.",
				Title = "Product types and categories"
			}, new
			{
				HelpTopicId = 11,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker",
				BodyContent = "# QR codes and labels\nEach physical batch receives a scannable QR value. The printable label identifies the product, batch code, packed date and expiry date.\n\nAttach the label to the matching physical stock. Scanning should open or identify that exact batch, not just the product master record.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 3,
				IsPublic = false,
				IsPublished = true,
				Keywords = "qr code label print batch",
				Slug = "qr-labels",
				SortOrder = 40,
				Summary = "Generate, download and use batch-specific QR labels.",
				Title = "QR codes and labels"
			}, new
			{
				HelpTopicId = 12,
				AudienceRolesCsv = "CEO,COO,BusinessManager,StockTaker",
				BodyContent = "# Stock takes\nStart a stock-take session, capture observed quantities and review discrepancies before posting.\n\nAdjustments require an approved reason and create immutable stock movements. Never edit aggregate stock directly; batch and movement records are the accountability source.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 3,
				IsPublic = false,
				IsPublished = true,
				Keywords = "stock take adjustment movement discrepancy",
				Slug = "stock-take",
				SortOrder = 50,
				Summary = "Count physical stock and record controlled adjustments.",
				Title = "Stock takes and adjustments"
			}, new
			{
				HelpTopicId = 13,
				AudienceRolesCsv = "CEO,COO,BusinessManager,StockTaker",
				BodyContent = "# Expiry management\nYellow warnings identify batches approaching expiry. Red urgent warnings appear when 24 hours or less remain.\n\nAuthorized users may write off remaining stock or approve the one-time two-day extension after inspection and with a reason. Expired, consumed and written-off batches are excluded from available stock.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 3,
				IsPublic = false,
				IsPublished = true,
				Keywords = "expiry yellow red urgent write off extension",
				Slug = "expiry-actions",
				SortOrder = 60,
				Summary = "Respond to yellow and urgent expiry alerts safely.",
				Title = "Expiry warnings, write-off and extension"
			}, new
			{
				HelpTopicId = 14,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Operational lookups\nLookup values supply controlled options for stock movements, write-offs, order cancellation, delivery failures, payment methods, customer and supplier types, and units of measure.\n\nDisplay names and active status are editable. Protected system codes remain immutable because workflow logic and reporting use them.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 4,
				IsPublic = false,
				IsPublished = true,
				Keywords = "lookup reason payment method customer supplier unit",
				Slug = "operational-lookups",
				SortOrder = 10,
				Summary = "Maintain approved reasons, payment methods, customer types and units.",
				Title = "Operational lookups"
			}, new
			{
				HelpTopicId = 15,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Warehouse sections\nCreate a unique section code, display name and description. Active sections appear in product and stock workflows.\n\nDeactivate a location that should no longer receive stock. Do not delete a section referenced by stock, batches or movements.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 4,
				IsPublic = false,
				IsPublished = true,
				Keywords = "warehouse section location create deactivate",
				Slug = "warehouse-sections",
				SortOrder = 20,
				Summary = "Maintain warehouse locations without breaking historical stock.",
				Title = "Warehouse sections"
			}, new
			{
				HelpTopicId = 16,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# System settings\nAuthorized management can edit expiry thresholds, scanning intervals, order-link lifetime, delivery duration, OTP limits and file limits.\n\nValues are type-checked and range-checked. Changes apply immediately through cache invalidation and retain a history with actor, time and reason.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 4,
				IsPublic = false,
				IsPublished = true,
				Keywords = "settings timers threshold history configuration",
				Slug = "system-settings",
				SortOrder = 30,
				Summary = "Change validated business timers and thresholds immediately.",
				Title = "System settings and history"
			}, new
			{
				HelpTopicId = 17,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Customers, suppliers and payments\nUse unique contact details and active classifications when maintaining customers and suppliers. Orders must link to valid customers.\n\nAdmin and authorized management capture and confirm payments. Amounts must be positive and cannot exceed the outstanding invoice. Reversal requires a reason and audit record.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 5,
				IsPublic = false,
				IsPublished = true,
				Keywords = "customer supplier payment invoice confirm reverse",
				Slug = "customers-suppliers-payments",
				SortOrder = 10,
				Summary = "Maintain parties and capture authorized payments.",
				Title = "Customers, suppliers and payments"
			}, new
			{
				HelpTopicId = 18,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Customer order links\nSelect a valid customer, confirm the email address and send the secure order link. The link expires according to the configured lifetime and can be used once.\n\nThe public form exposes only active products with current valid prices. A submitted link cannot be reused.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 5,
				IsPublic = false,
				IsPublished = true,
				Keywords = "order link customer email one time expiry",
				Slug = "order-links",
				SortOrder = 20,
				Summary = "Generate and email a unique, expiring, one-time order form.",
				Title = "Send customer order links"
			}, new
			{
				HelpTopicId = 19,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Create and validate orders\nSelect a customer and add products with positive quantities. Prices are read from the current server-side price record and snapshotted onto order lines.\n\nValidation checks details and uses FEFO to reserve eligible batches atomically. An order cannot be confirmed when stock is insufficient.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 5,
				IsPublic = false,
				IsPublished = true,
				Keywords = "create order validate stock reserve fefo price",
				Slug = "create-validate-orders",
				SortOrder = 30,
				Summary = "Capture order lines and reserve sufficient eligible stock.",
				Title = "Create and validate orders"
			}, new
			{
				HelpTopicId = 20,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Order status and cancellation\nOrders move through the controlled sequence from pending validation to confirmed, packed, out for delivery and delivered.\n\nCancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 5,
				IsPublic = false,
				IsPublished = true,
				Keywords = "order status cancel reservation release",
				Slug = "order-status-cancel",
				SortOrder = 40,
				Summary = "Follow the valid status sequence and release reservations on cancellation.",
				Title = "Order status and cancellation"
			}, new
			{
				HelpTopicId = 21,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer",
				BodyContent = "# Packing and invoices\nPackers open the packing queue, verify each allocated batch and quantity, then confirm packing once.\n\nPacking decreases stock with movements and creates the order's invoice snapshot. The invoice remains linked to the order and later price changes do not alter it.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 5,
				IsPublic = false,
				IsPublished = true,
				Keywords = "packing list batch invoice stock decrease",
				Slug = "packing-invoices",
				SortOrder = 50,
				Summary = "Pack allocated batches and view the immutable invoice snapshot.",
				Title = "Packing lists and invoices"
			}, new
			{
				HelpTopicId = 22,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Pricing\nA price must be greater than zero and belong to a valid product. Updating a price closes the previous record and creates a new current version.\n\nSoft deletion removes a price from future ordering but preserves its history. Existing order items and invoices retain their snapshotted unit prices.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 6,
				IsPublic = false,
				IsPublished = true,
				Keywords = "price create update history soft delete current",
				Slug = "pricing",
				SortOrder = 10,
				Summary = "Create current product prices while preserving historical versions.",
				Title = "Pricing and price history"
			}, new
			{
				HelpTopicId = 23,
				AudienceRolesCsv = "CEO,COO,BusinessManager",
				BodyContent = "# Audit logs\nSearch by user, date, action, module, entity, success state, correlation ID or text. Open a result to inspect sanitized before-and-after details.\n\nAudit logs are read-only and retained for accountability. A correlation ID groups changes and security events from the same request or workflow.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 6,
				IsPublic = false,
				IsPublished = true,
				Keywords = "audit log search correlation activity readonly",
				Slug = "audit-logs",
				SortOrder = 20,
				Summary = "Find read-only accountability records and use correlation IDs.",
				Title = "Search audit logs"
			}, new
			{
				HelpTopicId = 24,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Assign drivers\nA packed order may be scheduled for a delivery window. Select an active available driver whose licence covers the full window.\n\nPhenyoSync prevents overlapping assignments and records assignment, reassignment and unassignment history.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 7,
				IsPublic = false,
				IsPublished = true,
				Keywords = "delivery schedule assign driver availability overlap",
				Slug = "assign-drivers",
				SortOrder = 10,
				Summary = "Schedule deliveries and prevent overlapping driver assignments.",
				Title = "Assign drivers"
			}, new
			{
				HelpTopicId = 25,
				AudienceRolesCsv = "Driver",
				BodyContent = "# My Deliveries\nDrivers see only currently assigned deliveries. Open a record for the schedule, customer, address and order details.\n\nStart the delivery only when it is Assigned. This moves the delivery and order into their in-transit states.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 7,
				IsPublic = false,
				IsPublished = true,
				Keywords = "driver my deliveries assigned start",
				Slug = "my-deliveries",
				SortOrder = 20,
				Summary = "Review and start only deliveries assigned to your driver account.",
				Title = "Driver: My Deliveries"
			}, new
			{
				HelpTopicId = 26,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Driver",
				BodyContent = "# Complete a delivery\nUpload one or more JPEG, PNG or WebP proof images, add a useful caption and select the primary image. Confirm the recipient and successful fulfillment.\n\nProof is required by default. The assigned Driver may complete their own in-transit delivery. Authorized management can complete on behalf of a driver or override missing proof only with an explicit reason.\n\nCompletion is final: proof becomes read-only, the delivery records a UTC completion time and the order becomes Delivered.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 7,
				IsPublic = false,
				IsPublished = true,
				Keywords = "delivery proof image upload complete recipient override",
				Slug = "complete-delivery-proof",
				SortOrder = 30,
				Summary = "Upload protected proof images before final delivery completion.",
				Title = "Complete delivery with proof images"
			}, new
			{
				HelpTopicId = 27,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# Validation and server errors\nRead the friendly message and correct every highlighted field. Refresh when a row-version conflict says the record changed.\n\nIf an unexpected server error persists, note the displayed trace ID and the time of the action. Do not send passwords, OTPs or recovery codes to support.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 8,
				IsPublic = true,
				IsPublished = true,
				Keywords = "validation error trace id conflict support",
				Slug = "validation-errors",
				SortOrder = 10,
				Summary = "Resolve highlighted fields and provide a trace ID when support is needed.",
				Title = "Validation messages and trace IDs"
			}, new
			{
				HelpTopicId = 28,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# Permission denied\nMenus and APIs are controlled by database permissions. A denied action means the signed-in role does not currently have that permission.\n\nAsk authorized management to review your effective permissions. Sign out and in again after a role change so the session uses the new security version.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 8,
				IsPublic = false,
				IsPublished = true,
				Keywords = "permission denied role access 403",
				Slug = "permission-denied",
				SortOrder = 20,
				Summary = "Understand why a page or action is unavailable.",
				Title = "Permission denied"
			}, new
			{
				HelpTopicId = 29,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# Expired links\nSecurity links are time-limited and often one-time. Request a new password-reset link, customer order link or expiry review link from the appropriate workflow.\n\nDo not edit tokens in the address bar or share links. A used link cannot be reactivated.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 8,
				IsPublic = true,
				IsPublished = true,
				Keywords = "expired link used token password order expiry",
				Slug = "expired-links",
				SortOrder = 30,
				Summary = "Recover from password, order or expiry-action links that no longer work.",
				Title = "Expired or used links"
			}, new
			{
				HelpTopicId = 30,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin",
				BodyContent = "# Unavailable drivers\nA driver is unavailable when inactive, not marked Available, missing a valid driver-user link, holding an expired licence or already assigned to an overlapping window.\n\nAdjust the schedule, update legitimate driver details or select a different available driver. Do not bypass overlap protection.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 8,
				IsPublic = false,
				IsPublished = true,
				Keywords = "driver unavailable overlap licence schedule",
				Slug = "unavailable-drivers",
				SortOrder = 40,
				Summary = "Resolve licence, status and schedule conflicts during assignment.",
				Title = "Unavailable drivers"
			}, new
			{
				HelpTopicId = 31,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# OTP email not received\nConfirm the masked email destination, check spam, wait for the resend countdown and request one fresh code. Only the newest code is valid.\n\nIf email remains unavailable, use a saved recovery code. Contact management to correct the account email; never create duplicate shared addresses.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 8,
				IsPublic = true,
				IsPublished = true,
				Keywords = "otp email not received resend recovery",
				Slug = "otp-not-received",
				SortOrder = 50,
				Summary = "Use safe recovery steps when the verification email is delayed.",
				Title = "OTP email not received"
			}, new
			{
				HelpTopicId = 32,
				AudienceRolesCsv = "CEO,COO,BusinessManager,Admin,Packer,StockTaker,Driver",
				BodyContent = "# File rejected\nProof images must be genuine JPEG, PNG or WebP files within the configured limit. Training media must be a genuine MP4 or WebM; captions must be WEBVTT.\n\nRenaming an extension does not convert a file. Export the file in an allowed format and retry. Executable, SVG, HTML, polyglot and mismatched files are blocked.",
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				HelpCategoryId = 8,
				IsPublic = false,
				IsPublished = true,
				Keywords = "file rejected image video size mime extension",
				Slug = "file-rejected",
				SortOrder = 60,
				Summary = "Resolve protected-file validation failures without weakening security.",
				Title = "A proof image or training video was rejected"
			});
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Invoice", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("InvoiceId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("InvoiceId").UseIdentityColumn(1L);
			b.Property<string>("BillingAddressSnapshot").IsRequired().HasMaxLength(500)
				.HasColumnType("nvarchar(500)");
			b.Property<string>("CustomerEmailSnapshot").IsRequired().HasMaxLength(254)
				.HasColumnType("nvarchar(254)");
			b.Property<string>("CustomerNameSnapshot").IsRequired().HasMaxLength(150)
				.HasColumnType("nvarchar(150)");
			b.Property<string>("InvoiceNumber").IsRequired().HasMaxLength(30)
				.HasColumnType("nvarchar(30)");
			b.Property<DateTime>("IssuedAtUtc").HasColumnType("datetime2");
			b.Property<int>("SalesOrderId").HasColumnType("int");
			b.Property<string>("Status").IsRequired().HasMaxLength(20)
				.HasColumnType("nvarchar(20)");
			b.Property<decimal>("Subtotal").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<decimal>("TaxAmount").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<decimal>("TotalAmount").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.HasKey("InvoiceId");
			b.HasIndex("InvoiceNumber").IsUnique();
			b.HasIndex("SalesOrderId").IsUnique();
			b.ToTable("Invoices", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.LookupType", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("LookupTypeId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("LookupTypeId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("Description").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("DisplayName").IsRequired().HasMaxLength(120)
				.HasColumnType("nvarchar(120)");
			b.Property<bool>("IsActive").HasColumnType("bit");
			b.Property<bool>("IsSystemType").HasColumnType("bit");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<string>("SystemCode").IsRequired().HasMaxLength(80)
				.HasColumnType("nvarchar(80)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.HasKey("LookupTypeId");
			b.HasIndex("SystemCode").IsUnique().HasDatabaseName("UX_LookupTypes_SystemCode");
			b.HasIndex("IsActive", "DisplayName");
			b.ToTable("LookupTypes", (string?)null);
			b.HasData(new
			{
				LookupTypeId = 1,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Reasons recorded when stock is adjusted or moved.",
				DisplayName = "Stock movement reasons",
				IsActive = true,
				IsSystemType = true,
				SystemCode = "STOCK_MOVEMENT_REASON"
			}, new
			{
				LookupTypeId = 2,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Approved reasons for final stock write-off.",
				DisplayName = "Write-off reasons",
				IsActive = true,
				IsSystemType = true,
				SystemCode = "WRITE_OFF_REASON"
			}, new
			{
				LookupTypeId = 3,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Reasons used when a sales order is cancelled.",
				DisplayName = "Order cancellation reasons",
				IsActive = true,
				IsSystemType = true,
				SystemCode = "ORDER_CANCELLATION_REASON"
			}, new
			{
				LookupTypeId = 4,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Reasons used when an order is rejected during validation.",
				DisplayName = "Order rejection reasons",
				IsActive = true,
				IsSystemType = true,
				SystemCode = "ORDER_REJECTION_REASON"
			}, new
			{
				LookupTypeId = 5,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Reasons recorded when a delivery cannot be fulfilled.",
				DisplayName = "Delivery failure reasons",
				IsActive = true,
				IsSystemType = true,
				SystemCode = "DELIVERY_FAILURE_REASON"
			}, new
			{
				LookupTypeId = 6,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Approved customer and supplier payment methods.",
				DisplayName = "Payment methods",
				IsActive = true,
				IsSystemType = true,
				SystemCode = "PAYMENT_METHOD"
			}, new
			{
				LookupTypeId = 7,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Customer classifications used by operational forms.",
				DisplayName = "Customer types",
				IsActive = true,
				IsSystemType = true,
				SystemCode = "CUSTOMER_TYPE"
			}, new
			{
				LookupTypeId = 8,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Supplier classifications used by operational forms.",
				DisplayName = "Supplier types",
				IsActive = true,
				IsSystemType = true,
				SystemCode = "SUPPLIER_TYPE"
			}, new
			{
				LookupTypeId = 9,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Description = "Units available for quantities and packaging.",
				DisplayName = "Units of measure",
				IsActive = true,
				IsSystemType = true,
				SystemCode = "UNIT_OF_MEASURE"
			});
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.LookupValue", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("LookupValueId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("LookupValueId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("Description").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("DisplayName").IsRequired().HasMaxLength(120)
				.HasColumnType("nvarchar(120)");
			b.Property<bool>("IsActive").HasColumnType("bit");
			b.Property<bool>("IsSystemValue").HasColumnType("bit");
			b.Property<int>("LookupTypeId").HasColumnType("int");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<int>("SortOrder").HasColumnType("int");
			b.Property<string>("SystemCode").IsRequired().HasMaxLength(80)
				.HasColumnType("nvarchar(80)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.HasKey("LookupValueId");
			b.HasIndex("LookupTypeId", "SystemCode").IsUnique().HasDatabaseName("UX_LookupValues_Type_SystemCode");
			b.HasIndex("LookupTypeId", "IsActive", "SortOrder", "DisplayName");
			b.ToTable("LookupValues", (string?)null);
			b.HasData(new
			{
				LookupValueId = 1,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Production increase",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 1,
				SortOrder = 10,
				SystemCode = "PRODUCTION_INCREASE"
			}, new
			{
				LookupValueId = 2,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Packing decrease",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 1,
				SortOrder = 20,
				SystemCode = "PACKING_DECREASE"
			}, new
			{
				LookupValueId = 3,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Stock adjustment",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 1,
				SortOrder = 30,
				SystemCode = "STOCK_ADJUSTMENT"
			}, new
			{
				LookupValueId = 4,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Expired stock",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 2,
				SortOrder = 10,
				SystemCode = "EXPIRED"
			}, new
			{
				LookupValueId = 5,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Damaged stock",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 2,
				SortOrder = 20,
				SystemCode = "DAMAGED"
			}, new
			{
				LookupValueId = 6,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Quality inspection failure",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 2,
				SortOrder = 30,
				SystemCode = "QUALITY_FAILURE"
			}, new
			{
				LookupValueId = 7,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Customer request",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 3,
				SortOrder = 10,
				SystemCode = "CUSTOMER_REQUEST"
			}, new
			{
				LookupValueId = 8,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Duplicate order",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 3,
				SortOrder = 20,
				SystemCode = "DUPLICATE_ORDER"
			}, new
			{
				LookupValueId = 9,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Stock unavailable",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 3,
				SortOrder = 30,
				SystemCode = "STOCK_UNAVAILABLE"
			}, new
			{
				LookupValueId = 10,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Insufficient stock",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 4,
				SortOrder = 10,
				SystemCode = "INSUFFICIENT_STOCK"
			}, new
			{
				LookupValueId = 11,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Invalid order details",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 4,
				SortOrder = 20,
				SystemCode = "INVALID_DETAILS"
			}, new
			{
				LookupValueId = 12,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Customer unavailable",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 5,
				SortOrder = 10,
				SystemCode = "CUSTOMER_UNAVAILABLE"
			}, new
			{
				LookupValueId = 13,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Address not found",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 5,
				SortOrder = 20,
				SystemCode = "ADDRESS_NOT_FOUND"
			}, new
			{
				LookupValueId = 14,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Vehicle issue",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 5,
				SortOrder = 30,
				SystemCode = "VEHICLE_ISSUE"
			}, new
			{
				LookupValueId = 15,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Electronic funds transfer",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 6,
				SortOrder = 10,
				SystemCode = "EFT"
			}, new
			{
				LookupValueId = 16,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Card",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 6,
				SortOrder = 20,
				SystemCode = "CARD"
			}, new
			{
				LookupValueId = 17,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Cash",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 6,
				SortOrder = 30,
				SystemCode = "CASH"
			}, new
			{
				LookupValueId = 18,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Retail",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 7,
				SortOrder = 10,
				SystemCode = "RETAIL"
			}, new
			{
				LookupValueId = 19,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Wholesale",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 7,
				SortOrder = 20,
				SystemCode = "WHOLESALE"
			}, new
			{
				LookupValueId = 20,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Distributor",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 7,
				SortOrder = 30,
				SystemCode = "DISTRIBUTOR"
			}, new
			{
				LookupValueId = 21,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Producer",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 8,
				SortOrder = 10,
				SystemCode = "PRODUCER"
			}, new
			{
				LookupValueId = 22,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Distributor",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 8,
				SortOrder = 20,
				SystemCode = "DISTRIBUTOR"
			}, new
			{
				LookupValueId = 23,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Service provider",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 8,
				SortOrder = 30,
				SystemCode = "SERVICE_PROVIDER"
			}, new
			{
				LookupValueId = 24,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Kilogram (kg)",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 9,
				SortOrder = 10,
				SystemCode = "KG"
			}, new
			{
				LookupValueId = 25,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Gram (g)",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 9,
				SortOrder = 20,
				SystemCode = "G"
			}, new
			{
				LookupValueId = 26,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Litre (L)",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 9,
				SortOrder = 30,
				SystemCode = "L"
			}, new
			{
				LookupValueId = 27,
				CreatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				DisplayName = "Unit",
				IsActive = true,
				IsSystemValue = true,
				LookupTypeId = 9,
				SortOrder = 40,
				SystemCode = "UNIT"
			});
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.LookupValueHistory", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("LookupValueHistoryId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("LookupValueHistoryId").UseIdentityColumn(1L);
			b.Property<string>("AfterValuesJson").HasColumnType("nvarchar(max)");
			b.Property<string>("BeforeValuesJson").HasColumnType("nvarchar(max)");
			b.Property<string>("ChangeType").IsRequired().HasMaxLength(40)
				.HasColumnType("nvarchar(40)");
			b.Property<DateTime>("ChangedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("ChangedByUserId").HasColumnType("int");
			b.Property<string>("CorrelationId").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<int>("LookupValueId").HasColumnType("int");
			b.Property<string>("Reason").IsRequired().HasMaxLength(500)
				.HasColumnType("nvarchar(500)");
			b.HasKey("LookupValueHistoryId");
			b.HasIndex("ChangedByUserId");
			b.HasIndex("LookupValueId", "ChangedAtUtc");
			b.ToTable("LookupValueHistory", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.OrderStatusHistory", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("OrderStatusHistoryId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("OrderStatusHistoryId").UseIdentityColumn(1L);
			b.Property<DateTime>("ChangedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("ChangedByUserId").HasColumnType("int");
			b.Property<string>("NewStatus").IsRequired().HasMaxLength(30)
				.HasColumnType("nvarchar(30)");
			b.Property<string>("PreviousStatus").HasMaxLength(30).HasColumnType("nvarchar(30)");
			b.Property<string>("Reason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<int>("SalesOrderId").HasColumnType("int");
			b.HasKey("OrderStatusHistoryId");
			b.HasIndex("ChangedByUserId");
			b.HasIndex("SalesOrderId", "ChangedAtUtc");
			b.ToTable("OrderStatusHistory", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.OrderStockReservation", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("OrderStockReservationId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("OrderStockReservationId").UseIdentityColumn(1L);
			b.Property<DateTime?>("ConsumedAtUtc").HasColumnType("datetime2");
			b.Property<int>("ProductBatchId").HasColumnType("int");
			b.Property<int>("ProductId").HasColumnType("int");
			b.Property<decimal>("QuantityReservedKg").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<DateTime?>("ReleasedAtUtc").HasColumnType("datetime2");
			b.Property<DateTime>("ReservedAtUtc").HasColumnType("datetime2");
			b.Property<int>("SalesOrderId").HasColumnType("int");
			b.Property<int>("SalesOrderItemId").HasColumnType("int");
			b.Property<int>("SectionId").HasColumnType("int");
			b.Property<string>("Status").IsRequired().HasMaxLength(20)
				.HasColumnType("nvarchar(20)");
			b.Property<int>("StockId").HasColumnType("int");
			b.HasKey("OrderStockReservationId");
			b.HasIndex("ProductId");
			b.HasIndex("SalesOrderItemId");
			b.HasIndex("SectionId");
			b.HasIndex("StockId");
			b.HasIndex("ProductBatchId", "Status");
			b.HasIndex("SalesOrderId", "Status");
			b.ToTable("OrderStockReservations", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Packer", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("PackerId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("PackerId").UseIdentityColumn(1L);
			b.Property<DateTime?>("EmploymentDate").HasColumnType("datetime2");
			b.Property<string>("PackingArea").HasColumnType("nvarchar(max)");
			b.Property<string>("PackingStation").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<string>("Shift").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<int>("UserId").HasColumnType("int");
			b.HasKey("PackerId");
			b.HasIndex("UserId");
			b.ToTable("Packers");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Permission", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("PermissionId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("PermissionId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("Description").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("DisplayName").IsRequired().HasMaxLength(120)
				.HasColumnType("nvarchar(120)");
			b.Property<bool>("IsActive").HasColumnType("bit");
			b.Property<bool>("IsSystemPermission").HasColumnType("bit");
			b.Property<string>("Module").IsRequired().HasMaxLength(80)
				.HasColumnType("nvarchar(80)");
			b.Property<string>("PermissionCode").IsRequired().HasMaxLength(100)
				.HasColumnType("nvarchar(100)");
			b.Property<string>("PermissionName").IsRequired().HasMaxLength(120)
				.HasColumnType("nvarchar(120)");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.HasKey("PermissionId");
			b.HasIndex("PermissionCode").IsUnique().HasDatabaseName("UX_Permissions_PermissionCode");
			b.HasIndex("Module", "IsActive");
			b.ToTable("Permissions", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Product", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("ProductId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("ProductId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAt").HasColumnType("datetime2");
			b.Property<int>("ProductCategoryId").HasColumnType("int");
			b.Property<string>("ProductName").IsRequired().HasMaxLength(150)
				.HasColumnType("nvarchar(150)");
			b.Property<int>("ProductTypeId").HasColumnType("int");
			b.Property<string>("QRCodeValue").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<decimal>("SellingPricePerKg").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<int>("ShelfLifeDays").HasColumnType("int");
			b.Property<string>("Size").IsRequired().HasMaxLength(50)
				.HasColumnType("nvarchar(50)");
			b.Property<string>("Status").IsRequired().HasMaxLength(20)
				.HasColumnType("nvarchar(20)");
			b.Property<DateTime?>("UpdatedAt").HasColumnType("datetime2");
			b.HasKey("ProductId");
			b.HasIndex("ProductCategoryId");
			b.HasIndex("ProductTypeId");
			b.HasIndex("ProductName", "ProductTypeId", "ProductCategoryId", "Size").IsUnique().HasDatabaseName("UX_Product_CompositeSku");
			b.ToTable("Product", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductBatch", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("ProductBatchId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("ProductBatchId").UseIdentityColumn(1L);
			b.Property<DateTime?>("AvailableQuantityRemovedAtUtc").HasColumnType("datetime2");
			b.Property<string>("BatchCode").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<DateTime>("EffectiveExpiryAtUtc").HasColumnType("datetime2");
			b.Property<DateTime>("OriginalExpiryAtUtc").HasColumnType("datetime2");
			b.Property<DateTime>("PackedAtUtc").HasColumnType("datetime2");
			b.Property<int>("ProductId").HasColumnType("int");
			b.Property<string>("QRCodeValue").IsRequired().HasMaxLength(500)
				.HasColumnType("nvarchar(500)");
			b.Property<decimal>("QuantityProducedKg").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<decimal>("QuantityRemainingKg").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<DateTime?>("RedAlertSentAtUtc").HasColumnType("datetime2");
			b.Property<int>("SectionId").HasColumnType("int");
			b.Property<bool>("ShelfLifeExtended").HasColumnType("bit");
			b.Property<DateTime?>("ShelfLifeExtendedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("ShelfLifeExtendedByUserId").HasColumnType("int");
			b.Property<string>("ShelfLifeExtensionReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("Status").IsRequired().HasMaxLength(40)
				.HasColumnType("nvarchar(40)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.Property<DateTime?>("YellowAlertSentAtUtc").HasColumnType("datetime2");
			b.HasKey("ProductBatchId");
			b.HasIndex("BatchCode").IsUnique();
			b.HasIndex("QRCodeValue").IsUnique();
			b.HasIndex("SectionId");
			b.HasIndex("ShelfLifeExtendedByUserId");
			b.HasIndex("ProductId", "SectionId");
			b.HasIndex("Status", "EffectiveExpiryAtUtc", "QuantityRemainingKg");
			b.ToTable("ProductBatches", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductCategory", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("ProductCategoryId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("ProductCategoryId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAt").HasColumnType("datetime2");
			b.Property<string>("Description").HasMaxLength(255).HasColumnType("nvarchar(255)");
			b.Property<string>("ProductCategoryName").IsRequired().HasMaxLength(100)
				.HasColumnType("nvarchar(100)");
			b.Property<string>("Status").IsRequired().HasMaxLength(20)
				.HasColumnType("nvarchar(20)");
			b.Property<DateTime?>("UpdatedAt").HasColumnType("datetime2");
			b.HasKey("ProductCategoryId");
			b.HasIndex("ProductCategoryName").IsUnique().HasDatabaseName("UX_ProductCategory_Name");
			b.ToTable("ProductCategory", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductPrice", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("ProductPriceId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("ProductPriceId").UseIdentityColumn(1L);
			b.Property<string>("ChangeReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("CreatedByUserId").HasColumnType("int");
			b.Property<string>("DeleteReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<DateTime?>("DeletedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("DeletedByUserId").HasColumnType("int");
			b.Property<DateTime>("EffectiveFromUtc").HasColumnType("datetime2");
			b.Property<DateTime?>("EffectiveToUtc").HasColumnType("datetime2");
			b.Property<bool>("IsCurrent").HasColumnType("bit");
			b.Property<bool>("IsDeleted").HasColumnType("bit");
			b.Property<int>("ProductId").HasColumnType("int");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<decimal>("SellingPrice").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.HasKey("ProductPriceId");
			b.HasIndex("CreatedByUserId");
			b.HasIndex("DeletedByUserId");
			b.HasIndex("EffectiveFromUtc");
			b.HasIndex("EffectiveToUtc");
			b.HasIndex("ProductId");
			b.HasIndex("SellingPrice");
			b.HasIndex("ProductId", "IsCurrent", "IsDeleted").IsUnique().HasDatabaseName("UX_ProductPrices_Current")
				.HasFilter("[IsCurrent] = 1 AND [IsDeleted] = 0");
			b.ToTable("ProductPrices", null, delegate(TableBuilder t)
			{
				t.HasCheckConstraint("CK_ProductPrices_Positive", "[SellingPrice] > 0");
			});
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductType", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("ProductTypeId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("ProductTypeId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAt").HasColumnType("datetime2");
			b.Property<string>("Description").HasMaxLength(255).HasColumnType("nvarchar(255)");
			b.Property<string>("ProductTypeName").IsRequired().HasMaxLength(100)
				.HasColumnType("nvarchar(100)");
			b.Property<string>("Status").IsRequired().HasMaxLength(20)
				.HasColumnType("nvarchar(20)");
			b.Property<DateTime?>("UpdatedAt").HasColumnType("datetime2");
			b.HasKey("ProductTypeId");
			b.HasIndex("ProductTypeName").IsUnique().HasDatabaseName("UX_ProductType_Name");
			b.ToTable("ProductType", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Role", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("RoleId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("RoleId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("Description").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<bool>("IsActive").HasColumnType("bit");
			b.Property<bool>("IsSystemRole").HasColumnType("bit");
			b.Property<string>("RoleCode").IsRequired().HasMaxLength(50)
				.HasColumnType("nvarchar(50)");
			b.Property<string>("RoleName").IsRequired().HasMaxLength(80)
				.HasColumnType("nvarchar(80)");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.HasKey("RoleId");
			b.HasIndex("RoleCode").IsUnique().HasDatabaseName("UX_Roles_RoleCode");
			b.HasIndex("RoleName").IsUnique().HasDatabaseName("UX_Roles_RoleName");
			b.ToTable("Roles", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.RolePermission", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("RoleId").HasColumnType("int");
			b.Property<int>("PermissionId").HasColumnType("int");
			b.Property<DateTime>("AssignedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("AssignedByUserId").HasColumnType("int");
			b.HasKey("RoleId", "PermissionId");
			b.HasIndex("AssignedByUserId");
			b.HasIndex("PermissionId");
			b.ToTable("RolePermissions", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SalesOrder", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("SalesOrderId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("SalesOrderId").UseIdentityColumn(1L);
			b.Property<string>("BillingAddressSnapshot").IsRequired().HasMaxLength(500)
				.HasColumnType("nvarchar(500)");
			b.Property<string>("CancellationReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<DateTime?>("CancelledAtUtc").HasColumnType("datetime2");
			b.Property<int?>("CancelledByUserId").HasColumnType("int");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("CreatedByUserId").HasColumnType("int");
			b.Property<long?>("CreatedViaOrderLinkId").HasColumnType("bigint");
			b.Property<int>("CustomerId").HasColumnType("int");
			b.Property<string>("DeliveryAddressSnapshot").IsRequired().HasMaxLength(500)
				.HasColumnType("nvarchar(500)");
			b.Property<string>("Notes").HasMaxLength(1000).HasColumnType("nvarchar(1000)");
			b.Property<DateTime>("OrderDateUtc").HasColumnType("datetime2");
			b.Property<string>("OrderNumber").IsRequired().HasMaxLength(30)
				.HasColumnType("nvarchar(30)");
			b.Property<DateTime?>("PackedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("PackedByUserId").HasColumnType("int");
			b.Property<DateTime?>("RequestedDeliveryDateUtc").HasColumnType("datetime2");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<string>("Status").IsRequired().HasMaxLength(30)
				.HasColumnType("nvarchar(30)");
			b.Property<decimal>("Subtotal").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<decimal>("TaxAmount").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<decimal>("TotalAmount").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.Property<DateTime?>("ValidatedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("ValidatedByUserId").HasColumnType("int");
			b.Property<string>("ValidationMessage").HasMaxLength(1000).HasColumnType("nvarchar(1000)");
			b.Property<string>("ValidationStatus").IsRequired().HasMaxLength(20)
				.HasColumnType("nvarchar(20)");
			b.HasKey("SalesOrderId");
			b.HasIndex("CancelledByUserId");
			b.HasIndex("CreatedByUserId");
			b.HasIndex("CreatedViaOrderLinkId");
			b.HasIndex("CustomerId");
			b.HasIndex("OrderDateUtc");
			b.HasIndex("OrderNumber").IsUnique();
			b.HasIndex("PackedByUserId");
			b.HasIndex("Status");
			b.HasIndex("ValidatedByUserId");
			b.HasIndex("ValidationStatus");
			b.ToTable("SalesOrders", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SalesOrderItem", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("SalesOrderItemId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("SalesOrderItemId").UseIdentityColumn(1L);
			b.Property<bool>("IsActive").HasColumnType("bit");
			b.Property<decimal>("LineTotal").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<string>("Notes").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<int>("ProductId").HasColumnType("int");
			b.Property<string>("ProductNameSnapshot").IsRequired().HasMaxLength(150)
				.HasColumnType("nvarchar(150)");
			b.Property<int?>("ProductPriceId").HasColumnType("int");
			b.Property<string>("ProductSizeSnapshot").IsRequired().HasMaxLength(50)
				.HasColumnType("nvarchar(50)");
			b.Property<decimal>("QuantityKg").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<int>("SalesOrderId").HasColumnType("int");
			b.Property<decimal>("UnitPricePerKg").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.HasKey("SalesOrderItemId");
			b.HasIndex("ProductId");
			b.HasIndex("ProductPriceId");
			b.HasIndex("SalesOrderId", "ProductId").IsUnique().HasFilter("[IsActive] = 1");
			b.ToTable("SalesOrderItems", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Stock", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("StockId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("StockId").UseIdentityColumn(1L);
			b.Property<string>("InventoryStatus").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<int>("ProductId").HasColumnType("int");
			b.Property<decimal>("QuantityAvailableKg").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<decimal>("ReorderLevelKg").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<int>("SectionId").HasColumnType("int");
			b.HasKey("StockId");
			b.HasIndex("SectionId");
			b.HasIndex("ProductId", "SectionId").IsUnique().HasDatabaseName("UX_Stocks_Product_Section");
			b.ToTable("Stocks", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.StockMovement", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("StockMovementId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("StockMovementId").UseIdentityColumn(1L);
			b.Property<int?>("CreatedByUserId").HasColumnType("int");
			b.Property<string>("MovementType").IsRequired().HasMaxLength(30)
				.HasColumnType("nvarchar(30)");
			b.Property<DateTime>("OccurredAtUtc").HasColumnType("datetime2");
			b.Property<int>("ProductBatchId").HasColumnType("int");
			b.Property<int>("ProductId").HasColumnType("int");
			b.Property<decimal>("QuantityKg").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.Property<string>("Reason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<int?>("SalesOrderId").HasColumnType("int");
			b.Property<int>("SectionId").HasColumnType("int");
			b.HasKey("StockMovementId");
			b.HasIndex("CreatedByUserId");
			b.HasIndex("ProductBatchId");
			b.HasIndex("SalesOrderId");
			b.HasIndex("SectionId");
			b.HasIndex("ProductId", "SectionId", "OccurredAtUtc");
			b.ToTable("StockMovements", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.StockTakeSession", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("SessionId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("SessionId").UseIdentityColumn(1L);
			b.Property<string>("Notes").HasColumnType("nvarchar(max)");
			b.Property<int>("SectionId").HasColumnType("int");
			b.Property<DateTime>("SessionDate").HasColumnType("datetime2");
			b.Property<string>("Status").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<int>("UserId").HasColumnType("int");
			b.Property<int>("WarehouseSectionSectionId").HasColumnType("int");
			b.HasKey("SessionId");
			b.HasIndex("UserId");
			b.HasIndex("WarehouseSectionSectionId");
			b.ToTable("StockTakeSessions");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Stocktaker", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("StockTakerId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("StockTakerId").UseIdentityColumn(1L);
			b.Property<string>("AssignedSection").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<DateTime?>("LastStockTakeDate").HasColumnType("datetime2");
			b.Property<string>("Shift").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<int>("UserId").HasColumnType("int");
			b.HasKey("StockTakerId");
			b.HasIndex("UserId");
			b.ToTable("StockTakers");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.StoredFile", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("StoredFileId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("StoredFileId").UseIdentityColumn(1L);
			b.Property<string>("ContentType").IsRequired().HasMaxLength(120)
				.HasColumnType("nvarchar(120)");
			b.Property<DateTime?>("DeletedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("DeletedByUserId").HasColumnType("int");
			b.Property<string>("Extension").IsRequired().HasMaxLength(16)
				.HasColumnType("nvarchar(16)");
			b.Property<bool>("IsDeleted").HasColumnType("bit");
			b.Property<string>("OriginalFileName").IsRequired().HasMaxLength(255)
				.HasColumnType("nvarchar(255)");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<string>("SafeDownloadName").IsRequired().HasMaxLength(255)
				.HasColumnType("nvarchar(255)");
			b.Property<string>("Sha256Hash").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<long>("SizeBytes").HasColumnType("bigint");
			b.Property<string>("StorageKey").IsRequired().HasMaxLength(300)
				.HasColumnType("nvarchar(300)");
			b.Property<string>("StorageProvider").IsRequired().HasMaxLength(40)
				.HasColumnType("nvarchar(40)");
			b.Property<DateTime>("UploadedAtUtc").HasColumnType("datetime2");
			b.Property<int>("UploadedByUserId").HasColumnType("int");
			b.HasKey("StoredFileId");
			b.HasIndex("DeletedByUserId");
			b.HasIndex("StorageKey").IsUnique().HasDatabaseName("UX_StoredFiles_StorageKey");
			b.HasIndex("UploadedByUserId");
			b.HasIndex("IsDeleted", "UploadedAtUtc");
			b.ToTable("StoredFiles", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Supplier", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("SupplierId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("SupplierId").UseIdentityColumn(1L);
			b.Property<string>("Address").HasColumnType("nvarchar(max)");
			b.Property<string>("ContactPerson").HasColumnType("nvarchar(max)");
			b.Property<string>("Email").HasColumnType("nvarchar(max)");
			b.Property<string>("Phone").HasColumnType("nvarchar(max)");
			b.Property<string>("Status").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<string>("SupplierName").IsRequired().HasColumnType("nvarchar(max)");
			b.HasKey("SupplierId");
			b.ToTable("Suppliers");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SupplierOrder", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("SupplierOrderId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("SupplierOrderId").UseIdentityColumn(1L);
			b.Property<DateTime>("OrderDate").HasColumnType("datetime2");
			b.Property<int>("SupplierId").HasColumnType("int");
			b.Property<decimal>("TotalAmount").HasPrecision(18, 2).HasColumnType("decimal(18,2)");
			b.HasKey("SupplierOrderId");
			b.HasIndex("SupplierId");
			b.ToTable("SupplierOrders");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SystemSetting", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("SystemSettingId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("SystemSettingId").UseIdentityColumn(1L);
			b.Property<string>("AllowedValuesJson").HasColumnType("nvarchar(max)");
			b.Property<string>("Category").IsRequired().HasMaxLength(80)
				.HasColumnType("nvarchar(80)");
			b.Property<string>("DefaultValue").IsRequired().HasMaxLength(2000)
				.HasColumnType("nvarchar(2000)");
			b.Property<string>("Description").IsRequired().HasMaxLength(500)
				.HasColumnType("nvarchar(500)");
			b.Property<string>("DisplayName").IsRequired().HasMaxLength(120)
				.HasColumnType("nvarchar(120)");
			b.Property<bool>("IsActive").HasColumnType("bit");
			b.Property<bool>("IsSensitive").HasColumnType("bit");
			b.Property<bool>("IsSystemSetting").HasColumnType("bit");
			b.Property<string>("Key").IsRequired().HasMaxLength(150)
				.HasColumnType("nvarchar(150)");
			b.Property<string>("MaximumValue").HasMaxLength(100).HasColumnType("nvarchar(100)");
			b.Property<string>("MinimumValue").HasMaxLength(100).HasColumnType("nvarchar(100)");
			b.Property<bool>("RequiresRestart").HasColumnType("bit");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<string>("Unit").HasMaxLength(40).HasColumnType("nvarchar(40)");
			b.Property<DateTime>("UpdatedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("UpdatedByUserId").HasColumnType("int");
			b.Property<string>("Value").IsRequired().HasMaxLength(2000)
				.HasColumnType("nvarchar(2000)");
			b.Property<string>("ValueType").IsRequired().HasMaxLength(40)
				.HasColumnType("nvarchar(40)");
			b.HasKey("SystemSettingId");
			b.HasIndex("Key").IsUnique().HasDatabaseName("UX_SystemSettings_Key");
			b.HasIndex("UpdatedByUserId");
			b.HasIndex("Category", "IsActive");
			b.ToTable("SystemSettings", (string?)null);
			b.HasData(new
			{
				SystemSettingId = 1,
				Category = "Expiry",
				DefaultValue = "72",
				Description = "Hours before expiry when a batch becomes a yellow warning.",
				DisplayName = "Yellow warning threshold",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Expiry.YellowThresholdHours",
				MaximumValue = "720",
				MinimumValue = "2",
				RequiresRestart = false,
				Unit = "hours",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "72",
				ValueType = "TimeSpanHours"
			}, new
			{
				SystemSettingId = 2,
				Category = "Expiry",
				DefaultValue = "24",
				Description = "Hours before expiry when a batch becomes urgent.",
				DisplayName = "Red urgent threshold",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Expiry.RedThresholdHours",
				MaximumValue = "168",
				MinimumValue = "1",
				RequiresRestart = false,
				Unit = "hours",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "24",
				ValueType = "TimeSpanHours"
			}, new
			{
				SystemSettingId = 3,
				Category = "Expiry",
				DefaultValue = "60",
				Description = "Minutes between automatic expiry scans.",
				DisplayName = "Expiry scan interval",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Expiry.ScanIntervalMinutes",
				MaximumValue = "1440",
				MinimumValue = "1",
				RequiresRestart = false,
				Unit = "minutes",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "60",
				ValueType = "TimeSpanMinutes"
			}, new
			{
				SystemSettingId = 4,
				Category = "Expiry",
				DefaultValue = "2",
				Description = "Days added by a permitted one-time shelf-life extension.",
				DisplayName = "Shelf-life extension",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Expiry.ShelfLifeExtensionDays",
				MaximumValue = "14",
				MinimumValue = "1",
				RequiresRestart = false,
				Unit = "days",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "2",
				ValueType = "Integer"
			}, new
			{
				SystemSettingId = 5,
				Category = "Expiry",
				DefaultValue = "48",
				Description = "Hours before a newly generated expiry decision link expires.",
				DisplayName = "Expiry action-link lifetime",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Expiry.ActionTokenLifetimeHours",
				MaximumValue = "168",
				MinimumValue = "1",
				RequiresRestart = false,
				Unit = "hours",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "48",
				ValueType = "TimeSpanHours"
			}, new
			{
				SystemSettingId = 6,
				Category = "Expiry",
				DefaultValue = "[\"BusinessManager\",\"CEO\",\"COO\",\"StockTaker\"]",
				Description = "Active role codes that receive new expiry-alert emails.",
				DisplayName = "Expiry recipient roles",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Expiry.RecipientRoleCodes",
				RequiresRestart = false,
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "[\"BusinessManager\",\"CEO\",\"COO\",\"StockTaker\"]",
				ValueType = "StringArray"
			}, new
			{
				SystemSettingId = 7,
				Category = "Orders",
				DefaultValue = "72",
				Description = "Hours before a newly created customer order link expires.",
				DisplayName = "Customer order-link lifetime",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Orders.OrderLinkLifetimeHours",
				MaximumValue = "168",
				MinimumValue = "1",
				RequiresRestart = false,
				Unit = "hours",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "72",
				ValueType = "TimeSpanHours"
			}, new
			{
				SystemSettingId = 8,
				Category = "Orders",
				DefaultValue = "0",
				Description = "Extra hours beyond requested delivery time that reserved batches must remain valid.",
				DisplayName = "Delivery stock-safety window",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Orders.DeliverySafetyHours",
				MaximumValue = "168",
				MinimumValue = "0",
				RequiresRestart = false,
				Unit = "hours",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "0",
				ValueType = "TimeSpanHours"
			}, new
			{
				SystemSettingId = 9,
				Category = "Delivery",
				DefaultValue = "120",
				Description = "Duration used for a new schedule when no end time is supplied.",
				DisplayName = "Default delivery duration",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Delivery.DefaultDurationMinutes",
				MaximumValue = "1440",
				MinimumValue = "15",
				RequiresRestart = false,
				Unit = "minutes",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "120",
				ValueType = "TimeSpanMinutes"
			}, new
			{
				SystemSettingId = 10,
				Category = "Security",
				DefaultValue = "5",
				Description = "Minutes before a login verification code expires.",
				DisplayName = "OTP lifetime",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Security.OtpLifetimeMinutes",
				MaximumValue = "15",
				MinimumValue = "2",
				RequiresRestart = false,
				Unit = "minutes",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "5",
				ValueType = "TimeSpanMinutes"
			}, new
			{
				SystemSettingId = 11,
				Category = "Security",
				DefaultValue = "5",
				Description = "Failed verification attempts allowed before a challenge is locked.",
				DisplayName = "OTP maximum attempts",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Security.OtpMaximumAttempts",
				MaximumValue = "10",
				MinimumValue = "3",
				RequiresRestart = false,
				Unit = "attempts",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "5",
				ValueType = "Integer"
			}, new
			{
				SystemSettingId = 12,
				Category = "Security",
				DefaultValue = "60",
				Description = "Seconds before another verification code may be sent.",
				DisplayName = "OTP resend delay",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Security.OtpResendDelaySeconds",
				MaximumValue = "300",
				MinimumValue = "30",
				RequiresRestart = false,
				Unit = "seconds",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "60",
				ValueType = "Integer"
			}, new
			{
				SystemSettingId = 13,
				Category = "Security",
				DefaultValue = "5",
				Description = "Verification emails allowed for one account in a rolling hour.",
				DisplayName = "OTP hourly resend limit",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Security.OtpMaximumResendsPerHour",
				MaximumValue = "10",
				MinimumValue = "1",
				RequiresRestart = false,
				Unit = "resends",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "5",
				ValueType = "Integer"
			}, new
			{
				SystemSettingId = 14,
				Category = "Security",
				DefaultValue = "30",
				Description = "Days before a trusted-device token expires.",
				DisplayName = "Trusted-device lifetime",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Security.TrustedDeviceDays",
				MaximumValue = "90",
				MinimumValue = "1",
				RequiresRestart = false,
				Unit = "days",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "30",
				ValueType = "Integer"
			}, new
			{
				SystemSettingId = 15,
				Category = "Security",
				DefaultValue = "10",
				Description = "One-time recovery codes generated for a user.",
				DisplayName = "Recovery-code count",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Security.RecoveryCodeCount",
				MaximumValue = "10",
				MinimumValue = "10",
				RequiresRestart = false,
				Unit = "codes",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "10",
				ValueType = "Integer"
			}, new
			{
				SystemSettingId = 16,
				Category = "Files",
				DefaultValue = "10",
				Description = "Maximum upload size for a delivery proof image.",
				DisplayName = "Proof-image maximum size",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Files.ProofImageMaximumMb",
				MaximumValue = "25",
				MinimumValue = "1",
				RequiresRestart = false,
				Unit = "MB",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "10",
				ValueType = "Integer"
			}, new
			{
				SystemSettingId = 17,
				Category = "Files",
				DefaultValue = "250",
				Description = "Maximum upload size for a training video.",
				DisplayName = "Training-video maximum size",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Files.TrainingVideoMaximumMb",
				MaximumValue = "500",
				MinimumValue = "10",
				RequiresRestart = false,
				Unit = "MB",
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "250",
				ValueType = "Integer"
			}, new
			{
				SystemSettingId = 18,
				Category = "Delivery",
				DefaultValue = "true",
				Description = "Require an active delivery proof image before final completion.",
				DisplayName = "Require proof image",
				IsActive = true,
				IsSensitive = false,
				IsSystemSetting = true,
				Key = "Delivery.RequireProofImageForCompletion",
				RequiresRestart = false,
				UpdatedAtUtc = new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc),
				Value = "true",
				ValueType = "Boolean"
			});
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SystemSettingHistory", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("SystemSettingHistoryId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("SystemSettingHistoryId").UseIdentityColumn(1L);
			b.Property<bool>("AppliedSuccessfully").HasColumnType("bit");
			b.Property<DateTime>("ChangedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("ChangedByUserId").HasColumnType("int");
			b.Property<string>("CorrelationId").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<string>("FailureReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<string>("NewValue").IsRequired().HasMaxLength(2000)
				.HasColumnType("nvarchar(2000)");
			b.Property<string>("PreviousValue").IsRequired().HasMaxLength(2000)
				.HasColumnType("nvarchar(2000)");
			b.Property<string>("Reason").IsRequired().HasMaxLength(500)
				.HasColumnType("nvarchar(500)");
			b.Property<int>("SystemSettingId").HasColumnType("int");
			b.HasKey("SystemSettingHistoryId");
			b.HasIndex("ChangedByUserId");
			b.HasIndex("SystemSettingId", "ChangedAtUtc");
			b.ToTable("SystemSettingHistory", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.TrustedDevice", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("TrustedDeviceId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("TrustedDeviceId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("DeviceName").IsRequired().HasMaxLength(120)
				.HasColumnType("nvarchar(120)");
			b.Property<DateTime>("ExpiresAtUtc").HasColumnType("datetime2");
			b.Property<DateTime>("LastUsedAtUtc").HasColumnType("datetime2");
			b.Property<string>("RevocationReason").HasMaxLength(300).HasColumnType("nvarchar(300)");
			b.Property<DateTime?>("RevokedAtUtc").HasColumnType("datetime2");
			b.Property<int?>("RevokedByUserId").HasColumnType("int");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<int>("SecurityVersionSnapshot").HasColumnType("int");
			b.Property<string>("TokenHash").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<string>("UserAgentSummary").HasMaxLength(256).HasColumnType("nvarchar(256)");
			b.Property<int>("UserId").HasColumnType("int");
			b.HasKey("TrustedDeviceId");
			b.HasIndex("RevokedByUserId");
			b.HasIndex("TokenHash").IsUnique().HasDatabaseName("UX_TrustedDevices_TokenHash");
			b.HasIndex("UserId", "RevokedAtUtc", "ExpiresAtUtc");
			b.ToTable("TrustedDevices", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.User", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("UserId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("UserId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedDate").HasColumnType("datetime2");
			b.Property<string>("Email").IsRequired().HasMaxLength(100)
				.HasColumnType("nvarchar(100)");
			b.Property<string>("FirstName").IsRequired().HasMaxLength(50)
				.HasColumnType("nvarchar(50)");
			b.Property<string>("LastName").IsRequired().HasMaxLength(50)
				.HasColumnType("nvarchar(50)");
			b.Property<string>("NormalizedEmail").IsRequired().HasMaxLength(100)
				.HasColumnType("nvarchar(100)");
			b.Property<string>("PasswordHash").IsRequired().HasColumnType("nvarchar(max)");
			b.Property<DateTime?>("PasswordResetTokenExpiry").HasColumnType("datetime2");
			b.Property<string>("PasswordResetTokenHash").HasMaxLength(256).HasColumnType("nvarchar(256)");
			b.Property<string>("PhoneNumber").HasMaxLength(20).HasColumnType("nvarchar(20)");
			b.Property<int>("RoleId").HasColumnType("int");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<int>("SecurityVersion").HasColumnType("int");
			b.Property<string>("Status").IsRequired().HasMaxLength(20)
				.HasColumnType("nvarchar(20)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.HasKey("UserId");
			b.HasIndex("NormalizedEmail").IsUnique().HasDatabaseName("UX_Users_NormalizedEmail");
			b.HasIndex("RoleId");
			b.HasIndex("Status", "RoleId");
			b.ToTable("Users", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.UserOtpChallenge", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("UserOtpChallengeId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("UserOtpChallengeId").UseIdentityColumn(1L);
			b.Property<int>("AttemptCount").HasColumnType("int");
			b.Property<string>("ChallengeTokenHash").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<DateTime?>("ConsumedAtUtc").HasColumnType("datetime2");
			b.Property<string>("CorrelationId").IsRequired().HasMaxLength(64)
				.HasColumnType("nvarchar(64)");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<DateTime>("ExpiresAtUtc").HasColumnType("datetime2");
			b.Property<string>("FailureReason").HasMaxLength(160).HasColumnType("nvarchar(160)");
			b.Property<string>("IpAddressSummary").HasMaxLength(64).HasColumnType("nvarchar(64)");
			b.Property<DateTime>("LastSentAtUtc").HasColumnType("datetime2");
			b.Property<int>("MaximumAttempts").HasColumnType("int");
			b.Property<string>("OtpHash").IsRequired().HasMaxLength(256)
				.HasColumnType("nvarchar(256)");
			b.Property<string>("Purpose").IsRequired().HasMaxLength(40)
				.HasColumnType("nvarchar(40)");
			b.Property<int>("ResendCount").HasColumnType("int");
			b.Property<DateTime?>("RevokedAtUtc").HasColumnType("datetime2");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<int>("SecurityVersionSnapshot").HasColumnType("int");
			b.Property<string>("UserAgentSummary").HasMaxLength(256).HasColumnType("nvarchar(256)");
			b.Property<int>("UserId").HasColumnType("int");
			b.HasKey("UserOtpChallengeId");
			b.HasIndex("ChallengeTokenHash").IsUnique().HasDatabaseName("UX_UserOtpChallenges_ChallengeHash");
			b.HasIndex("UserId", "Purpose", "ExpiresAtUtc");
			b.ToTable("UserOtpChallenges", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.UserRecoveryCode", delegate(EntityTypeBuilder b)
		{
			b.Property<long>("UserRecoveryCodeId").ValueGeneratedOnAdd().HasColumnType("bigint");
			b.Property<long>("UserRecoveryCodeId").UseIdentityColumn(1L);
			b.Property<string>("CodeHash").IsRequired().HasMaxLength(256)
				.HasColumnType("nvarchar(256)");
			b.Property<int>("CodeOrder").HasColumnType("int");
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<DateTime?>("RevokedAtUtc").HasColumnType("datetime2");
			b.Property<int>("SecurityVersionSnapshot").HasColumnType("int");
			b.Property<DateTime?>("UsedAtUtc").HasColumnType("datetime2");
			b.Property<int>("UserId").HasColumnType("int");
			b.HasKey("UserRecoveryCodeId");
			b.HasIndex("UserId", "CodeOrder", "CreatedAtUtc");
			b.ToTable("UserRecoveryCodes", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.WarehouseSection", delegate(EntityTypeBuilder b)
		{
			b.Property<int>("SectionId").ValueGeneratedOnAdd().HasColumnType("int");
			b.Property<int>("SectionId").UseIdentityColumn(1L);
			b.Property<DateTime>("CreatedAtUtc").HasColumnType("datetime2");
			b.Property<string>("Description").HasMaxLength(500).HasColumnType("nvarchar(500)");
			b.Property<byte[]>("RowVersion").IsConcurrencyToken().ValueGeneratedOnAddOrUpdate()
				.HasColumnType("rowversion");
			b.Property<string>("SectionCode").IsRequired().HasMaxLength(40)
				.HasColumnType("nvarchar(40)");
			b.Property<string>("SectionName").IsRequired().HasMaxLength(100)
				.HasColumnType("nvarchar(100)");
			b.Property<string>("Status").IsRequired().HasMaxLength(20)
				.HasColumnType("nvarchar(20)");
			b.Property<DateTime?>("UpdatedAtUtc").HasColumnType("datetime2");
			b.HasKey("SectionId");
			b.HasIndex("SectionCode").IsUnique().HasDatabaseName("UX_WarehouseSections_SectionCode");
			b.HasIndex("Status", "SectionName");
			b.ToTable("WarehouseSections", (string?)null);
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Businessmanager", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithMany().HasForeignKey("UserId")
				.OnDelete(DeleteBehavior.Cascade)
				.IsRequired();
			b.Navigation("User");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.CEO", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithMany().HasForeignKey("UserId")
				.OnDelete(DeleteBehavior.Cascade)
				.IsRequired();
			b.Navigation("User");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.COO", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithMany().HasForeignKey("UserId")
				.OnDelete(DeleteBehavior.Cascade)
				.IsRequired();
			b.Navigation("User");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.CustomerOrderLink", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "CreatedByUser").WithMany().HasForeignKey("CreatedByUserId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.Customer", "Customer").WithMany("OrderLinks").HasForeignKey("CustomerId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.SalesOrder", "SalesOrder").WithOne().HasForeignKey("PhenyoSyncAPI.Entities.CustomerOrderLink", "SalesOrderId")
				.OnDelete(DeleteBehavior.Restrict);
			b.Navigation("CreatedByUser");
			b.Navigation("Customer");
			b.Navigation("SalesOrder");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Delivery", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "AssignedByUser").WithMany().HasForeignKey("AssignedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.User", "CompletedByUser").WithMany().HasForeignKey("CompletedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.Driver", "Driver").WithMany("Deliveries").HasForeignKey("DriverId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.SalesOrder", "SalesOrder").WithOne("Delivery").HasForeignKey("PhenyoSyncAPI.Entities.Delivery", "SalesOrderId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.User", "StartedByUser").WithMany().HasForeignKey("StartedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.Navigation("AssignedByUser");
			b.Navigation("CompletedByUser");
			b.Navigation("Driver");
			b.Navigation("SalesOrder");
			b.Navigation("StartedByUser");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.DeliveryCompletionRecord", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.Driver", "CompletedByDriver").WithMany("CompletionRecords").HasForeignKey("CompletedByDriverId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.User", "CompletedByUser").WithMany().HasForeignKey("CompletedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.Delivery", "Delivery").WithOne("CompletionRecord").HasForeignKey("PhenyoSyncAPI.Entities.DeliveryCompletionRecord", "DeliveryId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("CompletedByDriver");
			b.Navigation("CompletedByUser");
			b.Navigation("Delivery");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.DeliveryDriverAssignment", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "AssignedByUser").WithMany().HasForeignKey("AssignedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.Delivery", "Delivery").WithMany("DriverAssignments").HasForeignKey("DeliveryId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.Driver", "Driver").WithMany("AssignmentHistory").HasForeignKey("DriverId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.User", "UnassignedByUser").WithMany().HasForeignKey("UnassignedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.Navigation("AssignedByUser");
			b.Navigation("Delivery");
			b.Navigation("Driver");
			b.Navigation("UnassignedByUser");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.DeliveryProofImage", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.Delivery", "Delivery").WithMany("ProofImages").HasForeignKey("DeliveryId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.User", "RemovedByUser").WithMany().HasForeignKey("RemovedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.StoredFile", "StoredFile").WithMany().HasForeignKey("StoredFileId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.StoredFile", "ThumbnailStoredFile").WithMany().HasForeignKey("ThumbnailStoredFileId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.Driver", "UploadedByDriver").WithMany().HasForeignKey("UploadedByDriverId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.User", "UploadedByUser").WithMany().HasForeignKey("UploadedByUserId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("Delivery");
			b.Navigation("RemovedByUser");
			b.Navigation("StoredFile");
			b.Navigation("ThumbnailStoredFile");
			b.Navigation("UploadedByDriver");
			b.Navigation("UploadedByUser");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.DeliveryStatusHistory", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "ChangedByUser").WithMany().HasForeignKey("ChangedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.Delivery", "Delivery").WithMany("StatusHistory").HasForeignKey("DeliveryId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("ChangedByUser");
			b.Navigation("Delivery");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Driver", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithOne("Driver").HasForeignKey("PhenyoSyncAPI.Entities.Driver", "UserId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("User");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ExpiryActionToken", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.ProductBatch", "ProductBatch").WithMany("ExpiryActionTokens").HasForeignKey("ProductBatchId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("ProductBatch");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.HelpContextMapping", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.HelpTopic", "HelpTopic").WithMany("ContextMappings").HasForeignKey("HelpTopicId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("HelpTopic");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.HelpMedia", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.StoredFile", "CaptionStoredFile").WithMany().HasForeignKey("CaptionStoredFileId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.HelpTopic", "HelpTopic").WithMany("Media").HasForeignKey("HelpTopicId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.User", "RemovedByUser").WithMany().HasForeignKey("RemovedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.StoredFile", "StoredFile").WithMany().HasForeignKey("StoredFileId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.User", "UploadedByUser").WithMany().HasForeignKey("UploadedByUserId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("CaptionStoredFile");
			b.Navigation("HelpTopic");
			b.Navigation("RemovedByUser");
			b.Navigation("StoredFile");
			b.Navigation("UploadedByUser");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.HelpTopic", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.HelpCategory", "Category").WithMany("Topics").HasForeignKey("HelpCategoryId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.User", "UpdatedByUser").WithMany().HasForeignKey("UpdatedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.Navigation("Category");
			b.Navigation("UpdatedByUser");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Invoice", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.SalesOrder", "SalesOrder").WithOne("Invoice").HasForeignKey("PhenyoSyncAPI.Entities.Invoice", "SalesOrderId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("SalesOrder");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.LookupValue", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.LookupType", "LookupType").WithMany("Values").HasForeignKey("LookupTypeId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("LookupType");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.LookupValueHistory", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "ChangedByUser").WithMany().HasForeignKey("ChangedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.LookupValue", "LookupValue").WithMany("History").HasForeignKey("LookupValueId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("ChangedByUser");
			b.Navigation("LookupValue");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.OrderStatusHistory", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "ChangedByUser").WithMany().HasForeignKey("ChangedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.SalesOrder", "SalesOrder").WithMany("StatusHistory").HasForeignKey("SalesOrderId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("ChangedByUser");
			b.Navigation("SalesOrder");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.OrderStockReservation", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.ProductBatch", "ProductBatch").WithMany("OrderStockReservations").HasForeignKey("ProductBatchId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.Product", "Product").WithMany("OrderStockReservations").HasForeignKey("ProductId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.SalesOrder", "SalesOrder").WithMany("StockReservations").HasForeignKey("SalesOrderId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.SalesOrderItem", "SalesOrderItem").WithMany("StockReservations").HasForeignKey("SalesOrderItemId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.WarehouseSection", "WarehouseSection").WithMany("OrderStockReservations").HasForeignKey("SectionId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.Stock", "Stock").WithMany("OrderStockReservations").HasForeignKey("StockId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("Product");
			b.Navigation("ProductBatch");
			b.Navigation("SalesOrder");
			b.Navigation("SalesOrderItem");
			b.Navigation("Stock");
			b.Navigation("WarehouseSection");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Packer", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithMany().HasForeignKey("UserId")
				.OnDelete(DeleteBehavior.Cascade)
				.IsRequired();
			b.Navigation("User");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Product", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.ProductCategory", "ProductCategory").WithMany("Products").HasForeignKey("ProductCategoryId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.ProductType", "ProductType").WithMany("Products").HasForeignKey("ProductTypeId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("ProductCategory");
			b.Navigation("ProductType");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductBatch", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.Product", "Product").WithMany("ProductBatches").HasForeignKey("ProductId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.WarehouseSection", "WarehouseSection").WithMany("ProductBatches").HasForeignKey("SectionId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.User", "ShelfLifeExtendedByUser").WithMany("ExtendedProductBatches").HasForeignKey("ShelfLifeExtendedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.Navigation("Product");
			b.Navigation("ShelfLifeExtendedByUser");
			b.Navigation("WarehouseSection");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductPrice", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "CreatedByUser").WithMany().HasForeignKey("CreatedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.User", "DeletedByUser").WithMany().HasForeignKey("DeletedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.Product", "Product").WithMany("ProductPrices").HasForeignKey("ProductId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("CreatedByUser");
			b.Navigation("DeletedByUser");
			b.Navigation("Product");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.RolePermission", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "AssignedByUser").WithMany().HasForeignKey("AssignedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.Permission", "Permission").WithMany("RolePermissions").HasForeignKey("PermissionId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.Role", "Role").WithMany("RolePermissions").HasForeignKey("RoleId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("AssignedByUser");
			b.Navigation("Permission");
			b.Navigation("Role");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SalesOrder", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "CancelledByUser").WithMany().HasForeignKey("CancelledByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.User", "CreatedByUser").WithMany().HasForeignKey("CreatedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.CustomerOrderLink", "CreatedViaOrderLink").WithMany().HasForeignKey("CreatedViaOrderLinkId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.Customer", "Customer").WithMany("SalesOrders").HasForeignKey("CustomerId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.User", "PackedByUser").WithMany().HasForeignKey("PackedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.User", "ValidatedByUser").WithMany().HasForeignKey("ValidatedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.Navigation("CancelledByUser");
			b.Navigation("CreatedByUser");
			b.Navigation("CreatedViaOrderLink");
			b.Navigation("Customer");
			b.Navigation("PackedByUser");
			b.Navigation("ValidatedByUser");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SalesOrderItem", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.Product", "Product").WithMany("SalesOrderItems").HasForeignKey("ProductId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.ProductPrice", "ProductPrice").WithMany("SalesOrderItems").HasForeignKey("ProductPriceId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.SalesOrder", "SalesOrder").WithMany("Items").HasForeignKey("SalesOrderId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("Product");
			b.Navigation("ProductPrice");
			b.Navigation("SalesOrder");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Stock", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.Product", "Product").WithMany("Stocks").HasForeignKey("ProductId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.WarehouseSection", "WarehouseSection").WithMany("Stocks").HasForeignKey("SectionId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("Product");
			b.Navigation("WarehouseSection");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.StockMovement", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "CreatedByUser").WithMany("CreatedStockMovements").HasForeignKey("CreatedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.ProductBatch", "ProductBatch").WithMany("StockMovements").HasForeignKey("ProductBatchId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.Product", "Product").WithMany("StockMovements").HasForeignKey("ProductId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.SalesOrder", "SalesOrder").WithMany("StockMovements").HasForeignKey("SalesOrderId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.WarehouseSection", "WarehouseSection").WithMany("StockMovements").HasForeignKey("SectionId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("CreatedByUser");
			b.Navigation("Product");
			b.Navigation("ProductBatch");
			b.Navigation("SalesOrder");
			b.Navigation("WarehouseSection");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.StockTakeSession", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithMany("StockTakeSessions").HasForeignKey("UserId")
				.OnDelete(DeleteBehavior.Cascade)
				.IsRequired();
			b.HasOne("PhenyoSyncAPI.Entities.WarehouseSection", "WarehouseSection").WithMany("StockTakeSessions").HasForeignKey("WarehouseSectionSectionId")
				.OnDelete(DeleteBehavior.Cascade)
				.IsRequired();
			b.Navigation("User");
			b.Navigation("WarehouseSection");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Stocktaker", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithMany().HasForeignKey("UserId")
				.OnDelete(DeleteBehavior.Cascade)
				.IsRequired();
			b.Navigation("User");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.StoredFile", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "DeletedByUser").WithMany().HasForeignKey("DeletedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.User", "UploadedByUser").WithMany().HasForeignKey("UploadedByUserId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("DeletedByUser");
			b.Navigation("UploadedByUser");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SupplierOrder", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.Supplier", "Supplier").WithMany("SupplierOrders").HasForeignKey("SupplierId")
				.OnDelete(DeleteBehavior.Cascade)
				.IsRequired();
			b.Navigation("Supplier");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SystemSetting", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "UpdatedByUser").WithMany().HasForeignKey("UpdatedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.Navigation("UpdatedByUser");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SystemSettingHistory", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "ChangedByUser").WithMany().HasForeignKey("ChangedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.SystemSetting", "SystemSetting").WithMany("History").HasForeignKey("SystemSettingId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("ChangedByUser");
			b.Navigation("SystemSetting");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.TrustedDevice", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "RevokedByUser").WithMany().HasForeignKey("RevokedByUserId")
				.OnDelete(DeleteBehavior.Restrict);
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithMany().HasForeignKey("UserId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("RevokedByUser");
			b.Navigation("User");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.User", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.Role", "Role").WithMany("Users").HasForeignKey("RoleId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("Role");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.UserOtpChallenge", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithMany().HasForeignKey("UserId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("User");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.UserRecoveryCode", delegate(EntityTypeBuilder b)
		{
			b.HasOne("PhenyoSyncAPI.Entities.User", "User").WithMany().HasForeignKey("UserId")
				.OnDelete(DeleteBehavior.Restrict)
				.IsRequired();
			b.Navigation("User");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Customer", delegate(EntityTypeBuilder b)
		{
			b.Navigation("OrderLinks");
			b.Navigation("SalesOrders");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Delivery", delegate(EntityTypeBuilder b)
		{
			b.Navigation("CompletionRecord");
			b.Navigation("DriverAssignments");
			b.Navigation("ProofImages");
			b.Navigation("StatusHistory");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Driver", delegate(EntityTypeBuilder b)
		{
			b.Navigation("AssignmentHistory");
			b.Navigation("CompletionRecords");
			b.Navigation("Deliveries");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.HelpCategory", delegate(EntityTypeBuilder b)
		{
			b.Navigation("Topics");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.HelpTopic", delegate(EntityTypeBuilder b)
		{
			b.Navigation("ContextMappings");
			b.Navigation("Media");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.LookupType", delegate(EntityTypeBuilder b)
		{
			b.Navigation("Values");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.LookupValue", delegate(EntityTypeBuilder b)
		{
			b.Navigation("History");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Permission", delegate(EntityTypeBuilder b)
		{
			b.Navigation("RolePermissions");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Product", delegate(EntityTypeBuilder b)
		{
			b.Navigation("OrderStockReservations");
			b.Navigation("ProductBatches");
			b.Navigation("ProductPrices");
			b.Navigation("SalesOrderItems");
			b.Navigation("StockMovements");
			b.Navigation("Stocks");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductBatch", delegate(EntityTypeBuilder b)
		{
			b.Navigation("ExpiryActionTokens");
			b.Navigation("OrderStockReservations");
			b.Navigation("StockMovements");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductCategory", delegate(EntityTypeBuilder b)
		{
			b.Navigation("Products");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductPrice", delegate(EntityTypeBuilder b)
		{
			b.Navigation("SalesOrderItems");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.ProductType", delegate(EntityTypeBuilder b)
		{
			b.Navigation("Products");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Role", delegate(EntityTypeBuilder b)
		{
			b.Navigation("RolePermissions");
			b.Navigation("Users");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SalesOrder", delegate(EntityTypeBuilder b)
		{
			b.Navigation("Delivery");
			b.Navigation("Invoice");
			b.Navigation("Items");
			b.Navigation("StatusHistory");
			b.Navigation("StockMovements");
			b.Navigation("StockReservations");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SalesOrderItem", delegate(EntityTypeBuilder b)
		{
			b.Navigation("StockReservations");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Stock", delegate(EntityTypeBuilder b)
		{
			b.Navigation("OrderStockReservations");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.Supplier", delegate(EntityTypeBuilder b)
		{
			b.Navigation("SupplierOrders");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.SystemSetting", delegate(EntityTypeBuilder b)
		{
			b.Navigation("History");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.User", delegate(EntityTypeBuilder b)
		{
			b.Navigation("CreatedStockMovements");
			b.Navigation("Driver");
			b.Navigation("ExtendedProductBatches");
			b.Navigation("StockTakeSessions");
		});
		modelBuilder.Entity("PhenyoSyncAPI.Entities.WarehouseSection", delegate(EntityTypeBuilder b)
		{
			b.Navigation("OrderStockReservations");
			b.Navigation("ProductBatches");
			b.Navigation("StockMovements");
			b.Navigation("StockTakeSessions");
			b.Navigation("Stocks");
		});
	}
}
