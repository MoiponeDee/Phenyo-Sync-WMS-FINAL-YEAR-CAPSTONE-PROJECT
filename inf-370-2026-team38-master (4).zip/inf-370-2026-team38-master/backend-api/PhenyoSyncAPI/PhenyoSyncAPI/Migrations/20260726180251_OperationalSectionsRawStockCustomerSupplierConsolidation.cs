﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class OperationalSectionsRawStockCustomerSupplierConsolidation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Suppliers",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Phone",
                table: "Suppliers",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "Suppliers",
                type: "nvarchar(254)",
                maxLength: 254,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ContactPerson",
                table: "Suppliers",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Address",
                table: "Suppliers",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                table: "Suppliers",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "NormalizedEmail",
                table: "Suppliers",
                type: "nvarchar(254)",
                maxLength: 254,
                nullable: true);

            migrationBuilder.AddColumn<byte[]>(
                name: "RowVersion",
                table: "Suppliers",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SupplierCode",
                table: "Suppliers",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "SupplierTypeCode",
                table: "Suppliers",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "UpdatedAtUtc",
                table: "Suppliers",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ApprovedAtUtc",
                table: "SupplierOrders",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ApprovedByUserId",
                table: "SupplierOrders",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CancelledAtUtc",
                table: "SupplierOrders",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                table: "SupplierOrders",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<int>(
                name: "CreatedByUserId",
                table: "SupplierOrders",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ExpectedDeliveryAtUtc",
                table: "SupplierOrders",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Notes",
                table: "SupplierOrders",
                type: "nvarchar(1000)",
                maxLength: 1000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "OrderNumber",
                table: "SupplierOrders",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<byte[]>(
                name: "RowVersion",
                table: "SupplierOrders",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "SupplierOrders",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "WarehouseSectionId",
                table: "SupplierOrders",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "ContactPerson",
                table: "Customers",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "NormalizedEmail",
                table: "Customers",
                type: "nvarchar(254)",
                maxLength: 254,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<byte[]>(
                name: "RowVersion",
                table: "Customers",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ProductId",
                table: "BuyerProcurementItems",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "RawStockItemId",
                table: "BuyerProcurementItems",
                type: "int",
                nullable: true);

            migrationBuilder.Sql("""
                UPDATE dbo.Suppliers
                SET SupplierCode =
                        CONCAT('SUP-', RIGHT(CONCAT('000000', SupplierId), 6)),
                    SupplierTypeCode =
                        CASE
                            WHEN NULLIF(LTRIM(RTRIM(SupplierTypeCode)), '') IS NULL
                                THEN 'GENERAL_SUPPLIER'
                            ELSE UPPER(LTRIM(RTRIM(SupplierTypeCode)))
                        END,
                    NormalizedEmail =
                        CASE
                            WHEN NULLIF(LTRIM(RTRIM(Email)), '') IS NULL THEN NULL
                            ELSE UPPER(LTRIM(RTRIM(Email)))
                        END,
                    CreatedAtUtc =
                        CASE
                            WHEN CreatedAtUtc = '0001-01-01T00:00:00'
                                THEN SYSUTCDATETIME()
                            ELSE CreatedAtUtc
                        END;

                UPDATE dbo.Customers
                SET NormalizedEmail = UPPER(LTRIM(RTRIM(Email)));

                IF EXISTS (
                    SELECT NormalizedEmail
                    FROM dbo.Customers
                    GROUP BY NormalizedEmail
                    HAVING COUNT(*) > 1)
                BEGIN
                    THROW 51001,
                        'Duplicate customer emails must be resolved before the operational-sections migration can continue.',
                        1;
                END;

                IF EXISTS (SELECT 1 FROM dbo.SupplierOrders)
                   AND NOT EXISTS (SELECT 1 FROM dbo.WarehouseSections)
                BEGIN
                    THROW 51002,
                        'At least one Warehouse Section is required to backfill existing Supplier Orders.',
                        1;
                END;

                UPDATE supplierOrder
                SET OrderNumber =
                        CONCAT('SUPORD-', RIGHT(CONCAT('00000000', SupplierOrderId), 8)),
                    Status =
                        CASE
                            WHEN NULLIF(LTRIM(RTRIM(Status)), '') IS NULL
                                THEN 'Draft'
                            ELSE Status
                        END,
                    CreatedAtUtc =
                        CASE
                            WHEN CreatedAtUtc = '0001-01-01T00:00:00'
                                THEN COALESCE(OrderDate, SYSUTCDATETIME())
                            ELSE CreatedAtUtc
                        END,
                    WarehouseSectionId =
                        (SELECT TOP (1) SectionId
                         FROM dbo.WarehouseSections
                         ORDER BY
                             CASE WHEN Status = 'Active' THEN 0 ELSE 1 END,
                             SectionId)
                FROM dbo.SupplierOrders supplierOrder;
                """);

            migrationBuilder.CreateTable(
                name: "FinancialPayments",
                columns: table => new
                {
                    FinancialPaymentId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PaymentNumber = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    CounterpartyType = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    CustomerId = table.Column<int>(type: "int", nullable: true),
                    SupplierId = table.Column<int>(type: "int", nullable: true),
                    InvoiceId = table.Column<int>(type: "int", nullable: true),
                    SupplierOrderId = table.Column<int>(type: "int", nullable: true),
                    OriginalPaymentId = table.Column<long>(type: "bigint", nullable: true),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    PaymentDateUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PaymentMethodCode = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Reference = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    Status = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    ReversalReason = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    CreatedByUserId = table.Column<int>(type: "int", nullable: false),
                    PostedByUserId = table.Column<int>(type: "int", nullable: true),
                    DecidedByUserId = table.Column<int>(type: "int", nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PostedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DecidedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FinancialPayments", x => x.FinancialPaymentId);
                    table.ForeignKey(
                        name: "FK_FinancialPayments_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "CustomerId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FinancialPayments_FinancialPayments_OriginalPaymentId",
                        column: x => x.OriginalPaymentId,
                        principalTable: "FinancialPayments",
                        principalColumn: "FinancialPaymentId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FinancialPayments_Invoices_InvoiceId",
                        column: x => x.InvoiceId,
                        principalTable: "Invoices",
                        principalColumn: "InvoiceId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FinancialPayments_SupplierOrders_SupplierOrderId",
                        column: x => x.SupplierOrderId,
                        principalTable: "SupplierOrders",
                        principalColumn: "SupplierOrderId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FinancialPayments_Suppliers_SupplierId",
                        column: x => x.SupplierId,
                        principalTable: "Suppliers",
                        principalColumn: "SupplierId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FinancialPayments_Users_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FinancialPayments_Users_DecidedByUserId",
                        column: x => x.DecidedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FinancialPayments_Users_PostedByUserId",
                        column: x => x.PostedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "OperationalReasons",
                columns: table => new
                {
                    OperationalReasonId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReasonCode = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    ReasonName = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false),
                    CategoryCode = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OperationalReasons", x => x.OperationalReasonId);
                });

            migrationBuilder.CreateTable(
                name: "RawStockItems",
                columns: table => new
                {
                    RawStockItemId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ItemCode = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    ItemName = table.Column<string>(type: "nvarchar(160)", maxLength: 160, nullable: false),
                    CategoryCode = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    DefaultUnitOfMeasure = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    IsProduce = table.Column<bool>(type: "bit", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockItems", x => x.RawStockItemId);
                });

            migrationBuilder.CreateTable(
                name: "RawStockReceipts",
                columns: table => new
                {
                    RawStockReceiptId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReceiptNumber = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    SourceType = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    SupplierId = table.Column<int>(type: "int", nullable: false),
                    SupplierOrderId = table.Column<int>(type: "int", nullable: true),
                    BuyerProcurementId = table.Column<int>(type: "int", nullable: true),
                    WarehouseSectionId = table.Column<int>(type: "int", nullable: false),
                    ReceivedByUserId = table.Column<int>(type: "int", nullable: false),
                    DocketReference = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false),
                    AdHocExplanation = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ReceivedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PostedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    OperationKeyHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockReceipts", x => x.RawStockReceiptId);
                    table.ForeignKey(
                        name: "FK_RawStockReceipts_BuyerProcurements_BuyerProcurementId",
                        column: x => x.BuyerProcurementId,
                        principalTable: "BuyerProcurements",
                        principalColumn: "BuyerProcurementId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockReceipts_SupplierOrders_SupplierOrderId",
                        column: x => x.SupplierOrderId,
                        principalTable: "SupplierOrders",
                        principalColumn: "SupplierOrderId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockReceipts_Suppliers_SupplierId",
                        column: x => x.SupplierId,
                        principalTable: "Suppliers",
                        principalColumn: "SupplierId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockReceipts_Users_ReceivedByUserId",
                        column: x => x.ReceivedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockReceipts_WarehouseSections_WarehouseSectionId",
                        column: x => x.WarehouseSectionId,
                        principalTable: "WarehouseSections",
                        principalColumn: "SectionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RawStockReconciliationGroups",
                columns: table => new
                {
                    RawStockReconciliationGroupId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GroupCode = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    GroupName = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockReconciliationGroups", x => x.RawStockReconciliationGroupId);
                });

            migrationBuilder.CreateTable(
                name: "RawStockTakeSessions",
                columns: table => new
                {
                    RawStockTakeSessionId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WarehouseSectionId = table.Column<int>(type: "int", nullable: false),
                    CreatedByUserId = table.Column<int>(type: "int", nullable: false),
                    ReviewedByUserId = table.Column<int>(type: "int", nullable: true),
                    DecidedByUserId = table.Column<int>(type: "int", nullable: true),
                    PeriodStartUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PeriodEndUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SubmittedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ReviewedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DecidedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ClosedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    AdministratorReviewNotes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ManagementDecisionReason = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ManagementApprovalRequired = table.Column<bool>(type: "bit", nullable: false),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockTakeSessions", x => x.RawStockTakeSessionId);
                    table.ForeignKey(
                        name: "FK_RawStockTakeSessions_Users_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockTakeSessions_Users_DecidedByUserId",
                        column: x => x.DecidedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockTakeSessions_Users_ReviewedByUserId",
                        column: x => x.ReviewedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockTakeSessions_WarehouseSections_WarehouseSectionId",
                        column: x => x.WarehouseSectionId,
                        principalTable: "WarehouseSections",
                        principalColumn: "SectionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RawStockBalances",
                columns: table => new
                {
                    RawStockBalanceId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false),
                    WarehouseSectionId = table.Column<int>(type: "int", nullable: false),
                    UnitOfMeasure = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    QuantityOnHand = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    ReservedQuantity = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    WeightedAverageUnitCost = table.Column<decimal>(type: "decimal(18,4)", precision: 18, scale: 4, nullable: false),
                    LastReceiptAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastStockTakeAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockBalances", x => x.RawStockBalanceId);
                    table.ForeignKey(
                        name: "FK_RawStockBalances_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockBalances_WarehouseSections_WarehouseSectionId",
                        column: x => x.WarehouseSectionId,
                        principalTable: "WarehouseSections",
                        principalColumn: "SectionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SupplierOrderLines",
                columns: table => new
                {
                    SupplierOrderLineId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SupplierOrderId = table.Column<int>(type: "int", nullable: false),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false),
                    OrderedQuantity = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    ReceivedQuantity = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    ExpectedUnitPrice = table.Column<decimal>(type: "decimal(18,4)", precision: 18, scale: 4, nullable: false),
                    UnitOfMeasure = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SupplierOrderLines", x => x.SupplierOrderLineId);
                    table.ForeignKey(
                        name: "FK_SupplierOrderLines_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SupplierOrderLines_SupplierOrders_SupplierOrderId",
                        column: x => x.SupplierOrderId,
                        principalTable: "SupplierOrders",
                        principalColumn: "SupplierOrderId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RawStockReceiptLines",
                columns: table => new
                {
                    RawStockReceiptLineId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RawStockReceiptId = table.Column<long>(type: "bigint", nullable: false),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false),
                    QuantityReceived = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    AcceptedQuantity = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    RejectedQuantity = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    UnitCost = table.Column<decimal>(type: "decimal(18,4)", precision: 18, scale: 4, nullable: false),
                    UnitOfMeasure = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    SupplierBatchReference = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: true),
                    BestBeforeAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockReceiptLines", x => x.RawStockReceiptLineId);
                    table.ForeignKey(
                        name: "FK_RawStockReceiptLines_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockReceiptLines_RawStockReceipts_RawStockReceiptId",
                        column: x => x.RawStockReceiptId,
                        principalTable: "RawStockReceipts",
                        principalColumn: "RawStockReceiptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProductReconciliationMappings",
                columns: table => new
                {
                    ProductReconciliationMappingId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RawStockReconciliationGroupId = table.Column<int>(type: "int", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductReconciliationMappings", x => x.ProductReconciliationMappingId);
                    table.ForeignKey(
                        name: "FK_ProductReconciliationMappings_Product_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductReconciliationMappings_RawStockReconciliationGroups_RawStockReconciliationGroupId",
                        column: x => x.RawStockReconciliationGroupId,
                        principalTable: "RawStockReconciliationGroups",
                        principalColumn: "RawStockReconciliationGroupId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RawStockReconciliationGroupItems",
                columns: table => new
                {
                    RawStockReconciliationGroupItemId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RawStockReconciliationGroupId = table.Column<int>(type: "int", nullable: false),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockReconciliationGroupItems", x => x.RawStockReconciliationGroupItemId);
                    table.ForeignKey(
                        name: "FK_RawStockReconciliationGroupItems_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockReconciliationGroupItems_RawStockReconciliationGroups_RawStockReconciliationGroupId",
                        column: x => x.RawStockReconciliationGroupId,
                        principalTable: "RawStockReconciliationGroups",
                        principalColumn: "RawStockReconciliationGroupId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RawStockTakeLines",
                columns: table => new
                {
                    RawStockTakeLineId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RawStockTakeSessionId = table.Column<long>(type: "bigint", nullable: false),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false),
                    RawStockBalanceId = table.Column<int>(type: "int", nullable: false),
                    RawStockReconciliationGroupId = table.Column<int>(type: "int", nullable: true),
                    OpeningRawStock = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    RawStockReceived = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    ApprovedPositiveAdjustments = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    ExistingPackedProductWeight = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    RecordedRawStockWriteOffs = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    ApprovedNegativeAdjustments = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    EstimatedRawStockRemaining = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    PhysicalStockCount = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: true),
                    UnexplainedStockDifference = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: true),
                    EstimatedFinancialImpact = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    IsMapped = table.Column<bool>(type: "bit", nullable: false),
                    RequiresManagementApproval = table.Column<bool>(type: "bit", nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockTakeLines", x => x.RawStockTakeLineId);
                    table.ForeignKey(
                        name: "FK_RawStockTakeLines_RawStockBalances_RawStockBalanceId",
                        column: x => x.RawStockBalanceId,
                        principalTable: "RawStockBalances",
                        principalColumn: "RawStockBalanceId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockTakeLines_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockTakeLines_RawStockReconciliationGroups_RawStockReconciliationGroupId",
                        column: x => x.RawStockReconciliationGroupId,
                        principalTable: "RawStockReconciliationGroups",
                        principalColumn: "RawStockReconciliationGroupId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockTakeLines_RawStockTakeSessions_RawStockTakeSessionId",
                        column: x => x.RawStockTakeSessionId,
                        principalTable: "RawStockTakeSessions",
                        principalColumn: "RawStockTakeSessionId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RawStockBatches",
                columns: table => new
                {
                    RawStockBatchId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false),
                    RawStockBalanceId = table.Column<int>(type: "int", nullable: false),
                    SupplierId = table.Column<int>(type: "int", nullable: true),
                    RawStockReceiptLineId = table.Column<long>(type: "bigint", nullable: true),
                    BatchCode = table.Column<string>(type: "nvarchar(70)", maxLength: 70, nullable: false),
                    QrCodeValue = table.Column<string>(type: "nvarchar(220)", maxLength: 220, nullable: false),
                    QuantityReceived = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    QuantityRemaining = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    UnitCost = table.Column<decimal>(type: "decimal(18,4)", precision: 18, scale: 4, nullable: false),
                    ReceivedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    BestBeforeAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockBatches", x => x.RawStockBatchId);
                    table.ForeignKey(
                        name: "FK_RawStockBatches_RawStockBalances_RawStockBalanceId",
                        column: x => x.RawStockBalanceId,
                        principalTable: "RawStockBalances",
                        principalColumn: "RawStockBalanceId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockBatches_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockBatches_RawStockReceiptLines_RawStockReceiptLineId",
                        column: x => x.RawStockReceiptLineId,
                        principalTable: "RawStockReceiptLines",
                        principalColumn: "RawStockReceiptLineId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockBatches_Suppliers_SupplierId",
                        column: x => x.SupplierId,
                        principalTable: "Suppliers",
                        principalColumn: "SupplierId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RawStockMovements",
                columns: table => new
                {
                    RawStockMovementId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false),
                    RawStockBalanceId = table.Column<int>(type: "int", nullable: false),
                    RawStockBatchId = table.Column<long>(type: "bigint", nullable: true),
                    OperationalReasonId = table.Column<int>(type: "int", nullable: true),
                    CreatedByUserId = table.Column<int>(type: "int", nullable: false),
                    MovementType = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    QuantityChange = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    UnitCost = table.Column<decimal>(type: "decimal(18,4)", precision: 18, scale: 4, nullable: false),
                    OccurredAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SourceType = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: true),
                    SourceId = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: true),
                    ReasonText = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockMovements", x => x.RawStockMovementId);
                    table.ForeignKey(
                        name: "FK_RawStockMovements_OperationalReasons_OperationalReasonId",
                        column: x => x.OperationalReasonId,
                        principalTable: "OperationalReasons",
                        principalColumn: "OperationalReasonId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockMovements_RawStockBalances_RawStockBalanceId",
                        column: x => x.RawStockBalanceId,
                        principalTable: "RawStockBalances",
                        principalColumn: "RawStockBalanceId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockMovements_RawStockBatches_RawStockBatchId",
                        column: x => x.RawStockBatchId,
                        principalTable: "RawStockBatches",
                        principalColumn: "RawStockBatchId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockMovements_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockMovements_Users_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RawStockWriteOffs",
                columns: table => new
                {
                    RawStockWriteOffId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RawStockItemId = table.Column<int>(type: "int", nullable: false),
                    RawStockBalanceId = table.Column<int>(type: "int", nullable: false),
                    RawStockBatchId = table.Column<long>(type: "bigint", nullable: true),
                    OperationalReasonId = table.Column<int>(type: "int", nullable: false),
                    SubmittedByUserId = table.Column<int>(type: "int", nullable: false),
                    DecidedByUserId = table.Column<int>(type: "int", nullable: true),
                    Quantity = table.Column<decimal>(type: "decimal(18,3)", precision: 18, scale: 3, nullable: false),
                    EstimatedUnitCost = table.Column<decimal>(type: "decimal(18,4)", precision: 18, scale: 4, nullable: false),
                    EstimatedTotalLoss = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    Condition = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    DecisionReason = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    SubmittedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DecidedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CompletedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockWriteOffs", x => x.RawStockWriteOffId);
                    table.ForeignKey(
                        name: "FK_RawStockWriteOffs_OperationalReasons_OperationalReasonId",
                        column: x => x.OperationalReasonId,
                        principalTable: "OperationalReasons",
                        principalColumn: "OperationalReasonId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockWriteOffs_RawStockBalances_RawStockBalanceId",
                        column: x => x.RawStockBalanceId,
                        principalTable: "RawStockBalances",
                        principalColumn: "RawStockBalanceId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockWriteOffs_RawStockBatches_RawStockBatchId",
                        column: x => x.RawStockBatchId,
                        principalTable: "RawStockBatches",
                        principalColumn: "RawStockBatchId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockWriteOffs_RawStockItems_RawStockItemId",
                        column: x => x.RawStockItemId,
                        principalTable: "RawStockItems",
                        principalColumn: "RawStockItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockWriteOffs_Users_DecidedByUserId",
                        column: x => x.DecidedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockWriteOffs_Users_SubmittedByUserId",
                        column: x => x.SubmittedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RawStockWriteOffEvidence",
                columns: table => new
                {
                    RawStockWriteOffEvidenceId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RawStockWriteOffId = table.Column<long>(type: "bigint", nullable: false),
                    StoredFileId = table.Column<long>(type: "bigint", nullable: false),
                    UploadedByUserId = table.Column<int>(type: "int", nullable: false),
                    UploadedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Caption = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RawStockWriteOffEvidence", x => x.RawStockWriteOffEvidenceId);
                    table.ForeignKey(
                        name: "FK_RawStockWriteOffEvidence_RawStockWriteOffs_RawStockWriteOffId",
                        column: x => x.RawStockWriteOffId,
                        principalTable: "RawStockWriteOffs",
                        principalColumn: "RawStockWriteOffId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_RawStockWriteOffEvidence_StoredFiles_StoredFileId",
                        column: x => x.StoredFileId,
                        principalTable: "StoredFiles",
                        principalColumn: "StoredFileId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RawStockWriteOffEvidence_Users_UploadedByUserId",
                        column: x => x.UploadedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "SystemSettings",
                columns: new[] { "SystemSettingId", "AllowedValuesJson", "Category", "DefaultValue", "Description", "DisplayName", "IsActive", "IsSensitive", "IsSystemSetting", "Key", "MaximumValue", "MinimumValue", "RequiresRestart", "Unit", "UpdatedAtUtc", "UpdatedByUserId", "Value", "ValueType" },
                values: new object[,]
                {
                    { 45, null, "Raw stock take", "25", "Absolute raw-stock variance above which management approval is required.", "Quantity approval threshold", true, false, true, "RawStockTake.RequireApprovalAboveKg", "100000", "0", false, "kg", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "25", "Decimal" },
                    { 46, null, "Raw stock take", "5", "Percentage raw-stock variance above which management approval is required.", "Percentage approval threshold", true, false, true, "RawStockTake.RequireApprovalAbovePercentage", "100", "0", false, "percent", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "5", "Decimal" },
                    { 47, null, "Raw stock take", "1000", "Estimated financial impact above which management approval is required.", "Value approval threshold", true, false, true, "RawStockTake.RequireApprovalAboveValue", "10000000", "0", false, "currency", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "1000", "Decimal" },
                    { 48, null, "Payments", "5000", "Maximum payment value an Administrator may reverse on the capture day.", "Administrator same-day reversal limit", true, false, true, "Payments.AdminVoidSameDayMaximumValue", "10000000", "0", false, "currency", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "5000", "Decimal" },
                    { 49, null, "Payments", "24", "Hours after posting when a payment reversal requires management approval.", "Reversal approval hours", true, false, true, "Payments.RequireManagementApprovalAfterHours", "720", "0", false, "hours", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "24", "Integer" },
                    { 50, null, "Payments", "5000", "Payment value above which reversal requires management approval.", "Reversal approval value", true, false, true, "Payments.RequireManagementApprovalAboveValue", "10000000", "0", false, "currency", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "5000", "Decimal" },
                    { 51, null, "Raw stock", "100", "Raw-stock write-off quantity above which management approval is required.", "Write-off quantity approval threshold", true, false, true, "RawStock.WriteOffRequireApprovalAboveQuantity", "1000000", "0", false, "units", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "100", "Decimal" },
                    { 52, null, "Raw stock", "1000", "Raw-stock write-off value above which management approval is required.", "Write-off value approval threshold", true, false, true, "RawStock.WriteOffRequireApprovalAboveValue", "10000000", "0", false, "currency", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "1000", "Decimal" },
                    { 53, null, "Raw stock", "500", "Raw-stock loss above which photographic evidence is required.", "Write-off evidence threshold", true, false, true, "RawStock.WriteOffEvidenceAboveValue", "10000000", "0", false, "currency", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "500", "Decimal" }
                });

            migrationBuilder.Sql("""
                DECLARE @OperationalPermissions TABLE
                (
                    PermissionCode nvarchar(100) NOT NULL PRIMARY KEY,
                    DisplayName nvarchar(120) NOT NULL,
                    Module nvarchar(80) NOT NULL
                );

                INSERT INTO @OperationalPermissions VALUES
                    ('RawStock.View', 'View raw stock', 'RawStock'),
                    ('RawStock.Manage', 'Create and maintain raw-stock items', 'RawStock'),
                    ('RawStock.Receive', 'Receive raw stock into warehouse balances', 'RawStock'),
                    ('RawStock.WriteOff', 'Submit raw-stock write-offs', 'RawStock'),
                    ('RawStock.ApproveWriteOff', 'Approve raw-stock write-offs', 'RawStock'),
                    ('RawStockTakes.View', 'View raw-stock takes', 'RawStock'),
                    ('RawStockTakes.Capture', 'Capture and submit raw-stock takes', 'RawStock'),
                    ('RawStockTakes.Review', 'Review raw-stock takes', 'RawStock'),
                    ('RawStockTakes.Approve', 'Approve raw-stock-take adjustments', 'RawStock'),
                    ('OperationalReasons.View', 'View operational reasons', 'Configuration'),
                    ('OperationalReasons.Manage', 'Manage operational reasons', 'Configuration'),
                    ('SupplierOrders.View', 'View supplier orders', 'Suppliers'),
                    ('SupplierOrders.Manage', 'Create and maintain supplier orders', 'Suppliers'),
                    ('CustomerPayments.View', 'View customer payments', 'Payments'),
                    ('CustomerPayments.Capture', 'Capture customer payments', 'Payments'),
                    ('CustomerPayments.Reverse', 'Request customer-payment reversal', 'Payments'),
                    ('CustomerPayments.ApproveReversal', 'Approve customer-payment reversal', 'Payments'),
                    ('SupplierPayments.View', 'View supplier payments', 'Payments'),
                    ('SupplierPayments.Capture', 'Capture supplier payments', 'Payments'),
                    ('SupplierPayments.Reverse', 'Request supplier-payment reversal', 'Payments'),
                    ('SupplierPayments.ApproveReversal', 'Approve supplier-payment reversal', 'Payments'),
                    ('Reconciliation.View', 'View raw-stock reconciliation mappings', 'RawStock'),
                    ('Reconciliation.Manage', 'Manage raw-stock reconciliation mappings', 'RawStock'),
                    ('ManagementDashboard.View', 'View management operational dashboard', 'Dashboard');

                INSERT INTO dbo.Permissions
                    (PermissionName, PermissionCode, DisplayName, Module,
                     IsSystemPermission, IsActive, CreatedAtUtc)
                SELECT seed.PermissionCode, seed.PermissionCode,
                       seed.DisplayName, seed.Module, 1, 1, SYSUTCDATETIME()
                FROM @OperationalPermissions seed
                WHERE NOT EXISTS (
                    SELECT 1 FROM dbo.Permissions existing
                    WHERE existing.PermissionCode = seed.PermissionCode);

                UPDATE permission
                SET permission.PermissionName = seed.PermissionCode,
                    permission.DisplayName = seed.DisplayName,
                    permission.Module = seed.Module,
                    permission.IsSystemPermission = 1,
                    permission.IsActive = 1,
                    permission.UpdatedAtUtc = SYSUTCDATETIME()
                FROM dbo.Permissions permission
                JOIN @OperationalPermissions seed
                  ON seed.PermissionCode = permission.PermissionCode;

                DECLARE @OperationalRolePermissions TABLE
                (
                    RoleCode nvarchar(50) NOT NULL,
                    PermissionCode nvarchar(100) NOT NULL,
                    PRIMARY KEY (RoleCode, PermissionCode)
                );

                INSERT INTO @OperationalRolePermissions
                SELECT roleCode.RoleCode, permission.PermissionCode
                FROM (VALUES ('CEO'), ('COO'), ('BusinessManager'))
                     roleCode(RoleCode)
                CROSS JOIN @OperationalPermissions permission;

                INSERT INTO @OperationalRolePermissions VALUES
                    ('Admin', 'CustomerPayments.View'),
                    ('Admin', 'CustomerPayments.Capture'),
                    ('Admin', 'CustomerPayments.Reverse'),
                    ('Admin', 'SupplierPayments.View'),
                    ('Admin', 'SupplierPayments.Capture'),
                    ('Admin', 'SupplierPayments.Reverse'),
                    ('Admin', 'RawStock.View'),
                    ('Admin', 'RawStock.Manage'),
                    ('Admin', 'RawStock.Receive'),
                    ('Admin', 'RawStockTakes.View'),
                    ('Admin', 'RawStockTakes.Review'),
                    ('Admin', 'OperationalReasons.View'),
                    ('Admin', 'OperationalReasons.Manage'),
                    ('Admin', 'SupplierOrders.View'),
                    ('Admin', 'SupplierOrders.Manage'),
                    ('Admin', 'Reconciliation.View'),
                    ('StockTaker', 'RawStock.View'),
                    ('StockTaker', 'RawStock.Receive'),
                    ('StockTaker', 'RawStock.WriteOff'),
                    ('StockTaker', 'RawStockTakes.View'),
                    ('StockTaker', 'RawStockTakes.Capture'),
                    ('StockTaker', 'OperationalReasons.View'),
                    ('StockTaker', 'Reconciliation.View'),
                    ('MarketBuyer', 'RawStock.View');

                INSERT INTO @OperationalRolePermissions
                    (RoleCode, PermissionCode)
                SELECT 'AdminClerk', PermissionCode
                FROM @OperationalRolePermissions
                WHERE RoleCode = 'Admin';

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
                FROM @OperationalRolePermissions seed
                JOIN dbo.Roles role
                  ON role.RoleCode = seed.RoleCode
                JOIN dbo.Permissions permission
                  ON permission.PermissionCode = seed.PermissionCode
                WHERE NOT EXISTS (
                    SELECT 1 FROM dbo.RolePermissions existing
                    WHERE existing.RoleId = role.RoleId
                      AND existing.PermissionId = permission.PermissionId);

                INSERT INTO dbo.OperationalReasons
                    (ReasonCode, ReasonName, CategoryCode, Description,
                     IsActive, CreatedAtUtc)
                SELECT seed.ReasonCode, seed.ReasonName, seed.CategoryCode,
                       seed.Description, 1, SYSUTCDATETIME()
                FROM (VALUES
                    ('EXPIRED', 'Expired stock', 'WriteOff',
                     'Stock passed its approved best-before date.'),
                    ('SPOILED', 'Spoiled stock', 'WriteOff',
                     'Stock is no longer fit for processing or sale.'),
                    ('DAMAGED', 'Damaged stock', 'WriteOff',
                     'Stock was damaged during handling or storage.'),
                    ('QUALITY_REJECTED', 'Quality rejected', 'WriteOff',
                     'Inspection found that the stock failed quality requirements.'),
                    ('STOCK_COUNT', 'Stock-count adjustment', 'StockTake',
                     'Controlled adjustment arising from an approved physical stock take.'),
                    ('RECEIPT_REJECTION', 'Receipt rejection', 'Receipt',
                     'Quantity was rejected during receiving inspection.')
                ) seed(ReasonCode, ReasonName, CategoryCode, Description)
                WHERE NOT EXISTS (
                    SELECT 1 FROM dbo.OperationalReasons existing
                    WHERE existing.ReasonCode = seed.ReasonCode);
                """);

            migrationBuilder.CreateIndex(
                name: "IX_Suppliers_NormalizedEmail",
                table: "Suppliers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "IX_Suppliers_SupplierTypeCode_Status",
                table: "Suppliers",
                columns: new[] { "SupplierTypeCode", "Status" });

            migrationBuilder.CreateIndex(
                name: "UX_Suppliers_Code",
                table: "Suppliers",
                column: "SupplierCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_SupplierOrders_ApprovedByUserId",
                table: "SupplierOrders",
                column: "ApprovedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SupplierOrders_CreatedByUserId",
                table: "SupplierOrders",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SupplierOrders_Status_OrderDate",
                table: "SupplierOrders",
                columns: new[] { "Status", "OrderDate" });

            migrationBuilder.CreateIndex(
                name: "IX_SupplierOrders_WarehouseSectionId",
                table: "SupplierOrders",
                column: "WarehouseSectionId");

            migrationBuilder.CreateIndex(
                name: "UX_SupplierOrders_Number",
                table: "SupplierOrders",
                column: "OrderNumber",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UX_Customers_NormalizedEmail",
                table: "Customers",
                column: "NormalizedEmail",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurementItems_RawStockItemId",
                table: "BuyerProcurementItems",
                column: "RawStockItemId");

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_CorrelationId",
                table: "FinancialPayments",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_CounterpartyType_Status_PaymentDateUtc",
                table: "FinancialPayments",
                columns: new[] { "CounterpartyType", "Status", "PaymentDateUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_CreatedByUserId",
                table: "FinancialPayments",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_CustomerId",
                table: "FinancialPayments",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_DecidedByUserId",
                table: "FinancialPayments",
                column: "DecidedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_InvoiceId",
                table: "FinancialPayments",
                column: "InvoiceId");

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_OriginalPaymentId",
                table: "FinancialPayments",
                column: "OriginalPaymentId");

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_PostedByUserId",
                table: "FinancialPayments",
                column: "PostedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_SupplierId",
                table: "FinancialPayments",
                column: "SupplierId");

            migrationBuilder.CreateIndex(
                name: "IX_FinancialPayments_SupplierOrderId",
                table: "FinancialPayments",
                column: "SupplierOrderId");

            migrationBuilder.CreateIndex(
                name: "UX_FinancialPayments_Number",
                table: "FinancialPayments",
                column: "PaymentNumber",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_OperationalReasons_CategoryCode_IsActive_ReasonName",
                table: "OperationalReasons",
                columns: new[] { "CategoryCode", "IsActive", "ReasonName" });

            migrationBuilder.CreateIndex(
                name: "UX_OperationalReasons_Code",
                table: "OperationalReasons",
                column: "ReasonCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProductReconciliationMappings_RawStockReconciliationGroupId",
                table: "ProductReconciliationMappings",
                column: "RawStockReconciliationGroupId");

            migrationBuilder.CreateIndex(
                name: "UX_ProductReconciliationMappings_Product",
                table: "ProductReconciliationMappings",
                column: "ProductId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RawStockBalances_WarehouseSectionId",
                table: "RawStockBalances",
                column: "WarehouseSectionId");

            migrationBuilder.CreateIndex(
                name: "UX_RawStockBalances_Item_Section_Unit",
                table: "RawStockBalances",
                columns: new[] { "RawStockItemId", "WarehouseSectionId", "UnitOfMeasure" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RawStockBatches_RawStockBalanceId",
                table: "RawStockBatches",
                column: "RawStockBalanceId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockBatches_RawStockItemId_Status_BestBeforeAtUtc",
                table: "RawStockBatches",
                columns: new[] { "RawStockItemId", "Status", "BestBeforeAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_RawStockBatches_RawStockReceiptLineId",
                table: "RawStockBatches",
                column: "RawStockReceiptLineId",
                unique: true,
                filter: "[RawStockReceiptLineId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockBatches_SupplierId",
                table: "RawStockBatches",
                column: "SupplierId");

            migrationBuilder.CreateIndex(
                name: "UX_RawStockBatches_BatchCode",
                table: "RawStockBatches",
                column: "BatchCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UX_RawStockBatches_Qr",
                table: "RawStockBatches",
                column: "QrCodeValue",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RawStockItems_CategoryCode_IsActive",
                table: "RawStockItems",
                columns: new[] { "CategoryCode", "IsActive" });

            migrationBuilder.CreateIndex(
                name: "UX_RawStockItems_Code",
                table: "RawStockItems",
                column: "ItemCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UX_RawStockItems_Name",
                table: "RawStockItems",
                column: "ItemName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RawStockMovements_CorrelationId",
                table: "RawStockMovements",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockMovements_CreatedByUserId",
                table: "RawStockMovements",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockMovements_OperationalReasonId",
                table: "RawStockMovements",
                column: "OperationalReasonId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockMovements_RawStockBalanceId",
                table: "RawStockMovements",
                column: "RawStockBalanceId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockMovements_RawStockBatchId",
                table: "RawStockMovements",
                column: "RawStockBatchId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockMovements_RawStockItemId_OccurredAtUtc",
                table: "RawStockMovements",
                columns: new[] { "RawStockItemId", "OccurredAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_RawStockMovements_SourceType_SourceId",
                table: "RawStockMovements",
                columns: new[] { "SourceType", "SourceId" });

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceiptLines_RawStockItemId",
                table: "RawStockReceiptLines",
                column: "RawStockItemId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceiptLines_RawStockReceiptId_RawStockItemId",
                table: "RawStockReceiptLines",
                columns: new[] { "RawStockReceiptId", "RawStockItemId" });

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceipts_BuyerProcurementId",
                table: "RawStockReceipts",
                column: "BuyerProcurementId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceipts_CorrelationId",
                table: "RawStockReceipts",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceipts_ReceivedByUserId",
                table: "RawStockReceipts",
                column: "ReceivedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceipts_Status_ReceivedAtUtc",
                table: "RawStockReceipts",
                columns: new[] { "Status", "ReceivedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceipts_SupplierId",
                table: "RawStockReceipts",
                column: "SupplierId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceipts_SupplierOrderId",
                table: "RawStockReceipts",
                column: "SupplierOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceipts_WarehouseSectionId",
                table: "RawStockReceipts",
                column: "WarehouseSectionId");

            migrationBuilder.CreateIndex(
                name: "UX_RawStockReceipts_Number",
                table: "RawStockReceipts",
                column: "ReceiptNumber",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UX_RawStockReceipts_Operation",
                table: "RawStockReceipts",
                column: "OperationKeyHash",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReconciliationGroupItems_RawStockReconciliationGroupId",
                table: "RawStockReconciliationGroupItems",
                column: "RawStockReconciliationGroupId");

            migrationBuilder.CreateIndex(
                name: "UX_ReconciliationGroupItems_RawStock",
                table: "RawStockReconciliationGroupItems",
                column: "RawStockItemId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UX_RawStockReconciliationGroups_Code",
                table: "RawStockReconciliationGroups",
                column: "GroupCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RawStockTakeLines_RawStockBalanceId",
                table: "RawStockTakeLines",
                column: "RawStockBalanceId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockTakeLines_RawStockItemId",
                table: "RawStockTakeLines",
                column: "RawStockItemId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockTakeLines_RawStockReconciliationGroupId",
                table: "RawStockTakeLines",
                column: "RawStockReconciliationGroupId");

            migrationBuilder.CreateIndex(
                name: "UX_RawStockTakeLines_Session_Balance",
                table: "RawStockTakeLines",
                columns: new[] { "RawStockTakeSessionId", "RawStockBalanceId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RawStockTakeSessions_CreatedByUserId",
                table: "RawStockTakeSessions",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockTakeSessions_DecidedByUserId",
                table: "RawStockTakeSessions",
                column: "DecidedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockTakeSessions_ReviewedByUserId",
                table: "RawStockTakeSessions",
                column: "ReviewedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockTakeSessions_WarehouseSectionId_Status_CreatedAtUtc",
                table: "RawStockTakeSessions",
                columns: new[] { "WarehouseSectionId", "Status", "CreatedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "UX_RawStockTakeSessions_Correlation",
                table: "RawStockTakeSessions",
                column: "CorrelationId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffEvidence_RawStockWriteOffId",
                table: "RawStockWriteOffEvidence",
                column: "RawStockWriteOffId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffEvidence_StoredFileId",
                table: "RawStockWriteOffEvidence",
                column: "StoredFileId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffEvidence_UploadedByUserId",
                table: "RawStockWriteOffEvidence",
                column: "UploadedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffs_CorrelationId",
                table: "RawStockWriteOffs",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffs_DecidedByUserId",
                table: "RawStockWriteOffs",
                column: "DecidedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffs_OperationalReasonId",
                table: "RawStockWriteOffs",
                column: "OperationalReasonId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffs_RawStockBalanceId",
                table: "RawStockWriteOffs",
                column: "RawStockBalanceId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffs_RawStockBatchId",
                table: "RawStockWriteOffs",
                column: "RawStockBatchId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffs_RawStockItemId",
                table: "RawStockWriteOffs",
                column: "RawStockItemId");

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffs_Status_SubmittedAtUtc",
                table: "RawStockWriteOffs",
                columns: new[] { "Status", "SubmittedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_RawStockWriteOffs_SubmittedByUserId",
                table: "RawStockWriteOffs",
                column: "SubmittedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_SupplierOrderLines_RawStockItemId",
                table: "SupplierOrderLines",
                column: "RawStockItemId");

            migrationBuilder.CreateIndex(
                name: "UX_SupplierOrderLines_Order_Item",
                table: "SupplierOrderLines",
                columns: new[] { "SupplierOrderId", "RawStockItemId" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_BuyerProcurementItems_RawStockItems_RawStockItemId",
                table: "BuyerProcurementItems",
                column: "RawStockItemId",
                principalTable: "RawStockItems",
                principalColumn: "RawStockItemId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SupplierOrders_Users_ApprovedByUserId",
                table: "SupplierOrders",
                column: "ApprovedByUserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SupplierOrders_Users_CreatedByUserId",
                table: "SupplierOrders",
                column: "CreatedByUserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SupplierOrders_WarehouseSections_WarehouseSectionId",
                table: "SupplierOrders",
                column: "WarehouseSectionId",
                principalTable: "WarehouseSections",
                principalColumn: "SectionId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BuyerProcurementItems_RawStockItems_RawStockItemId",
                table: "BuyerProcurementItems");

            migrationBuilder.DropForeignKey(
                name: "FK_SupplierOrders_Users_ApprovedByUserId",
                table: "SupplierOrders");

            migrationBuilder.DropForeignKey(
                name: "FK_SupplierOrders_Users_CreatedByUserId",
                table: "SupplierOrders");

            migrationBuilder.DropForeignKey(
                name: "FK_SupplierOrders_WarehouseSections_WarehouseSectionId",
                table: "SupplierOrders");

            migrationBuilder.DropTable(
                name: "FinancialPayments");

            migrationBuilder.DropTable(
                name: "ProductReconciliationMappings");

            migrationBuilder.DropTable(
                name: "RawStockMovements");

            migrationBuilder.DropTable(
                name: "RawStockReconciliationGroupItems");

            migrationBuilder.DropTable(
                name: "RawStockTakeLines");

            migrationBuilder.DropTable(
                name: "RawStockWriteOffEvidence");

            migrationBuilder.DropTable(
                name: "SupplierOrderLines");

            migrationBuilder.DropTable(
                name: "RawStockReconciliationGroups");

            migrationBuilder.DropTable(
                name: "RawStockTakeSessions");

            migrationBuilder.DropTable(
                name: "RawStockWriteOffs");

            migrationBuilder.DropTable(
                name: "OperationalReasons");

            migrationBuilder.DropTable(
                name: "RawStockBatches");

            migrationBuilder.DropTable(
                name: "RawStockBalances");

            migrationBuilder.DropTable(
                name: "RawStockReceiptLines");

            migrationBuilder.DropTable(
                name: "RawStockItems");

            migrationBuilder.DropTable(
                name: "RawStockReceipts");

            migrationBuilder.DropIndex(
                name: "IX_Suppliers_NormalizedEmail",
                table: "Suppliers");

            migrationBuilder.DropIndex(
                name: "IX_Suppliers_SupplierTypeCode_Status",
                table: "Suppliers");

            migrationBuilder.DropIndex(
                name: "UX_Suppliers_Code",
                table: "Suppliers");

            migrationBuilder.DropIndex(
                name: "IX_SupplierOrders_ApprovedByUserId",
                table: "SupplierOrders");

            migrationBuilder.DropIndex(
                name: "IX_SupplierOrders_CreatedByUserId",
                table: "SupplierOrders");

            migrationBuilder.DropIndex(
                name: "IX_SupplierOrders_Status_OrderDate",
                table: "SupplierOrders");

            migrationBuilder.DropIndex(
                name: "IX_SupplierOrders_WarehouseSectionId",
                table: "SupplierOrders");

            migrationBuilder.DropIndex(
                name: "UX_SupplierOrders_Number",
                table: "SupplierOrders");

            migrationBuilder.DropIndex(
                name: "UX_Customers_NormalizedEmail",
                table: "Customers");

            migrationBuilder.DropIndex(
                name: "IX_BuyerProcurementItems_RawStockItemId",
                table: "BuyerProcurementItems");

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 45);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 46);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 47);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 48);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 49);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 50);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 51);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 52);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 53);

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                table: "Suppliers");

            migrationBuilder.DropColumn(
                name: "NormalizedEmail",
                table: "Suppliers");

            migrationBuilder.DropColumn(
                name: "RowVersion",
                table: "Suppliers");

            migrationBuilder.DropColumn(
                name: "SupplierCode",
                table: "Suppliers");

            migrationBuilder.DropColumn(
                name: "SupplierTypeCode",
                table: "Suppliers");

            migrationBuilder.DropColumn(
                name: "UpdatedAtUtc",
                table: "Suppliers");

            migrationBuilder.DropColumn(
                name: "ApprovedAtUtc",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "ApprovedByUserId",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "CancelledAtUtc",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "CreatedByUserId",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "ExpectedDeliveryAtUtc",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "Notes",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "OrderNumber",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "RowVersion",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "WarehouseSectionId",
                table: "SupplierOrders");

            migrationBuilder.DropColumn(
                name: "ContactPerson",
                table: "Customers");

            migrationBuilder.DropColumn(
                name: "NormalizedEmail",
                table: "Customers");

            migrationBuilder.DropColumn(
                name: "RowVersion",
                table: "Customers");

            migrationBuilder.DropColumn(
                name: "RawStockItemId",
                table: "BuyerProcurementItems");

            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Suppliers",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AlterColumn<string>(
                name: "Phone",
                table: "Suppliers",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(30)",
                oldMaxLength: 30,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                table: "Suppliers",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(254)",
                oldMaxLength: 254,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ContactPerson",
                table: "Suppliers",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Address",
                table: "Suppliers",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(500)",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ProductId",
                table: "BuyerProcurementItems",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }
    }
}
