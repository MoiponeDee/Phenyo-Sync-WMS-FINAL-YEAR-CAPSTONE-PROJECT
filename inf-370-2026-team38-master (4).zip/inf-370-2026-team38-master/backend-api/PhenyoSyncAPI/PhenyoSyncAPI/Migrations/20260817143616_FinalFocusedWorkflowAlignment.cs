﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class FinalFocusedWorkflowAlignment : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "SupplierId",
                table: "RawStockReceipts",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.Sql("""
                DELETE mapping
                FROM dbo.RolePermissions mapping
                JOIN dbo.Roles role ON role.RoleId = mapping.RoleId
                JOIN dbo.Permissions permission
                  ON permission.PermissionId = mapping.PermissionId
                WHERE
                    (role.RoleCode = 'Admin' AND permission.PermissionCode IN
                        ('RawStock.View', 'Products.Make',
                         'WarehouseSections.Manage'))
                    OR
                    (role.RoleCode = 'OperationsManager' AND
                     permission.PermissionCode IN
                        ('RawStock.View', 'Products.Make',
                         'ProductTypes.Manage',
                         'ProductCategories.Manage',
                         'WarehouseSections.Manage',
                         'Orders.Validate', 'Orders.Confirm',
                         'Users.View', 'Roles.View',
                         'PermissionDefinitions.View'))
                    OR
                    (role.RoleCode = 'WarehouseManager' AND
                     permission.PermissionCode IN
                        ('Users.View', 'Roles.View',
                         'PermissionDefinitions.View',
                         'ProductTypes.Manage',
                         'ProductCategories.Manage',
                         'Orders.Validate', 'Orders.Confirm'));

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
                FROM dbo.Roles role
                JOIN dbo.Permissions permission
                  ON
                    (role.RoleCode = 'Admin' AND
                     permission.PermissionCode IN
                        ('Orders.Validate', 'Orders.Confirm'))
                    OR
                    (role.RoleCode = 'WarehouseManager' AND
                     permission.PermissionCode IN
                        ('Products.Make', 'BuyingLists.View',
                         'BuyingLists.ViewAll', 'Orders.ChangeStatus'))
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.RolePermissions existing
                    WHERE existing.RoleId = role.RoleId
                      AND existing.PermissionId = permission.PermissionId
                );
                """);

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 8,
                columns: new[] { "AudienceRolesCsv", "BodyContent", "Keywords" },
                values: new object[] { "WarehouseManager", "# Make products\nSelect a warehouse section, then select an existing active Product whose Raw Stock requirements are configured and currently available. The readiness card shows adjusted input quantities and maximum packable output.\n\nEnter only the warehouse section, Product and quantity to make. PhenyoSync automatically consumes eligible Raw Stock in earliest-expiry-first order, records the conversion and increases finished Product stock. The transaction rolls back when any input is insufficient or changes concurrently. Product master creation and order barcode packing remain separate workflows.", "make product raw stock conversion recipe availability" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 18,
                column: "BodyContent",
                value: "# Customer order form\nOpen the configured Google Form from Order Management and share it with the customer. When responses are ready, an authorised user selects Synchronise responses. PhenyoSync reads the configured Google Sheet through the backend and never exposes the provider key to the browser.\n\nThe live form uses customer identity, account reference, phone, fulfilment choice, address, requested date, purchase-order reference, six Product/quantity pairs, additional items and customer notes. Products match an exact Product code first and then one unambiguous description. Customers match email first, account reference second and a unique phone number only as a safe fallback. Collection requests do not require a delivery address. Additional free-text products and any ambiguity remain in Needs Attention instead of silently creating records or changing master data.\n\nSynchronisation is a Super Admin commercial-intake task. Each response has a stable external key, so repeated syncs cannot create duplicate orders. Authoritative prices come from PhenyoSync and accepted requests enter Submitted for commercial approval.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 19,
                column: "BodyContent",
                value: "# Create and validate orders\nSelect a customer and add products with positive quantities. Prices are read from the current server-side price record and snapshotted onto order lines.\n\nA Super Admin reviews the request and selects Validate and Approve Order or Reject Order with a reason. Approval activates demand without rejecting a valid request merely because stock is short. After approved demand is fulfilled, a Packer scans finished Product Batches and completes packing. The Warehouse Manager then reviews the completed packing and confirms Ready for Dispatch.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 20,
                column: "BodyContent",
                value: "# Order status and cancellation\nOrders move from Submitted to commercially Approved, Packing, Packing Complete, Ready for Dispatch, Out for Delivery and Delivered. Commercial approval belongs to Super Admin. Packing belongs to the Packer, and the Warehouse Manager confirms dispatch readiness only after packing is complete.\n\nCancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 36,
                columns: new[] { "BodyContent", "Keywords", "Summary", "Title" },
                values: new object[] { "# Product and price Excel exchange\nUse the filters to create a presentation-ready Excel workbook showing Product master data and the price effective at the selected business date. Excel includes instructions, metadata, filters and typed columns.\n\nImport is a controlled Excel workflow: upload the current template, review valid, warning and invalid rows, enter a business reason, confirm, and apply the exact staged content. Existing prices are versioned instead of overwritten. JSON is reserved for Stock Taker inventory snapshots and never contains prices or costs.", "excel product price catalogue template validate import export stock count json", "Export professional pricing workbooks and apply only validated Excel imports.", "Product and price Excel exchange" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 37,
                column: "BodyContent",
                value: "# Procurement shortages\nShortage planning starts with commercially approved and active fulfilment demand. Submitted customer or Google Form requests are excluded until Super Admin approval. Active finished-stock reservations are subtracted before the Product shortage is calculated.\n\nThe Warehouse Manager maintains Product-to-Raw-Stock mappings using friendly dropdowns, quantity, unit, waste and yield. Unmapped approved demand is shown separately and cannot generate misleading purchase quantities. Mapped shortages include available Raw Stock, outstanding supplier orders and open Buying List quantities.\n\nReceive Raw Stock only from a controlled Supplier Order line or a submitted Buying List line. Supplier and unit are derived from the selected source. A Buying List may use Market Purchase / Not applicable when no supplier applies. Record the received quantity, actual cost, docket and any variance notes; the source document remains the traceability record.");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "SupplierId",
                table: "RawStockReceipts",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.Sql("""
                DELETE mapping
                FROM dbo.RolePermissions mapping
                JOIN dbo.Roles role ON role.RoleId = mapping.RoleId
                JOIN dbo.Permissions permission
                  ON permission.PermissionId = mapping.PermissionId
                WHERE
                    (role.RoleCode = 'Admin' AND
                     permission.PermissionCode IN
                        ('Orders.Validate', 'Orders.Confirm'))
                    OR
                    (role.RoleCode = 'WarehouseManager' AND
                     permission.PermissionCode IN
                        ('Products.Make', 'BuyingLists.View',
                         'BuyingLists.ViewAll', 'Orders.ChangeStatus'));

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
                FROM dbo.Roles role
                JOIN dbo.Permissions permission
                  ON
                    (role.RoleCode = 'Admin' AND
                     permission.PermissionCode IN
                        ('RawStock.View', 'Products.Make',
                         'WarehouseSections.Manage'))
                    OR
                    (role.RoleCode = 'OperationsManager' AND
                     permission.PermissionCode IN
                        ('RawStock.View', 'Products.Make',
                         'ProductTypes.Manage',
                         'ProductCategories.Manage',
                         'WarehouseSections.Manage',
                         'Orders.Validate', 'Orders.Confirm',
                         'Users.View', 'Roles.View',
                         'PermissionDefinitions.View'))
                    OR
                    (role.RoleCode = 'WarehouseManager' AND
                     permission.PermissionCode IN
                        ('Users.View', 'Roles.View',
                         'PermissionDefinitions.View',
                         'ProductTypes.Manage',
                         'ProductCategories.Manage',
                         'Orders.Validate', 'Orders.Confirm'))
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.RolePermissions existing
                    WHERE existing.RoleId = role.RoleId
                      AND existing.PermissionId = permission.PermissionId
                );
                """);

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 8,
                columns: new[] { "AudienceRolesCsv", "BodyContent", "Keywords" },
                values: new object[] { "WarehouseManager,Admin,Packer", "# Make products\nSelect a warehouse section, then select an existing active Product whose Raw Stock requirements are configured and currently available. The readiness card shows adjusted input quantities and maximum packable output.\n\nConfirming production consumes eligible Raw Stock batches in expiry and FIFO order, writes negative Raw Stock movements, creates one finished Product batch and stock increase, and links the records through one conversion and correlation ID. The transaction rolls back when any input is insufficient or changes concurrently. Product master creation and order barcode packing remain separate workflows.", "make product raw stock conversion recipe trace batch" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 18,
                column: "BodyContent",
                value: "# Customer order form\nOpen the configured Google Form from Order Management and share it with the customer. When responses are ready, an authorised user selects Synchronise responses. PhenyoSync reads the configured Google Sheet through the backend and never exposes the provider key to the browser.\n\nEach response has a stable external key, so repeated syncs cannot create duplicate orders. Valid responses use the existing Product codes and active Customer, apply authoritative server-side prices, and enter the system as Submitted with Pending Validation. Unknown customers, Products, malformed quantities and incomplete addresses remain in Needs Attention instead of silently creating records.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 19,
                column: "BodyContent",
                value: "# Create and validate orders\nSelect a customer and add products with positive quantities. Prices are read from the current server-side price record and snapshotted onto order lines.\n\nValidation checks details and uses FEFO to reserve eligible batches atomically. An order cannot be confirmed when stock is insufficient.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 20,
                column: "BodyContent",
                value: "# Order status and cancellation\nOrders move through the controlled sequence from Submitted to validated, confirmed, packed, out for delivery and delivered.\n\nCancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 36,
                columns: new[] { "BodyContent", "Keywords", "Summary", "Title" },
                values: new object[] { "# Product and price data exchange\nUse the same filters for the presentation-ready Excel workbook and stable, indented JSON catalogue. Both formats show the Product master and price effective at the selected business date. Excel includes instructions, metadata, filters and typed columns; JSON includes a schema version and deterministic Product ordering.\n\nImport remains an Excel-only controlled workflow: upload the current template, review valid, warning and invalid rows, enter a business reason, confirm, and apply the exact staged content. Existing prices are versioned instead of overwritten. JSON catalogue export never imports or mutates records.", "excel json product price catalogue template validate import export", "Export professional Excel or readable JSON and apply only validated Excel imports.", "Product and price data exchange" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 37,
                column: "BodyContent",
                value: "# Procurement shortages\nShortage planning starts with approved, confirmed and active fulfilment demand. Submitted customer or Google Form requests are excluded until validation succeeds. Active finished-stock reservations are subtracted before the Product shortage is calculated.\n\nProduct shortages are translated through active Product-to-Raw-Stock requirements, including configured yield and waste. Available Raw Stock, outstanding supplier orders and open buying-list quantities are then subtracted. Negative values are clamped per line before aggregation so one over-supplied line cannot hide another shortage.");
        }
    }
}
