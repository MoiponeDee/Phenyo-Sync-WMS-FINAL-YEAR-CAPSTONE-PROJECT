﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedWorkflowHelp : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "HelpContextMappings",
                columns: new[] { "HelpContextMappingId", "ComponentKey", "HelpTopicId", "IsActive", "Priority", "RoutePattern" },
                values: new object[] { 50, "AddProduct", 38, true, 110, "/add-product" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 16,
                columns: new[] { "BodyContent", "Keywords" },
                values: new object[] { "# System settings\nUse this screen to change validated operating rules without restarting PhenyoSync. You need System Settings access and a clear business reason before starting.\n\n1. Find the setting by its business category and label.\n2. Enter a value within the displayed range.\n3. Record why the change is required and save.\n4. Confirm the new value and history entry.\n\nVAT rate (%) applies to newly created orders and to editable orders when they are recalculated. Existing issued invoices and completed orders retain their saved totals. Values are type-checked and range-checked; successful changes apply immediately and retain the old value, new value, actor, time and reason. If a value is rejected, use the displayed range rather than retrying an unsupported format.", "settings vat tax timers threshold history configuration" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 19,
                columns: new[] { "BodyContent", "Keywords" },
                values: new object[] { "# Create and validate orders\nUse this workflow to capture sellable quantities for a customer and make a commercial decision. Confirm that the customer, delivery details and requested products are correct before starting.\n\n1. Select the active customer and enter the delivery and billing addresses.\n2. Add each product once and enter a positive quantity in its displayed selling unit.\n3. Review the unit price, kilogram conversion and estimated subtotal, then save.\n4. A Super Admin selects Accept Order or Deny Order. A denial reason is optional.\n5. Accepted demand proceeds to packing and shortage planning; finished-stock shortage does not make a valid commercial order invalid.\n\nPackaged products require whole units. Variable-weight products use kilograms. Prices, units, kilograms-per-unit, VAT and totals are recalculated and snapshotted by the server. If ordering is blocked, check that the product is active and has a current price and valid pack weight.", "create order accept deny units kilograms vat stock reserve fefo price" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 38,
                column: "BodyContent",
                value: "# Product creation and production\nUse Add Product to create a catalogue definition; use Make Product only when producing physical stock. Before starting, confirm that the category and product type are linked and that an approved price per kilogram is available.\n\n1. Open Add Product from Warehouse Operations.\n2. Choose the category and type, then enter the product name, display size and shelf life.\n3. Choose variable-weight kg or a packaged selling unit such as bag, box or pack.\n4. For packaged products, enter the positive kilograms contained in one unit.\n5. Enter the initial price per kilogram, a price reason and status, then save.\n\nPhenyoSync derives the packaged unit price from price per kilogram × kilograms per unit and prevents duplicate Product names within the same hierarchy. Do not estimate a pack weight from the display-size text.\n\nSelect Configure Raw Stock Recipe after creation. A recipe describes the Raw Stock needed for one sellable Product unit. For example, one Granny Smith Apples 3 KG Product unit consumes 3 kg of Loose Granny Smith Apples. Make Product multiplies that recipe by the number of units and records Raw Stock movements and a traceable Product Batch.\n\nPermanently delete only unused master data. If a Product, Customer, Supplier, Raw Stock item, Category or Type has operational history, PhenyoSync blocks deletion and offers deactivation so history remains intact.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 39,
                column: "BodyContent",
                value: "# Mobile scanning and delivery tracking\nPackers can scan a Product Batch QR with the Android camera or a laptop webcam. If live scanning is unavailable, enter the printed code manually. The server always verifies the Product, batch, order, expiry, available quantity and duplicate-scan rules before progress changes.\n\nDrivers start a dispatched delivery before sharing location. While the delivery page remains open, PhenyoSync sends a first browser or device location immediately and retries foreground updates at a controlled interval. Track Driver refreshes automatically and shows the latest timestamp, accuracy, live, stale or waiting state and route trail. If map tiles fail, use the displayed coordinates. Permission denial or unavailable GPS must be resolved on the driver device; foreground sharing stops when the page or session ends.\n\nTake or select a delivery proof photo, wait for the successful upload message, name the recipient and confirm the handover before completing the delivery. Google Maps remains available for turn-by-turn navigation.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 40,
                column: "BodyContent",
                value: "# Controlled offline data exchange\nUse Product and Price Excel for catalogue work and Stocktake JSON for offline counts. Download a fresh file before starting and keep its sheet names, headers, metadata and identifiers unchanged.\n\n1. Export the current data.\n2. Edit only the documented business cells; example rows are not importable data.\n3. Upload and validate the file. Validation does not change stock or prices.\n4. Resolve every row-level error, validate again and review the preview.\n5. Enter the required business reason and confirm once. Replaying the same validation cannot duplicate the change.\n\nJSON must remain valid machine-readable JSON without comments or renamed keys. If the import is rejected, download a new template and copy only the intended editable values.");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 50);

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 16,
                columns: new[] { "BodyContent", "Keywords" },
                values: new object[] { "# System settings\nAuthorized management can edit expiry thresholds, scanning intervals, order-link lifetime, delivery duration, OTP limits and file limits.\n\nValues are type-checked and range-checked. Changes apply immediately through cache invalidation and retain a history with actor, time and reason.", "settings timers threshold history configuration" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 19,
                columns: new[] { "BodyContent", "Keywords" },
                values: new object[] { "# Create and validate orders\nSelect a customer and add products with positive quantities. Prices are read from the current server-side price record and snapshotted onto order lines.\n\nA Super Admin reviews the request and selects Validate and Approve Order or Reject Order with a reason. Approval activates demand without rejecting a valid request merely because stock is short. After approved demand is fulfilled, a Packer scans finished Product Batches and completes packing. The Warehouse Manager then reviews the completed packing and confirms Ready for Dispatch.", "create order validate stock reserve fefo price" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 38,
                column: "BodyContent",
                value: "# Product creation and production\nOpen Product Hierarchy and select Add Product. Choose a compatible Category and Product Type, enter the pack Size, shelf life, initial selling price and status, then save. PhenyoSync prevents duplicate Product names within the same hierarchy and creates the first versioned price.\n\nSelect Configure Raw Stock Recipe after creation. A recipe describes the Raw Stock needed for one sellable Product unit. For example, one Granny Smith Apples 3 KG Product unit consumes 3 kg of Loose Granny Smith Apples. Make Product multiplies that recipe by the number of units and records Raw Stock movements and a traceable Product Batch.\n\nPermanently delete only unused master data. If a Product, Customer, Supplier, Raw Stock item, Category or Type has operational history, PhenyoSync blocks deletion and offers deactivation so history remains intact.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 39,
                column: "BodyContent",
                value: "# Mobile scanning and delivery tracking\nPackers can scan a Product Batch QR with the Android camera or a laptop webcam. If live scanning is unavailable, enter the printed code manually. The server always verifies the Product, batch, order, expiry, available quantity and duplicate-scan rules before progress changes.\n\nDrivers start a dispatched delivery before sharing location. While the delivery page remains open, PhenyoSync sends a first browser or device location immediately and retries foreground updates at a controlled interval. The driver and authorised management maps show the latest timestamp, accuracy, stale state and route trail. For a presentation, browser developer tools may simulate movement; this is test evidence, not physical GPS evidence.\n\nTake or select a delivery proof photo, wait for the successful upload message, name the recipient and confirm the handover before completing the delivery. Google Maps remains available for turn-by-turn navigation.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 40,
                column: "BodyContent",
                value: "# Controlled offline data exchange\nProduct and Price offline work uses Excel. Download the current workbook, preserve its template version, validate it, review the staged rows and confirm the exact validated import.\n\nStocktake offline work uses the dedicated JSON package. It contains operational count fields and excludes prices, costs and normal user-facing internal identifiers. Always review the variance preview and business reason before applying a stock count.");
        }
    }
}
