﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class RestoreAdminClerkRoleFamily : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                DECLARE @SuperAdminRoleId int =
                (
                    SELECT TOP (1) RoleId
                    FROM dbo.Roles
                    WHERE RoleCode = N'Admin'
                );

                IF @SuperAdminRoleId IS NULL
                BEGIN
                    THROW 51000, 'The canonical Admin role is required before restoring the administrator role family.', 1;
                END;

                DECLARE @AdminClerkRoleId int =
                (
                    SELECT TOP (1) RoleId
                    FROM dbo.Roles
                    WHERE RoleCode = N'AdminClerk'
                );

                IF @AdminClerkRoleId IS NULL
                BEGIN
                    INSERT INTO dbo.Roles
                    (
                        RoleCode,
                        RoleName,
                        Description,
                        IsSystemRole,
                        IsActive,
                        CreatedAtUtc,
                        UpdatedAtUtc
                    )
                    VALUES
                    (
                        N'AdminClerk',
                        N'Admin',
                        N'Administers users and system configuration without Super Admin escalation rights.',
                        1,
                        1,
                        SYSUTCDATETIME(),
                        NULL
                    );

                    SET @AdminClerkRoleId = CONVERT(int, SCOPE_IDENTITY());
                END
                ELSE
                BEGIN
                    UPDATE dbo.Roles
                    SET
                        RoleName = N'Admin',
                        Description = N'Administers users and system configuration without Super Admin escalation rights.',
                        IsSystemRole = 1,
                        IsActive = 1,
                        UpdatedAtUtc = SYSUTCDATETIME()
                    WHERE RoleId = @AdminClerkRoleId;
                END;

                INSERT INTO dbo.RolePermissions
                (
                    RoleId,
                    PermissionId,
                    AssignedAtUtc,
                    AssignedByUserId
                )
                SELECT
                    @AdminClerkRoleId,
                    superAdminPermission.PermissionId,
                    SYSUTCDATETIME(),
                    NULL
                FROM dbo.RolePermissions AS superAdminPermission
                WHERE superAdminPermission.RoleId = @SuperAdminRoleId
                  AND NOT EXISTS
                  (
                      SELECT 1
                      FROM dbo.RolePermissions AS existingPermission
                      WHERE existingPermission.RoleId = @AdminClerkRoleId
                        AND existingPermission.PermissionId = superAdminPermission.PermissionId
                  );
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                DECLARE @SuperAdminRoleId int =
                (
                    SELECT TOP (1) RoleId
                    FROM dbo.Roles
                    WHERE RoleCode = N'Admin'
                );
                DECLARE @AdminClerkRoleId int =
                (
                    SELECT TOP (1) RoleId
                    FROM dbo.Roles
                    WHERE RoleCode = N'AdminClerk'
                );

                IF @AdminClerkRoleId IS NOT NULL
                BEGIN
                    IF @SuperAdminRoleId IS NOT NULL
                    BEGIN
                        UPDATE dbo.Users
                        SET
                            RoleId = @SuperAdminRoleId,
                            SecurityVersion = SecurityVersion + 1,
                            UpdatedAtUtc = SYSUTCDATETIME()
                        WHERE RoleId = @AdminClerkRoleId;
                    END;

                    DELETE FROM dbo.RolePermissions
                    WHERE RoleId = @AdminClerkRoleId;

                    DELETE FROM dbo.Roles
                    WHERE RoleId = @AdminClerkRoleId;
                END;
                """);
        }
    }
}
