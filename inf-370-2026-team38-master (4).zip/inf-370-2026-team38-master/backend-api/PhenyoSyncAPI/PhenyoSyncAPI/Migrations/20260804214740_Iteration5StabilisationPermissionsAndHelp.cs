﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class Iteration5StabilisationPermissionsAndHelp : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                DELETE rolePermission
                FROM dbo.RolePermissions AS rolePermission
                INNER JOIN dbo.Roles AS role
                    ON role.RoleId = rolePermission.RoleId
                INNER JOIN dbo.Permissions AS permission
                    ON permission.PermissionId = rolePermission.PermissionId
                WHERE role.RoleCode = N'WarehouseManager'
                  AND permission.PermissionCode = N'RawStock.ApproveWriteOff';

                INSERT INTO dbo.RolePermissions
                (
                    RoleId,
                    PermissionId,
                    AssignedAtUtc,
                    AssignedByUserId
                )
                SELECT
                    role.RoleId,
                    permission.PermissionId,
                    SYSUTCDATETIME(),
                    NULL
                FROM dbo.Roles AS role
                CROSS JOIN dbo.Permissions AS permission
                WHERE role.RoleCode = N'OperationsManager'
                  AND permission.PermissionCode = N'RawStock.ApproveWriteOff'
                  AND NOT EXISTS
                  (
                      SELECT 1
                      FROM dbo.RolePermissions AS existing
                      WHERE existing.RoleId = role.RoleId
                        AND existing.PermissionId = permission.PermissionId
                  );
                """);

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 1,
                column: "BodyContent",
                value: "# Getting started\nSign in with the email address assigned to your user account. PhenyoSync opens the dashboard and actions permitted by your role and permissions.\n\nUse the persistent Help action for guidance on the page you are viewing. Navigation cards and side menus only show authorized workflows. Always sign out when leaving a shared device.\n\nManagement users administer users and configuration. Admin handles operational administration. Packers prepare products and orders, Warehouse Managers control stock and expiry, and Drivers access only their assigned deliveries.");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                DELETE rolePermission
                FROM dbo.RolePermissions AS rolePermission
                INNER JOIN dbo.Roles AS role
                    ON role.RoleId = rolePermission.RoleId
                INNER JOIN dbo.Permissions AS permission
                    ON permission.PermissionId = rolePermission.PermissionId
                WHERE role.RoleCode = N'OperationsManager'
                  AND permission.PermissionCode = N'RawStock.ApproveWriteOff';

                INSERT INTO dbo.RolePermissions
                (
                    RoleId,
                    PermissionId,
                    AssignedAtUtc,
                    AssignedByUserId
                )
                SELECT
                    role.RoleId,
                    permission.PermissionId,
                    SYSUTCDATETIME(),
                    NULL
                FROM dbo.Roles AS role
                CROSS JOIN dbo.Permissions AS permission
                WHERE role.RoleCode = N'WarehouseManager'
                  AND permission.PermissionCode = N'RawStock.ApproveWriteOff'
                  AND NOT EXISTS
                  (
                      SELECT 1
                      FROM dbo.RolePermissions AS existing
                      WHERE existing.RoleId = role.RoleId
                        AND existing.PermissionId = permission.PermissionId
                  );
                """);

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 1,
                column: "BodyContent",
                value: "# Getting started\nSign in with the email address assigned to your user account. PhenyoSync opens the dashboard and actions permitted by your role and permissions.\n\nUse the persistent Help action for guidance on the page you are viewing. Navigation cards and side menus only show authorized workflows. Always sign out when leaving a shared device.\n\nManagement users administer users and configuration. Admin handles operational administration. Packers prepare products and orders, Stock Takers control stock and expiry, and Drivers access only their assigned deliveries.");
        }
    }
}
