﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class FinalWorkflowStabilisation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                UPDATE dbo.SalesOrders
                SET Status = N'Submitted'
                WHERE Status = N'PendingValidation';

                UPDATE dbo.OrderStatusHistory
                SET PreviousStatus = N'Submitted'
                WHERE PreviousStatus = N'PendingValidation';

                UPDATE dbo.OrderStatusHistory
                SET NewStatus = N'Submitted'
                WHERE NewStatus = N'PendingValidation';

                DECLARE @PricingPermissions TABLE
                (
                    PermissionCode nvarchar(100) NOT NULL,
                    DisplayName nvarchar(120) NOT NULL
                );

                INSERT INTO @PricingPermissions (PermissionCode, DisplayName)
                VALUES
                    (N'Pricing.Create', N'Create price versions'),
                    (N'Pricing.Cancel', N'Cancel eligible price versions'),
                    (N'Pricing.ViewHistory', N'View price history');

                INSERT INTO dbo.Permissions
                (
                    PermissionName,
                    PermissionCode,
                    DisplayName,
                    Module,
                    IsSystemPermission,
                    IsActive,
                    CreatedAtUtc
                )
                SELECT
                    seed.PermissionCode,
                    seed.PermissionCode,
                    seed.DisplayName,
                    N'Pricing',
                    1,
                    1,
                    SYSUTCDATETIME()
                FROM @PricingPermissions AS seed
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.Permissions AS existing
                    WHERE existing.PermissionCode = seed.PermissionCode
                );

                UPDATE permission
                SET PermissionName = seed.PermissionCode,
                    DisplayName = seed.DisplayName,
                    Module = N'Pricing',
                    IsSystemPermission = 1,
                    IsActive = 1,
                    UpdatedAtUtc = SYSUTCDATETIME()
                FROM dbo.Permissions AS permission
                INNER JOIN @PricingPermissions AS seed
                    ON seed.PermissionCode = permission.PermissionCode;

                UPDATE dbo.Permissions
                SET DisplayName = N'Share customer order form',
                    UpdatedAtUtc = SYSUTCDATETIME()
                WHERE PermissionCode = N'Orders.SendLink';

                DECLARE @RolePermissionAssignments TABLE
                (
                    RoleCode nvarchar(50) NOT NULL,
                    PermissionCode nvarchar(100) NOT NULL
                );

                INSERT INTO @RolePermissionAssignments (RoleCode, PermissionCode)
                VALUES
                    (N'OperationsManager', N'Pricing.ViewHistory'),
                    (N'Admin', N'Suppliers.View'),
                    (N'Admin', N'Suppliers.Manage'),
                    (N'Admin', N'Pricing.Create'),
                    (N'Admin', N'Pricing.Cancel'),
                    (N'Admin', N'Pricing.ViewHistory'),
                    (N'BusinessManager', N'Customers.Manage'),
                    (N'BusinessManager', N'Pricing.Create'),
                    (N'BusinessManager', N'Pricing.Cancel'),
                    (N'BusinessManager', N'Pricing.ViewHistory'),
                    (N'BusinessManager', N'CustomerPayments.View'),
                    (N'BusinessManager', N'CustomerPayments.Capture'),
                    (N'BusinessManager', N'CustomerPayments.Reverse'),
                    (N'BusinessManager', N'SupplierPayments.View'),
                    (N'BusinessManager', N'SupplierPayments.Capture'),
                    (N'BusinessManager', N'SupplierPayments.Reverse'),
                    (N'BusinessManager', N'ManagementDashboard.View'),
                    (N'Packer', N'Packing.Confirm');

                INSERT INTO dbo.RolePermissions
                (
                    RoleId,
                    PermissionId,
                    AssignedAtUtc,
                    AssignedByUserId
                )
                SELECT
                    role.RoleId,
                    permission.PermissionId,
                    SYSUTCDATETIME(),
                    NULL
                FROM @RolePermissionAssignments AS assignment
                INNER JOIN dbo.Roles AS role
                    ON role.RoleCode = assignment.RoleCode
                INNER JOIN dbo.Permissions AS permission
                    ON permission.PermissionCode = assignment.PermissionCode
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.RolePermissions AS existing
                    WHERE existing.RoleId = role.RoleId
                      AND existing.PermissionId = permission.PermissionId
                );
                """);

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 18,
                columns: new[] { "BodyContent", "Keywords", "Summary", "Title" },
                values: new object[] { "# Customer order form\nOpen the configured Google Form from Order Management and share it with the customer. The response is an intake aid only. An authorised staff member must review it and capture the official multi-line order in PhenyoSync, where server-side prices and stock rules are applied.\n\nCustomer Form responses never create or price an order automatically.", "customer google form intake capture official order", "Open or share the configured Google Form, then capture the official order.", "Share the customer order form" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 20,
                column: "BodyContent",
                value: "# Order status and cancellation\nOrders move through the controlled sequence from Submitted to validated, confirmed, packed, out for delivery and delivered.\n\nCancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 29,
                column: "BodyContent",
                value: "# Expired links\nSecurity links are time-limited and often one-time. Request a new password-reset or expiry-review link from the appropriate workflow. Customer ordering uses the configured Google Form and staff capture process.\n\nDo not edit tokens in the address bar or share links. A used link cannot be reactivated.");

            migrationBuilder.InsertData(
                table: "SystemSettings",
                columns: new[] { "SystemSettingId", "AllowedValuesJson", "Category", "DefaultValue", "Description", "DisplayName", "IsActive", "IsSensitive", "IsSystemSetting", "Key", "MaximumValue", "MinimumValue", "RequiresRestart", "Unit", "UpdatedAtUtc", "UpdatedByUserId", "Value", "ValueType" },
                values: new object[] { 60, null, "Orders", "", "Google Form used to collect external customer requests before staff capture an official order.", "Customer request Google Form URL", true, false, true, "Orders.CustomerGoogleFormUrl", null, null, false, null, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "", "String" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                DECLARE @RolePermissionAssignments TABLE
                (
                    RoleCode nvarchar(50) NOT NULL,
                    PermissionCode nvarchar(100) NOT NULL
                );

                INSERT INTO @RolePermissionAssignments (RoleCode, PermissionCode)
                VALUES
                    (N'OperationsManager', N'Pricing.ViewHistory'),
                    (N'Admin', N'Suppliers.View'),
                    (N'Admin', N'Suppliers.Manage'),
                    (N'Admin', N'Pricing.Create'),
                    (N'Admin', N'Pricing.Cancel'),
                    (N'Admin', N'Pricing.ViewHistory'),
                    (N'BusinessManager', N'Customers.Manage'),
                    (N'BusinessManager', N'Pricing.Create'),
                    (N'BusinessManager', N'Pricing.Cancel'),
                    (N'BusinessManager', N'Pricing.ViewHistory'),
                    (N'BusinessManager', N'CustomerPayments.View'),
                    (N'BusinessManager', N'CustomerPayments.Capture'),
                    (N'BusinessManager', N'CustomerPayments.Reverse'),
                    (N'BusinessManager', N'SupplierPayments.View'),
                    (N'BusinessManager', N'SupplierPayments.Capture'),
                    (N'BusinessManager', N'SupplierPayments.Reverse'),
                    (N'BusinessManager', N'ManagementDashboard.View'),
                    (N'Packer', N'Packing.Confirm');

                DELETE rolePermission
                FROM dbo.RolePermissions AS rolePermission
                INNER JOIN dbo.Roles AS role
                    ON role.RoleId = rolePermission.RoleId
                INNER JOIN dbo.Permissions AS permission
                    ON permission.PermissionId = rolePermission.PermissionId
                INNER JOIN @RolePermissionAssignments AS assignment
                    ON assignment.RoleCode = role.RoleCode
                   AND assignment.PermissionCode = permission.PermissionCode;

                DELETE rolePermission
                FROM dbo.RolePermissions AS rolePermission
                INNER JOIN dbo.Permissions AS permission
                    ON permission.PermissionId = rolePermission.PermissionId
                WHERE permission.PermissionCode IN
                    (N'Pricing.Create', N'Pricing.Cancel', N'Pricing.ViewHistory');

                DELETE FROM dbo.Permissions
                WHERE PermissionCode IN
                    (N'Pricing.Create', N'Pricing.Cancel', N'Pricing.ViewHistory');

                UPDATE dbo.Permissions
                SET DisplayName = N'Send customer order links',
                    UpdatedAtUtc = SYSUTCDATETIME()
                WHERE PermissionCode = N'Orders.SendLink';

                UPDATE dbo.SalesOrders
                SET Status = N'PendingValidation'
                WHERE Status = N'Submitted';

                UPDATE dbo.OrderStatusHistory
                SET PreviousStatus = N'PendingValidation'
                WHERE PreviousStatus = N'Submitted';

                UPDATE dbo.OrderStatusHistory
                SET NewStatus = N'PendingValidation'
                WHERE NewStatus = N'Submitted';
                """);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 60);

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 18,
                columns: new[] { "BodyContent", "Keywords", "Summary", "Title" },
                values: new object[] { "# Customer order links\nSelect a valid customer, confirm the email address and send the secure order link. The link expires according to the configured lifetime and can be used once.\n\nThe public form exposes only active products with current valid prices. A submitted link cannot be reused.", "order link customer email one time expiry", "Generate and email a unique, expiring, one-time order form.", "Send customer order links" });

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 20,
                column: "BodyContent",
                value: "# Order status and cancellation\nOrders move through the controlled sequence from pending validation to confirmed, packed, out for delivery and delivered.\n\nCancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.");

            migrationBuilder.UpdateData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 29,
                column: "BodyContent",
                value: "# Expired links\nSecurity links are time-limited and often one-time. Request a new password-reset link, customer order link or expiry review link from the appropriate workflow.\n\nDo not edit tokens in the address bar or share links. A used link cannot be reactivated.");
        }
    }
}
