﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class FormalReportingHelpContent : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "HelpCategories",
                columns: new[] { "HelpCategoryId", "CreatedAtUtc", "Description", "DisplayName", "IsActive", "SortOrder", "SystemCode", "UpdatedAtUtc" },
                values: new object[] { 9, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), "Formal operational, transactional, financial and pricing reports.", "Reports and analytics", true, 90, "REPORTING", null });

            migrationBuilder.InsertData(
                table: "HelpTopics",
                columns: new[] { "HelpTopicId", "AudienceRolesCsv", "BodyContent", "CreatedAtUtc", "HelpCategoryId", "IsPublic", "IsPublished", "Keywords", "Slug", "SortOrder", "Summary", "Title", "UpdatedAtUtc", "UpdatedByUserId" },
                values: new object[,]
                {
                    { 33, "OperationsManager,BusinessManager,Admin,WarehouseManager", "# Formal reports\nChoose a report, set its criteria and select Preview. The preview is the authoritative dataset for the PDF. If any criterion changes, preview the report again before downloading.\n\nInventory Availability, Expiry and Waste, and Markup Analysis are simple flat reports. Sales and Stock Movement reports use visible control breaks, subtotals and grand totals. Currency is displayed in South African rand and timestamps are shown consistently with the selected criteria.\n\nAccess to costs, reversals and exports is controlled independently. An empty report means no records matched the selected criteria; it is not a failure. Every preview and PDF export is audited.", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), 9, false, true, "report preview criteria pdf export totals empty audit", "formal-reports", 10, "Preview report criteria, understand report structure and export the exact preview as PDF.", "Run and export formal reports", null, null },
                    { 34, "OperationsManager,BusinessManager,Admin,WarehouseManager", "# Financial report\nFilter by date, customer, invoice status, payment status, payment method and amount range. The report summarizes invoiced value, confirmed payments, outstanding value, reversals and write-off losses from stored operational records.\n\nThis is an operational financial summary, not a profit-and-loss statement. It does not infer general-ledger balances, tax liability, payroll, overheads or accounting profit where those ledgers do not exist. Reversal detail is shown only to users with the dedicated permission.", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), 9, false, true, "financial criteria invoice payment outstanding reversal write off non profit loss", "financial-report", 20, "Use adjustable criteria and interpret the operational financial summary correctly.", "Interpret the financial report", null, null },
                    { 35, "OperationsManager,BusinessManager,Admin,WarehouseManager", "# Pricing management report\nMonthly average selling price is quantity weighted from stored SalesOrderItem price snapshots: the sum of quantity multiplied by unit price, divided by total quantity. The annual value is the arithmetic mean of available monthly averages. Months without observations are shown as N/A and are never treated as zero.\n\nThe box plot uses linear-interpolated quartiles and 1.5 times the interquartile range for whiskers and outliers. A box is shown only when at least five observations are available. The support tables contain the exact values used by the line, bar and box-plot charts.", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), 9, false, true, "pricing weighted monthly annual average box plot quartile iqr observation snapshot", "pricing-management-report", 30, "Understand weighted monthly averages, annual means and reliable box plots.", "Interpret pricing charts and formulas", null, null }
                });

            migrationBuilder.InsertData(
                table: "HelpContextMappings",
                columns: new[] { "HelpContextMappingId", "ComponentKey", "HelpTopicId", "IsActive", "Priority", "RoutePattern" },
                values: new object[,]
                {
                    { 33, "ReportsLanding", 33, true, 100, "/reports" },
                    { 34, "FormalReportInventory", 33, true, 100, "/reports/inventory-availability" },
                    { 35, "FormalReportExpiryWaste", 33, true, 100, "/reports/expiry-waste" },
                    { 36, "FormalReportMarkup", 33, true, 100, "/reports/markup-analysis" },
                    { 37, "FormalReportSales", 33, true, 100, "/reports/sales-transactions" },
                    { 38, "FormalReportStockMovements", 33, true, 100, "/reports/stock-movements" },
                    { 39, "FormalReportFinancial", 34, true, 100, "/reports/financial-summary" },
                    { 40, "FormalReportPricing", 35, true, 100, "/reports/pricing-management" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 33);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 34);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 35);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 36);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 37);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 38);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 39);

            migrationBuilder.DeleteData(
                table: "HelpContextMappings",
                keyColumn: "HelpContextMappingId",
                keyValue: 40);

            migrationBuilder.DeleteData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 33);

            migrationBuilder.DeleteData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 34);

            migrationBuilder.DeleteData(
                table: "HelpTopics",
                keyColumn: "HelpTopicId",
                keyValue: 35);

            migrationBuilder.DeleteData(
                table: "HelpCategories",
                keyColumn: "HelpCategoryId",
                keyValue: 9);
        }
    }
}
