﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class PhaseCMobileOperationsTrackingNotifications : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BuyerProcurements",
                columns: table => new
                {
                    BuyerProcurementId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BuyingDateUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AssignedBuyerUserId = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    DocketStoredFileId = table.Column<long>(type: "bigint", nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SubmittedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BuyerProcurements", x => x.BuyerProcurementId);
                    table.ForeignKey(
                        name: "FK_BuyerProcurements_StoredFiles_DocketStoredFileId",
                        column: x => x.DocketStoredFileId,
                        principalTable: "StoredFiles",
                        principalColumn: "StoredFileId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BuyerProcurements_Users_AssignedBuyerUserId",
                        column: x => x.AssignedBuyerUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryRouteCalculations",
                columns: table => new
                {
                    DeliveryRouteCalculationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DeliveryId = table.Column<int>(type: "int", nullable: false),
                    OriginLatitude = table.Column<decimal>(type: "decimal(9,6)", precision: 9, scale: 6, nullable: false),
                    OriginLongitude = table.Column<decimal>(type: "decimal(9,6)", precision: 9, scale: 6, nullable: false),
                    DestinationLatitude = table.Column<decimal>(type: "decimal(9,6)", precision: 9, scale: 6, nullable: false),
                    DestinationLongitude = table.Column<decimal>(type: "decimal(9,6)", precision: 9, scale: 6, nullable: false),
                    DistanceMetres = table.Column<long>(type: "bigint", nullable: false),
                    DurationSeconds = table.Column<int>(type: "int", nullable: false),
                    TrafficDurationSeconds = table.Column<int>(type: "int", nullable: true),
                    EncodedPolyline = table.Column<string>(type: "nvarchar(max)", maxLength: 16000, nullable: true),
                    Provider = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    RequestFingerprint = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    CalculatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExpiresAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryRouteCalculations", x => x.DeliveryRouteCalculationId);
                    table.ForeignKey(
                        name: "FK_DeliveryRouteCalculations_Deliveries_DeliveryId",
                        column: x => x.DeliveryId,
                        principalTable: "Deliveries",
                        principalColumn: "DeliveryId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DriverTrackingSessions",
                columns: table => new
                {
                    DriverTrackingSessionId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DeliveryId = table.Column<int>(type: "int", nullable: false),
                    DriverId = table.Column<int>(type: "int", nullable: false),
                    StartedByUserId = table.Column<int>(type: "int", nullable: false),
                    StartedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ConsentConfirmedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EndedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    EndedReason = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: true),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DriverTrackingSessions", x => x.DriverTrackingSessionId);
                    table.ForeignKey(
                        name: "FK_DriverTrackingSessions_Deliveries_DeliveryId",
                        column: x => x.DeliveryId,
                        principalTable: "Deliveries",
                        principalColumn: "DeliveryId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DriverTrackingSessions_Drivers_DriverId",
                        column: x => x.DriverId,
                        principalTable: "Drivers",
                        principalColumn: "DriverId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DriverTrackingSessions_Users_StartedByUserId",
                        column: x => x.StartedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MobileDeliveryEvents",
                columns: table => new
                {
                    MobileDeliveryEventId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DeliveryId = table.Column<int>(type: "int", nullable: false),
                    RecordedByUserId = table.Column<int>(type: "int", nullable: false),
                    EventType = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    RecordedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MobileDeliveryEvents", x => x.MobileDeliveryEventId);
                    table.ForeignKey(
                        name: "FK_MobileDeliveryEvents_Deliveries_DeliveryId",
                        column: x => x.DeliveryId,
                        principalTable: "Deliveries",
                        principalColumn: "DeliveryId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MobileDeliveryEvents_Users_RecordedByUserId",
                        column: x => x.RecordedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MobileDeviceRegistrations",
                columns: table => new
                {
                    MobileDeviceRegistrationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    DeviceIdentifierHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Platform = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    DeviceName = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: true),
                    AppVersion = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: true),
                    PushToken = table.Column<string>(type: "nvarchar(2048)", maxLength: 2048, nullable: true),
                    RegisteredAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastSeenAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    RevokedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RevokedByUserId = table.Column<int>(type: "int", nullable: true),
                    RevocationReason = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MobileDeviceRegistrations", x => x.MobileDeviceRegistrationId);
                    table.ForeignKey(
                        name: "FK_MobileDeviceRegistrations_Users_RevokedByUserId",
                        column: x => x.RevokedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MobileDeviceRegistrations_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MobileIdempotencyRecords",
                columns: table => new
                {
                    MobileIdempotencyRecordId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    OperationType = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    OperationKeyHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RequestHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    ResponseJson = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExpiresAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MobileIdempotencyRecords", x => x.MobileIdempotencyRecordId);
                    table.ForeignKey(
                        name: "FK_MobileIdempotencyRecords_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "NotificationPreferences",
                columns: table => new
                {
                    NotificationPreferenceId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    PushEnabled = table.Column<bool>(type: "bit", nullable: false),
                    EmailFallbackEnabled = table.Column<bool>(type: "bit", nullable: false),
                    CriticalAlertsEnabled = table.Column<bool>(type: "bit", nullable: false),
                    QuietHoursStart = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    QuietHoursEnd = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    UpdatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NotificationPreferences", x => x.NotificationPreferenceId);
                    table.ForeignKey(
                        name: "FK_NotificationPreferences_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OperationalNotifications",
                columns: table => new
                {
                    OperationalNotificationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NotificationType = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    Severity = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Title = table.Column<string>(type: "nvarchar(180)", maxLength: 180, nullable: false),
                    Message = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                    EntityType = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    EntityId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ActionRoute = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: true),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    CreatedByUserId = table.Column<int>(type: "int", nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExpiresAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OperationalNotifications", x => x.OperationalNotificationId);
                    table.ForeignKey(
                        name: "FK_OperationalNotifications_Users_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PackingScans",
                columns: table => new
                {
                    PackingScanId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SalesOrderId = table.Column<int>(type: "int", nullable: false),
                    SalesOrderItemId = table.Column<int>(type: "int", nullable: false),
                    OrderStockReservationId = table.Column<long>(type: "bigint", nullable: false),
                    ProductBatchId = table.Column<int>(type: "int", nullable: false),
                    ScannedByUserId = table.Column<int>(type: "int", nullable: false),
                    QuantityPackedKg = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    ScannedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RemovedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RemovedByUserId = table.Column<int>(type: "int", nullable: true),
                    RemovalReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    OperationKeyHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PackingScans", x => x.PackingScanId);
                    table.ForeignKey(
                        name: "FK_PackingScans_OrderStockReservations_OrderStockReservationId",
                        column: x => x.OrderStockReservationId,
                        principalTable: "OrderStockReservations",
                        principalColumn: "OrderStockReservationId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingScans_ProductBatches_ProductBatchId",
                        column: x => x.ProductBatchId,
                        principalTable: "ProductBatches",
                        principalColumn: "ProductBatchId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingScans_SalesOrderItems_SalesOrderItemId",
                        column: x => x.SalesOrderItemId,
                        principalTable: "SalesOrderItems",
                        principalColumn: "SalesOrderItemId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingScans_SalesOrders_SalesOrderId",
                        column: x => x.SalesOrderId,
                        principalTable: "SalesOrders",
                        principalColumn: "SalesOrderId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingScans_Users_RemovedByUserId",
                        column: x => x.RemovedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PackingScans_Users_ScannedByUserId",
                        column: x => x.ScannedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "StockReceipts",
                columns: table => new
                {
                    StockReceiptId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SupplierId = table.Column<int>(type: "int", nullable: false),
                    SupplierOrderId = table.Column<int>(type: "int", nullable: true),
                    WarehouseSectionId = table.Column<int>(type: "int", nullable: false),
                    ReceivedByUserId = table.Column<int>(type: "int", nullable: false),
                    ReceiptNumber = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    SupplierDocketNumber = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    PurchaseDateUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    DocketStoredFileId = table.Column<long>(type: "bigint", nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SubmittedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StockReceipts", x => x.StockReceiptId);
                    table.ForeignKey(
                        name: "FK_StockReceipts_StoredFiles_DocketStoredFileId",
                        column: x => x.DocketStoredFileId,
                        principalTable: "StoredFiles",
                        principalColumn: "StoredFileId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockReceipts_SupplierOrders_SupplierOrderId",
                        column: x => x.SupplierOrderId,
                        principalTable: "SupplierOrders",
                        principalColumn: "SupplierOrderId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockReceipts_Suppliers_SupplierId",
                        column: x => x.SupplierId,
                        principalTable: "Suppliers",
                        principalColumn: "SupplierId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockReceipts_Users_ReceivedByUserId",
                        column: x => x.ReceivedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockReceipts_WarehouseSections_WarehouseSectionId",
                        column: x => x.WarehouseSectionId,
                        principalTable: "WarehouseSections",
                        principalColumn: "SectionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "StockWriteOffs",
                columns: table => new
                {
                    StockWriteOffId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductBatchId = table.Column<int>(type: "int", nullable: false),
                    SectionId = table.Column<int>(type: "int", nullable: false),
                    SubmittedByUserId = table.Column<int>(type: "int", nullable: false),
                    DecidedByUserId = table.Column<int>(type: "int", nullable: true),
                    QuantityKg = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    EstimatedUnitCost = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    EstimatedTotalLoss = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    ReasonCode = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    Condition = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    DecisionReason = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    SubmittedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DecidedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CompletedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CorrelationId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StockWriteOffs", x => x.StockWriteOffId);
                    table.ForeignKey(
                        name: "FK_StockWriteOffs_ProductBatches_ProductBatchId",
                        column: x => x.ProductBatchId,
                        principalTable: "ProductBatches",
                        principalColumn: "ProductBatchId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockWriteOffs_Users_DecidedByUserId",
                        column: x => x.DecidedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockWriteOffs_Users_SubmittedByUserId",
                        column: x => x.SubmittedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockWriteOffs_WarehouseSections_SectionId",
                        column: x => x.SectionId,
                        principalTable: "WarehouseSections",
                        principalColumn: "SectionId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BuyerProcurementItems",
                columns: table => new
                {
                    BuyerProcurementItemId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BuyerProcurementId = table.Column<int>(type: "int", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    SupplierId = table.Column<int>(type: "int", nullable: true),
                    RecommendedQuantity = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    RequiredQuantity = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    ActualQuantity = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: true),
                    ActualUnitPrice = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: true),
                    UnitOfMeasure = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Status = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    IsPromotionalItem = table.Column<bool>(type: "bit", nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    UnavailableReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    UpdatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BuyerProcurementItems", x => x.BuyerProcurementItemId);
                    table.ForeignKey(
                        name: "FK_BuyerProcurementItems_BuyerProcurements_BuyerProcurementId",
                        column: x => x.BuyerProcurementId,
                        principalTable: "BuyerProcurements",
                        principalColumn: "BuyerProcurementId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BuyerProcurementItems_Product_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BuyerProcurementItems_Suppliers_SupplierId",
                        column: x => x.SupplierId,
                        principalTable: "Suppliers",
                        principalColumn: "SupplierId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DriverLocationUpdates",
                columns: table => new
                {
                    DriverLocationUpdateId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DriverTrackingSessionId = table.Column<long>(type: "bigint", nullable: false),
                    Latitude = table.Column<decimal>(type: "decimal(9,6)", precision: 9, scale: 6, nullable: false),
                    Longitude = table.Column<decimal>(type: "decimal(9,6)", precision: 9, scale: 6, nullable: false),
                    AccuracyMetres = table.Column<decimal>(type: "decimal(10,2)", precision: 10, scale: 2, nullable: false),
                    SpeedMetresPerSecond = table.Column<decimal>(type: "decimal(10,2)", precision: 10, scale: 2, nullable: true),
                    HeadingDegrees = table.Column<decimal>(type: "decimal(6,2)", precision: 6, scale: 2, nullable: true),
                    CapturedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ReceivedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Source = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    OperationKeyHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DriverLocationUpdates", x => x.DriverLocationUpdateId);
                    table.ForeignKey(
                        name: "FK_DriverLocationUpdates_DriverTrackingSessions_DriverTrackingSessionId",
                        column: x => x.DriverTrackingSessionId,
                        principalTable: "DriverTrackingSessions",
                        principalColumn: "DriverTrackingSessionId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OperationalNotificationRecipients",
                columns: table => new
                {
                    OperationalNotificationRecipientId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OperationalNotificationId = table.Column<long>(type: "bigint", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    ReadAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DismissedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PushSentAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EmailSentAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PushStatus = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    PushAttemptCount = table.Column<int>(type: "int", nullable: false),
                    NextPushAttemptAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SafePushErrorCode = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OperationalNotificationRecipients", x => x.OperationalNotificationRecipientId);
                    table.ForeignKey(
                        name: "FK_OperationalNotificationRecipients_OperationalNotifications_OperationalNotificationId",
                        column: x => x.OperationalNotificationId,
                        principalTable: "OperationalNotifications",
                        principalColumn: "OperationalNotificationId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OperationalNotificationRecipients_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "StockReceiptItems",
                columns: table => new
                {
                    StockReceiptItemId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockReceiptId = table.Column<int>(type: "int", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    ProductBatchId = table.Column<int>(type: "int", nullable: true),
                    QuantityReceivedKg = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    AcceptedQuantityKg = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    RejectedQuantityKg = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    UnitCost = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: true),
                    ContainerCount = table.Column<int>(type: "int", nullable: true),
                    ContainerType = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    BatchReference = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: true),
                    ReceivedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    BestBeforeAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    QualityStatus = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StockReceiptItems", x => x.StockReceiptItemId);
                    table.ForeignKey(
                        name: "FK_StockReceiptItems_ProductBatches_ProductBatchId",
                        column: x => x.ProductBatchId,
                        principalTable: "ProductBatches",
                        principalColumn: "ProductBatchId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockReceiptItems_Product_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockReceiptItems_StockReceipts_StockReceiptId",
                        column: x => x.StockReceiptId,
                        principalTable: "StockReceipts",
                        principalColumn: "StockReceiptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "StockWriteOffEvidence",
                columns: table => new
                {
                    StockWriteOffEvidenceId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockWriteOffId = table.Column<long>(type: "bigint", nullable: false),
                    StoredFileId = table.Column<long>(type: "bigint", nullable: false),
                    UploadedByUserId = table.Column<int>(type: "int", nullable: false),
                    UploadedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Caption = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StockWriteOffEvidence", x => x.StockWriteOffEvidenceId);
                    table.ForeignKey(
                        name: "FK_StockWriteOffEvidence_StockWriteOffs_StockWriteOffId",
                        column: x => x.StockWriteOffId,
                        principalTable: "StockWriteOffs",
                        principalColumn: "StockWriteOffId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_StockWriteOffEvidence_StoredFiles_StoredFileId",
                        column: x => x.StoredFileId,
                        principalTable: "StoredFiles",
                        principalColumn: "StoredFileId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_StockWriteOffEvidence_Users_UploadedByUserId",
                        column: x => x.UploadedByUserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "NotificationDeliveryAttempts",
                columns: table => new
                {
                    NotificationDeliveryAttemptId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OperationalNotificationRecipientId = table.Column<long>(type: "bigint", nullable: false),
                    Channel = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Provider = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Status = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    AttemptNumber = table.Column<int>(type: "int", nullable: false),
                    AttemptedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CompletedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SafeErrorCode = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NotificationDeliveryAttempts", x => x.NotificationDeliveryAttemptId);
                    table.ForeignKey(
                        name: "FK_NotificationDeliveryAttempts_OperationalNotificationRecipients_OperationalNotificationRecipientId",
                        column: x => x.OperationalNotificationRecipientId,
                        principalTable: "OperationalNotificationRecipients",
                        principalColumn: "OperationalNotificationRecipientId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "SystemSettings",
                columns: new[] { "SystemSettingId", "AllowedValuesJson", "Category", "DefaultValue", "Description", "DisplayName", "IsActive", "IsSensitive", "IsSystemSetting", "Key", "MaximumValue", "MinimumValue", "RequiresRestart", "Unit", "UpdatedAtUtc", "UpdatedByUserId", "Value", "ValueType" },
                values: new object[,]
                {
                    { 26, null, "Mobile", "45", "Seconds between foreground driver-location updates.", "Location interval", true, false, true, "Mobile.LocationIntervalSeconds", "300", "15", false, "seconds", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "45", "Integer" },
                    { 27, null, "Mobile", "20", "Movement required before another driver-location point is accepted.", "Minimum movement", true, false, true, "Mobile.LocationMinimumMovementMetres", "1000", "0", false, "metres", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "20", "Integer" },
                    { 28, null, "Mobile", "180", "Seconds after which an active driver location is shown as stale.", "Location stale threshold", true, false, true, "Mobile.LocationStaleAfterSeconds", "3600", "30", false, "seconds", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "180", "Integer" },
                    { 29, null, "Mobile", "30", "Days that detailed delivery-location history is retained.", "Location retention", true, false, true, "Mobile.LocationRetentionDays", "365", "1", false, "days", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "30", "Integer" },
                    { 30, null, "Mobile", "250", "Maximum safe draft operations retained by the mobile client.", "Offline queue maximum", true, false, true, "Mobile.OfflineQueueMaximumItems", "2000", "10", false, "items", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "250", "Integer" },
                    { 31, null, "Mobile", "10", "Maximum delivery proof photograph size accepted from mobile.", "Proof image maximum", true, false, true, "Mobile.ProofMaximumMb", "25", "1", false, "MB", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "10", "Integer" },
                    { 32, null, "Mobile", "10", "Maximum buying-list or receipt docket image size.", "Docket image maximum", true, false, true, "Mobile.DocketMaximumMb", "25", "1", false, "MB", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "10", "Integer" },
                    { 33, null, "Maps", "10", "Minutes a matching route calculation may be reused.", "Route cache", true, false, true, "Maps.RouteCacheMinutes", "120", "1", false, "minutes", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "10", "Integer" },
                    { 34, null, "Maps", "20", "Maximum explicit route refreshes per delivery.", "Route refresh limit", true, false, true, "Maps.MaximumRefreshesPerDelivery", "100", "1", false, "refreshes", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "20", "Integer" },
                    { 35, null, "Maps", "true", "Request traffic-aware travel durations from the configured provider.", "Traffic-aware routing", true, false, true, "Maps.TrafficAwareEnabled", null, null, false, null, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "true", "Boolean" },
                    { 36, null, "Notifications", "true", "Enable Firebase push processing when protected provider configuration is present.", "Push enabled", true, false, true, "Notifications.PushEnabled", null, null, false, null, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "true", "Boolean" },
                    { 37, null, "Notifications", "false", "Allow email fallback for supported critical operational notifications.", "Email fallback", true, false, true, "Notifications.EmailFallbackEnabled", null, null, false, null, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "false", "Boolean" },
                    { 38, null, "Notifications", "4", "Maximum attempts for a transient notification delivery failure.", "Maximum retries", true, false, true, "Notifications.MaximumRetryCount", "10", "0", false, "attempts", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "4", "Integer" },
                    { 39, null, "Notifications", "60", "Base seconds before retrying a transient notification delivery failure.", "Retry delay", true, false, true, "Notifications.RetryDelaySeconds", "3600", "10", false, "seconds", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "60", "Integer" },
                    { 40, null, "Write-off", "1000", "Maximum estimated loss a Stock Taker may complete without management approval.", "Stock Taker value limit", true, false, true, "WriteOff.StockTakerMaximumValue", "1000000", "0", false, "currency", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "1000", "Decimal" },
                    { 41, null, "Write-off", "100", "Maximum quantity a Stock Taker may complete without management approval.", "Stock Taker quantity limit", true, false, true, "WriteOff.StockTakerMaximumQuantity", "100000", "0", false, "kg", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "100", "Decimal" },
                    { 42, null, "Write-off", "500", "Estimated loss above which write-off evidence is required.", "Photo threshold", true, false, true, "WriteOff.RequirePhotoAboveValue", "1000000", "0", false, "currency", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "500", "Decimal" },
                    { 43, null, "Write-off", "1000", "Estimated loss above which management approval is required.", "Approval threshold", true, false, true, "WriteOff.RequireApprovalAboveValue", "1000000", "0", false, "currency", new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "1000", "Decimal" },
                    { 44, null, "Write-off", "true", "Block expired batches from normal stock use until a write-off decision is recorded.", "Block expired batches", true, false, true, "WriteOff.AllowExpiredBatchAutomaticBlock", null, null, false, null, new DateTime(2026, 7, 24, 0, 0, 0, 0, DateTimeKind.Utc), null, "true", "Boolean" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurementItems_BuyerProcurementId_ProductId",
                table: "BuyerProcurementItems",
                columns: new[] { "BuyerProcurementId", "ProductId" });

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurementItems_ProductId",
                table: "BuyerProcurementItems",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurementItems_SupplierId",
                table: "BuyerProcurementItems",
                column: "SupplierId");

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurements_AssignedBuyerUserId_BuyingDateUtc_Status",
                table: "BuyerProcurements",
                columns: new[] { "AssignedBuyerUserId", "BuyingDateUtc", "Status" });

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurements_CorrelationId",
                table: "BuyerProcurements",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurements_DocketStoredFileId",
                table: "BuyerProcurements",
                column: "DocketStoredFileId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryRouteCalculations_DeliveryId_CalculatedAtUtc",
                table: "DeliveryRouteCalculations",
                columns: new[] { "DeliveryId", "CalculatedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryRouteCalculations_DeliveryId_RequestFingerprint",
                table: "DeliveryRouteCalculations",
                columns: new[] { "DeliveryId", "RequestFingerprint" });

            migrationBuilder.CreateIndex(
                name: "IX_DriverLocationUpdates_DriverTrackingSessionId_CapturedAtUtc",
                table: "DriverLocationUpdates",
                columns: new[] { "DriverTrackingSessionId", "CapturedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "UX_DriverLocationUpdates_Session_Operation",
                table: "DriverLocationUpdates",
                columns: new[] { "DriverTrackingSessionId", "OperationKeyHash" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_DriverTrackingSessions_CorrelationId",
                table: "DriverTrackingSessions",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_DriverTrackingSessions_DeliveryId_Status",
                table: "DriverTrackingSessions",
                columns: new[] { "DeliveryId", "Status" });

            migrationBuilder.CreateIndex(
                name: "IX_DriverTrackingSessions_DriverId_Status",
                table: "DriverTrackingSessions",
                columns: new[] { "DriverId", "Status" });

            migrationBuilder.CreateIndex(
                name: "IX_DriverTrackingSessions_StartedByUserId",
                table: "DriverTrackingSessions",
                column: "StartedByUserId");

            migrationBuilder.CreateIndex(
                name: "UX_DriverTrackingSessions_ActiveDelivery",
                table: "DriverTrackingSessions",
                column: "DeliveryId",
                unique: true,
                filter: "[Status] = 'Active'");

            migrationBuilder.CreateIndex(
                name: "IX_MobileDeliveryEvents_CorrelationId",
                table: "MobileDeliveryEvents",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_MobileDeliveryEvents_DeliveryId_RecordedAtUtc",
                table: "MobileDeliveryEvents",
                columns: new[] { "DeliveryId", "RecordedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_MobileDeliveryEvents_RecordedByUserId",
                table: "MobileDeliveryEvents",
                column: "RecordedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_MobileDeviceRegistrations_IsActive_LastSeenAtUtc",
                table: "MobileDeviceRegistrations",
                columns: new[] { "IsActive", "LastSeenAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_MobileDeviceRegistrations_RevokedByUserId",
                table: "MobileDeviceRegistrations",
                column: "RevokedByUserId");

            migrationBuilder.CreateIndex(
                name: "UX_MobileDeviceRegistrations_User_Device",
                table: "MobileDeviceRegistrations",
                columns: new[] { "UserId", "DeviceIdentifierHash" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MobileIdempotencyRecords_ExpiresAtUtc",
                table: "MobileIdempotencyRecords",
                column: "ExpiresAtUtc");

            migrationBuilder.CreateIndex(
                name: "UX_MobileIdempotency_User_Operation_Key",
                table: "MobileIdempotencyRecords",
                columns: new[] { "UserId", "OperationType", "OperationKeyHash" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_NotificationDeliveryAttempts_OperationalNotificationRecipientId_AttemptNumber",
                table: "NotificationDeliveryAttempts",
                columns: new[] { "OperationalNotificationRecipientId", "AttemptNumber" });

            migrationBuilder.CreateIndex(
                name: "IX_NotificationPreferences_UserId",
                table: "NotificationPreferences",
                column: "UserId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_OperationalNotificationRecipients_PushStatus_NextPushAttemptAtUtc",
                table: "OperationalNotificationRecipients",
                columns: new[] { "PushStatus", "NextPushAttemptAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_OperationalNotificationRecipients_UserId_ReadAtUtc_DismissedAtUtc",
                table: "OperationalNotificationRecipients",
                columns: new[] { "UserId", "ReadAtUtc", "DismissedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "UX_NotificationRecipients_Notification_User",
                table: "OperationalNotificationRecipients",
                columns: new[] { "OperationalNotificationId", "UserId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_OperationalNotifications_CorrelationId",
                table: "OperationalNotifications",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_OperationalNotifications_CreatedAtUtc_NotificationType",
                table: "OperationalNotifications",
                columns: new[] { "CreatedAtUtc", "NotificationType" });

            migrationBuilder.CreateIndex(
                name: "IX_OperationalNotifications_CreatedByUserId",
                table: "OperationalNotifications",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_PackingScans_OrderStockReservationId",
                table: "PackingScans",
                column: "OrderStockReservationId");

            migrationBuilder.CreateIndex(
                name: "IX_PackingScans_ProductBatchId",
                table: "PackingScans",
                column: "ProductBatchId");

            migrationBuilder.CreateIndex(
                name: "IX_PackingScans_RemovedByUserId",
                table: "PackingScans",
                column: "RemovedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_PackingScans_SalesOrderId_ScannedAtUtc",
                table: "PackingScans",
                columns: new[] { "SalesOrderId", "ScannedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_PackingScans_SalesOrderItemId",
                table: "PackingScans",
                column: "SalesOrderItemId");

            migrationBuilder.CreateIndex(
                name: "UX_PackingScans_User_Operation",
                table: "PackingScans",
                columns: new[] { "ScannedByUserId", "OperationKeyHash" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_StockReceiptItems_ProductBatchId",
                table: "StockReceiptItems",
                column: "ProductBatchId");

            migrationBuilder.CreateIndex(
                name: "IX_StockReceiptItems_ProductId",
                table: "StockReceiptItems",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_StockReceiptItems_StockReceiptId_ProductId",
                table: "StockReceiptItems",
                columns: new[] { "StockReceiptId", "ProductId" });

            migrationBuilder.CreateIndex(
                name: "IX_StockReceipts_CorrelationId",
                table: "StockReceipts",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_StockReceipts_DocketStoredFileId",
                table: "StockReceipts",
                column: "DocketStoredFileId");

            migrationBuilder.CreateIndex(
                name: "IX_StockReceipts_ReceiptNumber",
                table: "StockReceipts",
                column: "ReceiptNumber",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_StockReceipts_ReceivedByUserId",
                table: "StockReceipts",
                column: "ReceivedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_StockReceipts_Status_PurchaseDateUtc",
                table: "StockReceipts",
                columns: new[] { "Status", "PurchaseDateUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_StockReceipts_SupplierId",
                table: "StockReceipts",
                column: "SupplierId");

            migrationBuilder.CreateIndex(
                name: "IX_StockReceipts_SupplierOrderId",
                table: "StockReceipts",
                column: "SupplierOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_StockReceipts_WarehouseSectionId",
                table: "StockReceipts",
                column: "WarehouseSectionId");

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffEvidence_StockWriteOffId_UploadedAtUtc",
                table: "StockWriteOffEvidence",
                columns: new[] { "StockWriteOffId", "UploadedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffEvidence_StoredFileId",
                table: "StockWriteOffEvidence",
                column: "StoredFileId");

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffEvidence_UploadedByUserId",
                table: "StockWriteOffEvidence",
                column: "UploadedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffs_CorrelationId",
                table: "StockWriteOffs",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffs_DecidedByUserId",
                table: "StockWriteOffs",
                column: "DecidedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffs_ProductBatchId_Status",
                table: "StockWriteOffs",
                columns: new[] { "ProductBatchId", "Status" });

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffs_SectionId",
                table: "StockWriteOffs",
                column: "SectionId");

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffs_Status_SubmittedAtUtc",
                table: "StockWriteOffs",
                columns: new[] { "Status", "SubmittedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_StockWriteOffs_SubmittedByUserId",
                table: "StockWriteOffs",
                column: "SubmittedByUserId");

            migrationBuilder.Sql("""
                IF NOT EXISTS (
                    SELECT 1 FROM dbo.Roles WHERE RoleCode = 'MarketBuyer')
                BEGIN
                    INSERT INTO dbo.Roles
                        (RoleCode, RoleName, Description, IsSystemRole, IsActive, CreatedAtUtc)
                    VALUES
                        ('MarketBuyer', 'Market Buyer',
                         'Mobile purchasing user for approved buying lists.',
                         1, 1, SYSUTCDATETIME());
                END;

                DECLARE @PhaseCPermissions TABLE
                (
                    PermissionCode nvarchar(100) NOT NULL PRIMARY KEY,
                    DisplayName nvarchar(120) NOT NULL,
                    Module nvarchar(80) NOT NULL
                );

                INSERT INTO @PhaseCPermissions VALUES
                    ('Mobile.Access', 'Access PhenyoSync Mobile', 'Mobile'),
                    ('Mobile.Delivery.ViewOwn', 'View own mobile deliveries', 'Mobile'),
                    ('Mobile.Delivery.ViewAll', 'View all mobile deliveries', 'Mobile'),
                    ('Mobile.Delivery.UpdateOwn', 'Update own mobile delivery', 'Mobile'),
                    ('Mobile.Delivery.CompleteOwn', 'Complete own mobile delivery', 'Mobile'),
                    ('Mobile.Delivery.UploadProof', 'Upload mobile delivery proof', 'Mobile'),
                    ('Mobile.BuyingList.View', 'View mobile buying lists', 'Mobile'),
                    ('Mobile.BuyingList.Update', 'Update mobile buying lists', 'Mobile'),
                    ('Mobile.BuyingList.Submit', 'Submit mobile buying lists', 'Mobile'),
                    ('Mobile.BuyingList.AddPromotionalItem', 'Add promotional buying items', 'Mobile'),
                    ('Mobile.BuyingList.UploadDocket', 'Upload buying-list dockets', 'Mobile'),
                    ('Mobile.StockReceipt.View', 'View mobile stock receipts', 'Mobile'),
                    ('Mobile.StockReceipt.Create', 'Create mobile stock receipts', 'Mobile'),
                    ('Mobile.StockReceipt.Submit', 'Submit mobile stock receipts', 'Mobile'),
                    ('Mobile.StockReceipt.UploadDocket', 'Upload stock-receipt dockets', 'Mobile'),
                    ('Mobile.Packing.View', 'View mobile packing work', 'Mobile'),
                    ('Mobile.Packing.Scan', 'Scan packed Product Batches', 'Mobile'),
                    ('Mobile.Packing.RemoveScan', 'Correct packing scans', 'Mobile'),
                    ('Mobile.Packing.Complete', 'Complete mobile packing', 'Mobile'),
                    ('Mobile.Dispatch.View', 'View dispatch queue', 'Mobile'),
                    ('Mobile.Dispatch.Confirm', 'Confirm order dispatch', 'Mobile'),
                    ('Mobile.Dispatch.Reject', 'Reject or return packed orders', 'Mobile'),
                    ('Mobile.Tracking.ShareOwn', 'Share own delivery location', 'Mobile'),
                    ('Mobile.Tracking.ViewOwn', 'View own delivery tracking', 'Mobile'),
                    ('Mobile.Tracking.ViewAll', 'View all delivery tracking', 'Mobile'),
                    ('Mobile.Tracking.Manage', 'Manage delivery tracking', 'Mobile'),
                    ('Mobile.WriteOff.View', 'View mobile stock write-offs', 'Mobile'),
                    ('Mobile.WriteOff.Create', 'Create mobile stock write-offs', 'Mobile'),
                    ('Mobile.WriteOff.Complete', 'Complete ordinary stock write-offs', 'Mobile'),
                    ('Mobile.WriteOff.Approve', 'Approve stock write-offs', 'Mobile'),
                    ('Mobile.WriteOff.Reject', 'Reject stock write-offs', 'Mobile'),
                    ('Mobile.WriteOff.Override', 'Override stock write-off rules', 'Mobile'),
                    ('Mobile.WriteOff.UploadEvidence', 'Upload stock write-off evidence', 'Mobile'),
                    ('Mobile.WriteOff.ViewFinancialImpact', 'View write-off financial impact', 'Mobile'),
                    ('Mobile.DeviceManagement.View', 'View registered mobile devices', 'Mobile'),
                    ('Mobile.DeviceManagement.Manage', 'Manage registered mobile devices', 'Mobile'),
                    ('Notifications.View', 'View operational notifications', 'Notifications'),
                    ('Notifications.ManagePreferences', 'Manage notification preferences', 'Notifications'),
                    ('Notifications.ManageRules', 'Manage notification rules', 'Notifications'),
                    ('Notifications.ViewDeliveryHistory', 'View notification delivery history', 'Notifications'),
                    ('Notifications.SendTest', 'Send test notifications', 'Notifications');

                INSERT INTO dbo.Permissions
                    (PermissionName, PermissionCode, DisplayName, Module,
                     IsSystemPermission, IsActive, CreatedAtUtc)
                SELECT seed.PermissionCode, seed.PermissionCode,
                       seed.DisplayName, seed.Module, 1, 1, SYSUTCDATETIME()
                FROM @PhaseCPermissions seed
                WHERE NOT EXISTS (
                    SELECT 1 FROM dbo.Permissions existing
                    WHERE existing.PermissionCode = seed.PermissionCode);

                UPDATE permission
                SET permission.PermissionName = seed.PermissionCode,
                    permission.DisplayName = seed.DisplayName,
                    permission.Module = seed.Module,
                    permission.IsSystemPermission = 1,
                    permission.IsActive = 1,
                    permission.UpdatedAtUtc = SYSUTCDATETIME()
                FROM dbo.Permissions permission
                JOIN @PhaseCPermissions seed
                  ON seed.PermissionCode = permission.PermissionCode;

                DECLARE @PhaseCRolePermissions TABLE
                (
                    RoleCode nvarchar(50) NOT NULL,
                    PermissionCode nvarchar(100) NOT NULL,
                    PRIMARY KEY (RoleCode, PermissionCode)
                );

                INSERT INTO @PhaseCRolePermissions
                SELECT roleCode.RoleCode, permission.PermissionCode
                FROM (VALUES ('CEO'), ('COO'), ('BusinessManager'))
                     roleCode(RoleCode)
                CROSS JOIN @PhaseCPermissions permission;

                INSERT INTO @PhaseCRolePermissions VALUES
                    ('Driver', 'Mobile.Access'),
                    ('Driver', 'Mobile.Delivery.ViewOwn'),
                    ('Driver', 'Mobile.Delivery.UpdateOwn'),
                    ('Driver', 'Mobile.Delivery.CompleteOwn'),
                    ('Driver', 'Mobile.Delivery.UploadProof'),
                    ('Driver', 'Mobile.Tracking.ShareOwn'),
                    ('Driver', 'Mobile.Tracking.ViewOwn'),
                    ('Driver', 'Notifications.View'),
                    ('Driver', 'Notifications.ManagePreferences'),
                    ('Packer', 'Mobile.Access'),
                    ('Packer', 'Mobile.Packing.View'),
                    ('Packer', 'Mobile.Packing.Scan'),
                    ('Packer', 'Mobile.Packing.RemoveScan'),
                    ('Packer', 'Mobile.Packing.Complete'),
                    ('Packer', 'Notifications.View'),
                    ('Packer', 'Notifications.ManagePreferences'),
                    ('StockTaker', 'Mobile.Access'),
                    ('StockTaker', 'Suppliers.View'),
                    ('StockTaker', 'Mobile.BuyingList.View'),
                    ('StockTaker', 'Mobile.StockReceipt.View'),
                    ('StockTaker', 'Mobile.StockReceipt.Create'),
                    ('StockTaker', 'Mobile.StockReceipt.Submit'),
                    ('StockTaker', 'Mobile.StockReceipt.UploadDocket'),
                    ('StockTaker', 'Mobile.WriteOff.View'),
                    ('StockTaker', 'Mobile.WriteOff.Create'),
                    ('StockTaker', 'Mobile.WriteOff.Complete'),
                    ('StockTaker', 'Mobile.WriteOff.UploadEvidence'),
                    ('StockTaker', 'Mobile.WriteOff.ViewFinancialImpact'),
                    ('StockTaker', 'Notifications.View'),
                    ('StockTaker', 'Notifications.ManagePreferences'),
                    ('MarketBuyer', 'Mobile.Access'),
                    ('MarketBuyer', 'Mobile.BuyingList.View'),
                    ('MarketBuyer', 'Mobile.BuyingList.Update'),
                    ('MarketBuyer', 'Mobile.BuyingList.Submit'),
                    ('MarketBuyer', 'Mobile.BuyingList.AddPromotionalItem'),
                    ('MarketBuyer', 'Mobile.BuyingList.UploadDocket'),
                    ('MarketBuyer', 'Notifications.View'),
                    ('MarketBuyer', 'Notifications.ManagePreferences');

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
                FROM @PhaseCRolePermissions seed
                JOIN dbo.Roles role
                  ON role.RoleCode = seed.RoleCode
                JOIN dbo.Permissions permission
                  ON permission.PermissionCode = seed.PermissionCode
                WHERE NOT EXISTS (
                    SELECT 1 FROM dbo.RolePermissions existing
                    WHERE existing.RoleId = role.RoleId
                      AND existing.PermissionId = permission.PermissionId);
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BuyerProcurementItems");

            migrationBuilder.DropTable(
                name: "DeliveryRouteCalculations");

            migrationBuilder.DropTable(
                name: "DriverLocationUpdates");

            migrationBuilder.DropTable(
                name: "MobileDeliveryEvents");

            migrationBuilder.DropTable(
                name: "MobileDeviceRegistrations");

            migrationBuilder.DropTable(
                name: "MobileIdempotencyRecords");

            migrationBuilder.DropTable(
                name: "NotificationDeliveryAttempts");

            migrationBuilder.DropTable(
                name: "NotificationPreferences");

            migrationBuilder.DropTable(
                name: "PackingScans");

            migrationBuilder.DropTable(
                name: "StockReceiptItems");

            migrationBuilder.DropTable(
                name: "StockWriteOffEvidence");

            migrationBuilder.DropTable(
                name: "BuyerProcurements");

            migrationBuilder.DropTable(
                name: "DriverTrackingSessions");

            migrationBuilder.DropTable(
                name: "OperationalNotificationRecipients");

            migrationBuilder.DropTable(
                name: "StockReceipts");

            migrationBuilder.DropTable(
                name: "StockWriteOffs");

            migrationBuilder.DropTable(
                name: "OperationalNotifications");

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 26);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 27);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 28);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 29);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 30);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 31);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 32);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 33);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 34);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 35);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 36);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 37);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 38);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 39);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 40);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 41);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 42);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 43);

            migrationBuilder.DeleteData(
                table: "SystemSettings",
                keyColumn: "SystemSettingId",
                keyValue: 44);
        }
    }
}
