using System.Reflection;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using PhenyoSyncAPI.Data;

#nullable disable

namespace PhenyoSyncAPI.Migrations;

[DbContext(typeof(PhenyoSyncDbContext))]
[Migration("20260724120000_PhaseA1SecurityValidationRoles")]
public partial class PhaseA1SecurityValidationRoles : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        var assembly = typeof(PhaseA1SecurityValidationRoles).Assembly;
        using var stream = assembly.GetManifestResourceStream(
            "PhenyoSyncAPI.Database.PhaseA1SecurityValidationRoles.sql")
            ?? throw new InvalidOperationException(
                "The embedded Phase A1 database script was not found.");
        using var reader = new StreamReader(stream);
        var script = reader.ReadToEnd();
        var batches = System.Text.RegularExpressions.Regex.Split(
            script,
            @"^\s*GO\s*$",
            System.Text.RegularExpressions.RegexOptions.Multiline |
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        foreach (var batch in batches.Where(item =>
                     !string.IsNullOrWhiteSpace(item)))
        {
            migrationBuilder.Sql(batch);
        }
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        // Intentionally non-destructive. Phase A1 normalizes security data and
        // adds accountability fields that must not be silently discarded.
    }
}
