﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class CompleteBuyingListManagementAndMobilePermissions : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Notes",
                table: "BuyerProcurementItems",
                newName: "ManagementNotes");

            migrationBuilder.AddColumn<int>(
                name: "BuyerProcurementItemId",
                table: "RawStockReceiptLines",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "AssignedBuyerUserId",
                table: "BuyerProcurements",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "CancellationReason",
                table: "BuyerProcurements",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CancelledAtUtc",
                table: "BuyerProcurements",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CancelledByUserId",
                table: "BuyerProcurements",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CreatedByUserId",
                table: "BuyerProcurements",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Priority",
                table: "BuyerProcurements",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "Standard");

            migrationBuilder.AddColumn<DateTime>(
                name: "PublishedAtUtc",
                table: "BuyerProcurements",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ReferenceNumber",
                table: "BuyerProcurements",
                type: "nvarchar(40)",
                maxLength: 40,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Title",
                table: "BuyerProcurements",
                type: "nvarchar(160)",
                maxLength: 160,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "UpdatedAtUtc",
                table: "BuyerProcurements",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "BuyerNotes",
                table: "BuyerProcurementItems",
                type: "nvarchar(1000)",
                maxLength: 1000,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "PreferredSupplierId",
                table: "BuyerProcurementItems",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Priority",
                table: "BuyerProcurementItems",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "Standard");

            migrationBuilder.AddColumn<decimal>(
                name: "ReceivedQuantity",
                table: "BuyerProcurementItems",
                type: "decimal(18,2)",
                precision: 18,
                scale: 2,
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<byte[]>(
                name: "RowVersion",
                table: "BuyerProcurementItems",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SubstituteNotes",
                table: "BuyerProcurementItems",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SubstituteRawStockItemId",
                table: "BuyerProcurementItems",
                type: "int",
                nullable: true);

            migrationBuilder.Sql(
                """
                UPDATE list
                SET
                    list.ReferenceNumber =
                        CONCAT(
                            'BL-LEGACY-',
                            RIGHT(
                                '0000000000' +
                                CONVERT(varchar(10), list.BuyerProcurementId),
                                10
                            )
                        ),
                    list.Priority = 'Standard',
                    list.UpdatedAtUtc =
                        COALESCE(
                            list.SubmittedAtUtc,
                            list.CreatedAtUtc,
                            SYSUTCDATETIME()
                        ),
                    list.PublishedAtUtc =
                        CASE
                            WHEN list.Status <> 'Draft'
                            THEN COALESCE(
                                list.SubmittedAtUtc,
                                list.CreatedAtUtc,
                                SYSUTCDATETIME()
                            )
                            ELSE NULL
                        END,
                    list.Status =
                        CASE
                            WHEN list.Status = 'Completed'
                                 AND EXISTS
                                 (
                                     SELECT 1
                                     FROM dbo.RawStockReceipts receipt
                                     WHERE receipt.BuyerProcurementId =
                                           list.BuyerProcurementId
                                 )
                            THEN 'Completed'
                            WHEN list.Status = 'Completed'
                            THEN 'Submitted'
                            ELSE list.Status
                        END
                FROM dbo.BuyerProcurements list
                WHERE list.ReferenceNumber = '';

                UPDATE item
                SET item.Priority = 'Standard'
                FROM dbo.BuyerProcurementItems item
                WHERE item.Priority = '';

                UPDATE line
                SET line.BuyerProcurementItemId = matched.BuyerProcurementItemId
                FROM dbo.RawStockReceiptLines line
                JOIN dbo.RawStockReceipts receipt
                  ON receipt.RawStockReceiptId = line.RawStockReceiptId
                CROSS APPLY
                (
                    SELECT MIN(item.BuyerProcurementItemId)
                           AS BuyerProcurementItemId,
                           COUNT_BIG(*) AS MatchCount
                    FROM dbo.BuyerProcurementItems item
                    WHERE item.BuyerProcurementId =
                          receipt.BuyerProcurementId
                      AND item.RawStockItemId = line.RawStockItemId
                ) matched
                WHERE receipt.BuyerProcurementId IS NOT NULL
                  AND matched.MatchCount = 1;

                UPDATE item
                SET item.ReceivedQuantity = received.AcceptedQuantity
                FROM dbo.BuyerProcurementItems item
                JOIN
                (
                    SELECT
                        line.BuyerProcurementItemId,
                        SUM(line.AcceptedQuantity) AS AcceptedQuantity
                    FROM dbo.RawStockReceiptLines line
                    WHERE line.BuyerProcurementItemId IS NOT NULL
                    GROUP BY line.BuyerProcurementItemId
                ) received
                  ON received.BuyerProcurementItemId =
                     item.BuyerProcurementItemId;
                """);

            migrationBuilder.Sql(
                """
                DECLARE @BuyingListPermissionSeed TABLE
                (
                    PermissionCode nvarchar(100) NOT NULL,
                    DisplayName nvarchar(150) NOT NULL,
                    Module nvarchar(100) NOT NULL
                );

                INSERT INTO @BuyingListPermissionSeed VALUES
                    ('BuyingList.View', 'View Buying Lists', 'BuyingList'),
                    ('BuyingList.ViewAll', 'View all Buying Lists', 'BuyingList'),
                    ('BuyingList.Create', 'Create Buying List drafts', 'BuyingList'),
                    ('BuyingList.UpdateDraft', 'Update Buying List drafts', 'BuyingList'),
                    ('BuyingList.DeleteDraft', 'Remove Buying List draft lines', 'BuyingList'),
                    ('BuyingList.Assign', 'Assign Buying Lists', 'BuyingList'),
                    ('BuyingList.Publish', 'Publish Buying Lists', 'BuyingList'),
                    ('BuyingList.Cancel', 'Cancel Buying Lists', 'BuyingList'),
                    ('Mobile.BuyingList.ViewAll', 'View all mobile Buying Lists', 'Mobile'),
                    ('Mobile.BuyingList.Create', 'Create mobile Buying Lists', 'Mobile'),
                    ('Mobile.BuyingList.Assign', 'Assign mobile Buying Lists', 'Mobile'),
                    ('Mobile.Notification.View', 'View mobile notifications', 'Mobile'),
                    ('Mobile.Profile.View', 'View the mobile profile', 'Mobile'),
                    ('Mobile.Help.View', 'View mobile help and safety', 'Mobile');

                INSERT INTO dbo.Permissions
                    (
                        PermissionName,
                        PermissionCode,
                        DisplayName,
                        Module,
                        IsSystemPermission,
                        IsActive,
                        CreatedAtUtc
                    )
                SELECT
                    seed.PermissionCode,
                    seed.PermissionCode,
                    seed.DisplayName,
                    seed.Module,
                    1,
                    1,
                    SYSUTCDATETIME()
                FROM @BuyingListPermissionSeed seed
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.Permissions existing
                    WHERE existing.PermissionCode = seed.PermissionCode
                );

                UPDATE permission
                SET
                    permission.PermissionName = seed.PermissionCode,
                    permission.DisplayName = seed.DisplayName,
                    permission.Module = seed.Module,
                    permission.IsSystemPermission = 1,
                    permission.IsActive = 1,
                    permission.UpdatedAtUtc = SYSUTCDATETIME()
                FROM dbo.Permissions permission
                JOIN @BuyingListPermissionSeed seed
                  ON seed.PermissionCode = permission.PermissionCode;

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT
                    role.RoleId,
                    permission.PermissionId,
                    SYSUTCDATETIME()
                FROM dbo.Roles role
                CROSS JOIN dbo.Permissions permission
                WHERE role.RoleCode IN
                    ('CEO', 'COO', 'BusinessManager')
                  AND permission.PermissionCode IN
                    (
                        SELECT PermissionCode
                        FROM @BuyingListPermissionSeed
                    )
                  AND NOT EXISTS
                    (
                        SELECT 1
                        FROM dbo.RolePermissions existing
                        WHERE existing.RoleId = role.RoleId
                          AND existing.PermissionId =
                              permission.PermissionId
                    );

                DECLARE @BuyingListRoleAssignments TABLE
                (
                    RoleCode nvarchar(50) NOT NULL,
                    PermissionCode nvarchar(100) NOT NULL
                );

                INSERT INTO @BuyingListRoleAssignments VALUES
                    ('Admin', 'BuyingList.View'),
                    ('Admin', 'BuyingList.ViewAll'),
                    ('Admin', 'BuyingList.Create'),
                    ('Admin', 'BuyingList.UpdateDraft'),
                    ('Admin', 'BuyingList.DeleteDraft'),
                    ('Admin', 'BuyingList.Assign'),
                    ('Admin', 'BuyingList.Publish'),
                    ('Admin', 'BuyingList.Cancel'),
                    ('StockTaker', 'Mobile.BuyingList.ViewAll'),
                    ('StockTaker', 'Mobile.Notification.View'),
                    ('StockTaker', 'Mobile.Profile.View'),
                    ('StockTaker', 'Mobile.Help.View'),
                    ('Packer', 'Mobile.Notification.View'),
                    ('Packer', 'Mobile.Profile.View'),
                    ('Packer', 'Mobile.Help.View'),
                    ('Driver', 'Mobile.Notification.View'),
                    ('Driver', 'Mobile.Profile.View'),
                    ('Driver', 'Mobile.Help.View'),
                    ('MarketBuyer', 'Mobile.Notification.View'),
                    ('MarketBuyer', 'Mobile.Profile.View'),
                    ('MarketBuyer', 'Mobile.Help.View');

                INSERT INTO dbo.RolePermissions
                    (RoleId, PermissionId, AssignedAtUtc)
                SELECT
                    role.RoleId,
                    permission.PermissionId,
                    SYSUTCDATETIME()
                FROM @BuyingListRoleAssignments assignment
                JOIN dbo.Roles role
                  ON role.RoleCode = assignment.RoleCode
                JOIN dbo.Permissions permission
                  ON permission.PermissionCode =
                     assignment.PermissionCode
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.RolePermissions existing
                    WHERE existing.RoleId = role.RoleId
                      AND existing.PermissionId =
                          permission.PermissionId
                );
                """);

            migrationBuilder.CreateIndex(
                name: "IX_RawStockReceiptLines_BuyerProcurementItemId",
                table: "RawStockReceiptLines",
                column: "BuyerProcurementItemId");

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurements_CancelledByUserId",
                table: "BuyerProcurements",
                column: "CancelledByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurements_CreatedByUserId",
                table: "BuyerProcurements",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "UX_BuyerProcurements_Reference",
                table: "BuyerProcurements",
                column: "ReferenceNumber",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurementItems_BuyerProcurementId_RawStockItemId",
                table: "BuyerProcurementItems",
                columns: new[] { "BuyerProcurementId", "RawStockItemId" });

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurementItems_PreferredSupplierId",
                table: "BuyerProcurementItems",
                column: "PreferredSupplierId");

            migrationBuilder.CreateIndex(
                name: "IX_BuyerProcurementItems_SubstituteRawStockItemId",
                table: "BuyerProcurementItems",
                column: "SubstituteRawStockItemId");

            migrationBuilder.AddForeignKey(
                name: "FK_BuyerProcurementItems_RawStockItems_SubstituteRawStockItemId",
                table: "BuyerProcurementItems",
                column: "SubstituteRawStockItemId",
                principalTable: "RawStockItems",
                principalColumn: "RawStockItemId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_BuyerProcurementItems_Suppliers_PreferredSupplierId",
                table: "BuyerProcurementItems",
                column: "PreferredSupplierId",
                principalTable: "Suppliers",
                principalColumn: "SupplierId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_BuyerProcurements_Users_CancelledByUserId",
                table: "BuyerProcurements",
                column: "CancelledByUserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_BuyerProcurements_Users_CreatedByUserId",
                table: "BuyerProcurements",
                column: "CreatedByUserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_RawStockReceiptLines_BuyerProcurementItems_BuyerProcurementItemId",
                table: "RawStockReceiptLines",
                column: "BuyerProcurementItemId",
                principalTable: "BuyerProcurementItems",
                principalColumn: "BuyerProcurementItemId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                """
                DELETE mapping
                FROM dbo.RolePermissions mapping
                JOIN dbo.Permissions permission
                  ON permission.PermissionId = mapping.PermissionId
                WHERE permission.PermissionCode IN
                (
                    'BuyingList.View',
                    'BuyingList.ViewAll',
                    'BuyingList.Create',
                    'BuyingList.UpdateDraft',
                    'BuyingList.DeleteDraft',
                    'BuyingList.Assign',
                    'BuyingList.Publish',
                    'BuyingList.Cancel',
                    'Mobile.BuyingList.ViewAll',
                    'Mobile.BuyingList.Create',
                    'Mobile.BuyingList.Assign',
                    'Mobile.Notification.View',
                    'Mobile.Profile.View',
                    'Mobile.Help.View'
                );

                DELETE FROM dbo.Permissions
                WHERE PermissionCode IN
                (
                    'BuyingList.View',
                    'BuyingList.ViewAll',
                    'BuyingList.Create',
                    'BuyingList.UpdateDraft',
                    'BuyingList.DeleteDraft',
                    'BuyingList.Assign',
                    'BuyingList.Publish',
                    'BuyingList.Cancel',
                    'Mobile.BuyingList.ViewAll',
                    'Mobile.BuyingList.Create',
                    'Mobile.BuyingList.Assign',
                    'Mobile.Notification.View',
                    'Mobile.Profile.View',
                    'Mobile.Help.View'
                );
                """);

            migrationBuilder.DropForeignKey(
                name: "FK_BuyerProcurementItems_RawStockItems_SubstituteRawStockItemId",
                table: "BuyerProcurementItems");

            migrationBuilder.DropForeignKey(
                name: "FK_BuyerProcurementItems_Suppliers_PreferredSupplierId",
                table: "BuyerProcurementItems");

            migrationBuilder.DropForeignKey(
                name: "FK_BuyerProcurements_Users_CancelledByUserId",
                table: "BuyerProcurements");

            migrationBuilder.DropForeignKey(
                name: "FK_BuyerProcurements_Users_CreatedByUserId",
                table: "BuyerProcurements");

            migrationBuilder.DropForeignKey(
                name: "FK_RawStockReceiptLines_BuyerProcurementItems_BuyerProcurementItemId",
                table: "RawStockReceiptLines");

            migrationBuilder.DropIndex(
                name: "IX_RawStockReceiptLines_BuyerProcurementItemId",
                table: "RawStockReceiptLines");

            migrationBuilder.DropIndex(
                name: "IX_BuyerProcurements_CancelledByUserId",
                table: "BuyerProcurements");

            migrationBuilder.DropIndex(
                name: "IX_BuyerProcurements_CreatedByUserId",
                table: "BuyerProcurements");

            migrationBuilder.DropIndex(
                name: "UX_BuyerProcurements_Reference",
                table: "BuyerProcurements");

            migrationBuilder.DropIndex(
                name: "IX_BuyerProcurementItems_BuyerProcurementId_RawStockItemId",
                table: "BuyerProcurementItems");

            migrationBuilder.DropIndex(
                name: "IX_BuyerProcurementItems_PreferredSupplierId",
                table: "BuyerProcurementItems");

            migrationBuilder.DropIndex(
                name: "IX_BuyerProcurementItems_SubstituteRawStockItemId",
                table: "BuyerProcurementItems");

            migrationBuilder.DropColumn(
                name: "BuyerProcurementItemId",
                table: "RawStockReceiptLines");

            migrationBuilder.DropColumn(
                name: "CancellationReason",
                table: "BuyerProcurements");

            migrationBuilder.DropColumn(
                name: "CancelledAtUtc",
                table: "BuyerProcurements");

            migrationBuilder.DropColumn(
                name: "CancelledByUserId",
                table: "BuyerProcurements");

            migrationBuilder.DropColumn(
                name: "CreatedByUserId",
                table: "BuyerProcurements");

            migrationBuilder.DropColumn(
                name: "Priority",
                table: "BuyerProcurements");

            migrationBuilder.DropColumn(
                name: "PublishedAtUtc",
                table: "BuyerProcurements");

            migrationBuilder.DropColumn(
                name: "ReferenceNumber",
                table: "BuyerProcurements");

            migrationBuilder.DropColumn(
                name: "Title",
                table: "BuyerProcurements");

            migrationBuilder.DropColumn(
                name: "UpdatedAtUtc",
                table: "BuyerProcurements");

            migrationBuilder.DropColumn(
                name: "BuyerNotes",
                table: "BuyerProcurementItems");

            migrationBuilder.DropColumn(
                name: "PreferredSupplierId",
                table: "BuyerProcurementItems");

            migrationBuilder.DropColumn(
                name: "Priority",
                table: "BuyerProcurementItems");

            migrationBuilder.DropColumn(
                name: "ReceivedQuantity",
                table: "BuyerProcurementItems");

            migrationBuilder.DropColumn(
                name: "RowVersion",
                table: "BuyerProcurementItems");

            migrationBuilder.DropColumn(
                name: "SubstituteNotes",
                table: "BuyerProcurementItems");

            migrationBuilder.DropColumn(
                name: "SubstituteRawStockItemId",
                table: "BuyerProcurementItems");

            migrationBuilder.RenameColumn(
                name: "ManagementNotes",
                table: "BuyerProcurementItems",
                newName: "Notes");

            migrationBuilder.AlterColumn<int>(
                name: "AssignedBuyerUserId",
                table: "BuyerProcurements",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }
    }
}
