﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhenyoSyncAPI.Migrations
{
    /// <inheritdoc />
    public partial class ProductPriceBasisForSellableUnits : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PriceBasis",
                table: "ProductPrices",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: false,
                defaultValue: "PerKilogram");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PriceBasis",
                table: "ProductPrices");
        }
    }
}
