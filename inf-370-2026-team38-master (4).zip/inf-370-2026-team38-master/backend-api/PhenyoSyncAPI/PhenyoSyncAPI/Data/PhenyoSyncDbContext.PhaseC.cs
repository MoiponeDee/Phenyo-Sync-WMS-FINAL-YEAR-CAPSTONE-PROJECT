using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Data;

/// <summary>Maps mobile operations, notifications, tracking, Buying Lists and write-offs.</summary>
public partial class PhenyoSyncDbContext
{
    public DbSet<MobileDeviceRegistration> MobileDeviceRegistrations { get; set; }
    public DbSet<OperationalNotification> OperationalNotifications { get; set; }
    public DbSet<OperationalNotificationRecipient> OperationalNotificationRecipients { get; set; }
    public DbSet<NotificationDeliveryAttempt> NotificationDeliveryAttempts { get; set; }
    public DbSet<NotificationPreference> NotificationPreferences { get; set; }
    public DbSet<MobileDeliveryEvent> MobileDeliveryEvents { get; set; }
    public DbSet<DriverTrackingSession> DriverTrackingSessions { get; set; }
    public DbSet<DriverLocationUpdate> DriverLocationUpdates { get; set; }
    public DbSet<DeliveryRouteCalculation> DeliveryRouteCalculations { get; set; }
    public DbSet<MobileIdempotencyRecord> MobileIdempotencyRecords { get; set; }
    public DbSet<BuyerProcurement> BuyerProcurements { get; set; }
    public DbSet<BuyerProcurementItem> BuyerProcurementItems { get; set; }
    public DbSet<StockReceipt> StockReceipts { get; set; }
    public DbSet<StockReceiptItem> StockReceiptItems { get; set; }
    public DbSet<PackingScan> PackingScans { get; set; }
    public DbSet<StockWriteOff> StockWriteOffs { get; set; }
    public DbSet<StockWriteOffEvidence> StockWriteOffEvidence { get; set; }

    private static void ConfigurePhaseC(ModelBuilder modelBuilder)
    {
        // Filtered/compound unique indexes turn mobile retry and active-session rules into
        // database guarantees, not timing-dependent checks in a handset or controller.
        modelBuilder.Entity<MobileDeviceRegistration>(entity =>
        {
            entity.ToTable("MobileDeviceRegistrations");
            entity.Property(item => item.RowVersion).IsRowVersion().IsConcurrencyToken();
            entity.HasIndex(item => new { item.UserId, item.DeviceIdentifierHash })
                .IsUnique()
                .HasDatabaseName("UX_MobileDeviceRegistrations_User_Device");
            entity.HasIndex(item => new { item.IsActive, item.LastSeenAtUtc });
            entity.HasOne(item => item.User).WithMany()
                .HasForeignKey(item => item.UserId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RevokedByUser).WithMany()
                .HasForeignKey(item => item.RevokedByUserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<OperationalNotification>(entity =>
        {
            entity.ToTable("OperationalNotifications");
            entity.HasIndex(item => new { item.CreatedAtUtc, item.NotificationType });
            entity.HasIndex(item => item.CorrelationId);
            entity.HasOne(item => item.CreatedByUser).WithMany()
                .HasForeignKey(item => item.CreatedByUserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<OperationalNotificationRecipient>(entity =>
        {
            entity.ToTable("OperationalNotificationRecipients");
            entity.Property(item => item.RowVersion).IsRowVersion().IsConcurrencyToken();
            entity.HasIndex(item => new { item.OperationalNotificationId, item.UserId })
                .IsUnique()
                .HasDatabaseName("UX_NotificationRecipients_Notification_User");
            entity.HasIndex(item => new
            {
                item.UserId,
                item.ReadAtUtc,
                item.DismissedAtUtc
            });
            entity.HasIndex(item => new
            {
                item.PushStatus,
                item.NextPushAttemptAtUtc
            });
            entity.HasOne(item => item.Notification).WithMany(item => item.Recipients)
                .HasForeignKey(item => item.OperationalNotificationId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.User).WithMany()
                .HasForeignKey(item => item.UserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<NotificationDeliveryAttempt>(entity =>
        {
            entity.ToTable("NotificationDeliveryAttempts");
            entity.HasIndex(item => new
            {
                item.OperationalNotificationRecipientId,
                item.AttemptNumber
            });
            entity.HasOne(item => item.Recipient).WithMany(item => item.DeliveryAttempts)
                .HasForeignKey(item => item.OperationalNotificationRecipientId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<NotificationPreference>(entity =>
        {
            entity.ToTable("NotificationPreferences");
            entity.Property(item => item.RowVersion).IsRowVersion().IsConcurrencyToken();
            entity.HasIndex(item => item.UserId).IsUnique();
            entity.HasOne(item => item.User).WithMany()
                .HasForeignKey(item => item.UserId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<MobileDeliveryEvent>(entity =>
        {
            entity.ToTable("MobileDeliveryEvents");
            entity.HasIndex(item => new { item.DeliveryId, item.RecordedAtUtc });
            entity.HasIndex(item => item.CorrelationId);
            entity.HasOne(item => item.Delivery).WithMany()
                .HasForeignKey(item => item.DeliveryId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RecordedByUser).WithMany()
                .HasForeignKey(item => item.RecordedByUserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<DriverTrackingSession>(entity =>
        {
            entity.ToTable("DriverTrackingSessions");
            entity.Property(item => item.RowVersion).IsRowVersion().IsConcurrencyToken();
            entity.HasIndex(item => new { item.DeliveryId, item.Status });
            entity.HasIndex(item => new { item.DriverId, item.Status });
            entity.HasIndex(item => item.CorrelationId);
            entity.HasIndex(item => item.DeliveryId)
                .IsUnique()
                .HasFilter("[Status] = 'Active'")
                .HasDatabaseName("UX_DriverTrackingSessions_ActiveDelivery");
            entity.HasOne(item => item.Delivery).WithMany()
                .HasForeignKey(item => item.DeliveryId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.Driver).WithMany()
                .HasForeignKey(item => item.DriverId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.StartedByUser).WithMany()
                .HasForeignKey(item => item.StartedByUserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<DriverLocationUpdate>(entity =>
        {
            entity.ToTable("DriverLocationUpdates");
            entity.Property(item => item.Latitude).HasPrecision(9, 6);
            entity.Property(item => item.Longitude).HasPrecision(9, 6);
            entity.Property(item => item.AccuracyMetres).HasPrecision(10, 2);
            entity.Property(item => item.SpeedMetresPerSecond).HasPrecision(10, 2);
            entity.Property(item => item.HeadingDegrees).HasPrecision(6, 2);
            entity.HasIndex(item => new
            {
                item.DriverTrackingSessionId,
                item.CapturedAtUtc
            });
            entity.HasIndex(item => new
            {
                item.DriverTrackingSessionId,
                item.OperationKeyHash
            })
                .IsUnique()
                .HasDatabaseName("UX_DriverLocationUpdates_Session_Operation");
            entity.HasOne(item => item.TrackingSession).WithMany(item => item.Locations)
                .HasForeignKey(item => item.DriverTrackingSessionId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<DeliveryRouteCalculation>(entity =>
        {
            entity.ToTable("DeliveryRouteCalculations");
            entity.Property(item => item.OriginLatitude).HasPrecision(9, 6);
            entity.Property(item => item.OriginLongitude).HasPrecision(9, 6);
            entity.Property(item => item.DestinationLatitude).HasPrecision(9, 6);
            entity.Property(item => item.DestinationLongitude).HasPrecision(9, 6);
            entity.HasIndex(item => new
            {
                item.DeliveryId,
                item.CalculatedAtUtc
            });
            entity.HasIndex(item => new
            {
                item.DeliveryId,
                item.RequestFingerprint
            });
            entity.HasOne(item => item.Delivery).WithMany()
                .HasForeignKey(item => item.DeliveryId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<MobileIdempotencyRecord>(entity =>
        {
            entity.ToTable("MobileIdempotencyRecords");
            entity.HasIndex(item => new
            {
                item.UserId,
                item.OperationType,
                item.OperationKeyHash
            })
                .IsUnique()
                .HasDatabaseName("UX_MobileIdempotency_User_Operation_Key");
            entity.HasIndex(item => item.ExpiresAtUtc);
            entity.HasOne(item => item.User).WithMany()
                .HasForeignKey(item => item.UserId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<BuyerProcurement>(entity =>
        {
            entity.ToTable("BuyerProcurements");
            entity.Property(item => item.RowVersion).IsRowVersion().IsConcurrencyToken();
            entity.HasIndex(item => item.ReferenceNumber)
                .IsUnique()
                .HasDatabaseName("UX_BuyerProcurements_Reference");
            entity.HasIndex(item => new
            {
                item.AssignedBuyerUserId,
                item.BuyingDateUtc,
                item.Status
            });
            entity.HasIndex(item => item.CorrelationId);
            entity.HasOne(item => item.AssignedBuyerUser).WithMany()
                .HasForeignKey(item => item.AssignedBuyerUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.CreatedByUser).WithMany()
                .HasForeignKey(item => item.CreatedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.CancelledByUser).WithMany()
                .HasForeignKey(item => item.CancelledByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.DocketStoredFile).WithMany()
                .HasForeignKey(item => item.DocketStoredFileId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<BuyerProcurementItem>(entity =>
        {
            entity.ToTable("BuyerProcurementItems");
            entity.Property(item => item.RecommendedQuantity).HasPrecision(18, 2);
            entity.Property(item => item.RequiredQuantity).HasPrecision(18, 2);
            entity.Property(item => item.ActualQuantity).HasPrecision(18, 2);
            entity.Property(item => item.ActualUnitPrice).HasPrecision(18, 2);
            entity.Property(item => item.ReceivedQuantity).HasPrecision(18, 2);
            entity.Property(item => item.RowVersion).IsRowVersion().IsConcurrencyToken();
            entity.HasIndex(item => new { item.BuyerProcurementId, item.ProductId });
            entity.HasIndex(item => new
                {
                    item.BuyerProcurementId,
                    item.RawStockItemId
                });
            entity.HasOne(item => item.BuyerProcurement).WithMany(item => item.Items)
                .HasForeignKey(item => item.BuyerProcurementId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.Product).WithMany()
                .HasForeignKey(item => item.ProductId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockItem).WithMany()
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.Supplier).WithMany()
                .HasForeignKey(item => item.SupplierId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.PreferredSupplier).WithMany()
                .HasForeignKey(item => item.PreferredSupplierId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.SubstituteRawStockItem).WithMany()
                .HasForeignKey(item => item.SubstituteRawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<StockReceipt>(entity =>
        {
            entity.ToTable("StockReceipts");
            entity.Property(item => item.RowVersion).IsRowVersion().IsConcurrencyToken();
            entity.HasIndex(item => item.ReceiptNumber).IsUnique();
            entity.HasIndex(item => new { item.Status, item.PurchaseDateUtc });
            entity.HasIndex(item => item.CorrelationId);
            entity.HasOne(item => item.Supplier).WithMany()
                .HasForeignKey(item => item.SupplierId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.SupplierOrder).WithMany()
                .HasForeignKey(item => item.SupplierOrderId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.WarehouseSection).WithMany()
                .HasForeignKey(item => item.WarehouseSectionId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ReceivedByUser).WithMany()
                .HasForeignKey(item => item.ReceivedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.DocketStoredFile).WithMany()
                .HasForeignKey(item => item.DocketStoredFileId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<StockReceiptItem>(entity =>
        {
            entity.ToTable("StockReceiptItems");
            entity.Property(item => item.QuantityReceivedKg).HasPrecision(18, 2);
            entity.Property(item => item.AcceptedQuantityKg).HasPrecision(18, 2);
            entity.Property(item => item.RejectedQuantityKg).HasPrecision(18, 2);
            entity.Property(item => item.UnitCost).HasPrecision(18, 2);
            entity.HasIndex(item => new { item.StockReceiptId, item.ProductId });
            entity.HasOne(item => item.StockReceipt).WithMany(item => item.Items)
                .HasForeignKey(item => item.StockReceiptId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.Product).WithMany()
                .HasForeignKey(item => item.ProductId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ProductBatch).WithMany()
                .HasForeignKey(item => item.ProductBatchId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<PackingScan>(entity =>
        {
            entity.ToTable("PackingScans");
            entity.Property(item => item.QuantityPackedKg).HasPrecision(18, 2);
            entity.HasIndex(item => new { item.SalesOrderId, item.ScannedAtUtc });
            entity.HasIndex(item => new
            {
                item.ScannedByUserId,
                item.OperationKeyHash
            })
                .IsUnique()
                .HasDatabaseName("UX_PackingScans_User_Operation");
            entity.HasOne(item => item.SalesOrder).WithMany(item => item.PackingScans)
                .HasForeignKey(item => item.SalesOrderId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.SalesOrderItem).WithMany()
                .HasForeignKey(item => item.SalesOrderItemId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.Reservation).WithMany()
                .HasForeignKey(item => item.OrderStockReservationId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ProductBatch).WithMany()
                .HasForeignKey(item => item.ProductBatchId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ScannedByUser).WithMany()
                .HasForeignKey(item => item.ScannedByUserId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RemovedByUser).WithMany()
                .HasForeignKey(item => item.RemovedByUserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<StockWriteOff>(entity =>
        {
            entity.ToTable("StockWriteOffs");
            entity.Property(item => item.QuantityKg).HasPrecision(18, 2);
            entity.Property(item => item.EstimatedUnitCost).HasPrecision(18, 2);
            entity.Property(item => item.EstimatedTotalLoss).HasPrecision(18, 2);
            entity.Property(item => item.RowVersion).IsRowVersion().IsConcurrencyToken();
            entity.HasIndex(item => new { item.Status, item.SubmittedAtUtc });
            entity.HasIndex(item => new
                {
                    item.CompletedAtUtc,
                    item.Status
                })
                .HasDatabaseName(
                    "IX_StockWriteOffs_ReportCompletedStatus");
            entity.HasIndex(item => new { item.ProductBatchId, item.Status });
            entity.HasIndex(item => item.CorrelationId);
            entity.HasOne(item => item.ProductBatch).WithMany()
                .HasForeignKey(item => item.ProductBatchId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.WarehouseSection).WithMany()
                .HasForeignKey(item => item.SectionId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.SubmittedByUser).WithMany()
                .HasForeignKey(item => item.SubmittedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.DecidedByUser).WithMany()
                .HasForeignKey(item => item.DecidedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<StockWriteOffEvidence>(entity =>
        {
            entity.ToTable("StockWriteOffEvidence");
            entity.HasIndex(item => new { item.StockWriteOffId, item.UploadedAtUtc });
            entity.HasOne(item => item.StockWriteOff).WithMany(item => item.Evidence)
                .HasForeignKey(item => item.StockWriteOffId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.StoredFile).WithMany()
                .HasForeignKey(item => item.StoredFileId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.UploadedByUser).WithMany()
                .HasForeignKey(item => item.UploadedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
