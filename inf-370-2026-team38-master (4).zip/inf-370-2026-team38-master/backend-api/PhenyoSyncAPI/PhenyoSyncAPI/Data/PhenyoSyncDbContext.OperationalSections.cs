using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Data;

/// <summary>Contains raw-stock, procurement, party and payment relationship mappings.</summary>
public partial class PhenyoSyncDbContext
{
    public DbSet<RawStockItem> RawStockItems { get; set; }
    public DbSet<RawStockBalance> RawStockBalances { get; set; }
    public DbSet<RawStockBatch> RawStockBatches { get; set; }
    public DbSet<RawStockMovement> RawStockMovements { get; set; }
    public DbSet<OperationalReason> OperationalReasons { get; set; }
    public DbSet<RawStockReceipt> RawStockReceipts { get; set; }
    public DbSet<RawStockReceiptLine> RawStockReceiptLines { get; set; }
    public DbSet<RawStockReconciliationGroup> RawStockReconciliationGroups { get; set; }
    public DbSet<RawStockReconciliationGroupItem> RawStockReconciliationGroupItems { get; set; }
    public DbSet<ProductReconciliationMapping> ProductReconciliationMappings { get; set; }
    public DbSet<RawStockTakeSession> RawStockTakeSessions { get; set; }
    public DbSet<RawStockTakeLine> RawStockTakeLines { get; set; }
    public DbSet<RawStockWriteOff> RawStockWriteOffs { get; set; }
    public DbSet<RawStockWriteOffEvidence> RawStockWriteOffEvidence { get; set; }
    public DbSet<SupplierOrderLine> SupplierOrderLines { get; set; }
    public DbSet<FinancialPayment> FinancialPayments { get; set; }
    public DbSet<ProductRawStockRequirement> ProductRawStockRequirements
        { get; set; }

    private static void ConfigureOperationalSections(ModelBuilder modelBuilder)
    {
        ConfigureRawStock(modelBuilder);
        ConfigureRawStockOperations(modelBuilder);
        ConfigurePartiesAndPayments(modelBuilder);
    }

    private static void ConfigureRawStock(ModelBuilder modelBuilder)
    {
        // A balance is unique per item, warehouse section and unit; batches retain traceability
        // beneath that balance and never cascade-delete historical movement rows.
        modelBuilder.Entity<RawStockItem>(entity =>
        {
            entity.ToTable("RawStockItems");
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.ItemCode)
                .IsUnique()
                .HasDatabaseName("UX_RawStockItems_Code");
            entity.HasIndex(item => item.ItemName)
                .IsUnique()
                .HasDatabaseName("UX_RawStockItems_Name");
            entity.HasIndex(item => new { item.CategoryCode, item.IsActive });
        });

        modelBuilder.Entity<RawStockBalance>(entity =>
        {
            entity.ToTable("RawStockBalances");
            entity.Property(item => item.QuantityOnHand).HasPrecision(18, 3);
            entity.Property(item => item.ReservedQuantity).HasPrecision(18, 3);
            entity.Property(item => item.WeightedAverageUnitCost)
                .HasPrecision(18, 4);
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => new
                {
                    item.RawStockItemId,
                    item.WarehouseSectionId,
                    item.UnitOfMeasure
                })
                .IsUnique()
                .HasDatabaseName("UX_RawStockBalances_Item_Section_Unit");
            entity.HasOne(item => item.RawStockItem)
                .WithMany(item => item.Balances)
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.WarehouseSection)
                .WithMany()
                .HasForeignKey(item => item.WarehouseSectionId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RawStockBatch>(entity =>
        {
            entity.ToTable("RawStockBatches");
            entity.Property(item => item.QuantityReceived).HasPrecision(18, 3);
            entity.Property(item => item.QuantityRemaining).HasPrecision(18, 3);
            entity.Property(item => item.UnitCost).HasPrecision(18, 4);
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.BatchCode)
                .IsUnique()
                .HasDatabaseName("UX_RawStockBatches_BatchCode");
            entity.HasIndex(item => item.QrCodeValue)
                .IsUnique()
                .HasDatabaseName("UX_RawStockBatches_Qr");
            entity.HasIndex(item => new
                {
                    item.RawStockItemId,
                    item.Status,
                    item.BestBeforeAtUtc
                });
            entity.HasOne(item => item.RawStockItem)
                .WithMany(item => item.Batches)
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockBalance)
                .WithMany(item => item.Batches)
                .HasForeignKey(item => item.RawStockBalanceId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.Supplier)
                .WithMany()
                .HasForeignKey(item => item.SupplierId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ReceiptLine)
                .WithOne(item => item.Batch)
                .HasForeignKey<RawStockBatch>(item => item.RawStockReceiptLineId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<OperationalReason>(entity =>
        {
            entity.ToTable("OperationalReasons");
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.ReasonCode)
                .IsUnique()
                .HasDatabaseName("UX_OperationalReasons_Code");
            entity.HasIndex(item => new
                {
                    item.CategoryCode,
                    item.IsActive,
                    item.ReasonName
                });
        });

        modelBuilder.Entity<RawStockMovement>(entity =>
        {
            entity.ToTable("RawStockMovements");
            entity.Property(item => item.QuantityChange).HasPrecision(18, 3);
            entity.Property(item => item.UnitCost).HasPrecision(18, 4);
            entity.HasIndex(item => new
                {
                    item.RawStockItemId,
                    item.OccurredAtUtc
                });
            entity.HasIndex(item => new
                {
                    item.OccurredAtUtc,
                    item.MovementType,
                    item.RawStockItemId
                })
                .HasDatabaseName(
                    "IX_RawStockMovements_ReportDateTypeItem");
            entity.HasIndex(item => item.CorrelationId);
            entity.HasIndex(item => new { item.SourceType, item.SourceId });
            entity.HasOne(item => item.RawStockItem)
                .WithMany(item => item.Movements)
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockBalance)
                .WithMany()
                .HasForeignKey(item => item.RawStockBalanceId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockBatch)
                .WithMany()
                .HasForeignKey(item => item.RawStockBatchId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.OperationalReason)
                .WithMany()
                .HasForeignKey(item => item.OperationalReasonId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.CreatedByUser)
                .WithMany()
                .HasForeignKey(item => item.CreatedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }

    private static void ConfigureRawStockOperations(ModelBuilder modelBuilder)
    {
        // Operation-key uniqueness makes receipt retries idempotent at the database boundary.
        modelBuilder.Entity<RawStockReceipt>(entity =>
        {
            entity.ToTable("RawStockReceipts");
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.ReceiptNumber)
                .IsUnique()
                .HasDatabaseName("UX_RawStockReceipts_Number");
            entity.HasIndex(item => item.OperationKeyHash)
                .IsUnique()
                .HasDatabaseName("UX_RawStockReceipts_Operation");
            entity.HasIndex(item => item.CorrelationId);
            entity.HasIndex(item => new { item.Status, item.ReceivedAtUtc });
            entity.HasOne(item => item.Supplier)
                .WithMany()
                .HasForeignKey(item => item.SupplierId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.SupplierOrder)
                .WithMany()
                .HasForeignKey(item => item.SupplierOrderId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.BuyerProcurement)
                .WithMany(item => item.RawStockReceipts)
                .HasForeignKey(item => item.BuyerProcurementId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.WarehouseSection)
                .WithMany()
                .HasForeignKey(item => item.WarehouseSectionId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ReceivedByUser)
                .WithMany()
                .HasForeignKey(item => item.ReceivedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RawStockReceiptLine>(entity =>
        {
            entity.ToTable("RawStockReceiptLines");
            entity.Property(item => item.QuantityReceived).HasPrecision(18, 3);
            entity.Property(item => item.AcceptedQuantity).HasPrecision(18, 3);
            entity.Property(item => item.RejectedQuantity).HasPrecision(18, 3);
            entity.Property(item => item.UnitCost).HasPrecision(18, 4);
            entity.HasIndex(item => new
                {
                    item.RawStockReceiptId,
                    item.RawStockItemId
                });
            entity.HasOne(item => item.Receipt)
                .WithMany(item => item.Lines)
                .HasForeignKey(item => item.RawStockReceiptId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.RawStockItem)
                .WithMany()
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.SupplierOrderLine)
                .WithMany(item => item.ReceiptLines)
                .HasForeignKey(item => item.SupplierOrderLineId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.BuyerProcurementItem)
                .WithMany()
                .HasForeignKey(item => item.BuyerProcurementItemId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RawStockReconciliationGroup>(entity =>
        {
            entity.ToTable("RawStockReconciliationGroups");
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.GroupCode)
                .IsUnique()
                .HasDatabaseName("UX_RawStockReconciliationGroups_Code");
        });

        modelBuilder.Entity<RawStockReconciliationGroupItem>(entity =>
        {
            entity.ToTable("RawStockReconciliationGroupItems");
            entity.HasIndex(item => item.RawStockItemId)
                .IsUnique()
                .HasDatabaseName("UX_ReconciliationGroupItems_RawStock");
            entity.HasOne(item => item.Group)
                .WithMany(item => item.RawStockItems)
                .HasForeignKey(item => item.RawStockReconciliationGroupId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.RawStockItem)
                .WithMany()
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ProductReconciliationMapping>(entity =>
        {
            entity.ToTable("ProductReconciliationMappings");
            entity.HasIndex(item => item.ProductId)
                .IsUnique()
                .HasDatabaseName("UX_ProductReconciliationMappings_Product");
            entity.HasOne(item => item.Group)
                .WithMany(item => item.Products)
                .HasForeignKey(item => item.RawStockReconciliationGroupId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.Product)
                .WithMany()
                .HasForeignKey(item => item.ProductId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RawStockTakeSession>(entity =>
        {
            entity.ToTable("RawStockTakeSessions");
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.CorrelationId)
                .IsUnique()
                .HasDatabaseName("UX_RawStockTakeSessions_Correlation");
            entity.HasIndex(item => new
                {
                    item.WarehouseSectionId,
                    item.Status,
                    item.CreatedAtUtc
                });
            entity.HasOne(item => item.WarehouseSection)
                .WithMany()
                .HasForeignKey(item => item.WarehouseSectionId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.CreatedByUser)
                .WithMany()
                .HasForeignKey(item => item.CreatedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ReviewedByUser)
                .WithMany()
                .HasForeignKey(item => item.ReviewedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.DecidedByUser)
                .WithMany()
                .HasForeignKey(item => item.DecidedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RawStockTakeLine>(entity =>
        {
            entity.ToTable("RawStockTakeLines");
            foreach (var propertyName in new[]
                     {
                         nameof(RawStockTakeLine.OpeningRawStock),
                         nameof(RawStockTakeLine.RawStockReceived),
                         nameof(RawStockTakeLine.ApprovedPositiveAdjustments),
                         nameof(RawStockTakeLine.ExistingPackedProductWeight),
                         nameof(RawStockTakeLine.RecordedRawStockWriteOffs),
                         nameof(RawStockTakeLine.ApprovedNegativeAdjustments),
                         nameof(RawStockTakeLine.EstimatedRawStockRemaining),
                         nameof(RawStockTakeLine.PhysicalStockCount),
                         nameof(RawStockTakeLine.UnexplainedStockDifference),
                         nameof(RawStockTakeLine.EstimatedFinancialImpact)
                     })
            {
                entity.Property(propertyName).HasPrecision(18, 3);
            }
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => new
                {
                    item.RawStockTakeSessionId,
                    item.RawStockBalanceId
                })
                .IsUnique()
                .HasDatabaseName("UX_RawStockTakeLines_Session_Balance");
            entity.HasOne(item => item.Session)
                .WithMany(item => item.Lines)
                .HasForeignKey(item => item.RawStockTakeSessionId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.RawStockItem)
                .WithMany()
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockBalance)
                .WithMany()
                .HasForeignKey(item => item.RawStockBalanceId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ReconciliationGroup)
                .WithMany()
                .HasForeignKey(item => item.RawStockReconciliationGroupId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RawStockWriteOff>(entity =>
        {
            entity.ToTable("RawStockWriteOffs");
            entity.Property(item => item.Quantity).HasPrecision(18, 3);
            entity.Property(item => item.EstimatedUnitCost).HasPrecision(18, 4);
            entity.Property(item => item.EstimatedTotalLoss).HasPrecision(18, 2);
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => new { item.Status, item.SubmittedAtUtc });
            entity.HasIndex(item => item.CorrelationId);
            entity.HasOne(item => item.RawStockItem)
                .WithMany()
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockBalance)
                .WithMany()
                .HasForeignKey(item => item.RawStockBalanceId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockBatch)
                .WithMany()
                .HasForeignKey(item => item.RawStockBatchId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.OperationalReason)
                .WithMany()
                .HasForeignKey(item => item.OperationalReasonId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.SubmittedByUser)
                .WithMany()
                .HasForeignKey(item => item.SubmittedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.DecidedByUser)
                .WithMany()
                .HasForeignKey(item => item.DecidedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RawStockWriteOffEvidence>(entity =>
        {
            entity.ToTable("RawStockWriteOffEvidence");
            entity.HasOne(item => item.RawStockWriteOff)
                .WithMany(item => item.Evidence)
                .HasForeignKey(item => item.RawStockWriteOffId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.StoredFile)
                .WithMany()
                .HasForeignKey(item => item.StoredFileId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.UploadedByUser)
                .WithMany()
                .HasForeignKey(item => item.UploadedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }

    private static void ConfigurePartiesAndPayments(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Customer>(entity =>
        {
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.NormalizedEmail)
                .IsUnique()
                .HasDatabaseName("UX_Customers_NormalizedEmail");
        });

        modelBuilder.Entity<Supplier>(entity =>
        {
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.SupplierCode)
                .IsUnique()
                .HasDatabaseName("UX_Suppliers_Code");
            entity.HasIndex(item => item.NormalizedEmail)
                .HasDatabaseName("IX_Suppliers_NormalizedEmail");
            entity.HasIndex(item => new { item.SupplierTypeCode, item.Status });
        });

        modelBuilder.Entity<SupplierOrder>(entity =>
        {
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.OrderNumber)
                .IsUnique()
                .HasDatabaseName("UX_SupplierOrders_Number");
            entity.HasIndex(item => new { item.Status, item.OrderDate });
            entity.HasOne(item => item.WarehouseSection)
                .WithMany()
                .HasForeignKey(item => item.WarehouseSectionId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.CreatedByUser)
                .WithMany()
                .HasForeignKey(item => item.CreatedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ApprovedByUser)
                .WithMany()
                .HasForeignKey(item => item.ApprovedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<SupplierOrderLine>(entity =>
        {
            entity.ToTable("SupplierOrderLines");
            entity.Property(item => item.OrderedQuantity).HasPrecision(18, 3);
            entity.Property(item => item.ReceivedQuantity).HasPrecision(18, 3);
            entity.Property(item => item.ExpectedUnitPrice).HasPrecision(18, 4);
            entity.HasIndex(item => new
                {
                    item.SupplierOrderId,
                    item.RawStockItemId
                })
                .IsUnique()
                .HasDatabaseName("UX_SupplierOrderLines_Order_Item");
            entity.HasOne(item => item.SupplierOrder)
                .WithMany(item => item.Lines)
                .HasForeignKey(item => item.SupplierOrderId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.RawStockItem)
                .WithMany()
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ProductRawStockRequirement>(entity =>
        {
            entity.ToTable("ProductRawStockRequirements");
            entity.Property(item => item.RawQuantityPerProductUnit)
                .HasPrecision(18, 4);
            entity.Property(item => item.WastePercentage)
                .HasPrecision(8, 4);
            entity.Property(item => item.YieldPercentage)
                .HasPrecision(8, 4);
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => new
                {
                    item.ProductId,
                    item.RawStockItemId
                })
                .IsUnique()
                .HasDatabaseName("UX_ProductRawStockRequirements_Product_RawStock");
            entity.HasIndex(item => new { item.RawStockItemId, item.IsActive });
            entity.HasOne(item => item.Product)
                .WithMany(item => item.RawStockRequirements)
                .HasForeignKey(item => item.ProductId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockItem)
                .WithMany(item => item.ProductRequirements)
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.CreatedByUser)
                .WithMany()
                .HasForeignKey(item => item.CreatedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.UpdatedByUser)
                .WithMany()
                .HasForeignKey(item => item.UpdatedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<FinancialPayment>(entity =>
        {
            entity.ToTable("FinancialPayments");
            entity.Property(item => item.Amount).HasPrecision(18, 2);
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.PaymentNumber)
                .IsUnique()
                .HasDatabaseName("UX_FinancialPayments_Number");
            entity.HasIndex(item => new
                {
                    item.CounterpartyType,
                    item.Status,
                    item.PaymentDateUtc
                });
            entity.HasIndex(item => new
                {
                    item.PaymentDateUtc,
                    item.CounterpartyType,
                    item.Status
                })
                .HasDatabaseName(
                    "IX_FinancialPayments_ReportDateCounterpartyStatus");
            entity.HasIndex(item => item.CorrelationId);
            entity.HasOne(item => item.Customer)
                .WithMany(item => item.Payments)
                .HasForeignKey(item => item.CustomerId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.Supplier)
                .WithMany(item => item.Payments)
                .HasForeignKey(item => item.SupplierId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.Invoice)
                .WithMany()
                .HasForeignKey(item => item.InvoiceId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.SupplierOrder)
                .WithMany(item => item.Payments)
                .HasForeignKey(item => item.SupplierOrderId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.OriginalPayment)
                .WithMany(item => item.Adjustments)
                .HasForeignKey(item => item.OriginalPaymentId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.CreatedByUser)
                .WithMany()
                .HasForeignKey(item => item.CreatedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.PostedByUser)
                .WithMany()
                .HasForeignKey(item => item.PostedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.DecidedByUser)
                .WithMany()
                .HasForeignKey(item => item.DecidedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
