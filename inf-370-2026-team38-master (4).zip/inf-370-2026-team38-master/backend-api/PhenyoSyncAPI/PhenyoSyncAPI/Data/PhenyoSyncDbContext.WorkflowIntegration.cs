using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Data;

/// <summary>Maps external intake idempotency and raw-to-finished packing conversion traceability.</summary>
public partial class PhenyoSyncDbContext
{
    public DbSet<ExternalOrderSubmission> ExternalOrderSubmissions { get; set; }
    public DbSet<PackingConversion> PackingConversions { get; set; }
    public DbSet<PackingConversionRawStock> PackingConversionRawStock { get; set; }

    private static void ConfigureWorkflowIntegration(ModelBuilder modelBuilder)
    {
        // Source plus external key is unique so re-reading the same form row cannot duplicate an order.
        modelBuilder.Entity<ExternalOrderSubmission>(entity =>
        {
            entity.ToTable("ExternalOrderSubmissions");
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => new { item.Source, item.ExternalSourceKey })
                .IsUnique()
                .HasDatabaseName("UX_ExternalOrderSubmissions_Source_Key");
            entity.HasIndex(item => new { item.Status, item.ImportedAtUtc });
            entity.HasIndex(item => item.CorrelationId);
            entity.HasOne(item => item.SalesOrder)
                .WithMany()
                .HasForeignKey(item => item.SalesOrderId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ImportedByUser)
                .WithMany()
                .HasForeignKey(item => item.ImportedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // One conversion per finished batch links production output back to each consumed raw batch.
        modelBuilder.Entity<PackingConversion>(entity =>
        {
            entity.ToTable("PackingConversions");
            entity.Property(item => item.QuantityProduced).HasPrecision(18, 3);
            entity.Property(item => item.RowVersion)
                .IsRowVersion()
                .IsConcurrencyToken();
            entity.HasIndex(item => item.ProductBatchId)
                .IsUnique()
                .HasDatabaseName("UX_PackingConversions_ProductBatch");
            entity.HasIndex(item => item.CorrelationId);
            entity.HasIndex(item => new
            {
                item.ProductId,
                item.PackedAtUtc
            });
            entity.HasOne(item => item.Product)
                .WithMany()
                .HasForeignKey(item => item.ProductId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.ProductBatch)
                .WithMany()
                .HasForeignKey(item => item.ProductBatchId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.WarehouseSection)
                .WithMany()
                .HasForeignKey(item => item.WarehouseSectionId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.PackedByUser)
                .WithMany()
                .HasForeignKey(item => item.PackedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<PackingConversionRawStock>(entity =>
        {
            entity.ToTable("PackingConversionRawStock");
            entity.Property(item => item.QuantityConsumed).HasPrecision(18, 3);
            entity.Property(item => item.BalanceBefore).HasPrecision(18, 3);
            entity.Property(item => item.BalanceAfter).HasPrecision(18, 3);
            entity.Property(item => item.BatchBefore).HasPrecision(18, 3);
            entity.Property(item => item.BatchAfter).HasPrecision(18, 3);
            entity.Property(item => item.UnitCost).HasPrecision(18, 4);
            entity.HasIndex(item => new
            {
                item.PackingConversionId,
                item.RawStockItemId
            });
            entity.HasIndex(item => item.RawStockBatchId);
            entity.HasOne(item => item.PackingConversion)
                .WithMany(item => item.RawStockLines)
                .HasForeignKey(item => item.PackingConversionId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockItem)
                .WithMany()
                .HasForeignKey(item => item.RawStockItemId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockBalance)
                .WithMany()
                .HasForeignKey(item => item.RawStockBalanceId)
                .OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(item => item.RawStockBatch)
                .WithMany()
                .HasForeignKey(item => item.RawStockBatchId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
