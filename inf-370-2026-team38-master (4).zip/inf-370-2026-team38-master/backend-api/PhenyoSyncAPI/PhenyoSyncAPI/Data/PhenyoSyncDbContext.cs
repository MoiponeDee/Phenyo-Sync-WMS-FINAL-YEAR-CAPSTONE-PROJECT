using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Data
{
   /// <summary>
   /// Defines PhenyoSync's EF Core unit of work and central relational model.
   /// Domain-specific mappings are split into partial files to keep this model reviewable.
   /// </summary>
   public partial class PhenyoSyncDbContext : DbContext
    {
        private readonly IAuditContextAccessor? _auditContextAccessor;
        private readonly string _fallbackAuditCorrelationId = Guid.NewGuid().ToString("N");
        private bool _savingAuditLogs;

        public PhenyoSyncDbContext(
            DbContextOptions<PhenyoSyncDbContext> options,
            IAuditContextAccessor? auditContextAccessor = null) : base(options)
        {
            _auditContextAccessor = auditContextAccessor;
        }
        public DbSet<Driver> Drivers { get; set; }

        public DbSet<Packer> Packers { get; set; }

        public DbSet<Stocktaker> StockTakers { get; set; }

        public DbSet<Businessmanager> BusinessManagers { get; set; }

        public DbSet<CEO> CEOs { get; set; }

        public DbSet<COO> COOs { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Permission> Permissions { get; set; }
        public DbSet<RolePermission> RolePermissions { get; set; }
        public DbSet<WarehouseSection> WarehouseSections { get; set; }
        public DbSet<Stock> Stocks { get; set; }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<SupplierOrder> SupplierOrders { get; set; }
        public DbSet<StockTakeSession> StockTakeSessions { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductType> ProductTypes { get; set; }
        public DbSet<ProductCategory> ProductCategories { get; set; }
        public DbSet<ProductBatch> ProductBatches { get; set; }
        public DbSet<StockMovement> StockMovements { get; set; }
        public DbSet<ExpiryActionToken> ExpiryActionTokens { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<SalesOrder> SalesOrders { get; set; }
        public DbSet<SalesOrderItem> SalesOrderItems { get; set; }
        public DbSet<CustomerOrderLink> CustomerOrderLinks { get; set; }
        public DbSet<OrderStatusHistory> OrderStatusHistory { get; set; }
        public DbSet<OrderStockReservation> OrderStockReservations { get; set; }
        public DbSet<Invoice> Invoices { get; set; }
        public DbSet<ProductPrice> ProductPrices { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }
        public DbSet<Delivery> Deliveries { get; set; }
        public DbSet<DeliveryDriverAssignment> DeliveryDriverAssignments { get; set; }
        public DbSet<DeliveryStatusHistory> DeliveryStatusHistory { get; set; }
        public DbSet<DeliveryCompletionRecord> DeliveryCompletionRecords { get; set; }
        public DbSet<LookupType> LookupTypes { get; set; }
        public DbSet<LookupValue> LookupValues { get; set; }
        public DbSet<LookupValueHistory> LookupValueHistory { get; set; }
        public DbSet<SystemSetting> SystemSettings { get; set; }
        public DbSet<SystemSettingHistory> SystemSettingHistory { get; set; }
        public DbSet<UserOtpChallenge> UserOtpChallenges { get; set; }
        public DbSet<TrustedDevice> TrustedDevices { get; set; }
        public DbSet<UserRecoveryCode> UserRecoveryCodes { get; set; }
        public DbSet<StoredFile> StoredFiles { get; set; }
        public DbSet<DeliveryProofImage> DeliveryProofImages { get; set; }
        public DbSet<HelpCategory> HelpCategories { get; set; }
        public DbSet<HelpTopic> HelpTopics { get; set; }
        public DbSet<HelpContextMapping> HelpContextMappings { get; set; }
        public DbSet<HelpMedia> HelpMedia { get; set; }
        public DbSet<ProductCategoryType> ProductCategoryTypes { get; set; }
        public DbSet<DataExchangeJob> DataExchangeJobs { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Identity codes and normalized email addresses are unique database invariants,
            // so concurrent requests cannot create duplicates even if UI validation races.
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("Users");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.NormalizedEmail)
                    .IsUnique()
                    .HasDatabaseName("UX_Users_NormalizedEmail");
                entity.HasIndex(item => new { item.Status, item.RoleId });
                entity.HasOne(item => item.Role)
                    .WithMany(role => role.Users)
                    .HasForeignKey(item => item.RoleId)
                    .OnDelete(DeleteBehavior.Restrict);
            });
            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("Roles");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.RoleCode)
                    .IsUnique()
                    .HasDatabaseName("UX_Roles_RoleCode");
                entity.HasIndex(item => item.RoleName)
                    .IsUnique()
                    .HasDatabaseName("UX_Roles_RoleName");
            });
            modelBuilder.Entity<Permission>(entity =>
            {
                entity.ToTable("Permissions");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.PermissionCode)
                    .IsUnique()
                    .HasDatabaseName("UX_Permissions_PermissionCode");
                entity.HasIndex(item => new { item.Module, item.IsActive });
            });
            modelBuilder.Entity<RolePermission>(entity =>
            {
                entity.ToTable("RolePermissions");
                entity.HasKey(item => new
                {
                    item.RoleId,
                    item.PermissionId
                });
                entity.HasOne(item => item.Role)
                    .WithMany(role => role.RolePermissions)
                    .HasForeignKey(item => item.RoleId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.Permission)
                    .WithMany(permission => permission.RolePermissions)
                    .HasForeignKey(item => item.PermissionId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.AssignedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.AssignedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });
            modelBuilder.Entity<WarehouseSection>(entity =>
            {
                entity.ToTable("WarehouseSections");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.SectionCode)
                    .IsUnique()
                    .HasDatabaseName("UX_WarehouseSections_SectionCode");
                entity.HasIndex(item => new { item.Status, item.SectionName });
            });
            modelBuilder.Entity<Driver>(entity =>
            {
                entity.ToTable("Drivers");
                entity.Property(item => item.AvailabilityStatus).HasMaxLength(100);
                entity.HasIndex(item => item.UserId)
                    .IsUnique()
                    .HasDatabaseName("UX_Drivers_UserId");
                entity.HasIndex(item => item.AvailabilityStatus);
                entity.HasOne(item => item.User)
                    .WithOne(user => user.Driver)
                    .HasForeignKey<Driver>(item => item.UserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });
            modelBuilder.Entity<AuditLog>(entity =>
            {
                entity.ToTable("AuditLogs");
                entity.HasKey(item => item.AuditLogId);
                entity.Property(item => item.OccurredAtUtc).HasPrecision(7);
                entity.HasIndex(item => item.OccurredAtUtc)
                    .IsDescending()
                    .HasDatabaseName("IX_AuditLogs_OccurredAtUtc");
                entity.HasIndex(item => new { item.UserId, item.OccurredAtUtc })
                    .IsDescending(false, true)
                    .HasDatabaseName("IX_AuditLogs_User_OccurredAtUtc");
                entity.HasIndex(item => new { item.ActionType, item.OccurredAtUtc })
                    .IsDescending(false, true)
                    .HasDatabaseName("IX_AuditLogs_Action_OccurredAtUtc");
                entity.HasIndex(item => new { item.SystemModule, item.OccurredAtUtc })
                    .IsDescending(false, true)
                    .HasDatabaseName("IX_AuditLogs_Module_OccurredAtUtc");
                entity.HasIndex(item => new { item.EntityType, item.EntityId })
                    .HasDatabaseName("IX_AuditLogs_Entity");
                entity.HasIndex(item => item.CorrelationId)
                    .HasDatabaseName("IX_AuditLogs_CorrelationId");
                entity.HasIndex(item => new { item.Success, item.OccurredAtUtc })
                    .IsDescending(false, true)
                    .HasDatabaseName("IX_AuditLogs_Success_OccurredAtUtc");
            });
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<SupplierOrder>(entity =>
            {
                entity.Property(item => item.TotalAmount)
                    .HasPrecision(18, 2);
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("Product");

                entity.HasKey(p => p.ProductId);
                entity.Property(p => p.SellingPricePerKg).HasPrecision(18, 2);
                entity.Property(p => p.KilogramsPerUnit).HasPrecision(18, 3);
                entity.Property(p => p.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();

                entity.HasOne(p => p.ProductType)
                    .WithMany(pt => pt.Products)
                    .HasForeignKey(p => p.ProductTypeId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(p => p.ProductCategory)
                    .WithMany(pc => pc.Products)
                    .HasForeignKey(p => p.ProductCategoryId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasIndex(p => new
                    {
                        p.ProductName,
                        p.ProductTypeId,
                        p.ProductCategoryId,
                        p.Size
                    })
                    .IsUnique()
                    .HasDatabaseName("UX_Product_CompositeSku");
            });

            modelBuilder.Entity<ProductType>(entity =>
            {
                entity.ToTable("ProductType");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.ProductTypeName)
                    .IsUnique()
                    .HasDatabaseName("UX_ProductType_Name");
            });

            modelBuilder.Entity<ProductCategory>(entity =>
            {
                entity.ToTable("ProductCategory");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.ProductCategoryName)
                    .IsUnique()
                    .HasDatabaseName("UX_ProductCategory_Name");
            });

            modelBuilder.Entity<ProductCategoryType>(entity =>
            {
                entity.ToTable("ProductCategoryTypes");
                entity.HasKey(item => item.ProductCategoryTypeId);
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => new
                    {
                        item.ProductCategoryId,
                        item.ProductTypeId
                    })
                    .IsUnique()
                    .HasDatabaseName("UX_ProductCategoryTypes_Category_Type");
                entity.HasOne(item => item.ProductCategory)
                    .WithMany(category => category.ProductCategoryTypes)
                    .HasForeignKey(item => item.ProductCategoryId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.ProductType)
                    .WithMany(type => type.ProductCategoryTypes)
                    .HasForeignKey(item => item.ProductTypeId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.CreatedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.CreatedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<Stock>(entity =>
            {
                entity.ToTable("Stocks");
                entity.Property(stock => stock.QuantityAvailableKg)
                    .HasPrecision(18, 2);
                entity.Property(stock => stock.ReorderLevelKg)
                    .HasPrecision(18, 2);
                entity.Property(stock => stock.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(stock => new { stock.ProductId, stock.SectionId })
                    .IsUnique()
                    .HasDatabaseName("UX_Stocks_Product_Section");
                entity.HasOne(stock => stock.Product)
                    .WithMany(product => product.Stocks)
                    .HasForeignKey(stock => stock.ProductId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(stock => stock.WarehouseSection)
                    .WithMany(section => section.Stocks)
                    .HasForeignKey(stock => stock.SectionId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<ProductBatch>(entity =>
            {
                entity.ToTable("ProductBatches");
                entity.Property(batch => batch.QuantityProducedKg)
                    .HasPrecision(18, 2);
                entity.Property(batch => batch.QuantityRemainingKg)
                    .HasPrecision(18, 2);
                entity.HasIndex(batch => batch.BatchCode).IsUnique();
                entity.HasIndex(batch => batch.QRCodeValue).IsUnique();
                entity.HasIndex(batch => new
                    {
                        batch.Status,
                        batch.EffectiveExpiryAtUtc,
                        batch.QuantityRemainingKg
                    });
                entity.HasIndex(batch => new { batch.ProductId, batch.SectionId });
                entity.HasOne(batch => batch.Product)
                    .WithMany(product => product.ProductBatches)
                    .HasForeignKey(batch => batch.ProductId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(batch => batch.WarehouseSection)
                    .WithMany(section => section.ProductBatches)
                    .HasForeignKey(batch => batch.SectionId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(batch => batch.ShelfLifeExtendedByUser)
                    .WithMany(user => user.ExtendedProductBatches)
                    .HasForeignKey(batch => batch.ShelfLifeExtendedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<StockMovement>(entity =>
            {
                entity.ToTable("StockMovements");
                entity.Property(movement => movement.QuantityKg)
                    .HasPrecision(18, 2);
                entity.HasIndex(movement => new
                    {
                        movement.ProductId,
                        movement.SectionId,
                        movement.OccurredAtUtc
                    });
                entity.HasIndex(movement => new
                    {
                        movement.OccurredAtUtc,
                        movement.MovementType,
                        movement.ProductId
                    })
                    .HasDatabaseName(
                        "IX_StockMovements_ReportDateTypeProduct");
                entity.HasOne(movement => movement.Product)
                    .WithMany(product => product.StockMovements)
                    .HasForeignKey(movement => movement.ProductId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(movement => movement.ProductBatch)
                    .WithMany(batch => batch.StockMovements)
                    .HasForeignKey(movement => movement.ProductBatchId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(movement => movement.WarehouseSection)
                    .WithMany(section => section.StockMovements)
                    .HasForeignKey(movement => movement.SectionId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(movement => movement.CreatedByUser)
                    .WithMany(user => user.CreatedStockMovements)
                    .HasForeignKey(movement => movement.CreatedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(movement => movement.SalesOrder)
                    .WithMany(order => order.StockMovements)
                    .HasForeignKey(movement => movement.SalesOrderId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(movement => movement.StockTakeSession)
                    .WithMany(session => session.StockMovements)
                    .HasForeignKey(movement => movement.StockTakeSessionId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<StockTakeSession>(entity =>
            {
                entity.HasIndex(item => item.CorrelationId)
                    .IsUnique()
                    .HasDatabaseName("UX_StockTakeSessions_CorrelationId");
                entity.HasOne(item => item.WarehouseSection)
                    .WithMany(section => section.StockTakeSessions)
                    .HasForeignKey(item => item.SectionId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<ExpiryActionToken>(entity =>
            {
                entity.ToTable("ExpiryActionTokens");
                entity.HasIndex(token => token.TokenHash).IsUnique();
                entity.HasIndex(token => new
                    {
                        token.ProductBatchId,
                        token.ExpiresAtUtc,
                        token.UsedAtUtc,
                        token.InvalidatedAtUtc
                    });
                entity.HasOne(token => token.ProductBatch)
                    .WithMany(batch => batch.ExpiryActionTokens)
                    .HasForeignKey(token => token.ProductBatchId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.ToTable("Customers");
                entity.HasIndex(customer => customer.CustomerNumber).IsUnique();
                entity.HasIndex(customer => customer.Email);
                entity.HasIndex(customer => new { customer.Status, customer.CustomerName });
            });

            // Orders retain price/address snapshots so later master-data changes do not rewrite history.
            modelBuilder.Entity<SalesOrder>(entity =>
            {
                entity.ToTable("SalesOrders");
                entity.Property(order => order.Subtotal).HasPrecision(18, 2);
                entity.Property(order => order.TaxRatePercent).HasPrecision(5, 2);
                entity.Property(order => order.TaxAmount).HasPrecision(18, 2);
                entity.Property(order => order.TotalAmount).HasPrecision(18, 2);
                entity.Property(order => order.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(order => order.OrderNumber).IsUnique();
                entity.HasIndex(order => order.CustomerId);
                entity.HasIndex(order => order.Status);
                entity.HasIndex(order => order.ValidationStatus);
                entity.HasIndex(order => order.OrderDateUtc);
                entity.HasIndex(order => new
                    {
                        order.OrderDateUtc,
                        order.CustomerId,
                        order.Status
                    })
                    .HasDatabaseName(
                        "IX_SalesOrders_ReportDateCustomerStatus");
                entity.HasIndex(order => order.PackingCompletionOperationKeyHash)
                    .IsUnique()
                    .HasFilter("[PackingCompletionOperationKeyHash] IS NOT NULL");
                entity.HasOne(order => order.Customer)
                    .WithMany(customer => customer.SalesOrders)
                    .HasForeignKey(order => order.CustomerId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(order => order.CreatedByUser)
                    .WithMany()
                    .HasForeignKey(order => order.CreatedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(order => order.ValidatedByUser)
                    .WithMany()
                    .HasForeignKey(order => order.ValidatedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(order => order.PackedByUser)
                    .WithMany()
                    .HasForeignKey(order => order.PackedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(order => order.CancelledByUser)
                    .WithMany()
                    .HasForeignKey(order => order.CancelledByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(order => order.CreatedViaOrderLink)
                    .WithMany()
                    .HasForeignKey(order => order.CreatedViaOrderLinkId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<SalesOrderItem>(entity =>
            {
                entity.ToTable("SalesOrderItems");
                entity.Property(item => item.QuantityKg).HasPrecision(18, 2);
                entity.Property(item => item.UnitPricePerKg).HasPrecision(18, 2);
                entity.Property(item => item.QuantityUnits).HasPrecision(18, 2);
                entity.Property(item => item.KilogramsPerUnitSnapshot).HasPrecision(18, 3);
                entity.Property(item => item.UnitPrice).HasPrecision(18, 2);
                entity.Property(item => item.LineTotal).HasPrecision(18, 2);
                entity.HasIndex(item => item.ProductId);
                entity.HasIndex(item => new { item.SalesOrderId, item.ProductId })
                    .IsUnique()
                    .HasFilter("[IsActive] = 1");
                entity.HasOne(item => item.SalesOrder)
                    .WithMany(order => order.Items)
                    .HasForeignKey(item => item.SalesOrderId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.Product)
                    .WithMany(product => product.SalesOrderItems)
                    .HasForeignKey(item => item.ProductId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.ProductPrice)
                    .WithMany(price => price.SalesOrderItems)
                    .HasForeignKey(item => item.ProductPriceId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<ProductPrice>(entity =>
            {
                entity.ToTable(
                    "ProductPrices",
                    table => table.HasCheckConstraint(
                        "CK_ProductPrices_Positive",
                        "[SellingPrice] > 0"));
                entity.Property(item => item.SellingPrice).HasPrecision(18, 2);
                entity.Property(item => item.PriceBasis)
                    .HasMaxLength(30)
                    .HasDefaultValue(ProductPriceBases.PerKilogram);
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.ProductId);
                entity.HasIndex(item => item.SellingPrice);
                entity.HasIndex(item => item.EffectiveFromUtc);
                entity.HasIndex(item => item.EffectiveToUtc);
                entity.HasIndex(item => new { item.ProductId, item.IsCurrent, item.IsDeleted })
                    .IsUnique()
                    .HasFilter("[IsCurrent] = 1 AND [IsDeleted] = 0")
                    .HasDatabaseName("UX_ProductPrices_Current");
                entity.HasOne(item => item.Product)
                    .WithMany(product => product.ProductPrices)
                    .HasForeignKey(item => item.ProductId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.CreatedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.CreatedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.DeletedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.DeletedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<CustomerOrderLink>(entity =>
            {
                entity.ToTable("CustomerOrderLinks");
                entity.HasIndex(link => link.TokenHash).IsUnique();
                entity.HasIndex(link => link.ExpiresAtUtc);
                entity.HasIndex(link => new { link.CustomerId, link.CreatedAtUtc });
                entity.HasIndex(link => link.SalesOrderId).IsUnique().HasFilter("[SalesOrderId] IS NOT NULL");
                entity.HasOne(link => link.Customer)
                    .WithMany(customer => customer.OrderLinks)
                    .HasForeignKey(link => link.CustomerId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(link => link.CreatedByUser)
                    .WithMany()
                    .HasForeignKey(link => link.CreatedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(link => link.SalesOrder)
                    .WithOne()
                    .HasForeignKey<CustomerOrderLink>(link => link.SalesOrderId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<OrderStatusHistory>(entity =>
            {
                entity.ToTable("OrderStatusHistory");
                entity.HasIndex(history => new { history.SalesOrderId, history.ChangedAtUtc });
                entity.HasOne(history => history.SalesOrder)
                    .WithMany(order => order.StatusHistory)
                    .HasForeignKey(history => history.SalesOrderId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(history => history.ChangedByUser)
                    .WithMany()
                    .HasForeignKey(history => history.ChangedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<OrderStockReservation>(entity =>
            {
                entity.ToTable("OrderStockReservations");
                entity.Property(reservation => reservation.QuantityReservedKg).HasPrecision(18, 2);
                entity.HasIndex(reservation => new { reservation.ProductBatchId, reservation.Status });
                entity.HasIndex(reservation => new { reservation.SalesOrderId, reservation.Status });
                entity.HasIndex(reservation => reservation.SalesOrderItemId);
                entity.HasOne(reservation => reservation.SalesOrder)
                    .WithMany(order => order.StockReservations)
                    .HasForeignKey(reservation => reservation.SalesOrderId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(reservation => reservation.SalesOrderItem)
                    .WithMany(item => item.StockReservations)
                    .HasForeignKey(reservation => reservation.SalesOrderItemId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(reservation => reservation.Product)
                    .WithMany(product => product.OrderStockReservations)
                    .HasForeignKey(reservation => reservation.ProductId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(reservation => reservation.ProductBatch)
                    .WithMany(batch => batch.OrderStockReservations)
                    .HasForeignKey(reservation => reservation.ProductBatchId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(reservation => reservation.Stock)
                    .WithMany(stock => stock.OrderStockReservations)
                    .HasForeignKey(reservation => reservation.StockId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(reservation => reservation.WarehouseSection)
                    .WithMany(section => section.OrderStockReservations)
                    .HasForeignKey(reservation => reservation.SectionId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<Invoice>(entity =>
            {
                entity.ToTable("Invoices");
                entity.Property(invoice => invoice.Subtotal).HasPrecision(18, 2);
                entity.Property(invoice => invoice.TaxAmount).HasPrecision(18, 2);
                entity.Property(invoice => invoice.TotalAmount).HasPrecision(18, 2);
                entity.HasIndex(invoice => invoice.InvoiceNumber).IsUnique();
                entity.HasIndex(invoice => invoice.SalesOrderId).IsUnique();
                entity.HasOne(invoice => invoice.SalesOrder)
                    .WithOne(order => order.Invoice)
                    .HasForeignKey<Invoice>(invoice => invoice.SalesOrderId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<Delivery>(entity =>
            {
                entity.ToTable("Deliveries", table =>
                {
                    table.HasCheckConstraint(
                        "CK_Deliveries_ScheduleWindow",
                        "[ScheduledEndUtc] > [ScheduledStartUtc]");
                    table.HasCheckConstraint(
                        "CK_Deliveries_Status",
                        "[Status] IN ('Scheduled','Assigned','InTransit','Completed','Cancelled')");
                });
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.SalesOrderId)
                    .IsUnique()
                    .HasDatabaseName("UX_Deliveries_SalesOrderId");
                entity.HasIndex(item => item.Status);
                entity.HasIndex(item => item.ScheduledStartUtc);
                entity.HasIndex(item => item.ScheduledEndUtc);
                entity.HasIndex(item => new
                {
                    item.DriverId,
                    item.Status,
                    item.ScheduledStartUtc,
                    item.ScheduledEndUtc
                }).HasDatabaseName("IX_Deliveries_Driver_Window");
                entity.HasOne(item => item.SalesOrder)
                    .WithOne(order => order.Delivery)
                    .HasForeignKey<Delivery>(item => item.SalesOrderId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.Driver)
                    .WithMany(driver => driver.Deliveries)
                    .HasForeignKey(item => item.DriverId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.AssignedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.AssignedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.StartedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.StartedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.CompletedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.CompletedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<DeliveryDriverAssignment>(entity =>
            {
                entity.ToTable("DeliveryDriverAssignments");
                entity.HasIndex(item => item.DeliveryId);
                entity.HasIndex(item => new
                {
                    item.DriverId,
                    item.IsCurrent,
                    item.AssignedAtUtc
                });
                entity.HasIndex(item => new { item.DeliveryId, item.IsCurrent })
                    .IsUnique()
                    .HasFilter("[IsCurrent] = 1")
                    .HasDatabaseName("UX_DeliveryDriverAssignments_Current");
                entity.HasOne(item => item.Delivery)
                    .WithMany(delivery => delivery.DriverAssignments)
                    .HasForeignKey(item => item.DeliveryId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.Driver)
                    .WithMany(driver => driver.AssignmentHistory)
                    .HasForeignKey(item => item.DriverId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.AssignedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.AssignedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.UnassignedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.UnassignedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<DeliveryStatusHistory>(entity =>
            {
                entity.ToTable("DeliveryStatusHistory");
                entity.HasIndex(item => new { item.DeliveryId, item.ChangedAtUtc });
                entity.HasOne(item => item.Delivery)
                    .WithMany(delivery => delivery.StatusHistory)
                    .HasForeignKey(item => item.DeliveryId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.ChangedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.ChangedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<DeliveryCompletionRecord>(entity =>
            {
                entity.ToTable("DeliveryCompletionRecords");
                entity.HasIndex(item => item.DeliveryId)
                    .IsUnique()
                    .HasDatabaseName("UX_DeliveryCompletionRecords_DeliveryId");
                entity.HasIndex(item => item.CompletedAtUtc);
                entity.HasOne(item => item.Delivery)
                    .WithOne(delivery => delivery.CompletionRecord)
                    .HasForeignKey<DeliveryCompletionRecord>(item => item.DeliveryId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.CompletedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.CompletedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.CompletedByDriver)
                    .WithMany(driver => driver.CompletionRecords)
                    .HasForeignKey(item => item.CompletedByDriverId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<LookupType>(entity =>
            {
                entity.ToTable("LookupTypes");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.SystemCode)
                    .IsUnique()
                    .HasDatabaseName("UX_LookupTypes_SystemCode");
                entity.HasIndex(item => new { item.IsActive, item.DisplayName });
                entity.HasData(PhaseA2Catalog.LookupTypes.Select(item =>
                    new LookupType
                    {
                        LookupTypeId = item.Id,
                        SystemCode = item.Code,
                        DisplayName = item.DisplayName,
                        Description = item.Description,
                        IsSystemType = true,
                        IsActive = true,
                        CreatedAtUtc = PhaseA2Catalog.SeededAtUtc
                    }));
            });

            modelBuilder.Entity<LookupValue>(entity =>
            {
                entity.ToTable("LookupValues");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => new
                    {
                        item.LookupTypeId,
                        item.SystemCode
                    })
                    .IsUnique()
                    .HasDatabaseName("UX_LookupValues_Type_SystemCode");
                entity.HasIndex(item => new
                {
                    item.LookupTypeId,
                    item.IsActive,
                    item.SortOrder,
                    item.DisplayName
                });
                entity.HasOne(item => item.LookupType)
                    .WithMany(type => type.Values)
                    .HasForeignKey(item => item.LookupTypeId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasData(PhaseA2Catalog.LookupValues.Select(item =>
                    new LookupValue
                    {
                        LookupValueId = item.Id,
                        LookupTypeId = item.TypeId,
                        SystemCode = item.Code,
                        DisplayName = item.DisplayName,
                        SortOrder = item.SortOrder,
                        IsSystemValue = true,
                        IsActive = true,
                        CreatedAtUtc = PhaseA2Catalog.SeededAtUtc
                    }));
            });

            modelBuilder.Entity<LookupValueHistory>(entity =>
            {
                entity.ToTable("LookupValueHistory");
                entity.HasIndex(item => new
                {
                    item.LookupValueId,
                    item.ChangedAtUtc
                });
                entity.HasOne(item => item.LookupValue)
                    .WithMany(value => value.History)
                    .HasForeignKey(item => item.LookupValueId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.ChangedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.ChangedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<SystemSetting>(entity =>
            {
                entity.ToTable("SystemSettings");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.Key)
                    .IsUnique()
                    .HasDatabaseName("UX_SystemSettings_Key");
                entity.HasIndex(item => new { item.Category, item.IsActive });
                entity.HasOne(item => item.UpdatedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.UpdatedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasData(PhaseA2Catalog.Settings.Select(item =>
                    new SystemSetting
                    {
                        SystemSettingId = item.Id,
                        Key = item.Key,
                        Category = item.Category,
                        DisplayName = item.DisplayName,
                        Description = item.Description,
                        ValueType = item.ValueType,
                        Value = item.DefaultValue,
                        DefaultValue = item.DefaultValue,
                        Unit = item.Unit,
                        MinimumValue = item.MinimumValue,
                        MaximumValue = item.MaximumValue,
                        AllowedValuesJson = item.AllowedValuesJson,
                        IsSensitive = false,
                        IsSystemSetting = true,
                        IsActive = true,
                        RequiresRestart = false,
                        UpdatedAtUtc = PhaseA2Catalog.SeededAtUtc
                    }));
            });

            modelBuilder.Entity<SystemSettingHistory>(entity =>
            {
                entity.ToTable("SystemSettingHistory");
                entity.HasIndex(item => new
                {
                    item.SystemSettingId,
                    item.ChangedAtUtc
                });
                entity.HasOne(item => item.SystemSetting)
                    .WithMany(setting => setting.History)
                    .HasForeignKey(item => item.SystemSettingId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.ChangedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.ChangedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<DataExchangeJob>(entity =>
            {
                entity.ToTable("DataExchangeJobs");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.ValidationTokenHash)
                    .IsUnique()
                    .HasDatabaseName("UX_DataExchangeJobs_ValidationTokenHash");
                entity.HasIndex(item => new
                {
                    item.CreatedByUserId,
                    item.ExchangeType,
                    item.Status,
                    item.ExpiresAtUtc
                });
                entity.HasOne(item => item.CreatedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.CreatedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<UserOtpChallenge>(entity =>
            {
                entity.ToTable("UserOtpChallenges");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.ChallengeTokenHash)
                    .IsUnique()
                    .HasDatabaseName("UX_UserOtpChallenges_ChallengeHash");
                entity.HasIndex(item => new
                {
                    item.UserId,
                    item.Purpose,
                    item.ExpiresAtUtc
                });
                entity.HasOne(item => item.User)
                    .WithMany()
                    .HasForeignKey(item => item.UserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<TrustedDevice>(entity =>
            {
                entity.ToTable("TrustedDevices");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.TokenHash)
                    .IsUnique()
                    .HasDatabaseName("UX_TrustedDevices_TokenHash");
                entity.HasIndex(item => new
                {
                    item.UserId,
                    item.RevokedAtUtc,
                    item.ExpiresAtUtc
                });
                entity.HasOne(item => item.User)
                    .WithMany()
                    .HasForeignKey(item => item.UserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.RevokedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.RevokedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<UserRecoveryCode>(entity =>
            {
                entity.ToTable("UserRecoveryCodes");
                entity.HasIndex(item => new
                {
                    item.UserId,
                    item.CodeOrder,
                    item.CreatedAtUtc
                });
                entity.HasOne(item => item.User)
                    .WithMany()
                    .HasForeignKey(item => item.UserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<StoredFile>(entity =>
            {
                entity.ToTable("StoredFiles");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.StorageKey)
                    .IsUnique()
                    .HasDatabaseName("UX_StoredFiles_StorageKey");
                entity.HasIndex(item => new
                {
                    item.IsDeleted,
                    item.UploadedAtUtc
                });
                entity.HasOne(item => item.UploadedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.UploadedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.DeletedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.DeletedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<DeliveryProofImage>(entity =>
            {
                entity.ToTable("DeliveryProofImages");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => new
                {
                    item.DeliveryId,
                    item.RemovedAtUtc,
                    item.UploadedAtUtc
                });
                entity.HasIndex(item => item.StoredFileId)
                    .IsUnique();
                entity.HasIndex(item => new
                {
                    item.DeliveryId,
                    item.IsPrimary
                })
                    .IsUnique()
                    .HasFilter("[IsPrimary] = 1 AND [RemovedAtUtc] IS NULL")
                    .HasDatabaseName("UX_DeliveryProofImages_Primary");
                entity.HasOne(item => item.Delivery)
                    .WithMany(delivery => delivery.ProofImages)
                    .HasForeignKey(item => item.DeliveryId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.StoredFile)
                    .WithMany()
                    .HasForeignKey(item => item.StoredFileId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.ThumbnailStoredFile)
                    .WithMany()
                    .HasForeignKey(item => item.ThumbnailStoredFileId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.UploadedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.UploadedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.UploadedByDriver)
                    .WithMany()
                    .HasForeignKey(item => item.UploadedByDriverId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.RemovedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.RemovedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<HelpCategory>(entity =>
            {
                entity.ToTable("HelpCategories");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.SystemCode)
                    .IsUnique();
                entity.HasIndex(item => new
                {
                    item.IsActive,
                    item.SortOrder,
                    item.DisplayName
                });
                entity.HasData(PhaseA3Catalog.HelpCategories.Select(item =>
                    new HelpCategory
                    {
                        HelpCategoryId = item.Id,
                        SystemCode = item.Code,
                        DisplayName = item.Name,
                        Description = item.Description,
                        SortOrder = item.SortOrder,
                        IsActive = true,
                        CreatedAtUtc = PhaseA3Catalog.SeededAtUtc
                    }));
            });

            modelBuilder.Entity<HelpTopic>(entity =>
            {
                entity.ToTable("HelpTopics");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => item.Slug)
                    .IsUnique();
                entity.HasIndex(item => new
                {
                    item.HelpCategoryId,
                    item.IsPublished,
                    item.SortOrder
                });
                entity.HasOne(item => item.Category)
                    .WithMany(category => category.Topics)
                    .HasForeignKey(item => item.HelpCategoryId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.UpdatedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.UpdatedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasData(PhaseA3Catalog.HelpTopics.Select(item =>
                    new HelpTopic
                    {
                        HelpTopicId = item.Id,
                        HelpCategoryId = item.CategoryId,
                        Slug = item.Slug,
                        Title = item.Title,
                        Summary = item.Summary,
                        BodyContent = NormalizeSeedText(item.Body),
                        Keywords = item.Keywords,
                        AudienceRolesCsv = item.AudienceRoles,
                        IsPublic = item.IsPublic,
                        IsPublished = true,
                        SortOrder = item.SortOrder,
                        CreatedAtUtc = PhaseA3Catalog.SeededAtUtc
                    }));
            });

            modelBuilder.Entity<HelpContextMapping>(entity =>
            {
                entity.ToTable("HelpContextMappings");
                entity.HasIndex(item => new
                {
                    item.RoutePattern,
                    item.ComponentKey,
                    item.IsActive,
                    item.Priority
                });
                entity.HasOne(item => item.HelpTopic)
                    .WithMany(topic => topic.ContextMappings)
                    .HasForeignKey(item => item.HelpTopicId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasData(PhaseA3Catalog.HelpContexts.Select(item =>
                    new HelpContextMapping
                    {
                        HelpContextMappingId = item.Id,
                        HelpTopicId = item.TopicId,
                        RoutePattern = item.RoutePattern,
                        ComponentKey = item.ComponentKey,
                        Priority = item.Priority,
                        IsActive = true
                    }));
            });

            modelBuilder.Entity<HelpMedia>(entity =>
            {
                entity.ToTable("HelpMedia");
                entity.Property(item => item.RowVersion)
                    .IsRowVersion()
                    .IsConcurrencyToken();
                entity.HasIndex(item => new
                {
                    item.IsPublished,
                    item.IsFeatured,
                    item.SortOrder
                });
                entity.HasOne(item => item.HelpTopic)
                    .WithMany(topic => topic.Media)
                    .HasForeignKey(item => item.HelpTopicId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.StoredFile)
                    .WithMany()
                    .HasForeignKey(item => item.StoredFileId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.CaptionStoredFile)
                    .WithMany()
                    .HasForeignKey(item => item.CaptionStoredFileId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.UploadedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.UploadedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
                entity.HasOne(item => item.RemovedByUser)
                    .WithMany()
                    .HasForeignKey(item => item.RemovedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Keep feature mappings in partial files while building one EF model and migration history.
            ConfigurePhaseC(modelBuilder);
            ConfigureOperationalSections(modelBuilder);
            ConfigureWorkflowIntegration(modelBuilder);
        }

        private static string NormalizeSeedText(string value) =>
            value.Replace("\r\n", "\n", StringComparison.Ordinal)
                .Replace('\r', '\n');
    }
}
