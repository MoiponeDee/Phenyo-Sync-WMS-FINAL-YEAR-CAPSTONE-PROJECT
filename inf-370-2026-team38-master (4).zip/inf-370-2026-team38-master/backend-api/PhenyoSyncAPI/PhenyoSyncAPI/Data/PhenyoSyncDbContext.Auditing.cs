using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Storage;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Data;

/// <summary>Adds automatic, immutable entity-change auditing to the shared EF unit of work.</summary>
public partial class PhenyoSyncDbContext
{
    public override int SaveChanges() => SaveChanges(true);

    public override int SaveChanges(bool acceptAllChangesOnSuccess)
    {
        // Capture changes before the first save, then persist generated keys and their audit rows
        // in the same transaction so business data cannot commit without its audit trail.
        PrepareSecurityEntities();
        RejectAuditLogMutations();
        ChangeTracker.DetectChanges();
        var pending = CapturePendingAudits();

        if (_savingAuditLogs || pending.Count == 0)
        {
            return base.SaveChanges(acceptAllChangesOnSuccess);
        }

        IDbContextTransaction? ownedTransaction = null;
        try
        {
            if (Database.CurrentTransaction is null)
            {
                ownedTransaction = Database.BeginTransaction();
            }

            var affected = base.SaveChanges(acceptAllChangesOnSuccess);
            AddCompletedAuditLogs(pending);
            _savingAuditLogs = true;
            base.SaveChanges(acceptAllChangesOnSuccess);
            _savingAuditLogs = false;
            ownedTransaction?.Commit();
            return affected;
        }
        catch
        {
            _savingAuditLogs = false;
            ownedTransaction?.Rollback();
            throw;
        }
        finally
        {
            ownedTransaction?.Dispose();
        }
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default) =>
        SaveChangesAsync(true, cancellationToken);

    public override async Task<int> SaveChangesAsync(
        bool acceptAllChangesOnSuccess,
        CancellationToken cancellationToken = default)
    {
        // Async saves follow the same two-phase audit write as synchronous callers.
        PrepareSecurityEntities();
        RejectAuditLogMutations();
        ChangeTracker.DetectChanges();
        var pending = CapturePendingAudits();

        if (_savingAuditLogs || pending.Count == 0)
        {
            return await base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
        }

        IDbContextTransaction? ownedTransaction = null;
        try
        {
            if (Database.CurrentTransaction is null)
            {
                ownedTransaction = await Database.BeginTransactionAsync(cancellationToken);
            }

            var affected = await base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
            AddCompletedAuditLogs(pending);
            _savingAuditLogs = true;
            await base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
            _savingAuditLogs = false;

            if (ownedTransaction is not null)
            {
                await ownedTransaction.CommitAsync(cancellationToken);
            }

            return affected;
        }
        catch
        {
            _savingAuditLogs = false;
            if (ownedTransaction is not null)
            {
                await ownedTransaction.RollbackAsync(cancellationToken);
            }
            throw;
        }
        finally
        {
            if (ownedTransaction is not null)
            {
                await ownedTransaction.DisposeAsync();
            }
        }
    }

    private void RejectAuditLogMutations()
    {
        // Audit history is append-only; application code cannot rewrite or delete evidence.
        var forbidden = ChangeTracker.Entries<AuditLog>()
            .FirstOrDefault(entry =>
                entry.State is EntityState.Modified or EntityState.Deleted);

        if (forbidden is not null)
        {
            throw new InvalidOperationException(
                "Audit logs are immutable and cannot be modified or deleted.");
        }
    }

    private void PrepareSecurityEntities()
    {
        // Normalize identity fields immediately before persistence so every write path,
        // including imports and background jobs, obeys the same uniqueness format.
        foreach (var entry in ChangeTracker.Entries<Customer>()
                     .Where(item =>
                         item.State is EntityState.Added or EntityState.Modified))
        {
            entry.Entity.Email = entry.Entity.Email.Trim().ToLowerInvariant();
            entry.Entity.NormalizedEmail =
                entry.Entity.Email.ToUpperInvariant();
        }

        foreach (var entry in ChangeTracker.Entries<Supplier>()
                     .Where(item =>
                         item.State is EntityState.Added or EntityState.Modified))
        {
            if (string.IsNullOrWhiteSpace(entry.Entity.SupplierCode))
            {
                entry.Entity.SupplierCode =
                    $"SUP-{Guid.NewGuid():N}"[..16].ToUpperInvariant();
            }
            if (string.IsNullOrWhiteSpace(entry.Entity.SupplierTypeCode))
                entry.Entity.SupplierTypeCode = "GeneralSupplier";
            entry.Entity.Email = string.IsNullOrWhiteSpace(entry.Entity.Email)
                ? null
                : entry.Entity.Email.Trim().ToLowerInvariant();
            entry.Entity.NormalizedEmail =
                entry.Entity.Email?.ToUpperInvariant();
        }

        foreach (var entry in ChangeTracker.Entries<User>()
                     .Where(item =>
                         item.State is EntityState.Added or EntityState.Modified))
        {
            entry.Entity.Email = entry.Entity.Email.Trim();
            entry.Entity.NormalizedEmail =
                entry.Entity.Email.ToUpperInvariant();
        }

        foreach (var entry in ChangeTracker.Entries<Role>()
                     .Where(item =>
                         item.State is EntityState.Added or EntityState.Modified))
        {
            if (string.IsNullOrWhiteSpace(entry.Entity.RoleCode))
            {
                entry.Entity.RoleCode =
                    RoleCodes.Normalize(entry.Entity.RoleName);
            }

            if (string.IsNullOrWhiteSpace(entry.Entity.RoleName))
            {
                entry.Entity.RoleName = entry.Entity.RoleCode;
            }
        }

        foreach (var entry in ChangeTracker.Entries<Permission>()
                     .Where(item =>
                         item.State is EntityState.Added or EntityState.Modified))
        {
            if (string.IsNullOrWhiteSpace(entry.Entity.PermissionCode))
            {
                entry.Entity.PermissionCode = string.Join(
                    '.',
                    new[] { entry.Entity.Module, entry.Entity.PermissionName }
                        .Where(value => !string.IsNullOrWhiteSpace(value)))
                    .Replace(" ", string.Empty);
            }

            if (string.IsNullOrWhiteSpace(entry.Entity.PermissionName))
            {
                entry.Entity.PermissionName = entry.Entity.PermissionCode;
            }

            if (string.IsNullOrWhiteSpace(entry.Entity.DisplayName))
            {
                entry.Entity.DisplayName = entry.Entity.PermissionName;
            }

            if (string.IsNullOrWhiteSpace(entry.Entity.Module))
            {
                entry.Entity.Module =
                    entry.Entity.PermissionCode.Split('.')[0];
            }
        }
    }

    private List<PendingAudit> CapturePendingAudits()
    {
        // Background changes receive an explicit system actor when no HTTP user is present.
        var actor = _auditContextAccessor?.Current ?? new AuditActorContext(
            null, null, "PhenyoSync System", null,
            AuditActorTypes.System, _fallbackAuditCorrelationId,
            null, null, null, null);

        return ChangeTracker.Entries()
            .Where(entry =>
                entry.Entity is not AuditLog &&
                entry.State is EntityState.Added or EntityState.Modified or EntityState.Deleted)
            .Select(entry => PendingAudit.Create(entry, actor))
            .Where(item => item is not null)
            .Cast<PendingAudit>()
            .ToList();
    }

    private void AddCompletedAuditLogs(IEnumerable<PendingAudit> pending)
    {
        foreach (var item in pending)
        {
            AuditLogs.Add(item.ToAuditLog());
        }
    }

    private sealed class PendingAudit
    {
        private readonly EntityEntry _entry;
        private readonly AuditActorContext _actor;
        private readonly IReadOnlyDictionary<string, object?>? _beforeValues;
        private readonly IReadOnlyDictionary<string, object?>? _capturedAfterValues;
        private readonly IReadOnlyCollection<string> _changedFields;
        private readonly EntityState _state;

        private PendingAudit(
            EntityEntry entry,
            AuditActorContext actor,
            IReadOnlyDictionary<string, object?>? beforeValues,
            IReadOnlyDictionary<string, object?>? capturedAfterValues,
            IReadOnlyCollection<string> changedFields)
        {
            _entry = entry;
            _actor = actor;
            _beforeValues = beforeValues;
            _capturedAfterValues = capturedAfterValues;
            _changedFields = changedFields;
            _state = entry.State;
        }

        public static PendingAudit? Create(EntityEntry entry, AuditActorContext actor)
        {
            // Store only changed properties for updates to keep the audit useful and bounded.
            var changedFields = entry.State == EntityState.Modified
                ? entry.Properties
                    .Where(property =>
                        property.IsModified &&
                        !Equals(property.OriginalValue, property.CurrentValue))
                    .Select(property => property.Metadata.Name)
                    .ToArray()
                : entry.Properties
                    .Select(property => property.Metadata.Name)
                    .ToArray();

            if (entry.State == EntityState.Modified && changedFields.Length == 0)
            {
                return null;
            }

            IReadOnlyDictionary<string, object?>? before = null;
            IReadOnlyDictionary<string, object?>? after = null;

            if (entry.State is EntityState.Modified or EntityState.Deleted)
            {
                before = entry.Properties
                    .Where(property =>
                        entry.State == EntityState.Deleted ||
                        changedFields.Contains(property.Metadata.Name))
                    .ToDictionary(
                        property => property.Metadata.Name,
                        property => AuditSanitizer.SafeValue(
                            property.Metadata.Name,
                            property.OriginalValue));
            }

            if (entry.State is EntityState.Modified)
            {
                after = entry.Properties
                    .Where(property => changedFields.Contains(property.Metadata.Name))
                    .ToDictionary(
                        property => property.Metadata.Name,
                        property => AuditSanitizer.SafeValue(
                            property.Metadata.Name,
                            property.CurrentValue));
            }

            return new PendingAudit(entry, actor, before, after, changedFields);
        }

        public AuditLog ToAuditLog()
        {
            // Values pass through the sanitizer before serialization, preventing secrets from
            // entering the immutable audit table even when an entity contains sensitive fields.
            var entityType = _entry.Metadata.ClrType.Name;
            var action = AuditMetadataResolver.ActionFor(
                _entry,
                _changedFields,
                _state);
            IReadOnlyDictionary<string, object?>? afterValues = _capturedAfterValues;

            if (_state == EntityState.Added)
            {
                afterValues = _entry.Properties.ToDictionary(
                    property => property.Metadata.Name,
                    property => AuditSanitizer.SafeValue(
                        property.Metadata.Name,
                        property.CurrentValue));
            }

            var primaryKey = _entry.Metadata.FindPrimaryKey();
            var entityId = primaryKey is null
                ? null
                : string.Join(
                    "|",
                    primaryKey.Properties.Select(property =>
                        $"{property.Name}={_entry.Property(property.Name).CurrentValue}"));

            return new AuditLog
            {
                OccurredAtUtc = DateTime.UtcNow,
                UserId = _actor.UserId,
                UserEmailSnapshot = AuditSanitizer.Bounded(_actor.Email, 320),
                UserDisplayNameSnapshot = AuditSanitizer.Bounded(_actor.DisplayName, 200),
                UserRoleSnapshot = AuditSanitizer.Bounded(_actor.Role, 100),
                ActorType = _actor.ActorType,
                ActionType = action,
                SystemModule = AuditMetadataResolver.ModuleFor(entityType),
                OperationName = $"{action}{entityType}",
                EntityType = entityType,
                EntityId = AuditSanitizer.Bounded(entityId, 256),
                EntityDisplay = AuditMetadataResolver.EntityDisplay(_entry),
                Description = $"{action} {entityType} {entityId}".Trim(),
                BeforeValuesJson = AuditSanitizer.Serialize(_beforeValues),
                AfterValuesJson = AuditSanitizer.Serialize(afterValues),
                ChangedFieldsJson = AuditSanitizer.SerializeFields(_changedFields),
                Success = true,
                CorrelationId = _actor.CorrelationId,
                RequestPath = _actor.RequestPath,
                HttpMethod = _actor.HttpMethod,
                IpAddress = _actor.IpAddress,
                UserAgent = _actor.UserAgent,
                EventSource = AuditEventSources.EntityChange
            };
        }
    }
}
