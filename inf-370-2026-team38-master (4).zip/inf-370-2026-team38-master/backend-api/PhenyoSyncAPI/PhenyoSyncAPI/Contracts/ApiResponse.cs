namespace PhenyoSyncAPI.Contracts;

// A common envelope gives both frontends stable result codes and trace IDs without exposing exceptions.

public interface IApiEnvelope
{
}

public sealed class ApiResponse<T> : IApiEnvelope
{
    public bool Success { get; init; } = true;
    public required string Message { get; init; }
    public required string Code { get; init; }
    public T? Data { get; init; }
    public required string TraceId { get; init; }
}

public sealed class ApiErrorResponse : IApiEnvelope
{
    public bool Success { get; init; }
    public required string Message { get; init; }
    public required string Code { get; init; }
    public IReadOnlyDictionary<string, string[]>? Errors { get; init; }
    public required string TraceId { get; init; }
}

public static class ApiResponses
{
    public static ApiResponse<T> Ok<T>(
        HttpContext context,
        T? data,
        string message = "The request was completed successfully.",
        string code = "REQUEST_COMPLETED") =>
        new()
        {
            Message = message,
            Code = code,
            Data = data,
            TraceId = context.TraceIdentifier
        };

    public static ApiErrorResponse Error(
        HttpContext context,
        string message,
        string code,
        IReadOnlyDictionary<string, string[]>? errors = null) =>
        new()
        {
            Message = message,
            Code = code,
            Errors = errors,
            TraceId = context.TraceIdentifier
        };
}
