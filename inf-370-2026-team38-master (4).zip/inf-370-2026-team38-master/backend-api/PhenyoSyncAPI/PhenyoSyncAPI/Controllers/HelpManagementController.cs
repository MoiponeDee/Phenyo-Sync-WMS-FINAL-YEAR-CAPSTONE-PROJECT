using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Help;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/help-management")]
[Authorize]
[HasPermission(Permissions.Help.Manage)]
/// <summary>Exposes versioned help-content administration under management permission.</summary>
public sealed class HelpManagementController : ControllerBase
{
    private readonly IHelpService _help;

    public HelpManagementController(IHelpService help)
    {
        _help = help;
    }

    [HttpGet("categories")]
    // HTTP GET at "categories" handles the categories operation for help management through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _help.ManageCategoriesAsync; failures
    // use existing HTTP handling.
    public Task<IReadOnlyList<HelpCategoryDto>> Categories(
        CancellationToken cancellationToken) =>
        _help.ManageCategoriesAsync(cancellationToken);

    [HttpPost("categories")]
    // HTTP POST at "categories" creates or attaches help management data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHelpCategoryRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _help.SaveCategoryAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> CreateCategory(
        [FromBody] SaveHelpCategoryRequest request,
        CancellationToken cancellationToken) =>
        Created(
            string.Empty,
            await _help.SaveCategoryAsync(
                null,
                request,
                UserId(),
                cancellationToken));

    [HttpPut("categories/{id:int}")]
    // HTTP PUT at "categories/{id:int}" updates only allowed help management fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHelpCategoryRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _help.SaveCategoryAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> UpdateCategory(
        int id,
        [FromBody] SaveHelpCategoryRequest request,
        CancellationToken cancellationToken) =>
        await Safe(() => _help.SaveCategoryAsync(
            id,
            request,
            UserId(),
            cancellationToken));

    [HttpGet("topics")]
    // HTTP GET at "topics" handles the topics operation for help management through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _help.ManageTopicsAsync; failures use
    // existing HTTP handling.
    public Task<IReadOnlyList<HelpTopicSummaryDto>> Topics(
        CancellationToken cancellationToken) =>
        _help.ManageTopicsAsync(cancellationToken);

    [HttpGet("topics/{id:int}")]
    // HTTP GET at "topics/{id:int}" returns the authoritative help management projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _help.ManageTopicAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Topic(
        int id,
        CancellationToken cancellationToken) =>
        await Safe(() => _help.ManageTopicAsync(
            id,
            cancellationToken));

    [HttpPost("topics")]
    // HTTP POST at "topics" creates or attaches help management data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHelpTopicRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _help.SaveTopicAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> CreateTopic(
        [FromBody] SaveHelpTopicRequest request,
        CancellationToken cancellationToken) =>
        Created(
            string.Empty,
            await _help.SaveTopicAsync(
                null,
                request,
                UserId(),
                cancellationToken));

    [HttpPut("topics/{id:int}")]
    // HTTP PUT at "topics/{id:int}" updates only allowed help management fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHelpTopicRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _help.SaveTopicAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> UpdateTopic(
        int id,
        [FromBody] SaveHelpTopicRequest request,
        CancellationToken cancellationToken) =>
        await Safe(() => _help.SaveTopicAsync(
            id,
            request,
            UserId(),
            cancellationToken));

    [HttpPost("contexts")]
    // HTTP POST at "contexts" creates or attaches help management data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHelpContextRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _help.SaveContextAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> CreateContext(
        [FromBody] SaveHelpContextRequest request,
        CancellationToken cancellationToken) =>
        Created(
            string.Empty,
            await _help.SaveContextAsync(
                null,
                request,
                UserId(),
                cancellationToken));

    [HttpPut("contexts/{id:int}")]
    // HTTP PUT at "contexts/{id:int}" updates only allowed help management fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHelpContextRequest instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _help.SaveContextAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> UpdateContext(
        int id,
        [FromBody] SaveHelpContextRequest request,
        CancellationToken cancellationToken) =>
        await Safe(() => _help.SaveContextAsync(
            id,
            request,
            UserId(),
            cancellationToken));

    private int UserId() =>
        int.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var userId)
            ? userId
            : throw new UnauthorizedAccessException();

    private static async Task<IActionResult> Safe<T>(Func<Task<T>> action)
    {
        try
        {
            return new OkObjectResult(await action());
        }
        catch (KeyNotFoundException exception)
        {
            return new NotFoundObjectResult(new { message = exception.Message });
        }
        catch (InvalidOperationException exception)
        {
            return new BadRequestObjectResult(new { message = exception.Message });
        }
        catch (Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException)
        {
            return new ConflictObjectResult(new
            {
                message = "The Help content changed. Refresh and try again."
            });
        }
    }
}
