using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Procurement;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Authorize]
[Route("api/procurement-planning")]
/// <summary>Exposes approved-demand planning and Buying List proposal endpoints.</summary>
public sealed class ProcurementPlanningController : ControllerBase
{
    private readonly IProcurementPlanningService _service;

    public ProcurementPlanningController(IProcurementPlanningService service)
    {
        _service = service;
    }

    [HttpGet("products/{productId:int}/requirements")]
    [HasAnyPermission(Permissions.Products.View, Permissions.RawStock.View)]
    // HTTP GET at "products/{productId:int}/requirements" returns the authoritative procurement planning
    // projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.RequirementsAsync; failures
    // use existing HTTP handling.
    public Task<IReadOnlyList<ProductRawStockRequirementDto>> Requirements(
        int productId,
        [FromQuery] bool includeInactive,
        CancellationToken cancellationToken) =>
        _service.RequirementsAsync(
            productId,
            includeInactive,
            cancellationToken);

    [HttpPost("products/{productId:int}/requirements")]
    [HasPermission(Permissions.Reconciliation.Manage)]
    // HTTP POST at "products/{productId:int}/requirements" creates or attaches procurement planning data
    // through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveProductRawStockRequirementRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveRequirementAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<ProductRawStockRequirementDto>> Create(
        int productId,
        SaveProductRawStockRequirementRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            StatusCodes.Status201Created,
            await _service.SaveRequirementAsync(
                productId,
                null,
                request,
                UserId(),
                cancellationToken));

    [HttpPut("products/{productId:int}/requirements/{requirementId:int}")]
    [HasPermission(Permissions.Reconciliation.Manage)]
    // HTTP PUT at "products/{productId:int}/requirements/{requirementId:int}" updates only allowed
    // procurement planning fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveProductRawStockRequirementRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveRequirementAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<ProductRawStockRequirementDto> Update(
        int productId,
        int requirementId,
        SaveProductRawStockRequirementRequest request,
        CancellationToken cancellationToken) =>
        _service.SaveRequirementAsync(
            productId,
            requirementId,
            request,
            UserId(),
            cancellationToken);

    [HttpGet("shortages")]
    [HasAnyPermission(
        Permissions.BuyingLists.Create,
        Permissions.BuyingLists.ViewAll,
        Permissions.RawStock.View)]
    // HTTP GET at "shortages" returns the authoritative procurement planning projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.ShortagesAsync; failures use
    // existing HTTP handling.
    public Task<IReadOnlyList<ProcurementShortageSuggestionDto>> Shortages(
        CancellationToken cancellationToken) =>
        _service.ShortagesAsync(cancellationToken);

    [HttpGet("unmapped-demand")]
    [HasAnyPermission(
        Permissions.BuyingLists.Create,
        Permissions.BuyingLists.ViewAll,
        Permissions.RawStock.View)]
    // HTTP GET at "unmapped-demand" returns the authoritative procurement planning projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.UnmappedDemandAsync; failures
    // use existing HTTP handling.
    public Task<IReadOnlyList<UnmappedProductDemandDto>> UnmappedDemand(
        CancellationToken cancellationToken) =>
        _service.UnmappedDemandAsync(cancellationToken);

    private int UserId() =>
        int.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var userId)
            ? userId
            : throw new PhaseCException(401, "The authenticated user is not valid.");
}
