using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Configuration;
using PhenyoSyncAPI.DTOs.Lookups;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
[HasPermission(Permissions.WarehouseSections.View)]
/// <summary>Exposes warehouse-location master data used by stock balances and batches.</summary>
public sealed class WarehouseSectionController : ControllerBase
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _audit;

    public WarehouseSectionController(
        PhenyoSyncDbContext context,
        IAuditService audit)
    {
        _context = context;
        _audit = audit;
    }

    [HttpGet]
    // HTTP GET at the controller root queries filtered warehouse section records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Search(
        [FromQuery] string? search,
        [FromQuery] string? status,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 25,
        CancellationToken cancellationToken = default)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var source = _context.WarehouseSections.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            source = source.Where(item =>
                item.SectionCode.Contains(term) ||
                item.SectionName.Contains(term) ||
                item.Description != null && item.Description.Contains(term));
        }
        if (!string.IsNullOrWhiteSpace(status))
        {
            var selected = status.Trim();
            source = source.Where(item => item.Status == selected);
        }

        var total = await source.CountAsync(cancellationToken);
        var items = await Project(source)
            .OrderBy(item => item.SectionName)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);
        return Ok(new
        {
            items,
            page,
            pageSize,
            total,
            totalPages = total == 0
                ? 0
                : (int)Math.Ceiling(total / (double)pageSize)
        });
    }

    [HttpGet("active")]
    // HTTP GET at "active" handles the get active operation for warehouse section through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public Task<List<WarehouseSectionDto>> GetActive(
        CancellationToken cancellationToken) =>
        Project(_context.WarehouseSections
                .AsNoTracking()
                .Where(item => item.Status == ProductStatuses.Active))
            .OrderBy(item => item.SectionName)
            .ToListAsync(cancellationToken);

    [HttpGet("{id:int}")]
    // HTTP GET at "{id:int}" returns the authoritative warehouse section projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Get(
        int id,
        CancellationToken cancellationToken)
    {
        var item = await Project(_context.WarehouseSections.AsNoTracking())
            .SingleOrDefaultAsync(
                section => section.SectionId == id,
                cancellationToken);
        return item is null
            ? NotFound(new { message = "The warehouse section was not found." })
            : Ok(item);
    }

    [HttpPost]
    [HasPermission(Permissions.WarehouseSections.Manage)]
    // HTTP POST at the controller root creates or attaches warehouse section data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveWarehouseSectionRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Create(
        [FromBody] SaveWarehouseSectionRequest request,
        CancellationToken cancellationToken)
    {
        var code = request.SectionCode.Trim().ToUpperInvariant();
        var name = request.SectionName.Trim();
        if (await _context.WarehouseSections.AnyAsync(item =>
                item.SectionCode == code ||
                item.SectionName.ToUpper() == name.ToUpper(),
                cancellationToken))
        {
            return Conflict(new
            {
                message = "A warehouse section with this code or name already exists."
            });
        }

        var section = new WarehouseSection
        {
            SectionCode = code,
            SectionName = name,
            Description = NullIfWhiteSpace(request.Description),
            Status = ProductStatuses.Active,
            CreatedAtUtc = DateTime.UtcNow
        };
        _context.WarehouseSections.Add(section);
        await _context.SaveChangesAsync(cancellationToken);
        return CreatedAtAction(nameof(Get), new { id = section.SectionId }, new
        {
            message = "The warehouse section was created successfully.",
            code = "WAREHOUSE_SECTION_CREATED",
            section.SectionId
        });
    }

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.WarehouseSections.Manage)]
    // HTTP PUT at "{id:int}" updates only allowed warehouse section fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveWarehouseSectionRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> Update(
        int id,
        [FromBody] SaveWarehouseSectionRequest request,
        CancellationToken cancellationToken)
    {
        var section = await _context.WarehouseSections.SingleOrDefaultAsync(
            item => item.SectionId == id,
            cancellationToken);
        if (section is null)
        {
            return NotFound(new { message = "The warehouse section was not found." });
        }
        if (!string.Equals(
                section.SectionCode,
                request.SectionCode.Trim(),
                StringComparison.OrdinalIgnoreCase))
        {
            return Conflict(new { message = "The warehouse section code is immutable." });
        }
        if (!TryApplyRowVersion(section, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The warehouse section version is invalid. Refresh and try again."
            });
        }

        var name = request.SectionName.Trim();
        if (await _context.WarehouseSections.AnyAsync(item =>
                item.SectionId != id &&
                item.SectionName.ToUpper() == name.ToUpper(),
                cancellationToken))
        {
            return Conflict(new { message = "This warehouse section name is already used." });
        }

        section.SectionName = name;
        section.Description = NullIfWhiteSpace(request.Description);
        section.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
        return Ok(new
        {
            message = "The warehouse section was updated successfully.",
            code = "WAREHOUSE_SECTION_UPDATED"
        });
    }

    [HttpPost("{id:int}/status")]
    [HasPermission(Permissions.WarehouseSections.Manage)]
    // HTTP POST at "{id:int}/status" changes warehouse section state only through the supported status
    // operation.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ChangeConfigurationStatusRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _audit.RecordAsync; failures use existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> ChangeStatus(
        int id,
        [FromBody] ChangeConfigurationStatusRequest request,
        CancellationToken cancellationToken)
    {
        var section = await _context.WarehouseSections.SingleOrDefaultAsync(
            item => item.SectionId == id,
            cancellationToken);
        if (section is null)
        {
            return NotFound(new { message = "The warehouse section was not found." });
        }
        if (!TryApplyRowVersion(section, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The warehouse section version is invalid. Refresh and try again."
            });
        }

        section.Status = request.IsActive
            ? ProductStatuses.Active
            : ProductStatuses.Inactive;
        section.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = request.IsActive
                ? AuditActionTypes.Activate
                : AuditActionTypes.Deactivate,
            SystemModule = AuditModules.Configuration,
            OperationName = "ChangeWarehouseSectionStatus",
            Description = "A warehouse section status was changed.",
            EntityType = nameof(WarehouseSection),
            EntityId = section.SectionId.ToString(),
            EntityDisplay = section.SectionName,
            SafeDetails = new Dictionary<string, object?>
            {
                ["SectionCode"] = section.SectionCode,
                ["Reason"] = request.Reason.Trim()
            }
        }, cancellationToken);
        return Ok(new
        {
            message = request.IsActive
                ? "The warehouse section was activated."
                : "The warehouse section was deactivated. Historical stock remains readable.",
            code = request.IsActive
                ? "WAREHOUSE_SECTION_ACTIVATED"
                : "WAREHOUSE_SECTION_DEACTIVATED"
        });
    }

    [HttpDelete("{id:int}")]
    [HasPermission(Permissions.WarehouseSections.Manage)]
    // HTTP DELETE at "{id:int}" removes or retires warehouse section data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeleteConfigurationRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _audit.RecordAsync; failures use existing HTTP handling.
    public async Task<IActionResult> Delete(
        int id,
        [FromBody] DeleteConfigurationRequest request,
        CancellationToken cancellationToken)
    {
        var section = await _context.WarehouseSections.SingleOrDefaultAsync(
            item => item.SectionId == id,
            cancellationToken);
        if (section is null)
        {
            return NotFound(new { message = "The warehouse section was not found." });
        }

        var dependencies =
            await _context.ProductBatches.CountAsync(
                item => item.SectionId == id,
                cancellationToken) +
            await _context.Stocks.CountAsync(
                item => item.SectionId == id,
                cancellationToken) +
            await _context.StockMovements.CountAsync(
                item => item.SectionId == id,
                cancellationToken) +
            await _context.StockTakeSessions.CountAsync(
                item => item.SectionId == id,
                cancellationToken);
        if (dependencies > 0)
        {
            return Conflict(new
            {
                message = "This warehouse section has stock or history. Deactivate it instead."
            });
        }

        _context.WarehouseSections.Remove(section);
        await _context.SaveChangesAsync(cancellationToken);
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.Delete,
            SystemModule = AuditModules.Configuration,
            OperationName = "DeleteWarehouseSection",
            Description = "An unused warehouse section was deleted.",
            EntityType = nameof(WarehouseSection),
            EntityId = id.ToString(),
            EntityDisplay = section.SectionName,
            SafeDetails = new Dictionary<string, object?>
            {
                ["SectionCode"] = section.SectionCode,
                ["Reason"] = request.Reason.Trim()
            }
        }, cancellationToken);
        return Ok(new
        {
            message = "The unused warehouse section was deleted.",
            code = "WAREHOUSE_SECTION_DELETED"
        });
    }

    private bool TryApplyRowVersion(
        WarehouseSection section,
        string? encoded)
    {
        if (string.IsNullOrWhiteSpace(encoded))
        {
            return false;
        }
        try
        {
            _context.Entry(section)
                .Property(item => item.RowVersion)
                .OriginalValue = Convert.FromBase64String(encoded);
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
    }

    private static IQueryable<WarehouseSectionDto> Project(
        IQueryable<WarehouseSection> source) =>
        source.Select(item => new WarehouseSectionDto
        {
            SectionId = item.SectionId,
            SectionCode = item.SectionCode,
            SectionName = item.SectionName,
            Description = item.Description,
            Status = item.Status,
            CreatedAtUtc = item.CreatedAtUtc,
            UpdatedAtUtc = item.UpdatedAtUtc,
            RowVersion = Convert.ToBase64String(
                item.RowVersion ?? Array.Empty<byte>())
        });

    private static string? NullIfWhiteSpace(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
