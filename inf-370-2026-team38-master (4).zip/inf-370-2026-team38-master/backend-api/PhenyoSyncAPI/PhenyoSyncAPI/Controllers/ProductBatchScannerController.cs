using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

// Resolves scanned batch identifiers through the authoritative stock and permission rules.
namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/product-batches")]
[HasPermission(Permissions.ProductBatchScanner.View)]
public sealed class ProductBatchScannerController : ControllerBase
{
    private readonly IQrResolutionService _qr;

    public ProductBatchScannerController(IQrResolutionService qr)
    {
        _qr = qr;
    }

    [HttpGet("resolve-qr")]
    // HTTP GET at "resolve-qr" resolves a QR value to current batch and product availability.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _qr.ResolveAsync; failures use existing
    // HTTP handling.
    public Task<ProductBatchQrResultDto> Resolve(
        [FromQuery] string value,
        CancellationToken cancellationToken) =>
        _qr.ResolveAsync(value, UserId(), cancellationToken);

    private int UserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)
            ? userId
            : throw new UnauthorizedAccessException();
}
