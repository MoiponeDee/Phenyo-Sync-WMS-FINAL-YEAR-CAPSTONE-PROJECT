using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Dashboard;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

// Returns server-authorized dashboard summaries instead of trusting client role labels.
namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/dashboards")]
[Authorize]
[HasPermission(Permissions.Dashboards.View)]
public sealed class RoleDashboardsController : ControllerBase
{
    private readonly IRoleDashboardService _service;

    public RoleDashboardsController(IRoleDashboardService service)
    {
        _service = service;
    }

    [HttpGet("me")]
    // HTTP GET at "me" derives the dashboard from persisted role and effective permissions.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _service.GetAsync; failures use
    // existing HTTP handling.
    public Task<RoleDashboardDto> Get(
        [FromQuery] DateTime? fromUtc,
        [FromQuery] DateTime? toUtc,
        CancellationToken cancellationToken) =>
        _service.GetAsync(
            UserId(),
            User.FindFirstValue(ClaimTypes.Role) ?? string.Empty,
            fromUtc,
            toUtc,
            cancellationToken);

    private int UserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id)
            ? id
            : throw new PhaseCException(401, "The current session is not valid.");
}
