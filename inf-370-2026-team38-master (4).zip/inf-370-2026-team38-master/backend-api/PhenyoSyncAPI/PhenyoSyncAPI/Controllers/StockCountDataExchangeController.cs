using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/stock-count-data-exchange/json")]
/// <summary>Exposes JSON stock-count export, validation, controlled import and result download.</summary>
public sealed class StockCountDataExchangeController : ControllerBase
{
    private readonly IStockCountJsonExchangeService _exchange;

    public StockCountDataExchangeController(
        IStockCountJsonExchangeService exchange)
    {
        _exchange = exchange;
    }

    [HttpGet("schema")]
    [HasPermission(Permissions.StockCountExchange.Import)]
    public IActionResult Schema()
    {
        var file = _exchange.Schema();
        return File(file.Content, file.ContentType, file.FileName);
    }

    [HttpGet("sample")]
    [HasPermission(Permissions.StockCountExchange.Import)]
    public IActionResult Sample()
    {
        var file = _exchange.Sample();
        return File(file.Content, file.ContentType, file.FileName);
    }

    [HttpGet("export")]
    [HasPermission(Permissions.StockCountExchange.Export)]
    // HTTP GET at "export" exports the current stock-count dataset for reconciliation.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts StockCountExportQueryDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _exchange.ExportAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Export(
        [FromQuery] StockCountExportQueryDto query,
        CancellationToken cancellationToken)
    {
        var file = await _exchange.ExportAsync(query, UserId(), cancellationToken);
        return File(file.Content, file.ContentType, file.FileName);
    }

    [HttpPost("validate")]
    [HasPermission(Permissions.StockCountExchange.Import)]
    [RequestSizeLimit(26 * 1024 * 1024)]
    // HTTP POST at "validate" validates uploaded stock-count data without changing balances.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Multipart file data crosses this boundary; size, type, and content validation remains server-side
    // before any persistent change is allowed.
    // The thin controller delegates business rules and persistence to _exchange.ValidateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<DataExchangeValidationResponseDto> Validate(
        IFormFile file,
        CancellationToken cancellationToken) =>
        _exchange.ValidateAsync(
            file,
            UserId(),
            HttpContext.TraceIdentifier,
            cancellationToken);

    [HttpPost("import")]
    [HasPermission(Permissions.StockCountExchange.Import)]
    // HTTP POST at "import" applies validated stock-count data through reconciliation.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ApplyDataExchangeRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _exchange.ImportAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<DataExchangeApplyResponseDto> Import(
        [FromQuery] string validationToken,
        ApplyDataExchangeRequest request,
        CancellationToken cancellationToken) =>
        _exchange.ImportAsync(
            validationToken,
            request,
            UserId(),
            cancellationToken);

    [HttpGet("results/{resultToken}")]
    [HasPermission(Permissions.StockCountExchange.Import)]
    // HTTP GET at "results/{resultToken}" returns the protected stock-count exchange result by token.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _exchange.ResultAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Result(
        string resultToken,
        CancellationToken cancellationToken)
    {
        var file = await _exchange.ResultAsync(
            resultToken,
            UserId(),
            cancellationToken);
        return File(file.Content, file.ContentType, file.FileName);
    }

    private int UserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)
            ? userId
            : throw new UnauthorizedAccessException();
}
