using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/orders")]
[HasPermission(Permissions.Orders.View)]
/// <summary>Exposes order CRUD, commercial validation and controlled lifecycle transitions.</summary>
public sealed class OrdersController : ControllerBase
{
    private readonly IOrderService _orders;
    private readonly IOrderStockService _stock;
    private readonly IOrderWorkflowService _workflow;
    private readonly IAuditService _audit;
    private readonly ISystemSettingProvider _settings;

    public OrdersController(
        IOrderService orders,
        IOrderStockService stock,
        IOrderWorkflowService workflow,
        IAuditService audit,
        ISystemSettingProvider settings)
    {
        _orders = orders;
        _stock = stock;
        _workflow = workflow;
        _audit = audit;
        _settings = settings;
    }

    [HttpPost]
    [HasPermission(Permissions.Orders.Create)]
    // HTTP POST at the controller root creates or attaches orders data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateSalesOrderDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _orders.CreateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Create([FromBody] CreateSalesOrderDto dto, CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Sales order submitted successfully and is ready for validation.",
            order = await _orders.CreateAsync(dto, UserId(), null, cancellationToken)
        }));

    [HttpGet]
    [HttpGet("search")]
    // HTTP GET at the controller root queries filtered orders records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts OrderSearchQueryDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _orders.SearchAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Search([FromQuery] OrderSearchQueryDto query, CancellationToken cancellationToken) =>
        await Execute(async () => Ok(await _orders.SearchAsync(query, cancellationToken)));

    [HttpGet("customer-intake-configuration")]
    [HasAnyPermission(Permissions.Orders.Create, Permissions.Orders.SendLink)]
    // HTTP GET at "customer-intake-configuration" handles the customer intake configuration operation for
    // orders through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _settings.GetStringAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> CustomerIntakeConfiguration(
        CancellationToken cancellationToken)
    {
        var configuredValue = (await _settings.GetStringAsync(
            SystemSettingKeys.OrdersCustomerGoogleFormUrl,
            cancellationToken)).Trim();
        var isConfigured = Uri.TryCreate(
            configuredValue,
            UriKind.Absolute,
            out var uri) &&
            uri.Scheme == Uri.UriSchemeHttps &&
            IsGoogleFormsHost(uri);

        return Ok(new CustomerOrderIntakeConfigurationDto
        {
            GoogleFormUrl = isConfigured ? configuredValue : string.Empty,
            IsConfigured = isConfigured,
            Guidance = isConfigured
                ? "Share the customer request form, then capture the verified response as an official order."
                : "A Super Admin must configure a genuine HTTPS Google Forms URL in System Settings before customer requests can be shared."
        });
    }

    private static bool IsGoogleFormsHost(Uri uri) =>
        string.Equals(uri.Host, "forms.gle", StringComparison.OrdinalIgnoreCase) ||
        (string.Equals(
             uri.Host,
             "docs.google.com",
             StringComparison.OrdinalIgnoreCase) &&
         uri.AbsolutePath.StartsWith(
             "/forms/",
             StringComparison.OrdinalIgnoreCase));

    [HttpGet("packing-list")]
    [HasPermission(Permissions.Packing.View)]
    // HTTP GET at "packing-list" returns approved fulfilment demand, including work blocked by stock
    // shortages.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _stock.GetPackingQueueAsync; failures
    // use existing HTTP handling.
    public async Task<IActionResult> PackingQueue([FromQuery] string? searchTerm, CancellationToken cancellationToken) =>
        await Execute(async () => Ok(await _stock.GetPackingQueueAsync(searchTerm, cancellationToken)));

    [HttpGet("{id:int}")]
    // HTTP GET at "{id:int}" returns the authoritative orders projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _orders.GetAsync; failures use existing
    // HTTP handling.
    public async Task<IActionResult> Get(int id, CancellationToken cancellationToken) =>
        await Execute(async () => Ok(await _orders.GetAsync(id, cancellationToken)));

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.Orders.Update)]
    // HTTP PUT at "{id:int}" updates only allowed orders fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateSalesOrderDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _orders.UpdateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Update(int id, [FromBody] UpdateSalesOrderDto dto, CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Sales order updated and returned to Submitted for validation.",
            order = await _orders.UpdateAsync(id, dto, UserId(), cancellationToken)
        }));

    [HttpPost("{id:int}/validate")]
    [HasPermission(Permissions.Orders.Validate)]
    // HTTP POST at "{id:int}/validate" validates an approved order and activates reservation and fulfilment
    // demand.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _stock.ValidateApprovedAndReserveAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Validate(int id, CancellationToken cancellationToken) =>
        await Execute(async () =>
        {
            var result = await _stock.ValidateApprovedAndReserveAsync(
                id,
                UserId(),
                cancellationToken);
            return result.Approved ? Ok(result) : Conflict(result);
        });

    [HttpPost("{id:int}/approve")]
    [HasPermission(Permissions.Orders.Validate)]
    [HasPermission(Permissions.Orders.Confirm)]
    // HTTP POST at "{id:int}/approve" records commercial approval independently from finished-stock
    // availability.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts OrderDecisionDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _workflow.ApproveAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Approve(
        int id,
        [FromBody] OrderDecisionDto dto,
        CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Order approved. Product demand is active and warehouse readiness is pending.",
            order = await _workflow.ApproveAsync(
                id,
                dto,
                UserId(),
                cancellationToken)
        }));

    [HttpPost("{id:int}/reject")]
    [HasPermission(Permissions.Orders.Validate)]
    [HasPermission(Permissions.Orders.Confirm)]
    // HTTP POST at "{id:int}/reject" rejects a pending-validation order with an auditable reason.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts OrderDecisionDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _workflow.RejectAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Reject(
        int id,
        [FromBody] OrderDecisionDto dto,
        CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Order rejected.",
            order = await _workflow.RejectAsync(
                id,
                dto,
                UserId(),
                cancellationToken)
        }));

    [HttpPost("{id:int}/warehouse-ready")]
    [HasPermission(Permissions.Orders.ChangeStatus)]
    // HTTP POST at "{id:int}/warehouse-ready" advances an approved order through the warehouse-ready
    // transition.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts OrderDecisionDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _workflow.TransitionAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> WarehouseReady(
        int id,
        [FromBody] OrderDecisionDto dto,
        CancellationToken cancellationToken) =>
        await Execute(async () =>
        {
            var order = await _workflow.TransitionAsync(
                id,
                new UpdateOrderStatusDto
                {
                    NewStatus = SalesOrderStatuses.ReadyForDispatch,
                    Reason = dto.Reason
                },
                UserId(),
                Role(),
                cancellationToken);
            return Ok(new
            {
                message = "Packing reviewed. The order is ready for driver assignment and dispatch.",
                order
            });
        });

    [HttpPost("{id:int}/cancel")]
    [HasPermission(Permissions.Orders.Cancel)]
    // HTTP POST at "{id:int}/cancel" continues the orders workflow through its named transition.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CancelOrderDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _workflow.CancelAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Cancel(
        int id,
        [FromBody] CancelOrderDto dto,
        CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Sales order cancelled and active reservations released.",
            order = await _workflow.CancelAsync(id, dto, UserId(), cancellationToken)
        }));

    [HttpPatch("{id:int}/status")]
    [HasPermission(Permissions.Orders.ChangeStatus)]
    // HTTP PATCH at "{id:int}/status" requests a legal workflow transition instead of directly assigning a
    // status.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateOrderStatusDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _workflow.TransitionAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Status(
        int id,
        [FromBody] UpdateOrderStatusDto dto,
        CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = $"Order status updated to {dto.NewStatus}.",
            order = await _workflow.TransitionAsync(id, dto, UserId(), Role(), cancellationToken)
        }));

    [HttpGet("{id:int}/invoice")]
    [HasPermission(Permissions.Invoices.View)]
    // HTTP GET at "{id:int}/invoice" returns the invoice snapshot and records access to the document.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _workflow.GetInvoiceAsync and
    // _audit.RecordAsync; failures use existing HTTP handling.
    public async Task<IActionResult> Invoice(int id, CancellationToken cancellationToken) =>
        await Execute(async () =>
        {
            var invoice = await _workflow.GetInvoiceAsync(id, cancellationToken);
            await _audit.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.ViewSensitiveRecord,
                SystemModule = AuditModules.Invoice,
                OperationName = "ViewInvoice",
                Description = "An authorized user viewed an order invoice.",
                EntityType = nameof(Entities.Invoice),
                EntityId = invoice.InvoiceId.ToString(),
                EntityDisplay = invoice.InvoiceNumber,
                Success = true,
                EventSource = AuditEventSources.SecurityEvent
            }, cancellationToken);
            return Ok(invoice);
        });

    [HttpGet("{id:int}/packing-list")]
    [HasPermission(Permissions.Packing.View)]
    // HTTP GET at "{id:int}/packing-list" returns server-calculated required, available, packed, and
    // remaining quantities.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _stock.GetPackingListAsync; failures
    // use existing HTTP handling.
    public async Task<IActionResult> PackingList(int id, CancellationToken cancellationToken) =>
        await Execute(async () => Ok(await _stock.GetPackingListAsync(id, cancellationToken)));

    private int UserId() => int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id)
        ? id : throw new OrderManagementException(401, "The authenticated user could not be identified.");

    private string Role() => User.FindFirstValue(ClaimTypes.Role) ?? string.Empty;

    private static async Task<IActionResult> Execute(Func<Task<IActionResult>> action)
    {
        try { return await action(); }
        catch (OrderManagementException exception)
        {
            return new ObjectResult(new { message = exception.Message, details = exception.Details })
            { StatusCode = exception.StatusCode };
        }
    }
}
