using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/google-order-intake")]
/// <summary>Runs authenticated Google order synchronization and exposes safe intake outcomes.</summary>
public sealed class GoogleOrderIntakeController : ControllerBase
{
    private readonly IGoogleOrderIntakeService _service;

    public GoogleOrderIntakeController(IGoogleOrderIntakeService service)
    {
        _service = service;
    }

    [HttpPost("sync")]
    [HasPermission(Permissions.Orders.Create)]
    // HTTP POST at "sync" imports unseen Google form rows once using source-key idempotency.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.SyncAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Sync(CancellationToken cancellationToken)
    {
        try
        {
            return Ok(await _service.SyncAsync(UserId(), cancellationToken));
        }
        catch (OrderManagementException exception)
        {
            return StatusCode(
                exception.StatusCode,
                new { message = exception.Message });
        }
    }

    [HttpGet("submissions")]
    [HasPermission(Permissions.Orders.View)]
    // HTTP GET at "submissions" returns external submissions for authorized validation review.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.RecentAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Recent(
        [FromQuery] int take = 25,
        CancellationToken cancellationToken = default) =>
        Ok(await _service.RecentAsync(take, cancellationToken));

    private int UserId() =>
        int.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var userId)
            ? userId
            : throw new OrderManagementException(401, "User context is unavailable.");
}
