using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Product;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using PhenyoSyncAPI.Configuration;
using QRCoder;

namespace PhenyoSyncAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [HasPermission(Permissions.Products.View)]
    /// <summary>Returns traceable finished-product batches and their current availability.</summary>
    public class ProductBatchController : ControllerBase
    {
        private readonly PhenyoSyncDbContext _context;
        private readonly ExpiryAlertOptions _options;
        private readonly ISystemSettingProvider? _settings;

        public ProductBatchController(
            PhenyoSyncDbContext context,
            IOptions<ExpiryAlertOptions> options,
            ISystemSettingProvider? settings = null)
        {
            _context = context;
            _options = options.Value;
            _settings = settings;
        }

        [HttpGet("{id:int}")]
        // HTTP GET at "{id:int}" handles the get by id operation for product batch through the established
        // workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // LoadBatch and Thresholds keep the no-tracking query and expiry classification reusable; a missing
        // batch is mapped to 404 and an authoritative projection to 200.
        public async Task<IActionResult> GetById(int id, CancellationToken cancellationToken)
        {
            var batch = await LoadBatch(id, cancellationToken);
            var thresholds = await Thresholds(cancellationToken);
            return batch is null
                ? NotFound(new { message = "Product batch not found." })
                : Ok(ToResponse(batch, thresholds.Red, thresholds.Yellow));
        }

        [HttpGet("by-qr")]
        // HTTP GET at "by-qr" resolves or renders the requested product batch QR representation.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // The action validates the QR text, queries a no-tracking batch projection, and maps invalid, missing,
        // or successful results to 400, 404, or 200 respectively.
        public async Task<IActionResult> GetByQr([FromQuery] string value, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(value))
                return BadRequest(new { message = "QR value is required." });

            var normalized = value.Trim();
            var batch = await BaseQuery().FirstOrDefaultAsync(item =>
                item.QRCodeValue == normalized || item.BatchCode == normalized,
                cancellationToken);
            var thresholds = await Thresholds(cancellationToken);
            return batch is null
                ? NotFound(new { message = "No product batch matches this QR value." })
                : Ok(ToResponse(batch, thresholds.Red, thresholds.Yellow));
        }

        [HttpGet("{id:int}/qr-code")]
        [HasPermission(Permissions.Labels.Print)]
        // HTTP GET at "{id:int}/qr-code" resolves or renders the requested product batch QR representation.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // The thin controller delegates business rules and persistence to _settings.GetIntAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> GetQrCode(int id, CancellationToken cancellationToken)
        {
            var value = await _context.ProductBatches.AsNoTracking()
                .Where(batch => batch.ProductBatchId == id)
                .Select(batch => batch.QRCodeValue)
                .FirstOrDefaultAsync(cancellationToken);
            if (value is null) return NotFound(new { message = "Product batch not found." });

            using var generator = new QRCodeGenerator();
            using var data = generator.CreateQrCode(value, QRCodeGenerator.ECCLevel.Q);
            using var qrCode = new PngByteQRCode(data);
            return File(qrCode.GetGraphic(20), "image/png");
        }

        private Task<ProductBatch?> LoadBatch(int id, CancellationToken cancellationToken) =>
            BaseQuery().FirstOrDefaultAsync(item => item.ProductBatchId == id, cancellationToken);

        private IQueryable<ProductBatch> BaseQuery() =>
            _context.ProductBatches
                .AsNoTracking()
                .Include(batch => batch.Product)
                    .ThenInclude(product => product.ProductType)
                .Include(batch => batch.Product)
                    .ThenInclude(product => product.ProductCategory)
                .Include(batch => batch.WarehouseSection);

        private ProductBatchResponseDto ToResponse(
            ProductBatch batch,
            int redThreshold,
            int yellowThreshold)
        {
            var now = DateTime.UtcNow;
            var hours = (batch.EffectiveExpiryAtUtc - now).TotalHours;
            var level = hours <= 0
                ? ExpiryAlertLevels.Expired
                : hours <= redThreshold
                    ? ExpiryAlertLevels.Urgent
                    : hours <= yellowThreshold
                        ? ExpiryAlertLevels.Warning
                        : ExpiryAlertLevels.Normal;

            return new ProductBatchResponseDto
            {
                ProductBatchId = batch.ProductBatchId,
                ProductId = batch.ProductId,
                ProductName = batch.Product.ProductName,
                ProductTypeName = batch.Product.ProductType?.ProductTypeName ?? string.Empty,
                ProductCategoryName = batch.Product.ProductCategory?.ProductCategoryName ?? string.Empty,
                Size = batch.Product.Size,
                SectionId = batch.SectionId,
                SectionName = batch.WarehouseSection.SectionName,
                ProductCode = batch.Product.QRCodeValue ?? $"PRODUCT-{batch.ProductId:D6}",
                BatchCode = batch.BatchCode,
                QRCodeValue = batch.QRCodeValue,
                QuantityProducedKg = batch.QuantityProducedKg,
                QuantityRemainingKg = batch.QuantityRemainingKg,
                PackedAtUtc = batch.PackedAtUtc,
                OriginalExpiryAtUtc = batch.OriginalExpiryAtUtc,
                EffectiveExpiryAtUtc = batch.EffectiveExpiryAtUtc,
                Status = batch.Status,
                ShelfLifeExtended = batch.ShelfLifeExtended,
                AlertLevel = level,
                RemainingHours = hours
            };
        }

        private async Task<(int Red, int Yellow)> Thresholds(
            CancellationToken cancellationToken)
        {
            if (_settings is null)
            {
                return (
                    _options.RedThresholdHours,
                    _options.YellowThresholdHours);
            }
            return (
                await _settings.GetIntAsync(
                    SystemSettingKeys.ExpiryRedThresholdHours,
                    cancellationToken),
                await _settings.GetIntAsync(
                    SystemSettingKeys.ExpiryYellowThresholdHours,
                    cancellationToken));
        }
    }
}
