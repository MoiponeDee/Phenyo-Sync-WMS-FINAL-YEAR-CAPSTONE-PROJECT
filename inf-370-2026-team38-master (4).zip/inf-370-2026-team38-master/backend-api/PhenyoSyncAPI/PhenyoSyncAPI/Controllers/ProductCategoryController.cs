using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Lookups;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [HasPermission(Permissions.ProductCategories.View)]
    /// <summary>Exposes Product Category master-data operations under category permissions.</summary>
    public class ProductCategoryController : ControllerBase
    {
        private readonly PhenyoSyncDbContext _context;

        public ProductCategoryController(PhenyoSyncDbContext context) => _context = context;

        [HttpGet]
        // HTTP GET at the controller root returns the authoritative product category projection needed by the
        // client.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // EF queries are projected to response data rather than exposing tracked entities.
        public Task<List<ProductCategoryDto>> GetAll(
            [FromQuery] string? searchTerm,
            [FromQuery] string? status,
            CancellationToken cancellationToken)
        {
            var query = _context.ProductCategories.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                var term = searchTerm.Trim();
                query = query.Where(item =>
                    item.ProductCategoryName.Contains(term) ||
                    (item.Description != null && item.Description.Contains(term)));
            }
            if (!string.IsNullOrWhiteSpace(status)) query = query.Where(item => item.Status == status);
            return Project(query).OrderBy(item => item.ProductCategoryName).ToListAsync(cancellationToken);
        }

        [HttpGet("active")]
        // HTTP GET at "active" handles the get active operation for product category through the established
        // workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // EF queries are projected to response data rather than exposing tracked entities.
        public Task<List<ProductCategoryDto>> GetActive(CancellationToken cancellationToken) =>
            Project(_context.ProductCategories.AsNoTracking().Where(item => item.Status == ProductStatuses.Active))
                .OrderBy(item => item.ProductCategoryName)
                .ToListAsync(cancellationToken);

        [HttpGet("{id:int}")]
        // HTTP GET at "{id:int}" handles the get by id operation for product category through the established
        // workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // EF queries are projected to response data rather than exposing tracked entities.
        public async Task<IActionResult> GetById(int id, CancellationToken cancellationToken)
        {
            var item = await Project(_context.ProductCategories.AsNoTracking())
                .FirstOrDefaultAsync(category => category.ProductCategoryId == id, cancellationToken);
            return item is null ? NotFound(new { message = "Product category not found." }) : Ok(item);
        }

        [HttpPost]
        [HasPermission(Permissions.ProductCategories.Manage)]
        // HTTP POST at the controller root creates or attaches product category data through the controlled API
        // boundary.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts SaveProductCategoryDto instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> Create(SaveProductCategoryDto dto, CancellationToken cancellationToken)
        {
            var name = dto.ProductCategoryName.Trim();
            if (await NameExists(name, null, cancellationToken))
                return Conflict(new { message = "A product category with this name already exists." });
            var item = new ProductCategory
            {
                ProductCategoryName = name,
                Description = dto.Description?.Trim(),
                Status = ProductStatuses.Active,
                CreatedAt = DateTime.UtcNow
            };
            _context.ProductCategories.Add(item);
            await _context.SaveChangesAsync(cancellationToken);
            return CreatedAtAction(nameof(GetById), new { id = item.ProductCategoryId }, new
            {
                message = "Product category created successfully.",
                productCategoryId = item.ProductCategoryId
            });
        }

        [HttpPut("{id:int}")]
        [HasPermission(Permissions.ProductCategories.Manage)]
        // HTTP PUT at "{id:int}" updates only allowed product category fields through a narrow request.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts SaveProductCategoryDto instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> Update(int id, SaveProductCategoryDto dto, CancellationToken cancellationToken)
        {
            var item = await _context.ProductCategories.FindAsync([id], cancellationToken);
            if (item is null) return NotFound(new { message = "Product category not found." });
            var name = dto.ProductCategoryName.Trim();
            if (await NameExists(name, id, cancellationToken))
                return Conflict(new { message = "A product category with this name already exists." });
            item.ProductCategoryName = name;
            item.Description = dto.Description?.Trim();
            item.Status = dto.Status;
            item.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync(cancellationToken);
            return Ok(new { message = "Product category updated successfully." });
        }

        [HttpDelete("{id:int}")]
        [HasPermission(Permissions.ProductCategories.Manage)]
        // HTTP DELETE at "{id:int}" removes or retires product category data after dependency checks.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> Delete(int id, CancellationToken cancellationToken)
        {
            var item = await _context.ProductCategories.FindAsync([id], cancellationToken);
            if (item is null) return NotFound(new { message = "Product category not found." });
            if (await _context.Products.AnyAsync(product => product.ProductCategoryId == id, cancellationToken))
                return Conflict(new { message = "This product category is in use and cannot be deleted. Mark it Inactive instead." });
            _context.ProductCategories.Remove(item);
            await _context.SaveChangesAsync(cancellationToken);
            return Ok(new { message = "Product category deleted successfully." });
        }

        private Task<bool> NameExists(string name, int? excludedId, CancellationToken cancellationToken)
        {
            var normalized = name.ToUpper();
            return _context.ProductCategories.AnyAsync(item =>
                item.ProductCategoryId != excludedId &&
                item.ProductCategoryName.ToUpper() == normalized,
                cancellationToken);
        }

        private static IQueryable<ProductCategoryDto> Project(IQueryable<ProductCategory> query) =>
            query.Select(item => new ProductCategoryDto
            {
                ProductCategoryId = item.ProductCategoryId,
                ProductCategoryName = item.ProductCategoryName,
                Description = item.Description,
                Status = item.Status,
                CreatedAt = item.CreatedAt,
                UpdatedAt = item.UpdatedAt
            });
    }
}
