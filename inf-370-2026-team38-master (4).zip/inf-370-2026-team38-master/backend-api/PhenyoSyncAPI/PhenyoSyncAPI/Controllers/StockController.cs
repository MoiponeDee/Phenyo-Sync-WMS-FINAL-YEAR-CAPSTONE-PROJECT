using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Legacy;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/stock")]
[Authorize]
/// <summary>Returns finished-stock balances while stock mutations remain in controlled services.</summary>
public sealed class StockController : ControllerBase
{
    private readonly PhenyoSyncDbContext _context;

    public StockController(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    [HttpPost("session")]
    [HasPermission(Permissions.Stock.Take)]
    // HTTP POST at "session" handles the start session operation for stock through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts StartStockTakeRequest instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> StartSession(
        [FromBody] StartStockTakeRequest request,
        CancellationToken cancellationToken)
    {
        if (!await _context.WarehouseSections.AnyAsync(
                item => item.SectionId == request.SectionId,
                cancellationToken))
        {
            return BadRequest(new
            {
                message = "Select a valid warehouse section."
            });
        }

        var session = new StockTakeSession
        {
            UserId = CurrentUserId(),
            SectionId = request.SectionId,
            SessionDate = DateTime.UtcNow,
            Status = "Open",
            Notes = string.IsNullOrWhiteSpace(request.Notes)
                ? null
                : request.Notes.Trim()
        };
        _context.StockTakeSessions.Add(session);
        await _context.SaveChangesAsync(cancellationToken);

        return StatusCode(
            StatusCodes.Status201Created,
            new
            {
                message = "The stock-take session was started.",
                code = "STOCK_TAKE_STARTED",
                sessionId = session.SessionId
            });
    }

    [HttpGet("session")]
    [HasPermission(Permissions.Stock.View)]
    // HTTP GET at "session" handles the get sessions operation for stock through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> GetSessions(
        CancellationToken cancellationToken) =>
        Ok(await _context.StockTakeSessions
            .AsNoTracking()
            .OrderByDescending(item => item.SessionDate)
            .Select(item => new
            {
                item.SessionId,
                item.UserId,
                item.SectionId,
                item.SessionDate,
                item.Status,
                item.Notes
            })
            .ToListAsync(cancellationToken));

    private int CurrentUserId() =>
        int.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var userId)
            ? userId
            : throw new UnauthorizedAccessException();
}
