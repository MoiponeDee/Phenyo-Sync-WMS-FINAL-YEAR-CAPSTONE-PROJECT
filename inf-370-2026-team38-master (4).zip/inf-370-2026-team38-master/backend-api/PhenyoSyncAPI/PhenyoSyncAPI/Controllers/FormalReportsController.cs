using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.DTOs.Reports;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services.Reports;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Authorize]
[Route("api/reports")]
[HasPermission(Permissions.Reports.View)]
/// <summary>Creates permission-filtered previews and PDFs from short-lived report snapshots.</summary>
public sealed class FormalReportsController : ControllerBase
{
    private const string InventoryKey = "inventory";
    private const string SalesKey = "sales";
    private const string FinancialKey = "financial";
    private const string StockMovementKey = "stock-movement";
    private const string ExpiryWasteKey = "expiry-waste";
    private const string PricingKey = "pricing";
    private const string MarkupKey = "markup";

    private readonly IFormalReportService _reports;
    private readonly IReportSnapshotStore _snapshots;
    private readonly IReportPdfService _pdf;
    private readonly IPermissionService _permissions;
    private readonly IAuditService _audit;

    public FormalReportsController(
        IFormalReportService reports,
        IReportSnapshotStore snapshots,
        IReportPdfService pdf,
        IPermissionService permissions,
        IAuditService audit)
    {
        _reports = reports;
        _snapshots = snapshots;
        _pdf = pdf;
        _permissions = permissions;
        _audit = audit;
    }

    [HttpGet("options")]
    // HTTP GET at "options" returns the authoritative formal reports projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _reports.GetOptionsAsync; failures use
    // existing HTTP handling.
    public async Task<ActionResult<ReportOptionsDto>> Options(
        CancellationToken cancellationToken) =>
        Ok(await _reports.GetOptionsAsync(cancellationToken));

    [HttpPost("inventory/preview")]
    [HasPermission(Permissions.Reports.InventoryView)]
    // HTTP POST at "inventory/preview" builds a read-only formal reports preview before PDF export.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts InventoryReportCriteriaDto instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _reports.InventoryAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<InventoryReportDto>> InventoryPreview(
        [FromBody] InventoryReportCriteriaDto criteria,
        CancellationToken cancellationToken)
    {
        var report = await _reports.InventoryAsync(
            criteria,
            UserId(),
            cancellationToken);
        return Ok(await StorePreviewAsync(
            InventoryKey,
            report,
            report.Metadata,
            cancellationToken));
    }

    [HttpPost("inventory/pdf")]
    [HasPermission(Permissions.Reports.InventoryExportPdf)]
    // HTTP POST at "inventory/pdf" generates or streams the formal reports PDF from authoritative data.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReportPdfRequestDto instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // PdfAsync binds the preview token to that actor, generates the file and records the export audit.
    public Task<IActionResult> InventoryPdf(
        [FromBody] ReportPdfRequestDto request,
        CancellationToken cancellationToken) =>
        PdfAsync<InventoryReportDto>(
            InventoryKey,
            request,
            cancellationToken);

    [HttpPost("sales/preview")]
    [HasPermission(Permissions.Reports.SalesView)]
    // HTTP POST at "sales/preview" builds a read-only formal reports preview before PDF export.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SalesReportCriteriaDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _reports.SalesAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<SalesReportDto>> SalesPreview(
        [FromBody] SalesReportCriteriaDto criteria,
        CancellationToken cancellationToken)
    {
        var report = await _reports.SalesAsync(
            criteria,
            UserId(),
            cancellationToken);
        return Ok(await StorePreviewAsync(
            SalesKey,
            report,
            report.Metadata,
            cancellationToken));
    }

    [HttpPost("sales/pdf")]
    [HasPermission(Permissions.Reports.SalesExportPdf)]
    // HTTP POST at "sales/pdf" generates or streams the formal reports PDF from authoritative data.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReportPdfRequestDto instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // PdfAsync binds the preview token to that actor, generates the file and records the export audit.
    public Task<IActionResult> SalesPdf(
        [FromBody] ReportPdfRequestDto request,
        CancellationToken cancellationToken) =>
        PdfAsync<SalesReportDto>(
            SalesKey,
            request,
            cancellationToken);

    [HttpPost("financial/preview")]
    [HasPermission(Permissions.Reports.FinancialView)]
    // HTTP POST at "financial/preview" builds a read-only formal reports preview before PDF export.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts FinancialReportCriteriaDto instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _reports.FinancialAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<FinancialReportDto>> FinancialPreview(
        [FromBody] FinancialReportCriteriaDto criteria,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        var report = await _reports.FinancialAsync(
            criteria,
            userId,
            await HasPermissionAsync(
                userId,
                Permissions.Reports.FinancialViewCost,
                cancellationToken),
            await HasPermissionAsync(
                userId,
                Permissions.Reports.FinancialViewReversalHistory,
                cancellationToken),
            cancellationToken);
        return Ok(await StorePreviewAsync(
            FinancialKey,
            report,
            report.Metadata,
            cancellationToken));
    }

    [HttpPost("financial/pdf")]
    [HasPermission(Permissions.Reports.FinancialExportPdf)]
    // HTTP POST at "financial/pdf" generates or streams the formal reports PDF from authoritative data.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReportPdfRequestDto instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // PdfAsync binds the preview token to that actor, generates the file and records the export audit.
    public Task<IActionResult> FinancialPdf(
        [FromBody] ReportPdfRequestDto request,
        CancellationToken cancellationToken) =>
        PdfAsync<FinancialReportDto>(
            FinancialKey,
            request,
            cancellationToken);

    [HttpPost("stock-movement/preview")]
    [HasPermission(Permissions.Reports.StockMovementView)]
    // HTTP POST at "stock-movement/preview" builds a read-only formal reports preview before PDF export.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts StockMovementReportCriteriaDto instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _reports.StockMovementAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<StockMovementReportDto>> StockMovementPreview(
        [FromBody] StockMovementReportCriteriaDto criteria,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        var report = await _reports.StockMovementAsync(
            criteria,
            userId,
            await HasPermissionAsync(
                userId,
                Permissions.Reports.StockMovementViewCost,
                cancellationToken),
            cancellationToken);
        return Ok(await StorePreviewAsync(
            StockMovementKey,
            report,
            report.Metadata,
            cancellationToken));
    }

    [HttpPost("stock-movement/pdf")]
    [HasPermission(Permissions.Reports.StockMovementExportPdf)]
    // HTTP POST at "stock-movement/pdf" generates or streams the formal reports PDF from authoritative data.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReportPdfRequestDto instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // PdfAsync binds the preview token to that actor, generates the file and records the export audit.
    public Task<IActionResult> StockMovementPdf(
        [FromBody] ReportPdfRequestDto request,
        CancellationToken cancellationToken) =>
        PdfAsync<StockMovementReportDto>(
            StockMovementKey,
            request,
            cancellationToken);

    [HttpPost("expiry-waste/preview")]
    [HasPermission(Permissions.Reports.ExpiryWasteView)]
    // HTTP POST at "expiry-waste/preview" builds a read-only formal reports preview before PDF export.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ExpiryWasteReportCriteriaDto instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _reports.ExpiryWasteAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<ExpiryWasteReportDto>> ExpiryWastePreview(
        [FromBody] ExpiryWasteReportCriteriaDto criteria,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        var report = await _reports.ExpiryWasteAsync(
            criteria,
            userId,
            await HasPermissionAsync(
                userId,
                Permissions.Reports.ExpiryWasteViewCost,
                cancellationToken),
            cancellationToken);
        return Ok(await StorePreviewAsync(
            ExpiryWasteKey,
            report,
            report.Metadata,
            cancellationToken));
    }

    [HttpPost("expiry-waste/pdf")]
    [HasPermission(Permissions.Reports.ExpiryWasteExportPdf)]
    // HTTP POST at "expiry-waste/pdf" generates or streams the formal reports PDF from authoritative data.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReportPdfRequestDto instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // PdfAsync binds the preview token to that actor, generates the file and records the export audit.
    public Task<IActionResult> ExpiryWastePdf(
        [FromBody] ReportPdfRequestDto request,
        CancellationToken cancellationToken) =>
        PdfAsync<ExpiryWasteReportDto>(
            ExpiryWasteKey,
            request,
            cancellationToken);

    [HttpPost("pricing/preview")]
    [HasPermission(Permissions.Reports.PricingView)]
    // HTTP POST at "pricing/preview" builds a read-only formal reports preview before PDF export.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts PricingReportCriteriaDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _reports.PricingAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<PricingReportDto>> PricingPreview(
        [FromBody] PricingReportCriteriaDto criteria,
        CancellationToken cancellationToken)
    {
        var report = await _reports.PricingAsync(
            criteria,
            UserId(),
            cancellationToken);
        return Ok(await StorePreviewAsync(
            PricingKey,
            report,
            report.Metadata,
            cancellationToken));
    }

    [HttpPost("pricing/pdf")]
    [HasPermission(Permissions.Reports.PricingExportPdf)]
    // HTTP POST at "pricing/pdf" generates or streams the formal reports PDF from authoritative data.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReportPdfRequestDto instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // PdfAsync binds the preview token to that actor, generates the file and records the export audit.
    public Task<IActionResult> PricingPdf(
        [FromBody] ReportPdfRequestDto request,
        CancellationToken cancellationToken) =>
        PdfAsync<PricingReportDto>(
            PricingKey,
            request,
            cancellationToken);

    [HttpPost("markup/preview")]
    [HasPermission(Permissions.Reports.MarkupView)]
    // HTTP POST at "markup/preview" builds a read-only formal reports preview before PDF export.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts MarkupReportCriteriaDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _reports.MarkupAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<MarkupReportDto>> MarkupPreview(
        [FromBody] MarkupReportCriteriaDto criteria,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        var report = await _reports.MarkupAsync(
            criteria,
            userId,
            await HasPermissionAsync(
                userId,
                Permissions.Reports.MarkupViewCost,
                cancellationToken),
            cancellationToken);
        return Ok(await StorePreviewAsync(
            MarkupKey,
            report,
            report.Metadata,
            cancellationToken));
    }

    [HttpPost("markup/pdf")]
    [HasPermission(Permissions.Reports.MarkupExportPdf)]
    // HTTP POST at "markup/pdf" generates or streams the formal reports PDF from authoritative data.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReportPdfRequestDto instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // PdfAsync binds the preview token to that actor, generates the file and records the export audit.
    public Task<IActionResult> MarkupPdf(
        [FromBody] ReportPdfRequestDto request,
        CancellationToken cancellationToken) =>
        PdfAsync<MarkupReportDto>(
            MarkupKey,
            request,
            cancellationToken);

    private async Task<TReport> StorePreviewAsync<TReport>(
        string reportKey,
        TReport report,
        ReportMetadataDto metadata,
        CancellationToken cancellationToken)
        where TReport : class
    {
        metadata.PreviewToken = _snapshots.Store(
            UserId(),
            reportKey,
            report);
        await RecordAuditAsync(
            AuditActionTypes.GenerateReport,
            $"Generate{Pascal(reportKey)}ReportPreview",
            reportKey,
            metadata,
            cancellationToken);
        return report;
    }

    private async Task<IActionResult> PdfAsync<TReport>(
        string reportKey,
        ReportPdfRequestDto request,
        CancellationToken cancellationToken)
        where TReport : class
    {
        var report = _snapshots.Get<TReport>(
            UserId(),
            reportKey,
            request.PreviewToken);
        var file = _pdf.Generate(report);
        await RecordAuditAsync(
            AuditActionTypes.Export,
            $"Export{Pascal(reportKey)}ReportPdf",
            reportKey,
            Metadata(report),
            cancellationToken);
        return File(file.Content, "application/pdf", file.FileName);
    }

    private async Task RecordAuditAsync(
        string actionType,
        string operationName,
        string reportKey,
        ReportMetadataDto metadata,
        CancellationToken cancellationToken)
    {
        await _audit.RecordAsync(new AuditEvent
        {
            ActionType = actionType,
            SystemModule = AuditModules.Reports,
            OperationName = operationName,
            Description = actionType == AuditActionTypes.Export
                ? $"The {metadata.Title} was exported as a PDF."
                : $"The {metadata.Title} preview was generated.",
            EntityType = "FormalReport",
            EntityId = reportKey,
            EntityDisplay = metadata.Title,
            SafeDetails = new Dictionary<string, object?>
            {
                ["ReportKey"] = reportKey,
                ["Classification"] = metadata.Classification,
                ["RecordCount"] = metadata.RecordCount,
                ["GeneratedAtUtc"] = metadata.GeneratedAtUtc,
                ["Criteria"] = metadata.Criteria
            }
        }, cancellationToken);
    }

    private Task<bool> HasPermissionAsync(
        int userId,
        string permissionCode,
        CancellationToken cancellationToken) =>
        _permissions.HasPermissionAsync(
            userId,
            permissionCode,
            cancellationToken);

    private int UserId()
    {
        if (int.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var userId))
        {
            return userId;
        }

        throw new UnauthorizedAccessException(
            "The authenticated user identity is invalid.");
    }

    private static string Pascal(string reportKey) =>
        string.Concat(
            reportKey.Split(
                    '-',
                    StringSplitOptions.RemoveEmptyEntries)
                .Select(value => char.ToUpperInvariant(value[0]) + value[1..]));

    private static ReportMetadataDto Metadata<TReport>(TReport report) =>
        report switch
        {
            InventoryReportDto value => value.Metadata,
            SalesReportDto value => value.Metadata,
            FinancialReportDto value => value.Metadata,
            StockMovementReportDto value => value.Metadata,
            ExpiryWasteReportDto value => value.Metadata,
            PricingReportDto value => value.Metadata,
            MarkupReportDto value => value.Metadata,
            _ => throw new InvalidOperationException(
                "The report type is not supported for PDF export.")
        };
}
