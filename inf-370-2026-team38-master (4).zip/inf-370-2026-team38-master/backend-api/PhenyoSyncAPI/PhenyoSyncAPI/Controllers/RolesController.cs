using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Security;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/roles")]
[Authorize]
/// <summary>Manages persisted roles while keeping friendly UI labels separate from role codes.</summary>
public sealed class RolesController : ControllerBase
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditService _auditService;

    public RolesController(
        PhenyoSyncDbContext context,
        IAuditService auditService)
    {
        _context = context;
        _auditService = auditService;
    }

    [HttpGet]
    [HasPermission(Permissions.Roles.View)]
    // HTTP GET at the controller root queries filtered roles records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RoleSearchQuery instead of an EF entity, limiting fields and preventing over-posting.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Search(
        [FromQuery] RoleSearchQuery query,
        CancellationToken cancellationToken)
    {
        var roles = _context.Roles.AsNoTracking().AsQueryable();
        if (!query.IncludeInactive)
        {
            roles = roles.Where(item => item.IsActive);
        }

        if (!string.IsNullOrWhiteSpace(query.Search))
        {
            var search = query.Search.Trim();
            roles = roles.Where(item =>
                item.RoleName.Contains(search) ||
                item.RoleCode.Contains(search));
        }

        var items = await roles
            .OrderByDescending(item => item.IsSystemRole)
            .ThenBy(item => item.RoleName)
            .Select(item => new
            {
                item.RoleId,
                item.RoleCode,
                item.RoleName,
                item.Description,
                item.IsSystemRole,
                item.IsActive,
                assignedUsers = item.Users.Count,
                effectivePermissionCount = item.RolePermissions.Count(mapping =>
                    mapping.Permission != null &&
                    mapping.Permission.IsActive),
                rowVersion = Convert.ToBase64String(
                    item.RowVersion ?? Array.Empty<byte>())
            })
            .ToListAsync(cancellationToken);

        return Ok(items);
    }

    [HttpGet("active")]
    [HasPermission(Permissions.Roles.View)]
    // HTTP GET at "active" returns the authoritative roles projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Active(
        CancellationToken cancellationToken)
    {
        var userId = int.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var parsedUserId)
            ? parsedUserId
            : 0;
        var mayAssignSuperAdmin = userId > 0 &&
            await _context.Users.AsNoTracking().AnyAsync(
                user =>
                    user.UserId == userId &&
                    user.Status == "Active" &&
                    user.Role != null &&
                    user.Role.IsActive &&
                    user.Role.RoleCode == RoleCodes.Admin,
                cancellationToken);

        return Ok(await _context.Roles
            .AsNoTracking()
            .Where(item =>
                item.IsActive &&
                (mayAssignSuperAdmin || item.RoleCode != RoleCodes.Admin))
            .OrderBy(item => item.RoleName)
            .Select(item => new
            {
                item.RoleId,
                item.RoleCode,
                roleName = item.RoleCode == RoleCodes.Admin
                    ? "Super Admin"
                    : item.RoleCode == RoleCodes.AdminClerk
                        ? "Admin"
                        : item.RoleName
            })
            .ToListAsync(cancellationToken));
    }

    [HttpGet("{id:int}")]
    [HasPermission(Permissions.Roles.View)]
    // HTTP GET at "{id:int}" returns the authoritative roles projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Get(
        int id,
        CancellationToken cancellationToken)
    {
        var role = await _context.Roles
            .AsNoTracking()
            .Where(item => item.RoleId == id)
            .Select(item => new
            {
                item.RoleId,
                item.RoleCode,
                item.RoleName,
                item.Description,
                item.IsSystemRole,
                item.IsActive,
                assignedUsers = item.Users.Count,
                permissionIds = item.RolePermissions
                    .Where(mapping =>
                        mapping.Permission != null &&
                        mapping.Permission.IsActive)
                    .Select(mapping => mapping.PermissionId)
                    .ToArray(),
                rowVersion = Convert.ToBase64String(
                    item.RowVersion ?? Array.Empty<byte>())
            })
            .SingleOrDefaultAsync(cancellationToken);

        return role is null
            ? NotFound(new { message = "The selected role was not found." })
            : Ok(role);
    }

    [HttpPost]
    [HasPermission(Permissions.Roles.Create)]
    // HTTP POST at the controller root creates or attaches roles data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateRoleRequest instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Create(
        [FromBody] CreateRoleRequest request,
        CancellationToken cancellationToken)
    {
        var code = request.RoleCode.Trim();
        var name = request.RoleName.Trim();
        if (await _context.Roles.AnyAsync(
                item => item.RoleCode == code || item.RoleName == name,
                cancellationToken))
        {
            return Conflict(new
            {
                message = "A role with this code or name already exists."
            });
        }

        var role = new Role
        {
            RoleCode = code,
            RoleName = name,
            Description = NullIfWhiteSpace(request.Description),
            IsSystemRole = false,
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        _context.Roles.Add(role);

        if (request.CopyFromRoleId.HasValue)
        {
            var permissionIds = await _context.RolePermissions
                .Where(item => item.RoleId == request.CopyFromRoleId)
                .Select(item => item.PermissionId)
                .ToListAsync(cancellationToken);
            foreach (var permissionId in permissionIds)
            {
                role.RolePermissions.Add(new RolePermission
                {
                    PermissionId = permissionId,
                    AssignedByUserId = CurrentUserId(),
                    AssignedAtUtc = DateTime.UtcNow
                });
            }
        }

        await _context.SaveChangesAsync(cancellationToken);
        return CreatedAtAction(
            nameof(Get),
            new { id = role.RoleId },
            new
            {
                message = request.CopyFromRoleId.HasValue
                    ? "The custom role was created with copied permissions."
                    : "The custom role was created without permissions.",
                code = "ROLE_CREATED",
                roleId = role.RoleId
            });
    }

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.Roles.Update)]
    // HTTP PUT at "{id:int}" updates only allowed roles fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateRoleRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> Update(
        int id,
        [FromBody] UpdateRoleRequest request,
        CancellationToken cancellationToken)
    {
        var role = await _context.Roles.SingleOrDefaultAsync(
            item => item.RoleId == id,
            cancellationToken);
        if (role is null)
        {
            return NotFound(new { message = "The selected role was not found." });
        }

        var name = request.RoleName.Trim();
        if (await _context.Roles.AnyAsync(
                item => item.RoleId != id && item.RoleName == name,
                cancellationToken))
        {
            return Conflict(new { message = "This role name is already used." });
        }

        if (!TryApplyRowVersion(role, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The role version is invalid. Refresh and try again."
            });
        }

        role.RoleName = name;
        role.Description = NullIfWhiteSpace(request.Description);
        role.UpdatedAtUtc = DateTime.UtcNow;
        await TouchRoleUsers(role.RoleId, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new
        {
            message = "The role was updated successfully.",
            code = "ROLE_UPDATED"
        });
    }

    [HttpPost("{id:int}/status")]
    [HasPermission(Permissions.Roles.Deactivate)]
    // HTTP POST at "{id:int}/status" changes roles state only through the supported status operation.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RoleStatusRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> ChangeStatus(
        int id,
        [FromBody] RoleStatusRequest request,
        CancellationToken cancellationToken)
    {
        var role = await _context.Roles.SingleOrDefaultAsync(
            item => item.RoleId == id,
            cancellationToken);
        if (role is null)
        {
            return NotFound(new { message = "The selected role was not found." });
        }

        if (!TryApplyRowVersion(role, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The role version is invalid. Refresh and try again."
            });
        }

        var activeUsers = await _context.Users.CountAsync(
            item => item.RoleId == id && item.Status == "Active",
            cancellationToken);
        if (!request.IsActive && activeUsers > 0)
        {
            return Conflict(new
            {
                message =
                    "Reassign or deactivate all active users before deactivating this role."
            });
        }

        role.IsActive = request.IsActive;
        role.UpdatedAtUtc = DateTime.UtcNow;
        await TouchRoleUsers(role.RoleId, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);

        await RecordRoleEvent(
            role,
            request.IsActive
                ? AuditActionTypes.Activate
                : AuditActionTypes.Deactivate,
            request.Reason,
            cancellationToken);

        return Ok(new
        {
            message = request.IsActive
                ? "The role was activated successfully."
                : "The role was deactivated successfully.",
            code = request.IsActive ? "ROLE_ACTIVATED" : "ROLE_DEACTIVATED"
        });
    }

    [HttpPut("{id:int}/permissions")]
    [HasPermission(Permissions.Roles.AssignPermissions)]
    // HTTP PUT at "{id:int}/permissions" changes the controlled roles assignment after eligibility checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts AssignRolePermissionsRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> AssignPermissions(
        int id,
        [FromBody] AssignRolePermissionsRequest request,
        CancellationToken cancellationToken)
    {
        var role = await _context.Roles
            .Include(item => item.RolePermissions)
            .SingleOrDefaultAsync(
                item => item.RoleId == id,
                cancellationToken);
        if (role is null)
        {
            return NotFound(new { message = "The selected role was not found." });
        }

        if (!TryApplyRowVersion(role, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The role version is invalid. Refresh and try again."
            });
        }

        var requestedIds = request.PermissionIds.Distinct().ToArray();
        var validIds = await _context.Permissions
            .Where(item =>
                requestedIds.Contains(item.PermissionId) &&
                item.IsActive)
            .Select(item => item.PermissionId)
            .ToListAsync(cancellationToken);
        if (validIds.Count != requestedIds.Length)
        {
            return BadRequest(new
            {
                message = "One or more selected permissions are invalid or inactive."
            });
        }

        _context.RolePermissions.RemoveRange(role.RolePermissions);
        role.RolePermissions = validIds
            .Select(permissionId => new RolePermission
            {
                RoleId = role.RoleId,
                PermissionId = permissionId,
                AssignedByUserId = CurrentUserId(),
                AssignedAtUtc = DateTime.UtcNow
            })
            .ToList();
        role.UpdatedAtUtc = DateTime.UtcNow;
        await TouchRoleUsers(role.RoleId, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);

        await RecordRoleEvent(
            role,
            AuditActionTypes.Update,
            request.Reason,
            cancellationToken);

        return Ok(new
        {
            message = "The role permissions were updated successfully.",
            code = "ROLE_PERMISSIONS_UPDATED",
            permissionCount = validIds.Count
        });
    }

    [HttpDelete("{id:int}")]
    [HasPermission(Permissions.Roles.Delete)]
    // HTTP DELETE at "{id:int}" removes or retires roles data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _auditService.RecordAsync; failures use existing HTTP handling.
    public async Task<IActionResult> Delete(
        int id,
        CancellationToken cancellationToken)
    {
        var role = await _context.Roles
            .Include(item => item.RolePermissions)
            .SingleOrDefaultAsync(
                item => item.RoleId == id,
                cancellationToken);
        if (role is null)
        {
            return NotFound(new { message = "The selected role was not found." });
        }

        if (role.IsSystemRole)
        {
            return Conflict(new { message = "System roles cannot be deleted." });
        }

        if (await _context.Users.AnyAsync(
                item => item.RoleId == id,
                cancellationToken) ||
            role.RolePermissions.Count > 0)
        {
            return Conflict(new
            {
                message =
                    "This role has dependencies. Deactivate it instead."
            });
        }

        _context.Roles.Remove(role);
        await _context.SaveChangesAsync(cancellationToken);
        return Ok(new
        {
            message = "The unused custom role was deleted.",
            code = "ROLE_DELETED"
        });
    }

    private async Task TouchRoleUsers(
        int roleId,
        CancellationToken cancellationToken)
    {
        var users = await _context.Users
            .Where(item => item.RoleId == roleId)
            .ToListAsync(cancellationToken);
        foreach (var user in users)
        {
            user.SecurityVersion++;
            user.UpdatedAtUtc = DateTime.UtcNow;
        }
    }

    private Task RecordRoleEvent(
        Role role,
        string action,
        string reason,
        CancellationToken cancellationToken) =>
        _auditService.RecordAsync(new AuditEvent
        {
            ActionType = action,
            SystemModule = AuditModules.Permissions,
            OperationName = "ManageRole",
            Description = "A role security configuration was changed.",
            EntityType = nameof(Role),
            EntityId = role.RoleId.ToString(),
            EntityDisplay = role.RoleName,
            SafeDetails = new Dictionary<string, object?>
            {
                ["RoleCode"] = role.RoleCode,
                ["Reason"] = reason.Trim()
            }
        }, cancellationToken);

    private bool TryApplyRowVersion(Role role, string rowVersion)
    {
        try
        {
            _context.Entry(role)
                .Property(item => item.RowVersion)
                .OriginalValue = Convert.FromBase64String(rowVersion);
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
    }

    private int CurrentUserId() =>
        int.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var userId)
            ? userId
            : throw new UnauthorizedAccessException();

    private static string? NullIfWhiteSpace(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
