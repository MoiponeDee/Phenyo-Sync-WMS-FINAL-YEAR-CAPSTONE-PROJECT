using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Mobile;
using PhenyoSyncAPI.DTOs.BuyingLists;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

public abstract class MobileControllerBase : ControllerBase
{
    protected int UserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id)
            ? id
            : throw new PhaseCException(401, "The mobile session is not valid.");

    protected string Role() =>
        RoleCodes.Normalize(User.FindFirstValue(ClaimTypes.Role));

    protected static string Correlation(HttpContext context) =>
        context.TraceIdentifier;
}

[ApiController]
[Authorize]
[Route("api/mobile")]
/// <summary>Returns the signed-in operator's permission-filtered mobile workload.</summary>
public sealed class MobileDashboardController : MobileControllerBase
{
    private readonly IMobileDashboardService _mobile;
    private readonly IPermissionService _permissions;

    public MobileDashboardController(
        IMobileDashboardService mobile,
        IPermissionService permissions)
    {
        _mobile = mobile;
        _permissions = permissions;
    }

    [HttpGet("dashboard")]
    // HTTP GET at "dashboard" returns the authoritative mobile dashboard projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Multipart file data crosses this boundary; size, type, and content validation remains server-side
    // before any persistent change is allowed.
    // The thin controller delegates business rules and persistence to _mobile.GetAsync; failures use existing
    // HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<MobileDashboardDto> Dashboard(CancellationToken cancellationToken) =>
        _mobile.GetAsync(UserId(), cancellationToken);

    [HttpGet("deliveries")]
    [HasPermission(Permissions.Mobile.DeliveryViewOwn)]
    // HTTP GET at "deliveries" handles the deliveries operation for mobile dashboard through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Multipart file data crosses this boundary; size, type, and content validation remains server-side
    // before any persistent change is allowed.
    // The thin controller delegates business rules and persistence to _mobile.DeliveriesAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IReadOnlyList<MobileDeliverySummaryDto>> Deliveries(
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _mobile.DeliveriesAsync(
            userId,
            await _permissions.HasPermissionAsync(
                userId,
                Permissions.Mobile.DeliveryViewAll,
                cancellationToken),
            cancellationToken);
    }

    [HttpPost("deliveries/{deliveryId:int}/events/{eventType}")]
    [HasPermission(Permissions.Mobile.DeliveryUpdateOwn)]
    // HTTP POST at "deliveries/{deliveryId:int}/events/{eventType}" handles the delivery event operation for
    // mobile dashboard through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts MobileDeliveryEventRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _mobile.RecordDeliveryEventAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> DeliveryEvent(
        int deliveryId,
        string eventType,
        MobileDeliveryEventRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        await _mobile.RecordDeliveryEventAsync(
            deliveryId,
            eventType,
            request,
            userId,
            await _permissions.HasPermissionAsync(
                userId,
                Permissions.Mobile.DeliveryViewAll,
                cancellationToken),
            Correlation(HttpContext),
            cancellationToken);
        return Ok(new { message = "Delivery update recorded." });
    }
}

[ApiController]
[Route("api/mobile/tracking")]
[HasAnyPermission(
    Permissions.Mobile.TrackingShareOwn,
    Permissions.Mobile.TrackingViewAll,
    Permissions.Mobile.TrackingManage)]
/// <summary>Accepts consented tracking commands and permission-filtered route history.</summary>
public sealed class MobileTrackingController : MobileControllerBase
{
    private readonly IDriverTrackingService _tracking;
    private readonly IPermissionService _permissions;

    public MobileTrackingController(
        IDriverTrackingService tracking,
        IPermissionService permissions)
    {
        _tracking = tracking;
        _permissions = permissions;
    }

    [HttpGet("active")]
    // HTTP GET at "active" returns the authoritative mobile tracking projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _tracking.ActiveAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IReadOnlyList<TrackingSessionDto>> Active(
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _tracking.ActiveAsync(
            userId,
            await _permissions.HasPermissionAsync(
                userId,
                Permissions.Mobile.TrackingViewAll,
                cancellationToken),
            cancellationToken);
    }

    [HttpGet("sessions/{sessionId:long}/locations")]
    // HTTP GET at "sessions/{sessionId:long}/locations" returns the authoritative mobile tracking projection
    // needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _tracking.HistoryAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IReadOnlyList<DriverLocationDto>> History(
        long sessionId,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _tracking.HistoryAsync(
            sessionId,
            userId,
            await _permissions.HasPermissionAsync(
                userId,
                Permissions.Mobile.TrackingViewAll,
                cancellationToken),
            cancellationToken);
    }

    [HttpPost("deliveries/{deliveryId:int}/start")]
    [HasAnyPermission(
        Permissions.Mobile.TrackingShareOwn,
        Permissions.Mobile.TrackingManage)]
    // HTTP POST at "deliveries/{deliveryId:int}/start" starts one tracking session for an assigned delivery.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts StartTrackingRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _tracking.StartAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<TrackingSessionDto> Start(
        int deliveryId,
        StartTrackingRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _tracking.StartAsync(
            deliveryId,
            request,
            userId,
            await CanManage(userId, cancellationToken),
            Correlation(HttpContext),
            cancellationToken);
    }

    [HttpPost("sessions/{sessionId:long}/locations")]
    [HasAnyPermission(
        Permissions.Mobile.TrackingShareOwn,
        Permissions.Mobile.TrackingManage)]
    // HTTP POST at "sessions/{sessionId:long}/locations" accepts one GPS sample for the driver's active
    // tracking session.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DriverLocationRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _tracking.AddLocationAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<DriverLocationDto> Location(
        long sessionId,
        DriverLocationRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _tracking.AddLocationAsync(
            sessionId,
            request,
            userId,
            await CanManage(userId, cancellationToken),
            cancellationToken);
    }

    [HttpPost("sessions/{sessionId:long}/stop")]
    [HasAnyPermission(
        Permissions.Mobile.TrackingShareOwn,
        Permissions.Mobile.TrackingManage)]
    // HTTP POST at "sessions/{sessionId:long}/stop" closes tracking without completing the separate driver
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts StopTrackingRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _tracking.StopAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<TrackingSessionDto> Stop(
        long sessionId,
        StopTrackingRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _tracking.StopAsync(
            sessionId,
            request,
            userId,
            await CanManage(userId, cancellationToken),
            cancellationToken);
    }

    private Task<bool> CanManage(int userId, CancellationToken cancellationToken) =>
        _permissions.HasPermissionAsync(
            userId,
            Permissions.Mobile.TrackingManage,
            cancellationToken);
}

[ApiController]
[Route("api/mobile/routes")]
[HasPermission(Permissions.Mobile.DeliveryViewOwn)]
/// <summary>Returns delivery route data for the mobile execution experience.</summary>
public sealed class MobileRoutesController : MobileControllerBase
{
    private readonly IDeliveryRouteService _routes;

    public MobileRoutesController(IDeliveryRouteService routes)
    {
        _routes = routes;
    }

    [HttpGet("deliveries/{deliveryId:int}")]
    // HTTP GET at "deliveries/{deliveryId:int}" returns the authoritative mobile routes projection needed by
    // the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _routes.StatusAsync; failures use
    // existing HTTP handling.
    public Task<DeliveryRouteDto> Get(
        int deliveryId,
        CancellationToken cancellationToken) =>
        _routes.StatusAsync(deliveryId, cancellationToken);

    [HttpPost("deliveries/{deliveryId:int}/calculate")]
    [HasPermission(Permissions.Mobile.DeliveryUpdateOwn)]
    // HTTP POST at "deliveries/{deliveryId:int}/calculate" handles the calculate operation for mobile routes
    // through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CalculateRouteRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _routes.CalculateAsync; failures use
    // existing HTTP handling.
    public Task<DeliveryRouteDto> Calculate(
        int deliveryId,
        CalculateRouteRequest request,
        CancellationToken cancellationToken) =>
        _routes.CalculateAsync(deliveryId, request, cancellationToken);
}

[ApiController]
[Route("api/mobile/buying-lists")]
[HasPermission(Permissions.Mobile.BuyingListView)]
/// <summary>Exposes assigned Buying List actions for authorized mobile buyers.</summary>
public sealed class MobileBuyingListsController : MobileControllerBase
{
    private readonly IMobileBuyingListService _lists;
    private readonly IBuyingListManagementService _management;
    private readonly IPermissionService _permissions;

    public MobileBuyingListsController(
        IMobileBuyingListService lists,
        IBuyingListManagementService management,
        IPermissionService permissions)
    {
        _lists = lists;
        _management = management;
        _permissions = permissions;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative mobile buying lists projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _lists.ListAsync; failures use existing
    // HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IReadOnlyList<BuyingListDto>> List(
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _lists.ListAsync(
            userId,
            await ViewAll(userId, cancellationToken),
            cancellationToken);
    }

    [HttpGet("{id:int}")]
    // HTTP GET at "{id:int}" returns the authoritative mobile buying lists projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _lists.GetAsync; failures use existing
    // HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<BuyingListDto> Get(int id, CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _lists.GetAsync(
            id,
            userId,
            await ViewAll(userId, cancellationToken),
            cancellationToken);
    }

    [HttpGet("options")]
    // HTTP GET at "options" returns the authoritative mobile buying lists projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _management.OptionsAsync; failures use
    // existing HTTP handling.
    public Task<BuyingListOptionsDto> Options(
        CancellationToken cancellationToken) =>
        _management.OptionsAsync(cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.Mobile.BuyingListCreate)]
    // HTTP POST at the controller root creates or attaches mobile buying lists data through the controlled
    // API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateBuyingListRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _lists.CreateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<BuyingListDto>> Create(
        CreateBuyingListRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            StatusCodes.Status201Created,
            await _lists.CreateAsync(
                request,
                UserId(),
                Correlation(HttpContext),
                cancellationToken));

    [HttpPut("{id:int}/items/{itemId:int}")]
    [HasPermission(Permissions.Mobile.BuyingListUpdate)]
    // HTTP PUT at "{id:int}/items/{itemId:int}" updates only allowed mobile buying lists fields through a
    // narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateBuyingListItemRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _lists.UpdateItemAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<BuyingListDto> UpdateItem(
        int id,
        int itemId,
        UpdateBuyingListItemRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _lists.UpdateItemAsync(
            id,
            itemId,
            request,
            userId,
            await ViewAll(userId, cancellationToken),
            cancellationToken);
    }

    [HttpPost("{id:int}/items")]
    [HasPermission(Permissions.Mobile.BuyingListAddPromotionalItem)]
    // HTTP POST at "{id:int}/items" creates or attaches mobile buying lists data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts AddBuyingListItemRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _lists.AddItemAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<BuyingListDto> AddItem(
        int id,
        AddBuyingListItemRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _lists.AddItemAsync(
            id,
            request,
            userId,
            await ViewAll(userId, cancellationToken),
            cancellationToken);
    }

    [HttpPost("{id:int}/submit")]
    [HasPermission(Permissions.Mobile.BuyingListSubmit)]
    // HTTP POST at "{id:int}/submit" continues the mobile buying lists workflow through its named transition.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReasonRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _lists.SubmitAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<BuyingListDto> Submit(
        int id,
        ReasonRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _lists.SubmitAsync(
            id,
            request,
            userId,
            await ViewAll(userId, cancellationToken),
            Correlation(HttpContext),
            cancellationToken);
    }

    [HttpPost("{id:int}/docket")]
    [Consumes("multipart/form-data")]
    [HasPermission(Permissions.Mobile.BuyingListUploadDocket)]
    // HTTP POST at "{id:int}/docket" creates or attaches mobile buying lists data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _lists.UploadDocketAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<BuyingListDto> UploadDocket(
        int id,
        IFormFile file,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _lists.UploadDocketAsync(
            id,
            file,
            userId,
            await ViewAll(userId, cancellationToken),
            cancellationToken);
    }

    private Task<bool> ViewAll(int userId, CancellationToken cancellationToken) =>
        _permissions.HasPermissionAsync(
            userId,
            Permissions.Mobile.BuyingListViewAll,
            cancellationToken);
}

[ApiController]
[Route("api/mobile/stock-receipts")]
[HasPermission(Permissions.Mobile.StockReceiptView)]
/// <summary>Exposes controlled finished-stock receiving commands on mobile.</summary>
public sealed class MobileStockReceiptsController : MobileControllerBase
{
    private readonly IMobileStockReceiptService _receipts;
    private readonly IPermissionService _permissions;

    public MobileStockReceiptsController(
        IMobileStockReceiptService receipts,
        IPermissionService permissions)
    {
        _receipts = receipts;
        _permissions = permissions;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative mobile stock receipts projection needed by
    // the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _receipts.ListAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IReadOnlyList<StockReceiptDto>> List(
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _receipts.ListAsync(
            userId,
            await ViewAll(userId, cancellationToken),
            cancellationToken);
    }

    [HttpGet("{id:int}")]
    // HTTP GET at "{id:int}" returns the authoritative mobile stock receipts projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _receipts.GetAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<StockReceiptDto> Get(
        int id,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _receipts.GetAsync(
            id,
            userId,
            await ViewAll(userId, cancellationToken),
            cancellationToken);
    }

    [HttpPost]
    [HasPermission(Permissions.Mobile.StockReceiptCreate)]
    // HTTP POST at the controller root creates or attaches mobile stock receipts data through the controlled
    // API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateStockReceiptRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _receipts.CreateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<StockReceiptDto>> Create(
        CreateStockReceiptRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            StatusCodes.Status201Created,
            await _receipts.CreateAsync(
                request,
                UserId(),
                Correlation(HttpContext),
                cancellationToken));

    [HttpPost("{id:int}/items")]
    [HasPermission(Permissions.Mobile.StockReceiptCreate)]
    // HTTP POST at "{id:int}/items" creates or attaches mobile stock receipts data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts StockReceiptItemRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _receipts.AddItemAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<StockReceiptDto> AddItem(
        int id,
        StockReceiptItemRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _receipts.AddItemAsync(
            id,
            request,
            userId,
            await ViewAll(userId, cancellationToken),
            cancellationToken);
    }

    [HttpPost("{id:int}/submit")]
    [HasPermission(Permissions.Mobile.StockReceiptSubmit)]
    // HTTP POST at "{id:int}/submit" posts a receipt through its idempotent stock-movement transaction.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReasonRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _receipts.SubmitAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<StockReceiptDto> Submit(
        int id,
        ReasonRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _receipts.SubmitAsync(
            id,
            request,
            userId,
            await ViewAll(userId, cancellationToken),
            Correlation(HttpContext),
            cancellationToken);
    }

    private Task<bool> ViewAll(int userId, CancellationToken cancellationToken) =>
        _permissions.HasPermissionAsync(
            userId,
            Permissions.Mobile.DeviceManagementManage,
            cancellationToken);
}

[ApiController]
[Route("api/mobile/packing")]
[HasPermission(Permissions.Mobile.PackingView)]
/// <summary>Exposes packing tasks, verified scans and completion commands.</summary>
public sealed class MobilePackingController : MobileControllerBase
{
    private readonly IMobilePackingDispatchService _packing;

    public MobilePackingController(IMobilePackingDispatchService packing)
    {
        _packing = packing;
    }

    [HttpGet("tasks")]
    // HTTP GET at "tasks" returns the authoritative mobile packing projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _packing.PackingTasksAsync; failures
    // use existing HTTP handling.
    public Task<IReadOnlyList<PackingTaskDto>> Tasks(CancellationToken cancellationToken) =>
        _packing.PackingTasksAsync(cancellationToken);

    [HttpGet("tasks/{orderId:int}")]
    // HTTP GET at "tasks/{orderId:int}" returns the authoritative mobile packing projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _packing.PackingTaskAsync; failures use
    // existing HTTP handling.
    public Task<PackingTaskDetailDto> Task(
        int orderId,
        CancellationToken cancellationToken) =>
        _packing.PackingTaskAsync(orderId, cancellationToken);

    [HttpPost("tasks/{orderId:int}/scan")]
    [HasPermission(Permissions.Mobile.PackingScan)]
    // HTTP POST at "tasks/{orderId:int}/scan" records a real batch scan and rejects nonexistent or
    // unavailable stock.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts PackingScanRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _packing.ScanAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<PackingTaskDetailDto> Scan(
        int orderId,
        PackingScanRequest request,
        CancellationToken cancellationToken) =>
        _packing.ScanAsync(orderId, request, UserId(), cancellationToken);

    [HttpPost("tasks/{orderId:int}/scans/{scanId:long}/remove")]
    [HasPermission(Permissions.Mobile.PackingRemoveScan)]
    // HTTP POST at "tasks/{orderId:int}/scans/{scanId:long}/remove" reverses a packing scan through the
    // audited packing workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReasonRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _packing.RemoveScanAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<PackingTaskDetailDto> Remove(
        int orderId,
        long scanId,
        ReasonRequest request,
        CancellationToken cancellationToken) =>
        _packing.RemoveScanAsync(
            orderId,
            scanId,
            request,
            UserId(),
            cancellationToken);

    [HttpPost("tasks/{orderId:int}/complete")]
    [HasPermission(Permissions.Mobile.PackingComplete)]
    // HTTP POST at "tasks/{orderId:int}/complete" completes packing only after every required quantity is
    // allocated.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReasonRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _packing.CompletePackingAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<PackingTaskDetailDto> Complete(
        int orderId,
        ReasonRequest request,
        CancellationToken cancellationToken) =>
        _packing.CompletePackingAsync(
            orderId,
            request,
            UserId(),
            Role(),
            cancellationToken);
}

[ApiController]
[Route("api/mobile/dispatch")]
[HasPermission(Permissions.Mobile.DispatchView)]
/// <summary>Exposes the warehouse dispatch queue and release command.</summary>
public sealed class MobileDispatchController : MobileControllerBase
{
    private readonly IMobilePackingDispatchService _dispatch;

    public MobileDispatchController(IMobilePackingDispatchService dispatch)
    {
        _dispatch = dispatch;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative mobile dispatch projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _dispatch.DispatchQueueAsync; failures
    // use existing HTTP handling.
    public Task<IReadOnlyList<DispatchOrderDto>> Queue(
        CancellationToken cancellationToken) =>
        _dispatch.DispatchQueueAsync(cancellationToken);

    [HttpPost("{orderId:int}/confirm")]
    [HasPermission(Permissions.Mobile.DispatchConfirm)]
    // HTTP POST at "{orderId:int}/confirm" continues the mobile dispatch workflow through its named
    // transition.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReasonRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _dispatch.ConfirmDispatchAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<DispatchOrderDto> Confirm(
        int orderId,
        ReasonRequest request,
        CancellationToken cancellationToken) =>
        _dispatch.ConfirmDispatchAsync(
            orderId,
            request,
            UserId(),
            Role(),
            cancellationToken);
}

[ApiController]
[Route("api/mobile/write-offs")]
[HasPermission(Permissions.Mobile.WriteOffView)]
/// <summary>Exposes stock write-off capture and approval actions with separation of duties.</summary>
public sealed class MobileWriteOffsController : MobileControllerBase
{
    private readonly IMobileWriteOffService _writeOffs;
    private readonly IPermissionService _permissions;

    public MobileWriteOffsController(
        IMobileWriteOffService writeOffs,
        IPermissionService permissions)
    {
        _writeOffs = writeOffs;
        _permissions = permissions;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative mobile write offs projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _writeOffs.ListAsync; failures use
    // existing HTTP handling.
    public Task<IReadOnlyList<StockWriteOffDto>> List(
        [FromQuery] bool approvalsOnly,
        CancellationToken cancellationToken) =>
        _writeOffs.ListAsync(approvalsOnly, cancellationToken);

    [HttpGet("{id:long}")]
    // HTTP GET at "{id:long}" returns the authoritative mobile write offs projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _writeOffs.GetAsync; failures use
    // existing HTTP handling.
    public Task<StockWriteOffDto> Get(long id, CancellationToken cancellationToken) =>
        _writeOffs.GetAsync(id, cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.Mobile.WriteOffCreate)]
    // HTTP POST at the controller root creates or attaches mobile write offs data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateWriteOffRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _writeOffs.CreateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<StockWriteOffDto>> Create(
        CreateWriteOffRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            StatusCodes.Status201Created,
            await _writeOffs.CreateAsync(
                request,
                UserId(),
                await Management(cancellationToken),
                cancellationToken));

    [HttpPost("{id:long}/evidence")]
    [HasPermission(Permissions.Mobile.WriteOffUploadEvidence)]
    [RequestSizeLimit(26 * 1024 * 1024)]
    // HTTP POST at "{id:long}/evidence" creates or attaches mobile write offs data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _writeOffs.UploadEvidenceAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<StockWriteOffDto> Evidence(
        long id,
        IFormFile file,
        [FromForm] string? caption,
        CancellationToken cancellationToken) =>
        _writeOffs.UploadEvidenceAsync(
            id,
            file,
            caption,
            UserId(),
            cancellationToken);

    [HttpPost("{id:long}/complete")]
    [HasPermission(Permissions.Mobile.WriteOffComplete)]
    // HTTP POST at "{id:long}/complete" submits a loss and routes high-value write-offs for independent
    // approval.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReasonRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _writeOffs.CompleteAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<StockWriteOffDto> Complete(
        long id,
        ReasonRequest request,
        CancellationToken cancellationToken) =>
        await _writeOffs.CompleteAsync(
            id,
            request,
            UserId(),
            await Management(cancellationToken),
            cancellationToken);

    [HttpPost("{id:long}/approve")]
    [HasPermission(Permissions.Mobile.WriteOffApprove)]
    // HTTP POST at "{id:long}/approve" approves a write-off while enforcing the no-self-approval rule.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReasonRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _writeOffs.DecideAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<StockWriteOffDto> Approve(
        long id,
        ReasonRequest request,
        CancellationToken cancellationToken) =>
        _writeOffs.DecideAsync(
            id,
            request,
            UserId(),
            true,
            cancellationToken);

    [HttpPost("{id:long}/reject")]
    [HasPermission(Permissions.Mobile.WriteOffReject)]
    // HTTP POST at "{id:long}/reject" rejects a submitted write-off with an auditable reason.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReasonRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _writeOffs.DecideAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<StockWriteOffDto> Reject(
        long id,
        ReasonRequest request,
        CancellationToken cancellationToken) =>
        _writeOffs.DecideAsync(
            id,
            request,
            UserId(),
            false,
            cancellationToken);

    private async Task<bool> Management(CancellationToken cancellationToken)
    {
        var id = UserId();
        return await _permissions.HasPermissionAsync(
            id,
            Permissions.Mobile.WriteOffApprove,
            cancellationToken);
    }
}

[ApiController]
[Route("api/mobile/notifications")]
[HasPermission(Permissions.Notifications.View)]
/// <summary>Returns and acknowledges operational notifications for the current user.</summary>
public sealed class MobileNotificationsController : MobileControllerBase
{
    private readonly IOperationalNotificationService _notifications;
    private readonly IPermissionService _permissions;

    public MobileNotificationsController(
        IOperationalNotificationService notifications,
        IPermissionService permissions)
    {
        _notifications = notifications;
        _permissions = permissions;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative mobile notifications projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _notifications.InboxAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<NotificationInboxDto> Inbox(
        [FromQuery] bool unreadOnly,
        CancellationToken cancellationToken) =>
        _notifications.InboxAsync(UserId(), unreadOnly, cancellationToken);

    [HttpPost("{recipientId:long}/read")]
    // HTTP POST at "{recipientId:long}/read" handles the read operation for mobile notifications through the
    // established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _notifications.MarkReadAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Read(
        long recipientId,
        CancellationToken cancellationToken)
    {
        await _notifications.MarkReadAsync(recipientId, UserId(), cancellationToken);
        return Ok(new { message = "Notification marked as read." });
    }

    [HttpPost("read-all")]
    // HTTP POST at "read-all" handles the read all operation for mobile notifications through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _notifications.MarkAllReadAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> ReadAll(CancellationToken cancellationToken)
    {
        await _notifications.MarkAllReadAsync(UserId(), cancellationToken);
        return Ok(new { message = "Notifications marked as read." });
    }

    [HttpGet("preferences")]
    // HTTP GET at "preferences" updates only allowed mobile notifications fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _notifications.PreferencesAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<NotificationPreferenceDto> Preferences(
        CancellationToken cancellationToken) =>
        _notifications.PreferencesAsync(UserId(), cancellationToken);

    [HttpPut("preferences")]
    // HTTP PUT at "preferences" updates only allowed mobile notifications fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts NotificationPreferenceDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _notifications.UpdatePreferencesAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<NotificationPreferenceDto> Preferences(
        NotificationPreferenceDto request,
        CancellationToken cancellationToken) =>
        _notifications.UpdatePreferencesAsync(
            UserId(),
            request,
            cancellationToken);

    [HttpGet("devices")]
    // HTTP GET at "devices" handles the devices operation for mobile notifications through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _notifications.DevicesAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IReadOnlyList<MobileDeviceDto>> Devices(
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _notifications.DevicesAsync(
            userId,
            await _permissions.HasPermissionAsync(
                userId,
                Permissions.Mobile.DeviceManagementManage,
                cancellationToken),
            cancellationToken);
    }

    [HttpPost("devices")]
    [HasPermission(Permissions.Mobile.Access)]
    // HTTP POST at "devices" creates or attaches mobile notifications data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RegisterMobileDeviceRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _notifications.RegisterDeviceAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<MobileDeviceDto> Register(
        RegisterMobileDeviceRequest request,
        CancellationToken cancellationToken) =>
        _notifications.RegisterDeviceAsync(
            UserId(),
            request,
            cancellationToken);

    [HttpPost("devices/{deviceId:long}/revoke")]
    // HTTP POST at "devices/{deviceId:long}/revoke" removes or retires mobile notifications data after
    // dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReasonRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _notifications.RevokeDeviceAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Revoke(
        long deviceId,
        ReasonRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        await _notifications.RevokeDeviceAsync(
            deviceId,
            userId,
            await _permissions.HasPermissionAsync(
                userId,
                Permissions.Mobile.DeviceManagementManage,
                cancellationToken),
            request.Reason,
            cancellationToken);
        return Ok(new { message = "Mobile device revoked." });
    }
}
