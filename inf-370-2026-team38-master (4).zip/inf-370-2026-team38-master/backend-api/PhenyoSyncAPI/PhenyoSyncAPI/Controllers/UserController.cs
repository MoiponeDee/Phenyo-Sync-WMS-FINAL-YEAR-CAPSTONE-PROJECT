using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Security;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/users")]
[Authorize]
/// <summary>Exposes user administration and the current user's effective authorization snapshot.</summary>
public sealed class UserController : ControllerBase
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IPermissionService _permissions;
    private readonly IEmailService _emailService;
    private readonly IConfiguration _configuration;
    private readonly IAuditService _auditService;

    public UserController(
        PhenyoSyncDbContext context,
        IPermissionService permissions,
        IEmailService emailService,
        IConfiguration configuration,
        IAuditService auditService)
    {
        _context = context;
        _permissions = permissions;
        _emailService = emailService;
        _configuration = configuration;
        _auditService = auditService;
    }

    [HttpGet]
    [HasPermission(Permissions.Users.View)]
    // HTTP GET at the controller root queries filtered user records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UserSearchQuery instead of an EF entity, limiting fields and preventing over-posting.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Search(
        [FromQuery] UserSearchQuery query,
        CancellationToken cancellationToken)
    {
        var users = _context.Users
            .AsNoTracking()
            .Include(item => item.Role)
            .Include(item => item.Driver)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(query.Search))
        {
            var search = query.Search.Trim();
            users = users.Where(item =>
                item.Email.Contains(search) ||
                item.FirstName.Contains(search) ||
                item.LastName.Contains(search));
        }

        if (!string.IsNullOrWhiteSpace(query.Role))
        {
            var role = RoleCodes.Normalize(query.Role);
            users = users.Where(item =>
                item.Role != null &&
                (item.Role.RoleCode == role || item.Role.RoleName == role));
        }

        if (!string.IsNullOrWhiteSpace(query.Status))
        {
            users = users.Where(item => item.Status == query.Status);
        }

        var total = await users.CountAsync(cancellationToken);
        var items = await users
            .OrderBy(item => item.FirstName)
            .ThenBy(item => item.LastName)
            .Skip((query.Page - 1) * query.PageSize)
            .Take(query.PageSize)
            .Select(item => new
            {
                item.UserId,
                item.Email,
                item.FirstName,
                item.LastName,
                item.PhoneNumber,
                item.Status,
                roleId = item.RoleId,
                role = item.Role == null
                    ? string.Empty
                    : item.Role.RoleName,
                roleCode = item.Role == null
                    ? string.Empty
                    : item.Role.RoleCode,
                driverId = item.Driver == null ? (int?)null : item.Driver.DriverId,
                licenseNumber = item.Driver == null ? null : item.Driver.LicenseNumber,
                licenseExpiryDate = item.Driver == null ? null : item.Driver.LicenseExpiryDate,
                vehicleAssigned = item.Driver == null ? null : item.Driver.VehicleAssigned,
                item.CreatedDate,
                item.UpdatedAtUtc,
                rowVersion = Convert.ToBase64String(
                    item.RowVersion ?? Array.Empty<byte>())
            })
            .ToListAsync(cancellationToken);

        return Ok(new
        {
            items,
            page = query.Page,
            pageSize = query.PageSize,
            total,
            totalPages = (int)Math.Ceiling(total / (double)query.PageSize)
        });
    }

    [HttpGet("role/{roleName}")]
    [HasPermission(Permissions.Users.View)]
    // HTTP GET at "role/{roleName}" handles the get by role operation for user through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> GetByRole(
        string roleName,
        CancellationToken cancellationToken)
    {
        var normalized = RoleCodes.Normalize(roleName);
        var users = await _context.Users
            .AsNoTracking()
            .Where(item =>
                item.Role != null &&
                (item.Role.RoleCode == normalized ||
                 item.Role.RoleName == normalized) &&
                item.Status == "Active")
            .OrderBy(item => item.FirstName)
            .Select(item => new
            {
                item.UserId,
                item.Email,
                item.FirstName,
                item.LastName
            })
            .ToListAsync(cancellationToken);

        return Ok(users);
    }

    [HttpGet("{id:int}")]
    [HasPermission(Permissions.Users.View)]
    // HTTP GET at "{id:int}" returns the authoritative user projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Get(
        int id,
        CancellationToken cancellationToken)
    {
        var user = await _context.Users
            .AsNoTracking()
            .Include(item => item.Role)
            .Include(item => item.Driver)
            .Where(item => item.UserId == id)
            .Select(item => new
            {
                item.UserId,
                item.Email,
                item.FirstName,
                item.LastName,
                item.PhoneNumber,
                item.Status,
                item.RoleId,
                role = item.Role == null
                    ? string.Empty
                    : item.Role.RoleName,
                roleCode = item.Role == null
                    ? string.Empty
                    : item.Role.RoleCode,
                driverId = item.Driver == null ? (int?)null : item.Driver.DriverId,
                licenseNumber = item.Driver == null ? null : item.Driver.LicenseNumber,
                licenseExpiryDate = item.Driver == null ? null : item.Driver.LicenseExpiryDate,
                vehicleAssigned = item.Driver == null ? null : item.Driver.VehicleAssigned,
                item.CreatedDate,
                item.UpdatedAtUtc,
                rowVersion = Convert.ToBase64String(
                    item.RowVersion ?? Array.Empty<byte>())
            })
            .SingleOrDefaultAsync(cancellationToken);

        return user is null
            ? NotFound(new { message = "The selected user was not found." })
            : Ok(user);
    }

    [HttpGet("me/permissions")]
    // HTTP GET at "me/permissions" handles the my permissions operation for user through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // PermissionService returns the server-authoritative snapshot for the JWT actor; an invalid session maps
    // to 401 instead of trusting permissions cached by the frontend.
    public async Task<IActionResult> MyPermissions(
        CancellationToken cancellationToken)
    {
        var snapshot = await _permissions.GetSnapshotAsync(
            CurrentUserId(),
            cancellationToken);

        return snapshot is null
            ? Unauthorized(new { message = "The session is no longer valid." })
            : Ok(ToPermissionResponse(snapshot));
    }

    [HttpGet("{id:int}/permissions")]
    [HasPermission(Permissions.Users.ViewEffectivePermissions)]
    // HTTP GET at "{id:int}/permissions" handles the effective permissions operation for user through the
    // established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // PermissionService calculates the selected user's effective server-side snapshot; an unknown user maps
    // to 404 rather than returning an empty permission set.
    public async Task<IActionResult> EffectivePermissions(
        int id,
        CancellationToken cancellationToken)
    {
        var snapshot = await _permissions.GetSnapshotAsync(
            id,
            cancellationToken);

        return snapshot is null
            ? NotFound(new { message = "The selected user was not found." })
            : Ok(ToPermissionResponse(snapshot));
    }

    [HttpPost]
    [HasPermission(Permissions.Users.Create)]
    // HTTP POST at the controller root creates or attaches user data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateUserRequest instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _emailService.SendPasswordResetEmailAsync; failures use existing HTTP handling.
    public async Task<IActionResult> Create(
        [FromBody] CreateUserRequest request,
        CancellationToken cancellationToken)
    {
        var normalizedEmail = NormalizeEmail(request.Email);
        if (await _context.Users.AnyAsync(
                item => item.NormalizedEmail == normalizedEmail,
                cancellationToken))
        {
            ModelState.AddModelError(
                nameof(request.Email),
                "A user with this email address already exists.");
            return ValidationProblem(ModelState);
        }

        var role = await _context.Roles
            .SingleOrDefaultAsync(
                item => item.RoleId == request.RoleId && item.IsActive,
                cancellationToken);
        if (role is null)
        {
            ModelState.AddModelError(
                nameof(request.RoleId),
                "Select an active role.");
            return ValidationProblem(ModelState);
        }

        if (role.RoleCode == RoleCodes.Admin &&
            User?.Identity?.IsAuthenticated == true &&
            !await IsSuperAdminAsync(CurrentUserId(), cancellationToken))
        {
            return Forbid();
        }

        if (role.RoleCode == RoleCodes.Driver &&
            (string.IsNullOrWhiteSpace(request.LicenseNumber) ||
             request.LicenseExpiryDate is null))
        {
            if (string.IsNullOrWhiteSpace(request.LicenseNumber))
            {
                ModelState.AddModelError(
                    nameof(request.LicenseNumber),
                    "A driver licence number is required.");
            }
            if (request.LicenseExpiryDate is null)
            {
                ModelState.AddModelError(
                    nameof(request.LicenseExpiryDate),
                    "A driver licence expiry date is required.");
            }
            return ValidationProblem(ModelState);
        }

        var setupToken = GenerateToken();
        var user = new User
        {
            Email = request.Email.Trim(),
            NormalizedEmail = normalizedEmail,
            FirstName = request.FirstName.Trim(),
            LastName = request.LastName.Trim(),
            PhoneNumber = NullIfWhiteSpace(request.PhoneNumber),
            RoleId = role.RoleId,
            Status = "Active",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(
                Convert.ToBase64String(RandomNumberGenerator.GetBytes(48))),
            PasswordResetTokenHash = HashToken(setupToken),
            PasswordResetTokenExpiry = DateTime.UtcNow.AddHours(24),
            CreatedDate = DateTime.UtcNow,
            SecurityVersion = 1
        };

        _context.Users.Add(user);
        if (role.RoleCode == RoleCodes.Driver)
        {
            _context.Drivers.Add(new Driver
            {
                User = user,
                LicenseNumber = request.LicenseNumber!.Trim(),
                LicenseExpiryDate = request.LicenseExpiryDate!.Value.Date,
                VehicleAssigned = NullIfWhiteSpace(request.VehicleAssigned),
                AvailabilityStatus = "Available"
            });
        }

        await _context.SaveChangesAsync(cancellationToken);

        var setupLink = BuildResetLink(user.Email, setupToken);
        var emailSent = true;
        try
        {
            await _emailService.SendPasswordResetEmailAsync(
                user.Email,
                setupLink);
        }
        catch (Exception exception)
        {
            emailSent = false;
            await _auditService.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.SendEmail,
                SystemModule = AuditModules.UserManagement,
                OperationName = "SendAccountSetupEmail",
                Description = "The account was created but its setup email could not be sent.",
                EntityType = nameof(User),
                EntityId = user.UserId.ToString(),
                EntityDisplay = AuditSanitizer.MaskEmail(user.Email),
                Success = false,
                FailureReason = exception.Message,
                EventSource = AuditEventSources.SecurityEvent
            }, cancellationToken);
        }

        return CreatedAtAction(
            nameof(Get),
            new { id = user.UserId },
            new
            {
                message = emailSent
                    ? "The user was created and a secure setup link was emailed."
                    : "The user was created, but the setup email could not be sent. Use Send setup link to retry.",
                code = emailSent
                    ? "USER_CREATED"
                    : "USER_CREATED_EMAIL_PENDING",
                userId = user.UserId
            });
    }

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.Users.Update)]
    // HTTP PUT at "{id:int}" updates only allowed user fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateUserRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> Update(
        int id,
        [FromBody] UpdateUserRequest request,
        CancellationToken cancellationToken)
    {
        var user = await _context.Users
            .Include(item => item.Role)
            .Include(item => item.Driver)
            .SingleOrDefaultAsync(
                item => item.UserId == id,
                cancellationToken);
        if (user is null)
        {
            return NotFound(new { message = "The selected user was not found." });
        }

        var targetRole = request.RoleId.HasValue
            ? await _context.Roles.SingleOrDefaultAsync(
                item => item.RoleId == request.RoleId.Value && item.IsActive,
                cancellationToken)
            : user.Role;
        if (targetRole is null)
        {
            ModelState.AddModelError(nameof(request.RoleId), "Select an active role.");
            return ValidationProblem(ModelState);
        }

        var roleChanged = targetRole.RoleId != user.RoleId;
        if (roleChanged && User?.Identity?.IsAuthenticated == true &&
            !await _permissions.HasPermissionAsync(
                CurrentUserId(), Permissions.Users.AssignRole, cancellationToken))
        {
            return Forbid();
        }
        if (targetRole.RoleCode == RoleCodes.Admin &&
            User?.Identity?.IsAuthenticated == true &&
            !await IsSuperAdminAsync(CurrentUserId(), cancellationToken))
        {
            return Forbid();
        }
        if (roleChanged && string.IsNullOrWhiteSpace(request.RoleChangeReason))
        {
            ModelState.AddModelError(
                nameof(request.RoleChangeReason),
                "Enter a reason for the role change.");
            return ValidationProblem(ModelState);
        }
        if (roleChanged && IsSecurityManager(user.Role) &&
            !IsSecurityManager(targetRole) &&
            await ActiveSecurityManagerCount(cancellationToken) <= 1)
        {
            return Conflict(new
            {
                message = "This role change would remove the final active security manager."
            });
        }
        var effectiveLicenseNumber = NullIfWhiteSpace(request.LicenseNumber)
            ?? user.Driver?.LicenseNumber;
        var effectiveLicenseExpiry = request.LicenseExpiryDate
            ?? user.Driver?.LicenseExpiryDate;
        if (targetRole.RoleCode == RoleCodes.Driver &&
            (string.IsNullOrWhiteSpace(effectiveLicenseNumber) ||
             effectiveLicenseExpiry is null))
        {
            if (string.IsNullOrWhiteSpace(effectiveLicenseNumber))
            {
                ModelState.AddModelError(
                    nameof(request.LicenseNumber),
                    "A driver licence number is required.");
            }
            if (effectiveLicenseExpiry is null)
            {
                ModelState.AddModelError(
                    nameof(request.LicenseExpiryDate),
                    "A driver licence expiry date is required.");
            }
            return ValidationProblem(ModelState);
        }

        var normalizedEmail = NormalizeEmail(request.Email);
        if (await _context.Users.AnyAsync(
                item => item.UserId != id &&
                    item.NormalizedEmail == normalizedEmail,
                cancellationToken))
        {
            ModelState.AddModelError(
                nameof(request.Email),
                "A user with this email address already exists.");
            return ValidationProblem(ModelState);
        }

        if (!TryApplyRowVersion(user, request.RowVersion))
        {
            ModelState.AddModelError(
                nameof(request.RowVersion),
                "The user version is invalid. Refresh and try again.");
            return ValidationProblem(ModelState);
        }

        var oldRole = user.Role?.RoleName ?? "Unknown";
        user.Email = request.Email.Trim();
        user.NormalizedEmail = normalizedEmail;
        user.FirstName = request.FirstName.Trim();
        user.LastName = request.LastName.Trim();
        user.PhoneNumber = NullIfWhiteSpace(request.PhoneNumber);
        if (roleChanged)
        {
            user.RoleId = targetRole.RoleId;
            user.SecurityVersion++;
        }
        if (targetRole.RoleCode == RoleCodes.Driver)
        {
            if (user.Driver is null)
            {
                user.Driver = new Driver
                {
                    UserId = user.UserId,
                    AvailabilityStatus = "Available"
                };
            }
            user.Driver.LicenseNumber = effectiveLicenseNumber!.Trim();
            user.Driver.LicenseExpiryDate = effectiveLicenseExpiry!.Value.Date;
            if (request.VehicleAssigned is not null)
            {
                user.Driver.VehicleAssigned = NullIfWhiteSpace(request.VehicleAssigned);
            }
        }
        user.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);

        if (roleChanged)
        {
            await _auditService.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.Update,
                SystemModule = AuditModules.Permissions,
                OperationName = "AssignUserRole",
                Description = $"A user role changed from {oldRole} to {targetRole.RoleName}.",
                EntityType = nameof(User),
                EntityId = user.UserId.ToString(),
                EntityDisplay = AuditSanitizer.MaskEmail(user.Email),
                SafeDetails = new Dictionary<string, object?>
                {
                    ["OldRole"] = oldRole,
                    ["NewRole"] = targetRole.RoleName,
                    ["Reason"] = request.RoleChangeReason!.Trim()
                }
            }, cancellationToken);
        }

        return Ok(new
        {
            message = "The user was updated successfully.",
            code = "USER_UPDATED",
            rowVersion = Convert.ToBase64String(user.RowVersion ?? Array.Empty<byte>())
        });
    }

    [HttpPost("{id:int}/assign-role")]
    [HasPermission(Permissions.Users.AssignRole)]
    // HTTP POST at "{id:int}/assign-role" changes the controlled user assignment after eligibility checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ChangeUserRoleRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _auditService.RecordAsync; failures use existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> AssignRole(
        int id,
        [FromBody] ChangeUserRoleRequest request,
        CancellationToken cancellationToken)
    {
        var user = await _context.Users
            .Include(item => item.Role)
            .Include(item => item.Driver)
            .SingleOrDefaultAsync(
                item => item.UserId == id,
                cancellationToken);
        var role = await _context.Roles
            .SingleOrDefaultAsync(
                item => item.RoleId == request.RoleId && item.IsActive,
                cancellationToken);

        if (user is null)
        {
            return NotFound(new { message = "The selected user was not found." });
        }

        if (role is null)
        {
            return BadRequest(new { message = "Select an active role." });
        }

        if (role.RoleCode == RoleCodes.Admin &&
            User?.Identity?.IsAuthenticated == true &&
            !await IsSuperAdminAsync(CurrentUserId(), cancellationToken))
        {
            return Forbid();
        }

        if (!TryApplyRowVersion(user, request.RowVersion))
        {
            ModelState.AddModelError(
                nameof(request.RowVersion),
                "The user version is invalid. Refresh and try again.");
            return ValidationProblem(ModelState);
        }

        if (IsSecurityManager(user.Role) &&
            !IsSecurityManager(role) &&
            await ActiveSecurityManagerCount(cancellationToken) <= 1)
        {
            return Conflict(new
            {
                message =
                    "This role change would remove the final active security manager."
            });
        }

        if (role.RoleCode == RoleCodes.Driver &&
            (user.Driver is null ||
             string.IsNullOrWhiteSpace(user.Driver.LicenseNumber) ||
             user.Driver.LicenseExpiryDate is null))
        {
            return Conflict(new
            {
                message = "Open Edit User and complete the driver licence details before assigning the Driver role."
            });
        }

        var oldRole = user.Role?.RoleName ?? "Unknown";
        user.RoleId = role.RoleId;
        user.SecurityVersion++;
        user.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);

        await _auditService.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.Update,
            SystemModule = AuditModules.Permissions,
            OperationName = "AssignUserRole",
            Description = $"A user role changed from {oldRole} to {role.RoleName}.",
            EntityType = nameof(User),
            EntityId = user.UserId.ToString(),
            EntityDisplay = AuditSanitizer.MaskEmail(user.Email),
            SafeDetails = new Dictionary<string, object?>
            {
                ["OldRole"] = oldRole,
                ["NewRole"] = role.RoleName,
                ["Reason"] = request.Reason.Trim()
            }
        }, cancellationToken);

        return Ok(new
        {
            message = "The user role was updated successfully.",
            code = "USER_ROLE_ASSIGNED"
        });
    }

    [HttpPost("{id:int}/deactivate")]
    [HasPermission(Permissions.Users.Deactivate)]
    // HTTP POST at "{id:int}/deactivate" handles the deactivate operation for user through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UserStatusRequest instead of an EF entity, limiting fields and preventing over-posting.
    // ChangeStatus resolves the actor from JWT claims, checks eligibility and RowVersion, then persists and
    // audits the deactivation before returning its mapped HTTP result.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public Task<IActionResult> Deactivate(
        int id,
        [FromBody] UserStatusRequest request,
        CancellationToken cancellationToken) =>
        ChangeStatus(
            id,
            false,
            request.Reason,
            request.RowVersion,
            cancellationToken);

    [HttpPost("{id:int}/reactivate")]
    [HasPermission(Permissions.Users.Reactivate)]
    // HTTP POST at "{id:int}/reactivate" handles the reactivate operation for user through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UserStatusRequest instead of an EF entity, limiting fields and preventing over-posting.
    // ChangeStatus resolves the actor from JWT claims, checks eligibility and RowVersion, then persists and
    // audits the reactivation before returning its mapped HTTP result.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public Task<IActionResult> Reactivate(
        int id,
        [FromBody] UserStatusRequest request,
        CancellationToken cancellationToken) =>
        ChangeStatus(
            id,
            true,
            request.Reason,
            request.RowVersion,
            cancellationToken);

    [HttpPost("{id:int}/password-reset")]
    [HasPermission(Permissions.Users.TriggerPasswordReset)]
    // HTTP POST at "{id:int}/password-reset" handles the trigger password reset operation for user through
    // the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _emailService.SendPasswordResetEmailAsync; failures use existing HTTP handling.
    public async Task<IActionResult> TriggerPasswordReset(
        int id,
        CancellationToken cancellationToken)
    {
        var user = await _context.Users
            .SingleOrDefaultAsync(
                item => item.UserId == id,
                cancellationToken);
        if (user is null)
        {
            return NotFound(new { message = "The selected user was not found." });
        }

        var token = GenerateToken();
        user.PasswordResetTokenHash = HashToken(token);
        user.PasswordResetTokenExpiry = DateTime.UtcNow.AddMinutes(30);
        user.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);

        await _emailService.SendPasswordResetEmailAsync(
            user.Email,
            BuildResetLink(user.Email, token));
        await _auditService.RecordAsync(new AuditEvent
        {
            ActionType = AuditActionTypes.PasswordResetRequested,
            SystemModule = AuditModules.UserManagement,
            OperationName = "ManagerTriggeredPasswordReset",
            Description = "An authorized manager sent a secure password-reset link.",
            EntityType = nameof(User),
            EntityId = user.UserId.ToString(),
            EntityDisplay = AuditSanitizer.MaskEmail(user.Email),
            EventSource = AuditEventSources.SecurityEvent
        }, cancellationToken);

        return Ok(new
        {
            message = "A secure password-reset link was sent.",
            code = "PASSWORD_RESET_SENT"
        });
    }

    [HttpDelete("{id:int}")]
    [HasPermission(Permissions.Users.Deactivate)]
    // HTTP DELETE at "{id:int}" removes or retires user data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _auditService.RecordAsync; failures use existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public IActionResult Delete(int id) =>
        Conflict(new
        {
            message =
                "User records are retained for accountability. Deactivate the account instead.",
            code = "USER_DEACTIVATION_REQUIRED",
            userId = id
        });

    private async Task<IActionResult> ChangeStatus(
        int id,
        bool active,
        string reason,
        string rowVersion,
        CancellationToken cancellationToken)
    {
        var user = await _context.Users
            .Include(item => item.Role)
            .SingleOrDefaultAsync(
                item => item.UserId == id,
                cancellationToken);
        if (user is null)
        {
            return NotFound(new { message = "The selected user was not found." });
        }

        if (!TryApplyRowVersion(user, rowVersion))
        {
            ModelState.AddModelError(
                nameof(rowVersion),
                "The user version is invalid. Refresh and try again.");
            return ValidationProblem(ModelState);
        }

        if (!active &&
            id == CurrentUserId())
        {
            return Conflict(new
            {
                message = "You cannot deactivate your own signed-in account."
            });
        }

        if (!active &&
            IsSecurityManager(user.Role) &&
            await ActiveSecurityManagerCount(cancellationToken) <= 1)
        {
            return Conflict(new
            {
                message =
                    "The final active security-management account cannot be deactivated."
            });
        }

        user.Status = active ? "Active" : "Inactive";
        user.SecurityVersion++;
        user.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);

        await _auditService.RecordAsync(new AuditEvent
        {
            ActionType = active
                ? AuditActionTypes.Activate
                : AuditActionTypes.Deactivate,
            SystemModule = AuditModules.UserManagement,
            OperationName = active ? "ReactivateUser" : "DeactivateUser",
            Description = active
                ? "A user account was reactivated."
                : "A user account was deactivated.",
            EntityType = nameof(User),
            EntityId = user.UserId.ToString(),
            EntityDisplay = AuditSanitizer.MaskEmail(user.Email),
            SafeDetails = new Dictionary<string, object?>
            {
                ["Reason"] = reason.Trim()
            }
        }, cancellationToken);

        return Ok(new
        {
            message = active
                ? "The user was reactivated successfully."
                : "The user was deactivated successfully.",
            code = active ? "USER_REACTIVATED" : "USER_DEACTIVATED"
        });
    }

    private int CurrentUserId() =>
        int.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var userId)
            ? userId
            : throw new UnauthorizedAccessException(
                "The current session does not identify a user.");

    private Task<int> ActiveSecurityManagerCount(
        CancellationToken cancellationToken) =>
        _context.Users.CountAsync(
            item =>
                item.Status == "Active" &&
                item.Role != null &&
                item.Role.IsActive &&
                item.Role.RoleCode == RoleCodes.OperationsManager,
            cancellationToken);

    private static bool IsSecurityManager(Role? role) =>
        role is not null &&
        RoleCodes.SecurityManagers.Contains(role.RoleCode);

    private bool TryApplyRowVersion(User user, string rowVersion)
    {
        try
        {
            var value = Convert.FromBase64String(rowVersion);
            // SQLite test stores do not generate SQL Server rowversion bytes. Treat two empty
            // values as the same version while production still compares the real token.
            if (value.Length == 0 && (user.RowVersion?.Length ?? 0) == 0)
            {
                return true;
            }
            _context.Entry(user)
                .Property(item => item.RowVersion)
                .OriginalValue = value;
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
    }

    private object ToPermissionResponse(UserPermissionSnapshot snapshot) =>
        new
        {
            userId = snapshot.UserId,
            snapshot.Email,
            role = snapshot.RoleName,
            roleCode = snapshot.RoleCode,
            snapshot.IsActive,
            permissions = snapshot.Permissions
                .OrderBy(item => item.Module)
                .ThenBy(item => item.DisplayName)
                .ToArray(),
            modules = snapshot.Permissions
                .GroupBy(item => item.Module)
                .OrderBy(group => group.Key)
                .Select(group => new
                {
                    module = group.Key,
                    permissions = group
                        .OrderBy(item => item.DisplayName)
                        .ToArray()
                })
                .ToArray()
        };

    private string BuildResetLink(string email, string token)
    {
        var frontendUrl = _configuration["FrontendUrl"]
            ?? "http://localhost:4200";
        return $"{frontendUrl.TrimEnd('/')}/reset-password" +
            $"?email={Uri.EscapeDataString(email)}" +
            $"&token={Uri.EscapeDataString(token)}";
    }

    private async Task<bool> IsSuperAdminAsync(
        int userId,
        CancellationToken cancellationToken) =>
        await _context.Users.AsNoTracking()
            .Where(user => user.UserId == userId && user.Status == "Active")
            .Select(user => user.Role != null && user.Role.RoleCode == RoleCodes.Admin)
            .SingleOrDefaultAsync(cancellationToken);

    private static string NormalizeEmail(string email) =>
        email.Trim().ToUpperInvariant();

    private static string? NullIfWhiteSpace(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private static string GenerateToken() =>
        Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
            .Replace("+", "-", StringComparison.Ordinal)
            .Replace("/", "_", StringComparison.Ordinal)
            .TrimEnd('=');

    private static string HashToken(string token) =>
        Convert.ToHexString(
            SHA256.HashData(Encoding.UTF8.GetBytes(token)));
}
