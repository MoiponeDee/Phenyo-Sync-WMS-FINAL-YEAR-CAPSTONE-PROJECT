using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.DTOs.Help;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/help-media-management")]
[Authorize]
[HasPermission(Permissions.HelpMedia.Manage)]
/// <summary>Exposes validated protected-media uploads and metadata management.</summary>
public sealed class HelpMediaManagementController : ControllerBase
{
    private readonly IHelpMediaService _media;

    public HelpMediaManagementController(IHelpMediaService media)
    {
        _media = media;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative help media management projection needed by
    // the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _media.ListAsync; failures use existing
    // HTTP handling.
    public Task<IReadOnlyList<HelpMediaDto>> List(
        CancellationToken cancellationToken) =>
        _media.ListAsync(
            true,
            User.FindFirstValue(ClaimTypes.Role),
            true,
            cancellationToken);

    [HttpPost]
    [RequestSizeLimit(510 * 1024 * 1024)]
    // HTTP POST at the controller root creates or attaches help media management data through the controlled
    // API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UploadHelpMediaRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _media.UploadAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Upload(
        IFormFile video,
        IFormFile? captions,
        [FromForm] UploadHelpMediaRequest request,
        CancellationToken cancellationToken)
    {
        try
        {
            return Created(
                string.Empty,
                new
                {
                    message = "The training video was stored securely.",
                    media = await _media.UploadAsync(
                        video,
                        captions,
                        request,
                        UserId(),
                        cancellationToken)
                });
        }
        catch (InvalidOperationException exception)
        {
            return BadRequest(new { message = exception.Message });
        }
    }

    [HttpDelete("{id:long}")]
    // HTTP DELETE at "{id:long}" removes or retires help media management data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RemoveHelpMediaRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _media.RemoveAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Remove(
        long id,
        [FromBody] RemoveHelpMediaRequest request,
        CancellationToken cancellationToken)
    {
        try
        {
            await _media.RemoveAsync(
                id,
                request.Reason,
                UserId(),
                cancellationToken);
            return Ok(new
            {
                message = "The training video was unpublished and its history retained."
            });
        }
        catch (KeyNotFoundException exception)
        {
            return NotFound(new { message = exception.Message });
        }
        catch (InvalidOperationException exception)
        {
            return BadRequest(new { message = exception.Message });
        }
    }

    [HttpPut("{id:long}")]
    // HTTP PUT at "{id:long}" updates only allowed help media management fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateHelpMediaRequest instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _media.UpdateAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Update(
        long id,
        [FromBody] UpdateHelpMediaRequest request,
        CancellationToken cancellationToken)
    {
        try
        {
            return Ok(await _media.UpdateAsync(
                id,
                request,
                UserId(),
                cancellationToken));
        }
        catch (KeyNotFoundException exception)
        {
            return NotFound(new { message = exception.Message });
        }
        catch (DbUpdateConcurrencyException exception)
        {
            return Conflict(new { message = exception.Message });
        }
        catch (InvalidOperationException exception)
        {
            return BadRequest(new { message = exception.Message });
        }
    }

    private int UserId() =>
        int.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var userId)
            ? userId
            : throw new UnauthorizedAccessException();
}

public sealed class RemoveHelpMediaRequest
{
    public string Reason { get; set; } = string.Empty;
}
