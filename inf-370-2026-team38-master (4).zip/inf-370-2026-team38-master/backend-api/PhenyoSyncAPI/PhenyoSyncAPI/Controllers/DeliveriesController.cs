using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Delivery;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/deliveries")]
[Authorize]
/// <summary>Exposes delivery management and driver-execution endpoints under backend policies.</summary>
public sealed class DeliveriesController : ControllerBase
{
    private readonly IDeliveryService _deliveries;
    private readonly IDeliveryProofImageService _proofImages;
    private readonly IPermissionService _permissions;

    public DeliveriesController(
        IDeliveryService deliveries,
        IDeliveryProofImageService proofImages,
        IPermissionService permissions)
    {
        _deliveries = deliveries;
        _proofImages = proofImages;
        _permissions = permissions;
    }

    [HttpGet]
    [HasPermission(Permissions.Deliveries.View)]
    // HTTP GET at the controller root queries filtered deliveries records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeliverySearchQueryDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _deliveries.SearchAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Search(
        [FromQuery] DeliverySearchQueryDto query,
        CancellationToken cancellationToken) =>
        await Execute(() => _deliveries.SearchAsync(query, cancellationToken));

    [HttpPost("schedule")]
    [HasPermission(Permissions.Deliveries.AssignDriver)]
    // HTTP POST at "schedule" handles the schedule operation for deliveries through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ScheduleDeliveryDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _deliveries.ScheduleAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Schedule(
        [FromBody] ScheduleDeliveryDto request,
        CancellationToken cancellationToken) =>
        await Execute(async () => new ObjectResult(new
        {
            message = "Delivery scheduled successfully.",
            delivery = await _deliveries.ScheduleAsync(request, UserId(), cancellationToken)
        }) { StatusCode = StatusCodes.Status201Created });

    [HttpGet("my")]
    [HasPermission(Permissions.Deliveries.ViewOwn)]
    // HTTP GET at "my" uses authenticated driver context to return only that driver's assignments.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _deliveries.MyDeliveriesAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> My(
        [FromQuery] string? status,
        [FromQuery] DateTime? fromUtc,
        [FromQuery] DateTime? toUtc,
        CancellationToken cancellationToken) =>
        await Execute(() => _deliveries.MyDeliveriesAsync(
            UserId(),
            status,
            fromUtc,
            toUtc,
            cancellationToken));

    [HttpGet("{id:int}")]
    [HasAnyPermission(
        Permissions.Deliveries.View,
        Permissions.Deliveries.ViewOwn)]
    // HTTP GET at "{id:int}" returns the authoritative deliveries projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _deliveries.GetAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Get(int id, CancellationToken cancellationToken) =>
        await Execute(() => _deliveries.GetAsync(
            id,
            UserId(),
            Role(),
            cancellationToken));

    [HttpGet("{id:int}/available-drivers")]
    [HasPermission(Permissions.Deliveries.AssignDriver)]
    // HTTP GET at "{id:int}/available-drivers" handles the available drivers operation for deliveries through
    // the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _deliveries.AvailableDriversAsync;
    // failures use existing HTTP handling.
    public async Task<IActionResult> AvailableDrivers(
        int id,
        CancellationToken cancellationToken) =>
        await Execute(() => _deliveries.AvailableDriversAsync(id, cancellationToken));

    [HttpPost("{id:int}/assign-driver")]
    [HasPermission(Permissions.Deliveries.AssignDriver)]
    // HTTP POST at "{id:int}/assign-driver" assigns an eligible driver through the delivery workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts AssignDriverDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _deliveries.AssignDriverAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> AssignDriver(
        int id,
        [FromBody] AssignDriverDto request,
        CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Driver assignment saved successfully.",
            delivery = await _deliveries.AssignDriverAsync(
                id,
                request,
                UserId(),
                cancellationToken)
        }));

    [HttpPost("{id:int}/unassign-driver")]
    [HasPermission(Permissions.Deliveries.ReassignDriver)]
    // HTTP POST at "{id:int}/unassign-driver" removes an assignment only while the delivery state permits it.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UnassignDriverDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _deliveries.UnassignDriverAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> UnassignDriver(
        int id,
        [FromBody] UnassignDriverDto request,
        CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Driver unassigned and assignment history preserved.",
            delivery = await _deliveries.UnassignDriverAsync(
                id,
                request,
                UserId(),
                cancellationToken)
        }));

    [HttpPost("{id:int}/start")]
    [HasPermission(Permissions.Deliveries.CompleteOwn)]
    // HTTP POST at "{id:int}/start" starts an assigned delivery through the legal status transition.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _deliveries.StartAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Start(int id, CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Delivery started and the order is now Out For Delivery.",
            delivery = await _deliveries.StartAsync(
                id,
                UserId(),
                Role(),
                cancellationToken)
        }));

    [HttpPost("{id:int}/complete")]
    [HasPermission(Permissions.Deliveries.CompleteOwn)]
    // HTTP POST at "{id:int}/complete" completes a delivery only after proof and workflow checks pass.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CompleteDeliveryDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _deliveries.CompleteAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Complete(
        int id,
        [FromBody] CompleteDeliveryDto request,
        CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Delivery completed and proof recorded.",
            proof = await _deliveries.CompleteAsync(
                id,
                request,
                UserId(),
                Role(),
                cancellationToken)
        }));

    [HttpGet("{id:int}/proof")]
    [HasPermission(Permissions.Deliveries.ViewProof)]
    // HTTP GET at "{id:int}/proof" handles the proof operation for deliveries through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _deliveries.GetProofAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Proof(int id, CancellationToken cancellationToken) =>
        await Execute(() => _deliveries.GetProofAsync(
            id,
            UserId(),
            Role(),
            cancellationToken));

    [HttpGet("{id:int}/proof-images")]
    [HasPermission(Permissions.Deliveries.ViewProof)]
    // HTTP GET at "{id:int}/proof-images" lists proof images without exposing protected storage paths.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _proofImages.ListAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> ProofImages(
        int id,
        CancellationToken cancellationToken) =>
        await Execute(() => _proofImages.ListAsync(
            id,
            UserId(),
            Role(),
            cancellationToken));

    [HttpPost("{id:int}/proof-images")]
    [HasAnyPermission(
        Permissions.Deliveries.ViewProof,
        Permissions.Mobile.DeliveryUploadProof)]
    [RequestSizeLimit(26 * 1024 * 1024)]
    // HTTP POST at "{id:int}/proof-images" accepts a bounded proof upload and associates it with the
    // delivery.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UploadDeliveryProofImageRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _proofImages.UploadAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> UploadProofImage(
        int id,
        IFormFile file,
        [FromForm] UploadDeliveryProofImageRequest request,
        CancellationToken cancellationToken) =>
        await Execute(async () => new ObjectResult(new
        {
            message = "The proof image was uploaded securely.",
            image = await _proofImages.UploadAsync(
                id,
                file,
                request,
                UserId(),
                Role(),
                await CanManageProofAsync(cancellationToken),
                cancellationToken)
        })
        {
            StatusCode = StatusCodes.Status201Created
        });

    [HttpGet("{id:int}/proof-images/{imageId:long}/file")]
    [HasPermission(Permissions.Deliveries.ViewProof)]
    // HTTP GET at "{id:int}/proof-images/{imageId:long}/file" streams an authorized proof image through
    // protected storage.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _proofImages.OpenAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> ProofImageFile(
        int id,
        long imageId,
        [FromQuery] bool thumbnail,
        CancellationToken cancellationToken)
    {
        try
        {
            var result = await _proofImages.OpenAsync(
                id,
                imageId,
                thumbnail,
                UserId(),
                Role(),
                cancellationToken);
            return File(
                result.Stream,
                result.StoredFile.ContentType,
                result.StoredFile.SafeDownloadName,
                enableRangeProcessing: false);
        }
        catch (DeliveryManagementException exception)
        {
            return new ObjectResult(new
            {
                message = exception.Message,
                details = exception.Details
            })
            {
                StatusCode = exception.StatusCode
            };
        }
    }

    [HttpDelete("{id:int}/proof-images/{imageId:long}")]
    [HasPermission(Permissions.Deliveries.ViewProof)]
    // HTTP DELETE at "{id:int}/proof-images/{imageId:long}" removes proof only when ownership or elevated
    // permission allows it.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RemoveDeliveryProofImageRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _proofImages.RemoveAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> RemoveProofImage(
        int id,
        long imageId,
        [FromBody] RemoveDeliveryProofImageRequest request,
        CancellationToken cancellationToken) =>
        await Execute(async () =>
        {
            await _proofImages.RemoveAsync(
                id,
                imageId,
                request.Reason,
                UserId(),
                Role(),
                await CanManageProofAsync(cancellationToken),
                cancellationToken);
            return Ok(new
            {
                message = "The proof image was removed and its history retained."
            });
        });

    private int UserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id)
            ? id
            : throw new DeliveryManagementException(
                401,
                "The authenticated user could not be identified.");

    private string Role() => User.FindFirstValue(ClaimTypes.Role) ?? string.Empty;

    private Task<bool> CanManageProofAsync(
        CancellationToken cancellationToken) =>
        _permissions.HasPermissionAsync(
            UserId(),
            Permissions.Deliveries.CompleteAny,
            cancellationToken);

    private static async Task<IActionResult> Execute<T>(Func<Task<T>> action)
    {
        try
        {
            var result = await action();

            return result is IActionResult actionResult
                ? actionResult
                : new OkObjectResult(result);
        }
        catch (DeliveryManagementException exception)
        {
            return new ObjectResult(new { message = exception.Message, details = exception.Details })
            {
                StatusCode = exception.StatusCode
            };
        }
    }

    private static async Task<IActionResult> Execute(Func<Task<IActionResult>> action)
    {
        try { return await action(); }
        catch (DeliveryManagementException exception)
        {
            return new ObjectResult(new { message = exception.Message, details = exception.Details })
            {
                StatusCode = exception.StatusCode
            };
        }
    }
}
