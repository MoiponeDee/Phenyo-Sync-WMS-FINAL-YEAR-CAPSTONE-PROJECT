using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/product-data-exchange/excel")]
/// <summary>Implements product workbook template, export, validation, import and result download.</summary>
public sealed class ProductDataExchangeController : ControllerBase
{
    private readonly IProductExcelExchangeService _exchange;

    public ProductDataExchangeController(IProductExcelExchangeService exchange)
    {
        _exchange = exchange;
    }

    [HttpGet("template")]
    [HasPermission(Permissions.ProductDataExchange.Export)]
    // HTTP GET at "template" downloads the canonical workbook template expected by validation.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Multipart file data crosses this boundary; size, type, and content validation remains server-side
    // before any persistent change is allowed.
    // The thin controller delegates business rules and persistence to _exchange.TemplateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Template(CancellationToken cancellationToken)
    {
        var file = await _exchange.TemplateAsync(UserId(), cancellationToken);
        return File(file.Content, file.ContentType, file.FileName);
    }

    [HttpGet("export")]
    [HasPermission(Permissions.ProductDataExchange.Export)]
    // HTTP GET at "export" exports the authorized product projection.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ProductExcelExportQueryDto instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _exchange.ExportAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Export(
        [FromQuery] ProductExcelExportQueryDto query,
        CancellationToken cancellationToken)
    {
        var file = await _exchange.ExportAsync(query, UserId(), cancellationToken);
        return File(file.Content, file.ContentType, file.FileName);
    }

    [HttpPost("validate")]
    [HasPermission(Permissions.ProductDataExchange.Import)]
    [RequestSizeLimit(51 * 1024 * 1024)]
    // HTTP POST at "validate" validates an uploaded workbook without persisting product changes.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _exchange.ValidateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<DataExchangeValidationResponseDto> Validate(
        IFormFile file,
        CancellationToken cancellationToken) =>
        _exchange.ValidateAsync(
            file,
            UserId(),
            HttpContext.TraceIdentifier,
            cancellationToken);

    [HttpPost("import")]
    [HasPermission(Permissions.ProductDataExchange.Import)]
    // HTTP POST at "import" applies only a previously validated import result.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ApplyDataExchangeRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _exchange.ImportAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<DataExchangeApplyResponseDto> Import(
        [FromQuery] string validationToken,
        ApplyDataExchangeRequest request,
        CancellationToken cancellationToken) =>
        _exchange.ImportAsync(
            validationToken,
            request,
            UserId(),
            cancellationToken);

    [HttpGet("results/{resultToken}")]
    [HasPermission(Permissions.ProductDataExchange.Import)]
    // HTTP GET at "results/{resultToken}" returns a short-lived import result without exposing server paths.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _exchange.ResultAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Result(
        string resultToken,
        CancellationToken cancellationToken)
    {
        var file = await _exchange.ResultAsync(
            resultToken,
            UserId(),
            cancellationToken);
        return File(file.Content, file.ContentType, file.FileName);
    }

    private int UserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)
            ? userId
            : throw new UnauthorizedAccessException();
}
