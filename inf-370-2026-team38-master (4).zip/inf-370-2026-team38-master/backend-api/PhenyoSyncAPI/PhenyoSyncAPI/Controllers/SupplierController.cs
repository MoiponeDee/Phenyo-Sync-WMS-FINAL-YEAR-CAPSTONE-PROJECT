using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Legacy;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/suppliers")]
[Authorize]
/// <summary>Exposes supplier records used by procurement and receiving workflows.</summary>
public sealed class SupplierController : ControllerBase
{
    private readonly PhenyoSyncDbContext _context;

    public SupplierController(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    [HasPermission(Permissions.Suppliers.View)]
    // HTTP GET at the controller root returns the authoritative supplier projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> GetAll(
        CancellationToken cancellationToken) =>
        Ok(await _context.Suppliers
            .AsNoTracking()
            .OrderBy(item => item.SupplierName)
            .Select(item => new
            {
                item.SupplierId,
                item.SupplierName,
                item.ContactPerson,
                item.Email,
                item.Phone,
                item.Address,
                item.Status
            })
            .ToListAsync(cancellationToken));

    [HttpPost]
    [HasPermission(Permissions.Suppliers.Manage)]
    // HTTP POST at the controller root creates or attaches supplier data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveSupplierRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Create(
        [FromBody] SaveSupplierRequest request,
        CancellationToken cancellationToken)
    {
        var name = request.SupplierName.Trim();
        if (await _context.Suppliers.AnyAsync(
                item => item.SupplierName == name,
                cancellationToken))
        {
            return Conflict(new
            {
                message = "A supplier with this name already exists."
            });
        }

        var supplier = new Supplier
        {
            SupplierName = name,
            ContactPerson = Clean(request.ContactPerson),
            Email = Clean(request.Email),
            Phone = Clean(request.Phone),
            Address = Clean(request.Address),
            Status = "Active"
        };
        _context.Suppliers.Add(supplier);
        await _context.SaveChangesAsync(cancellationToken);

        return StatusCode(
            StatusCodes.Status201Created,
            new
            {
                message = "The supplier was created successfully.",
                code = "SUPPLIER_CREATED",
                supplierId = supplier.SupplierId
            });
    }

    private static string? Clean(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
