using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Lookups;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [HasPermission(Permissions.ProductTypes.View)]
    /// <summary>Exposes Product Type master-data operations under type permissions.</summary>
    public class ProductTypeController : ControllerBase
    {
        private readonly PhenyoSyncDbContext _context;

        public ProductTypeController(PhenyoSyncDbContext context) => _context = context;

        [HttpGet]
        // HTTP GET at the controller root returns the authoritative product type projection needed by the client.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // EF queries are projected to response data rather than exposing tracked entities.
        public Task<List<ProductTypeDto>> GetAll(
            [FromQuery] string? searchTerm,
            [FromQuery] string? status,
            CancellationToken cancellationToken)
        {
            var query = _context.ProductTypes.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                var term = searchTerm.Trim();
                query = query.Where(item =>
                    item.ProductTypeName.Contains(term) ||
                    (item.Description != null && item.Description.Contains(term)));
            }
            if (!string.IsNullOrWhiteSpace(status)) query = query.Where(item => item.Status == status);
            return Project(query).OrderBy(item => item.ProductTypeName).ToListAsync(cancellationToken);
        }

        [HttpGet("active")]
        // HTTP GET at "active" handles the get active operation for product type through the established
        // workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // EF queries are projected to response data rather than exposing tracked entities.
        public Task<List<ProductTypeDto>> GetActive(CancellationToken cancellationToken) =>
            Project(_context.ProductTypes.AsNoTracking().Where(item => item.Status == ProductStatuses.Active))
                .OrderBy(item => item.ProductTypeName)
                .ToListAsync(cancellationToken);

        [HttpGet("{id:int}")]
        // HTTP GET at "{id:int}" handles the get by id operation for product type through the established
        // workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // EF queries are projected to response data rather than exposing tracked entities.
        public async Task<IActionResult> GetById(int id, CancellationToken cancellationToken)
        {
            var item = await Project(_context.ProductTypes.AsNoTracking())
                .FirstOrDefaultAsync(type => type.ProductTypeId == id, cancellationToken);
            return item is null ? NotFound(new { message = "Product type not found." }) : Ok(item);
        }

        [HttpPost]
        [HasPermission(Permissions.ProductTypes.Manage)]
        // HTTP POST at the controller root creates or attaches product type data through the controlled API
        // boundary.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts SaveProductTypeDto instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> Create(SaveProductTypeDto dto, CancellationToken cancellationToken)
        {
            var name = dto.ProductTypeName.Trim();
            if (await NameExists(name, null, cancellationToken))
                return Conflict(new { message = "A product type with this name already exists." });

            var item = new ProductType
            {
                ProductTypeName = name,
                Description = dto.Description?.Trim(),
                Status = ProductStatuses.Active,
                CreatedAt = DateTime.UtcNow
            };
            _context.ProductTypes.Add(item);
            await _context.SaveChangesAsync(cancellationToken);
            return CreatedAtAction(nameof(GetById), new { id = item.ProductTypeId }, new
            {
                message = "Product type created successfully.",
                productTypeId = item.ProductTypeId
            });
        }

        [HttpPut("{id:int}")]
        [HasPermission(Permissions.ProductTypes.Manage)]
        // HTTP PUT at "{id:int}" updates only allowed product type fields through a narrow request.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts SaveProductTypeDto instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> Update(int id, SaveProductTypeDto dto, CancellationToken cancellationToken)
        {
            var item = await _context.ProductTypes.FindAsync([id], cancellationToken);
            if (item is null) return NotFound(new { message = "Product type not found." });
            var name = dto.ProductTypeName.Trim();
            if (await NameExists(name, id, cancellationToken))
                return Conflict(new { message = "A product type with this name already exists." });

            item.ProductTypeName = name;
            item.Description = dto.Description?.Trim();
            item.Status = dto.Status;
            item.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync(cancellationToken);
            return Ok(new { message = "Product type updated successfully." });
        }

        [HttpDelete("{id:int}")]
        [HasPermission(Permissions.ProductTypes.Manage)]
        // HTTP DELETE at "{id:int}" removes or retires product type data after dependency checks.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> Delete(int id, CancellationToken cancellationToken)
        {
            var item = await _context.ProductTypes.FindAsync([id], cancellationToken);
            if (item is null) return NotFound(new { message = "Product type not found." });
            if (await _context.Products.AnyAsync(product => product.ProductTypeId == id, cancellationToken))
                return Conflict(new { message = "This product type is in use and cannot be deleted. Mark it Inactive instead." });
            _context.ProductTypes.Remove(item);
            await _context.SaveChangesAsync(cancellationToken);
            return Ok(new { message = "Product type deleted successfully." });
        }

        private Task<bool> NameExists(string name, int? excludedId, CancellationToken cancellationToken)
        {
            var normalized = name.ToUpper();
            return _context.ProductTypes.AnyAsync(item =>
                item.ProductTypeId != excludedId &&
                item.ProductTypeName.ToUpper() == normalized,
                cancellationToken);
        }

        private static IQueryable<ProductTypeDto> Project(IQueryable<ProductType> query) =>
            query.Select(item => new ProductTypeDto
            {
                ProductTypeId = item.ProductTypeId,
                ProductTypeName = item.ProductTypeName,
                Description = item.Description,
                Status = item.Status,
                CreatedAt = item.CreatedAt,
                UpdatedAt = item.UpdatedAt
            });
    }
}
