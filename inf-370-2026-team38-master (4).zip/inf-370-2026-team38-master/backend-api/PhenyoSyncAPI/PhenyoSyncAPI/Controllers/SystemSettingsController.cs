using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Configuration;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/system-settings")]
[Authorize]
[HasPermission(Permissions.SystemSettings.View)]
/// <summary>Reads and updates governed non-secret operational settings with history.</summary>
public sealed class SystemSettingsController : ControllerBase
{
    private readonly PhenyoSyncDbContext _context;
    private readonly ISystemSettingProvider _provider;
    private readonly IAuditContextAccessor _auditContext;

    public SystemSettingsController(
        PhenyoSyncDbContext context,
        ISystemSettingProvider provider,
        IAuditContextAccessor auditContext)
    {
        _context = context;
        _provider = provider;
        _auditContext = auditContext;
    }

    [HttpGet]
    // HTTP GET at the controller root queries filtered system settings records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Search(
        [FromQuery] string? search,
        [FromQuery] string? category,
        CancellationToken cancellationToken)
    {
        var source = _context.SystemSettings
            .AsNoTracking()
            .Where(item => item.IsActive && !item.IsSensitive);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            source = source.Where(item =>
                item.Key.Contains(term) ||
                item.DisplayName.Contains(term) ||
                item.Description.Contains(term));
        }
        if (!string.IsNullOrWhiteSpace(category))
        {
            var selected = category.Trim();
            source = source.Where(item => item.Category == selected);
        }

        var settings = await source
            .OrderBy(item => item.Category)
            .ThenBy(item => item.DisplayName)
            .Select(item => new
            {
                item.SystemSettingId,
                item.Key,
                item.Category,
                item.DisplayName,
                item.Description,
                item.ValueType,
                item.Value,
                item.DefaultValue,
                item.Unit,
                item.MinimumValue,
                item.MaximumValue,
                item.AllowedValuesJson,
                item.IsSystemSetting,
                item.RequiresRestart,
                item.UpdatedAtUtc,
                updatedBy = item.UpdatedByUser == null
                    ? "System"
                    : item.UpdatedByUser.FirstName + " " + item.UpdatedByUser.LastName,
                rowVersion = Convert.ToBase64String(
                    item.RowVersion ?? Array.Empty<byte>()),
                appliesImmediately = !item.RequiresRestart
            })
            .ToListAsync(cancellationToken);
        return Ok(settings);
    }

    [HttpGet("{key}")]
    // HTTP GET at "{key}" returns the authoritative system settings projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Get(
        string key,
        CancellationToken cancellationToken)
    {
        var setting = await _context.SystemSettings
            .AsNoTracking()
            .Where(item =>
                item.Key == key &&
                item.IsActive &&
                !item.IsSensitive)
            .Select(item => new
            {
                item.SystemSettingId,
                item.Key,
                item.Category,
                item.DisplayName,
                item.Description,
                item.ValueType,
                item.Value,
                item.DefaultValue,
                item.Unit,
                item.MinimumValue,
                item.MaximumValue,
                item.AllowedValuesJson,
                item.UpdatedAtUtc,
                updatedBy = item.UpdatedByUser == null
                    ? "System"
                    : item.UpdatedByUser.FirstName + " " + item.UpdatedByUser.LastName,
                rowVersion = Convert.ToBase64String(
                    item.RowVersion ?? Array.Empty<byte>()),
                appliesImmediately = !item.RequiresRestart
            })
            .SingleOrDefaultAsync(cancellationToken);
        return setting is null
            ? NotFound(new { message = "The system setting was not found." })
            : Ok(setting);
    }

    [HttpPost("{key}/validate")]
    [HasPermission(Permissions.SystemSettings.Manage)]
    // HTTP POST at "{key}/validate" validates the requested system settings operation on the server.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateSystemSettingRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // ValidateValue applies the setting's type, range and allowed-value rules; this action maps its result to
    // an explicit 200 or 400 response without persisting a change.
    public async Task<IActionResult> Validate(
        string key,
        [FromBody] UpdateSystemSettingRequest request,
        CancellationToken cancellationToken)
    {
        var result = await ValidateValue(key, request.Value, cancellationToken);
        return result.Error is null
            ? Ok(new
            {
                message = "The setting value is valid.",
                code = "SETTING_VALID",
                normalizedValue = result.Normalized
            })
            : BadRequest(new
            {
                message = result.Error,
                code = "SETTING_INVALID"
            });
    }

    [HttpPut("{key}")]
    [HasPermission(Permissions.SystemSettings.Manage)]
    // HTTP PUT at "{key}" updates only allowed system settings fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateSystemSettingRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _provider.Invalidate; failures use existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> Update(
        string key,
        [FromBody] UpdateSystemSettingRequest request,
        CancellationToken cancellationToken)
    {
        var setting = await _context.SystemSettings.SingleOrDefaultAsync(
            item => item.Key == key && !item.IsSensitive,
            cancellationToken);
        if (setting is null)
        {
            return NotFound(new { message = "The system setting was not found." });
        }
        if (!TryApplyRowVersion(setting, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The system setting version is invalid. Refresh and try again."
            });
        }

        var validation = await ValidateValue(
            setting.Key,
            request.Value,
            cancellationToken);
        if (validation.Error is not null)
        {
            return BadRequest(new
            {
                message = validation.Error,
                code = "SETTING_INVALID"
            });
        }

        var previous = setting.Value;
        setting.Value = validation.Normalized;
        setting.UpdatedAtUtc = DateTime.UtcNow;
        setting.UpdatedByUserId = CurrentUserId();
        setting.History.Add(History(
            setting,
            previous,
            validation.Normalized,
            request.Reason,
            true));

        try
        {
            await _context.SaveChangesAsync(cancellationToken);
        }
        catch (DbUpdateConcurrencyException)
        {
            return Conflict(new
            {
                message = "The setting changed after it was loaded. Refresh and try again.",
                code = "SETTING_CONCURRENCY_CONFLICT"
            });
        }

        _provider.Invalidate(setting.Key);
        return Ok(new
        {
            message = "The business rule was updated and applies immediately.",
            code = "SETTING_UPDATED",
            setting.Key,
            setting.Value,
            appliedImmediately = true
        });
    }

    [HttpPost("{key}/reset")]
    [HasPermission(Permissions.SystemSettings.Manage)]
    // HTTP POST at "{key}/reset" handles the reset operation for system settings through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ResetSystemSettingRequest instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _provider.Invalidate; failures use existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> Reset(
        string key,
        [FromBody] ResetSystemSettingRequest request,
        CancellationToken cancellationToken)
    {
        var setting = await _context.SystemSettings.SingleOrDefaultAsync(
            item => item.Key == key && !item.IsSensitive,
            cancellationToken);
        if (setting is null)
        {
            return NotFound(new { message = "The system setting was not found." });
        }
        if (!TryApplyRowVersion(setting, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The system setting version is invalid. Refresh and try again."
            });
        }

        var validation = await ValidateValue(
            setting.Key,
            setting.DefaultValue,
            cancellationToken);
        if (validation.Error is not null)
        {
            return Conflict(new
            {
                message = "The configured default is not valid for the current system state.",
                code = "SETTING_DEFAULT_INVALID"
            });
        }

        var previous = setting.Value;
        setting.Value = validation.Normalized;
        setting.UpdatedAtUtc = DateTime.UtcNow;
        setting.UpdatedByUserId = CurrentUserId();
        setting.History.Add(History(
            setting,
            previous,
            validation.Normalized,
            request.Reason,
            true));
        await _context.SaveChangesAsync(cancellationToken);
        _provider.Invalidate(setting.Key);
        return Ok(new
        {
            message = "The business rule was reset to its default and applies immediately.",
            code = "SETTING_RESET",
            setting.Key,
            setting.Value,
            appliedImmediately = true
        });
    }

    [HttpGet("{key}/history")]
    // HTTP GET at "{key}/history" returns the authoritative system settings projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _context.Entry; failures use existing
    // HTTP handling.
    public async Task<IActionResult> History(
        string key,
        CancellationToken cancellationToken)
    {
        var exists = await _context.SystemSettings
            .AsNoTracking()
            .AnyAsync(item => item.Key == key && !item.IsSensitive, cancellationToken);
        if (!exists)
        {
            return NotFound(new { message = "The system setting was not found." });
        }

        var history = await _context.SystemSettingHistory
            .AsNoTracking()
            .Where(item => item.SystemSetting.Key == key)
            .OrderByDescending(item => item.ChangedAtUtc)
            .Select(item => new
            {
                item.SystemSettingHistoryId,
                item.PreviousValue,
                item.NewValue,
                item.ChangedAtUtc,
                changedBy = item.ChangedByUser == null
                    ? "System"
                    : item.ChangedByUser.FirstName + " " + item.ChangedByUser.LastName,
                item.Reason,
                item.CorrelationId,
                item.AppliedSuccessfully,
                item.FailureReason
            })
            .ToListAsync(cancellationToken);
        return Ok(history);
    }

    private async Task<(string Normalized, string? Error)> ValidateValue(
        string key,
        string rawValue,
        CancellationToken cancellationToken)
    {
        if (!PhaseA2Catalog.TryGetSetting(key, out var definition))
        {
            return (string.Empty, "Unknown settings cannot be added through this interface.");
        }
        if (!PhaseA2Catalog.TryNormalizeValue(
                definition,
                rawValue,
                out var normalized,
                out var error))
        {
            return (string.Empty, error);
        }

        if (key == SystemSettingKeys.ExpiryRecipientRoleCodes)
        {
            var roles = JsonSerializer.Deserialize<string[]>(normalized) ?? [];
            var valid = await _context.Roles
                .AsNoTracking()
                .CountAsync(item =>
                    item.IsActive &&
                    roles.Contains(item.RoleCode),
                    cancellationToken);
            if (valid != roles.Length)
            {
                return (string.Empty, "Select only active system roles for expiry notifications.");
            }
        }

        if (key is SystemSettingKeys.ExpiryYellowThresholdHours or
            SystemSettingKeys.ExpiryRedThresholdHours)
        {
            var proposed = int.Parse(normalized);
            var otherKey = key == SystemSettingKeys.ExpiryYellowThresholdHours
                ? SystemSettingKeys.ExpiryRedThresholdHours
                : SystemSettingKeys.ExpiryYellowThresholdHours;
            var other = await _context.SystemSettings
                .AsNoTracking()
                .Where(item => item.Key == otherKey)
                .Select(item => item.Value)
                .SingleOrDefaultAsync(cancellationToken)
                ?? PhaseA2Catalog.GetSetting(otherKey).DefaultValue;
            var otherValue = int.Parse(other);
            var yellow = key == SystemSettingKeys.ExpiryYellowThresholdHours
                ? proposed
                : otherValue;
            var red = key == SystemSettingKeys.ExpiryRedThresholdHours
                ? proposed
                : otherValue;
            if (yellow <= red)
            {
                return (string.Empty, "The yellow warning threshold must be greater than the red urgent threshold.");
            }
        }

        return (normalized, null);
    }

    private SystemSettingHistory History(
        SystemSetting setting,
        string previous,
        string next,
        string reason,
        bool appliedSuccessfully) =>
        new()
        {
            PreviousValue = previous,
            NewValue = next,
            ChangedAtUtc = DateTime.UtcNow,
            ChangedByUserId = CurrentUserId(),
            Reason = reason.Trim(),
            CorrelationId = _auditContext.Current.CorrelationId,
            AppliedSuccessfully = appliedSuccessfully
        };

    private bool TryApplyRowVersion(
        SystemSetting setting,
        string encoded)
    {
        try
        {
            _context.Entry(setting)
                .Property(item => item.RowVersion)
                .OriginalValue = Convert.FromBase64String(encoded);
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
    }

    private int CurrentUserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)
            ? userId
            : throw new UnauthorizedAccessException();
}
