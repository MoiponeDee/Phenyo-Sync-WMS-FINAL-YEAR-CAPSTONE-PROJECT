using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Pricing;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/prices")]
[HasPermission(Permissions.Pricing.View)]
/// <summary>Exposes effective-dated product pricing and price-history operations.</summary>
public sealed class PricesController : ControllerBase
{
    private readonly IProductPricingService _pricing;
    private readonly IPermissionService _permissions;

    public PricesController(
        IProductPricingService pricing,
        IPermissionService permissions)
    {
        _pricing = pricing;
        _permissions = permissions;
    }

    [HttpPost]
    [HasAnyPermission(Permissions.Pricing.Create, Permissions.Pricing.Manage)]
    // HTTP POST at the controller root creates or attaches prices data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateProductPriceDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _pricing.CreateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<IActionResult> Create(
        [FromBody] CreateProductPriceDto dto,
        CancellationToken cancellationToken) =>
        Execute(async () => Ok(new
        {
            message = "Initial price created successfully.",
            price = await _pricing.CreateAsync(dto, UserId(), cancellationToken)
        }));

    [HttpGet]
    // HTTP GET at the controller root queries filtered prices records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ProductPriceSearchDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _pricing.SearchAsync; failures use
    // existing HTTP handling.
    public Task<IActionResult> Search(
        [FromQuery] ProductPriceSearchDto query,
        CancellationToken cancellationToken) =>
        Execute(async () =>
        {
            var mayManage = await MayManagePricingAsync(cancellationToken);
            return Ok(await _pricing.SearchAsync(
                query,
                mayManage,
                cancellationToken));
        });

    [HttpGet("orderable-products")]
    // HTTP GET at "orderable-products" handles the orderable products operation for prices through the
    // established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _pricing.GetOrderableProductsAsync;
    // failures use existing HTTP handling.
    public Task<IActionResult> OrderableProducts(CancellationToken cancellationToken) =>
        Execute(async () => Ok(await _pricing.GetOrderableProductsAsync(cancellationToken)));

    [HttpGet("product/{productId:int}/current")]
    // HTTP GET at "product/{productId:int}/current" returns the authoritative prices projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _pricing.SearchAsync; failures use
    // existing HTTP handling.
    public Task<IActionResult> Current(
        int productId,
        CancellationToken cancellationToken) =>
        Execute(async () =>
        {
            var result = await _pricing.SearchAsync(
                new ProductPriceSearchDto
                {
                    ProductId = productId,
                    Status = PriceRecordStatuses.Current,
                    PageSize = 1
                },
                false,
                cancellationToken);

            return result.Items.Count == 0
                ? NotFound(new { message = "This product has no current price." })
                : Ok(result.Items[0]);
        });

    [HttpGet("product/{productId:int}/history")]
    [HasAnyPermission(
        Permissions.Pricing.ViewHistory,
        Permissions.Pricing.Manage)]
    // HTTP GET at "product/{productId:int}/history" returns the authoritative prices projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _pricing.GetHistoryAsync; failures use
    // existing HTTP handling.
    public Task<IActionResult> History(
        int productId,
        CancellationToken cancellationToken) =>
        Execute(async () =>
        {
            var mayManage = await MayManagePricingAsync(cancellationToken);
            return Ok(await _pricing.GetHistoryAsync(
                productId,
                mayManage,
                cancellationToken));
        });

    [HttpGet("{id:int}")]
    // HTTP GET at "{id:int}" returns the authoritative prices projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _pricing.GetAsync; failures use
    // existing HTTP handling.
    public Task<IActionResult> Get(
        int id,
        CancellationToken cancellationToken) =>
        Execute(async () =>
        {
            var mayManage = await MayManagePricingAsync(cancellationToken);
            return Ok(await _pricing.GetAsync(
                id,
                mayManage,
                cancellationToken));
        });

    [HttpPut("{id:int}")]
    [HasAnyPermission(Permissions.Pricing.Create, Permissions.Pricing.Manage)]
    // HTTP PUT at "{id:int}" updates only allowed prices fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateProductPriceDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _pricing.UpdateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<IActionResult> Update(
        int id,
        [FromBody] UpdateProductPriceDto dto,
        CancellationToken cancellationToken) =>
        Execute(async () => Ok(await _pricing.UpdateAsync(
            id,
            dto,
            UserId(),
            cancellationToken)));

    [HttpPost("{id:int}/soft-delete")]
    [HasAnyPermission(Permissions.Pricing.Cancel, Permissions.Pricing.Manage)]
    // HTTP POST at "{id:int}/soft-delete" handles the soft delete operation for prices through the
    // established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeleteProductPriceDto instead of an EF entity, limiting fields and preventing over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _pricing.SoftDeleteAsync; failures use
    // existing HTTP handling.
    public Task<IActionResult> SoftDelete(
        int id,
        [FromBody] DeleteProductPriceDto dto,
        CancellationToken cancellationToken) =>
        Execute(async () => Ok(new
        {
            message = "Price record soft deleted. Historical data was retained.",
            price = await _pricing.SoftDeleteAsync(
                id,
                dto,
                UserId(),
                cancellationToken)
        }));

    private int UserId()
    {
        return int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)
            ? userId
            : throw new PricingException(401, "The authenticated user could not be identified.");
    }

    private Task<bool> MayManagePricingAsync(
        CancellationToken cancellationToken) =>
        MayManagePricingCoreAsync(cancellationToken);

    private async Task<bool> MayManagePricingCoreAsync(
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        return await _permissions.HasPermissionAsync(
                   userId,
                   Permissions.Pricing.Manage,
                   cancellationToken) ||
               await _permissions.HasPermissionAsync(
                   userId,
                   Permissions.Pricing.Cancel,
                   cancellationToken);
    }

    private static async Task<IActionResult> Execute(Func<Task<IActionResult>> action)
    {
        try
        {
            return await action();
        }
        catch (PricingException exception)
        {
            return new ObjectResult(new
            {
                message = exception.Message,
                code = exception.Code
            })
            {
                StatusCode = exception.StatusCode
            };
        }
    }
}
