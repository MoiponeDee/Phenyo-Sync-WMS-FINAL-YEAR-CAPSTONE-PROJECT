using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Security;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/permissions")]
[Authorize]
/// <summary>Returns and manages the backend-authoritative role-permission model.</summary>
public sealed class PermissionController : ControllerBase
{
    private readonly PhenyoSyncDbContext _context;

    public PermissionController(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    [HasPermission(Permissions.PermissionDefinitions.View)]
    // HTTP GET at the controller root queries filtered permission records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts PermissionSearchQuery instead of an EF entity, limiting fields and preventing over-posting.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> Search(
        [FromQuery] PermissionSearchQuery query,
        CancellationToken cancellationToken)
    {
        var permissions = _context.Permissions.AsNoTracking().AsQueryable();
        if (!query.IncludeInactive)
        {
            permissions = permissions.Where(item => item.IsActive);
        }

        if (!string.IsNullOrWhiteSpace(query.Module))
        {
            permissions = permissions.Where(item =>
                item.Module == query.Module);
        }

        if (!string.IsNullOrWhiteSpace(query.Search))
        {
            var search = query.Search.Trim();
            permissions = permissions.Where(item =>
                item.PermissionCode.Contains(search) ||
                item.DisplayName.Contains(search) ||
                item.Module.Contains(search));
        }

        return Ok(await permissions
            .OrderBy(item => item.Module)
            .ThenBy(item => item.DisplayName)
            .Select(item => new
            {
                item.PermissionId,
                item.PermissionCode,
                item.DisplayName,
                item.Module,
                item.Description,
                item.IsSystemPermission,
                item.IsActive,
                assignedRoleCount = item.RolePermissions.Count,
                rowVersion = Convert.ToBase64String(
                    item.RowVersion ?? Array.Empty<byte>())
            })
            .ToListAsync(cancellationToken));
    }

    [HttpPost]
    [HasPermission(Permissions.PermissionDefinitions.Create)]
    // HTTP POST at the controller root creates or attaches permission data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreatePermissionRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Create(
        [FromBody] CreatePermissionRequest request,
        CancellationToken cancellationToken)
    {
        var code = request.PermissionCode.Trim();
        if (await _context.Permissions.AnyAsync(
                item => item.PermissionCode == code,
                cancellationToken))
        {
            return Conflict(new
            {
                message = "A permission with this code already exists."
            });
        }

        var permission = new Permission
        {
            PermissionCode = code,
            PermissionName = code,
            DisplayName = request.DisplayName.Trim(),
            Module = request.Module.Trim(),
            Description = NullIfWhiteSpace(request.Description),
            IsSystemPermission = false,
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        _context.Permissions.Add(permission);
        await _context.SaveChangesAsync(cancellationToken);

        return StatusCode(
            StatusCodes.Status201Created,
            new
            {
                message = "The custom permission was created.",
                code = "PERMISSION_CREATED",
                permissionId = permission.PermissionId
            });
    }

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.PermissionDefinitions.Update)]
    // HTTP PUT at "{id:int}" updates only allowed permission fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdatePermissionRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> Update(
        int id,
        [FromBody] UpdatePermissionRequest request,
        CancellationToken cancellationToken)
    {
        var permission = await _context.Permissions.SingleOrDefaultAsync(
            item => item.PermissionId == id,
            cancellationToken);
        if (permission is null)
        {
            return NotFound(new
            {
                message = "The selected permission was not found."
            });
        }

        if (!TryApplyRowVersion(permission, request.RowVersion))
        {
            return BadRequest(new
            {
                message =
                    "The permission version is invalid. Refresh and try again."
            });
        }

        permission.DisplayName = request.DisplayName.Trim();
        permission.Module = request.Module.Trim();
        permission.Description = NullIfWhiteSpace(request.Description);
        permission.UpdatedAtUtc = DateTime.UtcNow;
        await TouchAssignedUsers(permission.PermissionId, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new
        {
            message = "The permission was updated successfully.",
            code = "PERMISSION_UPDATED"
        });
    }

    [HttpPost("{id:int}/status")]
    [HasPermission(Permissions.PermissionDefinitions.Deactivate)]
    // HTTP POST at "{id:int}/status" changes permission state only through the supported status operation.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts PermissionStatusRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> ChangeStatus(
        int id,
        [FromBody] PermissionStatusRequest request,
        CancellationToken cancellationToken)
    {
        var permission = await _context.Permissions.SingleOrDefaultAsync(
            item => item.PermissionId == id,
            cancellationToken);
        if (permission is null)
        {
            return NotFound(new
            {
                message = "The selected permission was not found."
            });
        }

        if (!TryApplyRowVersion(permission, request.RowVersion))
        {
            return BadRequest(new
            {
                message =
                    "The permission version is invalid. Refresh and try again."
            });
        }

        permission.IsActive = request.IsActive;
        permission.UpdatedAtUtc = DateTime.UtcNow;
        await TouchAssignedUsers(permission.PermissionId, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);

        return Ok(new
        {
            message = request.IsActive
                ? "The permission was activated successfully."
                : "The permission was deactivated successfully.",
            code = request.IsActive
                ? "PERMISSION_ACTIVATED"
                : "PERMISSION_DEACTIVATED"
        });
    }

    [HttpDelete("{id:int}")]
    [HasPermission(Permissions.PermissionDefinitions.Delete)]
    // HTTP DELETE at "{id:int}" removes or retires permission data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
    // _context.Entry; failures use existing HTTP handling.
    public async Task<IActionResult> Delete(
        int id,
        CancellationToken cancellationToken)
    {
        var permission = await _context.Permissions
            .Include(item => item.RolePermissions)
            .SingleOrDefaultAsync(
                item => item.PermissionId == id,
                cancellationToken);
        if (permission is null)
        {
            return NotFound(new
            {
                message = "The selected permission was not found."
            });
        }

        if (permission.IsSystemPermission)
        {
            return Conflict(new
            {
                message = "System permissions cannot be deleted."
            });
        }

        if (permission.RolePermissions.Count > 0)
        {
            return Conflict(new
            {
                message =
                    "This permission is assigned to roles. Deactivate it instead."
            });
        }

        _context.Permissions.Remove(permission);
        await _context.SaveChangesAsync(cancellationToken);
        return Ok(new
        {
            message = "The unused custom permission was deleted.",
            code = "PERMISSION_DELETED"
        });
    }

    private async Task TouchAssignedUsers(
        int permissionId,
        CancellationToken cancellationToken)
    {
        var roleIds = await _context.RolePermissions
            .Where(item => item.PermissionId == permissionId)
            .Select(item => item.RoleId)
            .ToListAsync(cancellationToken);
        var users = await _context.Users
            .Where(item => roleIds.Contains(item.RoleId))
            .ToListAsync(cancellationToken);
        foreach (var user in users)
        {
            user.SecurityVersion++;
            user.UpdatedAtUtc = DateTime.UtcNow;
        }
    }

    private bool TryApplyRowVersion(
        Permission permission,
        string rowVersion)
    {
        try
        {
            _context.Entry(permission)
                .Property(item => item.RowVersion)
                .OriginalValue = Convert.FromBase64String(rowVersion);
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
    }

    private static string? NullIfWhiteSpace(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
