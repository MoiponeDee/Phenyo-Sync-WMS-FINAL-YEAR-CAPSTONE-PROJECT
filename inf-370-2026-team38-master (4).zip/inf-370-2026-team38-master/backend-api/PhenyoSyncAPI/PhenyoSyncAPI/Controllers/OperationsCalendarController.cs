using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

// Exposes permission-protected operational milestones without leaking unrelated workflow data.
namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/operations-calendar")]
[HasPermission(Permissions.OperationsCalendar.View)]
public sealed class OperationsCalendarController : ControllerBase
{
    private readonly IOperationsCalendarService _calendar;

    public OperationsCalendarController(IOperationsCalendarService calendar)
    {
        _calendar = calendar;
    }

    [HttpGet("events")]
    // HTTP GET at "events" returns the authoritative operations calendar projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts OperationsCalendarQueryDto instead of an EF entity, limiting fields and preventing
    // over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _calendar.GetAsync; failures use
    // existing HTTP handling.
    public Task<OperationsCalendarResponseDto> Events(
        [FromQuery] OperationsCalendarQueryDto query,
        CancellationToken cancellationToken) =>
        _calendar.GetAsync(
            query,
            UserId(),
            User.FindFirstValue(ClaimTypes.Role) ?? string.Empty,
            cancellationToken);

    private int UserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)
            ? userId
            : throw new UnauthorizedAccessException();
}
