using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Configuration;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/lookups")]
[Authorize]
/// <summary>Exposes governed lookup values used by forms and operational validation.</summary>
public sealed class LookupsController : ControllerBase
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditContextAccessor _auditContext;

    public LookupsController(
        PhenyoSyncDbContext context,
        IAuditContextAccessor auditContext)
    {
        _context = context;
        _auditContext = auditContext;
    }

    [HttpGet("types")]
    [HasPermission(Permissions.Lookups.View)]
    // HTTP GET at "types" handles the search types operation for lookups through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts LookupSearchQuery instead of an EF entity, limiting fields and preventing over-posting.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> SearchTypes(
        [FromQuery] LookupSearchQuery query,
        CancellationToken cancellationToken)
    {
        var source = _context.LookupTypes.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(query.Search))
        {
            var search = query.Search.Trim();
            source = source.Where(item =>
                item.SystemCode.Contains(search) ||
                item.DisplayName.Contains(search) ||
                item.Description != null && item.Description.Contains(search));
        }
        if (query.IsActive.HasValue)
        {
            source = source.Where(item => item.IsActive == query.IsActive);
        }

        var total = await source.CountAsync(cancellationToken);
        var items = await source
            .OrderBy(item => item.DisplayName)
            .Skip((query.Page - 1) * query.PageSize)
            .Take(query.PageSize)
            .Select(item => new
            {
                item.LookupTypeId,
                item.SystemCode,
                item.DisplayName,
                item.Description,
                item.IsSystemType,
                item.IsActive,
                valueCount = item.Values.Count,
                activeValueCount = item.Values.Count(value => value.IsActive),
                item.CreatedAtUtc,
                item.UpdatedAtUtc,
                rowVersion = Convert.ToBase64String(
                    item.RowVersion ?? Array.Empty<byte>())
            })
            .ToListAsync(cancellationToken);

        return Ok(new
        {
            items,
            query.Page,
            query.PageSize,
            total,
            totalPages = total == 0
                ? 0
                : (int)Math.Ceiling(total / (double)query.PageSize)
        });
    }

    [HttpGet("types/{typeCode}")]
    [HasPermission(Permissions.Lookups.View)]
    // HTTP GET at "types/{typeCode}" handles the get type operation for lookups through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts LookupSearchQuery instead of an EF entity, limiting fields and preventing over-posting.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> GetType(
        string typeCode,
        [FromQuery] LookupSearchQuery query,
        CancellationToken cancellationToken)
    {
        var normalized = typeCode.Trim().ToUpperInvariant();
        var type = await _context.LookupTypes
            .AsNoTracking()
            .SingleOrDefaultAsync(
                item => item.SystemCode == normalized,
                cancellationToken);
        if (type is null)
        {
            return NotFound(new { message = "The lookup type was not found." });
        }

        var source = _context.LookupValues
            .AsNoTracking()
            .Where(item => item.LookupTypeId == type.LookupTypeId);
        if (!string.IsNullOrWhiteSpace(query.Search))
        {
            var search = query.Search.Trim();
            source = source.Where(item =>
                item.SystemCode.Contains(search) ||
                item.DisplayName.Contains(search) ||
                item.Description != null && item.Description.Contains(search));
        }
        if (query.IsActive.HasValue)
        {
            source = source.Where(item => item.IsActive == query.IsActive);
        }

        var total = await source.CountAsync(cancellationToken);
        var values = await ProjectValues(source)
            .OrderBy(item => item.SortOrder)
            .ThenBy(item => item.DisplayName)
            .Skip((query.Page - 1) * query.PageSize)
            .Take(query.PageSize)
            .ToListAsync(cancellationToken);

        return Ok(new
        {
            type.LookupTypeId,
            type.SystemCode,
            type.DisplayName,
            type.Description,
            type.IsSystemType,
            type.IsActive,
            rowVersion = Convert.ToBase64String(
                type.RowVersion ?? Array.Empty<byte>()),
            values,
            query.Page,
            query.PageSize,
            total,
            totalPages = total == 0
                ? 0
                : (int)Math.Ceiling(total / (double)query.PageSize)
        });
    }

    [HttpGet("types/{typeCode}/active-values")]
    [HasPermission(Permissions.Lookups.View)]
    // HTTP GET at "types/{typeCode}/active-values" handles the active values operation for lookups through
    // the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> ActiveValues(
        string typeCode,
        CancellationToken cancellationToken)
    {
        var normalized = typeCode.Trim().ToUpperInvariant();
        var values = await ProjectValues(
                _context.LookupValues
                    .AsNoTracking()
                    .Where(item =>
                        item.IsActive &&
                        item.LookupType.IsActive &&
                        item.LookupType.SystemCode == normalized))
            .OrderBy(item => item.SortOrder)
            .ThenBy(item => item.DisplayName)
            .ToListAsync(cancellationToken);
        return Ok(values);
    }

    [HttpPost("types")]
    [HasPermission(Permissions.Lookups.Manage)]
    // HTTP POST at "types" creates or attaches lookups data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveLookupTypeRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> CreateType(
        [FromBody] SaveLookupTypeRequest request,
        CancellationToken cancellationToken)
    {
        var code = request.SystemCode.Trim().ToUpperInvariant();
        var name = request.DisplayName.Trim();
        if (await _context.LookupTypes.AnyAsync(item =>
                item.SystemCode == code ||
                item.DisplayName.ToUpper() == name.ToUpper(),
                cancellationToken))
        {
            return Conflict(new
            {
                message = "A lookup type with this code or name already exists."
            });
        }

        var type = new LookupType
        {
            SystemCode = code,
            DisplayName = name,
            Description = NullIfWhiteSpace(request.Description),
            IsSystemType = false,
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        _context.LookupTypes.Add(type);
        await _context.SaveChangesAsync(cancellationToken);
        return CreatedAtAction(
            nameof(GetType),
            new { typeCode = type.SystemCode },
            new
            {
                message = "The lookup type was created successfully.",
                code = "LOOKUP_TYPE_CREATED",
                type.LookupTypeId
            });
    }

    [HttpPut("types/{id:int}")]
    [HasPermission(Permissions.Lookups.Manage)]
    // HTTP PUT at "types/{id:int}" updates only allowed lookups fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveLookupTypeRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> UpdateType(
        int id,
        [FromBody] SaveLookupTypeRequest request,
        CancellationToken cancellationToken)
    {
        var type = await _context.LookupTypes.SingleOrDefaultAsync(
            item => item.LookupTypeId == id,
            cancellationToken);
        if (type is null)
        {
            return NotFound(new { message = "The lookup type was not found." });
        }
        if (!string.Equals(
                type.SystemCode,
                request.SystemCode.Trim(),
                StringComparison.OrdinalIgnoreCase))
        {
            return Conflict(new
            {
                message = "The lookup type system code is immutable."
            });
        }
        if (!ApplyRowVersion(type, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The lookup type version is invalid. Refresh and try again."
            });
        }

        var name = request.DisplayName.Trim();
        if (await _context.LookupTypes.AnyAsync(item =>
                item.LookupTypeId != id &&
                item.DisplayName.ToUpper() == name.ToUpper(),
                cancellationToken))
        {
            return Conflict(new { message = "This lookup type name is already used." });
        }

        type.DisplayName = name;
        type.Description = NullIfWhiteSpace(request.Description);
        type.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
        return Ok(new
        {
            message = "The lookup type was updated successfully.",
            code = "LOOKUP_TYPE_UPDATED"
        });
    }

    [HttpPost("types/{id:int}/status")]
    [HasPermission(Permissions.Lookups.Manage)]
    // HTTP POST at "types/{id:int}/status" handles the change type status operation for lookups through the
    // established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ChangeConfigurationStatusRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> ChangeTypeStatus(
        int id,
        [FromBody] ChangeConfigurationStatusRequest request,
        CancellationToken cancellationToken)
    {
        var type = await _context.LookupTypes.SingleOrDefaultAsync(
            item => item.LookupTypeId == id,
            cancellationToken);
        if (type is null)
        {
            return NotFound(new { message = "The lookup type was not found." });
        }
        if (!ApplyRowVersion(type, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The lookup type version is invalid. Refresh and try again."
            });
        }

        type.IsActive = request.IsActive;
        type.UpdatedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
        return Ok(new
        {
            message = request.IsActive
                ? "The lookup type was activated."
                : "The lookup type was deactivated. It is no longer available to operational forms.",
            code = request.IsActive
                ? "LOOKUP_TYPE_ACTIVATED"
                : "LOOKUP_TYPE_DEACTIVATED"
        });
    }

    [HttpDelete("types/{id:int}")]
    [HasPermission(Permissions.Lookups.Manage)]
    // HTTP DELETE at "types/{id:int}" removes or retires lookups data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeleteConfigurationRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> DeleteType(
        int id,
        [FromBody] DeleteConfigurationRequest request,
        CancellationToken cancellationToken)
    {
        var type = await _context.LookupTypes
            .Include(item => item.Values)
            .SingleOrDefaultAsync(
                item => item.LookupTypeId == id,
                cancellationToken);
        if (type is null)
        {
            return NotFound(new { message = "The lookup type was not found." });
        }
        if (type.IsSystemType)
        {
            return Conflict(new { message = "System lookup types cannot be deleted." });
        }
        if (type.Values.Count > 0)
        {
            return Conflict(new
            {
                message = "This lookup type has values. Deactivate it instead."
            });
        }

        _context.LookupTypes.Remove(type);
        await _context.SaveChangesAsync(cancellationToken);
        return Ok(new
        {
            message = "The unused custom lookup type was deleted.",
            code = "LOOKUP_TYPE_DELETED"
        });
    }

    [HttpPost("types/{typeCode}/values")]
    [HasPermission(Permissions.Lookups.Manage)]
    // HTTP POST at "types/{typeCode}/values" creates or attaches lookups data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveLookupValueRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> CreateValue(
        string typeCode,
        [FromBody] SaveLookupValueRequest request,
        CancellationToken cancellationToken)
    {
        var type = await FindType(typeCode, cancellationToken);
        if (type is null)
        {
            return NotFound(new { message = "The lookup type was not found." });
        }
        if (!type.IsActive)
        {
            return Conflict(new { message = "Activate the lookup type before adding values." });
        }

        var code = request.SystemCode.Trim().ToUpperInvariant();
        var name = request.DisplayName.Trim();
        if (await _context.LookupValues.AnyAsync(item =>
                item.LookupTypeId == type.LookupTypeId &&
                (item.SystemCode == code ||
                 item.DisplayName.ToUpper() == name.ToUpper()),
                cancellationToken))
        {
            return Conflict(new
            {
                message = "A value with this code or name already exists in the lookup type."
            });
        }

        var value = new LookupValue
        {
            LookupTypeId = type.LookupTypeId,
            SystemCode = code,
            DisplayName = name,
            Description = NullIfWhiteSpace(request.Description),
            SortOrder = request.SortOrder,
            IsSystemValue = false,
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow
        };
        _context.LookupValues.Add(value);
        await _context.SaveChangesAsync(cancellationToken);
        AddHistory(value, "Create", null, SafeSnapshot(value), request.Reason);
        await _context.SaveChangesAsync(cancellationToken);
        return CreatedAtAction(
            nameof(GetType),
            new { typeCode = type.SystemCode },
            new
            {
                message = "The lookup value was created successfully.",
                code = "LOOKUP_VALUE_CREATED",
                value.LookupValueId
            });
    }

    [HttpPut("values/{id:int}")]
    [HasPermission(Permissions.Lookups.Manage)]
    // HTTP PUT at "values/{id:int}" updates only allowed lookups fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveLookupValueRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> UpdateValue(
        int id,
        [FromBody] SaveLookupValueRequest request,
        CancellationToken cancellationToken)
    {
        var value = await _context.LookupValues.SingleOrDefaultAsync(
            item => item.LookupValueId == id,
            cancellationToken);
        if (value is null)
        {
            return NotFound(new { message = "The lookup value was not found." });
        }
        if (!string.Equals(
                value.SystemCode,
                request.SystemCode.Trim(),
                StringComparison.OrdinalIgnoreCase))
        {
            return Conflict(new { message = "The lookup value system code is immutable." });
        }
        if (!ApplyRowVersion(value, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The lookup value version is invalid. Refresh and try again."
            });
        }

        var name = request.DisplayName.Trim();
        if (await _context.LookupValues.AnyAsync(item =>
                item.LookupValueId != id &&
                item.LookupTypeId == value.LookupTypeId &&
                item.DisplayName.ToUpper() == name.ToUpper(),
                cancellationToken))
        {
            return Conflict(new { message = "This lookup value name is already used." });
        }

        var before = SafeSnapshot(value);
        value.DisplayName = name;
        value.Description = NullIfWhiteSpace(request.Description);
        value.SortOrder = request.SortOrder;
        value.UpdatedAtUtc = DateTime.UtcNow;
        AddHistory(value, "Update", before, SafeSnapshot(value), request.Reason);
        await _context.SaveChangesAsync(cancellationToken);
        return Ok(new
        {
            message = "The lookup value was updated successfully.",
            code = "LOOKUP_VALUE_UPDATED"
        });
    }

    [HttpPost("values/{id:int}/status")]
    [HasPermission(Permissions.Lookups.Manage)]
    // HTTP POST at "values/{id:int}/status" handles the change value status operation for lookups through the
    // established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ChangeConfigurationStatusRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> ChangeValueStatus(
        int id,
        [FromBody] ChangeConfigurationStatusRequest request,
        CancellationToken cancellationToken)
    {
        var value = await _context.LookupValues.SingleOrDefaultAsync(
            item => item.LookupValueId == id,
            cancellationToken);
        if (value is null)
        {
            return NotFound(new { message = "The lookup value was not found." });
        }
        if (!ApplyRowVersion(value, request.RowVersion))
        {
            return BadRequest(new
            {
                message = "The lookup value version is invalid. Refresh and try again."
            });
        }

        var before = SafeSnapshot(value);
        value.IsActive = request.IsActive;
        value.UpdatedAtUtc = DateTime.UtcNow;
        AddHistory(
            value,
            request.IsActive ? "Activate" : "Deactivate",
            before,
            SafeSnapshot(value),
            request.Reason);
        await _context.SaveChangesAsync(cancellationToken);
        return Ok(new
        {
            message = request.IsActive
                ? "The lookup value was activated."
                : "The lookup value was deactivated. Historical records remain readable.",
            code = request.IsActive
                ? "LOOKUP_VALUE_ACTIVATED"
                : "LOOKUP_VALUE_DEACTIVATED"
        });
    }

    [HttpDelete("values/{id:int}")]
    [HasPermission(Permissions.Lookups.Manage)]
    // HTTP DELETE at "values/{id:int}" removes or retires lookups data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeleteConfigurationRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> DeleteValue(
        int id,
        [FromBody] DeleteConfigurationRequest request,
        CancellationToken cancellationToken)
    {
        var value = await _context.LookupValues
            .Include(item => item.History)
            .SingleOrDefaultAsync(
                item => item.LookupValueId == id,
                cancellationToken);
        if (value is null)
        {
            return NotFound(new { message = "The lookup value was not found." });
        }
        if (value.IsSystemValue)
        {
            return Conflict(new { message = "System lookup values cannot be deleted." });
        }
        if (value.History.Count > 1)
        {
            return Conflict(new
            {
                message = "This lookup value has change history. Deactivate it instead."
            });
        }

        _context.LookupValueHistory.RemoveRange(value.History);
        _context.LookupValues.Remove(value);
        await _context.SaveChangesAsync(cancellationToken);
        return Ok(new
        {
            message = "The unused custom lookup value was deleted.",
            code = "LOOKUP_VALUE_DELETED"
        });
    }

    [HttpGet("values/{id:int}/history")]
    [HasPermission(Permissions.Lookups.Manage)]
    // HTTP GET at "values/{id:int}/history" handles the value history operation for lookups through the
    // established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _context.Entry; failures use existing
    // HTTP handling.
    public async Task<IActionResult> ValueHistory(
        int id,
        CancellationToken cancellationToken)
    {
        var exists = await _context.LookupValues
            .AsNoTracking()
            .AnyAsync(item => item.LookupValueId == id, cancellationToken);
        if (!exists)
        {
            return NotFound(new { message = "The lookup value was not found." });
        }

        var history = await _context.LookupValueHistory
            .AsNoTracking()
            .Where(item => item.LookupValueId == id)
            .OrderByDescending(item => item.ChangedAtUtc)
            .Select(item => new
            {
                item.LookupValueHistoryId,
                item.ChangeType,
                item.BeforeValuesJson,
                item.AfterValuesJson,
                item.ChangedAtUtc,
                changedBy = item.ChangedByUser == null
                    ? "System"
                    : item.ChangedByUser.FirstName + " " + item.ChangedByUser.LastName,
                item.Reason,
                item.CorrelationId
            })
            .ToListAsync(cancellationToken);
        return Ok(history);
    }

    private Task<LookupType?> FindType(
        string typeCode,
        CancellationToken cancellationToken)
    {
        var normalized = typeCode.Trim().ToUpperInvariant();
        return _context.LookupTypes.SingleOrDefaultAsync(
            item => item.SystemCode == normalized,
            cancellationToken);
    }

    private void AddHistory(
        LookupValue value,
        string changeType,
        object? before,
        object? after,
        string reason)
    {
        value.History.Add(new LookupValueHistory
        {
            ChangeType = changeType,
            BeforeValuesJson = before is null
                ? null
                : JsonSerializer.Serialize(before),
            AfterValuesJson = after is null
                ? null
                : JsonSerializer.Serialize(after),
            ChangedByUserId = CurrentUserId(),
            ChangedAtUtc = DateTime.UtcNow,
            Reason = reason.Trim(),
            CorrelationId = _auditContext.Current.CorrelationId
        });
    }

    private static object SafeSnapshot(LookupValue value) => new
    {
        value.SystemCode,
        value.DisplayName,
        value.Description,
        value.SortOrder,
        value.IsActive
    };

    private bool ApplyRowVersion(object entity, string? encoded)
    {
        if (string.IsNullOrWhiteSpace(encoded))
        {
            return false;
        }
        try
        {
            _context.Entry(entity)
                .Property(nameof(LookupValue.RowVersion))
                .OriginalValue = Convert.FromBase64String(encoded);
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
    }

    private int CurrentUserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)
            ? userId
            : throw new UnauthorizedAccessException();

    private static string? NullIfWhiteSpace(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private static IQueryable<LookupValueResponse> ProjectValues(
        IQueryable<LookupValue> source) =>
        source.Select(item => new LookupValueResponse
        {
            LookupValueId = item.LookupValueId,
            LookupTypeId = item.LookupTypeId,
            SystemCode = item.SystemCode,
            DisplayName = item.DisplayName,
            Description = item.Description,
            SortOrder = item.SortOrder,
            IsSystemValue = item.IsSystemValue,
            IsActive = item.IsActive,
            CreatedAtUtc = item.CreatedAtUtc,
            UpdatedAtUtc = item.UpdatedAtUtc,
            RowVersion = Convert.ToBase64String(
                item.RowVersion ?? Array.Empty<byte>())
        });

    private sealed class LookupValueResponse
    {
        public int LookupValueId { get; set; }
        public int LookupTypeId { get; set; }
        public string SystemCode { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public int SortOrder { get; set; }
        public bool IsSystemValue { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAtUtc { get; set; }
        public DateTime? UpdatedAtUtc { get; set; }
        public string RowVersion { get; set; } = string.Empty;
    }
}
