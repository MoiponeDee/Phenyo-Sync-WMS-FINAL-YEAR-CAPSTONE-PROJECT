using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.DTOs.Audit;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/audit-logs")]
[HasPermission(Permissions.AuditLogs.View)]
/// <summary>Exposes protected audit search, detail and export operations.</summary>
public sealed class AuditLogsController : ControllerBase
{
    private readonly IAuditLogQueryService _query;
    private readonly IAuditService _audit;

    public AuditLogsController(
        IAuditLogQueryService query,
        IAuditService audit)
    {
        _query = query;
        _audit = audit;
    }

    [HttpGet]
    // HTTP GET at the controller root queries filtered audit logs records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts AuditLogSearchDto instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _query.SearchAsync and
    // _audit.RecordAsync; failures use existing HTTP handling.
    public async Task<IActionResult> Search(
        [FromQuery] AuditLogSearchDto filters,
        CancellationToken cancellationToken)
    {
        try
        {
            var result = await _query.SearchAsync(filters, cancellationToken);
            await _audit.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.SearchAuditLogs,
                SystemModule = AuditModules.Audit,
                OperationName = "SearchAuditLogs",
                Description = "An authorized user searched the read-only audit log.",
                EntityType = nameof(Entities.AuditLog),
                EventSource = AuditEventSources.SecurityEvent,
                SafeDetails = ActiveFilterNames(filters)
            }, cancellationToken);
            return Ok(result);
        }
        catch (AuditQueryException exception)
        {
            return StatusCode(exception.StatusCode, new { message = exception.Message });
        }
    }

    [HttpGet("metadata")]
    // HTTP GET at "metadata" returns the authoritative audit logs projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _query.GetMetadataAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Metadata(CancellationToken cancellationToken) =>
        Ok(await _query.GetMetadataAsync(cancellationToken));

    [HttpGet("{id:long}")]
    // HTTP GET at "{id:long}" returns the authoritative audit logs projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _query.GetAsync and _audit.RecordAsync;
    // failures use existing HTTP handling.
    public async Task<IActionResult> Get(
        long id,
        CancellationToken cancellationToken)
    {
        try
        {
            var result = await _query.GetAsync(id, cancellationToken);
            await _audit.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.ViewAuditLogDetails,
                SystemModule = AuditModules.Audit,
                OperationName = "ViewAuditLogDetails",
                Description = "An authorized user viewed an audit log detail record.",
                EntityType = nameof(Entities.AuditLog),
                EntityId = id.ToString(),
                Success = true,
                EventSource = AuditEventSources.SecurityEvent
            }, cancellationToken);
            return Ok(result);
        }
        catch (AuditQueryException exception)
        {
            return StatusCode(exception.StatusCode, new { message = exception.Message });
        }
    }

    private static IReadOnlyDictionary<string, object?> ActiveFilterNames(
        AuditLogSearchDto filters)
    {
        var names = new List<string>();
        if (filters.UserId.HasValue) names.Add(nameof(filters.UserId));
        if (!string.IsNullOrWhiteSpace(filters.UserSearch)) names.Add(nameof(filters.UserSearch));
        if (filters.DateFromUtc.HasValue) names.Add(nameof(filters.DateFromUtc));
        if (filters.DateToUtc.HasValue) names.Add(nameof(filters.DateToUtc));
        if (!string.IsNullOrWhiteSpace(filters.ActionType)) names.Add(nameof(filters.ActionType));
        if (!string.IsNullOrWhiteSpace(filters.SystemModule)) names.Add(nameof(filters.SystemModule));
        if (!string.IsNullOrWhiteSpace(filters.OperationName)) names.Add(nameof(filters.OperationName));
        if (!string.IsNullOrWhiteSpace(filters.EntityType)) names.Add(nameof(filters.EntityType));
        if (!string.IsNullOrWhiteSpace(filters.EntityId)) names.Add(nameof(filters.EntityId));
        if (filters.Success.HasValue) names.Add(nameof(filters.Success));
        if (!string.IsNullOrWhiteSpace(filters.CorrelationId)) names.Add(nameof(filters.CorrelationId));
        if (!string.IsNullOrWhiteSpace(filters.SearchTerm)) names.Add(nameof(filters.SearchTerm));
        return new Dictionary<string, object?>
        {
            ["AppliedFilterNames"] = names,
            ["PageNumber"] = filters.PageNumber,
            ["PageSize"] = filters.PageSize
        };
    }
}
