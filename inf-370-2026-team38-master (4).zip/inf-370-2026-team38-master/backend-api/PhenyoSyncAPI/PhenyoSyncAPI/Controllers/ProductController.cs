using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Product;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using PhenyoSyncAPI.Configuration;
using PhenyoSyncAPI.Auditing;
using QRCoder;

namespace PhenyoSyncAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [HasPermission(Permissions.Products.View)]
    /// <summary>Exposes the Product master while delegating workflow and persistence rules to services.</summary>
    public class ProductController : ControllerBase
    {
        private readonly PhenyoSyncDbContext _context;
        private readonly IProductionService _productionService;
        private readonly ExpiryAlertOptions _expiryOptions;
        private readonly ISystemSettingProvider? _settings;
        private readonly IAuditService? _audit;

        public ProductController(
            PhenyoSyncDbContext context,
            IProductionService productionService,
            IOptions<ExpiryAlertOptions> expiryOptions,
            ISystemSettingProvider? settings = null,
            IAuditService? audit = null)
        {
            _context = context;
            _productionService = productionService;
            _expiryOptions = expiryOptions.Value;
            _settings = settings;
            _audit = audit;
        }

        [HttpPost]
        [HasPermission(Permissions.Products.Make)]
        // HTTP POST at the controller root creates or attaches product data through the controlled API boundary.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts CreateProductDto instead of an EF entity, limiting fields and preventing over-posting.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to _productionService.MakeProductAsync;
        // failures use existing HTTP handling.
        public async Task<IActionResult> CreateProduct(
            [FromBody] CreateProductDto dto,
            CancellationToken cancellationToken)
        {
            try
            {
                var result = await _productionService.MakeProductAsync(
                    dto,
                    GetCurrentUserId(),
                    cancellationToken);
                return Ok(result);
            }
            catch (Subsystem7Exception exception)
            {
                return StatusCode(exception.StatusCode, new { message = exception.Message });
            }
        }

        [HttpGet("packable")]
        [HasPermission(Permissions.Products.Make)]
        // HTTP GET at "packable" handles the get packable products operation for product through the established
        // workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // The thin controller delegates business rules and persistence to
        // _productionService.PackableProductsAsync; failures use existing HTTP handling.
        public async Task<IActionResult> GetPackableProducts(
            [FromQuery] int sectionId,
            CancellationToken cancellationToken)
        {
            try
            {
                return Ok(await _productionService.PackableProductsAsync(
                    sectionId,
                    cancellationToken));
            }
            catch (Subsystem7Exception exception)
            {
                return StatusCode(
                    exception.StatusCode,
                    new { message = exception.Message });
            }
        }

        [HttpGet]
        // HTTP GET at the controller root handles the get products operation for product through the established
        // workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // QueryProducts owns the shared no-tracking DTO projection and threshold calculation so EF entities do
        // not escape the API boundary.
        public async Task<List<ProductResponseDto>> GetProducts(
            CancellationToken cancellationToken)
        {
            var thresholds = await Thresholds(cancellationToken);
            return await QueryProducts(thresholds.Red, thresholds.Yellow)
                .OrderBy(product => product.ProductName)
                .ToListAsync(cancellationToken);
        }

        [HttpGet("{id:int}")]
        // HTTP GET at "{id:int}" handles the get product operation for product through the established workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // QueryProducts reuses the authoritative DTO projection; the action maps an unknown product to 404.
        public async Task<IActionResult> GetProduct(int id, CancellationToken cancellationToken)
        {
            var thresholds = await Thresholds(cancellationToken);
            var product = await QueryProducts(thresholds.Red, thresholds.Yellow)
                .FirstOrDefaultAsync(item => item.ProductId == id, cancellationToken);
            return product is null
                ? NotFound(new { message = "Product not found." })
                : Ok(product);
        }

        [HttpGet("search")]
        // HTTP GET at "search" handles the search products operation for product through the established
        // workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // EF queries are projected to response data rather than exposing tracked entities.
        public async Task<IActionResult> SearchProducts(
            [FromQuery] string? searchTerm,
            [FromQuery] int? productTypeId,
            [FromQuery] int? productCategoryId,
            [FromQuery] string? status,
            CancellationToken cancellationToken)
        {
            if (productTypeId is < 1 || productCategoryId is < 1)
            {
                return BadRequest(new { message = "Lookup IDs must be greater than zero." });
            }

            if (!string.IsNullOrWhiteSpace(status) &&
                status is not ProductStatuses.Active and not ProductStatuses.Inactive)
            {
                return BadRequest(new { message = "Status must be Active or Inactive." });
            }

            var query = _context.Products.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                var term = searchTerm.Trim();
                query = query.Where(product =>
                    product.ProductName.Contains(term) ||
                    product.Size.Contains(term) ||
                    (product.QRCodeValue != null && product.QRCodeValue.Contains(term)) ||
                    product.ProductType!.ProductTypeName.Contains(term) ||
                    product.ProductCategory!.ProductCategoryName.Contains(term) ||
                    product.ProductBatches.Any(batch =>
                        batch.BatchCode.Contains(term) || batch.QRCodeValue.Contains(term)));
            }

            if (productTypeId.HasValue)
                query = query.Where(product => product.ProductTypeId == productTypeId.Value);
            if (productCategoryId.HasValue)
                query = query.Where(product => product.ProductCategoryId == productCategoryId.Value);
            if (!string.IsNullOrWhiteSpace(status))
                query = query.Where(product => product.Status == status);

            var thresholds = await Thresholds(cancellationToken);
            var products = await ProjectProducts(
                    query,
                    thresholds.Red,
                    thresholds.Yellow)
                .OrderBy(product => product.ProductName)
                .ThenBy(product => product.Size)
                .ToListAsync(cancellationToken);
            return Ok(products);
        }

        [HttpPut("{id:int}")]
        [HasPermission(Permissions.Products.Update)]
        // HTTP PUT at "{id:int}" handles the update product operation for product through the established
        // workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts UpdateProductDto instead of an EF entity, limiting fields and preventing over-posting.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> UpdateProduct(
            int id,
            [FromBody] UpdateProductDto dto,
            CancellationToken cancellationToken)
        {
            var product = await _context.Products.FirstOrDefaultAsync(
                item => item.ProductId == id,
                cancellationToken);
            if (product is null) return NotFound(new { message = "Product not found." });

            var typeExists = await _context.ProductTypes.AnyAsync(
                item => item.ProductTypeId == dto.ProductTypeId,
                cancellationToken);
            var categoryExists = await _context.ProductCategories.AnyAsync(
                item => item.ProductCategoryId == dto.ProductCategoryId,
                cancellationToken);
            if (!typeExists || !categoryExists)
                return BadRequest(new { message = "The selected product type or category does not exist." });

            if (!await _context.ProductCategoryTypes.AnyAsync(item =>
                    item.ProductCategoryId == dto.ProductCategoryId &&
                    item.ProductTypeId == dto.ProductTypeId,
                    cancellationToken))
            {
                _context.ProductCategoryTypes.Add(new ProductCategoryType
                {
                    ProductCategoryId = dto.ProductCategoryId,
                    ProductTypeId = dto.ProductTypeId,
                    CreatedAtUtc = DateTime.UtcNow,
                    CreatedByUserId = GetCurrentUserId()
                });
            }

            var name = dto.ProductName.Trim();
            var size = dto.Size.Trim();
            var normalizedName = name.ToUpper();
            var normalizedSize = size.ToUpper();
            var duplicate = await _context.Products.AnyAsync(item =>
                item.ProductId != id &&
                item.ProductTypeId == dto.ProductTypeId &&
                item.ProductCategoryId == dto.ProductCategoryId &&
                item.ProductName.ToUpper() == normalizedName &&
                item.Size.ToUpper() == normalizedSize,
                cancellationToken);
            if (duplicate)
            {
                return Conflict(new
                {
                    message = "Another product with the same name, type, category and size already exists."
                });
            }

            product.ProductName = name;
            product.ProductTypeId = dto.ProductTypeId;
            product.ProductCategoryId = dto.ProductCategoryId;
            product.Size = size;
            product.ShelfLifeDays = dto.ShelfLifeDays;
            product.Status = dto.Status;
            product.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync(cancellationToken);

            return Ok(new
            {
                message = "Product updated successfully.",
                productId = product.ProductId,
                qrCode = product.QRCodeValue
            });
        }

        [HttpPatch("{id:int}/status")]
        [HasPermission(Permissions.Products.ChangeStatus)]
        // HTTP PATCH at "{id:int}/status" changes product state only through the supported status operation.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts UpdateProductStatusDto instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> ChangeStatus(
            int id,
            [FromBody] UpdateProductStatusDto dto,
            CancellationToken cancellationToken)
        {
            var product = await _context.Products.FindAsync([id], cancellationToken);
            if (product is null) return NotFound(new { message = "Product not found." });

            product.Status = dto.Status;
            product.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync(cancellationToken);
            return Ok(new { message = "Product status updated successfully." });
        }

        [HttpDelete("{id:int}")]
        [HasPermission(Permissions.Products.Delete)]
        // HTTP DELETE at "{id:int}" removes or retires product data after dependency checks.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
        // _audit.RecordAsync; failures use existing HTTP handling.
        public async Task<IActionResult> DeleteProduct(int id, CancellationToken cancellationToken)
        {
            var product = await _context.Products.FirstOrDefaultAsync(
                item => item.ProductId == id,
                cancellationToken);
            if (product is null) return NotFound(new { message = "Product not found." });

            var hasDependencies = await _context.ProductBatches.AnyAsync(
                    item => item.ProductId == id, cancellationToken) ||
                await _context.Stocks.AnyAsync(item => item.ProductId == id, cancellationToken) ||
                await _context.StockMovements.AnyAsync(item => item.ProductId == id, cancellationToken) ||
                await _context.SalesOrderItems.AnyAsync(item => item.ProductId == id, cancellationToken) ||
                await _context.OrderStockReservations.AnyAsync(item => item.ProductId == id, cancellationToken) ||
                await _context.BuyerProcurementItems.AnyAsync(item => item.ProductId == id, cancellationToken) ||
                await _context.StockReceiptItems.AnyAsync(item => item.ProductId == id, cancellationToken) ||
                await _context.PackingConversions.AnyAsync(item => item.ProductId == id, cancellationToken);

            if (hasDependencies)
            {
                return Conflict(new
                {
                    code = "DELETE_NOT_ALLOWED",
                    message = "This product has inventory history and cannot be permanently deleted. Deactivate it instead.",
                    canDelete = false,
                    deleteBlockedReason = "Inventory, procurement, reservation, receiving, packing, or order history must be retained.",
                    isCommitted = true,
                    canDeactivate = product.Status != ProductStatuses.Inactive
                });
            }

            try
            {
                await using var transaction = await _context.Database.BeginTransactionAsync(
                    cancellationToken);
                var requirements = await _context.ProductRawStockRequirements
                    .Where(item => item.ProductId == id)
                    .ToListAsync(cancellationToken);
                var mappings = await _context.ProductReconciliationMappings
                    .Where(item => item.ProductId == id)
                    .ToListAsync(cancellationToken);
                var prices = await _context.ProductPrices
                    .Where(item => item.ProductId == id)
                    .ToListAsync(cancellationToken);
                _context.ProductRawStockRequirements.RemoveRange(requirements);
                _context.ProductReconciliationMappings.RemoveRange(mappings);
                _context.ProductPrices.RemoveRange(prices);
                _context.Products.Remove(product);
                await _context.SaveChangesAsync(cancellationToken);
                if (_audit is not null)
                {
                    await _audit.RecordAsync(new AuditEvent
                    {
                        ActionType = AuditActionTypes.Delete,
                        SystemModule = AuditModules.ProductHierarchy,
                        OperationName = "Delete unused product",
                        Description = $"Unused product {product.ProductName} was permanently deleted.",
                        EntityType = nameof(Product),
                        EntityId = id.ToString(),
                        EntityDisplay = product.ProductName,
                        UserId = GetCurrentUserId(),
                        SafeDetails = new Dictionary<string, object?>
                        {
                            ["removedPriceRows"] = prices.Count,
                            ["removedRecipeRows"] = requirements.Count,
                            ["removedReconciliationMappings"] = mappings.Count
                        }
                    }, cancellationToken);
                }
                await transaction.CommitAsync(cancellationToken);
                return Ok(new { message = "Product permanently deleted successfully.", productId = id });
            }
            catch (DbUpdateException)
            {
                return Conflict(new
                {
                    code = "DELETE_NOT_ALLOWED",
                    message = "This product is linked to other records and cannot be permanently deleted. Deactivate it instead.",
                    canDelete = false,
                    deleteBlockedReason = "Related business records must be retained.",
                    isCommitted = true,
                    canDeactivate = product.Status != ProductStatuses.Inactive
                });
            }
        }

        [HttpGet("{id:int}/qr-code")]
        [HasPermission(Permissions.Labels.Print)]
        // HTTP GET at "{id:int}/qr-code" resolves or renders the requested product QR representation.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to _settings.GetIntAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> GetProductQrCode(int id, CancellationToken cancellationToken)
        {
            var product = await _context.Products.AsNoTracking()
                .Where(product => product.ProductId == id)
                .Select(product => new { product.ProductId, product.QRCodeValue })
                .FirstOrDefaultAsync(cancellationToken);
            if (product is null)
            {
                return NotFound(new { message = "Product not found." });
            }

            var value = product.QRCodeValue ?? $"PRODUCT-{product.ProductId:D6}";
            return File(CreateQrPng(value), "image/png");
        }

        private IQueryable<ProductResponseDto> QueryProducts(
            int redThreshold,
            int yellowThreshold)
        {
            return ProjectProducts(
                _context.Products.AsNoTracking(),
                redThreshold,
                yellowThreshold);
        }

        private IQueryable<ProductResponseDto> ProjectProducts(
            IQueryable<Product> query,
            int redThreshold,
            int yellowThreshold)
        {
            var now = DateTime.UtcNow;
            return query.Select(product => new ProductResponseDto
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                ProductTypeId = product.ProductTypeId,
                ProductTypeName = product.ProductType!.ProductTypeName,
                ProductCategoryId = product.ProductCategoryId,
                ProductCategoryName = product.ProductCategory!.ProductCategoryName,
                Size = product.Size,
                ShelfLifeDays = product.ShelfLifeDays,
                SellingPricePerKg = product.SellingPricePerKg,
                CurrentPriceBasis = product.ProductPrices
                    .Where(price => price.IsCurrent)
                    .OrderByDescending(price => price.EffectiveFromUtc)
                    .Select(price => price.PriceBasis)
                    .FirstOrDefault() ?? ProductPriceBases.PerKilogram,
                SellingUnit = product.SellingUnit,
                KilogramsPerUnit = product.KilogramsPerUnit,
                IsVariableWeight = product.IsVariableWeight,
                QRCodeValue = product.QRCodeValue,
                Status = product.Status,
                CreatedAt = product.CreatedAt,
                UpdatedAt = product.UpdatedAt,
                TotalAvailableQuantityKg = product.ProductBatches
                    .Where(batch =>
                        batch.Status == ProductBatchStatuses.Available &&
                        batch.QuantityRemainingKg > 0 &&
                        batch.EffectiveExpiryAtUtc > now)
                    .Sum(batch => (decimal?)batch.QuantityRemainingKg) ?? 0,
                NearestExpiryAtUtc = product.ProductBatches
                    .Where(batch =>
                        batch.Status == ProductBatchStatuses.Available &&
                        batch.QuantityRemainingKg > 0 &&
                        batch.EffectiveExpiryAtUtc > now)
                    .Min(batch => (DateTime?)batch.EffectiveExpiryAtUtc),
                AlertLevel = product.ProductBatches.Any(batch =>
                        batch.QuantityRemainingKg > 0 &&
                        batch.EffectiveExpiryAtUtc > now &&
                        batch.EffectiveExpiryAtUtc <= now.AddHours(redThreshold))
                    ? ExpiryAlertLevels.Urgent
                    : product.ProductBatches.Any(batch =>
                        batch.QuantityRemainingKg > 0 &&
                        batch.EffectiveExpiryAtUtc > now &&
                        batch.EffectiveExpiryAtUtc <= now.AddHours(yellowThreshold))
                        ? ExpiryAlertLevels.Warning
                        : ExpiryAlertLevels.Normal,
                CanDelete = !product.ProductBatches.Any() &&
                            !product.Stocks.Any() &&
                            !product.StockMovements.Any() &&
                            !product.SalesOrderItems.Any() &&
                            !product.OrderStockReservations.Any() &&
                            !_context.BuyerProcurementItems.Any(item => item.ProductId == product.ProductId) &&
                            !_context.StockReceiptItems.Any(item => item.ProductId == product.ProductId) &&
                            !_context.PackingConversions.Any(item => item.ProductId == product.ProductId),
                IsCommitted = product.ProductBatches.Any() ||
                              product.Stocks.Any() ||
                              product.StockMovements.Any() ||
                              product.SalesOrderItems.Any() ||
                              product.OrderStockReservations.Any() ||
                              _context.BuyerProcurementItems.Any(item => item.ProductId == product.ProductId) ||
                              _context.StockReceiptItems.Any(item => item.ProductId == product.ProductId) ||
                              _context.PackingConversions.Any(item => item.ProductId == product.ProductId),
                DeleteBlockedReason = product.ProductBatches.Any() ||
                                      product.Stocks.Any() ||
                                      product.StockMovements.Any() ||
                                      product.SalesOrderItems.Any() ||
                                      product.OrderStockReservations.Any() ||
                                      _context.BuyerProcurementItems.Any(item => item.ProductId == product.ProductId) ||
                                      _context.StockReceiptItems.Any(item => item.ProductId == product.ProductId) ||
                                      _context.PackingConversions.Any(item => item.ProductId == product.ProductId)
                    ? "Inventory, procurement, reservation, receiving, packing, or order history must be retained."
                    : null,
                CanDeactivate = product.Status != ProductStatuses.Inactive
            });
        }

        private int? GetCurrentUserId()
        {
            return int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)
                ? userId
                : null;
        }

        private async Task<(int Red, int Yellow)> Thresholds(
            CancellationToken cancellationToken)
        {
            if (_settings is null)
            {
                return (
                    _expiryOptions.RedThresholdHours,
                    _expiryOptions.YellowThresholdHours);
            }
            return (
                await _settings.GetIntAsync(
                    SystemSettingKeys.ExpiryRedThresholdHours,
                    cancellationToken),
                await _settings.GetIntAsync(
                    SystemSettingKeys.ExpiryYellowThresholdHours,
                    cancellationToken));
        }

        private static byte[] CreateQrPng(string value)
        {
            using var generator = new QRCodeGenerator();
            using var data = generator.CreateQrCode(value, QRCodeGenerator.ECCLevel.Q);
            using var code = new PngByteQRCode(data);
            return code.GetGraphic(20);
        }
    }
}
