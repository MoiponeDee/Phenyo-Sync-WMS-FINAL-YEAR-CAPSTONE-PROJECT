using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.BuyingLists;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Authorize]
[Route("api/buying-lists")]
[HasPermission(Permissions.BuyingLists.View)]
/// <summary>Maps management Buying List commands to the governed lifecycle service.</summary>
public sealed class BuyingListsController : OperationalControllerBase
{
    private readonly IBuyingListManagementService _service;

    public BuyingListsController(IBuyingListManagementService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root queries filtered buying lists records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts BuyingListSearchRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.SearchAsync; failures use
    // existing HTTP handling.
    public Task<BuyingListSearchResultDto> Search(
        [FromQuery] BuyingListSearchRequest request,
        CancellationToken cancellationToken) =>
        _service.SearchAsync(request, cancellationToken);

    [HttpGet("options")]
    // HTTP GET at "options" returns the authoritative buying lists projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.OptionsAsync; failures use
    // existing HTTP handling.
    public Task<BuyingListOptionsDto> Options(
        CancellationToken cancellationToken) =>
        _service.OptionsAsync(cancellationToken);

    [HttpGet("{id:int}")]
    // HTTP GET at "{id:int}" returns the authoritative buying lists projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.GetAsync; failures use
    // existing HTTP handling.
    public Task<BuyingListDetailDto> Get(
        int id,
        CancellationToken cancellationToken) =>
        _service.GetAsync(id, cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.BuyingLists.Create)]
    // HTTP POST at the controller root creates or attaches buying lists data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateBuyingListManagementRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.CreateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<ActionResult<BuyingListDetailDto>> Create(
        CreateBuyingListManagementRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            StatusCodes.Status201Created,
            await _service.CreateAsync(
                request,
                UserId(),
                HttpContext.TraceIdentifier,
                cancellationToken));

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.BuyingLists.UpdateDraft)]
    // HTTP PUT at "{id:int}" updates only allowed buying lists fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts UpdateBuyingListHeaderRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.UpdateHeaderAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<BuyingListDetailDto> UpdateHeader(
        int id,
        UpdateBuyingListHeaderRequest request,
        CancellationToken cancellationToken) =>
        _service.UpdateHeaderAsync(
            id,
            request,
            UserId(),
            cancellationToken);

    [HttpPost("{id:int}/items")]
    [HasPermission(Permissions.BuyingLists.UpdateDraft)]
    // HTTP POST at "{id:int}/items" creates or attaches buying lists data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveBuyingListLineRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.AddLineAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<BuyingListDetailDto> AddLine(
        int id,
        SaveBuyingListLineRequest request,
        CancellationToken cancellationToken) =>
        _service.AddLineAsync(
            id,
            request,
            UserId(),
            cancellationToken);

    [HttpPut("{id:int}/items/{lineId:int}")]
    [HasPermission(Permissions.BuyingLists.UpdateDraft)]
    // HTTP PUT at "{id:int}/items/{lineId:int}" updates only allowed buying lists fields through a narrow
    // request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveBuyingListLineRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.UpdateLineAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<BuyingListDetailDto> UpdateLine(
        int id,
        int lineId,
        SaveBuyingListLineRequest request,
        CancellationToken cancellationToken) =>
        _service.UpdateLineAsync(
            id,
            lineId,
            request,
            UserId(),
            cancellationToken);

    [HttpDelete("{id:int}/items/{lineId:int}")]
    [HasPermission(Permissions.BuyingLists.DeleteDraft)]
    // HTTP DELETE at "{id:int}/items/{lineId:int}" removes or retires buying lists data after dependency
    // checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts BuyingListCommandRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.RemoveLineAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<BuyingListDetailDto> RemoveLine(
        int id,
        int lineId,
        [FromBody] BuyingListCommandRequest request,
        CancellationToken cancellationToken) =>
        _service.RemoveLineAsync(
            id,
            lineId,
            request,
            UserId(),
            cancellationToken);

    [HttpPost("{id:int}/assign")]
    [HasPermission(Permissions.BuyingLists.Assign)]
    // HTTP POST at "{id:int}/assign" changes the controlled buying lists assignment after eligibility checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts AssignBuyingListRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.AssignAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<BuyingListDetailDto> Assign(
        int id,
        AssignBuyingListRequest request,
        CancellationToken cancellationToken) =>
        _service.AssignAsync(
            id,
            request,
            UserId(),
            HttpContext.TraceIdentifier,
            cancellationToken);

    [HttpPost("{id:int}/publish")]
    [HasPermission(Permissions.BuyingLists.Publish)]
    // HTTP POST at "{id:int}/publish" continues the buying lists workflow through its named transition.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts BuyingListCommandRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.PublishAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<BuyingListDetailDto> Publish(
        int id,
        BuyingListCommandRequest request,
        CancellationToken cancellationToken) =>
        _service.PublishAsync(
            id,
            request,
            UserId(),
            HttpContext.TraceIdentifier,
            cancellationToken);

    [HttpPost("{id:int}/cancel")]
    [HasPermission(Permissions.BuyingLists.Cancel)]
    // HTTP POST at "{id:int}/cancel" continues the buying lists workflow through its named transition.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts BuyingListCommandRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.CancelAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<BuyingListDetailDto> Cancel(
        int id,
        BuyingListCommandRequest request,
        CancellationToken cancellationToken) =>
        _service.CancelAsync(
            id,
            request,
            UserId(),
            HttpContext.TraceIdentifier,
            cancellationToken);
}
