using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.PhaseB;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/product-hierarchy")]
[HasPermission(Permissions.ProductHierarchy.View)]
/// <summary>Exposes Category-to-Type-to-Product hierarchy queries and governed edits.</summary>
public sealed class ProductHierarchyController : ControllerBase
{
    private readonly IProductHierarchyService _hierarchy;

    public ProductHierarchyController(IProductHierarchyService hierarchy)
    {
        _hierarchy = hierarchy;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative product hierarchy projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _hierarchy.GetAsync; failures use
    // existing HTTP handling.
    public Task<ProductHierarchyResponseDto> Get(
        [FromQuery] string? search,
        [FromQuery] bool includeInactive,
        [FromQuery] int? categoryId,
        [FromQuery] int? typeId,
        CancellationToken cancellationToken) =>
        _hierarchy.GetAsync(
            search,
            includeInactive,
            categoryId,
            typeId,
            cancellationToken);

    [HttpPost("categories")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP POST at "categories" creates or attaches product hierarchy data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHierarchyCategoryRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _hierarchy.CreateCategoryAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> CreateCategory(
        SaveHierarchyCategoryRequest request,
        CancellationToken cancellationToken)
    {
        var id = await _hierarchy.CreateCategoryAsync(
            request,
            UserId(),
            cancellationToken);
        return StatusCode(201, new
        {
            message = "Product category created in the hierarchy.",
            productCategoryId = id
        });
    }

    [HttpPut("categories/{categoryId:int}")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP PUT at "categories/{categoryId:int}" updates only allowed product hierarchy fields through a
    // narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHierarchyCategoryRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _hierarchy.UpdateCategoryAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> UpdateCategory(
        int categoryId,
        SaveHierarchyCategoryRequest request,
        CancellationToken cancellationToken)
    {
        await _hierarchy.UpdateCategoryAsync(categoryId, request, UserId(), cancellationToken);
        return Ok(new { message = "Product category updated." });
    }

    [HttpPost("categories/{categoryId:int}/delete")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP POST at "categories/{categoryId:int}/delete" removes or retires product hierarchy data after
    // dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeleteHierarchyNodeRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _hierarchy.DeleteCategoryAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> DeleteCategory(
        int categoryId,
        DeleteHierarchyNodeRequest request,
        CancellationToken cancellationToken)
    {
        await _hierarchy.DeleteCategoryAsync(categoryId, request, UserId(), cancellationToken);
        return Ok(new { message = "Unused product category deleted." });
    }

    [HttpPost("categories/{categoryId:int}/types")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP POST at "categories/{categoryId:int}/types" creates or attaches product hierarchy data through the
    // controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHierarchyTypeRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _hierarchy.CreateTypeAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> CreateType(
        int categoryId,
        SaveHierarchyTypeRequest request,
        CancellationToken cancellationToken)
    {
        var id = await _hierarchy.CreateTypeAsync(
            categoryId,
            request,
            UserId(),
            cancellationToken);
        return StatusCode(201, new
        {
            message = "Product type created under the selected category.",
            productTypeId = id
        });
    }

    [HttpPut("types/{typeId:int}")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP PUT at "types/{typeId:int}" updates only allowed product hierarchy fields through a narrow
    // request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveHierarchyTypeRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _hierarchy.UpdateTypeAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> UpdateType(
        int typeId,
        SaveHierarchyTypeRequest request,
        CancellationToken cancellationToken)
    {
        await _hierarchy.UpdateTypeAsync(typeId, request, UserId(), cancellationToken);
        return Ok(new { message = "Product type updated." });
    }

    [HttpPost("associations/{productCategoryTypeId:int}/move")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP POST at "associations/{productCategoryTypeId:int}/move" updates only allowed product hierarchy
    // fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts MoveHierarchyTypeRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _hierarchy.MoveTypeAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> MoveType(
        int productCategoryTypeId,
        MoveHierarchyTypeRequest request,
        CancellationToken cancellationToken)
    {
        await _hierarchy.MoveTypeAsync(
            productCategoryTypeId,
            request,
            UserId(),
            cancellationToken);
        return Ok(new { message = "Product type moved to the selected category." });
    }

    [HttpPost("types/{typeId:int}/delete")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP POST at "types/{typeId:int}/delete" removes or retires product hierarchy data after dependency
    // checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeleteHierarchyNodeRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _hierarchy.DeleteTypeAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> DeleteType(
        int typeId,
        DeleteHierarchyNodeRequest request,
        CancellationToken cancellationToken)
    {
        await _hierarchy.DeleteTypeAsync(typeId, request, UserId(), cancellationToken);
        return Ok(new { message = "Unused product type deleted." });
    }

    [HttpPost("categories/{categoryId:int}/types/{typeId:int}/products")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP POST at "categories/{categoryId:int}/types/{typeId:int}/products" creates or attaches product
    // hierarchy data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateHierarchyProductRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _hierarchy.CreateProductAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> CreateProduct(
        int categoryId,
        int typeId,
        CreateHierarchyProductRequest request,
        CancellationToken cancellationToken)
    {
        var id = await _hierarchy.CreateProductAsync(
            categoryId,
            typeId,
            request,
            UserId(),
            cancellationToken);
        return StatusCode(201, new
        {
            message = "Product created under the selected type.",
            productId = id
        });
    }

    [HttpPut("products/{productId:int}/classification")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP PUT at "products/{productId:int}/classification" updates only allowed product hierarchy fields
    // through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReclassifyHierarchyProductRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _hierarchy.ReclassifyProductAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> ReclassifyProduct(
        int productId,
        ReclassifyHierarchyProductRequest request,
        CancellationToken cancellationToken)
    {
        await _hierarchy.ReclassifyProductAsync(
            productId,
            request,
            UserId(),
            cancellationToken);
        return Ok(new { message = "Product classification updated." });
    }

    [HttpPut("products/{productId:int}/status")]
    [HasPermission(Permissions.ProductHierarchy.Manage)]
    // HTTP PUT at "products/{productId:int}/status" changes product hierarchy state only through the
    // supported status operation.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ChangeHierarchyStatusRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // The thin controller delegates business rules and persistence to _hierarchy.ChangeProductStatusAsync;
    // failures use existing HTTP handling.
    public async Task<IActionResult> ChangeProductStatus(
        int productId,
        ChangeHierarchyStatusRequest request,
        CancellationToken cancellationToken)
    {
        await _hierarchy.ChangeProductStatusAsync(
            productId,
            request,
            UserId(),
            cancellationToken);
        return Ok(new { message = "Product status updated." });
    }

    private int UserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)
            ? userId
            : throw new UnauthorizedAccessException();
}
