using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Expiry;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using PhenyoSyncAPI.Auditing;

namespace PhenyoSyncAPI.Controllers
{
    [ApiController]
    [Route("api/expiry-alerts")]
    [HasPermission(Permissions.Expiry.View)]
    /// <summary>Exposes expiry queues and controlled batch-resolution commands.</summary>
    public class ExpiryAlertsController : ControllerBase
    {
        private readonly IExpiryService _expiryService;
        private readonly IAuditService _auditService;

        public ExpiryAlertsController(
            IExpiryService expiryService,
            IAuditService auditService)
        {
            _expiryService = expiryService;
            _auditService = auditService;
        }

        [HttpGet]
        // HTTP GET at the controller root handles the get alerts operation for expiry alerts through the
        // established workflow.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // The thin controller delegates business rules and persistence to _expiryService.GetAlertsAsync; failures
        // use existing HTTP handling.
        public Task<ExpiryAlertSummaryDto> GetAlerts(
            [FromQuery] string? level,
            [FromQuery] int? productId,
            [FromQuery] int? categoryId,
            [FromQuery] int? sectionId,
            CancellationToken cancellationToken) =>
            _expiryService.GetAlertsAsync(level, productId, categoryId, sectionId, cancellationToken);

        [HttpPost("run-scan")]
        [HasPermission(Permissions.Expiry.Resolve)]
        // HTTP POST at "run-scan" runs the expiry scan and records who initiated the operation.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // The thin controller delegates business rules and persistence to _expiryService.RunScanAsync and
        // _auditService.RecordAsync; failures use existing HTTP handling.
        public async Task<IActionResult> RunScan(CancellationToken cancellationToken)
        {
            var result = await _expiryService.RunScanAsync(cancellationToken);
            await _auditService.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.BackgroundJob,
                SystemModule = AuditModules.ExpiryManagement,
                OperationName = "ManualExpiryScan",
                Description = "An authorized user ran the expiry scan manually.",
                Success = true,
                EventSource = AuditEventSources.BusinessEvent,
                SafeDetails = new Dictionary<string, object?>
                {
                    ["BatchesScanned"] = result.BatchesScanned,
                    ["MarkedExpired"] = result.MarkedExpired,
                    ["WarningEmailsSent"] = result.WarningEmailsSent,
                    ["UrgentEmailsSent"] = result.UrgentEmailsSent
                }
            }, cancellationToken);
            return Ok(new
            {
                message = "Expiry scan completed.",
                result.BatchesScanned,
                result.MarkedExpired,
                result.WarningEmailsSent,
                result.UrgentEmailsSent
            });
        }

        [HttpGet("action")]
        [HasPermission(Permissions.Expiry.Resolve)]
        // HTTP GET at "action" validates a one-time token before exposing expiry decision details.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // The thin controller delegates business rules and persistence to _expiryService.GetActionReviewAsync;
        // failures use existing HTTP handling.
        public async Task<IActionResult> GetActionReview(
            [FromQuery] string token,
            CancellationToken cancellationToken)
        {
            try
            {
                return Ok(await _expiryService.GetActionReviewAsync(token, cancellationToken));
            }
            catch (Subsystem7Exception exception)
            {
                return StatusCode(exception.StatusCode, new { message = exception.Message });
            }
        }

        [HttpPost("action/write-off")]
        [HasPermission(Permissions.Expiry.Resolve)]
        // HTTP POST at "action/write-off" applies the token-authorized expiry write-off decision.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts ExpiryDecisionDto instead of an EF entity, limiting fields and preventing over-posting.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // PerformDecision enforces explicit confirmation and delegates the token-backed write-off to the
        // expiry service, keeping the transactional rule outside the HTTP layer.
        public Task<IActionResult> WriteOff(
            [FromQuery] string token,
            [FromBody] ExpiryDecisionDto dto,
            CancellationToken cancellationToken) =>
            PerformDecision(token, dto, true, cancellationToken);

        [HttpPost("action/extend")]
        [HasPermission(Permissions.Expiry.Resolve)]
        // HTTP POST at "action/extend" extends shelf life only after token and business-rule validation.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts ExpiryDecisionDto instead of an EF entity, limiting fields and preventing over-posting.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // PerformDecision enforces explicit confirmation and delegates the token-backed shelf-life change to
        // the expiry service, keeping the transactional rule outside the HTTP layer.
        public Task<IActionResult> Extend(
            [FromQuery] string token,
            [FromBody] ExpiryDecisionDto dto,
            CancellationToken cancellationToken) =>
            PerformDecision(token, dto, false, cancellationToken);

        private async Task<IActionResult> PerformDecision(
            string token,
            ExpiryDecisionDto dto,
            bool writeOff,
            CancellationToken cancellationToken)
        {
            if (!dto.Confirmed)
                return BadRequest(new { message = "Explicit confirmation is required." });
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
                return Unauthorized(new { message = "The authenticated user could not be identified." });

            try
            {
                var message = writeOff
                    ? await _expiryService.WriteOffAsync(token, dto.Reason, userId, cancellationToken)
                    : await _expiryService.ExtendShelfLifeAsync(
                        token,
                        dto.Reason,
                        dto.NewExpiryAtUtc ?? throw new Subsystem7Exception(
                            400,
                            "Select a new expiry date and time."),
                        userId,
                        cancellationToken);
                return Ok(new { message });
            }
            catch (Subsystem7Exception exception)
            {
                return StatusCode(exception.StatusCode, new { message = exception.Message });
            }
        }
    }
}
