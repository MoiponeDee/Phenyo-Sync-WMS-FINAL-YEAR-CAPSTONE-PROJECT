using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Services;

// Retains obsolete public routes only to return a stable 410 response; no order data is exposed.
namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/public")]
[AllowAnonymous]
[EnableRateLimiting("public-orders")]
[ApiExplorerSettings(IgnoreApi = true)]
public sealed class PublicOrdersController : ControllerBase
{
    private readonly IOrderLinkService _service;
    public PublicOrdersController(IOrderLinkService service) => _service = service;

    [HttpGet("order-links/validate")]
    // HTTP GET at "order-links/validate" returns the retired response for the obsolete public order-link
    // endpoint.
    // This retired compatibility route remains anonymous but always returns 410 without exposing data.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The action maps directly to the shared Retired response; no business workflow or persistence is invoked.
    public IActionResult Validate() => Retired();

    [HttpPost("orders")]
    // HTTP POST at "orders" returns the retired response so obsolete intake cannot create orders.
    // This retired compatibility route remains anonymous but always returns 410 without mutating data.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The action maps directly to the shared Retired response; no business workflow or persistence is invoked.
    public IActionResult Submit() => Retired();

    private ObjectResult Retired() => StatusCode(410, new
    {
        message =
            "This customer order-link workflow has been retired. " +
            "Use the configured customer Google Form, then ask an authorised " +
            "staff member to capture the official order in PhenyoSync."
    });

    private static async Task<IActionResult> Execute(Func<Task<IActionResult>> action)
    {
        try { return await action(); }
        catch (OrderManagementException exception)
        {
            return new ObjectResult(new { message = exception.Message, details = exception.Details })
            { StatusCode = exception.StatusCode };
        }
    }
}
