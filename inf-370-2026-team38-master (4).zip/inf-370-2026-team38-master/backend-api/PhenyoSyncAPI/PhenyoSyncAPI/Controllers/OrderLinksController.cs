using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Order;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/order-links")]
[HasPermission(Permissions.Orders.SendLink)]
/// <summary>Retains compatibility routes while directing order-link creation through current APIs.</summary>
public sealed class OrderLinksController : ControllerBase
{
    private readonly IOrderLinkService _service;
    public OrderLinksController(IOrderLinkService service) => _service = service;

    [HttpPost]
    // HTTP POST at the controller root handles the send operation for order links through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // The retired action accepts no request body, so caller-controlled order data is never bound.
    // It maps directly to the shared 410 response without starting an order-link workflow.
    public IActionResult Send() => Retired();

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative order links projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.ListAsync; failures use
    // existing HTTP handling.
    public Task<List<OrderLinkDto>> List(CancellationToken cancellationToken) => _service.ListAsync(cancellationToken);

    [HttpPost("{id:long}/revoke")]
    // HTTP POST at "{id:long}/revoke" removes or retires order links data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.RevokeAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Revoke(long id, CancellationToken cancellationToken) =>
        await Execute(async () => Ok(new
        {
            message = "Order link revoked.",
            link = await _service.RevokeAsync(id, cancellationToken)
        }));

    [HttpPost("{id:long}/resend")]
    // HTTP POST at "{id:long}/resend" handles the resend operation for order links through the established
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The action maps directly to the shared 410 response; no resend workflow or persistence is invoked.
    public IActionResult Resend(long id) => Retired();

    private ObjectResult Retired() => StatusCode(410, new
    {
        message =
            "Secure customer order links are retired. Share the configured " +
            "customer Google Form instead."
    });

    private int UserId() => int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id)
        ? id : throw new OrderManagementException(401, "The authenticated user could not be identified.");

    private static async Task<IActionResult> Execute(Func<Task<IActionResult>> action)
    {
        try { return await action(); }
        catch (OrderManagementException exception)
        {
            return new ObjectResult(new { message = exception.Message, details = exception.Details })
            { StatusCode = exception.StatusCode };
        }
    }
}
