using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Operational;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

public abstract class OperationalControllerBase : ControllerBase
{
    protected int UserId() =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id)
            ? id
            : throw new PhaseCException(401, "The authenticated user is not valid.");
}

[ApiController]
[Authorize]
[Route("api/raw-stock")]
[HasPermission(Permissions.RawStock.View)]
/// <summary>Exposes raw-stock master, balance and receipt operations.</summary>
public sealed class RawStockController : OperationalControllerBase
{
    private readonly IRawStockService _service;

    public RawStockController(IRawStockService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root queries filtered raw stock records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RawStockSearchRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.SearchAsync; failures use
    // existing HTTP handling.
    public Task<PagedResult<RawStockSummaryDto>> Search(
        [FromQuery] RawStockSearchRequest request,
        CancellationToken cancellationToken) =>
        _service.SearchAsync(request, cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.RawStock.Manage)]
    // HTTP POST at the controller root creates or attaches raw stock data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateRawStockRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.CreateAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Create(
        CreateRawStockRequest request,
        CancellationToken cancellationToken)
    {
        var id = await _service.CreateAsync(
            request,
            UserId(),
            cancellationToken);
        return StatusCode(201, new
        {
            message = "Raw-stock item and opening balance created.",
            rawStockItemId = id
        });
    }

    [HttpPost("{id:int}/delete")]
    [HasPermission(Permissions.RawStock.Manage)]
    // HTTP POST at "{id:int}/delete" removes or retires raw stock data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeleteOperationalPartyRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.DeleteAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Delete(
        int id,
        DeleteOperationalPartyRequest request,
        CancellationToken cancellationToken)
    {
        var result = await _service.DeleteAsync(
            id,
            request.Reason,
            UserId(),
            cancellationToken);
        return result.Deleted ? Ok(result) : Conflict(result);
    }

    [HttpPut("{id:int}/status")]
    [HasPermission(Permissions.RawStock.Manage)]
    // HTTP PUT at "{id:int}/status" changes raw stock state only through the supported status operation.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ChangeRawStockStatusRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.ChangeStatusAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> ChangeStatus(
        int id,
        ChangeRawStockStatusRequest request,
        CancellationToken cancellationToken)
    {
        await _service.ChangeStatusAsync(id, request, UserId(), cancellationToken);
        return Ok(new
        {
            message = request.IsActive
                ? "Raw-stock item activated."
                : "Raw-stock item deactivated. Business history was preserved."
        });
    }

    [HttpGet("receipts")]
    [HasPermission(Permissions.RawStock.Receive)]
    // HTTP GET at "receipts" handles the receipts operation for raw stock through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.RecentReceiptsAsync; failures
    // use existing HTTP handling.
    public Task<IReadOnlyList<RawStockReceiptDto>> Receipts(
        CancellationToken cancellationToken) =>
        _service.RecentReceiptsAsync(cancellationToken);

    [HttpPost("receipts")]
    [HasPermission(Permissions.RawStock.Receive)]
    // HTTP POST at "receipts" handles the receive operation for raw stock through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateRawStockReceiptRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.ReceiveAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Receive(
        CreateRawStockReceiptRequest request,
        CancellationToken cancellationToken)
    {
        var result = await _service.ReceiveAsync(
            request,
            UserId(),
            cancellationToken);
        return StatusCode(201, result);
    }
}

[ApiController]
[Authorize]
[Route("api/operational-reasons")]
[HasPermission(Permissions.OperationalReasons.View)]
/// <summary>Manages governed reason codes used by controlled stock adjustments.</summary>
public sealed class OperationalReasonsController : OperationalControllerBase
{
    private readonly IRawStockService _service;

    public OperationalReasonsController(IRawStockService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root queries filtered operational reasons records without mutating state.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts OperationalReasonSearchRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.SearchReasonsAsync; failures
    // use existing HTTP handling.
    public Task<PagedResult<OperationalReasonDto>> Search(
        [FromQuery] OperationalReasonSearchRequest request,
        CancellationToken cancellationToken) =>
        _service.SearchReasonsAsync(request, cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.OperationalReasons.Manage)]
    // HTTP POST at the controller root creates or attaches operational reasons data through the controlled
    // API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveOperationalReasonRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveReasonAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Create(
        SaveOperationalReasonRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            201,
            await _service.SaveReasonAsync(
                null,
                request,
                UserId(),
                cancellationToken));

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.OperationalReasons.Manage)]
    // HTTP PUT at "{id:int}" updates only allowed operational reasons fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveOperationalReasonRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveReasonAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<OperationalReasonDto> Update(
        int id,
        SaveOperationalReasonRequest request,
        CancellationToken cancellationToken) =>
        _service.SaveReasonAsync(
            id,
            request,
            UserId(),
            cancellationToken);
}

[ApiController]
[Authorize]
[Route("api/raw-stock-reconciliation")]
[HasPermission(Permissions.Reconciliation.View)]
/// <summary>Manages raw-to-finished reconciliation control groups.</summary>
public sealed class RawStockReconciliationController : OperationalControllerBase
{
    private readonly IRawStockService _service;

    public RawStockReconciliationController(IRawStockService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative raw stock reconciliation projection needed by
    // the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.GetReconciliationGroupsAsync;
    // failures use existing HTTP handling.
    public Task<IReadOnlyList<ReconciliationGroupDto>> Get(
        CancellationToken cancellationToken) =>
        _service.GetReconciliationGroupsAsync(cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.Reconciliation.Manage)]
    // HTTP POST at the controller root creates or attaches raw stock reconciliation data through the
    // controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReconciliationGroupRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveReconciliationGroupAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Create(
        ReconciliationGroupRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            201,
            await _service.SaveReconciliationGroupAsync(
                null,
                request,
                UserId(),
                cancellationToken));

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.Reconciliation.Manage)]
    // HTTP PUT at "{id:int}" updates only allowed raw stock reconciliation fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts ReconciliationGroupRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveReconciliationGroupAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<ReconciliationGroupDto> Update(
        int id,
        ReconciliationGroupRequest request,
        CancellationToken cancellationToken) =>
        _service.SaveReconciliationGroupAsync(
            id,
            request,
            UserId(),
            cancellationToken);
}

[ApiController]
[Authorize]
[Route("api/raw-stock-takes")]
[HasPermission(Permissions.RawStockTakes.View)]
/// <summary>Exposes stock-take capture and independent approval decisions.</summary>
public sealed class RawStockTakesController : OperationalControllerBase
{
    private readonly IRawStockControlService _service;

    public RawStockTakesController(IRawStockControlService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative raw stock takes projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.ListStockTakesAsync; failures
    // use existing HTTP handling.
    public Task<IReadOnlyList<RawStockTakeDto>> List(
        CancellationToken cancellationToken) =>
        _service.ListStockTakesAsync(cancellationToken);

    [HttpGet("{id:long}")]
    // HTTP GET at "{id:long}" returns the authoritative raw stock takes projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.GetStockTakeAsync; failures
    // use existing HTTP handling.
    public Task<RawStockTakeDto> Get(
        long id,
        CancellationToken cancellationToken) =>
        _service.GetStockTakeAsync(id, cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.RawStockTakes.Capture)]
    // HTTP POST at the controller root creates or attaches raw stock takes data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateRawStockTakeRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.CreateStockTakeAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Create(
        CreateRawStockTakeRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            201,
            await _service.CreateStockTakeAsync(
                request,
                UserId(),
                cancellationToken));

    [HttpPut("{id:long}/lines/{lineId:long}/count")]
    [HasPermission(Permissions.RawStockTakes.Capture)]
    // HTTP PUT at "{id:long}/lines/{lineId:long}/count" records counted quantity while preserving the
    // stock-take concurrency boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveRawStockCountRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveCountAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<RawStockTakeDto> Count(
        long id,
        long lineId,
        SaveRawStockCountRequest request,
        CancellationToken cancellationToken) =>
        _service.SaveCountAsync(
            id,
            lineId,
            request,
            UserId(),
            cancellationToken);

    [HttpPost("{id:long}/submit")]
    [HasPermission(Permissions.RawStockTakes.Capture)]
    // HTTP POST at "{id:long}/submit" submits the count for reconciliation instead of changing stock
    // directly.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RowVersionRequest instead of an EF entity, limiting fields and preventing over-posting.
    // RowVersion is forwarded so a stale client cannot overwrite a newer database update.
    // The thin controller delegates business rules and persistence to _service.SubmitStockTakeAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<RawStockTakeDto> Submit(
        long id,
        RowVersionRequest request,
        CancellationToken cancellationToken) =>
        _service.SubmitStockTakeAsync(
            id,
            request.RowVersion,
            UserId(),
            cancellationToken);

    [HttpPost("{id:long}/review")]
    [HasPermission(Permissions.RawStockTakes.Review)]
    // HTTP POST at "{id:long}/review" records reconciliation review before an approval decision.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RawStockTakeReviewRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.ReviewStockTakeAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<RawStockTakeDto> Review(
        long id,
        RawStockTakeReviewRequest request,
        CancellationToken cancellationToken) =>
        _service.ReviewStockTakeAsync(
            id,
            request,
            UserId(),
            cancellationToken);

    [HttpPost("{id:long}/decision")]
    [HasPermission(Permissions.RawStockTakes.Approve)]
    // HTTP POST at "{id:long}/decision" applies thresholds and no-self-approval rules to the decision.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RawStockTakeDecisionRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.DecideStockTakeAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<RawStockTakeDto> Decide(
        long id,
        RawStockTakeDecisionRequest request,
        CancellationToken cancellationToken) =>
        _service.DecideStockTakeAsync(
            id,
            request,
            UserId(),
            cancellationToken);
}

[ApiController]
[Authorize]
[Route("api/raw-stock-write-offs")]
[HasAnyPermission(
    Permissions.RawStock.View,
    Permissions.RawStock.ApproveWriteOff)]
/// <summary>Exposes raw-stock write-off requests and approval decisions.</summary>
public sealed class RawStockWriteOffsController : OperationalControllerBase
{
    private readonly IRawStockControlService _service;

    public RawStockWriteOffsController(IRawStockControlService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative raw stock write offs projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.ListWriteOffsAsync; failures
    // use existing HTTP handling.
    public Task<IReadOnlyList<RawStockWriteOffDto>> List(
        CancellationToken cancellationToken) =>
        _service.ListWriteOffsAsync(cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.RawStock.WriteOff)]
    // HTTP POST at the controller root creates or attaches raw stock write offs data through the controlled
    // API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateRawStockWriteOffRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.CreateWriteOffAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Create(
        CreateRawStockWriteOffRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            201,
            await _service.CreateWriteOffAsync(
                request,
                UserId(),
                cancellationToken));

    [HttpPost("{id:long}/decision")]
    [HasPermission(Permissions.RawStock.ApproveWriteOff)]
    // HTTP POST at "{id:long}/decision" applies an independent raw-stock write-off decision.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RawStockWriteOffDecisionRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.DecideWriteOffAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<RawStockWriteOffDto> Decide(
        long id,
        RawStockWriteOffDecisionRequest request,
        CancellationToken cancellationToken) =>
        _service.DecideWriteOffAsync(
            id,
            request,
            UserId(),
            cancellationToken);
}

[ApiController]
[Authorize]
[Route("api/operational/customers")]
[HasPermission(Permissions.Customers.View)]
/// <summary>Exposes customer master-data operations used by order intake.</summary>
public sealed class OperationalCustomersController : OperationalControllerBase
{
    private readonly IOperationalPartyService _service;

    public OperationalCustomersController(IOperationalPartyService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative operational customers projection needed by
    // the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.CustomersAsync; failures use
    // existing HTTP handling.
    public Task<IReadOnlyList<CustomerSummaryDto>> List(
        [FromQuery] string? search,
        [FromQuery] bool includeInactive,
        CancellationToken cancellationToken) =>
        _service.CustomersAsync(search, includeInactive, cancellationToken);

    [HttpGet("{id:int}")]
    // HTTP GET at "{id:int}" returns the authoritative operational customers projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.CustomerAsync; failures use
    // existing HTTP handling.
    public Task<CustomerSummaryDto> Get(
        int id,
        CancellationToken cancellationToken) =>
        _service.CustomerAsync(id, cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.Customers.Manage)]
    // HTTP POST at the controller root creates or attaches operational customers data through the controlled
    // API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveCustomerRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveCustomerAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Create(
        SaveCustomerRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            201,
            await _service.SaveCustomerAsync(
                null,
                request,
                UserId(),
                cancellationToken));

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.Customers.Manage)]
    // HTTP PUT at "{id:int}" updates only allowed operational customers fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveCustomerRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveCustomerAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<CustomerSummaryDto> Update(
        int id,
        SaveCustomerRequest request,
        CancellationToken cancellationToken) =>
        _service.SaveCustomerAsync(
            id,
            request,
            UserId(),
            cancellationToken);

    [HttpPost("{id:int}/delete")]
    [HasPermission(Permissions.Customers.Manage)]
    // HTTP POST at "{id:int}/delete" removes or retires operational customers data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeleteOperationalPartyRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.DeleteCustomerAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> Delete(
        int id,
        DeleteOperationalPartyRequest request,
        CancellationToken cancellationToken)
    {
        var result = await _service.DeleteCustomerAsync(
            id,
            request.Reason,
            request.RowVersion,
            UserId(),
            cancellationToken);
        return result.Deleted ? Ok(result) : Conflict(result);
    }
}

[ApiController]
[Authorize]
[Route("api/operational/suppliers")]
[HasPermission(Permissions.Suppliers.View)]
/// <summary>Exposes supplier master-data operations used by procurement.</summary>
public sealed class OperationalSuppliersController : OperationalControllerBase
{
    private readonly IOperationalPartyService _service;

    public OperationalSuppliersController(IOperationalPartyService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative operational suppliers projection needed by
    // the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.SuppliersAsync; failures use
    // existing HTTP handling.
    public Task<IReadOnlyList<SupplierSummaryDto>> List(
        [FromQuery] string? search,
        [FromQuery] bool includeInactive,
        CancellationToken cancellationToken) =>
        _service.SuppliersAsync(search, includeInactive, cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.Suppliers.Manage)]
    // HTTP POST at the controller root creates or attaches operational suppliers data through the controlled
    // API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveSupplierRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveSupplierAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Create(
        SaveSupplierRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            201,
            await _service.SaveSupplierAsync(
                null,
                request,
                UserId(),
                cancellationToken));

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.Suppliers.Manage)]
    // HTTP PUT at "{id:int}" updates only allowed operational suppliers fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SaveSupplierRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.SaveSupplierAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<SupplierSummaryDto> Update(
        int id,
        SaveSupplierRequest request,
        CancellationToken cancellationToken) =>
        _service.SaveSupplierAsync(
            id,
            request,
            UserId(),
            cancellationToken);

    [HttpPost("{id:int}/delete")]
    [HasPermission(Permissions.Suppliers.Manage)]
    // HTTP POST at "{id:int}/delete" removes or retires operational suppliers data after dependency checks.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts DeleteOperationalPartyRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.DeleteSupplierAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
    public async Task<IActionResult> Delete(
        int id,
        DeleteOperationalPartyRequest request,
        CancellationToken cancellationToken)
    {
        var result = await _service.DeleteSupplierAsync(
            id,
            request.Reason,
            request.RowVersion,
            UserId(),
            cancellationToken);
        return result.Deleted ? Ok(result) : Conflict(result);
    }
}

[ApiController]
[Authorize]
[Route("api/supplier-orders")]
[HasPermission(Permissions.SupplierOrders.View)]
/// <summary>Exposes the supplier-order lifecycle and receipt-ready state.</summary>
public sealed class SupplierOrdersController : OperationalControllerBase
{
    private readonly IOperationalPartyService _service;

    public SupplierOrdersController(IOperationalPartyService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative supplier orders projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.SupplierOrdersAsync; failures
    // use existing HTTP handling.
    public Task<IReadOnlyList<SupplierOrderDto>> List(
        CancellationToken cancellationToken) =>
        _service.SupplierOrdersAsync(cancellationToken);

    [HttpGet("raw-stock-options")]
    [HasPermission(Permissions.SupplierOrders.Manage)]
    // The Supplier Order editor needs a narrow purchasing catalogue, not broad Raw Stock access.
    // Backend authorization keeps Warehouse Manager view-only while authorised administrators
    // can select active items without receiving RawStock.View.
    public Task<IReadOnlyList<SupplierOrderRawStockOptionDto>> RawStockOptions(
        CancellationToken cancellationToken) =>
        _service.SupplierOrderRawStockOptionsAsync(cancellationToken);

    [HttpPost]
    [HasPermission(Permissions.SupplierOrders.Manage)]
    // HTTP POST at the controller root creates or attaches supplier orders data through the controlled API
    // boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateSupplierOrderRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.CreateSupplierOrderAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Create(
        CreateSupplierOrderRequest request,
        CancellationToken cancellationToken) =>
        StatusCode(
            201,
            await _service.CreateSupplierOrderAsync(
                request,
                UserId(),
                cancellationToken));

    [HttpPost("{id:int}/approve")]
    [HasPermission(Permissions.SupplierOrders.Manage)]
    // HTTP POST at "{id:int}/approve" approves the supplier order using optimistic concurrency data.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RowVersionRequest instead of an EF entity, limiting fields and preventing over-posting.
    // RowVersion is forwarded so a stale client cannot overwrite a newer database update.
    // The thin controller delegates business rules and persistence to _service.ApproveSupplierOrderAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<SupplierOrderDto> Approve(
        int id,
        RowVersionRequest request,
        CancellationToken cancellationToken) =>
        _service.ApproveSupplierOrderAsync(
            id,
            request.RowVersion,
            UserId(),
            cancellationToken);

    [HttpPost("{id:int}/place")]
    [HasPermission(Permissions.SupplierOrders.Manage)]
    // HTTP POST at "{id:int}/place" places only an approved supplier order using concurrency data.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts RowVersionRequest instead of an EF entity, limiting fields and preventing over-posting.
    // RowVersion is forwarded so a stale client cannot overwrite a newer database update.
    // The thin controller delegates business rules and persistence to _service.ApproveSupplierOrderAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<SupplierOrderDto> Place(
        int id,
        RowVersionRequest request,
        CancellationToken cancellationToken) =>
        _service.ApproveSupplierOrderAsync(
            id,
            request.RowVersion,
            UserId(),
            cancellationToken);

    [HttpPut("{id:int}")]
    [HasPermission(Permissions.SupplierOrders.Manage)]
    // HTTP PUT at "{id:int}" updates only allowed supplier orders fields through a narrow request.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateSupplierOrderRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // RowVersion is forwarded so a stale client cannot overwrite a newer database update.
    // The thin controller delegates business rules and persistence to _service.UpdateSupplierOrderAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<SupplierOrderDto> Update(
        int id,
        [FromQuery] string rowVersion,
        CreateSupplierOrderRequest request,
        CancellationToken cancellationToken) =>
        _service.UpdateSupplierOrderAsync(
            id,
            request,
            rowVersion,
            UserId(),
            cancellationToken);

    [HttpPost("{id:int}/cancel")]
    [HasPermission(Permissions.SupplierOrders.Manage)]
    // HTTP POST at "{id:int}/cancel" continues the supplier orders workflow through its named transition.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts SupplierOrderCommandRequest instead of an EF entity, limiting fields and preventing
    // over-posting.
    // The thin controller delegates business rules and persistence to _service.CancelSupplierOrderAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public Task<SupplierOrderDto> Cancel(
        int id,
        SupplierOrderCommandRequest request,
        CancellationToken cancellationToken) =>
        _service.CancelSupplierOrderAsync(
            id,
            request,
            UserId(),
            cancellationToken);
}

[ApiController]
[Authorize]
[Route("api/financial-payments")]
/// <summary>Exposes payment posting and controlled reversal workflows.</summary>
public sealed class FinancialPaymentsController : OperationalControllerBase
{
    private readonly IOperationalPartyService _service;
    private readonly IPermissionService _permissions;

    public FinancialPaymentsController(
        IOperationalPartyService service,
        IPermissionService permissions)
    {
        _service = service;
        _permissions = permissions;
    }

    [HttpGet]
    [HasAnyPermission(
        Permissions.CustomerPayments.View,
        Permissions.SupplierPayments.View)]
    // HTTP GET at the controller root returns the authoritative financial payments projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.PaymentsAsync; failures use
    // existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IReadOnlyList<PaymentDto>> List(
        [FromQuery] PaymentSearchRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        var canViewCustomers = await _permissions.HasPermissionAsync(
            userId,
            Permissions.CustomerPayments.View,
            cancellationToken);
        var canViewSuppliers = await _permissions.HasPermissionAsync(
            userId,
            Permissions.SupplierPayments.View,
            cancellationToken);

        var requested = request.CounterpartyType?.Trim();
        if (requested?.Equals("Customer", StringComparison.OrdinalIgnoreCase) == true &&
            !canViewCustomers ||
            requested?.Equals("Supplier", StringComparison.OrdinalIgnoreCase) == true &&
            !canViewSuppliers)
        {
            throw new PhaseCException(
                StatusCodes.Status403Forbidden,
                "You do not have permission to view this payment type.");
        }

        if (string.IsNullOrWhiteSpace(request.CounterpartyType))
        {
            request.CounterpartyType = canViewCustomers && canViewSuppliers
                ? null
                : canViewCustomers ? "Customer" : "Supplier";
        }

        if (request.FromUtc.HasValue && request.ToUtc.HasValue &&
            request.FromUtc.Value > request.ToUtc.Value)
            throw new PhaseCException(400, "The payment date range is invalid.");

        return await _service.PaymentsAsync(request, cancellationToken);
    }

    [HttpGet("capture-options")]
    [HasAnyPermission(
        Permissions.CustomerPayments.Capture,
        Permissions.SupplierPayments.Capture)]
    // HTTP GET at "capture-options" handles the capture options operation for financial payments through the
    // established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.PaymentCaptureOptionsAsync;
    // failures use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<PaymentCaptureOptionsDto> CaptureOptions(
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        var includeCustomers = await _permissions.HasPermissionAsync(
            userId,
            Permissions.CustomerPayments.Capture,
            cancellationToken);
        var includeSuppliers = await _permissions.HasPermissionAsync(
            userId,
            Permissions.SupplierPayments.Capture,
            cancellationToken);
        return await _service.PaymentCaptureOptionsAsync(
            includeCustomers,
            includeSuppliers,
            cancellationToken);
    }

    [HttpPost]
    [HasAnyPermission(
        Permissions.CustomerPayments.Capture,
        Permissions.SupplierPayments.Capture)]
    // HTTP POST at the controller root captures a customer or supplier payment through the permitted
    // workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts PaymentRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.CapturePaymentAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<IActionResult> Capture(
        PaymentRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        var requiredPermission = request.SupplierId.HasValue ||
                                 request.SupplierOrderId.HasValue
            ? Permissions.SupplierPayments.Capture
            : Permissions.CustomerPayments.Capture;
        if (!await _permissions.HasPermissionAsync(
                userId,
                requiredPermission,
                cancellationToken))
        {
            throw new PhaseCException(
                StatusCodes.Status403Forbidden,
                "You do not have permission to capture this payment type.");
        }

        return StatusCode(
            201,
            await _service.CapturePaymentAsync(
                request,
                userId,
                cancellationToken));
    }

    [HttpPost("{id:long}/request-reversal")]
    [HasAnyPermission(
        Permissions.CustomerPayments.Reverse,
        Permissions.SupplierPayments.Reverse)]
    // HTTP POST at "{id:long}/request-reversal" requests reversal without deleting or rewriting the payment.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts PaymentDecisionRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.RequestReversalAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<PaymentDto> RequestReversal(
        long id,
        PaymentDecisionRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        var payment = await _service.PaymentAsync(id, cancellationToken);
        var requiredPermission = payment.CounterpartyType == "Supplier"
            ? Permissions.SupplierPayments.Reverse
            : Permissions.CustomerPayments.Reverse;
        if (!await _permissions.HasPermissionAsync(
                userId,
                requiredPermission,
                cancellationToken))
            throw new PhaseCException(
                StatusCodes.Status403Forbidden,
                "You do not have permission to reverse this payment.");

        return await _service.RequestReversalAsync(
            id,
            request,
            userId,
            cancellationToken);
    }

    [HttpPost("{id:long}/reversal-decision")]
    [HasAnyPermission(
        Permissions.CustomerPayments.ApproveReversal,
        Permissions.SupplierPayments.ApproveReversal)]
    // HTTP POST at "{id:long}/reversal-decision" records an independent approval or rejection of the
    // reversal.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts PaymentDecisionRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _service.DecideReversalAsync; failures
    // use existing HTTP handling.
    // Actor identity comes from JWT claims rather than a caller-supplied user ID.
    public async Task<PaymentDto> DecideReversal(
        long id,
        [FromQuery] bool approved,
        PaymentDecisionRequest request,
        CancellationToken cancellationToken)
    {
        var userId = UserId();
        var payment = await _service.PaymentAsync(id, cancellationToken);
        var requiredPermission = payment.CounterpartyType == "Supplier"
            ? Permissions.SupplierPayments.ApproveReversal
            : Permissions.CustomerPayments.ApproveReversal;
        if (!await _permissions.HasPermissionAsync(
                userId,
                requiredPermission,
                cancellationToken))
        {
            throw new PhaseCException(
                StatusCodes.Status403Forbidden,
                "You do not have permission to decide this payment reversal.");
        }

        return await _service.DecideReversalAsync(
            id,
            approved,
            request,
            userId,
            cancellationToken);
    }
}

[ApiController]
[Authorize]
[Route("api/management-dashboard")]
[HasPermission(Permissions.ManagementDashboard.View)]
/// <summary>Returns operational management KPIs under dashboard permissions.</summary>
public sealed class ManagementDashboardController : ControllerBase
{
    private readonly IManagementDashboardService _service;

    public ManagementDashboardController(IManagementDashboardService service)
    {
        _service = service;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative management dashboard projection needed by the
    // client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // The thin controller delegates business rules and persistence to _service.GetAsync; failures use
    // existing HTTP handling.
    public Task<ManagementDashboardDto> Get(
        [FromQuery] DateTime? fromUtc,
        [FromQuery] DateTime? toUtc,
        CancellationToken cancellationToken) =>
        _service.GetAsync(fromUtc, toUtc, cancellationToken);
}
