using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Services;
using PhenyoSyncAPI.DTOs.Auth;
using System.Security.Cryptography;
using System.Text;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Security;
using System.Security.Claims;
using Microsoft.AspNetCore.RateLimiting;

namespace PhenyoSyncAPI.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        private readonly PhenyoSyncDbContext _context;
        private readonly JwtService _jwt;
        private readonly IEmailService _emailService;
        private readonly IConfiguration _configuration;
        private readonly IAuditService _auditService;
        private readonly ITwoFactorService _twoFactor;
        private readonly ILogger<AuthController> _logger;
        private const string TrustedDeviceCookie = "phenyosync_trusted_device";

        public AuthController(
            PhenyoSyncDbContext context,
            JwtService jwt,
            IEmailService emailService,
            IConfiguration configuration,
            IAuditService auditService,
            ITwoFactorService twoFactor,
            ILogger<AuthController> logger)
        {
            _context = context;
            _jwt = jwt;
            _emailService = emailService;
            _configuration = configuration;
            _auditService = auditService;
            _twoFactor = twoFactor;
            _logger = logger;
        }

        // =====================================================
        // LOGIN
        // POST: api/auth/login
        // =====================================================

        [HttpPost("login")]
        [AllowAnonymous]
        [EnableRateLimiting("login")]
        // HTTP POST at "login" authenticates credentials and either returns a session or opens a two-factor
        // challenge.
        // This endpoint is deliberately anonymous; narrow input plus credential or token checks contain access.
        // Accepts LoginDto instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _twoFactor.CreateChallengeAsync;
        // failures use existing HTTP handling.
        public async Task<IActionResult> Login(
            [FromBody] LoginDto dto,
            CancellationToken cancellationToken)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(dto.Email) ||
                    string.IsNullOrWhiteSpace(dto.Password))
                {
                    await RecordLoginAsync(
                        false,
                        dto.Email,
                        null,
                        "Email and password are required.",
                        cancellationToken);
                    return BadRequest(new
                    {
                        message = "Email and password are required."
                    });
                }

                var client = dto.Client.Trim();
                if (!AuthenticationClients.Allowed.Contains(client))
                {
                    return BadRequest(new
                    {
                        message = "Client must be Web or Mobile."
                    });
                }

                string email = dto.Email.Trim();
                string normalizedEmail = email.ToUpperInvariant();

                var user = await _context.Users
                    .Include(u => u.Role)
                    .FirstOrDefaultAsync(
                        u => u.NormalizedEmail == normalizedEmail,
                        cancellationToken);

                if (user == null)
                {
                    await RecordLoginAsync(
                        false,
                        email,
                        null,
                        "Invalid credentials.",
                        cancellationToken);
                    return Unauthorized(new
                    {
                        message = "Invalid email or password."
                    });
                }

                bool isPasswordValid;

                try
                {
                    isPasswordValid =
                        BCrypt.Net.BCrypt.Verify(
                            dto.Password,
                            user.PasswordHash
                        );
                }
                catch (BCrypt.Net.SaltParseException)
                {
                    // Legacy non-BCrypt accounts must use the reset flow.
                    isPasswordValid = false;
                }

                if (!isPasswordValid)
                {
                    await RecordLoginAsync(
                        false,
                        email,
                        null,
                        "Invalid credentials.",
                        cancellationToken);
                    return Unauthorized(new
                    {
                        message = "Invalid email or password."
                    });
                }

                if (string.IsNullOrWhiteSpace(user.Status) ||
                    !string.Equals(
                        user.Status,
                        "Active",
                        StringComparison.OrdinalIgnoreCase) ||
                    user.Role is not { IsActive: true })
                {
                    await RecordLoginAsync(
                        false,
                        email,
                        user,
                        "The user account is inactive.",
                        cancellationToken);
                    return Unauthorized(new
                    {
                        message = "User account is inactive."
                    });
                }
                var isMobile = client.Equals(
                    AuthenticationClients.Mobile,
                    StringComparison.OrdinalIgnoreCase);
                if (isMobile || !user.RequireTwoFactorOnNextWebLogin)
                {
                    await RecordLoginAsync(
                        true,
                        user.Email,
                        user,
                        null,
                        cancellationToken,
                        client);
                    return Ok(Authentication(user));
                }

                var challenge = await _twoFactor.CreateChallengeAsync(
                    user,
                    HttpContext.TraceIdentifier,
                    HttpContext.Connection.RemoteIpAddress?.ToString(),
                    Request.Headers.UserAgent.ToString(),
                    cancellationToken);
                return Ok(challenge);
            }
            catch (TwoFactorException exception)
            {
                return StatusCode(
                    exception.StatusCode,
                    new
                    {
                        message = exception.Message,
                        code = exception.Code
                    });
            }
            catch (Exception)
            {
                return StatusCode(500, new
                {
                    message = "An error occurred during login."
                });
            }
        }

        [HttpPost("verify-otp")]
        [AllowAnonymous]
        [EnableRateLimiting("two-factor")]
        // HTTP POST at "verify-otp" verifies the email OTP before issuing the authenticated session.
        // This endpoint is deliberately anonymous; narrow input plus credential or token checks contain access.
        // Accepts VerifyOtpRequest instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _twoFactor.VerifyOtpAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> VerifyOtp(
            [FromBody] VerifyOtpRequest request,
            CancellationToken cancellationToken) =>
            await VerifySecondFactorAsync(
                () => _twoFactor.VerifyOtpAsync(
                    request.ChallengeToken,
                    request.Otp,
                    request.TrustDevice,
                    request.DeviceName,
                    Request.Headers.UserAgent.ToString(),
                    cancellationToken),
                cancellationToken);

        [HttpPost("verify-recovery-code")]
        [AllowAnonymous]
        [EnableRateLimiting("two-factor")]
        // HTTP POST at "verify-recovery-code" consumes a recovery code as the fallback second factor.
        // This endpoint is deliberately anonymous; narrow input plus credential or token checks contain access.
        // Accepts VerifyRecoveryCodeRequest instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _twoFactor.VerifyRecoveryCodeAsync;
        // failures use existing HTTP handling.
        public async Task<IActionResult> VerifyRecoveryCode(
            [FromBody] VerifyRecoveryCodeRequest request,
            CancellationToken cancellationToken) =>
            await VerifySecondFactorAsync(
                () => _twoFactor.VerifyRecoveryCodeAsync(
                    request.ChallengeToken,
                    request.RecoveryCode,
                    request.TrustDevice,
                    request.DeviceName,
                    Request.Headers.UserAgent.ToString(),
                    cancellationToken),
                cancellationToken);

        [HttpPost("resend-otp")]
        [AllowAnonymous]
        [EnableRateLimiting("two-factor")]
        // HTTP POST at "resend-otp" requests a replacement OTP without exposing unrelated account data.
        // This endpoint is deliberately anonymous; narrow input plus credential or token checks contain access.
        // Accepts ResendOtpRequest instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _twoFactor.ResendAsync; failures use
        // existing HTTP handling.
        public async Task<IActionResult> ResendOtp(
            [FromBody] ResendOtpRequest request,
            CancellationToken cancellationToken)
        {
            try
            {
                return Ok(await _twoFactor.ResendAsync(
                    request.ChallengeToken,
                    cancellationToken));
            }
            catch (TwoFactorException exception)
            {
                return StatusCode(
                    exception.StatusCode,
                    new
                    {
                        message = exception.Message,
                        code = exception.Code
                    });
            }
        }

        [HttpGet("trusted-devices")]
        [Authorize]
        // HTTP GET at "trusted-devices" lists trusted-device sessions belonging only to the authenticated
        // account.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to _twoFactor.GetTrustedDevicesAsync;
        // failures use existing HTTP handling.
        public async Task<IActionResult> TrustedDevices(
            CancellationToken cancellationToken) =>
            Ok(await _twoFactor.GetTrustedDevicesAsync(
                CurrentUserId(),
                Request.Cookies[TrustedDeviceCookie],
                cancellationToken));

        [HttpDelete("trusted-devices/{id:long}")]
        [Authorize]
        // HTTP DELETE at "trusted-devices/{id:long}" revokes one trusted device owned by the authenticated
        // account.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to _twoFactor.RevokeTrustedDeviceAsync;
        // failures use existing HTTP handling.
        public async Task<IActionResult> RevokeTrustedDevice(
            long id,
            CancellationToken cancellationToken)
        {
            try
            {
                await _twoFactor.RevokeTrustedDeviceAsync(
                    CurrentUserId(),
                    id,
                    "Revoked by the account owner.",
                    cancellationToken);
                return Ok(new
                {
                    message = "The trusted device was revoked."
                });
            }
            catch (TwoFactorException exception)
            {
                return StatusCode(
                    exception.StatusCode,
                    new
                    {
                        message = exception.Message,
                        code = exception.Code
                    });
            }
        }

        [HttpDelete("trusted-devices")]
        [Authorize]
        // HTTP DELETE at "trusted-devices" invalidates every trusted device for the authenticated account.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to
        // _twoFactor.RevokeAllTrustedDevicesAsync; failures use existing HTTP handling.
        public async Task<IActionResult> RevokeAllTrustedDevices(
            CancellationToken cancellationToken)
        {
            await _twoFactor.RevokeAllTrustedDevicesAsync(
                CurrentUserId(),
                "All devices revoked by the account owner.",
                cancellationToken);
            DeleteTrustedDeviceCookie();
            return Ok(new
            {
                message = "All trusted devices were revoked."
            });
        }

        [HttpGet("recovery-codes/status")]
        [Authorize]
        // HTTP GET at "recovery-codes/status" reports recovery-code availability without returning stored code
        // material.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to _twoFactor.GetRecoveryCodeStatusAsync;
        // failures use existing HTTP handling.
        public async Task<IActionResult> RecoveryCodeStatus(
            CancellationToken cancellationToken) =>
            Ok(await _twoFactor.GetRecoveryCodeStatusAsync(
                CurrentUserId(),
                cancellationToken));

        [HttpPost("recovery-codes/regenerate")]
        [Authorize]
        // HTTP POST at "recovery-codes/regenerate" replaces recovery codes after password confirmation and
        // returns them once.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts RegenerateRecoveryCodesRequest instead of an EF entity, limiting fields and preventing
        // over-posting.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to
        // _twoFactor.RegenerateRecoveryCodesAsync; failures use existing HTTP handling.
        public async Task<IActionResult> RegenerateRecoveryCodes(
            [FromBody] RegenerateRecoveryCodesRequest request,
            CancellationToken cancellationToken)
        {
            var user = await _context.Users
                .Include(item => item.Role)
                .SingleAsync(
                    item => item.UserId == CurrentUserId(),
                    cancellationToken);
            if (!BCrypt.Net.BCrypt.Verify(
                    request.CurrentPassword,
                    user.PasswordHash))
            {
                return Unauthorized(new
                {
                    message = "The current password is incorrect.",
                    code = "CURRENT_PASSWORD_INVALID"
                });
            }

            var result = await _twoFactor.RegenerateRecoveryCodesAsync(
                user,
                cancellationToken);
            return Ok(new
            {
                message = "New recovery codes were generated. Save them now; they cannot be shown again.",
                recoveryCodes = result.Codes,
                status = result.Status
            });
        }

        [HttpGet("profile")]
        [Authorize]
        // HTTP GET at "profile" returns the authenticated user's own profile projection.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // EF queries are projected to response data rather than exposing tracked entities.
        public async Task<ActionResult<MyProfileDto>> MyProfile(
            CancellationToken cancellationToken)
        {
            var user = await _context.Users
                .AsNoTracking()
                .Include(item => item.Role)
                .Include(item => item.Driver)
                .SingleAsync(
                    item => item.UserId == CurrentUserId(),
                    cancellationToken);
            return Ok(MapProfile(user));
        }

        [HttpPut("profile")]
        [Authorize]
        // HTTP PUT at "profile" updates only fields allowed for self-service profile editing.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts UpdateMyProfileRequest instead of an EF entity, limiting fields and preventing over-posting.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to _context.Entry and
        // _context.SaveChangesAsync; failures use existing HTTP handling.
        // RowVersion is forwarded for optimistic concurrency; stale clients cannot overwrite newer state.
        public async Task<ActionResult<MyProfileDto>> UpdateMyProfile(
            [FromBody] UpdateMyProfileRequest request,
            CancellationToken cancellationToken)
        {
            // The authenticated claim chooses the record. A caller cannot put
            // another user id in the body and update somebody else's profile.
            var user = await _context.Users
                .Include(item => item.Role)
                .Include(item => item.Driver)
                .SingleAsync(
                    item => item.UserId == CurrentUserId(),
                    cancellationToken);
            byte[] submittedRowVersion;
            try
            {
                submittedRowVersion = Convert.FromBase64String(request.RowVersion);
            }
            catch (FormatException)
            {
                return BadRequest(new
                {
                    message = "The profile version is invalid. Refresh and try again."
                });
            }

            _context.Entry(user).Property(item => item.RowVersion)
                .OriginalValue = submittedRowVersion;

            // Phone number is the only self-service contact field. Names,
            // email, username, role, status and Driver details remain exactly
            // as stored and can only be changed by their admin endpoints.
            user.PhoneNumber = string.IsNullOrWhiteSpace(request.PhoneNumber)
                ? null
                : request.PhoneNumber.Trim();
            user.UpdatedAtUtc = DateTime.UtcNow;

            await _context.SaveChangesAsync(cancellationToken);
            await _auditService.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.Update,
                SystemModule = AuditModules.UserManagement,
                OperationName = "UpdateMyProfile",
                Description = "A user updated their own profile.",
                EntityType = nameof(Entities.User),
                EntityId = user.UserId.ToString(),
                EntityDisplay = $"{user.FirstName} {user.LastName}".Trim(),
                UserId = user.UserId,
                UserEmail = user.Email,
                UserDisplayName = $"{user.FirstName} {user.LastName}".Trim(),
                ActorType = AuditActorTypes.User,
                EventSource = AuditEventSources.SecurityEvent,
                SafeDetails = new Dictionary<string, object?>
                {
                    ["EditableField"] = "PhoneNumber",
                    ["PhoneSupplied"] = user.PhoneNumber is not null
                }
            }, cancellationToken);
            return Ok(MapProfile(user));
        }

        [HttpPost("change-password")]
        [Authorize]
        // HTTP POST at "change-password" changes the current password and invalidates trusted sessions.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Accepts ChangeMyPasswordRequest instead of an EF entity, limiting fields and preventing over-posting.
        // Actor identity comes from JWT claims rather than a caller-supplied user ID.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
        // _twoFactor.RevokeAllTrustedDevicesAsync; failures use existing HTTP handling.
        public async Task<IActionResult> ChangeMyPassword(
            [FromBody] ChangeMyPasswordRequest request,
            CancellationToken cancellationToken)
        {
            if (request.NewPassword != request.ConfirmPassword)
                return BadRequest(new { message = "Passwords do not match." });
            if (request.NewPassword.Length < 8)
                return BadRequest(new
                {
                    message = "Password must contain at least 8 characters."
                });

            var user = await _context.Users.SingleAsync(
                item => item.UserId == CurrentUserId(),
                cancellationToken);
            if (!BCrypt.Net.BCrypt.Verify(
                    request.CurrentPassword,
                    user.PasswordHash))
            {
                return Unauthorized(new
                {
                    message = "The current password is incorrect."
                });
            }

            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(
                request.NewPassword);
            user.SecurityVersion++;
            user.RequireTwoFactorOnNextWebLogin = true;
            user.UpdatedAtUtc = DateTime.UtcNow;
            user.PasswordResetTokenHash = null;
            user.PasswordResetTokenExpiry = null;
            await _context.SaveChangesAsync(cancellationToken);
            await _twoFactor.RevokeAllTrustedDevicesAsync(
                user.UserId,
                "Password changed by the account owner.",
                cancellationToken);
            DeleteTrustedDeviceCookie();
            await _auditService.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.PasswordResetCompleted,
                SystemModule = AuditModules.Authentication,
                OperationName = "ChangeMyPassword",
                Description = "A user changed their own password.",
                EntityType = nameof(Entities.User),
                EntityId = user.UserId.ToString(),
                UserId = user.UserId,
                UserEmail = user.Email,
                UserDisplayName = $"{user.FirstName} {user.LastName}".Trim(),
                ActorType = AuditActorTypes.User,
                EventSource = AuditEventSources.SecurityEvent
            }, cancellationToken);
            return Ok(new
            {
                message = "Password changed. Sign in again with your new password."
            });
        }

        // =====================================================
        // FORGOT PASSWORD
        // POST: api/auth/forgot-password
        // =====================================================

        [HttpPost("forgot-password")]
        [AllowAnonymous]
        // HTTP POST at "forgot-password" starts the privacy-preserving password-reset email flow.
        // Account recovery is anonymous, but the response stays uniform to prevent account enumeration.
        // Accepts ForgotPasswordRequest instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _auditService.RecordAsync and
        // _context.SaveChangesAsync; failures use existing HTTP handling.
        public async Task<IActionResult> ForgotPassword(
            [FromBody] ForgotPasswordRequest request,
            CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(request.Email))
            {
                return BadRequest(new
                {
                    message = "Email address is required."
                });
            }

            string email = request.Email.Trim();
            string normalizedEmail = email.ToUpperInvariant();

            var user = await _context.Users
                .FirstOrDefaultAsync(u =>
                    u.NormalizedEmail == normalizedEmail &&
                    u.Status == "Active",
                    cancellationToken);

            var genericResponse = new
            {
                message =
                    "If an account exists for that email, a password reset link has been sent."
            };

            /*
             * Do not reveal whether the email exists.
             * This protects the system from account enumeration.
             */
            if (user == null)
            {
                await _auditService.RecordAsync(new AuditEvent
                {
                    ActionType = AuditActionTypes.PasswordResetRequested,
                    SystemModule = AuditModules.Authentication,
                    OperationName = "RequestPasswordReset",
                    Description = "A password-reset request was received.",
                    Success = true,
                    ActorType = AuditActorTypes.Anonymous,
                    UserEmail = AuditSanitizer.MaskEmail(email),
                    EventSource = AuditEventSources.SecurityEvent
                }, HttpContext.RequestAborted);
                return Ok(genericResponse);
            }

            string token = GenerateResetToken();

            user.PasswordResetTokenHash =
                HashResetToken(token);

            user.PasswordResetTokenExpiry =
                DateTime.UtcNow.AddMinutes(30);

            await _context.SaveChangesAsync(cancellationToken);

            string frontendUrl =
                _configuration["FrontendUrl"]
                ?? "http://localhost:4200";

            string resetLink =
                $"{frontendUrl}/reset-password" +
                $"?email={Uri.EscapeDataString(user.Email)}" +
                $"&token={Uri.EscapeDataString(token)}";

            try
            {
                await _emailService
                    .SendPasswordResetEmailAsync(
                        user.Email,
                        resetLink
                    );
            }
            catch (Exception)
            {
                _logger.LogError("Password reset email could not be sent.");
                await _auditService.RecordAsync(new AuditEvent
                {
                    ActionType = AuditActionTypes.SendEmail,
                    SystemModule = AuditModules.Authentication,
                    OperationName = "SendPasswordResetEmail",
                    Description = "The password-reset email could not be sent.",
                    EntityType = nameof(Entities.User),
                    EntityId = user.UserId.ToString(),
                    EntityDisplay = AuditSanitizer.MaskEmail(user.Email),
                    Success = false,
                    FailureReason = "Email delivery failed.",
                    ActorType = AuditActorTypes.Anonymous,
                    UserEmail = AuditSanitizer.MaskEmail(email),
                    EventSource = AuditEventSources.SecurityEvent
                }, HttpContext.RequestAborted);

                // Keep the public response indistinguishable from an unknown
                // account while surfacing the delivery failure through the
                // safe operational log and audit event above.
                return Ok(genericResponse);
            }

            await _auditService.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.PasswordResetRequested,
                SystemModule = AuditModules.Authentication,
                OperationName = "RequestPasswordReset",
                Description = "A password-reset link was generated and sent.",
                EntityType = nameof(Entities.User),
                EntityId = user.UserId.ToString(),
                EntityDisplay = AuditSanitizer.MaskEmail(user.Email),
                Success = true,
                ActorType = AuditActorTypes.Anonymous,
                UserEmail = AuditSanitizer.MaskEmail(email),
                EventSource = AuditEventSources.SecurityEvent
            }, HttpContext.RequestAborted);
            return Ok(genericResponse);
        }

        // =====================================================
        // RESET PASSWORD
        // POST: api/auth/reset-password
        // =====================================================

        [HttpPost("reset-password")]
        [AllowAnonymous]
        // HTTP POST at "reset-password" consumes the reset token, changes the password, and invalidates old
        // sessions.
        // This endpoint is deliberately anonymous; narrow input plus credential or token checks contain access.
        // Accepts ResetPasswordRequest instead of an EF entity, limiting fields and preventing over-posting.
        // The thin controller delegates business rules and persistence to _context.SaveChangesAsync and
        // _twoFactor.RevokeAllTrustedDevicesAsync; failures use existing HTTP handling.
        public async Task<IActionResult> ResetPassword(
            [FromBody] ResetPasswordRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email) ||
                string.IsNullOrWhiteSpace(request.Token) ||
                string.IsNullOrWhiteSpace(request.NewPassword) ||
                string.IsNullOrWhiteSpace(request.ConfirmPassword))
            {
                return BadRequest(new
                {
                    message = "All fields are required."
                });
            }

            if (request.NewPassword != request.ConfirmPassword)
            {
                return BadRequest(new
                {
                    message = "Passwords do not match."
                });
            }

            if (request.NewPassword.Length < 8)
            {
                return BadRequest(new
                {
                    message =
                        "Password must contain at least 8 characters."
                });
            }

            string email = request.Email.Trim();
            string normalizedEmail = email.ToUpperInvariant();

            var user = await _context.Users
                .FirstOrDefaultAsync(u =>
                    u.NormalizedEmail == normalizedEmail);

            if (user == null ||
                string.IsNullOrWhiteSpace(
                    user.PasswordResetTokenHash
                ) ||
                user.PasswordResetTokenExpiry == null ||
                user.PasswordResetTokenExpiry <= DateTime.UtcNow)
            {
                return BadRequest(new
                {
                    message =
                        "The password reset link is invalid or has expired."
                });
            }

            string suppliedTokenHash =
                HashResetToken(request.Token);

            bool tokenMatches =
                CryptographicOperations.FixedTimeEquals(
                    Convert.FromHexString(
                        user.PasswordResetTokenHash
                    ),
                    Convert.FromHexString(
                        suppliedTokenHash
                    )
                );

            if (!tokenMatches)
            {
                return BadRequest(new
                {
                    message =
                        "The password reset link is invalid or has expired."
                });
            }

            user.PasswordHash =
                BCrypt.Net.BCrypt.HashPassword(
                    request.NewPassword
                );

            // Prevent the reset link from being reused.
            user.PasswordResetTokenHash = null;
            user.PasswordResetTokenExpiry = null;
            user.SecurityVersion++;
            user.RequireTwoFactorOnNextWebLogin = true;
            user.UpdatedAtUtc = DateTime.UtcNow;

            await _context.SaveChangesAsync(HttpContext.RequestAborted);
            await _twoFactor.RevokeAllTrustedDevicesAsync(
                user.UserId,
                "Password reset completed.",
                HttpContext.RequestAborted);
            await _auditService.RecordAsync(new AuditEvent
            {
                ActionType = AuditActionTypes.PasswordResetCompleted,
                SystemModule = AuditModules.Authentication,
                OperationName = "CompletePasswordReset",
                Description = "A user password was reset successfully.",
                EntityType = nameof(Entities.User),
                EntityId = user.UserId.ToString(),
                EntityDisplay = AuditSanitizer.MaskEmail(user.Email),
                UserId = user.UserId,
                UserEmail = user.Email,
                UserDisplayName = $"{user.FirstName} {user.LastName}".Trim(),
                ActorType = AuditActorTypes.Anonymous,
                EventSource = AuditEventSources.SecurityEvent
            }, HttpContext.RequestAborted);

            return Ok(new
            {
                message =
                    "Password reset successfully. You can now log in."
            });
        }

        // =====================================================
        // HELPER METHODS
        // =====================================================

        private static string GenerateResetToken()
        {
            byte[] tokenBytes =
                RandomNumberGenerator.GetBytes(32);

            return Convert
                .ToBase64String(tokenBytes)
                .Replace("+", "-")
                .Replace("/", "_")
                .TrimEnd('=');
        }

        private static string HashResetToken(
            string token)
        {
            byte[] tokenBytes =
                Encoding.UTF8.GetBytes(token);

            byte[] hashBytes =
                SHA256.HashData(tokenBytes);

            return Convert.ToHexString(hashBytes);
        }

        private async Task<IActionResult> VerifySecondFactorAsync(
            Func<Task<TwoFactorVerificationResult>> verify,
            CancellationToken cancellationToken)
        {
            try
            {
                var result = await verify();
                if (result.User.RequireTwoFactorOnNextWebLogin)
                {
                    result.User.RequireTwoFactorOnNextWebLogin = false;
                    result.User.UpdatedAtUtc = DateTime.UtcNow;
                    await _context.SaveChangesAsync(cancellationToken);
                    await _auditService.RecordAsync(new AuditEvent
                    {
                        ActionType = AuditActionTypes.Update,
                        SystemModule = AuditModules.Authentication,
                        OperationName = "SatisfyPostResetWebTwoFactor",
                        Description =
                            "The one-time post-password-reset web verification requirement was satisfied.",
                        EntityType = nameof(Entities.User),
                        EntityId = result.User.UserId.ToString(),
                        UserId = result.User.UserId,
                        UserEmail = result.User.Email,
                        UserDisplayName =
                            $"{result.User.FirstName} {result.User.LastName}".Trim(),
                        ActorType = AuditActorTypes.User,
                        EventSource = AuditEventSources.SecurityEvent
                    }, cancellationToken);
                }
                if (!string.IsNullOrWhiteSpace(result.TrustedDeviceToken) &&
                    result.TrustedDeviceExpiresAtUtc.HasValue)
                {
                    SetTrustedDeviceCookie(
                        result.TrustedDeviceToken,
                        result.TrustedDeviceExpiresAtUtc.Value);
                }

                await RecordLoginAsync(
                    true,
                    result.User.Email,
                    result.User,
                    null,
                    cancellationToken);
                return Ok(Authentication(
                    result.User,
                    result.RecoveryCodes));
            }
            catch (TwoFactorException exception)
            {
                return StatusCode(
                    exception.StatusCode,
                    new
                    {
                        message = exception.Message,
                        code = exception.Code
                    });
            }
        }

        private AuthenticationResponse Authentication(
            Entities.User user,
            IReadOnlyList<string>? recoveryCodes = null) =>
            new(
                _jwt.GenerateToken(user),
                user.UserId,
                user.Email,
                user.FirstName,
                user.LastName,
                user.Role is null
                    ? "Unknown"
                    : RoleCodes.Normalize(
                        user.Role.RoleCode ?? user.Role.RoleName),
                recoveryCodes);

        private static MyProfileDto MapProfile(Entities.User user)
        {
            var roleCode = RoleCodes.Normalize(
                user.Role?.RoleCode ?? user.Role?.RoleName);
            return new MyProfileDto
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Username = user.Email,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                RoleCode = roleCode,
                RoleName = roleCode == RoleCodes.Admin
                    ? "Super Admin"
                    : user.Role?.RoleName ?? roleCode,
                LicenseNumber = roleCode == RoleCodes.Driver
                    ? user.Driver?.LicenseNumber
                    : null,
                LicenseExpiryDate = roleCode == RoleCodes.Driver
                    ? user.Driver?.LicenseExpiryDate
                    : null,
                VehicleAssigned = roleCode == RoleCodes.Driver
                    ? user.Driver?.VehicleAssigned
                    : null,
                AvailabilityStatus = roleCode == RoleCodes.Driver
                    ? user.Driver?.AvailabilityStatus
                    : null,
                RowVersion = Convert.ToBase64String(user.RowVersion ?? [])
            };
        }

        private int CurrentUserId() =>
            int.TryParse(
                User.FindFirstValue(ClaimTypes.NameIdentifier),
                out var userId)
                ? userId
                : throw new UnauthorizedAccessException();

        private void SetTrustedDeviceCookie(
            string token,
            DateTime expiresAtUtc) =>
            Response.Cookies.Append(
                TrustedDeviceCookie,
                token,
                new CookieOptions
                {
                    HttpOnly = true,
                    Secure = true,
                    SameSite = SameSiteMode.None,
                    Path = "/api/auth",
                    Expires = expiresAtUtc
                });

        private void DeleteTrustedDeviceCookie() =>
            Response.Cookies.Delete(
                TrustedDeviceCookie,
                new CookieOptions
                {
                    HttpOnly = true,
                    Secure = true,
                    SameSite = SameSiteMode.None,
                    Path = "/api/auth"
                });

        private Task RecordLoginAsync(
            bool success,
            string? email,
            Entities.User? user,
            string? failureReason,
            CancellationToken cancellationToken,
            string client = AuthenticationClients.Web) =>
            _auditService.RecordAsync(new AuditEvent
            {
                ActionType = success
                    ? AuditActionTypes.LoginSuccess
                    : AuditActionTypes.LoginFailure,
                SystemModule = AuditModules.Authentication,
                OperationName = "Login",
                Description = success
                    ? "A user logged in successfully."
                    : "A login attempt was rejected.",
                EntityType = user is null ? null : nameof(Entities.User),
                EntityId = user?.UserId.ToString(),
                EntityDisplay = AuditSanitizer.MaskEmail(email),
                Success = success,
                FailureReason = failureReason,
                UserId = success ? user?.UserId : null,
                UserEmail = success ? user?.Email : AuditSanitizer.MaskEmail(email),
                UserDisplayName = success && user is not null
                    ? $"{user.FirstName} {user.LastName}".Trim()
                    : null,
                UserRole = success ? user?.Role?.RoleName : null,
                ActorType = success ? AuditActorTypes.User : AuditActorTypes.Anonymous,
                EventSource = AuditEventSources.SecurityEvent,
                SafeDetails = new Dictionary<string, object?>
                {
                    ["client"] = client
                }
            }, cancellationToken);
    }
}
