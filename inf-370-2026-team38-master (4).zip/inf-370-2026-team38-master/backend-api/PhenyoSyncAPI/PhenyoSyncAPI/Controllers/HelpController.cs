using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhenyoSyncAPI.DTOs.Help;
using PhenyoSyncAPI.Services;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/help")]
[AllowAnonymous]
/// <summary>Returns help content filtered by route, role and active publication state.</summary>
public sealed class HelpController : ControllerBase
{
    private readonly IHelpService _help;
    private readonly IHelpMediaService _media;

    public HelpController(
        IHelpService help,
        IHelpMediaService media)
    {
        _help = help;
        _media = media;
    }

    [HttpGet]
    // HTTP GET at the controller root returns the authoritative help projection needed by the client.
    // This endpoint is deliberately anonymous so published help remains available before sign-in.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // When a caller is signed in, role context comes from JWT claims; anonymous callers supply no identity.
    // The thin controller delegates business rules and persistence to _help.HomeAsync; failures use existing
    // HTTP handling.
    public Task<HelpHomeDto> Home(CancellationToken cancellationToken) =>
        _help.HomeAsync(
            Role(),
            User.Identity?.IsAuthenticated == true,
            cancellationToken);

    [HttpGet("search")]
    // HTTP GET at "search" queries filtered help records without mutating state.
    // This endpoint is deliberately anonymous so published help remains available before sign-in.
    // Accepts HelpSearchQuery instead of an EF entity, limiting fields and preventing over-posting.
    // When a caller is signed in, role context comes from JWT claims; anonymous callers supply no identity.
    // The thin controller delegates business rules and persistence to _help.SearchAsync; failures use
    // existing HTTP handling.
    public Task<HelpSearchResultDto> Search(
        [FromQuery] HelpSearchQuery criteria,
        CancellationToken cancellationToken) =>
        _help.SearchAsync(
            criteria,
            Role(),
            User.Identity?.IsAuthenticated == true,
            cancellationToken);

    [HttpGet("topics/{slug}")]
    // HTTP GET at "topics/{slug}" returns the authoritative help projection needed by the client.
    // This endpoint is deliberately anonymous so published help remains available before sign-in.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // When a caller is signed in, role context comes from JWT claims; anonymous callers supply no identity.
    // The thin controller delegates business rules and persistence to _help.TopicAsync; failures use existing
    // HTTP handling.
    public async Task<IActionResult> Topic(
        string slug,
        CancellationToken cancellationToken)
    {
        try
        {
            return Ok(await _help.TopicAsync(
                slug,
                Role(),
                User.Identity?.IsAuthenticated == true,
                cancellationToken));
        }
        catch (KeyNotFoundException exception)
        {
            return NotFound(new { message = exception.Message });
        }
    }

    [HttpGet("context")]
    // HTTP GET at "context" returns the authoritative help projection needed by the client.
    // This endpoint is deliberately anonymous so contextual help remains available before sign-in.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // When a caller is signed in, role context comes from JWT claims; anonymous callers supply no identity.
    // The thin controller delegates business rules and persistence to _help.ResolveContextAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Context(
        [FromQuery] string route,
        [FromQuery] string? componentKey,
        CancellationToken cancellationToken)
    {
        try
        {
            return Ok(await _help.ResolveContextAsync(
                route,
                componentKey,
                Role(),
                User.Identity?.IsAuthenticated == true,
                cancellationToken));
        }
        catch (KeyNotFoundException exception)
        {
            return NotFound(new { message = exception.Message });
        }
    }

    [HttpGet("user-guide.pdf")]
    // HTTP GET at "user-guide.pdf" generates or streams the help PDF from authoritative data.
    // This endpoint is deliberately anonymous so the published guide remains available before sign-in.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // For signed-in callers, role and generator email come from JWT claims rather than request values.
    // The thin controller delegates business rules and persistence to _help.PdfAsync; failures use existing
    // HTTP handling.
    public async Task<IActionResult> Pdf(CancellationToken cancellationToken)
    {
        var generatedBy = User.Identity?.IsAuthenticated == true
            ? User.FindFirstValue(ClaimTypes.Email) ?? "PhenyoSync user"
            : "Public Help visitor";
        var bytes = await _help.PdfAsync(
            Role(),
            User.Identity?.IsAuthenticated == true,
            generatedBy,
            cancellationToken);
        return File(
            bytes,
            "application/pdf",
            $"PhenyoSync-User-Guide-{DateTime.UtcNow:yyyyMMdd}.pdf");
    }

    [HttpGet("media")]
    // HTTP GET at "media" returns the authoritative help projection needed by the client.
    // This endpoint is deliberately anonymous so published help media remains available before sign-in.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // When a caller is signed in, role context comes from JWT claims; anonymous callers supply no identity.
    // The thin controller delegates business rules and persistence to _media.ListAsync; failures use existing
    // HTTP handling.
    public Task<IReadOnlyList<HelpMediaDto>> Media(
        CancellationToken cancellationToken) =>
        _media.ListAsync(
            false,
            Role(),
            User.Identity?.IsAuthenticated == true,
            cancellationToken);

    [HttpGet("media/{id:long}/stream")]
    // HTTP GET at "media/{id:long}/stream" returns the authoritative help projection needed by the client.
    // This endpoint is deliberately anonymous so published help media remains available before sign-in.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // When a caller is signed in, role context comes from JWT claims; anonymous callers supply no identity.
    // The thin controller delegates business rules and persistence to _media.OpenAsync; failures use existing
    // HTTP handling.
    public async Task<IActionResult> Stream(
        long id,
        CancellationToken cancellationToken)
    {
        try
        {
            var result = await _media.OpenAsync(
                id,
                false,
                Role(),
                User.Identity?.IsAuthenticated == true,
                cancellationToken);
            return File(
                result.Stream,
                result.StoredFile.ContentType,
                enableRangeProcessing: true);
        }
        catch (KeyNotFoundException exception)
        {
            return NotFound(new { message = exception.Message });
        }
        catch (UnauthorizedAccessException exception)
        {
            return StatusCode(403, new { message = exception.Message });
        }
    }

    [HttpGet("media/{id:long}/captions")]
    // HTTP GET at "media/{id:long}/captions" returns the authoritative help projection needed by the client.
    // This endpoint is deliberately anonymous so published captions remain available before sign-in.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // When a caller is signed in, role context comes from JWT claims; anonymous callers supply no identity.
    // The thin controller delegates business rules and persistence to _media.OpenAsync; failures use existing
    // HTTP handling.
    public async Task<IActionResult> Captions(
        long id,
        CancellationToken cancellationToken)
    {
        try
        {
            var result = await _media.OpenAsync(
                id,
                true,
                Role(),
                User.Identity?.IsAuthenticated == true,
                cancellationToken);
            return File(result.Stream, "text/vtt");
        }
        catch (KeyNotFoundException exception)
        {
            return NotFound(new { message = exception.Message });
        }
        catch (UnauthorizedAccessException exception)
        {
            return StatusCode(403, new { message = exception.Message });
        }
    }

    private string? Role() =>
        User.Identity?.IsAuthenticated == true
            ? User.FindFirstValue(ClaimTypes.Role)
            : null;
}
