using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.DTOs.Legacy;
using PhenyoSyncAPI.Entities;
using PhenyoSyncAPI.Security;

namespace PhenyoSyncAPI.Controllers;

[ApiController]
[Route("api/drivers")]
[Authorize]
/// <summary>Returns active Driver records used by delivery assignment workflows.</summary>
public sealed class DriverController : ControllerBase
{
    private readonly PhenyoSyncDbContext _context;

    public DriverController(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    [HasPermission(Permissions.Deliveries.AssignDriver)]
    // HTTP POST at the controller root creates or attaches driver data through the controlled API boundary.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Accepts CreateDriverRequest instead of an EF entity, limiting fields and preventing over-posting.
    // The thin controller delegates business rules and persistence to _context.SaveChangesAsync; failures use
    // existing HTTP handling.
    public async Task<IActionResult> Create(
        [FromBody] CreateDriverRequest request,
        CancellationToken cancellationToken)
    {
        var user = await _context.Users
            .Include(item => item.Role)
            .SingleOrDefaultAsync(
                item => item.UserId == request.UserId,
                cancellationToken);
        if (user is null ||
            user.Role?.RoleCode != RoleCodes.Driver ||
            user.Status != "Active")
        {
            return BadRequest(new
            {
                message = "Select an active user with the Driver role."
            });
        }

        if (await _context.Drivers.AnyAsync(
                item => item.UserId == request.UserId,
                cancellationToken))
        {
            return Conflict(new
            {
                message = "This user already has a driver profile."
            });
        }

        var driver = new Driver
        {
            UserId = request.UserId,
            LicenseNumber = request.LicenseNumber.Trim(),
            VehicleAssigned = string.IsNullOrWhiteSpace(request.VehicleAssigned)
                ? null
                : request.VehicleAssigned.Trim(),
            AvailabilityStatus = request.AvailabilityStatus
        };
        _context.Drivers.Add(driver);
        await _context.SaveChangesAsync(cancellationToken);

        return StatusCode(
            StatusCodes.Status201Created,
            new
            {
                message = "The driver profile was created.",
                code = "DRIVER_CREATED",
                driverId = driver.DriverId
            });
    }

    [HttpGet("jobs")]
    [HasPermission(Permissions.Deliveries.ViewOwn)]
    // HTTP GET at "jobs" handles the get driver jobs operation for driver through the established workflow.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // This compatibility action returns the canonical My Deliveries route; it does not query or mutate jobs.
    public IActionResult GetDriverJobs() =>
        Ok(new
        {
            message = "Use My Deliveries to view assigned delivery work.",
            route = "/api/deliveries/my"
        });

    [HttpGet]
    [HasPermission(Permissions.Deliveries.AssignDriver)]
    // HTTP GET at the controller root returns the authoritative driver projection needed by the client.
    // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
    // Only route or query values cross this boundary; domain validation remains server-side.
    // EF queries are projected to response data rather than exposing tracked entities.
    public async Task<IActionResult> GetAll(
        CancellationToken cancellationToken) =>
        Ok(await _context.Drivers
            .AsNoTracking()
            .Include(item => item.User)
            .OrderBy(item => item.User.FirstName)
            .Select(item => new
            {
                item.DriverId,
                item.LicenseNumber,
                item.VehicleAssigned,
                item.AvailabilityStatus,
                item.UserId,
                item.User.FirstName,
                item.User.LastName
            })
            .ToListAsync(cancellationToken));
}
