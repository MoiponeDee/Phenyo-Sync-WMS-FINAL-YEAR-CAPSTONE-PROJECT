﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Security;

// Provides the deliberately minimal authenticated probe used by environment checks.
namespace PhenyoSyncAPI.Controllers
{
    [ApiController]
    [Route("api/test")]
    [HasPermission(Permissions.AuditLogs.View)]
    public class TestController : Controller
    {
        private readonly PhenyoSyncDbContext _context;
        public TestController(PhenyoSyncDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        // HTTP GET at the controller root provides a permission-protected database health probe for diagnostics.
        // Backend authorization is the real security boundary; hidden Angular or Ionic controls are UX only.
        // Only route or query values cross this boundary; domain validation remains server-side.
        // EF queries are projected to response data rather than exposing tracked entities.
        public IActionResult TestDb()
        {
            var users = _context.Users.ToList();
            return Ok(users);
        }
    }
}
