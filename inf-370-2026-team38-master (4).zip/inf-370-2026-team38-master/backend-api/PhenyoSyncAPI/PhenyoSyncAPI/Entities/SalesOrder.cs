using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities;

// SalesOrder keeps commercial snapshots, lifecycle history, reservations and packing scans together.

public class SalesOrder
{
    [Key]
    public int SalesOrderId { get; set; }

    [Required, MaxLength(30)]
    public string OrderNumber { get; set; } = string.Empty;

    public int CustomerId { get; set; }
    public DateTime OrderDateUtc { get; set; }
    public DateTime? RequestedDeliveryDateUtc { get; set; }

    [Required, MaxLength(500)]
    public string DeliveryAddressSnapshot { get; set; } = string.Empty;

    [Required, MaxLength(500)]
    public string BillingAddressSnapshot { get; set; } = string.Empty;

    [Required, MaxLength(30)]
    public string Status { get; set; } = SalesOrderStatuses.Submitted;

    [Required, MaxLength(20)]
    public string ValidationStatus { get; set; } = OrderValidationStatuses.Pending;

    [MaxLength(1000)]
    public string? ValidationMessage { get; set; }

    public decimal Subtotal { get; set; }
    public decimal? TaxRatePercent { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public int? CreatedByUserId { get; set; }
    public long? CreatedViaOrderLinkId { get; set; }
    public int? ValidatedByUserId { get; set; }
    public DateTime? ValidatedAtUtc { get; set; }
    public int? PackedByUserId { get; set; }
    public DateTime? PackedAtUtc { get; set; }

    [MaxLength(64)]
    public string? PackingCompletionOperationKeyHash { get; set; }

    public int? CancelledByUserId { get; set; }
    public DateTime? CancelledAtUtc { get; set; }

    [MaxLength(500)]
    public string? CancellationReason { get; set; }

    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public Customer Customer { get; set; } = null!;
    public User? CreatedByUser { get; set; }
    public User? ValidatedByUser { get; set; }
    public User? PackedByUser { get; set; }
    public User? CancelledByUser { get; set; }
    public CustomerOrderLink? CreatedViaOrderLink { get; set; }
    public Invoice? Invoice { get; set; }
    public Delivery? Delivery { get; set; }
    public ICollection<SalesOrderItem> Items { get; set; } = new List<SalesOrderItem>();
    public ICollection<OrderStatusHistory> StatusHistory { get; set; } = new List<OrderStatusHistory>();
    public ICollection<OrderStockReservation> StockReservations { get; set; } = new List<OrderStockReservation>();
    public ICollection<StockMovement> StockMovements { get; set; } = new List<StockMovement>();
    public ICollection<PackingScan> PackingScans { get; set; } = new List<PackingScan>();
}
