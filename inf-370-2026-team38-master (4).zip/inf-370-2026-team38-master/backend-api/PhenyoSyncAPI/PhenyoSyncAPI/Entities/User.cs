﻿using System.ComponentModel.DataAnnotations;
namespace PhenyoSyncAPI.Entities
{
    public class User
    {

        [Key]
        public int UserId { get; set; }

        [Required, MaxLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string NormalizedEmail { get; set; } = string.Empty;

        [Required]
        public string PasswordHash { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string LastName { get; set; } = string.Empty;

        [MaxLength(20)]
        public string? PhoneNumber { get; set; }

        public int RoleId { get; set; }

        [Required, MaxLength(20)]
        public string Status { get; set; } = "Active";

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime? UpdatedAtUtc { get; set; }
        public int SecurityVersion { get; set; } = 1;

        public bool RequireTwoFactorOnNextWebLogin { get; set; }

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        [MaxLength(256)]
        public string? PasswordResetTokenHash { get; set; }

        public DateTime? PasswordResetTokenExpiry { get; set; }
        // Navigation
        public Role? Role { get; set; }
        public Driver? Driver { get; set; }
        public ICollection<StockTakeSession> StockTakeSessions { get; set; }
            = new List<StockTakeSession>();

        public ICollection<StockMovement> CreatedStockMovements { get; set; }
            = new List<StockMovement>();

        public ICollection<ProductBatch> ExtendedProductBatches { get; set; }
            = new List<ProductBatch>();
    }
}
