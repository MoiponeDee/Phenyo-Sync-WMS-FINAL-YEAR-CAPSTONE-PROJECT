namespace PhenyoSyncAPI.Entities;

// Centralizes persisted order-state codes used across all workflow transitions.
public static class CustomerStatuses
{
    public const string Active = "Active";
    public const string Inactive = "Inactive";
}

public static class SalesOrderStatuses
{
    // Compatibility value retained for legitimate orders created before the
    // workflow was standardised on Submitted. New writes must use Submitted.
    public const string LegacyPendingValidation = "PendingValidation";
    public const string Submitted = "Submitted";
    public const string Approved = "Approved";
    public const string Confirmed = "Confirmed";
    public const string Packing = "Packing";
    public const string Packed = "Packed";
    public const string ReadyForDispatch = "ReadyForDispatch";
    public const string OutForDelivery = "OutForDelivery";
    public const string Delivered = "Delivered";
    public const string Rejected = "Rejected";
    public const string Cancelled = "Cancelled";

    public static readonly IReadOnlySet<string> All = new HashSet<string>(StringComparer.Ordinal)
    {
        Submitted, Approved, Confirmed, Packing, Packed, ReadyForDispatch,
        OutForDelivery, Delivered, Rejected, Cancelled
    };

    public static bool IsPendingCommercialDecision(string? status) =>
        string.Equals(status, Submitted, StringComparison.Ordinal) ||
        string.Equals(status, LegacyPendingValidation, StringComparison.Ordinal);

    public static string Normalize(string status) =>
        IsPendingCommercialDecision(status) ? Submitted : status;
}

public static class OrderValidationStatuses
{
    public const string Pending = "Pending";
    public const string Approved = "Approved";
    public const string Rejected = "Rejected";
}

public static class OrderReservationStatuses
{
    public const string Active = "Active";
    public const string Released = "Released";
    public const string Consumed = "Consumed";
}

public static class InvoiceStatuses
{
    public const string Issued = "Issued";
    public const string Cancelled = "Cancelled";
}
