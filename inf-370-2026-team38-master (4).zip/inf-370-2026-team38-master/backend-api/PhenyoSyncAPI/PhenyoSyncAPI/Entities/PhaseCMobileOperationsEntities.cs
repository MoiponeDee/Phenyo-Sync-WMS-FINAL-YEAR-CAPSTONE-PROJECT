using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities;

// Mobile entities retain operation hashes, evidence and actor links for retry safety and traceability.

public static class MobileOperationStatuses
{
    public const string Draft = "Draft";
    public const string PendingApproval = "PendingApproval";
    public const string Completed = "Completed";
    public const string Rejected = "Rejected";
    public const string Cancelled = "Cancelled";
}

public static class BuyingListStatuses
{
    public const string Draft = "Draft";
    public const string Open = "Open";
    public const string InProgress = "InProgress";
    public const string Submitted = "Submitted";
    public const string PartiallyReceived = "PartiallyReceived";
    public const string Completed = "Completed";
    public const string Cancelled = "Cancelled";

    public static IReadOnlySet<string> All { get; } =
        new HashSet<string>(
            [
                Draft,
                Open,
                InProgress,
                Submitted,
                PartiallyReceived,
                Completed,
                Cancelled
            ],
            StringComparer.OrdinalIgnoreCase);

    public static IReadOnlySet<string> BuyerVisible { get; } =
        new HashSet<string>(
            [Open, InProgress, Submitted, PartiallyReceived, Completed],
            StringComparer.OrdinalIgnoreCase);

    public static IReadOnlySet<string> Receivable { get; } =
        new HashSet<string>(
            [Submitted, PartiallyReceived],
            StringComparer.OrdinalIgnoreCase);
}

public static class BuyingListPriorities
{
    public const string Standard = "Standard";
    public const string Urgent = "Urgent";
    public const string Critical = "Critical";

    public static IReadOnlySet<string> All { get; } =
        new HashSet<string>(
            [Standard, Urgent, Critical],
            StringComparer.OrdinalIgnoreCase);
}

public static class BuyingItemStatuses
{
    public const string Pending = "Pending";
    public const string Purchased = "Purchased";
    public const string Unavailable = "Unavailable";
    public const string Substituted = "Substituted";
    public const string Cancelled = "Cancelled";

    public static IReadOnlySet<string> All { get; } =
        new HashSet<string>(
            [Pending, Purchased, Unavailable, Substituted, Cancelled],
            StringComparer.OrdinalIgnoreCase);
}

public static class NotificationDeliveryStatuses
{
    public const string Pending = "Pending";
    public const string Processing = "Processing";
    public const string Sent = "Sent";
    public const string Failed = "Failed";
    public const string Disabled = "Disabled";
}

public static class TrackingSessionStatuses
{
    public const string Active = "Active";
    public const string Completed = "Completed";
    public const string Stopped = "Stopped";
}

public static class WriteOffStatuses
{
    public const string Draft = MobileOperationStatuses.Draft;
    public const string PendingApproval = MobileOperationStatuses.PendingApproval;
    public const string Completed = MobileOperationStatuses.Completed;
    public const string Rejected = MobileOperationStatuses.Rejected;
}

public sealed class MobileDeviceRegistration
{
    public long MobileDeviceRegistrationId { get; set; }
    public int UserId { get; set; }

    [Required, MaxLength(64)]
    public string DeviceIdentifierHash { get; set; } = string.Empty;

    [Required, MaxLength(30)]
    public string Platform { get; set; } = "Android";

    [MaxLength(120)]
    public string? DeviceName { get; set; }

    [MaxLength(40)]
    public string? AppVersion { get; set; }

    [MaxLength(2048)]
    public string? PushToken { get; set; }

    public DateTime RegisteredAtUtc { get; set; }
    public DateTime LastSeenAtUtc { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? RevokedAtUtc { get; set; }
    public int? RevokedByUserId { get; set; }

    [MaxLength(300)]
    public string? RevocationReason { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public User User { get; set; } = null!;
    public User? RevokedByUser { get; set; }
}

public sealed class OperationalNotification
{
    public long OperationalNotificationId { get; set; }

    [Required, MaxLength(80)]
    public string NotificationType { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string Severity { get; set; } = "Info";

    [Required, MaxLength(180)]
    public string Title { get; set; } = string.Empty;

    [Required, MaxLength(1000)]
    public string Message { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? EntityType { get; set; }

    [MaxLength(100)]
    public string? EntityId { get; set; }

    [MaxLength(300)]
    public string? ActionRoute { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    public int? CreatedByUserId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? ExpiresAtUtc { get; set; }

    public User? CreatedByUser { get; set; }
    public ICollection<OperationalNotificationRecipient> Recipients { get; set; } =
        new List<OperationalNotificationRecipient>();
}

public sealed class OperationalNotificationRecipient
{
    public long OperationalNotificationRecipientId { get; set; }
    public long OperationalNotificationId { get; set; }
    public int UserId { get; set; }
    public DateTime? ReadAtUtc { get; set; }
    public DateTime? DismissedAtUtc { get; set; }
    public DateTime? PushSentAtUtc { get; set; }
    public DateTime? EmailSentAtUtc { get; set; }

    [Required, MaxLength(20)]
    public string PushStatus { get; set; } =
        NotificationDeliveryStatuses.Pending;

    public int PushAttemptCount { get; set; }
    public DateTime? NextPushAttemptAtUtc { get; set; }

    [MaxLength(80)]
    public string? SafePushErrorCode { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public OperationalNotification Notification { get; set; } = null!;
    public User User { get; set; } = null!;
    public ICollection<NotificationDeliveryAttempt> DeliveryAttempts { get; set; } =
        new List<NotificationDeliveryAttempt>();
}

public sealed class NotificationDeliveryAttempt
{
    public long NotificationDeliveryAttemptId { get; set; }
    public long OperationalNotificationRecipientId { get; set; }

    [Required, MaxLength(20)]
    public string Channel { get; set; } = "Push";

    [Required, MaxLength(40)]
    public string Provider { get; set; } = "Firebase";

    [Required, MaxLength(20)]
    public string Status { get; set; } = NotificationDeliveryStatuses.Pending;

    public int AttemptNumber { get; set; }
    public DateTime AttemptedAtUtc { get; set; }
    public DateTime? CompletedAtUtc { get; set; }

    [MaxLength(80)]
    public string? SafeErrorCode { get; set; }

    public OperationalNotificationRecipient Recipient { get; set; } = null!;
}

public sealed class NotificationPreference
{
    public long NotificationPreferenceId { get; set; }
    public int UserId { get; set; }
    public bool PushEnabled { get; set; } = true;
    public bool EmailFallbackEnabled { get; set; }
    public bool CriticalAlertsEnabled { get; set; } = true;

    [MaxLength(5)]
    public string? QuietHoursStart { get; set; }

    [MaxLength(5)]
    public string? QuietHoursEnd { get; set; }

    public DateTime UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public User User { get; set; } = null!;
}

public sealed class MobileDeliveryEvent
{
    public long MobileDeliveryEventId { get; set; }
    public int DeliveryId { get; set; }
    public int RecordedByUserId { get; set; }

    [Required, MaxLength(40)]
    public string EventType { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public DateTime RecordedAtUtc { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    public Delivery Delivery { get; set; } = null!;
    public User RecordedByUser { get; set; } = null!;
}

public sealed class DriverTrackingSession
{
    public long DriverTrackingSessionId { get; set; }
    public int DeliveryId { get; set; }
    public int DriverId { get; set; }
    public int StartedByUserId { get; set; }
    public DateTime StartedAtUtc { get; set; }
    public DateTime ConsentConfirmedAtUtc { get; set; }
    public DateTime? EndedAtUtc { get; set; }

    [Required, MaxLength(20)]
    public string Status { get; set; } = TrackingSessionStatuses.Active;

    [MaxLength(300)]
    public string? EndedReason { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public Delivery Delivery { get; set; } = null!;
    public Driver Driver { get; set; } = null!;
    public User StartedByUser { get; set; } = null!;
    public ICollection<DriverLocationUpdate> Locations { get; set; } =
        new List<DriverLocationUpdate>();
}

public sealed class DriverLocationUpdate
{
    public long DriverLocationUpdateId { get; set; }
    public long DriverTrackingSessionId { get; set; }
    public decimal Latitude { get; set; }
    public decimal Longitude { get; set; }
    public decimal AccuracyMetres { get; set; }
    public decimal? SpeedMetresPerSecond { get; set; }
    public decimal? HeadingDegrees { get; set; }
    public DateTime CapturedAtUtc { get; set; }
    public DateTime ReceivedAtUtc { get; set; }

    [Required, MaxLength(20)]
    public string Source { get; set; } = "Capacitor";

    [Required, MaxLength(64)]
    public string OperationKeyHash { get; set; } = string.Empty;

    public DriverTrackingSession TrackingSession { get; set; } = null!;
}

public sealed class DeliveryRouteCalculation
{
    public long DeliveryRouteCalculationId { get; set; }
    public int DeliveryId { get; set; }
    public decimal OriginLatitude { get; set; }
    public decimal OriginLongitude { get; set; }
    public decimal DestinationLatitude { get; set; }
    public decimal DestinationLongitude { get; set; }
    public long DistanceMetres { get; set; }
    public int DurationSeconds { get; set; }
    public int? TrafficDurationSeconds { get; set; }

    [MaxLength(16000)]
    public string? EncodedPolyline { get; set; }

    [Required, MaxLength(40)]
    public string Provider { get; set; } = "GoogleRoutes";

    [Required, MaxLength(64)]
    public string RequestFingerprint { get; set; } = string.Empty;

    public DateTime CalculatedAtUtc { get; set; }
    public DateTime ExpiresAtUtc { get; set; }

    public Delivery Delivery { get; set; } = null!;
}

public sealed class MobileIdempotencyRecord
{
    public long MobileIdempotencyRecordId { get; set; }
    public int UserId { get; set; }

    [Required, MaxLength(80)]
    public string OperationType { get; set; } = string.Empty;

    [Required, MaxLength(64)]
    public string OperationKeyHash { get; set; } = string.Empty;

    [Required, MaxLength(64)]
    public string RequestHash { get; set; } = string.Empty;

    [Required]
    public string ResponseJson { get; set; } = string.Empty;

    public DateTime CreatedAtUtc { get; set; }
    public DateTime ExpiresAtUtc { get; set; }

    public User User { get; set; } = null!;
}

public sealed class BuyerProcurement
{
    public int BuyerProcurementId { get; set; }
    public DateTime BuyingDateUtc { get; set; }
    public int? AssignedBuyerUserId { get; set; }

    [Required, MaxLength(40)]
    public string ReferenceNumber { get; set; } = string.Empty;

    [MaxLength(160)]
    public string? Title { get; set; }

    [Required, MaxLength(20)]
    public string Priority { get; set; } = BuyingListPriorities.Standard;

    [Required, MaxLength(30)]
    public string Status { get; set; } = BuyingListStatuses.Draft;

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public long? DocketStoredFileId { get; set; }
    public int? CreatedByUserId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime UpdatedAtUtc { get; set; }
    public DateTime? PublishedAtUtc { get; set; }
    public DateTime? SubmittedAtUtc { get; set; }
    public DateTime? CancelledAtUtc { get; set; }
    public int? CancelledByUserId { get; set; }

    [MaxLength(500)]
    public string? CancellationReason { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public User? AssignedBuyerUser { get; set; }
    public User? CreatedByUser { get; set; }
    public User? CancelledByUser { get; set; }
    public StoredFile? DocketStoredFile { get; set; }
    public ICollection<BuyerProcurementItem> Items { get; set; } =
        new List<BuyerProcurementItem>();
    public ICollection<RawStockReceipt> RawStockReceipts { get; set; } =
        new List<RawStockReceipt>();
}

public sealed class BuyerProcurementItem
{
    public int BuyerProcurementItemId { get; set; }
    public int BuyerProcurementId { get; set; }
    public int? ProductId { get; set; }
    public int? RawStockItemId { get; set; }
    public int? SupplierId { get; set; }
    public int? PreferredSupplierId { get; set; }
    public int? SubstituteRawStockItemId { get; set; }
    public decimal RecommendedQuantity { get; set; }
    public decimal RequiredQuantity { get; set; }
    public decimal? ActualQuantity { get; set; }
    public decimal? ActualUnitPrice { get; set; }
    public decimal ReceivedQuantity { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = "kg";

    [Required, MaxLength(30)]
    public string Status { get; set; } = BuyingItemStatuses.Pending;

    public bool IsPromotionalItem { get; set; }

    [MaxLength(1000)]
    public string? ManagementNotes { get; set; }

    [MaxLength(1000)]
    public string? BuyerNotes { get; set; }

    [MaxLength(500)]
    public string? UnavailableReason { get; set; }

    [MaxLength(500)]
    public string? SubstituteNotes { get; set; }

    [Required, MaxLength(20)]
    public string Priority { get; set; } = BuyingListPriorities.Standard;

    public DateTime UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public BuyerProcurement BuyerProcurement { get; set; } = null!;
    public Product? Product { get; set; }
    public RawStockItem? RawStockItem { get; set; }
    public Supplier? Supplier { get; set; }
    public Supplier? PreferredSupplier { get; set; }
    public RawStockItem? SubstituteRawStockItem { get; set; }
}

public sealed class StockReceipt
{
    public int StockReceiptId { get; set; }
    public int SupplierId { get; set; }
    public int? SupplierOrderId { get; set; }
    public int WarehouseSectionId { get; set; }
    public int ReceivedByUserId { get; set; }

    [Required, MaxLength(80)]
    public string ReceiptNumber { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? SupplierDocketNumber { get; set; }

    public DateTime PurchaseDateUtc { get; set; }

    [Required, MaxLength(30)]
    public string Status { get; set; } = MobileOperationStatuses.Draft;

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public long? DocketStoredFileId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? SubmittedAtUtc { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public Supplier Supplier { get; set; } = null!;
    public SupplierOrder? SupplierOrder { get; set; }
    public WarehouseSection WarehouseSection { get; set; } = null!;
    public User ReceivedByUser { get; set; } = null!;
    public StoredFile? DocketStoredFile { get; set; }
    public ICollection<StockReceiptItem> Items { get; set; } =
        new List<StockReceiptItem>();
}

public sealed class StockReceiptItem
{
    public int StockReceiptItemId { get; set; }
    public int StockReceiptId { get; set; }
    public int ProductId { get; set; }
    public int? ProductBatchId { get; set; }
    public decimal QuantityReceivedKg { get; set; }
    public decimal AcceptedQuantityKg { get; set; }
    public decimal RejectedQuantityKg { get; set; }
    public decimal? UnitCost { get; set; }
    public int? ContainerCount { get; set; }

    [MaxLength(30)]
    public string? ContainerType { get; set; }

    [MaxLength(80)]
    public string? BatchReference { get; set; }

    public DateTime ReceivedAtUtc { get; set; }
    public DateTime BestBeforeAtUtc { get; set; }

    [Required, MaxLength(30)]
    public string QualityStatus { get; set; } = "Accepted";

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public StockReceipt StockReceipt { get; set; } = null!;
    public Product Product { get; set; } = null!;
    public ProductBatch? ProductBatch { get; set; }
}

public sealed class PackingScan
{
    public long PackingScanId { get; set; }
    public int SalesOrderId { get; set; }
    public int SalesOrderItemId { get; set; }
    public long OrderStockReservationId { get; set; }
    public int ProductBatchId { get; set; }
    public int ScannedByUserId { get; set; }
    public decimal QuantityPackedKg { get; set; }
    public DateTime ScannedAtUtc { get; set; }
    public DateTime? RemovedAtUtc { get; set; }
    public int? RemovedByUserId { get; set; }

    [MaxLength(500)]
    public string? RemovalReason { get; set; }

    [Required, MaxLength(64)]
    public string OperationKeyHash { get; set; } = string.Empty;

    public SalesOrder SalesOrder { get; set; } = null!;
    public SalesOrderItem SalesOrderItem { get; set; } = null!;
    public OrderStockReservation Reservation { get; set; } = null!;
    public ProductBatch ProductBatch { get; set; } = null!;
    public User ScannedByUser { get; set; } = null!;
    public User? RemovedByUser { get; set; }
}

public sealed class StockWriteOff
{
    public long StockWriteOffId { get; set; }
    public int ProductBatchId { get; set; }
    public int SectionId { get; set; }
    public int SubmittedByUserId { get; set; }
    public int? DecidedByUserId { get; set; }
    public decimal QuantityKg { get; set; }
    public decimal? EstimatedUnitCost { get; set; }
    public decimal? EstimatedTotalLoss { get; set; }

    [Required, MaxLength(80)]
    public string ReasonCode { get; set; } = string.Empty;

    [MaxLength(120)]
    public string? Condition { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [Required, MaxLength(30)]
    public string Status { get; set; } = WriteOffStatuses.Draft;

    [MaxLength(1000)]
    public string? DecisionReason { get; set; }

    public DateTime SubmittedAtUtc { get; set; }
    public DateTime? DecidedAtUtc { get; set; }
    public DateTime? CompletedAtUtc { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ProductBatch ProductBatch { get; set; } = null!;
    public WarehouseSection WarehouseSection { get; set; } = null!;
    public User SubmittedByUser { get; set; } = null!;
    public User? DecidedByUser { get; set; }
    public ICollection<StockWriteOffEvidence> Evidence { get; set; } =
        new List<StockWriteOffEvidence>();
}

public sealed class StockWriteOffEvidence
{
    public long StockWriteOffEvidenceId { get; set; }
    public long StockWriteOffId { get; set; }
    public long StoredFileId { get; set; }
    public int UploadedByUserId { get; set; }
    public DateTime UploadedAtUtc { get; set; }

    [MaxLength(300)]
    public string? Caption { get; set; }

    public StockWriteOff StockWriteOff { get; set; } = null!;
    public StoredFile StoredFile { get; set; } = null!;
    public User UploadedByUser { get; set; } = null!;
}
