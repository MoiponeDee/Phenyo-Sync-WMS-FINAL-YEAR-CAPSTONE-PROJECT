using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities;

// Security challenges store hashes rather than reusable plaintext secrets; expiry and consumption
// fields make OTP/reset attempts time-bound and single use.

public sealed class UserOtpChallenge
{
    public long UserOtpChallengeId { get; set; }
    public int UserId { get; set; }

    [Required, MaxLength(64)]
    public string ChallengeTokenHash { get; set; } = string.Empty;

    [Required, MaxLength(256)]
    public string OtpHash { get; set; } = string.Empty;

    [Required, MaxLength(40)]
    public string Purpose { get; set; } = "Login";

    public DateTime CreatedAtUtc { get; set; }
    public DateTime ExpiresAtUtc { get; set; }
    public DateTime LastSentAtUtc { get; set; }
    public int AttemptCount { get; set; }
    public int MaximumAttempts { get; set; }
    public int ResendCount { get; set; }
    public DateTime? ConsumedAtUtc { get; set; }
    public DateTime? RevokedAtUtc { get; set; }

    [MaxLength(160)]
    public string? FailureReason { get; set; }

    [MaxLength(64)]
    public string? IpAddressSummary { get; set; }

    [MaxLength(256)]
    public string? UserAgentSummary { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    public int SecurityVersionSnapshot { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public User User { get; set; } = null!;
}

public sealed class TrustedDevice
{
    public long TrustedDeviceId { get; set; }
    public int UserId { get; set; }

    [Required, MaxLength(64)]
    public string TokenHash { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string DeviceName { get; set; } = string.Empty;

    [MaxLength(256)]
    public string? UserAgentSummary { get; set; }

    public DateTime CreatedAtUtc { get; set; }
    public DateTime LastUsedAtUtc { get; set; }
    public DateTime ExpiresAtUtc { get; set; }
    public DateTime? RevokedAtUtc { get; set; }
    public int? RevokedByUserId { get; set; }

    [MaxLength(300)]
    public string? RevocationReason { get; set; }

    public int SecurityVersionSnapshot { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public User User { get; set; } = null!;
    public User? RevokedByUser { get; set; }
}

public sealed class UserRecoveryCode
{
    public long UserRecoveryCodeId { get; set; }
    public int UserId { get; set; }

    [Required, MaxLength(256)]
    public string CodeHash { get; set; } = string.Empty;

    public int CodeOrder { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UsedAtUtc { get; set; }
    public DateTime? RevokedAtUtc { get; set; }
    public int SecurityVersionSnapshot { get; set; }

    public User User { get; set; } = null!;
}

public sealed class StoredFile
{
    public long StoredFileId { get; set; }

    [Required, MaxLength(40)]
    public string StorageProvider { get; set; } = "LocalProtected";

    [Required, MaxLength(300)]
    public string StorageKey { get; set; } = string.Empty;

    [Required, MaxLength(255)]
    public string OriginalFileName { get; set; } = string.Empty;

    [Required, MaxLength(255)]
    public string SafeDownloadName { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string ContentType { get; set; } = string.Empty;

    [Required, MaxLength(16)]
    public string Extension { get; set; } = string.Empty;

    public long SizeBytes { get; set; }

    [Required, MaxLength(64)]
    public string Sha256Hash { get; set; } = string.Empty;

    public DateTime UploadedAtUtc { get; set; }
    public int UploadedByUserId { get; set; }
    public bool IsDeleted { get; set; }
    public DateTime? DeletedAtUtc { get; set; }
    public int? DeletedByUserId { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public User UploadedByUser { get; set; } = null!;
    public User? DeletedByUser { get; set; }
}

public sealed class DeliveryProofImage
{
    public long DeliveryProofImageId { get; set; }
    public int DeliveryId { get; set; }
    public long StoredFileId { get; set; }
    public long? ThumbnailStoredFileId { get; set; }
    public DateTime UploadedAtUtc { get; set; }
    public int UploadedByUserId { get; set; }
    public int? UploadedByDriverId { get; set; }

    [MaxLength(300)]
    public string? Caption { get; set; }

    public bool IsPrimary { get; set; }
    public DateTime? RemovedAtUtc { get; set; }
    public int? RemovedByUserId { get; set; }

    [MaxLength(500)]
    public string? RemovalReason { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public Delivery Delivery { get; set; } = null!;
    public StoredFile StoredFile { get; set; } = null!;
    public StoredFile? ThumbnailStoredFile { get; set; }
    public User UploadedByUser { get; set; } = null!;
    public Driver? UploadedByDriver { get; set; }
    public User? RemovedByUser { get; set; }
}

public sealed class HelpCategory
{
    public int HelpCategoryId { get; set; }

    [Required, MaxLength(80)]
    public string SystemCode { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string DisplayName { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }

    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ICollection<HelpTopic> Topics { get; set; } = new List<HelpTopic>();
}

public sealed class HelpTopic
{
    public int HelpTopicId { get; set; }
    public int HelpCategoryId { get; set; }

    [Required, MaxLength(160)]
    public string Slug { get; set; } = string.Empty;

    [Required, MaxLength(180)]
    public string Title { get; set; } = string.Empty;

    [Required, MaxLength(600)]
    public string Summary { get; set; } = string.Empty;

    [Required]
    public string BodyContent { get; set; } = string.Empty;

    [MaxLength(800)]
    public string? Keywords { get; set; }

    [MaxLength(500)]
    public string? AudienceRolesCsv { get; set; }

    public bool IsPublic { get; set; }
    public bool IsPublished { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }
    public int? UpdatedByUserId { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public HelpCategory Category { get; set; } = null!;
    public User? UpdatedByUser { get; set; }
    public ICollection<HelpContextMapping> ContextMappings { get; set; } =
        new List<HelpContextMapping>();
    public ICollection<HelpMedia> Media { get; set; } = new List<HelpMedia>();
}

public sealed class HelpContextMapping
{
    public int HelpContextMappingId { get; set; }
    public int HelpTopicId { get; set; }

    [Required, MaxLength(240)]
    public string RoutePattern { get; set; } = string.Empty;

    [MaxLength(120)]
    public string? ComponentKey { get; set; }

    public int Priority { get; set; }
    public bool IsActive { get; set; } = true;

    public HelpTopic HelpTopic { get; set; } = null!;
}

public sealed class HelpMedia
{
    public long HelpMediaId { get; set; }
    public int? HelpTopicId { get; set; }
    public long StoredFileId { get; set; }
    public long? CaptionStoredFileId { get; set; }

    [Required, MaxLength(40)]
    public string MediaType { get; set; } = "TrainingVideo";

    [Required, MaxLength(180)]
    public string Title { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Description { get; set; }

    public string? Transcript { get; set; }
    public bool IsFeatured { get; set; }
    public bool IsPublished { get; set; }
    public int SortOrder { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }
    public int UploadedByUserId { get; set; }
    public DateTime? RemovedAtUtc { get; set; }
    public int? RemovedByUserId { get; set; }

    [MaxLength(500)]
    public string? RemovalReason { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public HelpTopic? HelpTopic { get; set; }
    public StoredFile StoredFile { get; set; } = null!;
    public StoredFile? CaptionStoredFile { get; set; }
    public User UploadedByUser { get; set; } = null!;
    public User? RemovedByUser { get; set; }
}
