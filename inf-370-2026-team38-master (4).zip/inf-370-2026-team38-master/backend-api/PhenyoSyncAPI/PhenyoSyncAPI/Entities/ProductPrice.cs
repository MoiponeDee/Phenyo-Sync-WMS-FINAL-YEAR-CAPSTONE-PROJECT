using System.ComponentModel.DataAnnotations;

// Stores effective-dated prices so orders can snapshot the current value.
namespace PhenyoSyncAPI.Entities;

public sealed class ProductPrice
{
    [Key]
    public int ProductPriceId { get; set; }

    public int ProductId { get; set; }

    public decimal SellingPrice { get; set; }

    [Required, MaxLength(30)]
    public string PriceBasis { get; set; } = ProductPriceBases.PerKilogram;

    public DateTime EffectiveFromUtc { get; set; }

    public DateTime? EffectiveToUtc { get; set; }

    public bool IsCurrent { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime CreatedAtUtc { get; set; }

    public int? CreatedByUserId { get; set; }

    [MaxLength(500)]
    public string? ChangeReason { get; set; }

    public DateTime? DeletedAtUtc { get; set; }

    public int? DeletedByUserId { get; set; }

    [MaxLength(500)]
    public string? DeleteReason { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public Product Product { get; set; } = null!;

    public User? CreatedByUser { get; set; }

    public User? DeletedByUser { get; set; }

    public ICollection<SalesOrderItem> SalesOrderItems { get; set; }
        = new List<SalesOrderItem>();
}

public static class ProductPriceBases
{
    public const string PerKilogram = "PerKilogram";
    public const string PerSellableUnit = "PerSellableUnit";

    public static bool IsValid(string? value) =>
        value is PerKilogram or PerSellableUnit;
}
