using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities;

// Delivery entities preserve assignment and status history instead of overwriting who did what.

public static class DeliveryStatuses
{
    public const string Scheduled = "Scheduled";
    public const string Assigned = "Assigned";
    public const string InTransit = "InTransit";
    public const string Completed = "Completed";
    public const string Cancelled = "Cancelled";

    public static readonly IReadOnlySet<string> All = new HashSet<string>(StringComparer.Ordinal)
    {
        Scheduled, Assigned, InTransit, Completed, Cancelled
    };
}

public sealed class Delivery
{
    [Key]
    public int DeliveryId { get; set; }

    public int SalesOrderId { get; set; }

    [Required, MaxLength(500)]
    public string DeliveryAddressSnapshot { get; set; } = string.Empty;

    public DateTime ScheduledStartUtc { get; set; }
    public DateTime ScheduledEndUtc { get; set; }

    public int? DriverId { get; set; }

    [Required, MaxLength(30)]
    public string Status { get; set; } = DeliveryStatuses.Scheduled;

    public DateTime? AssignedAtUtc { get; set; }
    public int? AssignedByUserId { get; set; }
    public DateTime? StartedAtUtc { get; set; }
    public int? StartedByUserId { get; set; }
    public DateTime? CompletedAtUtc { get; set; }
    public int? CompletedByUserId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public SalesOrder SalesOrder { get; set; } = null!;
    public Driver? Driver { get; set; }
    public User? AssignedByUser { get; set; }
    public User? StartedByUser { get; set; }
    public User? CompletedByUser { get; set; }
    public DeliveryCompletionRecord? CompletionRecord { get; set; }
    public ICollection<DeliveryDriverAssignment> DriverAssignments { get; set; } =
        new List<DeliveryDriverAssignment>();
    public ICollection<DeliveryStatusHistory> StatusHistory { get; set; } =
        new List<DeliveryStatusHistory>();
    public ICollection<DeliveryProofImage> ProofImages { get; set; } =
        new List<DeliveryProofImage>();
}

public sealed class DeliveryDriverAssignment
{
    [Key]
    public long DeliveryDriverAssignmentId { get; set; }
    public int DeliveryId { get; set; }
    public int DriverId { get; set; }
    public DateTime AssignedAtUtc { get; set; }
    public int? AssignedByUserId { get; set; }
    public DateTime? UnassignedAtUtc { get; set; }
    public int? UnassignedByUserId { get; set; }

    [MaxLength(500)]
    public string? AssignmentNotes { get; set; }

    [MaxLength(500)]
    public string? ReassignmentReason { get; set; }

    public bool IsCurrent { get; set; }
    public DateTime CreatedAtUtc { get; set; }

    public Delivery Delivery { get; set; } = null!;
    public Driver Driver { get; set; } = null!;
    public User? AssignedByUser { get; set; }
    public User? UnassignedByUser { get; set; }
}

public sealed class DeliveryStatusHistory
{
    [Key]
    public long DeliveryStatusHistoryId { get; set; }
    public int DeliveryId { get; set; }

    [MaxLength(30)]
    public string? PreviousStatus { get; set; }

    [Required, MaxLength(30)]
    public string NewStatus { get; set; } = string.Empty;

    public DateTime ChangedAtUtc { get; set; }
    public int? ChangedByUserId { get; set; }

    [MaxLength(500)]
    public string? Reason { get; set; }

    [MaxLength(80)]
    public string Source { get; set; } = "DeliveryWorkflow";

    public Delivery Delivery { get; set; } = null!;
    public User? ChangedByUser { get; set; }
}

public sealed class DeliveryCompletionRecord
{
    [Key]
    public long DeliveryCompletionRecordId { get; set; }
    public int DeliveryId { get; set; }
    public DateTime CompletedAtUtc { get; set; }
    public int? CompletedByUserId { get; set; }
    public int? CompletedByDriverId { get; set; }
    public bool CompletedOnBehalfOfDriver { get; set; }

    [MaxLength(500)]
    public string? ManagementOverrideReason { get; set; }

    [Required, MaxLength(200)]
    public string RecipientName { get; set; } = string.Empty;

    public bool RecipientConfirmed { get; set; }
    public bool FulfillmentConfirmed { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [MaxLength(500)]
    public string? ProofReference { get; set; }

    public DateTime CreatedAtUtc { get; set; }

    public Delivery Delivery { get; set; } = null!;
    public User? CompletedByUser { get; set; }
    public Driver? CompletedByDriver { get; set; }
}
