using System.ComponentModel.DataAnnotations;

// Represents stock reserved for an approved order before packing consumes it.
namespace PhenyoSyncAPI.Entities;

public class OrderStockReservation
{
    [Key]
    public long OrderStockReservationId { get; set; }
    public int SalesOrderId { get; set; }
    public int SalesOrderItemId { get; set; }
    public int ProductId { get; set; }
    public int StockId { get; set; }
    public int SectionId { get; set; }
    public int ProductBatchId { get; set; }
    public decimal QuantityReservedKg { get; set; }

    [Required, MaxLength(20)]
    public string Status { get; set; } = OrderReservationStatuses.Active;

    public DateTime ReservedAtUtc { get; set; }
    public DateTime? ReleasedAtUtc { get; set; }
    public DateTime? ConsumedAtUtc { get; set; }

    public SalesOrder SalesOrder { get; set; } = null!;
    public SalesOrderItem SalesOrderItem { get; set; } = null!;
    public Product Product { get; set; } = null!;
    public Stock Stock { get; set; } = null!;
    public WarehouseSection WarehouseSection { get; set; } = null!;
    public ProductBatch ProductBatch { get; set; } = null!;
}
