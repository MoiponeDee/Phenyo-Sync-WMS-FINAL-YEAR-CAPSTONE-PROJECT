﻿using PhenyoSyncAPI.Entities;
using System.ComponentModel.DataAnnotations;

// Joins a product category to its master products in the hierarchy.
namespace PhenyoSyncAPI.Entities
{
    public class ProductType
    {
        [Key]
        public int ProductTypeId { get; set; }

        [Required]
        [StringLength(100)]
        public string ProductTypeName { get; set; } = string.Empty;

        [StringLength(255)]
        public string? Description { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Active";

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        public virtual ICollection<Product> Products { get; set; }
            = new List<Product>();

        public ICollection<ProductCategoryType> ProductCategoryTypes { get; set; }
            = new List<ProductCategoryType>();
    }
}
