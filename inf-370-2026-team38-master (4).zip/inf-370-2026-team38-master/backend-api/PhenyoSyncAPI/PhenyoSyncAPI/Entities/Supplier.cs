﻿using System.ComponentModel.DataAnnotations;

// Stores approved supplier master data used by procurement and receiving.
namespace PhenyoSyncAPI.Entities
{
    public class Supplier
    {
        [Key]
        public int SupplierId { get; set; }

        [Required]
        public string SupplierName { get; set; } = string.Empty;

        [Required, MaxLength(40)]
        public string SupplierCode { get; set; } = string.Empty;

        [Required, MaxLength(40)]
        public string SupplierTypeCode { get; set; } = "GeneralSupplier";

        [MaxLength(150)]
        public string? ContactPerson { get; set; }

        [EmailAddress, MaxLength(254)]
        public string? Email { get; set; }

        [MaxLength(254)]
        public string? NormalizedEmail { get; set; }

        [MaxLength(30)]
        public string? Phone { get; set; }

        [MaxLength(500)]
        public string? Address { get; set; }

        [Required]
        public string Status { get; set; } = "Active";

        public DateTime CreatedAtUtc { get; set; }
        public DateTime? UpdatedAtUtc { get; set; }

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        public ICollection<SupplierOrder> SupplierOrders { get; set; } =
            new List<SupplierOrder>();

        public ICollection<FinancialPayment> Payments { get; set; } =
            new List<FinancialPayment>();
    }
}
