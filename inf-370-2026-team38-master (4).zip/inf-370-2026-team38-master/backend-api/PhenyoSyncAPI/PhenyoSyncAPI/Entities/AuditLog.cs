using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities;

// AuditLog stores bounded snapshots so historical evidence survives later user/entity changes.

public sealed class AuditLog
{
    [Key]
    public long AuditLogId { get; set; }
    public DateTime OccurredAtUtc { get; set; }
    public int? UserId { get; set; }

    [MaxLength(320)]
    public string? UserEmailSnapshot { get; set; }

    [MaxLength(200)]
    public string? UserDisplayNameSnapshot { get; set; }

    [MaxLength(100)]
    public string? UserRoleSnapshot { get; set; }

    [Required, MaxLength(32)]
    public string ActorType { get; set; } = string.Empty;

    [Required, MaxLength(64)]
    public string ActionType { get; set; } = string.Empty;

    [Required, MaxLength(80)]
    public string SystemModule { get; set; } = string.Empty;

    [Required, MaxLength(160)]
    public string OperationName { get; set; } = string.Empty;

    [MaxLength(128)]
    public string? EntityType { get; set; }

    [MaxLength(256)]
    public string? EntityId { get; set; }

    [MaxLength(500)]
    public string? EntityDisplay { get; set; }

    [Required, MaxLength(1000)]
    public string Description { get; set; } = string.Empty;

    public string? BeforeValuesJson { get; set; }
    public string? AfterValuesJson { get; set; }
    public string? ChangedFieldsJson { get; set; }
    public bool Success { get; set; }

    [MaxLength(1000)]
    public string? FailureReason { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [MaxLength(512)]
    public string? RequestPath { get; set; }

    [MaxLength(10)]
    public string? HttpMethod { get; set; }

    [MaxLength(64)]
    public string? IpAddress { get; set; }

    [MaxLength(512)]
    public string? UserAgent { get; set; }

    [Required, MaxLength(64)]
    public string EventSource { get; set; } = string.Empty;
}
