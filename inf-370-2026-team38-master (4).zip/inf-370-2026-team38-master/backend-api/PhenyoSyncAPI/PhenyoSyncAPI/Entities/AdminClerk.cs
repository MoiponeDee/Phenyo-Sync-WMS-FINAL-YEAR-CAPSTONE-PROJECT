﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
// Links the persisted AdminClerk role profile to its application user.
namespace PhenyoSyncAPI.Entities
{
    public class AdminClerk
    {
        [Key]
        public int AdminClerkId { get; set; }

        public int UserId { get; set; }

        public string EmployeeNumber { get; set; } = string.Empty;
        public string AccessLevel { get; set; } = string.Empty;

        public bool IsActive { get; set; } = true;

        public string AssignedCustomerPortfolio { get; set; } = string.Empty;

        public bool CanRecordProcurementInvoices { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; } = null!;
    }
}
