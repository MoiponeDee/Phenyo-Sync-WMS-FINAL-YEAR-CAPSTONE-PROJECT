using System.ComponentModel.DataAnnotations;

// Captures the financial snapshot produced for an order.
namespace PhenyoSyncAPI.Entities;

public class Invoice
{
    [Key]
    public int InvoiceId { get; set; }

    [Required, MaxLength(30)]
    public string InvoiceNumber { get; set; } = string.Empty;

    public int SalesOrderId { get; set; }
    public DateTime IssuedAtUtc { get; set; }

    [Required, MaxLength(150)]
    public string CustomerNameSnapshot { get; set; } = string.Empty;

    [Required, MaxLength(254)]
    public string CustomerEmailSnapshot { get; set; } = string.Empty;

    [Required, MaxLength(500)]
    public string BillingAddressSnapshot { get; set; } = string.Empty;

    public decimal Subtotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }

    [Required, MaxLength(20)]
    public string Status { get; set; } = InvoiceStatuses.Issued;

    public SalesOrder SalesOrder { get; set; } = null!;
}
