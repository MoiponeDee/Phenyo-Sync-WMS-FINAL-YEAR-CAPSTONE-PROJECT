﻿using System.ComponentModel.DataAnnotations;

// Represents procurement commitments used when netting raw-material shortage.
namespace PhenyoSyncAPI.Entities
{
    public class SupplierOrder
    {
        [Key]
        public int SupplierOrderId { get; set; }

        public int SupplierId { get; set; }

        [Required, MaxLength(40)]
        public string OrderNumber { get; set; } = string.Empty;

        public DateTime OrderDate { get; set; } = DateTime.UtcNow;
        public DateTime? ExpectedDeliveryAtUtc { get; set; }
        public int WarehouseSectionId { get; set; }

        public decimal TotalAmount { get; set; }

        [Required, MaxLength(40)]
        public string Status { get; set; } = SupplierOrderStatuses.Draft;

        [MaxLength(1000)]
        public string? Notes { get; set; }

        public int? CreatedByUserId { get; set; }
        public int? ApprovedByUserId { get; set; }
        public DateTime CreatedAtUtc { get; set; }
        public DateTime? ApprovedAtUtc { get; set; }
        public DateTime? CancelledAtUtc { get; set; }

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        public Supplier Supplier { get; set; } = null!;
        public WarehouseSection WarehouseSection { get; set; } = null!;
        public User? CreatedByUser { get; set; }
        public User? ApprovedByUser { get; set; }
        public ICollection<SupplierOrderLine> Lines { get; set; } =
            new List<SupplierOrderLine>();
        public ICollection<FinancialPayment> Payments { get; set; } =
            new List<FinancialPayment>();
    }
}
