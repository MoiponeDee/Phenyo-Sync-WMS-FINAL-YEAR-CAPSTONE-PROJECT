using System.ComponentModel.DataAnnotations;

// Records immutable stock deltas and operation keys for retry-safe inventory.
namespace PhenyoSyncAPI.Entities
{
    public class StockMovement
    {
        [Key]
        public long StockMovementId { get; set; }

        public int ProductId { get; set; }

        public int ProductBatchId { get; set; }

        public int SectionId { get; set; }

        [Required, MaxLength(30)]
        public string MovementType { get; set; } = string.Empty;

        public decimal QuantityKg { get; set; }

        public DateTime OccurredAtUtc { get; set; }

        public int? CreatedByUserId { get; set; }

        public int? SalesOrderId { get; set; }

        public int? StockTakeSessionId { get; set; }

        [MaxLength(500)]
        public string? Reason { get; set; }

        public Product Product { get; set; } = null!;

        public ProductBatch ProductBatch { get; set; } = null!;

        public WarehouseSection WarehouseSection { get; set; } = null!;

        public User? CreatedByUser { get; set; }

        public SalesOrder? SalesOrder { get; set; }

        public StockTakeSession? StockTakeSession { get; set; }
    }
}
