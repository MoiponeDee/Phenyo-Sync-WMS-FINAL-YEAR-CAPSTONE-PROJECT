using System.ComponentModel.DataAnnotations;

// Stores reusable customer identity; orders retain their own contact snapshots.
namespace PhenyoSyncAPI.Entities;

public class Customer
{
    [Key]
    public int CustomerId { get; set; }

    [Required, MaxLength(30)]
    public string CustomerNumber { get; set; } = string.Empty;

    [Required, MaxLength(150)]
    public string CustomerName { get; set; } = string.Empty;

    [Required, EmailAddress, MaxLength(254)]
    public string Email { get; set; } = string.Empty;

    [Required, MaxLength(254)]
    public string NormalizedEmail { get; set; } = string.Empty;

    [MaxLength(150)]
    public string? ContactPerson { get; set; }

    [MaxLength(30)]
    public string? PhoneNumber { get; set; }

    [MaxLength(500)]
    public string? BillingAddress { get; set; }

    [MaxLength(500)]
    public string? DeliveryAddress { get; set; }

    [Required, MaxLength(20)]
    public string Status { get; set; } = CustomerStatuses.Active;

    public DateTime CreatedAtUtc { get; set; }

    public DateTime? UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ICollection<SalesOrder> SalesOrders { get; set; } = new List<SalesOrder>();
    public ICollection<CustomerOrderLink> OrderLinks { get; set; } = new List<CustomerOrderLink>();
    public ICollection<FinancialPayment> Payments { get; set; } =
        new List<FinancialPayment>();
}
