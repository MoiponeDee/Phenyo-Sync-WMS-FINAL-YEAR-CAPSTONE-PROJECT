using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities;

// Configuration entities retain RowVersion/history fields so administrative changes are reviewable.

public sealed class LookupType
{
    public int LookupTypeId { get; set; }

    [Required, MaxLength(80)]
    public string SystemCode { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string DisplayName { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }

    public bool IsSystemType { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ICollection<LookupValue> Values { get; set; } = new List<LookupValue>();
}

public sealed class LookupValue
{
    public int LookupValueId { get; set; }
    public int LookupTypeId { get; set; }

    [Required, MaxLength(80)]
    public string SystemCode { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string DisplayName { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }

    public int SortOrder { get; set; }
    public bool IsSystemValue { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public LookupType LookupType { get; set; } = null!;
    public ICollection<LookupValueHistory> History { get; set; } =
        new List<LookupValueHistory>();
}

public sealed class LookupValueHistory
{
    public long LookupValueHistoryId { get; set; }
    public int LookupValueId { get; set; }

    [Required, MaxLength(40)]
    public string ChangeType { get; set; } = string.Empty;

    public string? BeforeValuesJson { get; set; }
    public string? AfterValuesJson { get; set; }
    public int? ChangedByUserId { get; set; }
    public DateTime ChangedAtUtc { get; set; }

    [Required, MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    public LookupValue LookupValue { get; set; } = null!;
    public User? ChangedByUser { get; set; }
}

public sealed class SystemSetting
{
    public int SystemSettingId { get; set; }

    [Required, MaxLength(150)]
    public string Key { get; set; } = string.Empty;

    [Required, MaxLength(80)]
    public string Category { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string DisplayName { get; set; } = string.Empty;

    [Required, MaxLength(500)]
    public string Description { get; set; } = string.Empty;

    [Required, MaxLength(40)]
    public string ValueType { get; set; } = string.Empty;

    [Required, MaxLength(2000)]
    public string Value { get; set; } = string.Empty;

    [Required, MaxLength(2000)]
    public string DefaultValue { get; set; } = string.Empty;

    [MaxLength(40)]
    public string? Unit { get; set; }

    [MaxLength(100)]
    public string? MinimumValue { get; set; }

    [MaxLength(100)]
    public string? MaximumValue { get; set; }

    public string? AllowedValuesJson { get; set; }
    public bool IsSensitive { get; set; }
    public bool IsSystemSetting { get; set; } = true;
    public bool IsActive { get; set; } = true;
    public bool RequiresRestart { get; set; }
    public DateTime UpdatedAtUtc { get; set; }
    public int? UpdatedByUserId { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public User? UpdatedByUser { get; set; }
    public ICollection<SystemSettingHistory> History { get; set; } =
        new List<SystemSettingHistory>();
}

public sealed class SystemSettingHistory
{
    public long SystemSettingHistoryId { get; set; }
    public int SystemSettingId { get; set; }

    [Required, MaxLength(2000)]
    public string PreviousValue { get; set; } = string.Empty;

    [Required, MaxLength(2000)]
    public string NewValue { get; set; } = string.Empty;

    public DateTime ChangedAtUtc { get; set; }
    public int? ChangedByUserId { get; set; }

    [Required, MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    public bool AppliedSuccessfully { get; set; }

    [MaxLength(500)]
    public string? FailureReason { get; set; }

    public SystemSetting SystemSetting { get; set; } = null!;
    public User? ChangedByUser { get; set; }
}

public static class SystemSettingValueTypes
{
    public const string Integer = "Integer";
    public const string Decimal = "Decimal";
    public const string Boolean = "Boolean";
    public const string String = "String";
    public const string TimeSpanMinutes = "TimeSpanMinutes";
    public const string TimeSpanHours = "TimeSpanHours";
    public const string StringArray = "StringArray";
}
