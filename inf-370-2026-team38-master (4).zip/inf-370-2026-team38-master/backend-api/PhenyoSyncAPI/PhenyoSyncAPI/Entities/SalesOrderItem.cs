using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Snapshots quantity and price so catalogue changes cannot rewrite an order.
namespace PhenyoSyncAPI.Entities;

public class SalesOrderItem
{
    [Key]
    public int SalesOrderItemId { get; set; }
    public int SalesOrderId { get; set; }
    public int ProductId { get; set; }
    public int? ProductPriceId { get; set; }

    [Required, MaxLength(150)]
    public string ProductNameSnapshot { get; set; } = string.Empty;

    [Required, MaxLength(50)]
    public string ProductSizeSnapshot { get; set; } = string.Empty;

    public decimal QuantityKg { get; set; }
    public decimal UnitPricePerKg { get; set; }
    public decimal? QuantityUnits { get; set; }

    [MaxLength(30)]
    public string? SellingUnitSnapshot { get; set; }

    public decimal? KilogramsPerUnitSnapshot { get; set; }
    public decimal? UnitPrice { get; set; }

    [MaxLength(30)]
    public string? PriceBasisSnapshot { get; set; }

    [NotMapped]
    public bool HasKnownFulfilmentWeight =>
        QuantityKg > 0 &&
        (!QuantityUnits.HasValue ||
         KilogramsPerUnitSnapshot.HasValue ||
         string.Equals(SellingUnitSnapshot, "kg", StringComparison.OrdinalIgnoreCase));

    public decimal LineTotal { get; set; }

    public bool IsActive { get; set; } = true;

    [MaxLength(500)]
    public string? Notes { get; set; }

    public SalesOrder SalesOrder { get; set; } = null!;
    public Product Product { get; set; } = null!;
    public ProductPrice? ProductPrice { get; set; }
    public ICollection<OrderStockReservation> StockReservations { get; set; } = new List<OrderStockReservation>();
}
