using System.ComponentModel.DataAnnotations;

// Preserves the immutable timeline of order transitions for audit reporting.
namespace PhenyoSyncAPI.Entities;

public class OrderStatusHistory
{
    [Key]
    public long OrderStatusHistoryId { get; set; }
    public int SalesOrderId { get; set; }

    [MaxLength(30)]
    public string? PreviousStatus { get; set; }

    [Required, MaxLength(30)]
    public string NewStatus { get; set; } = string.Empty;

    public int? ChangedByUserId { get; set; }
    public DateTime ChangedAtUtc { get; set; }

    [MaxLength(500)]
    public string? Reason { get; set; }

    public SalesOrder SalesOrder { get; set; } = null!;
    public User? ChangedByUser { get; set; }
}
