﻿using System.ComponentModel.DataAnnotations;

// Persists stable permission codes independently from friendly role labels.
namespace PhenyoSyncAPI.Entities
{
    public class Permission
    {
        [Key]
        public int PermissionId { get; set; }

        [Required, MaxLength(100)]
        public string PermissionCode { get; set; } = string.Empty;

        [Required, MaxLength(120)]
        public string PermissionName { get; set; } = string.Empty;

        [Required, MaxLength(120)]
        public string DisplayName { get; set; } = string.Empty;

        [Required, MaxLength(80)]
        public string Module { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Description { get; set; }

        public bool IsSystemPermission { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
        public DateTime? UpdatedAtUtc { get; set; }

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        public ICollection<RolePermission> RolePermissions { get; set; } =
            new List<RolePermission>();
    }
}
