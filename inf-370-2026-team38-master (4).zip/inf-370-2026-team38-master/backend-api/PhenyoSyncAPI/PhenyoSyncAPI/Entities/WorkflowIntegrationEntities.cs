using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities;

// Integration entities provide durable idempotency for external rows and raw-to-finished lineage.

public static class ExternalOrderSubmissionStatuses
{
    public const string Processing = "Processing";
    public const string Imported = "Imported";
    public const string NeedsAttention = "NeedsAttention";
    public const string Failed = "Failed";
}

public sealed class ExternalOrderSubmission
{
    public long ExternalOrderSubmissionId { get; set; }

    [Required, MaxLength(40)]
    public string Source { get; set; } = string.Empty;

    [Required, MaxLength(180)]
    public string ExternalSourceKey { get; set; } = string.Empty;

    [Required, MaxLength(64)]
    public string PayloadHash { get; set; } = string.Empty;

    [Required, MaxLength(30)]
    public string Status { get; set; } = ExternalOrderSubmissionStatuses.NeedsAttention;

    [MaxLength(1000)]
    public string? SafeIssueSummary { get; set; }

    public DateTime? SubmittedAtUtc { get; set; }
    public DateTime ImportedAtUtc { get; set; }
    public int? SalesOrderId { get; set; }
    public int ImportedByUserId { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public SalesOrder? SalesOrder { get; set; }
    public User ImportedByUser { get; set; } = null!;
}

public sealed class PackingConversion
{
    public long PackingConversionId { get; set; }
    public int ProductId { get; set; }
    public int ProductBatchId { get; set; }
    public int WarehouseSectionId { get; set; }
    public decimal QuantityProduced { get; set; }
    public int PackedByUserId { get; set; }
    public DateTime PackedAtUtc { get; set; }
    public DateTime CreatedAtUtc { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public Product Product { get; set; } = null!;
    public ProductBatch ProductBatch { get; set; } = null!;
    public WarehouseSection WarehouseSection { get; set; } = null!;
    public User PackedByUser { get; set; } = null!;
    public ICollection<PackingConversionRawStock> RawStockLines { get; set; } =
        new List<PackingConversionRawStock>();
}

public sealed class PackingConversionRawStock
{
    public long PackingConversionRawStockId { get; set; }
    public long PackingConversionId { get; set; }
    public int RawStockItemId { get; set; }
    public int RawStockBalanceId { get; set; }
    public long RawStockBatchId { get; set; }
    public decimal QuantityConsumed { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = string.Empty;

    public decimal BalanceBefore { get; set; }
    public decimal BalanceAfter { get; set; }
    public decimal BatchBefore { get; set; }
    public decimal BatchAfter { get; set; }
    public decimal? UnitCost { get; set; }

    public PackingConversion PackingConversion { get; set; } = null!;
    public RawStockItem RawStockItem { get; set; } = null!;
    public RawStockBalance RawStockBalance { get; set; } = null!;
    public RawStockBatch RawStockBatch { get; set; } = null!;
}
