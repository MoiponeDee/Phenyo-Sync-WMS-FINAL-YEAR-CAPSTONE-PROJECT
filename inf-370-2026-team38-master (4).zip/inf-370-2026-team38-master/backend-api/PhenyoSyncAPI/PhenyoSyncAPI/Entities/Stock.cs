﻿using System.ComponentModel.DataAnnotations;

// Holds aggregate finished stock while batches provide allocation detail.
namespace PhenyoSyncAPI.Entities
{
    public class Stock
    {
        [Key]
        public int StockId { get; set; }

        public int ProductId { get; set; }

        public int SectionId { get; set; }

        public decimal QuantityAvailableKg { get; set; }

        public decimal ReorderLevelKg { get; set; }

        public string InventoryStatus { get; set; } = "Available";

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        public Product Product { get; set; } = null!;

        public WarehouseSection WarehouseSection { get; set; } = null!;

        public ICollection<OrderStockReservation> OrderStockReservations { get; set; }
            = new List<OrderStockReservation>();
    }
}
