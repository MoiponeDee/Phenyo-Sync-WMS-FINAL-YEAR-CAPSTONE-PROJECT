﻿using System.ComponentModel.DataAnnotations;

// Defines a physical location referenced by balances, batches, and movements.
namespace PhenyoSyncAPI.Entities
{
    public class WarehouseSection
    {
        [Key]
        public int SectionId { get; set; }

        [Required, MaxLength(40)]
        public string SectionCode { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string SectionName { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Description { get; set; }

        [Required, MaxLength(20)]
        public string Status { get; set; } = "Active";

        public DateTime CreatedAtUtc { get; set; }
        public DateTime? UpdatedAtUtc { get; set; }

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        public ICollection<Stock> Stocks { get; set; } = new List<Stock>();
        public ICollection<StockTakeSession> StockTakeSessions { get; set; }
            = new List<StockTakeSession>();
        public ICollection<ProductBatch> ProductBatches { get; set; }
            = new List<ProductBatch>();
        public ICollection<StockMovement> StockMovements { get; set; }
            = new List<StockMovement>();
        public ICollection<OrderStockReservation> OrderStockReservations { get; set; }
            = new List<OrderStockReservation>();
    }
}
