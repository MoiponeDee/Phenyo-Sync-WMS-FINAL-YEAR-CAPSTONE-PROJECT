﻿using System.ComponentModel.DataAnnotations;

// Associates a driver profile with the user used for delivery assignment.
namespace PhenyoSyncAPI.Entities
{
    public class Driver
    {

        [Key]
        public int DriverId { get; set; }

        public int UserId { get; set; }

        [Required]
        public string LicenseNumber { get; set; } = string.Empty;

        public DateTime? LicenseExpiryDate { get; set; }

        public string? VehicleAssigned { get; set; }

        [Required]
        public string AvailabilityStatus { get; set; } = string.Empty;

        public User User { get; set; } = null!;
        public ICollection<Delivery> Deliveries { get; set; } = new List<Delivery>();
        public ICollection<DeliveryDriverAssignment> AssignmentHistory { get; set; } =
            new List<DeliveryDriverAssignment>();
        public ICollection<DeliveryCompletionRecord> CompletionRecords { get; set; } =
            new List<DeliveryCompletionRecord>();
    }
}
