﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PhenyoSyncAPI.Entities
{
    // Product is the finished-goods master; type/category links and price history are relational.
    public class Product
    {
        [Key]
        public int ProductId { get; set; }

        [Required]
        [StringLength(150)]
        public string ProductName { get; set; } = string.Empty;

        [Required]
        public int ProductTypeId { get; set; }

        [Required]
        public int ProductCategoryId { get; set; }

        [Required]
        [StringLength(50)]
        public string Size { get; set; } = string.Empty;

        [Required]
        public int ShelfLifeDays { get; set; }

        public decimal SellingPricePerKg { get; set; }

        [Required]
        [StringLength(30)]
        public string SellingUnit { get; set; } = "kg";

        public decimal? KilogramsPerUnit { get; set; }

        public bool IsVariableWeight { get; set; } = true;

        [StringLength(500)]
        public string? QRCodeValue { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Active";

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        [ForeignKey(nameof(ProductTypeId))]
        public virtual ProductType? ProductType { get; set; }

        [ForeignKey(nameof(ProductCategoryId))]
        public virtual ProductCategory? ProductCategory { get; set; }

        public ICollection<ProductBatch> ProductBatches { get; set; }
            = new List<ProductBatch>();

        public ICollection<Stock> Stocks { get; set; }
            = new List<Stock>();

        public ICollection<StockMovement> StockMovements { get; set; }
            = new List<StockMovement>();

        public ICollection<SalesOrderItem> SalesOrderItems { get; set; }
            = new List<SalesOrderItem>();

        public ICollection<OrderStockReservation> OrderStockReservations { get; set; }
            = new List<OrderStockReservation>();

        public ICollection<ProductPrice> ProductPrices { get; set; }
            = new List<ProductPrice>();

        public ICollection<ProductRawStockRequirement> RawStockRequirements
            { get; set; } = new List<ProductRawStockRequirement>();
    }
}
