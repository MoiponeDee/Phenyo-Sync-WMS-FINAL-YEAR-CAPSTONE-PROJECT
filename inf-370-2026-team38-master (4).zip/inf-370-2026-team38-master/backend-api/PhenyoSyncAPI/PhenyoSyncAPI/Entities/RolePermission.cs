﻿namespace PhenyoSyncAPI.Entities
{
    public class RolePermission
    {
        public int RoleId { get; set; }
        public int PermissionId { get; set; }
        public DateTime AssignedAtUtc { get; set; } = DateTime.UtcNow;
        public int? AssignedByUserId { get; set; }

        public Role? Role { get; set; }
        public Permission? Permission { get; set; }
        public User? AssignedByUser { get; set; }
    }
}
