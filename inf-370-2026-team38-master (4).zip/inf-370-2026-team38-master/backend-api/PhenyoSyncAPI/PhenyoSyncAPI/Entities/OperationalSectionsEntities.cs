using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities;

// Operational entities separate master data, documents, balances and append-only movement history.

public static class RawStockCategories
{
    public const string Produce = "Produce";
    public const string Packaging = "Packaging";
    public const string General = "General";

    public static IReadOnlySet<string> All { get; } =
        new HashSet<string>(
            [Produce, Packaging, General],
            StringComparer.OrdinalIgnoreCase);
}

public static class RawStockUnits
{
    public const string Kilogram = "kg";
    public const string Unit = "unit";
    public const string Pack = "pack";
    public const string Roll = "roll";
    public const string Bag = "bag";
    public const string Box = "box";

    public static IReadOnlySet<string> All { get; } =
        new HashSet<string>(
            [Kilogram, Unit, Pack, Roll, Bag, Box],
            StringComparer.OrdinalIgnoreCase);
}

public static class RawStockMovementTypes
{
    public const string OpeningBalance = "OpeningBalance";
    public const string Receipt = "Receipt";
    public const string WriteOff = "WriteOff";
    public const string PositiveAdjustment = "PositiveAdjustment";
    public const string NegativeAdjustment = "NegativeAdjustment";
    public const string ProductionConversion = "ProductionConversion";
}

public static class RawStockReceiptSources
{
    public const string SupplierOrder = "SupplierOrder";
    public const string BuyingList = "BuyingList";
    public const string AdHocSupplier = "AdHocSupplier";

    public static IReadOnlySet<string> All { get; } =
        new HashSet<string>(
            [SupplierOrder, BuyingList, AdHocSupplier],
            StringComparer.OrdinalIgnoreCase);
}

public static class RawStockTakeStatuses
{
    public const string Draft = "Draft";
    public const string Submitted = "Submitted";
    public const string AdministratorReviewed = "AdministratorReviewed";
    public const string PendingManagementApproval = "PendingManagementApproval";
    public const string Approved = "Approved";
    public const string Rejected = "Rejected";
    public const string Closed = "Closed";
}

public static class FinancialPaymentStatuses
{
    public const string Draft = "Draft";
    public const string Posted = "Posted";
    public const string PendingReversalApproval = "PendingReversalApproval";
    public const string Voided = "Voided";
    public const string Reversed = "Reversed";
    public const string Rejected = "Rejected";
}

public static class SupplierOrderStatuses
{
    public const string Draft = "Draft";
    public const string Ordered = "Ordered";
    public const string PartiallyReceived = "PartiallyReceived";
    public const string FullyReceived = "FullyReceived";
    public const string Cancelled = "Cancelled";

    public static IReadOnlySet<string> Receivable { get; } =
        new HashSet<string>(
            [Ordered, PartiallyReceived],
            StringComparer.OrdinalIgnoreCase);
}

public sealed class RawStockItem
{
    public int RawStockItemId { get; set; }

    [Required, MaxLength(40)]
    public string ItemCode { get; set; } = string.Empty;

    [Required, MaxLength(160)]
    public string ItemName { get; set; } = string.Empty;

    [Required, MaxLength(30)]
    public string CategoryCode { get; set; } = RawStockCategories.Produce;

    [Required, MaxLength(20)]
    public string DefaultUnitOfMeasure { get; set; } = RawStockUnits.Kilogram;

    [MaxLength(1000)]
    public string? Description { get; set; }

    public bool IsProduce { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ICollection<RawStockBalance> Balances { get; set; } =
        new List<RawStockBalance>();

    public ICollection<RawStockBatch> Batches { get; set; } =
        new List<RawStockBatch>();

    public ICollection<RawStockMovement> Movements { get; set; } =
        new List<RawStockMovement>();

    public ICollection<ProductRawStockRequirement> ProductRequirements
        { get; set; } = new List<ProductRawStockRequirement>();
}

public sealed class RawStockBalance
{
    public int RawStockBalanceId { get; set; }
    public int RawStockItemId { get; set; }
    public int WarehouseSectionId { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = RawStockUnits.Kilogram;

    public decimal QuantityOnHand { get; set; }
    public decimal ReservedQuantity { get; set; }
    public decimal? WeightedAverageUnitCost { get; set; }
    public DateTime? LastReceiptAtUtc { get; set; }
    public DateTime? LastStockTakeAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public RawStockItem RawStockItem { get; set; } = null!;
    public WarehouseSection WarehouseSection { get; set; } = null!;
    public ICollection<RawStockBatch> Batches { get; set; } =
        new List<RawStockBatch>();
}

public sealed class RawStockBatch
{
    public long RawStockBatchId { get; set; }
    public int RawStockItemId { get; set; }
    public int RawStockBalanceId { get; set; }
    public int? SupplierId { get; set; }
    public long? RawStockReceiptLineId { get; set; }

    [Required, MaxLength(70)]
    public string BatchCode { get; set; } = string.Empty;

    [Required, MaxLength(220)]
    public string QrCodeValue { get; set; } = string.Empty;

    public decimal QuantityReceived { get; set; }
    public decimal QuantityRemaining { get; set; }
    public decimal? UnitCost { get; set; }
    public DateTime ReceivedAtUtc { get; set; }
    public DateTime? BestBeforeAtUtc { get; set; }

    [Required, MaxLength(30)]
    public string Status { get; set; } = ProductBatchStatuses.Available;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public RawStockItem RawStockItem { get; set; } = null!;
    public RawStockBalance RawStockBalance { get; set; } = null!;
    public Supplier? Supplier { get; set; }
    public RawStockReceiptLine? ReceiptLine { get; set; }
}

public sealed class OperationalReason
{
    public int OperationalReasonId { get; set; }

    [Required, MaxLength(40)]
    public string ReasonCode { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string ReasonName { get; set; } = string.Empty;

    [Required, MaxLength(40)]
    public string CategoryCode { get; set; } = "WriteOff";

    [MaxLength(1000)]
    public string? Description { get; set; }

    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }
}

public sealed class RawStockReceipt
{
    public long RawStockReceiptId { get; set; }

    [Required, MaxLength(40)]
    public string ReceiptNumber { get; set; } = string.Empty;

    [Required, MaxLength(30)]
    public string SourceType { get; set; } = RawStockReceiptSources.AdHocSupplier;

    public int? SupplierId { get; set; }
    public int? SupplierOrderId { get; set; }
    public int? BuyerProcurementId { get; set; }
    public int WarehouseSectionId { get; set; }
    public int ReceivedByUserId { get; set; }

    [Required, MaxLength(120)]
    public string DocketReference { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? AdHocExplanation { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public DateTime ReceivedAtUtc { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? PostedAtUtc { get; set; }

    [Required, MaxLength(30)]
    public string Status { get; set; } = MobileOperationStatuses.Draft;

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Required, MaxLength(64)]
    public string OperationKeyHash { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public Supplier? Supplier { get; set; }
    public SupplierOrder? SupplierOrder { get; set; }
    public BuyerProcurement? BuyerProcurement { get; set; }
    public WarehouseSection WarehouseSection { get; set; } = null!;
    public User ReceivedByUser { get; set; } = null!;
    public ICollection<RawStockReceiptLine> Lines { get; set; } =
        new List<RawStockReceiptLine>();
}

public sealed class RawStockReceiptLine
{
    public long RawStockReceiptLineId { get; set; }
    public long RawStockReceiptId { get; set; }
    public int RawStockItemId { get; set; }
    public int? SupplierOrderLineId { get; set; }
    public int? BuyerProcurementItemId { get; set; }
    public decimal QuantityReceived { get; set; }
    public decimal AcceptedQuantity { get; set; }
    public decimal RejectedQuantity { get; set; }
    public decimal UnitCost { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = RawStockUnits.Kilogram;

    [MaxLength(80)]
    public string? SupplierBatchReference { get; set; }

    public DateTime? BestBeforeAtUtc { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }

    public RawStockReceipt Receipt { get; set; } = null!;
    public RawStockItem RawStockItem { get; set; } = null!;
    public SupplierOrderLine? SupplierOrderLine { get; set; }
    public BuyerProcurementItem? BuyerProcurementItem { get; set; }
    public RawStockBatch? Batch { get; set; }
}

public sealed class RawStockMovement
{
    public long RawStockMovementId { get; set; }
    public int RawStockItemId { get; set; }
    public int RawStockBalanceId { get; set; }
    public long? RawStockBatchId { get; set; }
    public int? OperationalReasonId { get; set; }
    public int CreatedByUserId { get; set; }

    [Required, MaxLength(40)]
    public string MovementType { get; set; } = string.Empty;

    public decimal QuantityChange { get; set; }
    public decimal? UnitCost { get; set; }
    public DateTime OccurredAtUtc { get; set; }

    [MaxLength(80)]
    public string? SourceType { get; set; }

    [MaxLength(80)]
    public string? SourceId { get; set; }

    [MaxLength(1000)]
    public string? ReasonText { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    public RawStockItem RawStockItem { get; set; } = null!;
    public RawStockBalance RawStockBalance { get; set; } = null!;
    public RawStockBatch? RawStockBatch { get; set; }
    public OperationalReason? OperationalReason { get; set; }
    public User CreatedByUser { get; set; } = null!;
}

public sealed class RawStockReconciliationGroup
{
    public int RawStockReconciliationGroupId { get; set; }

    [Required, MaxLength(40)]
    public string GroupCode { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string GroupName { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Description { get; set; }

    public bool IsActive { get; set; } = true;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ICollection<RawStockReconciliationGroupItem> RawStockItems { get; set; } =
        new List<RawStockReconciliationGroupItem>();

    public ICollection<ProductReconciliationMapping> Products { get; set; } =
        new List<ProductReconciliationMapping>();
}

public sealed class RawStockReconciliationGroupItem
{
    public int RawStockReconciliationGroupItemId { get; set; }
    public int RawStockReconciliationGroupId { get; set; }
    public int RawStockItemId { get; set; }
    public RawStockReconciliationGroup Group { get; set; } = null!;
    public RawStockItem RawStockItem { get; set; } = null!;
}

public sealed class ProductReconciliationMapping
{
    public int ProductReconciliationMappingId { get; set; }
    public int RawStockReconciliationGroupId { get; set; }
    public int ProductId { get; set; }
    public RawStockReconciliationGroup Group { get; set; } = null!;
    public Product Product { get; set; } = null!;
}

public sealed class RawStockTakeSession
{
    public long RawStockTakeSessionId { get; set; }
    public int WarehouseSectionId { get; set; }
    public int CreatedByUserId { get; set; }
    public int? ReviewedByUserId { get; set; }
    public int? DecidedByUserId { get; set; }
    public DateTime PeriodStartUtc { get; set; }
    public DateTime PeriodEndUtc { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? SubmittedAtUtc { get; set; }
    public DateTime? ReviewedAtUtc { get; set; }
    public DateTime? DecidedAtUtc { get; set; }
    public DateTime? ClosedAtUtc { get; set; }

    [Required, MaxLength(40)]
    public string Status { get; set; } = RawStockTakeStatuses.Draft;

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [MaxLength(1000)]
    public string? AdministratorReviewNotes { get; set; }

    [MaxLength(1000)]
    public string? ManagementDecisionReason { get; set; }

    public bool ManagementApprovalRequired { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public WarehouseSection WarehouseSection { get; set; } = null!;
    public User CreatedByUser { get; set; } = null!;
    public User? ReviewedByUser { get; set; }
    public User? DecidedByUser { get; set; }
    public ICollection<RawStockTakeLine> Lines { get; set; } =
        new List<RawStockTakeLine>();
}

public sealed class RawStockTakeLine
{
    public long RawStockTakeLineId { get; set; }
    public long RawStockTakeSessionId { get; set; }
    public int RawStockItemId { get; set; }
    public int RawStockBalanceId { get; set; }
    public int? RawStockReconciliationGroupId { get; set; }
    public decimal OpeningRawStock { get; set; }
    public decimal RawStockReceived { get; set; }
    public decimal ApprovedPositiveAdjustments { get; set; }
    public decimal ExistingPackedProductWeight { get; set; }
    public decimal RecordedRawStockWriteOffs { get; set; }
    public decimal ApprovedNegativeAdjustments { get; set; }
    public decimal EstimatedRawStockRemaining { get; set; }
    public decimal? PhysicalStockCount { get; set; }
    public decimal? UnexplainedStockDifference { get; set; }
    public decimal? EstimatedFinancialImpact { get; set; }
    public bool IsMapped { get; set; }
    public bool RequiresManagementApproval { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public RawStockTakeSession Session { get; set; } = null!;
    public RawStockItem RawStockItem { get; set; } = null!;
    public RawStockBalance RawStockBalance { get; set; } = null!;
    public RawStockReconciliationGroup? ReconciliationGroup { get; set; }
}

public sealed class RawStockWriteOff
{
    public long RawStockWriteOffId { get; set; }
    public int RawStockItemId { get; set; }
    public int RawStockBalanceId { get; set; }
    public long? RawStockBatchId { get; set; }
    public int OperationalReasonId { get; set; }
    public int SubmittedByUserId { get; set; }
    public int? DecidedByUserId { get; set; }
    public decimal Quantity { get; set; }
    public decimal? EstimatedUnitCost { get; set; }
    public decimal? EstimatedTotalLoss { get; set; }

    [MaxLength(120)]
    public string? Condition { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [Required, MaxLength(30)]
    public string Status { get; set; } = WriteOffStatuses.Draft;

    [MaxLength(1000)]
    public string? DecisionReason { get; set; }

    public DateTime SubmittedAtUtc { get; set; }
    public DateTime? DecidedAtUtc { get; set; }
    public DateTime? CompletedAtUtc { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public RawStockItem RawStockItem { get; set; } = null!;
    public RawStockBalance RawStockBalance { get; set; } = null!;
    public RawStockBatch? RawStockBatch { get; set; }
    public OperationalReason OperationalReason { get; set; } = null!;
    public User SubmittedByUser { get; set; } = null!;
    public User? DecidedByUser { get; set; }
    public ICollection<RawStockWriteOffEvidence> Evidence { get; set; } =
        new List<RawStockWriteOffEvidence>();
}

public sealed class RawStockWriteOffEvidence
{
    public long RawStockWriteOffEvidenceId { get; set; }
    public long RawStockWriteOffId { get; set; }
    public long StoredFileId { get; set; }
    public int UploadedByUserId { get; set; }
    public DateTime UploadedAtUtc { get; set; }

    [MaxLength(300)]
    public string? Caption { get; set; }

    public RawStockWriteOff RawStockWriteOff { get; set; } = null!;
    public StoredFile StoredFile { get; set; } = null!;
    public User UploadedByUser { get; set; } = null!;
}

public sealed class SupplierOrderLine
{
    public int SupplierOrderLineId { get; set; }
    public int SupplierOrderId { get; set; }
    public int RawStockItemId { get; set; }
    public decimal OrderedQuantity { get; set; }
    public decimal ReceivedQuantity { get; set; }
    public decimal ExpectedUnitPrice { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = RawStockUnits.Kilogram;

    [MaxLength(500)]
    public string? Notes { get; set; }

    public SupplierOrder SupplierOrder { get; set; } = null!;
    public RawStockItem RawStockItem { get; set; } = null!;
    public ICollection<RawStockReceiptLine> ReceiptLines { get; set; } =
        new List<RawStockReceiptLine>();
}

public sealed class ProductRawStockRequirement
{
    public int ProductRawStockRequirementId { get; set; }
    public int ProductId { get; set; }
    public int RawStockItemId { get; set; }
    public decimal RawQuantityPerProductUnit { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = RawStockUnits.Kilogram;

    public decimal WastePercentage { get; set; }
    public decimal YieldPercentage { get; set; } = 100;
    public bool IsActive { get; set; } = true;
    public int CreatedByUserId { get; set; }
    public int? UpdatedByUserId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public Product Product { get; set; } = null!;
    public RawStockItem RawStockItem { get; set; } = null!;
    public User CreatedByUser { get; set; } = null!;
    public User? UpdatedByUser { get; set; }
}

public sealed class FinancialPayment
{
    public long FinancialPaymentId { get; set; }

    [Required, MaxLength(40)]
    public string PaymentNumber { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string CounterpartyType { get; set; } = "Customer";

    public int? CustomerId { get; set; }
    public int? SupplierId { get; set; }
    public int? InvoiceId { get; set; }
    public int? SupplierOrderId { get; set; }
    public long? OriginalPaymentId { get; set; }
    public decimal Amount { get; set; }
    public DateTime PaymentDateUtc { get; set; }

    [Required, MaxLength(40)]
    public string PaymentMethodCode { get; set; } = string.Empty;

    [MaxLength(120)]
    public string? Reference { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [Required, MaxLength(40)]
    public string Status { get; set; } = FinancialPaymentStatuses.Draft;

    [MaxLength(1000)]
    public string? ReversalReason { get; set; }

    public int CreatedByUserId { get; set; }
    public int? PostedByUserId { get; set; }
    public int? DecidedByUserId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? PostedAtUtc { get; set; }
    public DateTime? DecidedAtUtc { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public Customer? Customer { get; set; }
    public Supplier? Supplier { get; set; }
    public Invoice? Invoice { get; set; }
    public SupplierOrder? SupplierOrder { get; set; }
    public FinancialPayment? OriginalPayment { get; set; }
    public ICollection<FinancialPayment> Adjustments { get; set; } =
        new List<FinancialPayment>();
    public User CreatedByUser { get; set; } = null!;
    public User? PostedByUser { get; set; }
    public User? DecidedByUser { get; set; }
}
