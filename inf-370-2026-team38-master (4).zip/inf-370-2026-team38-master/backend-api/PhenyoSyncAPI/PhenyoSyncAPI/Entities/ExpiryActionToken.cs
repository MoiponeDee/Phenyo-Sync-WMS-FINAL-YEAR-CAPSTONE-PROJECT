using System.ComponentModel.DataAnnotations;

// Records hashed, one-time expiry-action tokens for revocable public actions.
namespace PhenyoSyncAPI.Entities
{
    public class ExpiryActionToken
    {
        [Key]
        public long ExpiryActionTokenId { get; set; }

        public int ProductBatchId { get; set; }

        [Required, MaxLength(64)]
        public string TokenHash { get; set; } = string.Empty;

        [Required, MaxLength(30)]
        public string AlertLevel { get; set; } = string.Empty;

        public DateTime CreatedAtUtc { get; set; }

        public DateTime ExpiresAtUtc { get; set; }

        public DateTime? UsedAtUtc { get; set; }

        public DateTime? InvalidatedAtUtc { get; set; }

        public ProductBatch ProductBatch { get; set; } = null!;
    }
}
