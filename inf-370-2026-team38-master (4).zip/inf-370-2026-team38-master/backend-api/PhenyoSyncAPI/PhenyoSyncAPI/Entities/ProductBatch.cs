using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities
{
    // ProductBatch is the traceable, expiry-aware unit consumed by FEFO reservation and packing.
    public class ProductBatch
    {
        [Key]
        public int ProductBatchId { get; set; }

        public int ProductId { get; set; }

        public int SectionId { get; set; }

        [Required, MaxLength(64)]
        public string BatchCode { get; set; } = string.Empty;

        [Required, MaxLength(500)]
        public string QRCodeValue { get; set; } = string.Empty;

        public decimal QuantityProducedKg { get; set; }

        public decimal QuantityRemainingKg { get; set; }

        public DateTime PackedAtUtc { get; set; }

        public DateTime OriginalExpiryAtUtc { get; set; }

        public DateTime EffectiveExpiryAtUtc { get; set; }

        [Required, MaxLength(40)]
        public string Status { get; set; } = ProductBatchStatuses.Available;

        public bool ShelfLifeExtended { get; set; }

        public DateTime? ShelfLifeExtendedAtUtc { get; set; }

        public int? ShelfLifeExtendedByUserId { get; set; }

        [MaxLength(500)]
        public string? ShelfLifeExtensionReason { get; set; }

        public DateTime? YellowAlertSentAtUtc { get; set; }

        public DateTime? RedAlertSentAtUtc { get; set; }

        public DateTime? AvailableQuantityRemovedAtUtc { get; set; }

        public DateTime CreatedAtUtc { get; set; }

        public DateTime? UpdatedAtUtc { get; set; }

        public Product Product { get; set; } = null!;

        public WarehouseSection WarehouseSection { get; set; } = null!;

        public User? ShelfLifeExtendedByUser { get; set; }

        public ICollection<StockMovement> StockMovements { get; set; }
            = new List<StockMovement>();

        public ICollection<ExpiryActionToken> ExpiryActionTokens { get; set; }
            = new List<ExpiryActionToken>();

        public ICollection<OrderStockReservation> OrderStockReservations { get; set; }
            = new List<OrderStockReservation>();
    }
}
