﻿using System.ComponentModel.DataAnnotations;

// Tracks one reconciliation session without replacing movement history.
namespace PhenyoSyncAPI.Entities
{
    public class StockTakeSession
    {
        [Key]
        public int SessionId { get; set; }

        public int UserId { get; set; }

        public int SectionId { get; set; }

        public DateTime SessionDate { get; set; } = DateTime.UtcNow;

        [Required]
        public string Status { get; set; } = "Open";

        public string? Notes { get; set; }

        [Required, MaxLength(64)]
        public string CorrelationId { get; set; } = string.Empty;

        public User User { get; set; } = null!;
        public WarehouseSection WarehouseSection { get; set; } = null!;
        public ICollection<StockMovement> StockMovements { get; set; } =
            new List<StockMovement>();
    }
}
