﻿using PhenyoSyncAPI.Entities;
using System.ComponentModel.DataAnnotations;

// Defines the top level of the Category-to-Type-to-Product hierarchy.
namespace PhenyoSyncAPI.Entities
{
    public class ProductCategory
    {
        [Key]
        public int ProductCategoryId { get; set; }

        [Required]
        [StringLength(100)]
        public string ProductCategoryName { get; set; } = string.Empty;

        [StringLength(255)]
        public string? Description { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Active";

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        public virtual ICollection<Product> Products { get; set; }
            = new List<Product>();

        public ICollection<ProductCategoryType> ProductCategoryTypes { get; set; }
            = new List<ProductCategoryType>();
    }
}
