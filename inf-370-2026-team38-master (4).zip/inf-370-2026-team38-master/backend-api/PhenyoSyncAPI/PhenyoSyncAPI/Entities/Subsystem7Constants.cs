namespace PhenyoSyncAPI.Entities
{
// Centralizes persisted stock, procurement, and expiry workflow codes.
    public static class ProductStatuses
    {
        public const string Active = "Active";
        public const string Inactive = "Inactive";
    }

    public static class ProductBatchStatuses
    {
        public const string Available = "Available";
        public const string Consumed = "Consumed";
        public const string ExpiredPendingDecision = "ExpiredPendingDecision";
        public const string WrittenOff = "WrittenOff";
    }

    public static class StockMovementTypes
    {
        public const string Increase = "Increase";
        public const string Decrease = "Decrease";
        public const string WriteOff = "WriteOff";
        public const string Adjustment = "Adjustment";
    }

    public static class ExpiryAlertLevels
    {
        public const string Normal = "Normal";
        public const string Warning = "Warning";
        public const string Urgent = "Urgent";
        public const string Expired = "Expired";
    }
}
