using System.ComponentModel.DataAnnotations;

// Persists revocable, expiring link metadata; raw customer-link tokens are not stored.
namespace PhenyoSyncAPI.Entities;

public class CustomerOrderLink
{
    [Key]
    public long CustomerOrderLinkId { get; set; }
    public int CustomerId { get; set; }

    [Required, MaxLength(64)]
    public string TokenHash { get; set; } = string.Empty;

    public int CreatedByUserId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime ExpiresAtUtc { get; set; }
    public DateTime? UsedAtUtc { get; set; }
    public DateTime? RevokedAtUtc { get; set; }
    public int? SalesOrderId { get; set; }
    public DateTime? EmailSentAtUtc { get; set; }

    public Customer Customer { get; set; } = null!;
    public User CreatedByUser { get; set; } = null!;
    public SalesOrder? SalesOrder { get; set; }
}
