using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.Entities;

// Data-exchange jobs persist server-owned validation state and hierarchy links carry RowVersion.

public sealed class ProductCategoryType
{
    public int ProductCategoryTypeId { get; set; }
    public int ProductCategoryId { get; set; }
    public int ProductTypeId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public int? CreatedByUserId { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public ProductCategory ProductCategory { get; set; } = null!;
    public ProductType ProductType { get; set; } = null!;
    public User? CreatedByUser { get; set; }
}

public static class DataExchangeTypes
{
    public const string ProductExcel = "ProductExcel";
    public const string StockCountJson = "StockCountJson";
}

public static class DataExchangeStatuses
{
    public const string Validated = "Validated";
    public const string Applied = "Applied";
    public const string Failed = "Failed";
    public const string Expired = "Expired";
}

public sealed class DataExchangeJob
{
    public long DataExchangeJobId { get; set; }

    [Required, MaxLength(64)]
    public string ValidationTokenHash { get; set; } = string.Empty;

    [Required, MaxLength(40)]
    public string ExchangeType { get; set; } = string.Empty;

    [Required, MaxLength(30)]
    public string Status { get; set; } = DataExchangeStatuses.Validated;

    [Required, MaxLength(255)]
    public string OriginalFileName { get; set; } = string.Empty;

    [Required, MaxLength(64)]
    public string ContentSha256 { get; set; } = string.Empty;

    [Required]
    public string StagedPayloadJson { get; set; } = string.Empty;

    public string? ResultPayloadJson { get; set; }
    public int TotalRows { get; set; }
    public int ValidRows { get; set; }
    public int WarningRows { get; set; }
    public int InvalidRows { get; set; }
    public int CreatedByUserId { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime ExpiresAtUtc { get; set; }
    public DateTime? AppliedAtUtc { get; set; }

    [MaxLength(500)]
    public string? ApplyReason { get; set; }

    [Required, MaxLength(64)]
    public string CorrelationId { get; set; } = string.Empty;

    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public User CreatedByUser { get; set; } = null!;
}
