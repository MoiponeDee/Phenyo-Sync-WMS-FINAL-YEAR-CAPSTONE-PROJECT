using System.Collections;
using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace PhenyoSyncAPI.Auditing;

/// <summary>
/// Central redaction and size boundary for data written to audit history.
/// This is a defence in depth layer; secrets should never be supplied to the
/// audit service in the first place.
/// </summary>
public static partial class AuditSanitizer
{
    private const int MaximumJsonLength = 16_000;
    private static readonly string[] SensitiveFragments =
    [
        "password", "confirmPassword", "token", "tokenHash", "resetToken",
        "actionToken", "orderLinkToken", "authorization", "secret", "apiKey",
        "jwt", "smtpPassword", "connectionString", "securityStamp", "cardNumber",
        "accountNumber", "cvv"
    ];

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false
    };

    public static bool IsSensitive(string propertyName) =>
        SensitiveFragments.Any(fragment =>
            propertyName.Contains(fragment, StringComparison.OrdinalIgnoreCase));

    public static object? SafeValue(string propertyName, object? value)
    {
        // Property-name matching prevents common token/password/key values
        // from being serialised even if a caller adds them accidentally.
        if (IsSensitive(propertyName))
        {
            return "[REDACTED]";
        }

        return value switch
        {
            null => null,
            DateTime dateTime => dateTime.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture),
            DateTimeOffset offset => offset.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture),
            byte[] bytes => Convert.ToBase64String(bytes),
            decimal number => number,
            double number => number,
            float number => number,
            bool boolean => boolean,
            Enum enumeration => enumeration.ToString(),
            string text => Bounded(text, 1000),
            IEnumerable enumerable when value is not string =>
                enumerable.Cast<object?>().Take(50).Select(item => item?.ToString()).ToArray(),
            _ => value
        };
    }

    public static string? Serialize(IReadOnlyDictionary<string, object?>? values)
    {
        if (values is null || values.Count == 0)
        {
            return null;
        }

        var sanitized = values.ToDictionary(
            item => item.Key,
            item => SafeValue(item.Key, item.Value),
            StringComparer.Ordinal);
        var json = JsonSerializer.Serialize(sanitized, JsonOptions);
        // Audit payloads are evidence, not document storage. Bound their size
        // so one event cannot create an unexpectedly large database record.
        if (json.Length <= MaximumJsonLength)
        {
            return json;
        }

        return JsonSerializer.Serialize(new
        {
            truncated = true,
            preview = json[..Math.Min(12_000, json.Length)]
        }, JsonOptions);
    }

    public static string SerializeFields(IEnumerable<string> fields) =>
        JsonSerializer.Serialize(fields.Distinct(StringComparer.Ordinal).OrderBy(item => item));

    public static string? Bounded(string? value, int maximumLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        var sanitized = ControlCharacters().Replace(value.Trim(), " ");
        return sanitized.Length <= maximumLength
            ? sanitized
            : $"{sanitized[..Math.Max(0, maximumLength - 13)]}[TRUNCATED]";
    }

    public static string SanitizeFailure(string? value)
    {
        var bounded = Bounded(value, 1000) ?? "The operation failed.";
        return BearerValue().Replace(bounded, "Bearer [REDACTED]");
    }

    public static string? MaskEmail(string? email)
    {
        if (string.IsNullOrWhiteSpace(email))
        {
            return null;
        }

        var separator = email.IndexOf('@');
        if (separator <= 0)
        {
            return "[REDACTED]";
        }

        var local = email[..separator];
        var domain = email[(separator + 1)..];
        // Keep only enough of the local part to identify an operational issue
        // without placing a complete email address into a failure description.
        var visible = local.Length <= 2 ? local[..1] : local[..2];
        return $"{visible}***@{domain}";
    }

    [GeneratedRegex(@"[\u0000-\u001F\u007F]+", RegexOptions.CultureInvariant)]
    private static partial Regex ControlCharacters();

    [GeneratedRegex(@"Bearer\s+[A-Za-z0-9._~+/=-]+", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex BearerValue();
}
