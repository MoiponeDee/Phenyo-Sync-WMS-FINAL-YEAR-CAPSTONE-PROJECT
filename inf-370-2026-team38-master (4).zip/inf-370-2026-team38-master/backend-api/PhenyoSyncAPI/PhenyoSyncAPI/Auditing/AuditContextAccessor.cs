using System.Security.Claims;

namespace PhenyoSyncAPI.Auditing;

// The accessor derives actor/correlation metadata from the current request so services do not
// accept spoofable browser-supplied user IDs when producing audit records.

public sealed record AuditActorContext(
    int? UserId,
    string? Email,
    string? DisplayName,
    string? Role,
    string ActorType,
    string CorrelationId,
    string? RequestPath,
    string? HttpMethod,
    string? IpAddress,
    string? UserAgent);

public interface IAuditContextAccessor
{
    AuditActorContext Current { get; }
}

public sealed class AuditContextAccessor : IAuditContextAccessor
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly string _fallbackCorrelationId = Guid.NewGuid().ToString("N");

    public AuditContextAccessor(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public AuditActorContext Current
    {
        get
        {
            var httpContext = _httpContextAccessor.HttpContext;
            if (httpContext is null)
            {
                return new AuditActorContext(
                    null, null, "PhenyoSync System", null,
                    AuditActorTypes.System, _fallbackCorrelationId,
                    null, null, null, null);
            }

            var principal = httpContext.User;
            var authenticated = principal.Identity?.IsAuthenticated == true;
            var userId = int.TryParse(
                principal.FindFirstValue(ClaimTypes.NameIdentifier),
                out var parsedUserId)
                    ? parsedUserId
                    : (int?)null;
            var correlationId =
                httpContext.Items[CorrelationIdMiddleware.ItemKey]?.ToString()
                ?? httpContext.TraceIdentifier;

            return new AuditActorContext(
                userId,
                principal.FindFirstValue(ClaimTypes.Email),
                principal.FindFirstValue(ClaimTypes.Name),
                principal.FindFirstValue(ClaimTypes.Role),
                authenticated ? AuditActorTypes.User : AuditActorTypes.Anonymous,
                AuditSanitizer.Bounded(correlationId, 64) ?? _fallbackCorrelationId,
                AuditSanitizer.Bounded(httpContext.Request.Path.Value, 512),
                AuditSanitizer.Bounded(httpContext.Request.Method, 10),
                AuditSanitizer.Bounded(httpContext.Connection.RemoteIpAddress?.ToString(), 64),
                AuditSanitizer.Bounded(httpContext.Request.Headers.UserAgent.ToString(), 512));
        }
    }
}
