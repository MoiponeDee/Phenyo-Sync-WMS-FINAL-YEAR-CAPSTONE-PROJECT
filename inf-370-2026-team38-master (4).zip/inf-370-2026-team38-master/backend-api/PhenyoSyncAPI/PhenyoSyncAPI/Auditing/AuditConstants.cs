namespace PhenyoSyncAPI.Auditing;

// Stable audit vocabulary is centralized so controllers, services and background jobs
// produce filterable records instead of inconsistent free-text action names.
public static class AuditActorTypes
{
    public const string User = "User";
    public const string System = "System";
    public const string BackgroundService = "BackgroundService";
    public const string Anonymous = "Anonymous";
}

public static class AuditActionTypes
{
    public const string Create = "Create";
    public const string Update = "Update";
    public const string Delete = "Delete";
    public const string SoftDelete = "SoftDelete";
    public const string Activate = "Activate";
    public const string Deactivate = "Deactivate";
    public const string StatusChange = "StatusChange";
    public const string ReserveStock = "ReserveStock";
    public const string ReleaseStock = "ReleaseStock";
    public const string IncreaseStock = "IncreaseStock";
    public const string DecreaseStock = "DecreaseStock";
    public const string WriteOff = "WriteOff";
    public const string ExtendShelfLife = "ExtendShelfLife";
    public const string SendEmail = "SendEmail";
    public const string GenerateLink = "GenerateLink";
    public const string GenerateInvoice = "GenerateInvoice";
    public const string ViewSensitiveRecord = "ViewSensitiveRecord";
    public const string LoginSuccess = "LoginSuccess";
    public const string LoginFailure = "LoginFailure";
    public const string PasswordResetRequested = "PasswordResetRequested";
    public const string PasswordResetCompleted = "PasswordResetCompleted";
    public const string SearchAuditLogs = "SearchAuditLogs";
    public const string ViewAuditLogDetails = "ViewAuditLogDetails";
    public const string BackgroundJob = "BackgroundJob";
    public const string Export = "Export";
    public const string Import = "Import";
    public const string ValidateImport = "ValidateImport";
    public const string Scan = "Scan";
    public const string GenerateReport = "GenerateReport";

    public static readonly string[] All =
    [
        Create, Update, Delete, SoftDelete, Activate, Deactivate, StatusChange,
        ReserveStock, ReleaseStock, IncreaseStock, DecreaseStock, WriteOff,
        ExtendShelfLife, SendEmail, GenerateLink, GenerateInvoice,
        ViewSensitiveRecord, LoginSuccess, LoginFailure, PasswordResetRequested,
        PasswordResetCompleted, SearchAuditLogs, ViewAuditLogDetails, BackgroundJob,
        Export, Import, ValidateImport, Scan, GenerateReport
    ];
}

public static class AuditModules
{
    public const string Authentication = "Authentication";
    public const string UserManagement = "UserManagement";
    public const string Permissions = "Permissions";
    public const string ProductManagement = "ProductManagement";
    public const string ProductType = "ProductType";
    public const string ProductCategory = "ProductCategory";
    public const string Stock = "Stock";
    public const string ProductBatch = "ProductBatch";
    public const string ExpiryManagement = "ExpiryManagement";
    public const string CustomerManagement = "CustomerManagement";
    public const string OrderManagement = "OrderManagement";
    public const string OrderLink = "OrderLink";
    public const string StockReservation = "StockReservation";
    public const string Packing = "Packing";
    public const string Invoice = "Invoice";
    public const string Pricing = "Pricing";
    public const string SupplierManagement = "SupplierManagement";
    public const string DeliveryLogistics = "DeliveryLogistics";
    public const string Audit = "Audit";
    public const string Configuration = "Configuration";
    public const string DataExchange = "DataExchange";
    public const string OperationsCalendar = "OperationsCalendar";
    public const string QrScanning = "QrScanning";
    public const string ProductHierarchy = "ProductHierarchy";
    public const string RawStock = "RawStock";
    public const string RawStockTake = "RawStockTake";
    public const string Payments = "Payments";
    public const string BuyingList = "BuyingList";
    public const string Reports = "Reports";

    public static readonly string[] All =
    [
        Authentication, UserManagement, Permissions, ProductManagement,
        ProductType, ProductCategory, Stock, ProductBatch, ExpiryManagement,
        CustomerManagement, OrderManagement, OrderLink, StockReservation,
        Packing, Invoice, Pricing, SupplierManagement, DeliveryLogistics, Audit,
        Configuration, DataExchange, OperationsCalendar, QrScanning,
        ProductHierarchy, RawStock, RawStockTake, Payments, BuyingList,
        Reports
    ];
}

public static class AuditEventSources
{
    public const string EntityChange = "EntityChange";
    public const string BusinessEvent = "BusinessEvent";
    public const string SecurityEvent = "SecurityEvent";
    public const string BackgroundService = "BackgroundService";
}
