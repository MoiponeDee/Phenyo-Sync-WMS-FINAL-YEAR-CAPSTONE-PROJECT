using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace PhenyoSyncAPI.Auditing;

/// <summary>Translates EF entity changes into stable, reviewer-friendly audit modules and actions.</summary>
internal static class AuditMetadataResolver
{
    public static string ModuleFor(string entityType) => entityType switch
    {
        "User" or "AdminClerk" or "Businessmanager" or "CEO" or "COO" or
            "Driver" or "Packer" or "Stocktaker" or "Warehousemanager" =>
            AuditModules.UserManagement,
        "Role" or "Permission" or "RolePermission" => AuditModules.Permissions,
        "Product" => AuditModules.ProductManagement,
        "ProductType" => AuditModules.ProductType,
        "ProductCategory" => AuditModules.ProductCategory,
        "Stock" or "StockMovement" => AuditModules.Stock,
        "ProductBatch" => AuditModules.ProductBatch,
        "ExpiryActionToken" => AuditModules.ExpiryManagement,
        "Customer" => AuditModules.CustomerManagement,
        "SalesOrder" or "SalesOrderItem" or "OrderStatusHistory" => AuditModules.OrderManagement,
        "CustomerOrderLink" => AuditModules.OrderLink,
        "OrderStockReservation" => AuditModules.StockReservation,
        "Invoice" => AuditModules.Invoice,
        "ProductPrice" => AuditModules.Pricing,
        "Supplier" or "SupplierOrder" => AuditModules.SupplierManagement,
        "Delivery" or "DeliveryDriverAssignment" or "DeliveryStatusHistory" or
            "DeliveryCompletionRecord" or "DriverJob" =>
            AuditModules.DeliveryLogistics,
        "LookupType" or "LookupValue" or "LookupValueHistory" or
            "SystemSetting" or "SystemSettingHistory" or "WarehouseSection" =>
            AuditModules.Configuration,
        _ => entityType
    };

    public static string ActionFor(
        EntityEntry entry,
        IReadOnlyCollection<string> changedFields,
        EntityState? capturedState = null)
    {
        // Infer the business action from state plus meaningful fields instead of recording every
        // change as a generic update, which keeps audit searches useful to reviewers.
        var entityType = entry.Metadata.ClrType.Name;
        var state = capturedState ?? entry.State;
        if (state == EntityState.Added)
        {
            if (entityType == "StockMovement")
            {
                return Current(entry, "MovementType") switch
                {
                    "Increase" => AuditActionTypes.IncreaseStock,
                    "Decrease" => AuditActionTypes.DecreaseStock,
                    "WriteOff" => AuditActionTypes.WriteOff,
                    _ => AuditActionTypes.Create
                };
            }

            return entityType switch
            {
                "CustomerOrderLink" or "ExpiryActionToken" => AuditActionTypes.GenerateLink,
                "Invoice" => AuditActionTypes.GenerateInvoice,
                "OrderStockReservation" => AuditActionTypes.ReserveStock,
                "OrderStatusHistory" => AuditActionTypes.StatusChange,
                _ => AuditActionTypes.Create
            };
        }

        if (state == EntityState.Deleted)
        {
            return AuditActionTypes.Delete;
        }

        if (changedFields.Contains("IsDeleted"))
        {
            return string.Equals(Current(entry, "IsDeleted"), "True", StringComparison.OrdinalIgnoreCase)
                ? AuditActionTypes.SoftDelete
                : AuditActionTypes.Activate;
        }

        if (entityType == "OrderStockReservation" && changedFields.Contains("Status"))
        {
            return string.Equals(Current(entry, "Status"), "Released", StringComparison.OrdinalIgnoreCase)
                ? AuditActionTypes.ReleaseStock
                : AuditActionTypes.StatusChange;
        }

        if (entityType == "ProductBatch" && changedFields.Contains("ShelfLifeExtendedAtUtc"))
        {
            return AuditActionTypes.ExtendShelfLife;
        }

        if (entityType == "ProductBatch" &&
            changedFields.Contains("Status") &&
            string.Equals(Current(entry, "Status"), "WrittenOff", StringComparison.OrdinalIgnoreCase))
        {
            return AuditActionTypes.WriteOff;
        }

        if (changedFields.Contains("Status") ||
            changedFields.Contains("ValidationStatus") ||
            changedFields.Contains("IsCurrent"))
        {
            return Current(entry, "Status") switch
            {
                "Active" or "Available" => AuditActionTypes.Activate,
                "Inactive" => AuditActionTypes.Deactivate,
                _ => AuditActionTypes.StatusChange
            };
        }

        return AuditActionTypes.Update;
    }

    public static string? EntityDisplay(EntityEntry entry)
    {
        string[] preferred =
        [
            "ProductName", "OrderNumber", "InvoiceNumber", "BatchCode",
            "CustomerName", "ProductTypeName", "ProductCategoryName",
            "PermissionName", "RoleName", "Email", "Name"
        ];

        foreach (var propertyName in preferred)
        {
            var property = entry.Properties.FirstOrDefault(item =>
                item.Metadata.Name.Equals(propertyName, StringComparison.Ordinal));
            if (property?.CurrentValue is null)
            {
                continue;
            }

            var value = property.CurrentValue.ToString();
            if (propertyName.Equals("Email", StringComparison.Ordinal))
            {
                value = AuditSanitizer.MaskEmail(value);
            }

            return AuditSanitizer.Bounded(value, 500);
        }

        return null;
    }

    private static string? Current(EntityEntry entry, string name) =>
        entry.Properties.FirstOrDefault(item => item.Metadata.Name == name)?.CurrentValue?.ToString();
}
