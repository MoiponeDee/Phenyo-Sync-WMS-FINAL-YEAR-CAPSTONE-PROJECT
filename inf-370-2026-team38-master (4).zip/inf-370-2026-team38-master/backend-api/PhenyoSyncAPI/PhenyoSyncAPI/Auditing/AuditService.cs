using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Auditing;

public interface IAuditService
{
    Task RecordAsync(AuditEvent auditEvent, CancellationToken cancellationToken = default);
}

/// <summary>
/// Creates the durable audit record for a completed business/security action.
/// Actor data is taken from the request context unless the caller supplies an
/// explicit system or background actor.
/// </summary>
public sealed class AuditService : IAuditService
{
    private readonly PhenyoSyncDbContext _context;
    private readonly IAuditContextAccessor _contextAccessor;

    public AuditService(
        PhenyoSyncDbContext context,
        IAuditContextAccessor contextAccessor)
    {
        _context = context;
        _contextAccessor = contextAccessor;
    }

    public async Task RecordAsync(
        AuditEvent auditEvent,
        CancellationToken cancellationToken = default)
    {
        // Combine event-specific values with the correlation/actor snapshot
        // captured by middleware at the start of the request.
        var actor = _contextAccessor.Current;
        var userId = auditEvent.UserId ?? actor.UserId;
        var email = auditEvent.UserEmail ?? actor.Email;
        var displayName = auditEvent.UserDisplayName ?? actor.DisplayName;
        var role = auditEvent.UserRole ?? actor.Role;

        if (userId.HasValue &&
            (string.IsNullOrWhiteSpace(email) ||
             string.IsNullOrWhiteSpace(displayName) ||
             string.IsNullOrWhiteSpace(role)))
        {
            // Some service operations only know a user id. Resolve missing
            // display values once so the audit remains understandable later.
            var user = await _context.Users
                .AsNoTracking()
                .Where(item => item.UserId == userId.Value)
                .Select(item => new
                {
                    item.Email,
                    DisplayName = item.FirstName + " " + item.LastName,
                    Role = item.Role != null ? item.Role.RoleName : null
                })
                .FirstOrDefaultAsync(cancellationToken);

            email ??= user?.Email;
            displayName ??= user?.DisplayName;
            role ??= user?.Role;
        }

        // Every free-text or structured value is bounded/sanitised before it
        // reaches the audit table. Callers must still pass only safe details.
        _context.AuditLogs.Add(new AuditLog
        {
            OccurredAtUtc = DateTime.UtcNow,
            UserId = userId,
            UserEmailSnapshot = AuditSanitizer.Bounded(email, 320),
            UserDisplayNameSnapshot = AuditSanitizer.Bounded(displayName, 200),
            UserRoleSnapshot = AuditSanitizer.Bounded(role, 100),
            ActorType = auditEvent.ActorType ?? actor.ActorType,
            ActionType = AuditSanitizer.Bounded(auditEvent.ActionType, 64)
                ?? AuditActionTypes.Update,
            SystemModule = AuditSanitizer.Bounded(auditEvent.SystemModule, 80)
                ?? AuditModules.Audit,
            OperationName = AuditSanitizer.Bounded(auditEvent.OperationName, 160)
                ?? auditEvent.ActionType,
            EntityType = AuditSanitizer.Bounded(auditEvent.EntityType, 128),
            EntityId = AuditSanitizer.Bounded(auditEvent.EntityId, 256),
            EntityDisplay = AuditSanitizer.Bounded(auditEvent.EntityDisplay, 500),
            Description = AuditSanitizer.Bounded(auditEvent.Description, 1000)
                ?? auditEvent.OperationName,
            AfterValuesJson = AuditSanitizer.Serialize(auditEvent.SafeDetails),
            Success = auditEvent.Success,
            FailureReason = auditEvent.Success
                ? null
                : AuditSanitizer.SanitizeFailure(auditEvent.FailureReason),
            CorrelationId = actor.CorrelationId,
            RequestPath = actor.RequestPath,
            HttpMethod = actor.HttpMethod,
            IpAddress = actor.IpAddress,
            UserAgent = actor.UserAgent,
            EventSource = auditEvent.EventSource
        });

        await _context.SaveChangesAsync(cancellationToken);
    }
}
