namespace PhenyoSyncAPI.Auditing;

// Carries one normalized audit event from business code into the persistence pipeline.
public sealed class AuditEvent
{
    public required string ActionType { get; init; }
    public required string SystemModule { get; init; }
    public required string OperationName { get; init; }
    public required string Description { get; init; }
    public string? EntityType { get; init; }
    public string? EntityId { get; init; }
    public string? EntityDisplay { get; init; }
    public bool Success { get; init; } = true;
    public string? FailureReason { get; init; }
    public string EventSource { get; init; } = AuditEventSources.BusinessEvent;
    public int? UserId { get; init; }
    public string? UserEmail { get; init; }
    public string? UserDisplayName { get; init; }
    public string? UserRole { get; init; }
    public string? ActorType { get; init; }
    public IReadOnlyDictionary<string, object?>? SafeDetails { get; init; }
}
