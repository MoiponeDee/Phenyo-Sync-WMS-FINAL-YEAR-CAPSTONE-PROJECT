using System.Reflection;
using Microsoft.EntityFrameworkCore;
using PhenyoSyncAPI.Contracts;

namespace PhenyoSyncAPI.Middleware;

/// <summary>Maps internal exceptions to consistent, safe API errors and correlation-friendly logs.</summary>
public sealed class ApiExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ApiExceptionMiddleware> _logger;

    public ApiExceptionMiddleware(
        RequestDelegate next,
        ILogger<ApiExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception exception) when (!context.Response.HasStarted)
        {
            // Log the original exception server-side, but return only the mapped safe message.
            var (status, code, message) = Map(exception);
            _logger.LogError(
                exception,
                "Request {TraceId} failed with {Code}.",
                context.TraceIdentifier,
                code);

            context.Response.Clear();
            context.Response.StatusCode = status;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsJsonAsync(
                ApiResponses.Error(context, message, code));
        }
    }

    private static (int Status, string Code, string Message) Map(
        Exception exception)
    {
        var customStatus = exception.GetType()
            .GetProperty(
                "StatusCode",
                BindingFlags.Public | BindingFlags.Instance)
            ?.GetValue(exception) as int?;

        if (customStatus.HasValue)
        {
            return (
                customStatus.Value,
                $"DOMAIN_{customStatus.Value}",
                SafeMessage(exception.Message, customStatus.Value));
        }

        return exception switch
        {
            KeyNotFoundException => (
                StatusCodes.Status404NotFound,
                "RESOURCE_NOT_FOUND",
                "The requested record was not found."),
            DbUpdateConcurrencyException => (
                StatusCodes.Status409Conflict,
                "CONCURRENCY_CONFLICT",
                "The record changed while you were editing it. Refresh and try again."),
            DbUpdateException => (
                StatusCodes.Status409Conflict,
                "DATABASE_CONFLICT",
                "The change conflicts with related or existing records."),
            UnauthorizedAccessException => (
                StatusCodes.Status403Forbidden,
                "ACCESS_DENIED",
                "You do not have permission to perform this action."),
            ArgumentException => (
                StatusCodes.Status400BadRequest,
                "INVALID_REQUEST",
                SafeMessage(exception.Message, StatusCodes.Status400BadRequest)),
            _ => (
                StatusCodes.Status500InternalServerError,
                "UNEXPECTED_ERROR",
                "Something went wrong while processing the request. Try again or contact support.")
        };
    }

    private static string SafeMessage(string message, int statusCode) =>
        // Unexpected server messages may contain implementation details and are never exposed.
        statusCode < StatusCodes.Status500InternalServerError &&
        !string.IsNullOrWhiteSpace(message)
            ? message
            : "The request could not be completed.";
}
