namespace PhenyoSyncAPI.Options
{
    public class ExpiryAlertOptions
    {
        public const string SectionName = "ExpiryAlerts";

        public int YellowThresholdHours { get; set; } = 72;

        public int RedThresholdHours { get; set; } = 24;

        public int ScanIntervalMinutes { get; set; } = 60;

        public int ActionTokenLifetimeHours { get; set; } = 48;

        public string[] RecipientRoles { get; set; }
            = ["OperationsManager", "WarehouseManager"];
    }
}
