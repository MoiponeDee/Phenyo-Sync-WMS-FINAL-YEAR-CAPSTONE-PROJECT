namespace PhenyoSyncAPI.Options;

public sealed class ProtectedStorageOptions
{
    public const string SectionName = "ProtectedStorage";
    public string RootPath { get; set; } = "App_Data/protected-files";
}
