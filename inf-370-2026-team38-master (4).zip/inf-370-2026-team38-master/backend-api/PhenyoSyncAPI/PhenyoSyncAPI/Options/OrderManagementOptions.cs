namespace PhenyoSyncAPI.Options;

public sealed class OrderManagementOptions
{
    public const string SectionName = "OrderManagement";

    public int OrderLinkLifetimeHours { get; set; } = 72;
    public int DeliverySafetyHours { get; set; } = 0;
    public decimal TaxRatePercent { get; set; } = 0;
    public int DefaultPageSize { get; set; } = 20;
    public int MaximumPageSize { get; set; } = 100;
}
