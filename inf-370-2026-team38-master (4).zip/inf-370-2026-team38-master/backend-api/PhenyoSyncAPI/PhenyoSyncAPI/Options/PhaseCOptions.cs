namespace PhenyoSyncAPI.Options;

// Binds mobile-operation limits and thresholds from external configuration.
public sealed class GoogleMapsOptions
{
    public const string SectionName = "GoogleMaps";
    public bool Enabled { get; set; }
    public string RoutesEndpoint { get; set; } =
        "https://routes.googleapis.com/directions/v2:computeRoutes";
    public string? ServerApiKey { get; set; }
    public int TimeoutSeconds { get; set; } = 15;

    public bool IsConfigured =>
        Enabled &&
        Uri.TryCreate(RoutesEndpoint, UriKind.Absolute, out _) &&
        !string.IsNullOrWhiteSpace(ServerApiKey);
}

public sealed class FirebaseMessagingOptions
{
    public const string SectionName = "FirebaseMessaging";
    public bool Enabled { get; set; }
    public string? ProjectId { get; set; }
    public string? ServiceAccountJson { get; set; }
    public int TimeoutSeconds { get; set; } = 15;

    public bool IsConfigured =>
        Enabled &&
        !string.IsNullOrWhiteSpace(ProjectId) &&
        !string.IsNullOrWhiteSpace(ServiceAccountJson);
}

public sealed class MobileOperationsOptions
{
    public const string SectionName = "MobileOperations";
    public string PublicApiBaseUrl { get; set; } = string.Empty;
    public string[] AllowedCorsOrigins { get; set; } = [];
    public bool RequireHttpsOutsideDevelopment { get; set; } = true;
}
