namespace PhenyoSyncAPI.Options;

public sealed class GoogleOrderIntakeOptions
{
    public const string SectionName = "GoogleOrderIntake";

    public string SpreadsheetId { get; set; } = string.Empty;
    public string Range { get; set; } = "Form Responses 1!A:Z";
    public string ApiKey { get; set; } = string.Empty;
}
