namespace PhenyoSyncAPI.Security;

public static class PricingRoles
{
    public const string Managers = "Admin";

    public const string Readers = "Admin,OperationsManager,BusinessManager";
}
