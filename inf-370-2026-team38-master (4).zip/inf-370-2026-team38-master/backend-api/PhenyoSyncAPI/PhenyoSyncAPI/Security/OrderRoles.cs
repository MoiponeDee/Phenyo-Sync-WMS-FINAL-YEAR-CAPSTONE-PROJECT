namespace PhenyoSyncAPI.Security;

public static class OrderRoles
{
    public const string Managers = "BusinessManager";
    public const string InternalReaders =
        "Admin,BusinessManager,OperationsManager,WarehouseManager,Packer";
    public const string PackersAndManagers =
        "Packer,WarehouseManager,BusinessManager";
}
