using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PhenyoSyncAPI.Contracts;
using PhenyoSyncAPI.Data;

namespace PhenyoSyncAPI.Security;

public sealed class HasPermissionAttribute : AuthorizeAttribute
{
    public const string PolicyPrefix = "Permission:";

    public HasPermissionAttribute(string permissionCode)
    {
        Policy = PolicyPrefix + permissionCode;
    }
}

public sealed record PermissionRequirement(string PermissionCode)
    : IAuthorizationRequirement;

public sealed class HasAnyPermissionAttribute : AuthorizeAttribute
{
    public const string PolicyPrefix = "PermissionAny:";

    public HasAnyPermissionAttribute(params string[] permissionCodes)
    {
        if (permissionCodes.Length == 0)
            throw new ArgumentException(
                "At least one permission code is required.",
                nameof(permissionCodes));
        Policy = PolicyPrefix + string.Join(",", permissionCodes);
    }
}

public sealed record AnyPermissionRequirement(
    IReadOnlyCollection<string> PermissionCodes)
    : IAuthorizationRequirement;

public sealed class PermissionPolicyProvider
    : DefaultAuthorizationPolicyProvider
{
    public PermissionPolicyProvider(
        IOptions<AuthorizationOptions> options) : base(options)
    {
    }

    public override Task<AuthorizationPolicy?> GetPolicyAsync(
        string policyName)
    {
        if (!policyName.StartsWith(
                HasPermissionAttribute.PolicyPrefix,
                StringComparison.Ordinal) &&
            !policyName.StartsWith(
                HasAnyPermissionAttribute.PolicyPrefix,
                StringComparison.Ordinal))
        {
            return base.GetPolicyAsync(policyName);
        }

        if (policyName.StartsWith(
                HasAnyPermissionAttribute.PolicyPrefix,
                StringComparison.Ordinal))
        {
            var permissionCodes = policyName[
                    HasAnyPermissionAttribute.PolicyPrefix.Length..]
                .Split(
                    ',',
                    StringSplitOptions.RemoveEmptyEntries |
                    StringSplitOptions.TrimEntries);
            return Task.FromResult<AuthorizationPolicy?>(
                new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .AddRequirements(
                        new AnyPermissionRequirement(permissionCodes))
                    .Build());
        }

        var permissionCode = policyName[HasPermissionAttribute.PolicyPrefix.Length..];
        return Task.FromResult<AuthorizationPolicy?>(
            new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .AddRequirements(
                    new PermissionRequirement(permissionCode))
                .Build());
    }
}

public sealed class AnyPermissionAuthorizationHandler
    : AuthorizationHandler<AnyPermissionRequirement>
{
    private readonly IPermissionService _permissions;

    public AnyPermissionAuthorizationHandler(IPermissionService permissions)
    {
        _permissions = permissions;
    }

    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        AnyPermissionRequirement requirement)
    {
        var userIdValue = context.User.FindFirstValue(
            ClaimTypes.NameIdentifier);
        if (!int.TryParse(userIdValue, out var userId))
            return;

        foreach (var permissionCode in requirement.PermissionCodes)
        {
            if (await _permissions.HasPermissionAsync(
                    userId,
                    permissionCode))
            {
                context.Succeed(requirement);
                return;
            }
        }
    }
}

public interface IPermissionService
{
    Task<UserPermissionSnapshot?> GetSnapshotAsync(
        int userId,
        CancellationToken cancellationToken = default);

    Task<bool> HasPermissionAsync(
        int userId,
        string permissionCode,
        CancellationToken cancellationToken = default);
}

public sealed record UserPermissionSnapshot(
    int UserId,
    string Email,
    string RoleCode,
    string RoleName,
    bool IsActive,
    IReadOnlyCollection<EffectivePermission> Permissions);

public sealed record EffectivePermission(
    int PermissionId,
    string Code,
    string DisplayName,
    string Module,
    string? Description);

public sealed class PermissionService : IPermissionService
{
    private readonly PhenyoSyncDbContext _context;
    private UserPermissionSnapshot? _snapshot;
    private int? _snapshotUserId;

    public PermissionService(PhenyoSyncDbContext context)
    {
        _context = context;
    }

    public async Task<UserPermissionSnapshot?> GetSnapshotAsync(
        int userId,
        CancellationToken cancellationToken = default)
    {
        // One PermissionService instance serves one web request, so caching the
        // same user's snapshot avoids repeating the role/permission query.
        if (_snapshotUserId == userId)
        {
            return _snapshot;
        }

        var user = await _context.Users
            .AsNoTracking()
            .Include(item => item.Role)
                .ThenInclude(role => role!.RolePermissions)
                    .ThenInclude(mapping => mapping.Permission)
            .SingleOrDefaultAsync(
                item => item.UserId == userId,
                cancellationToken);

        _snapshotUserId = userId;
        if (user is null)
        {
            _snapshot = null;
            return null;
        }

        var roleCode = RoleCodes.Normalize(user.Role?.RoleCode);
        // Normalization keeps legacy database labels compatible while the
        // application works with one canonical role code.
        var mappings = user.Role?.RolePermissions
            .Where(mapping => mapping.Permission is { IsActive: true }) ?? [];
        if (SecurityRoleMatrix.Assignments.TryGetValue(
                roleCode,
                out var rolePermissionBoundary))
        {
            // Database assignments cannot expand a protected system role past
            // the reviewed code matrix. The backend remains authoritative even
            // if a navigation item is accidentally shown in the browser.
            mappings = mappings.Where(mapping =>
                rolePermissionBoundary.Contains(
                    mapping.Permission!.PermissionCode,
                    StringComparer.OrdinalIgnoreCase));
        }

        var effectivePermissions = mappings
            // Only active, matrix-approved permissions reach controllers.
            .Select(mapping => new EffectivePermission(
                mapping.PermissionId,
                mapping.Permission!.PermissionCode,
                mapping.Permission.DisplayName,
                mapping.Permission.Module,
                mapping.Permission.Description))
            .ToList();

        // Buying Lists is part of the reviewed Super Admin baseline. Some older
        // databases pre-date that role mapping, so restore only these existing
        // permission records at runtime until the prepared migration is applied.
        if (roleCode == RoleCodes.Admin)
        {
            var requiredCodes = new[]
            {
                Permissions.BuyingLists.View,
                Permissions.BuyingLists.ViewAll
            };
            var missingCodes = requiredCodes
                .Where(code => effectivePermissions.All(item =>
                    !item.Code.Equals(code, StringComparison.OrdinalIgnoreCase)))
                .ToArray();
            if (missingCodes.Length > 0)
            {
                effectivePermissions.AddRange(await _context.Permissions
                    .AsNoTracking()
                    .Where(permission =>
                        permission.IsActive &&
                        missingCodes.Contains(permission.PermissionCode))
                    .Select(permission => new EffectivePermission(
                        permission.PermissionId,
                        permission.PermissionCode,
                        permission.DisplayName,
                        permission.Module,
                        permission.Description))
                    .ToListAsync(cancellationToken));
            }
        }

        _snapshot = new UserPermissionSnapshot(
            user.UserId,
            user.Email,
            roleCode,
            RoleCodes.Normalize(user.Role?.RoleName),
            user.Role is { IsActive: true } &&
            string.Equals(
                user.Status,
                "Active",
                StringComparison.OrdinalIgnoreCase),
            effectivePermissions);

        return _snapshot;
    }

    public async Task<bool> HasPermissionAsync(
        int userId,
        string permissionCode,
        CancellationToken cancellationToken = default)
    {
        var snapshot = await GetSnapshotAsync(userId, cancellationToken);
        return snapshot is { IsActive: true } &&
            snapshot.Permissions.Any(item =>
                string.Equals(
                    item.Code,
                    permissionCode,
                    StringComparison.OrdinalIgnoreCase));
    }
}

public sealed class PermissionAuthorizationHandler
    : AuthorizationHandler<PermissionRequirement>
{
    private readonly IPermissionService _permissions;

    public PermissionAuthorizationHandler(
        IPermissionService permissions)
    {
        _permissions = permissions;
    }

    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        PermissionRequirement requirement)
    {
        var userIdValue = context.User.FindFirstValue(
            ClaimTypes.NameIdentifier);

        if (int.TryParse(userIdValue, out var userId) &&
            await _permissions.HasPermissionAsync(
                userId,
                requirement.PermissionCode))
        {
            context.Succeed(requirement);
        }
    }
}

public sealed class ApiAuthorizationResultHandler
    : IAuthorizationMiddlewareResultHandler
{
    private readonly AuthorizationMiddlewareResultHandler _fallback = new();

    public async Task HandleAsync(
        RequestDelegate next,
        HttpContext context,
        AuthorizationPolicy policy,
        PolicyAuthorizationResult authorizeResult)
    {
        if (authorizeResult.Succeeded)
        {
            await _fallback.HandleAsync(
                next,
                context,
                policy,
                authorizeResult);
            return;
        }

        var statusCode = authorizeResult.Challenged
            ? StatusCodes.Status401Unauthorized
            : StatusCodes.Status403Forbidden;
        var message = statusCode == StatusCodes.Status401Unauthorized
            ? "Sign in to continue."
            : "You do not have permission to perform this action.";
        var code = statusCode == StatusCodes.Status401Unauthorized
            ? "AUTHENTICATION_REQUIRED"
            : "PERMISSION_DENIED";

        context.Response.StatusCode = statusCode;
        context.Response.ContentType = "application/json";
        await context.Response.WriteAsJsonAsync(
            ApiResponses.Error(context, message, code));
    }
}
