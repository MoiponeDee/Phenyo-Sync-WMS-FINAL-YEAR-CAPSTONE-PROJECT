namespace PhenyoSyncAPI.Security;

/// <summary>
/// Canonical permission codes shared by policies, role defaults and navigation responses.
/// Persisted codes remain stable even when the user-facing label changes.
/// </summary>
public static class Permissions
{
    public static class Users
    {
        public const string View = "Users.View";
        public const string Create = "Users.Create";
        public const string Update = "Users.Update";
        public const string Deactivate = "Users.Deactivate";
        public const string Reactivate = "Users.Reactivate";
        public const string AssignRole = "Users.AssignRole";
        public const string TriggerPasswordReset = "Users.TriggerPasswordReset";
        public const string ViewEffectivePermissions = "Users.ViewEffectivePermissions";
    }

    public static class Roles
    {
        public const string View = "Roles.View";
        public const string Create = "Roles.Create";
        public const string Update = "Roles.Update";
        public const string Deactivate = "Roles.Deactivate";
        public const string Delete = "Roles.Delete";
        public const string AssignPermissions = "Roles.AssignPermissions";
    }

    public static class PermissionDefinitions
    {
        public const string View = "Permissions.View";
        public const string Create = "Permissions.Create";
        public const string Update = "Permissions.Update";
        public const string Deactivate = "Permissions.Deactivate";
        public const string Delete = "Permissions.Delete";
    }

    public static class Products
    {
        public const string View = "Products.View";
        public const string Make = "Products.Make";
        public const string Update = "Products.Update";
        public const string Delete = "Products.Delete";
        public const string ChangeStatus = "Products.ChangeStatus";
    }

    public static class ProductTypes
    {
        public const string View = "ProductTypes.View";
        public const string Manage = "ProductTypes.Manage";
    }

    public static class ProductCategories
    {
        public const string View = "ProductCategories.View";
        public const string Manage = "ProductCategories.Manage";
    }

    public static class Stock
    {
        public const string View = "Stock.View";
        public const string Take = "Stock.Take";
        public const string Adjust = "Stock.Adjust";
        public const string WriteOff = "Stock.WriteOff";
    }

    public static class Expiry
    {
        public const string View = "Expiry.View";
        public const string Resolve = "Expiry.Resolve";
    }

    public static class Labels
    {
        public const string Print = "Labels.Print";
    }

    public static class Customers
    {
        public const string View = "Customers.View";
        public const string Manage = "Customers.Manage";
    }

    public static class Suppliers
    {
        public const string View = "Suppliers.View";
        public const string Manage = "Suppliers.Manage";
    }

    public static class Orders
    {
        public const string View = "Orders.View";
        public const string Create = "Orders.Create";
        public const string Update = "Orders.Update";
        public const string Validate = "Orders.Validate";
        public const string Confirm = "Orders.Confirm";
        public const string Cancel = "Orders.Cancel";
        public const string ChangeStatus = "Orders.ChangeStatus";
        public const string SendLink = "Orders.SendLink";
    }

    public static class Packing
    {
        public const string View = "Packing.View";
        public const string Confirm = "Packing.Confirm";
    }

    public static class Invoices
    {
        public const string View = "Invoices.View";
    }

    public static class Payments
    {
        public const string View = "Payments.View";
        public const string Capture = "Payments.Capture";
        public const string Confirm = "Payments.Confirm";
        public const string Reverse = "Payments.Reverse";
    }

    public static class Pricing
    {
        public const string View = "Pricing.View";
        public const string Create = "Pricing.Create";
        public const string Cancel = "Pricing.Cancel";
        public const string ViewHistory = "Pricing.ViewHistory";
        public const string Manage = "Pricing.Manage";
    }

    public static class Deliveries
    {
        public const string View = "Deliveries.View";
        public const string ViewOwn = "Deliveries.ViewOwn";
        public const string AssignDriver = "Deliveries.AssignDriver";
        public const string ReassignDriver = "Deliveries.ReassignDriver";
        public const string CompleteOwn = "Deliveries.CompleteOwn";
        public const string CompleteAny = "Deliveries.CompleteAny";
        public const string ViewProof = "Deliveries.ViewProof";
    }

    public static class AuditLogs
    {
        public const string View = "AuditLogs.View";
    }

    public static class Help
    {
        public const string View = "Help.View";
        public const string Manage = "Help.Manage";
    }

    public static class HelpMedia
    {
        public const string Manage = "HelpMedia.Manage";
    }

    public static class Lookups
    {
        public const string View = "Lookups.View";
        public const string Manage = "Lookups.Manage";
    }

    public static class WarehouseSections
    {
        public const string View = "WarehouseSections.View";
        public const string Manage = "WarehouseSections.Manage";
    }

    public static class SystemSettings
    {
        public const string View = "SystemSettings.View";
        public const string Manage = "SystemSettings.Manage";
    }

    public static class ProductHierarchy
    {
        public const string View = "ProductHierarchy.View";
        public const string Manage = "ProductHierarchy.Manage";
    }

    public static class ProductDataExchange
    {
        public const string Export = "ProductDataExchange.Export";
        public const string Import = "ProductDataExchange.Import";
    }

    public static class StockCountExchange
    {
        public const string Export = "StockCountExchange.Export";
        public const string Import = "StockCountExchange.Import";
    }

    public static class OperationsCalendar
    {
        public const string View = "OperationsCalendar.View";
    }

    public static class ProductBatchScanner
    {
        public const string View = "ProductBatchScanner.View";
    }

    public static class BuyingLists
    {
        public const string View = "BuyingList.View";
        public const string ViewAll = "BuyingList.ViewAll";
        public const string Create = "BuyingList.Create";
        public const string UpdateDraft = "BuyingList.UpdateDraft";
        public const string DeleteDraft = "BuyingList.DeleteDraft";
        public const string Assign = "BuyingList.Assign";
        public const string Publish = "BuyingList.Publish";
        public const string Cancel = "BuyingList.Cancel";
    }

    public static class Mobile
    {
        public const string Access = "Mobile.Access";
        public const string DeliveryViewOwn = "Mobile.Delivery.ViewOwn";
        public const string DeliveryViewAll = "Mobile.Delivery.ViewAll";
        public const string DeliveryUpdateOwn = "Mobile.Delivery.UpdateOwn";
        public const string DeliveryCompleteOwn = "Mobile.Delivery.CompleteOwn";
        public const string DeliveryUploadProof = "Mobile.Delivery.UploadProof";
        public const string BuyingListView = "Mobile.BuyingList.View";
        public const string BuyingListViewAll = "Mobile.BuyingList.ViewAll";
        public const string BuyingListCreate = "Mobile.BuyingList.Create";
        public const string BuyingListUpdate = "Mobile.BuyingList.Update";
        public const string BuyingListSubmit = "Mobile.BuyingList.Submit";
        public const string BuyingListAssign = "Mobile.BuyingList.Assign";
        public const string BuyingListAddPromotionalItem =
            "Mobile.BuyingList.AddPromotionalItem";
        public const string BuyingListUploadDocket =
            "Mobile.BuyingList.UploadDocket";
        public const string StockReceiptView = "Mobile.StockReceipt.View";
        public const string StockReceiptCreate = "Mobile.StockReceipt.Create";
        public const string StockReceiptSubmit = "Mobile.StockReceipt.Submit";
        public const string StockReceiptUploadDocket =
            "Mobile.StockReceipt.UploadDocket";
        public const string PackingView = "Mobile.Packing.View";
        public const string PackingScan = "Mobile.Packing.Scan";
        public const string PackingRemoveScan = "Mobile.Packing.RemoveScan";
        public const string PackingComplete = "Mobile.Packing.Complete";
        public const string DispatchView = "Mobile.Dispatch.View";
        public const string DispatchConfirm = "Mobile.Dispatch.Confirm";
        public const string DispatchReject = "Mobile.Dispatch.Reject";
        public const string TrackingShareOwn = "Mobile.Tracking.ShareOwn";
        public const string TrackingViewOwn = "Mobile.Tracking.ViewOwn";
        public const string TrackingViewAll = "Mobile.Tracking.ViewAll";
        public const string TrackingManage = "Mobile.Tracking.Manage";
        public const string WriteOffView = "Mobile.WriteOff.View";
        public const string WriteOffCreate = "Mobile.WriteOff.Create";
        public const string WriteOffComplete = "Mobile.WriteOff.Complete";
        public const string WriteOffApprove = "Mobile.WriteOff.Approve";
        public const string WriteOffReject = "Mobile.WriteOff.Reject";
        public const string WriteOffOverride = "Mobile.WriteOff.Override";
        public const string WriteOffUploadEvidence =
            "Mobile.WriteOff.UploadEvidence";
        public const string WriteOffViewFinancialImpact =
            "Mobile.WriteOff.ViewFinancialImpact";
        public const string DeviceManagementView =
            "Mobile.DeviceManagement.View";
        public const string DeviceManagementManage =
            "Mobile.DeviceManagement.Manage";
        public const string NotificationView = "Mobile.Notification.View";
        public const string ProfileView = "Mobile.Profile.View";
        public const string HelpView = "Mobile.Help.View";
    }

    public static class Notifications
    {
        public const string View = "Notifications.View";
        public const string ManagePreferences = "Notifications.ManagePreferences";
        public const string ManageRules = "Notifications.ManageRules";
        public const string ViewDeliveryHistory =
            "Notifications.ViewDeliveryHistory";
        public const string SendTest = "Notifications.SendTest";
    }

    public static class RawStock
    {
        public const string View = "RawStock.View";
        public const string Manage = "RawStock.Manage";
        public const string Receive = "RawStock.Receive";
        public const string WriteOff = "RawStock.WriteOff";
        public const string ApproveWriteOff = "RawStock.ApproveWriteOff";
    }

    public static class RawStockTakes
    {
        public const string View = "RawStockTakes.View";
        public const string Capture = "RawStockTakes.Capture";
        public const string Review = "RawStockTakes.Review";
        public const string Approve = "RawStockTakes.Approve";
    }

    public static class OperationalReasons
    {
        public const string View = "OperationalReasons.View";
        public const string Manage = "OperationalReasons.Manage";
    }

    public static class SupplierOrders
    {
        public const string View = "SupplierOrders.View";
        public const string Manage = "SupplierOrders.Manage";
    }

    public static class CustomerPayments
    {
        public const string View = "CustomerPayments.View";
        public const string Capture = "CustomerPayments.Capture";
        public const string Reverse = "CustomerPayments.Reverse";
        public const string ApproveReversal = "CustomerPayments.ApproveReversal";
    }

    public static class SupplierPayments
    {
        public const string View = "SupplierPayments.View";
        public const string Capture = "SupplierPayments.Capture";
        public const string Reverse = "SupplierPayments.Reverse";
        public const string ApproveReversal = "SupplierPayments.ApproveReversal";
    }

    public static class Reconciliation
    {
        public const string View = "Reconciliation.View";
        public const string Manage = "Reconciliation.Manage";
    }

    public static class Dashboards
    {
        public const string View = "Dashboards.View";
    }

    public static class Reports
    {
        public const string View = "Reports.View";
        public const string InventoryView = "Reports.Inventory.View";
        public const string InventoryExportPdf = "Reports.Inventory.ExportPdf";
        public const string SalesView = "Reports.Sales.View";
        public const string SalesExportPdf = "Reports.Sales.ExportPdf";
        public const string FinancialView = "Reports.Financial.View";
        public const string FinancialViewCost = "Reports.Financial.ViewCost";
        public const string FinancialExportPdf = "Reports.Financial.ExportPdf";
        public const string FinancialViewReversalHistory =
            "Reports.Financial.ViewReversalHistory";
        public const string StockMovementView = "Reports.StockMovement.View";
        public const string StockMovementViewCost =
            "Reports.StockMovement.ViewCost";
        public const string StockMovementExportPdf =
            "Reports.StockMovement.ExportPdf";
        public const string ExpiryWasteView = "Reports.ExpiryWaste.View";
        public const string ExpiryWasteViewCost =
            "Reports.ExpiryWaste.ViewCost";
        public const string ExpiryWasteExportPdf =
            "Reports.ExpiryWaste.ExportPdf";
        public const string PricingView = "Reports.Pricing.View";
        public const string PricingExportPdf = "Reports.Pricing.ExportPdf";
        public const string MarkupView = "Reports.Markup.View";
        public const string MarkupViewCost = "Reports.Markup.ViewCost";
        public const string MarkupExportPdf = "Reports.Markup.ExportPdf";
    }

    public static class ManagementDashboard
    {
        public const string View = "ManagementDashboard.View";
    }

    public static IReadOnlyList<PermissionDefinition> Catalog { get; } =
    [
        P(Users.View, "View users", "Security"),
        P(Users.Create, "Create users", "Security"),
        P(Users.Update, "Update users", "Security"),
        P(Users.Deactivate, "Deactivate users", "Security"),
        P(Users.Reactivate, "Reactivate users", "Security"),
        P(Users.AssignRole, "Assign user roles", "Security"),
        P(Users.TriggerPasswordReset, "Trigger secure password reset", "Security"),
        P(Users.ViewEffectivePermissions, "View effective permissions", "Security"),
        P(Roles.View, "View roles", "Security"),
        P(Roles.Create, "Create roles", "Security"),
        P(Roles.Update, "Update roles", "Security"),
        P(Roles.Deactivate, "Deactivate roles", "Security"),
        P(Roles.Delete, "Delete unused custom roles", "Security"),
        P(Roles.AssignPermissions, "Assign role permissions", "Security"),
        P(PermissionDefinitions.View, "View permission definitions", "Security"),
        P(PermissionDefinitions.Create, "Create permission definitions", "Security"),
        P(PermissionDefinitions.Update, "Update permission definitions", "Security"),
        P(PermissionDefinitions.Deactivate, "Deactivate permission definitions", "Security"),
        P(PermissionDefinitions.Delete, "Delete unused custom permissions", "Security"),
        P(Products.View, "View products", "Product"),
        P(Products.Make, "Make products", "Product"),
        P(Products.Update, "Update products", "Product"),
        P(Products.Delete, "Delete or deactivate products", "Product"),
        P(Products.ChangeStatus, "Change product status", "Product"),
        P(ProductTypes.View, "View product types", "Product"),
        P(ProductTypes.Manage, "Manage product types", "Product"),
        P(ProductCategories.View, "View product categories", "Product"),
        P(ProductCategories.Manage, "Manage product categories", "Product"),
        P(Stock.View, "View stock", "Stock"),
        P(Stock.Take, "Perform stock takes", "Stock"),
        P(Stock.Adjust, "Adjust stock", "Stock"),
        P(Stock.WriteOff, "Write off stock", "Stock"),
        P(Expiry.View, "View expiry information", "Stock"),
        P(Expiry.Resolve, "Resolve expiry alerts", "Stock"),
        P(Labels.Print, "Print product and batch labels", "Product"),
        P(Customers.View, "View customers", "Orders"),
        P(Customers.Manage, "Manage customers", "Orders"),
        P(Suppliers.View, "View suppliers", "Suppliers"),
        P(Suppliers.Manage, "Manage suppliers", "Suppliers"),
        P(Orders.View, "View orders", "Orders"),
        P(Orders.Create, "Create orders", "Orders"),
        P(Orders.Update, "Update orders", "Orders"),
        P(Orders.Validate, "Validate orders", "Orders"),
        P(Orders.Confirm, "Confirm orders", "Orders"),
        P(Orders.Cancel, "Cancel orders", "Orders"),
        P(Orders.ChangeStatus, "Change order status", "Orders"),
        P(Orders.SendLink, "Share customer order form", "Orders"),
        P(Packing.View, "View packing lists", "Packing"),
        P(Packing.Confirm, "Confirm packing", "Packing"),
        P(Invoices.View, "View invoices", "Orders"),
        P(Payments.View, "View payments", "Payments"),
        P(Payments.Capture, "Capture payments", "Payments"),
        P(Payments.Confirm, "Confirm payments", "Payments"),
        P(Payments.Reverse, "Reverse payments", "Payments"),
        P(Pricing.View, "View pricing", "Pricing"),
        P(Pricing.Create, "Create price versions", "Pricing"),
        P(Pricing.Cancel, "Cancel eligible price versions", "Pricing"),
        P(Pricing.ViewHistory, "View price history", "Pricing"),
        P(Pricing.Manage, "Manage pricing", "Pricing"),
        P(Deliveries.View, "View deliveries", "Delivery"),
        P(Deliveries.ViewOwn, "View own deliveries", "Delivery"),
        P(Deliveries.AssignDriver, "Assign drivers", "Delivery"),
        P(Deliveries.ReassignDriver, "Reassign drivers", "Delivery"),
        P(Deliveries.CompleteOwn, "Complete own delivery", "Delivery"),
        P(Deliveries.CompleteAny, "Complete delivery on behalf", "Delivery"),
        P(Deliveries.ViewProof, "View proof of delivery", "Delivery"),
        P(AuditLogs.View, "View audit logs", "Audit"),
        P(Help.View, "View Help and user guidance", "Help"),
        P(Help.Manage, "Manage Help categories and topics", "Help"),
        P(HelpMedia.Manage, "Manage Help training media", "Help"),
        P(Lookups.View, "View operational lookup values", "Configuration"),
        P(Lookups.Manage, "Manage operational lookup values", "Configuration"),
        P(WarehouseSections.View, "View warehouse sections", "Configuration"),
        P(WarehouseSections.Manage, "Manage warehouse sections", "Configuration"),
        P(SystemSettings.View, "View configurable business rules", "Configuration"),
        P(SystemSettings.Manage, "Manage configurable business rules", "Configuration"),
        P(ProductHierarchy.View, "View the product hierarchy", "Product"),
        P(ProductHierarchy.Manage, "Manage the product hierarchy", "Product"),
        P(ProductDataExchange.Export, "Export Product and Price workbooks", "DataExchange"),
        P(ProductDataExchange.Import, "Validate and import Product and Price workbooks", "DataExchange"),
        P(StockCountExchange.Export, "Export Stock Count JSON packages", "DataExchange"),
        P(StockCountExchange.Import, "Validate and import Stock Count JSON packages", "DataExchange"),
        P(OperationsCalendar.View, "View the Operations Calendar", "Operations"),
        P(ProductBatchScanner.View, "Resolve Product Batch QR codes", "Product"),
        P(BuyingLists.View, "View Buying Lists", "BuyingList"),
        P(BuyingLists.ViewAll, "View all Buying Lists", "BuyingList"),
        P(BuyingLists.Create, "Create Buying Lists", "BuyingList"),
        P(BuyingLists.UpdateDraft, "Update draft Buying Lists", "BuyingList"),
        P(BuyingLists.DeleteDraft, "Remove draft Buying List lines", "BuyingList"),
        P(BuyingLists.Assign, "Assign Buying Lists", "BuyingList"),
        P(BuyingLists.Publish, "Publish Buying Lists", "BuyingList"),
        P(BuyingLists.Cancel, "Cancel Buying Lists", "BuyingList"),
        P(Mobile.Access, "Access PhenyoSync Mobile", "Mobile"),
        P(Mobile.DeliveryViewOwn, "View own mobile deliveries", "Mobile"),
        P(Mobile.DeliveryViewAll, "View all mobile deliveries", "Mobile"),
        P(Mobile.DeliveryUpdateOwn, "Update own mobile delivery", "Mobile"),
        P(Mobile.DeliveryCompleteOwn, "Complete own mobile delivery", "Mobile"),
        P(Mobile.DeliveryUploadProof, "Upload mobile delivery proof", "Mobile"),
        P(Mobile.BuyingListView, "View mobile buying lists", "Mobile"),
        P(Mobile.BuyingListViewAll, "View all mobile buying lists", "Mobile"),
        P(Mobile.BuyingListCreate, "Create mobile buying lists", "Mobile"),
        P(Mobile.BuyingListUpdate, "Update mobile buying lists", "Mobile"),
        P(Mobile.BuyingListSubmit, "Submit mobile buying lists", "Mobile"),
        P(Mobile.BuyingListAssign, "Assign mobile buying lists", "Mobile"),
        P(Mobile.BuyingListAddPromotionalItem, "Add promotional buying items", "Mobile"),
        P(Mobile.BuyingListUploadDocket, "Upload buying-list dockets", "Mobile"),
        P(Mobile.StockReceiptView, "View mobile stock receipts", "Mobile"),
        P(Mobile.StockReceiptCreate, "Create mobile stock receipts", "Mobile"),
        P(Mobile.StockReceiptSubmit, "Submit mobile stock receipts", "Mobile"),
        P(Mobile.StockReceiptUploadDocket, "Upload stock-receipt dockets", "Mobile"),
        P(Mobile.PackingView, "View mobile packing work", "Mobile"),
        P(Mobile.PackingScan, "Scan packed Product Batches", "Mobile"),
        P(Mobile.PackingRemoveScan, "Correct packing scans", "Mobile"),
        P(Mobile.PackingComplete, "Complete mobile packing", "Mobile"),
        P(Mobile.DispatchView, "View dispatch queue", "Mobile"),
        P(Mobile.DispatchConfirm, "Confirm order dispatch", "Mobile"),
        P(Mobile.DispatchReject, "Reject or return packed orders", "Mobile"),
        P(Mobile.TrackingShareOwn, "Share own delivery location", "Mobile"),
        P(Mobile.TrackingViewOwn, "View own delivery tracking", "Mobile"),
        P(Mobile.TrackingViewAll, "View all delivery tracking", "Mobile"),
        P(Mobile.TrackingManage, "Manage delivery tracking", "Mobile"),
        P(Mobile.WriteOffView, "View mobile stock write-offs", "Mobile"),
        P(Mobile.WriteOffCreate, "Create mobile stock write-offs", "Mobile"),
        P(Mobile.WriteOffComplete, "Complete ordinary stock write-offs", "Mobile"),
        P(Mobile.WriteOffApprove, "Approve stock write-offs", "Mobile"),
        P(Mobile.WriteOffReject, "Reject stock write-offs", "Mobile"),
        P(Mobile.WriteOffOverride, "Override stock write-off rules", "Mobile"),
        P(Mobile.WriteOffUploadEvidence, "Upload stock write-off evidence", "Mobile"),
        P(Mobile.WriteOffViewFinancialImpact, "View write-off financial impact", "Mobile"),
        P(Mobile.DeviceManagementView, "View registered mobile devices", "Mobile"),
        P(Mobile.DeviceManagementManage, "Manage registered mobile devices", "Mobile"),
        P(Mobile.NotificationView, "View the mobile notification centre", "Mobile"),
        P(Mobile.ProfileView, "View the mobile profile", "Mobile"),
        P(Mobile.HelpView, "View mobile Help", "Mobile"),
        P(Notifications.View, "View operational notifications", "Notifications"),
        P(Notifications.ManagePreferences, "Manage notification preferences", "Notifications"),
        P(Notifications.ManageRules, "Manage notification rules", "Notifications"),
        P(Notifications.ViewDeliveryHistory, "View notification delivery history", "Notifications"),
        P(Notifications.SendTest, "Send test notifications", "Notifications"),
        P(RawStock.View, "View raw stock", "RawStock"),
        P(RawStock.Manage, "Create and maintain raw-stock items", "RawStock"),
        P(RawStock.Receive, "Receive raw stock into warehouse balances", "RawStock"),
        P(RawStock.WriteOff, "Submit raw-stock write-offs", "RawStock"),
        P(RawStock.ApproveWriteOff, "Approve raw-stock write-offs", "RawStock"),
        P(RawStockTakes.View, "View raw-stock takes", "RawStock"),
        P(RawStockTakes.Capture, "Capture and submit raw-stock takes", "RawStock"),
        P(RawStockTakes.Review, "Review raw-stock takes", "RawStock"),
        P(RawStockTakes.Approve, "Approve raw-stock-take adjustments", "RawStock"),
        P(OperationalReasons.View, "View operational reasons", "Configuration"),
        P(OperationalReasons.Manage, "Manage operational reasons", "Configuration"),
        P(SupplierOrders.View, "View supplier orders", "Suppliers"),
        P(SupplierOrders.Manage, "Create and maintain supplier orders", "Suppliers"),
        P(CustomerPayments.View, "View customer payments", "Payments"),
        P(CustomerPayments.Capture, "Capture customer payments", "Payments"),
        P(CustomerPayments.Reverse, "Request customer-payment reversal", "Payments"),
        P(CustomerPayments.ApproveReversal, "Approve customer-payment reversal", "Payments"),
        P(SupplierPayments.View, "View supplier payments", "Payments"),
        P(SupplierPayments.Capture, "Capture supplier payments", "Payments"),
        P(SupplierPayments.Reverse, "Request supplier-payment reversal", "Payments"),
        P(SupplierPayments.ApproveReversal, "Approve supplier-payment reversal", "Payments"),
        P(Reconciliation.View, "View raw-stock reconciliation mappings", "RawStock"),
        P(Reconciliation.Manage, "Manage raw-stock reconciliation mappings", "RawStock"),
        P(Dashboards.View, "View the role-sensitive operational dashboard", "Dashboard"),
        P(Reports.View, "Open Reports and Analytics", "Reports"),
        P(Reports.InventoryView, "View the Inventory Position Report", "Reports"),
        P(Reports.InventoryExportPdf, "Export the Inventory Position Report PDF", "Reports"),
        P(Reports.SalesView, "View the Sales by Customer and Product Report", "Reports"),
        P(Reports.SalesExportPdf, "Export the Sales Report PDF", "Reports"),
        P(Reports.FinancialView, "View the Financial Activity Report", "Reports"),
        P(Reports.FinancialViewCost, "View financial report cost values", "Reports"),
        P(Reports.FinancialExportPdf, "Export the Financial Activity Report PDF", "Reports"),
        P(Reports.FinancialViewReversalHistory, "View reversed and voided financial activity", "Reports"),
        P(Reports.StockMovementView, "View the Stock Movement Report", "Reports"),
        P(Reports.StockMovementViewCost, "View stock movement cost values", "Reports"),
        P(Reports.StockMovementExportPdf, "Export the Stock Movement Report PDF", "Reports"),
        P(Reports.ExpiryWasteView, "View the Expiry and Waste Risk Report", "Reports"),
        P(Reports.ExpiryWasteViewCost, "View expiry and waste cost values", "Reports"),
        P(Reports.ExpiryWasteExportPdf, "Export the Expiry and Waste Report PDF", "Reports"),
        P(Reports.PricingView, "View the Product Pricing Analysis Report", "Reports"),
        P(Reports.PricingExportPdf, "Export the Product Pricing Analysis Report PDF", "Reports"),
        P(Reports.MarkupView, "View the Product Markup and Gross Margin Report", "Reports"),
        P(Reports.MarkupViewCost, "View markup report cost values", "Reports"),
        P(Reports.MarkupExportPdf, "Export the Product Markup and Gross Margin Report PDF", "Reports"),
        P(ManagementDashboard.View, "View management operational dashboard", "Dashboard")
    ];

    private static PermissionDefinition P(
        string code,
        string displayName,
        string module) =>
        new(code, displayName, module);
}

public sealed record PermissionDefinition(
    string Code,
    string DisplayName,
    string Module);
