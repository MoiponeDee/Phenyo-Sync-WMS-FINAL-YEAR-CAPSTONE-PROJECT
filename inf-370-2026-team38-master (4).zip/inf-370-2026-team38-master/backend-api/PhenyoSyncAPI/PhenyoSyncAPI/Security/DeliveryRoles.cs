namespace PhenyoSyncAPI.Security;

public static class DeliveryRoles
{
    public const string Managers =
        "WarehouseManager,BusinessManager,OperationsManager";
    public const string ManagementAndDrivers =
        "WarehouseManager,BusinessManager,OperationsManager,Driver";
    public const string CompleteAny = "WarehouseManager";
    public const string Drivers = "Driver";
}
