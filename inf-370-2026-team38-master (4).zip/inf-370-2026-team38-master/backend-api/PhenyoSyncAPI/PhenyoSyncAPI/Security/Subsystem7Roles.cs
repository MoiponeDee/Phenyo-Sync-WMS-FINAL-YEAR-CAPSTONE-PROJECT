namespace PhenyoSyncAPI.Security
{
    public static class Subsystem7Roles
    {
        public const string Readers =
            "Packer,WarehouseManager,Admin,BusinessManager,OperationsManager";

        public const string ProductManagers =
            "WarehouseManager,Admin";

        public const string ExpiryDecisionMakers =
            "WarehouseManager,OperationsManager";
    }
}
