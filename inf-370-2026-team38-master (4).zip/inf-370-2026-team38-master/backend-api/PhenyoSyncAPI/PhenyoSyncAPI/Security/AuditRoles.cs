namespace PhenyoSyncAPI.Security;

public static class AuditRoles
{
    public const string Viewers = "OperationsManager,Admin";
}
