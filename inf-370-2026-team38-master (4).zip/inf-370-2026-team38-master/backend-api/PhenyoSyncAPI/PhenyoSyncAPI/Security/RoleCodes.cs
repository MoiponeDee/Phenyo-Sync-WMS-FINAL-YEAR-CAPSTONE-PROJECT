namespace PhenyoSyncAPI.Security;

// Maps friendly UI choices to existing roles without persisting SuperAdmin.
public static class RoleCodes
{
    public const string Admin = "Admin";
    public const string AdminClerk = "AdminClerk";
    public const string LegacyAdminClerk = AdminClerk;
    public const string Packer = "Packer";
    public const string Driver = "Driver";
    public const string MarketBuyer = "MarketBuyer";
    public const string WarehouseManager = "WarehouseManager";
    public const string OperationsManager = "OperationsManager";
    public const string BusinessManager = "BusinessManager";

    public const string LegacyStockTaker = "StockTaker";
    public const string LegacyCeo = "CEO";
    public const string LegacyCoo = "COO";

    public static readonly IReadOnlySet<string> SystemRoles =
        new HashSet<string>(
            [
                Admin,
                AdminClerk,
                Packer,
                Driver,
                MarketBuyer,
                WarehouseManager,
                OperationsManager
            ],
            StringComparer.OrdinalIgnoreCase);

    public static readonly IReadOnlySet<string> SecurityManagers =
        new HashSet<string>(
            [Admin, AdminClerk],
            StringComparer.OrdinalIgnoreCase);

    public static string Normalize(string? value)
    {
        var role = value?.Trim() ?? string.Empty;
        if (string.Equals(role, LegacyStockTaker, StringComparison.OrdinalIgnoreCase))
            return WarehouseManager;
        if (string.Equals(role, LegacyCeo, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(role, LegacyCoo, StringComparison.OrdinalIgnoreCase))
            return OperationsManager;
        if (string.Equals(role, BusinessManager, StringComparison.OrdinalIgnoreCase))
            return Admin;
        return role;
    }
}
