namespace PhenyoSyncAPI.Configuration;

public sealed record HelpCategorySeed(
    int Id,
    string Code,
    string Name,
    string Description,
    int SortOrder);

public sealed record HelpTopicSeed(
    int Id,
    int CategoryId,
    string Slug,
    string Title,
    string Summary,
    string Body,
    string Keywords,
    string AudienceRoles,
    bool IsPublic,
    int SortOrder);

public sealed record HelpContextSeed(
    int Id,
    int TopicId,
    string RoutePattern,
    string ComponentKey,
    int Priority);

/// <summary>Declares security, help and media configuration definitions for controlled seeding.</summary>
public static class PhaseA3Catalog
{
    public static readonly DateTime SeededAtUtc =
        new(2026, 7, 24, 0, 0, 0, DateTimeKind.Utc);

    private const string AllRoles =
        "OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer";
    private const string Management =
        "OperationsManager,BusinessManager,Admin,WarehouseManager";

    public static IReadOnlyList<HelpCategorySeed> HelpCategories { get; } =
    [
        new(1, "GETTING_STARTED", "Getting started", "Sign-in, security, navigation and account recovery.", 10),
        new(2, "SECURITY_ADMIN", "Users and security", "User, role, permission and security administration.", 20),
        new(3, "PRODUCT_STOCK", "Products and stock", "Product, batch, stock, expiry and label workflows.", 30),
        new(4, "CONFIGURATION", "Configuration", "Lookups, warehouse sections and runtime business settings.", 40),
        new(5, "ORDERS", "Customers and orders", "Customers, orders, reservations, packing and invoices.", 50),
        new(6, "PRICING_AUDIT", "Pricing and accountability", "Price history and audit-log workflows.", 60),
        new(7, "DELIVERY", "Logistics and delivery", "Driver assignment, delivery completion and proof images.", 70),
        new(8, "TROUBLESHOOTING", "Troubleshooting", "Common validation, access, email and file problems.", 80),
        new(9, "REPORTING", "Reports and analytics", "Formal operational, transactional, financial and pricing reports.", 90)
    ];

    public static IReadOnlyList<HelpTopicSeed> HelpTopics { get; } =
    [
        T(1, 1, "getting-started", "Getting started with PhenyoSync",
            "Learn the main navigation, role dashboards and safe sign-out workflow.",
            """
            # Getting started
            Sign in with the email address assigned to your user account. PhenyoSync opens the dashboard and actions permitted by your role and permissions.

            Use the persistent Help action for guidance on the page you are viewing. Navigation cards and side menus only show authorized workflows. Always sign out when leaving a shared device.

            Management users administer users and configuration. Admin handles operational administration. Packers prepare products and orders, Warehouse Managers control stock and expiry, and Drivers access only their assigned deliveries.
            """,
            "start navigation dashboard sign out role", AllRoles, false, 10),
        T(2, 1, "login-and-otp", "Login and email verification",
            "Sign in normally and understand the one-time web verification required after a password reset.",
            """
            # Login and email verification
            Enter your email and password. Normal web and mobile sign-in opens the permitted dashboard without an email code.

            After a successful password reset or account-owner password change, the next web login requires one email verification challenge. Mobile login remains available and does not clear this requirement. The requirement is cleared only after the web code or recovery code is verified successfully.

            The code expires after five minutes and is attempt limited. Never share a password or verification code. If email is delayed, check junk mail, confirm the masked destination, wait for the resend timer and request one fresh code.
            """,
            "login otp code two factor email resend", AllRoles, true, 20),
        T(3, 1, "trusted-devices", "Trusted devices",
            "Review and revoke legacy trusted-device records safely.",
            """
            # Trusted devices
            Normal sign-in no longer uses a trusted-device token to decide whether verification is required. Existing device records remain visible for accountability and can be revoked.

            Open Account Security to review device names, last use and expiry. Revoke an unfamiliar device immediately. Password reset, account deactivation, role changes and security-session revocation invalidate trusted devices.
            """,
            "trusted device revoke thirty days security", AllRoles, false, 30),
        T(4, 1, "recovery-codes", "Recovery codes",
            "Save, use and regenerate one-time recovery codes.",
            """
            # Recovery codes
            After the first successful OTP, PhenyoSync displays ten one-time recovery codes. Save or print them immediately; they cannot be shown again.

            Use one code from the login verification screen only when email verification is unavailable. Each code works once. Regenerating codes revokes every unused code from the previous set and requires your current password.
            """,
            "recovery code regenerate download print", AllRoles, false, 40),
        T(5, 1, "password-reset", "Reset a forgotten password",
            "Request and use the secure, expiring password-reset email.",
            """
            # Password reset
            Select Forgot Password on the login page and enter your account email. For privacy, the same confirmation appears whether or not an account exists.

            Open the email link within 30 minutes, enter matching passwords of at least eight characters and submit once. A successful reset invalidates previous sessions and trusted devices.
            """,
            "forgot password reset email expired link", AllRoles, true, 50),
        T(6, 2, "manage-users", "Manage users",
            "Create, search, update, deactivate and reactivate users safely.",
            """
            # Manage users
            Authorized management can search users, create accounts with unique real email addresses, update identity details, assign roles and deactivate or reactivate accounts.

            Deactivation blocks new and current sessions without deleting history. Historical users must remain linked to their audit and operational records. Trigger password-reset email instead of setting a password manually.
            """,
            "users create update deactivate role password reset", Management, false, 10),
        T(7, 2, "roles-and-permissions", "Roles and permissions",
            "Maintain roles, permission assignments and effective access.",
            """
            # Roles and permissions
            Roles group permissions by business responsibility. Create or update custom roles, assign permission checkboxes and inspect a user's effective permissions before changing access.

            System role codes and system permission codes are protected because APIs depend on them. Unused custom roles may be deactivated or deleted; roles with users or historical references must remain.
            """,
            "role permission create assign effective access", Management, false, 20),
        T(8, 3, "make-products", "Make products and batches",
            "Convert mapped Raw Stock into an existing Product and trace both sides of production.",
            """
            # Make products
            Select a warehouse section, then select an existing active Product whose Raw Stock requirements are configured and currently available. The readiness card shows adjusted input quantities and maximum packable output.

            Enter only the warehouse section, Product and quantity to make. PhenyoSync automatically consumes eligible Raw Stock in earliest-expiry-first order, records the conversion and increases finished Product stock. The transaction rolls back when any input is insufficient or changes concurrently. Product master creation and order barcode packing remain separate workflows.
            """,
            "make product raw stock conversion recipe availability", "WarehouseManager", false, 10),
        T(9, 3, "search-update-products", "Search and update products",
            "Find products by details or QR value and edit valid master data.",
            """
            # Search and update products
            Search by product name, type, category, status or QR value. Select a result to view or update it.

            Product changes affect future production, not historical batch snapshots. Use Inactive when a product must stay in history but should not be available for new operations.
            """,
            "search product update qr inactive", "OperationsManager,BusinessManager,Admin,WarehouseManager,Packer", false, 20),
        T(10, 3, "product-types-categories", "Product types and categories",
            "Create, edit, activate and dependency-check product classifications.",
            """
            # Product types and categories
            Management pages maintain the database values shown in product forms. Names are unique and active entries are available for new products.

            A type or category linked to products cannot be permanently removed. Deactivate it instead so history remains valid.
            """,
            "product type category crud deactivate", Management, false, 30),
        T(11, 3, "qr-labels", "QR codes and labels",
            "Generate, download and use batch-specific QR labels.",
            """
            # QR codes and labels
            Each physical batch receives a scannable QR value. The printable label identifies the product, batch code, packed date and expiry date.

            Attach the label to the matching physical stock. Scanning should open or identify that exact batch, not just the product master record.
            """,
            "qr code label print batch", "WarehouseManager,Packer", false, 40),
        T(12, 3, "stock-take", "Stock takes and adjustments",
            "Count physical stock and record controlled adjustments.",
            """
            # Stock takes
            Start a stock-take session, capture observed quantities and review discrepancies before posting.

            Adjustments require an approved reason and create immutable stock movements. Never edit aggregate stock directly; batch and movement records are the accountability source.
            """,
            "stock take adjustment movement discrepancy", "OperationsManager,WarehouseManager", false, 50),
        T(13, 3, "expiry-actions", "Expiry warnings, write-off and extension",
            "Respond to yellow and urgent expiry alerts safely.",
            """
            # Expiry management
            Yellow warnings identify batches approaching expiry. Red urgent warnings appear when 24 hours or less remain.

            Authorized users may write off remaining stock or approve the one-time two-day extension after inspection and with a reason. Expired, consumed and written-off batches are excluded from available stock.
            """,
            "expiry yellow red urgent write off extension", "OperationsManager,WarehouseManager", false, 60),
        T(14, 4, "operational-lookups", "Operational lookups",
            "Maintain approved reasons, payment methods, customer types and units.",
            """
            # Operational lookups
            Lookup values supply controlled options for stock movements, write-offs, order cancellation, delivery failures, payment methods, customer and supplier types, and units of measure.

            Display names and active status are editable. Protected system codes remain immutable because workflow logic and reporting use them.
            """,
            "lookup reason payment method customer supplier unit", Management, false, 10),
        T(15, 4, "warehouse-sections", "Warehouse sections",
            "Maintain warehouse locations without breaking historical stock.",
            """
            # Warehouse sections
            Create a unique section code, display name and description. Active sections appear in product and stock workflows.

            Deactivate a location that should no longer receive stock. Do not delete a section referenced by stock, batches or movements.
            """,
            "warehouse section location create deactivate", Management, false, 20),
        T(16, 4, "system-settings", "System settings and history",
            "Change validated business timers and thresholds immediately.",
            """
            # System settings
            Use this screen to change validated operating rules without restarting PhenyoSync. You need System Settings access and a clear business reason before starting.

            1. Find the setting by its business category and label.
            2. Enter a value within the displayed range.
            3. Record why the change is required and save.
            4. Confirm the new value and history entry.

            VAT rate (%) applies to newly created orders and to editable orders when they are recalculated. Existing issued invoices and completed orders retain their saved totals. Values are type-checked and range-checked; successful changes apply immediately and retain the old value, new value, actor, time and reason. If a value is rejected, use the displayed range rather than retrying an unsupported format.
            """,
            "settings vat tax timers threshold history configuration", Management, false, 30),
        T(17, 5, "customers-suppliers-payments", "Customers, suppliers and payments",
            "Maintain parties and capture authorized payments.",
            """
            # Customers, suppliers and payments
            Use unique contact details and active classifications when maintaining customers and suppliers. Orders must link to valid customers.

            Admin and authorized management capture and confirm payments. Amounts must be positive and cannot exceed the outstanding invoice. Reversal requires a reason and audit record.
            """,
            "customer supplier payment invoice confirm reverse", Management, false, 10),
        T(18, 5, "order-links", "Share the customer order form",
            "Share the configured Google Form and manually synchronise controlled order requests.",
            """
            # Customer order form
            Open the configured Google Form from Order Management and share it with the customer. When responses are ready, an authorised user selects Synchronise responses. PhenyoSync reads the configured Google Sheet through the backend and never exposes the provider key to the browser.

            The live form uses customer identity, account reference, phone, fulfilment choice, address, requested date, purchase-order reference, six Product/quantity pairs, additional items and customer notes. Products match an exact Product code first and then one unambiguous description. Customers match email first, account reference second and a unique phone number only as a safe fallback. Collection requests do not require a delivery address. Additional free-text products and any ambiguity remain in Needs Attention instead of silently creating records or changing master data.

            Synchronisation is a Super Admin commercial-intake task. Each response has a stable external key, so repeated syncs cannot create duplicate orders. Authoritative prices come from PhenyoSync and accepted requests enter Submitted for commercial approval.
            """,
            "customer google sheet order sync duplicate pending validation", Management, false, 20),
        T(19, 5, "create-validate-orders", "Create and validate orders",
            "Capture order lines and reserve sufficient eligible stock.",
            """
            # Create and validate orders
            Use this workflow to capture sellable quantities for a customer and make a commercial decision. Confirm that the customer, delivery details and requested products are correct before starting.

            1. Select the active customer and enter the delivery and billing addresses.
            2. Add each product once and enter a positive quantity in its displayed selling unit.
            3. Review the unit price, kilogram conversion and estimated subtotal, then save.
            4. A Super Admin selects Accept Order or Deny Order. A denial reason is optional.
            5. Accepted demand proceeds to packing and shortage planning; finished-stock shortage does not make a valid commercial order invalid.

            Packaged products require whole units. Variable-weight products use kilograms. Prices, units, kilograms-per-unit, VAT and totals are recalculated and snapshotted by the server. If ordering is blocked, check that the product is active and has a current price and valid pack weight.
            """,
            "create order accept deny units kilograms vat stock reserve fefo price", Management, false, 30),
        T(20, 5, "order-status-cancel", "Order status and cancellation",
            "Follow the valid status sequence and release reservations on cancellation.",
            """
            # Order status and cancellation
            Orders move from Submitted to commercially Approved, Packing, Packing Complete, Ready for Dispatch, Out for Delivery and Delivered. Commercial approval belongs to Super Admin. Packing belongs to the Packer, and the Warehouse Manager confirms dispatch readiness only after packing is complete.

            Cancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.
            """,
            "order status cancel reservation release", Management, false, 40),
        T(21, 5, "packing-invoices", "Packing lists and invoices",
            "Pack allocated batches and view the immutable invoice snapshot.",
            """
            # Packing and invoices
            Packers open the packing queue, verify each allocated batch and quantity, then confirm packing once.

            Packing decreases stock with movements and creates the order's invoice snapshot. The invoice remains linked to the order and later price changes do not alter it.
            """,
            "packing list batch invoice stock decrease", "OperationsManager,BusinessManager,WarehouseManager,Packer", false, 50),
        T(22, 6, "pricing", "Pricing and price history",
            "Create current product prices while preserving historical versions.",
            """
            # Pricing
            A price must be greater than zero and belong to a valid product. Updating a price closes the previous record and creates a new current version.

            Soft deletion removes a price from future ordering but preserves its history. Existing order items and invoices retain their snapshotted unit prices.
            """,
            "price create update history soft delete current", Management, false, 10),
        T(23, 6, "audit-logs", "Search audit logs",
            "Find read-only accountability records and use correlation IDs.",
            """
            # Audit logs
            Search by user, date, action, module, entity, success state, correlation ID or text. Open a result to inspect sanitized before-and-after details.

            Audit logs are read-only and retained for accountability. A correlation ID groups changes and security events from the same request or workflow.
            """,
            "audit log search correlation activity readonly", "OperationsManager,Admin", false, 20),
        T(24, 7, "assign-drivers", "Assign drivers",
            "Schedule deliveries and prevent overlapping driver assignments.",
            """
            # Assign drivers
            A packed order may be scheduled for a delivery window. Select an active available driver whose licence covers the full window.

            PhenyoSync prevents overlapping assignments and records assignment, reassignment and unassignment history.
            """,
            "delivery schedule assign driver availability overlap", Management, false, 10),
        T(25, 7, "my-deliveries", "Driver: My Deliveries",
            "Review and start only deliveries assigned to your driver account.",
            """
            # My Deliveries
            Drivers see only currently assigned deliveries. Open a record for the schedule, customer, address and order details.

            Start the delivery only when it is Assigned. This moves the delivery and order into their in-transit states.
            """,
            "driver my deliveries assigned start", "Driver", false, 20),
        T(26, 7, "complete-delivery-proof", "Complete delivery with proof images",
            "Upload protected proof images before final delivery completion.",
            """
            # Complete a delivery
            Upload one or more JPEG, PNG or WebP proof images, add a useful caption and select the primary image. Confirm the recipient and successful fulfillment.

            Proof is required by default. The assigned Driver may complete their own in-transit delivery. Authorized management can complete on behalf of a driver or override missing proof only with an explicit reason.

            Completion is final: proof becomes read-only, the delivery records a UTC completion time and the order becomes Delivered.
            """,
            "delivery proof image upload complete recipient override", "OperationsManager,BusinessManager,WarehouseManager,Driver", false, 30),
        T(27, 8, "validation-errors", "Validation messages and trace IDs",
            "Resolve highlighted fields and provide a trace ID when support is needed.",
            """
            # Validation and server errors
            Read the friendly message and correct every highlighted field. Refresh when a row-version conflict says the record changed.

            If an unexpected server error persists, note the displayed trace ID and the time of the action. Do not send passwords, OTPs or recovery codes to support.
            """,
            "validation error trace id conflict support", AllRoles, true, 10),
        T(28, 8, "permission-denied", "Permission denied",
            "Understand why a page or action is unavailable.",
            """
            # Permission denied
            Menus and APIs are controlled by database permissions. A denied action means the signed-in role does not currently have that permission.

            Ask authorized management to review your effective permissions. Sign out and in again after a role change so the session uses the new security version.
            """,
            "permission denied role access 403", AllRoles, false, 20),
        T(29, 8, "expired-links", "Expired or used links",
            "Recover from password, order or expiry-action links that no longer work.",
            """
            # Expired links
            Security links are time-limited and often one-time. Request a new password-reset or expiry-review link from the appropriate workflow. Customer ordering uses the configured Google Form and staff capture process.

            Do not edit tokens in the address bar or share links. A used link cannot be reactivated.
            """,
            "expired link used token password order expiry", AllRoles, true, 30),
        T(30, 8, "unavailable-drivers", "Unavailable drivers",
            "Resolve licence, status and schedule conflicts during assignment.",
            """
            # Unavailable drivers
            A driver is unavailable when inactive, not marked Available, missing a valid driver-user link, holding an expired licence or already assigned to an overlapping window.

            Adjust the schedule, update legitimate driver details or select a different available driver. Do not bypass overlap protection.
            """,
            "driver unavailable overlap licence schedule", Management, false, 40),
        T(31, 8, "otp-not-received", "OTP email not received",
            "Use safe recovery steps when the verification email is delayed.",
            """
            # OTP email not received
            Confirm the masked email destination, check spam, wait for the resend countdown and request one fresh code. Only the newest code is valid.

            If email remains unavailable, use a saved recovery code. Contact management to correct the account email; never create duplicate shared addresses.
            """,
            "otp email not received resend recovery", AllRoles, true, 50),
        T(32, 8, "file-rejected", "A proof image or training video was rejected",
            "Resolve protected-file validation failures without weakening security.",
            """
            # File rejected
            Proof images must be genuine JPEG, PNG or WebP files within the configured limit. Training media must be a genuine MP4 or WebM; captions must be WEBVTT.

            Renaming an extension does not convert a file. Export the file in an allowed format and retry. Executable, SVG, HTML, polyglot and mismatched files are blocked.
            """,
            "file rejected image video size mime extension", AllRoles, false, 60),
        T(33, 9, "formal-reports", "Run and export formal reports",
            "Preview report criteria, understand report structure and export the exact preview as PDF.",
            """
            # Formal reports
            Choose a report, set its criteria and select Preview. The preview is the authoritative dataset for the PDF. If any criterion changes, preview the report again before downloading.

            Inventory Availability, Expiry and Waste, and Markup Analysis are simple flat reports. Sales and Stock Movement reports use visible control breaks, subtotals and grand totals. Currency is displayed in South African rand and timestamps are shown consistently with the selected criteria.

            Access to costs, reversals and exports is controlled independently. Future dates and future pricing periods are rejected in both the page and API. An empty report means no records matched the selected criteria; it is not a failure. Every preview and PDF export is audited.
            """,
            "report preview criteria pdf export totals empty audit", Management, false, 10),
        T(34, 9, "financial-report", "Interpret the financial report",
            "Use adjustable criteria and interpret the operational financial summary correctly.",
            """
            # Financial report
            Filter by date, customer, invoice status, payment status, payment method and amount range. The report summarizes invoiced value, confirmed payments, outstanding value, reversals and write-off losses from stored operational records.

            This is an operational financial summary, not a profit-and-loss statement. It does not infer general-ledger balances, tax liability, payroll, overheads or accounting profit where those ledgers do not exist. Reversal detail is shown only to users with the dedicated permission.
            """,
            "financial criteria invoice payment outstanding reversal write off non profit loss", Management, false, 20),
        T(35, 9, "pricing-management-report", "Interpret pricing charts and formulas",
            "Understand weighted monthly averages, annual means and reliable box plots.",
            """
            # Pricing management report
            Monthly average selling price is quantity weighted from stored SalesOrderItem price snapshots: the sum of quantity multiplied by unit price, divided by total quantity. The annual value is the arithmetic mean of available monthly averages. Months without observations are shown as N/A and are never treated as zero.

            The box plot uses linear-interpolated quartiles and 1.5 times the interquartile range for whiskers and outliers. A box is shown only when at least five observations are available. The support tables contain the exact values used by the line, bar and box-plot charts.
            """,
            "pricing weighted monthly annual average box plot quartile iqr observation snapshot", Management, false, 30),
        T(36, 3, "product-data-exchange", "Product and price Excel exchange",
            "Export professional pricing workbooks and apply only validated Excel imports.",
            """
            # Product and price Excel exchange
            Use the filters to create a presentation-ready Excel workbook showing Product master data and the price effective at the selected business date. Excel includes instructions, metadata, filters and typed columns.

            Import is a controlled Excel workflow: upload the current template, review valid, warning and invalid rows, enter a business reason, confirm, and apply the exact staged content. Existing prices are versioned instead of overwritten. JSON is reserved for Stock Taker inventory snapshots and never contains prices or costs.
            """,
            "excel product price catalogue template validate import export stock count json", Management, false, 40),
        T(37, 3, "procurement-shortages", "Demand-driven procurement shortages",
            "Understand how validated demand becomes Product and Raw Stock buying requirements.",
            """
            # Procurement shortages
            Shortage planning starts with commercially approved and active fulfilment demand. Submitted customer or Google Form requests are excluded until Super Admin approval. Active finished-stock reservations are subtracted before the Product shortage is calculated.

            The Warehouse Manager maintains Product-to-Raw-Stock mappings using friendly dropdowns, quantity, unit, waste and yield. Unmapped approved demand is shown separately and cannot generate misleading purchase quantities. Mapped shortages include available Raw Stock, outstanding supplier orders and open Buying List quantities.

            Receive Raw Stock only from a controlled Supplier Order line or a submitted Buying List line. Supplier and unit are derived from the selected source. A Buying List may use Market Purchase / Not applicable when no supplier applies. Record the received quantity, actual cost, docket and any variance notes; the source document remains the traceability record.
            """,
            "procurement demand shortage reservation raw stock buying list", Management, false, 50),
        T(38, 3, "product-production-lifecycle", "Add, configure and make Products",
            "Create a sellable Product, configure its Raw Stock recipe and produce traceable batches.",
            """
            # Product creation and production
            Use Add Product to create a catalogue definition; use Make Product only when producing physical stock. Before starting, confirm that the category and product type are linked and that an approved price per kilogram is available.

            1. Open Add Product from Warehouse Operations.
            2. Choose the category and type, then enter the product name, display size and shelf life.
            3. Choose variable-weight kg or a packaged selling unit such as bag, box or pack.
            4. For packaged products, enter the positive kilograms contained in one unit.
            5. Enter the initial price per kilogram, a price reason and status, then save.

            PhenyoSync derives the packaged unit price from price per kilogram × kilograms per unit and prevents duplicate Product names within the same hierarchy. Do not estimate a pack weight from the display-size text.

            Select Configure Raw Stock Recipe after creation. A recipe describes the Raw Stock needed for one sellable Product unit. For example, one Granny Smith Apples 3 KG Product unit consumes 3 kg of Loose Granny Smith Apples. Make Product multiplies that recipe by the number of units and records Raw Stock movements and a traceable Product Batch.

            Permanently delete only unused master data. If a Product, Customer, Supplier, Raw Stock item, Category or Type has operational history, PhenyoSync blocks deletion and offers deactivation so history remains intact.
            """,
            "add product hierarchy recipe make product unit price safe delete deactivate", Management, false, 60),
        T(39, 7, "mobile-scanning-and-tracking", "Scan, track and complete deliveries",
            "Use browser or mobile scanning, live foreground tracking and protected proof capture.",
            """
            # Mobile scanning and delivery tracking
            Packers can scan a Product Batch QR with the Android camera or a laptop webcam. If live scanning is unavailable, enter the printed code manually. The server always verifies the Product, batch, order, expiry, available quantity and duplicate-scan rules before progress changes.

            Drivers start a dispatched delivery before sharing location. While the delivery page remains open, PhenyoSync sends a first browser or device location immediately and retries foreground updates at a controlled interval. Track Driver refreshes automatically and shows the latest timestamp, accuracy, live, stale or waiting state and route trail. If map tiles fail, use the displayed coordinates. Permission denial or unavailable GPS must be resolved on the driver device; foreground sharing stops when the page or session ends.

            Take or select a delivery proof photo, wait for the successful upload message, name the recipient and confirm the handover before completing the delivery. Google Maps remains available for turn-by-turn navigation.
            """,
            "packing qr webcam manual scan driver location leaflet map simulated proof", AllRoles, false, 70),
        T(40, 4, "offline-data-exchange", "Controlled offline data exchange",
            "Use the correct controlled Excel and JSON workflow for offline operational data.",
            """
            # Controlled offline data exchange
            Use Product and Price Excel for catalogue work and Stocktake JSON for offline counts. Download a fresh file before starting and keep its sheet names, headers, metadata and identifiers unchanged.

            1. Export the current data.
            2. Edit only the documented business cells; example rows are not importable data.
            3. Upload and validate the file. Validation does not change stock or prices.
            4. Resolve every row-level error, validate again and review the preview.
            5. Enter the required business reason and confirm once. Replaying the same validation cannot duplicate the change.

            JSON must remain valid machine-readable JSON without comments or renamed keys. If the import is rejected, download a new template and copy only the intended editable values.
            """,
            "excel product price stocktake json offline validate import export", Management, false, 80)
    ];

    public static IReadOnlyList<HelpContextSeed> HelpContexts { get; } =
    [
        C(1, 1, "/admin-dashboard", "AdminDashboard", 100),
        C(2, 1, "/packer-dashboard", "PackerDashboard", 100),
        C(3, 1, "/dashboard", "RoleDashboard", 100),
        C(4, 25, "/driver-dashboard", "DriverDashboard", 100),
        C(5, 2, "/login", "Login", 100),
        C(6, 5, "/reset-password", "ResetPassword", 100),
        C(7, 6, "/manage-users", "ManageUsers", 100),
        C(8, 7, "/manage-roles", "ManageRoles", 100),
        C(9, 7, "/manage-permissions", "ManagePermissions", 100),
        C(10, 8, "/make-product", "MakeProduct", 100),
        C(11, 9, "/search-product", "SearchProduct", 100),
        C(12, 9, "/update-product", "UpdateProduct", 100),
        C(13, 10, "/manage-product-types", "ManageProductTypes", 100),
        C(14, 10, "/manage-product-categories", "ManageProductCategories", 100),
        C(15, 12, "/stock-take", "StockTake", 100),
        C(16, 13, "/expiry-alerts", "ExpiryAlerts", 100),
        C(17, 14, "/manage-lookups", "ManageLookups", 100),
        C(18, 15, "/manage-warehouse-sections", "WarehouseSections", 100),
        C(19, 16, "/manage-system-settings", "SystemSettings", 100),
        C(20, 18, "/send-order-link", "SendOrderLink", 100),
        C(21, 19, "/create-order", "OrderEditor", 100),
        C(22, 20, "/order-details/:id", "OrderDetails", 100),
        C(23, 21, "/view-pick-list", "PackingOrders", 100),
        C(24, 21, "/order-invoice/:id", "OrderInvoice", 100),
        C(25, 22, "/pricing-management", "PricingManagement", 100),
        C(26, 23, "/audit-logs", "AuditLogs", 100),
        C(27, 24, "/deliveries", "DeliveryManagement", 100),
        C(28, 25, "/my-deliveries", "MyDeliveries", 100),
        C(29, 26, "/deliveries/:id/complete", "CompleteDelivery", 100),
        C(30, 26, "/deliveries/:id/proof", "DeliveryProof", 100),
        C(31, 3, "/account-security", "AccountSecurity", 100),
        C(32, 1, "/help", "HelpCenter", 50),
        C(33, 33, "/reports", "ReportsLanding", 100),
        C(34, 33, "/reports/inventory-availability", "FormalReportInventory", 100),
        C(35, 33, "/reports/expiry-waste", "FormalReportExpiryWaste", 100),
        C(36, 33, "/reports/markup-analysis", "FormalReportMarkup", 100),
        C(37, 33, "/reports/sales-transactions", "FormalReportSales", 100),
        C(38, 33, "/reports/stock-movements", "FormalReportStockMovements", 100),
        C(39, 34, "/reports/financial-summary", "FormalReportFinancial", 100),
        C(40, 35, "/reports/pricing-management", "FormalReportPricing", 100),
        C(41, 36, "/product-data-exchange", "ProductDataExchange", 100),
        C(42, 37, "/buying-lists", "BuyingLists", 100),
        C(43, 37, "/raw-stock", "RawStock", 90),
        C(44, 38, "/product-hierarchy", "ProductHierarchy", 100),
        C(50, 38, "/add-product", "AddProduct", 110),
        C(46, 39, "/scan-product-batch", "ProductBatchScanner", 100),
        C(47, 39, "/mobile-operations-control", "MobileOperationsControl", 100),
        C(49, 40, "/stock-count-data-exchange", "StockCountDataExchange", 100)
    ];

    private static HelpTopicSeed T(
        int id,
        int categoryId,
        string slug,
        string title,
        string summary,
        string body,
        string keywords,
        string audienceRoles,
        bool isPublic,
        int sortOrder) =>
        new(id, categoryId, slug, title, summary, body.Trim(), keywords,
            audienceRoles, isPublic, sortOrder);

    private static HelpContextSeed C(
        int id,
        int topicId,
        string route,
        string component,
        int priority) =>
        new(id, topicId, route, component, priority);
}
