using System.Globalization;
using System.Text.Json;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.Configuration;

// These constants are persisted identifiers. Friendly labels may change without renaming them.
public static class LookupCodes
{
    public const string StockMovementReason = "STOCK_MOVEMENT_REASON";
    public const string WriteOffReason = "WRITE_OFF_REASON";
    public const string OrderCancellationReason = "ORDER_CANCELLATION_REASON";
    public const string OrderRejectionReason = "ORDER_REJECTION_REASON";
    public const string DeliveryFailureReason = "DELIVERY_FAILURE_REASON";
    public const string PaymentMethod = "PAYMENT_METHOD";
    public const string CustomerType = "CUSTOMER_TYPE";
    public const string SupplierType = "SUPPLIER_TYPE";
    public const string UnitOfMeasure = "UNIT_OF_MEASURE";
}

/// <summary>Canonical non-secret operational setting keys consumed by typed providers.</summary>
public static class SystemSettingKeys
{
    public const string ExpiryYellowThresholdHours = "Expiry.YellowThresholdHours";
    public const string ExpiryRedThresholdHours = "Expiry.RedThresholdHours";
    public const string ExpiryScanIntervalMinutes = "Expiry.ScanIntervalMinutes";
    public const string ExpiryShelfLifeExtensionDays = "Expiry.ShelfLifeExtensionDays";
    public const string ExpiryActionTokenLifetimeHours = "Expiry.ActionTokenLifetimeHours";
    public const string ExpiryRecipientRoleCodes = "Expiry.RecipientRoleCodes";
    public const string OrdersOrderLinkLifetimeHours = "Orders.OrderLinkLifetimeHours";
    public const string OrdersDeliverySafetyHours = "Orders.DeliverySafetyHours";
    public const string OrdersCustomerGoogleFormUrl = "Orders.CustomerGoogleFormUrl";
    public const string OrdersVatRatePercent = "Orders.VatRatePercent";
    public const string DeliveryDefaultDurationMinutes = "Delivery.DefaultDurationMinutes";
    public const string SecurityOtpLifetimeMinutes = "Security.OtpLifetimeMinutes";
    public const string SecurityOtpMaximumAttempts = "Security.OtpMaximumAttempts";
    public const string SecurityOtpResendDelaySeconds = "Security.OtpResendDelaySeconds";
    public const string SecurityOtpMaximumResendsPerHour = "Security.OtpMaximumResendsPerHour";
    public const string SecurityTrustedDeviceDays = "Security.TrustedDeviceDays";
    public const string SecurityRecoveryCodeCount = "Security.RecoveryCodeCount";
    public const string FilesProofImageMaximumMb = "Files.ProofImageMaximumMb";
    public const string FilesTrainingVideoMaximumMb = "Files.TrainingVideoMaximumMb";
    public const string DeliveryRequireProofImageForCompletion =
        "Delivery.RequireProofImageForCompletion";
    public const string FilesExcelImportMaximumMb = "Files.ExcelImportMaximumMb";
    public const string FilesJsonImportMaximumMb = "Files.JsonImportMaximumMb";
    public const string DataExchangeMaximumRows = "DataExchange.MaximumRows";
    public const string DataExchangeValidationLifetimeMinutes =
        "DataExchange.ValidationLifetimeMinutes";
    public const string QrDuplicateDelaySeconds = "Qr.DuplicateDelaySeconds";
    public const string CalendarDefaultView = "Calendar.DefaultView";
    public const string CalendarMaximumDateRangeDays =
        "Calendar.MaximumDateRangeDays";
    public const string MobileLocationIntervalSeconds =
        "Mobile.LocationIntervalSeconds";
    public const string MobileLocationMinimumMovementMetres =
        "Mobile.LocationMinimumMovementMetres";
    public const string MobileLocationStaleAfterSeconds =
        "Mobile.LocationStaleAfterSeconds";
    public const string MobileLocationRetentionDays =
        "Mobile.LocationRetentionDays";
    public const string MobileOfflineQueueMaximumItems =
        "Mobile.OfflineQueueMaximumItems";
    public const string MobileProofMaximumMb = "Mobile.ProofMaximumMb";
    public const string MobileDocketMaximumMb = "Mobile.DocketMaximumMb";
    public const string MapsRouteCacheMinutes = "Maps.RouteCacheMinutes";
    public const string MapsMaximumRefreshesPerDelivery =
        "Maps.MaximumRefreshesPerDelivery";
    public const string MapsTrafficAwareEnabled = "Maps.TrafficAwareEnabled";
    public const string NotificationsPushEnabled = "Notifications.PushEnabled";
    public const string NotificationsEmailFallbackEnabled =
        "Notifications.EmailFallbackEnabled";
    public const string NotificationsMaximumRetryCount =
        "Notifications.MaximumRetryCount";
    public const string NotificationsRetryDelaySeconds =
        "Notifications.RetryDelaySeconds";
    public const string WriteOffWarehouseManagerMaximumValue =
        "WriteOff.WarehouseManagerMaximumValue";
    public const string WriteOffWarehouseManagerMaximumQuantity =
        "WriteOff.WarehouseManagerMaximumQuantity";
    public const string WriteOffRequirePhotoAboveValue =
        "WriteOff.RequirePhotoAboveValue";
    public const string WriteOffRequireApprovalAboveValue =
        "WriteOff.RequireApprovalAboveValue";
    public const string WriteOffAllowExpiredBatchAutomaticBlock =
        "WriteOff.AllowExpiredBatchAutomaticBlock";
    public const string RawStockTakeRequireApprovalAboveKg =
        "RawStockTake.RequireApprovalAboveKg";
    public const string RawStockTakeRequireApprovalAbovePercentage =
        "RawStockTake.RequireApprovalAbovePercentage";
    public const string RawStockTakeRequireApprovalAboveValue =
        "RawStockTake.RequireApprovalAboveValue";
    public const string PaymentsAdminVoidSameDayMaximumValue =
        "Payments.AdminVoidSameDayMaximumValue";
    public const string PaymentsRequireManagementApprovalAfterHours =
        "Payments.RequireManagementApprovalAfterHours";
    public const string PaymentsRequireManagementApprovalAboveValue =
        "Payments.RequireManagementApprovalAboveValue";
    public const string RawStockWriteOffRequireApprovalAboveQuantity =
        "RawStock.WriteOffRequireApprovalAboveQuantity";
    public const string RawStockWriteOffRequireApprovalAboveValue =
        "RawStock.WriteOffRequireApprovalAboveValue";
    public const string RawStockWriteOffEvidenceAboveValue =
        "RawStock.WriteOffEvidenceAboveValue";
    public const string ReportsDefaultPageSize =
        "Reports.DefaultPageSize";
    public const string ReportsMaximumPageSize =
        "Reports.MaximumPageSize";
    public const string ReportsPreviewLifetimeMinutes =
        "Reports.PreviewLifetimeMinutes";
    public const string ReportsMaximumDateRangeDays =
        "Reports.MaximumDateRangeDays";
    public const string ReportsMarkupAllowPriorReceiptCostFallback =
        "Reports.Markup.AllowPriorReceiptCostFallback";
    public const string ReportsPricingMinimumBoxPlotObservations =
        "Reports.Pricing.MinimumBoxPlotObservations";
}

public sealed record SettingDefinition(
    int Id,
    string Key,
    string Category,
    string DisplayName,
    string Description,
    string ValueType,
    string DefaultValue,
    string? Unit = null,
    string? MinimumValue = null,
    string? MaximumValue = null,
    string? AllowedValuesJson = null);

public sealed record LookupTypeSeed(
    int Id,
    string Code,
    string DisplayName,
    string Description);

public sealed record LookupValueSeed(
    int Id,
    int TypeId,
    string Code,
    string DisplayName,
    int SortOrder);

/// <summary>Declares seeded lookup/setting definitions used to validate configuration values.</summary>
public static class PhaseA2Catalog
{
    public static readonly DateTime SeededAtUtc =
        new(2026, 7, 24, 0, 0, 0, DateTimeKind.Utc);

    public static IReadOnlyList<LookupTypeSeed> LookupTypes { get; } =
    [
        new(1, LookupCodes.StockMovementReason, "Stock movement reasons", "Reasons recorded when stock is adjusted or moved."),
        new(2, LookupCodes.WriteOffReason, "Write-off reasons", "Approved reasons for final stock write-off."),
        new(3, LookupCodes.OrderCancellationReason, "Order cancellation reasons", "Reasons used when a sales order is cancelled."),
        new(4, LookupCodes.OrderRejectionReason, "Order rejection reasons", "Reasons used when an order is rejected during validation."),
        new(5, LookupCodes.DeliveryFailureReason, "Delivery failure reasons", "Reasons recorded when a delivery cannot be fulfilled."),
        new(6, LookupCodes.PaymentMethod, "Payment methods", "Approved customer and supplier payment methods."),
        new(7, LookupCodes.CustomerType, "Customer types", "Customer classifications used by operational forms."),
        new(8, LookupCodes.SupplierType, "Supplier types", "Supplier classifications used by operational forms."),
        new(9, LookupCodes.UnitOfMeasure, "Units of measure", "Units available for quantities and packaging.")
    ];

    public static IReadOnlyList<LookupValueSeed> LookupValues { get; } =
    [
        new(1, 1, "PRODUCTION_INCREASE", "Production increase", 10),
        new(2, 1, "PACKING_DECREASE", "Packing decrease", 20),
        new(3, 1, "STOCK_ADJUSTMENT", "Stock adjustment", 30),
        new(4, 2, "EXPIRED", "Expired stock", 10),
        new(5, 2, "DAMAGED", "Damaged stock", 20),
        new(6, 2, "QUALITY_FAILURE", "Quality inspection failure", 30),
        new(7, 3, "CUSTOMER_REQUEST", "Customer request", 10),
        new(8, 3, "DUPLICATE_ORDER", "Duplicate order", 20),
        new(9, 3, "STOCK_UNAVAILABLE", "Stock unavailable", 30),
        new(10, 4, "INSUFFICIENT_STOCK", "Insufficient stock", 10),
        new(11, 4, "INVALID_DETAILS", "Invalid order details", 20),
        new(12, 5, "CUSTOMER_UNAVAILABLE", "Customer unavailable", 10),
        new(13, 5, "ADDRESS_NOT_FOUND", "Address not found", 20),
        new(14, 5, "VEHICLE_ISSUE", "Vehicle issue", 30),
        new(15, 6, "EFT", "Electronic funds transfer", 10),
        new(16, 6, "CARD", "Card", 20),
        new(17, 6, "CASH", "Cash", 30),
        new(18, 7, "RETAIL", "Retail", 10),
        new(19, 7, "WHOLESALE", "Wholesale", 20),
        new(20, 7, "DISTRIBUTOR", "Distributor", 30),
        new(21, 8, "PRODUCER", "Producer", 10),
        new(22, 8, "DISTRIBUTOR", "Distributor", 20),
        new(23, 8, "SERVICE_PROVIDER", "Service provider", 30),
        new(24, 9, "KG", "Kilogram (kg)", 10),
        new(25, 9, "G", "Gram (g)", 20),
        new(26, 9, "L", "Litre (L)", 30),
        new(27, 9, "UNIT", "Unit", 40)
    ];

    public static IReadOnlyList<SettingDefinition> Settings { get; } =
    [
        new(1, SystemSettingKeys.ExpiryYellowThresholdHours, "Expiry", "Yellow warning threshold",
            "Hours before expiry when a batch becomes a yellow warning.", SystemSettingValueTypes.TimeSpanHours,
            "72", "hours", "2", "720"),
        new(2, SystemSettingKeys.ExpiryRedThresholdHours, "Expiry", "Red urgent threshold",
            "Hours before expiry when a batch becomes urgent.", SystemSettingValueTypes.TimeSpanHours,
            "24", "hours", "1", "168"),
        new(3, SystemSettingKeys.ExpiryScanIntervalMinutes, "Expiry", "Expiry scan interval",
            "Minutes between automatic expiry scans.", SystemSettingValueTypes.TimeSpanMinutes,
            "60", "minutes", "1", "1440"),
        new(4, SystemSettingKeys.ExpiryShelfLifeExtensionDays, "Expiry", "Shelf-life extension",
            "Days added by a permitted one-time shelf-life extension.", SystemSettingValueTypes.Integer,
            "2", "days", "1", "14"),
        new(5, SystemSettingKeys.ExpiryActionTokenLifetimeHours, "Expiry", "Expiry action-link lifetime",
            "Hours before a newly generated expiry decision link expires.", SystemSettingValueTypes.TimeSpanHours,
            "48", "hours", "1", "168"),
        new(6, SystemSettingKeys.ExpiryRecipientRoleCodes, "Expiry", "Expiry recipient roles",
            "Active role codes that receive new expiry-alert emails.", SystemSettingValueTypes.StringArray,
            JsonSerializer.Serialize(new[] { "OperationsManager", "WarehouseManager" })),
        new(7, SystemSettingKeys.OrdersOrderLinkLifetimeHours, "Orders", "Customer order-link lifetime",
            "Hours before a newly created customer order link expires.", SystemSettingValueTypes.TimeSpanHours,
            "72", "hours", "1", "168"),
        new(8, SystemSettingKeys.OrdersDeliverySafetyHours, "Orders", "Delivery stock-safety window",
            "Extra hours beyond requested delivery time that reserved batches must remain valid.", SystemSettingValueTypes.TimeSpanHours,
            "0", "hours", "0", "168"),
        new(9, SystemSettingKeys.DeliveryDefaultDurationMinutes, "Delivery", "Default delivery duration",
            "Duration used for a new schedule when no end time is supplied.", SystemSettingValueTypes.TimeSpanMinutes,
            "120", "minutes", "15", "1440"),
        new(10, SystemSettingKeys.SecurityOtpLifetimeMinutes, "Security", "OTP lifetime",
            "Minutes before a login verification code expires.", SystemSettingValueTypes.TimeSpanMinutes,
            "5", "minutes", "2", "15"),
        new(11, SystemSettingKeys.SecurityOtpMaximumAttempts, "Security", "OTP maximum attempts",
            "Failed verification attempts allowed before a challenge is locked.", SystemSettingValueTypes.Integer,
            "5", "attempts", "3", "10"),
        new(12, SystemSettingKeys.SecurityOtpResendDelaySeconds, "Security", "OTP resend delay",
            "Seconds before another verification code may be sent.", SystemSettingValueTypes.Integer,
            "60", "seconds", "30", "300"),
        new(13, SystemSettingKeys.SecurityOtpMaximumResendsPerHour, "Security", "OTP hourly resend limit",
            "Verification emails allowed for one account in a rolling hour.", SystemSettingValueTypes.Integer,
            "5", "resends", "1", "10"),
        new(14, SystemSettingKeys.SecurityTrustedDeviceDays, "Security", "Trusted-device lifetime",
            "Days before a trusted-device token expires.", SystemSettingValueTypes.Integer,
            "30", "days", "1", "90"),
        new(15, SystemSettingKeys.SecurityRecoveryCodeCount, "Security", "Recovery-code count",
            "One-time recovery codes generated for a user.", SystemSettingValueTypes.Integer,
            "10", "codes", "10", "10"),
        new(16, SystemSettingKeys.FilesProofImageMaximumMb, "Files", "Proof-image maximum size",
            "Maximum upload size for a delivery proof image.", SystemSettingValueTypes.Integer,
            "10", "MB", "1", "25"),
        new(17, SystemSettingKeys.FilesTrainingVideoMaximumMb, "Files", "Training-video maximum size",
            "Maximum upload size for a training video.", SystemSettingValueTypes.Integer,
            "250", "MB", "10", "500"),
        new(18, SystemSettingKeys.DeliveryRequireProofImageForCompletion, "Delivery", "Require proof image",
            "Require an active delivery proof image before final completion.", SystemSettingValueTypes.Boolean,
            "true"),
        new(19, SystemSettingKeys.FilesExcelImportMaximumMb, "Files", "Excel import maximum size",
            "Maximum accepted Product and Price Excel workbook size.", SystemSettingValueTypes.Integer,
            "10", "MB", "1", "50"),
        new(20, SystemSettingKeys.FilesJsonImportMaximumMb, "Files", "JSON import maximum size",
            "Maximum accepted Stock Count JSON package size.", SystemSettingValueTypes.Integer,
            "5", "MB", "1", "25"),
        new(21, SystemSettingKeys.DataExchangeMaximumRows, "Data exchange", "Maximum import rows",
            "Maximum number of rows accepted in one validated import.", SystemSettingValueTypes.Integer,
            "2000", "rows", "1", "10000"),
        new(22, SystemSettingKeys.DataExchangeValidationLifetimeMinutes, "Data exchange", "Validation lifetime",
            "Minutes a validated import remains available for confirmation.", SystemSettingValueTypes.TimeSpanMinutes,
            "30", "minutes", "5", "120"),
        new(23, SystemSettingKeys.QrDuplicateDelaySeconds, "QR scanning", "Duplicate scan delay",
            "Seconds during which a repeated camera scan is ignored.", SystemSettingValueTypes.Integer,
            "3", "seconds", "1", "30"),
        new(24, SystemSettingKeys.CalendarDefaultView, "Calendar", "Default calendar view",
            "Initial view used by the Operations Calendar.", SystemSettingValueTypes.String,
            "month", null, null, null, JsonSerializer.Serialize(new[] { "month", "week", "day", "agenda" })),
        new(25, SystemSettingKeys.CalendarMaximumDateRangeDays, "Calendar", "Maximum date range",
            "Maximum number of days returned by one Operations Calendar query.", SystemSettingValueTypes.Integer,
            "93", "days", "7", "366"),
        new(26, SystemSettingKeys.MobileLocationIntervalSeconds, "Mobile", "Location interval",
            "Seconds between foreground driver-location updates.", SystemSettingValueTypes.Integer,
            "45", "seconds", "15", "300"),
        new(27, SystemSettingKeys.MobileLocationMinimumMovementMetres, "Mobile", "Minimum movement",
            "Movement required before another driver-location point is accepted.", SystemSettingValueTypes.Integer,
            "20", "metres", "0", "1000"),
        new(28, SystemSettingKeys.MobileLocationStaleAfterSeconds, "Mobile", "Location stale threshold",
            "Seconds after which an active driver location is shown as stale.", SystemSettingValueTypes.Integer,
            "180", "seconds", "30", "3600"),
        new(29, SystemSettingKeys.MobileLocationRetentionDays, "Mobile", "Location retention",
            "Days that detailed delivery-location history is retained.", SystemSettingValueTypes.Integer,
            "30", "days", "1", "365"),
        new(30, SystemSettingKeys.MobileOfflineQueueMaximumItems, "Mobile", "Offline queue maximum",
            "Maximum safe draft operations retained by the mobile client.", SystemSettingValueTypes.Integer,
            "250", "items", "10", "2000"),
        new(31, SystemSettingKeys.MobileProofMaximumMb, "Mobile", "Proof image maximum",
            "Maximum delivery proof photograph size accepted from mobile.", SystemSettingValueTypes.Integer,
            "10", "MB", "1", "25"),
        new(32, SystemSettingKeys.MobileDocketMaximumMb, "Mobile", "Docket image maximum",
            "Maximum buying-list or receipt docket image size.", SystemSettingValueTypes.Integer,
            "10", "MB", "1", "25"),
        new(33, SystemSettingKeys.MapsRouteCacheMinutes, "Maps", "Route cache",
            "Minutes a matching route calculation may be reused.", SystemSettingValueTypes.Integer,
            "10", "minutes", "1", "120"),
        new(34, SystemSettingKeys.MapsMaximumRefreshesPerDelivery, "Maps", "Route refresh limit",
            "Maximum explicit route refreshes per delivery.", SystemSettingValueTypes.Integer,
            "20", "refreshes", "1", "100"),
        new(35, SystemSettingKeys.MapsTrafficAwareEnabled, "Maps", "Traffic-aware routing",
            "Request traffic-aware travel durations from the configured provider.", SystemSettingValueTypes.Boolean,
            "true"),
        new(36, SystemSettingKeys.NotificationsPushEnabled, "Notifications", "Push enabled",
            "Enable Firebase push processing when protected provider configuration is present.", SystemSettingValueTypes.Boolean,
            "true"),
        new(37, SystemSettingKeys.NotificationsEmailFallbackEnabled, "Notifications", "Email fallback",
            "Allow email fallback for supported critical operational notifications.", SystemSettingValueTypes.Boolean,
            "false"),
        new(38, SystemSettingKeys.NotificationsMaximumRetryCount, "Notifications", "Maximum retries",
            "Maximum attempts for a transient notification delivery failure.", SystemSettingValueTypes.Integer,
            "4", "attempts", "0", "10"),
        new(39, SystemSettingKeys.NotificationsRetryDelaySeconds, "Notifications", "Retry delay",
            "Base seconds before retrying a transient notification delivery failure.", SystemSettingValueTypes.Integer,
            "60", "seconds", "10", "3600"),
        new(40, SystemSettingKeys.WriteOffWarehouseManagerMaximumValue, "Write-off", "Warehouse Manager value limit",
            "Maximum estimated loss a Warehouse Manager may complete without Operations Manager approval.", SystemSettingValueTypes.Decimal,
            "1000", "currency", "0", "1000000"),
        new(41, SystemSettingKeys.WriteOffWarehouseManagerMaximumQuantity, "Write-off", "Warehouse Manager quantity limit",
            "Maximum quantity a Warehouse Manager may complete without Operations Manager approval.", SystemSettingValueTypes.Decimal,
            "100", "kg", "0", "100000"),
        new(42, SystemSettingKeys.WriteOffRequirePhotoAboveValue, "Write-off", "Photo threshold",
            "Estimated loss above which write-off evidence is required.", SystemSettingValueTypes.Decimal,
            "500", "currency", "0", "1000000"),
        new(43, SystemSettingKeys.WriteOffRequireApprovalAboveValue, "Write-off", "Approval threshold",
            "Estimated loss above which management approval is required.", SystemSettingValueTypes.Decimal,
            "1000", "currency", "0", "1000000"),
        new(44, SystemSettingKeys.WriteOffAllowExpiredBatchAutomaticBlock, "Write-off", "Block expired batches",
            "Block expired batches from normal stock use until a write-off decision is recorded.", SystemSettingValueTypes.Boolean,
            "true"),
        new(45, SystemSettingKeys.RawStockTakeRequireApprovalAboveKg, "Raw stock take", "Quantity approval threshold",
            "Absolute raw-stock variance above which management approval is required.", SystemSettingValueTypes.Decimal,
            "25", "kg", "0", "100000"),
        new(46, SystemSettingKeys.RawStockTakeRequireApprovalAbovePercentage, "Raw stock take", "Percentage approval threshold",
            "Percentage raw-stock variance above which management approval is required.", SystemSettingValueTypes.Decimal,
            "5", "percent", "0", "100"),
        new(47, SystemSettingKeys.RawStockTakeRequireApprovalAboveValue, "Raw stock take", "Value approval threshold",
            "Estimated financial impact above which management approval is required.", SystemSettingValueTypes.Decimal,
            "1000", "currency", "0", "10000000"),
        new(48, SystemSettingKeys.PaymentsAdminVoidSameDayMaximumValue, "Payments", "Administrator same-day reversal limit",
            "Maximum payment value an Administrator may reverse on the capture day.", SystemSettingValueTypes.Decimal,
            "5000", "currency", "0", "10000000"),
        new(49, SystemSettingKeys.PaymentsRequireManagementApprovalAfterHours, "Payments", "Reversal approval hours",
            "Hours after posting when a payment reversal requires management approval.", SystemSettingValueTypes.Integer,
            "24", "hours", "0", "720"),
        new(50, SystemSettingKeys.PaymentsRequireManagementApprovalAboveValue, "Payments", "Reversal approval value",
            "Payment value above which reversal requires management approval.", SystemSettingValueTypes.Decimal,
            "5000", "currency", "0", "10000000"),
        new(51, SystemSettingKeys.RawStockWriteOffRequireApprovalAboveQuantity, "Raw stock", "Write-off quantity approval threshold",
            "Raw-stock write-off quantity above which management approval is required.", SystemSettingValueTypes.Decimal,
            "100", "units", "0", "1000000"),
        new(52, SystemSettingKeys.RawStockWriteOffRequireApprovalAboveValue, "Raw stock", "Write-off value approval threshold",
            "Raw-stock write-off value above which management approval is required.", SystemSettingValueTypes.Decimal,
            "1000", "currency", "0", "10000000"),
        new(53, SystemSettingKeys.RawStockWriteOffEvidenceAboveValue, "Raw stock", "Write-off evidence threshold",
            "Raw-stock loss above which photographic evidence is required.", SystemSettingValueTypes.Decimal,
            "500", "currency", "0", "10000000"),
        new(54, SystemSettingKeys.ReportsDefaultPageSize, "Reports", "Default page size",
            "Rows shown when a paged report does not specify a page size.", SystemSettingValueTypes.Integer,
            "50", "rows", "10", "500"),
        new(55, SystemSettingKeys.ReportsMaximumPageSize, "Reports", "Maximum page size",
            "Largest row count accepted for one paged report preview.", SystemSettingValueTypes.Integer,
            "500", "rows", "50", "2000"),
        new(56, SystemSettingKeys.ReportsPreviewLifetimeMinutes, "Reports", "Preview lifetime",
            "Minutes an authenticated preview remains available for matching PDF export.", SystemSettingValueTypes.TimeSpanMinutes,
            "30", "minutes", "5", "120"),
        new(57, SystemSettingKeys.ReportsMaximumDateRangeDays, "Reports", "Maximum date range",
            "Maximum date range accepted by transactional and adjustable reports.", SystemSettingValueTypes.Integer,
            "365", "days", "31", "1095"),
        new(58, SystemSettingKeys.ReportsMarkupAllowPriorReceiptCostFallback, "Reports", "Allow prior receipt cost fallback",
            "Allow markup analysis to use a prior receipt cost when no direct or current receipt cost is available.", SystemSettingValueTypes.Boolean,
            "false"),
        new(59, SystemSettingKeys.ReportsPricingMinimumBoxPlotObservations, "Reports", "Minimum box-plot observations",
            "Minimum historical price observations required before a box plot is reliable.", SystemSettingValueTypes.Integer,
            "5", "observations", "5", "30"),
        new(60, SystemSettingKeys.OrdersCustomerGoogleFormUrl, "Orders", "Customer request Google Form URL",
            "Google Form used to collect external customer requests before staff capture an official order.", SystemSettingValueTypes.String,
            ""),
        new(61, SystemSettingKeys.OrdersVatRatePercent, "Orders", "VAT rate (%)",
            "VAT percentage applied when a new or editable customer order is calculated.", SystemSettingValueTypes.Decimal,
            "0", "percent", "0", "100")
    ];

    public static SettingDefinition GetSetting(string key) =>
        Settings.Single(item =>
            item.Key.Equals(key, StringComparison.OrdinalIgnoreCase));

    public static bool TryGetSetting(string key, out SettingDefinition definition)
    {
        definition = Settings.FirstOrDefault(item =>
            item.Key.Equals(key, StringComparison.OrdinalIgnoreCase))!;
        return definition is not null;
    }

    public static bool TryNormalizeValue(
        SettingDefinition definition,
        string rawValue,
        out string normalized,
        out string? error)
    {
        normalized = rawValue.Trim();
        error = null;

        if (definition.ValueType is SystemSettingValueTypes.Integer or
            SystemSettingValueTypes.TimeSpanHours or
            SystemSettingValueTypes.TimeSpanMinutes)
        {
            if (!int.TryParse(normalized, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value))
            {
                error = "Enter a whole number.";
                return false;
            }

            if (definition.MinimumValue is not null &&
                value < int.Parse(definition.MinimumValue, CultureInfo.InvariantCulture) ||
                definition.MaximumValue is not null &&
                value > int.Parse(definition.MaximumValue, CultureInfo.InvariantCulture))
            {
                error = $"Enter a value between {definition.MinimumValue} and {definition.MaximumValue}.";
                return false;
            }

            normalized = value.ToString(CultureInfo.InvariantCulture);
            return true;
        }

        if (definition.ValueType == SystemSettingValueTypes.Decimal)
        {
            if (!decimal.TryParse(normalized, NumberStyles.Number, CultureInfo.InvariantCulture, out var value))
            {
                error = "Enter a valid decimal number.";
                return false;
            }
            if (definition.MinimumValue is not null &&
                value < decimal.Parse(definition.MinimumValue, CultureInfo.InvariantCulture) ||
                definition.MaximumValue is not null &&
                value > decimal.Parse(definition.MaximumValue, CultureInfo.InvariantCulture))
            {
                error = $"Enter a value between {definition.MinimumValue} and {definition.MaximumValue}.";
                return false;
            }
            normalized = value.ToString(CultureInfo.InvariantCulture);
            return true;
        }

        if (definition.ValueType == SystemSettingValueTypes.Boolean)
        {
            if (!bool.TryParse(normalized, out var value))
            {
                error = "Select true or false.";
                return false;
            }
            normalized = value ? "true" : "false";
            return true;
        }

        if (definition.ValueType == SystemSettingValueTypes.StringArray)
        {
            try
            {
                var values = JsonSerializer.Deserialize<string[]>(normalized) ?? [];
                values = values
                    .Select(item => item.Trim())
                    .Where(item => item.Length > 0)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToArray();
                if (values.Length == 0)
                {
                    error = "Select at least one value.";
                    return false;
                }
                normalized = JsonSerializer.Serialize(values);
                return true;
            }
            catch (JsonException)
            {
                error = "The selected values are not valid.";
                return false;
            }
        }

        if (normalized.Length > 2000)
        {
            error = "The value is too long.";
            return false;
        }

        if (!string.IsNullOrWhiteSpace(definition.AllowedValuesJson))
        {
            var allowed = JsonSerializer.Deserialize<string[]>(
                definition.AllowedValuesJson) ?? [];
            var candidate = normalized;
            var match = allowed.FirstOrDefault(value =>
                value.Equals(candidate, StringComparison.OrdinalIgnoreCase));
            if (match is null)
            {
                error = $"Select one of: {string.Join(", ", allowed)}.";
                return false;
            }
            normalized = match;
        }

        return true;
    }
}
