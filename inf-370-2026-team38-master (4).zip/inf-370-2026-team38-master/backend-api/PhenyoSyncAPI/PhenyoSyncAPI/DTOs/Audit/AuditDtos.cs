namespace PhenyoSyncAPI.DTOs.Audit;

// Audit DTOs expose sanitized snapshots and bounded filters, never tracked audit entities.

public sealed class AuditLogSearchDto
{
    public int? UserId { get; set; }
    public string? UserSearch { get; set; }
    public DateTime? DateFromUtc { get; set; }
    public DateTime? DateToUtc { get; set; }
    public string? ActionType { get; set; }
    public string? SystemModule { get; set; }
    public string? OperationName { get; set; }
    public string? EntityType { get; set; }
    public string? EntityId { get; set; }
    public bool? Success { get; set; }
    public string? CorrelationId { get; set; }
    public string? SearchTerm { get; set; }
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 25;
}

public class AuditLogListItemDto
{
    public long AuditLogId { get; set; }
    public DateTime OccurredAtUtc { get; set; }
    public int? UserId { get; set; }
    public string? UserEmail { get; set; }
    public string? UserDisplayName { get; set; }
    public string? UserRole { get; set; }
    public string ActorType { get; set; } = string.Empty;
    public string ActionType { get; set; } = string.Empty;
    public string SystemModule { get; set; } = string.Empty;
    public string OperationName { get; set; } = string.Empty;
    public string? EntityType { get; set; }
    public string? EntityId { get; set; }
    public string? EntityDisplay { get; set; }
    public string Description { get; set; } = string.Empty;
    public bool Success { get; set; }
    public string CorrelationId { get; set; } = string.Empty;
}

public sealed class AuditLogDetailDto : AuditLogListItemDto
{
    public string? BeforeValuesJson { get; set; }
    public string? AfterValuesJson { get; set; }
    public string? ChangedFieldsJson { get; set; }
    public string? FailureReason { get; set; }
    public string? RequestPath { get; set; }
    public string? HttpMethod { get; set; }
    public string? IpAddress { get; set; }
    public string? UserAgent { get; set; }
    public string EventSource { get; set; } = string.Empty;
    public List<AuditLogListItemDto> RelatedLogs { get; set; } = [];
}

public sealed class AuditLogPageDto
{
    public List<AuditLogListItemDto> Items { get; set; } = [];
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public long TotalCount { get; set; }
    public int TotalPages { get; set; }
    public bool HasPreviousPage { get; set; }
    public bool HasNextPage { get; set; }
}

public sealed class AuditUserOptionDto
{
    public int UserId { get; set; }
    public string DisplayName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}

public sealed class AuditLogMetadataDto
{
    public List<string> ActionTypes { get; set; } = [];
    public List<string> SystemModules { get; set; } = [];
    public List<string> EntityTypes { get; set; } = [];
    public List<AuditUserOptionDto> Users { get; set; } = [];
}
