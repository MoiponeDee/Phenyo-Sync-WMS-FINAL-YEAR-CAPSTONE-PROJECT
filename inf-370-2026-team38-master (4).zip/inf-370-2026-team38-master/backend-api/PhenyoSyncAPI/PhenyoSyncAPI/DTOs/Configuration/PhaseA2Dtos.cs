using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Configuration;

// Configuration DTOs constrain paging, codes and values before they reach governed services.

public sealed class LookupSearchQuery
{
    [MaxLength(120)]
    public string? Search { get; set; }
    public bool? IsActive { get; set; }
    [Range(1, int.MaxValue)]
    public int Page { get; set; } = 1;
    [Range(1, 100)]
    public int PageSize { get; set; } = 25;
}

public sealed class SaveLookupTypeRequest
{
    [Required, RegularExpression("^[A-Z][A-Z0-9_]{2,79}$")]
    public string SystemCode { get; set; } = string.Empty;
    [Required, MaxLength(120)]
    public string DisplayName { get; set; } = string.Empty;
    [MaxLength(500)]
    public string? Description { get; set; }
    public string? RowVersion { get; set; }
}

public sealed class SaveLookupValueRequest
{
    [Required, RegularExpression("^[A-Z][A-Z0-9_]{1,79}$")]
    public string SystemCode { get; set; } = string.Empty;
    [Required, MaxLength(120)]
    public string DisplayName { get; set; } = string.Empty;
    [MaxLength(500)]
    public string? Description { get; set; }
    [Range(0, 100000)]
    public int SortOrder { get; set; }
    [Required, MinLength(5), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;
    public string? RowVersion { get; set; }
}

public sealed class ChangeConfigurationStatusRequest
{
    public bool IsActive { get; set; }
    [Required, MinLength(5), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;
    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class DeleteConfigurationRequest
{
    [Required, MinLength(5), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;
}

public sealed class SaveWarehouseSectionRequest
{
    [Required, RegularExpression("^[A-Z][A-Z0-9_-]{1,39}$")]
    public string SectionCode { get; set; } = string.Empty;
    [Required, MaxLength(100)]
    public string SectionName { get; set; } = string.Empty;
    [MaxLength(500)]
    public string? Description { get; set; }
    public string? RowVersion { get; set; }
}

public sealed class UpdateSystemSettingRequest
{
    [Required, MaxLength(2000)]
    public string Value { get; set; } = string.Empty;
    [Required, MinLength(5), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;
    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class ResetSystemSettingRequest
{
    [Required, MinLength(5), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;
    [Required]
    public string RowVersion { get; set; } = string.Empty;
}
