using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.BuyingLists;

// Buying List API contracts deliberately carry RowVersion and operation identifiers so
// browser/mobile commands can detect stale edits and retry safely without exposing entities.

public sealed class BuyingListSearchRequest
{
    [MaxLength(160)]
    public string? Search { get; set; }

    [MaxLength(30)]
    public string? Status { get; set; }

    public int? AssignedBuyerUserId { get; set; }
    public DateTime? FromDateUtc { get; set; }
    public DateTime? ToDateUtc { get; set; }

    [Range(1, 100000)]
    public int Page { get; set; } = 1;

    [Range(1, 100)]
    public int PageSize { get; set; } = 20;
}

public sealed class BuyingListSearchResultDto
{
    public required IReadOnlyList<BuyingListSummaryDto> Items { get; init; }
    public int Page { get; init; }
    public int PageSize { get; init; }
    public int Total { get; init; }
}

public class BuyingListSummaryDto
{
    public int BuyerProcurementId { get; init; }
    public required string ReferenceNumber { get; init; }
    public string? Title { get; init; }
    public DateTime BuyingDateUtc { get; init; }
    public int? AssignedBuyerUserId { get; init; }
    public string? BuyerName { get; init; }
    public required string Priority { get; init; }
    public required string Status { get; init; }
    public int ItemCount { get; init; }
    public int ResolvedItemCount { get; init; }
    public decimal RequiredQuantity { get; init; }
    public decimal PurchasedQuantity { get; init; }
    public decimal ReceivedQuantity { get; init; }
    public DateTime UpdatedAtUtc { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class BuyingListDetailDto : BuyingListSummaryDto
{
    public string? Notes { get; init; }
    public DateTime CreatedAtUtc { get; init; }
    public DateTime? PublishedAtUtc { get; init; }
    public DateTime? SubmittedAtUtc { get; init; }
    public DateTime? CancelledAtUtc { get; init; }
    public string? CancellationReason { get; init; }
    public string? CreatedByName { get; init; }
    public long? DocketStoredFileId { get; init; }
    public required IReadOnlyList<BuyingListLineDto> Items { get; init; }
}

public sealed class BuyingListLineDto
{
    public int BuyerProcurementItemId { get; init; }
    public int? ProductId { get; init; }
    public int? RawStockItemId { get; init; }
    public required string ItemCode { get; init; }
    public required string ItemName { get; init; }
    public required string Category { get; init; }
    public required string UnitOfMeasure { get; init; }
    public decimal CurrentStock { get; init; }
    public decimal RecommendedQuantity { get; init; }
    public decimal RequiredQuantity { get; init; }
    public decimal? ActualQuantity { get; init; }
    public decimal? ActualUnitPrice { get; init; }
    public decimal ReceivedQuantity { get; init; }
    public decimal OutstandingQuantity { get; init; }
    public required string Priority { get; init; }
    public int? PreferredSupplierId { get; init; }
    public string? PreferredSupplierName { get; init; }
    public int? SupplierId { get; init; }
    public string? SupplierName { get; init; }
    public required string Status { get; init; }
    public bool IsPromotionalItem { get; init; }
    public string? ManagementNotes { get; init; }
    public string? BuyerNotes { get; init; }
    public string? UnavailableReason { get; init; }
    public int? SubstituteRawStockItemId { get; init; }
    public string? SubstituteItemName { get; init; }
    public string? SubstituteNotes { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class CreateBuyingListManagementRequest
{
    public DateTime BuyingDateUtc { get; set; }

    [MaxLength(160)]
    public string? Title { get; set; }

    [Required, MaxLength(20)]
    public string Priority { get; set; } = "Standard";

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public int? AssignedBuyerUserId { get; set; }
    public List<SaveBuyingListLineRequest> Items { get; set; } = [];
}

public sealed class UpdateBuyingListHeaderRequest
{
    public DateTime BuyingDateUtc { get; set; }

    [MaxLength(160)]
    public string? Title { get; set; }

    [Required, MaxLength(20)]
    public string Priority { get; set; } = "Standard";

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class SaveBuyingListLineRequest
{
    public int? ProductId { get; set; }
    public int? RawStockItemId { get; set; }

    [Range(typeof(decimal), "0", "1000000")]
    public decimal RecommendedQuantity { get; set; }

    [Range(typeof(decimal), "0.001", "1000000")]
    public decimal RequiredQuantity { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string Priority { get; set; } = "Standard";

    public int? PreferredSupplierId { get; set; }

    [MaxLength(1000)]
    public string? ManagementNotes { get; set; }

    public string? RowVersion { get; set; }
}

public sealed class AssignBuyingListRequest
{
    [Range(1, int.MaxValue)]
    public int AssignedBuyerUserId { get; set; }

    [Required, MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class BuyingListCommandRequest
{
    [Required, MinLength(3), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class BuyingListOptionsDto
{
    public required IReadOnlyList<BuyingListOptionDto> Statuses { get; init; }
    public required IReadOnlyList<BuyingListOptionDto> Priorities { get; init; }
    public required IReadOnlyList<BuyingListBuyerOptionDto> Buyers { get; init; }
    public required IReadOnlyList<BuyingListRawStockOptionDto> RawStockItems { get; init; }
    public required IReadOnlyList<BuyingListSupplierOptionDto> Suppliers { get; init; }
}

public sealed record BuyingListOptionDto(string Code, string Name);

public sealed record BuyingListBuyerOptionDto(
    int UserId,
    string DisplayName,
    string Email);

public sealed record BuyingListRawStockOptionDto(
    int RawStockItemId,
    string ItemCode,
    string ItemName,
    string CategoryCode,
    string UnitOfMeasure,
    decimal CurrentBalance);

public sealed record BuyingListSupplierOptionDto(
    int SupplierId,
    string SupplierName);
