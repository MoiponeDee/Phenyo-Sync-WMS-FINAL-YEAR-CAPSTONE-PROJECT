using System.ComponentModel.DataAnnotations;

// Expiry contracts distinguish display data from state-changing action requests.
namespace PhenyoSyncAPI.DTOs.Expiry
{
    public class ExpiryAlertDto
    {
        public int ProductBatchId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string ProductCategoryName { get; set; } = string.Empty;
        public string BatchCode { get; set; } = string.Empty;
        public string SectionName { get; set; } = string.Empty;
        public decimal QuantityRemainingKg { get; set; }
        public DateTime PackedAtUtc { get; set; }
        public DateTime EffectiveExpiryAtUtc { get; set; }
        public double RemainingHours { get; set; }
        public string AlertLevel { get; set; } = string.Empty;
        public string BatchStatus { get; set; } = string.Empty;
        public bool ShelfLifeExtended { get; set; }
    }

    public class ExpiryAlertSummaryDto
    {
        public int WarningCount { get; set; }
        public int UrgentCount { get; set; }
        public int ExpiredCount { get; set; }
        public IReadOnlyList<ExpiryAlertDto> Batches { get; set; }
            = Array.Empty<ExpiryAlertDto>();
    }

    public class ExpiryActionReviewDto : ExpiryAlertDto
    {
        public bool CanExtend { get; set; }
        public bool CanWriteOff { get; set; }
        public int ShelfLifeExtensionDays { get; set; }
        public DateTime TokenExpiresAtUtc { get; set; }
    }

    public class ExpiryDecisionDto
    {
        [Required, MinLength(5), MaxLength(500)]
        public string Reason { get; set; } = string.Empty;

        [Range(typeof(bool), "true", "true", ErrorMessage = "Confirmation is required.")]
        public bool Confirmed { get; set; }

        public DateTime? NewExpiryAtUtc { get; set; }
    }
}
