using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Procurement;

// Procurement projections distinguish calculated shortages from management-approved Buying List inputs.

public sealed class SaveProductRawStockRequirementRequest
{
    [Range(1, int.MaxValue)]
    public int RawStockItemId { get; set; }

    [Range(typeof(decimal), "0.0001", "1000000")]
    public decimal RawQuantityPerProductUnit { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = "kg";

    [Range(typeof(decimal), "0", "99.9999")]
    public decimal WastePercentage { get; set; }

    [Range(typeof(decimal), "0.0001", "100")]
    public decimal YieldPercentage { get; set; } = 100;

    public bool IsActive { get; set; } = true;
    public string? RowVersion { get; set; }
}

public sealed class ProductRawStockRequirementDto
{
    public int ProductRawStockRequirementId { get; init; }
    public int ProductId { get; init; }
    public required string ProductName { get; init; }
    public int RawStockItemId { get; init; }
    public required string RawStockItemCode { get; init; }
    public required string RawStockItemName { get; init; }
    public decimal RawQuantityPerProductUnit { get; init; }
    public required string UnitOfMeasure { get; init; }
    public decimal WastePercentage { get; init; }
    public decimal YieldPercentage { get; init; }
    public bool IsActive { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class ProcurementShortageSuggestionDto
{
    public int RawStockItemId { get; init; }
    public required string ItemCode { get; init; }
    public required string ItemName { get; init; }
    public required string UnitOfMeasure { get; init; }
    public decimal GrossRawRequirement { get; init; }
    public decimal UsableRawStock { get; init; }
    public decimal SupplierOrderOutstanding { get; init; }
    public decimal BuyingListOutstanding { get; init; }
    public decimal SuggestedPurchaseQuantity { get; init; }
    public required IReadOnlyList<ProcurementDemandBreakdownDto> DemandBreakdown
        { get; init; }
}

public sealed class ProcurementDemandBreakdownDto
{
    public int ProductId { get; init; }
    public required string ProductName { get; init; }
    public decimal UnfulfilledDemand { get; init; }
    public decimal FinishedStockAvailable { get; init; }
    public decimal FinishedProductShortage { get; init; }
    public decimal RawQuantityPerProductUnit { get; init; }
    public decimal WastePercentage { get; init; }
    public decimal YieldPercentage { get; init; }
    public decimal RawQuantityRequired { get; init; }
}

public sealed class UnmappedProductDemandDto
{
    public int ProductId { get; init; }
    public required string ProductName { get; init; }
    public decimal UnfulfilledDemand { get; init; }
    public required string Guidance { get; init; }
}
