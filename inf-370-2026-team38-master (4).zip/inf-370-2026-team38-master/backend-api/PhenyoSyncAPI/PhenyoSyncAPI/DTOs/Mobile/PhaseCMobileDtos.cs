using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Mobile;

// Mobile DTOs contain only workflow inputs/outputs; user identity and authorization come from JWT.

public sealed class MobileDashboardDto
{
    public required string RoleCode { get; init; }
    public required string DisplayName { get; init; }
    public int UnreadNotifications { get; init; }
    public int DeliveriesToday { get; init; }
    public int ActiveDeliveries { get; init; }
    public int BuyingItemsRemaining { get; init; }
    public int DraftStockReceipts { get; init; }
    public int PackingTasks { get; init; }
    public int DispatchQueue { get; init; }
    public int CriticalExpiryAlerts { get; init; }
    public int PendingWriteOffApprovals { get; init; }
    public string WorkloadChartTitle { get; init; } = "Current workload";
    public string ActivityTrendTitle { get; init; } = "Seven-day activity";
    public IReadOnlyList<MobileDashboardChartPointDto> WorkloadChart { get; init; } = [];
    public IReadOnlyList<MobileDashboardChartPointDto> ActivityTrend { get; init; } = [];
    public required IReadOnlyList<MobileModuleDto> Modules { get; init; }
}

public sealed record MobileDashboardChartPointDto(
    string Label,
    int Value);

public sealed record MobileModuleDto(
    string Code,
    string Title,
    string Route,
    string Icon,
    int BadgeCount = 0);

public sealed class MobileDeliverySummaryDto
{
    public int DeliveryId { get; init; }
    public int SalesOrderId { get; init; }
    public required string OrderNumber { get; init; }
    public required string CustomerName { get; init; }
    public string? ContactPerson { get; init; }
    public string? PhoneNumber { get; init; }
    public required string DeliveryAddress { get; init; }
    public DateTime ScheduledStartUtc { get; init; }
    public DateTime ScheduledEndUtc { get; init; }
    public required string Status { get; init; }
    public string? Vehicle { get; init; }
    public string? DriverName { get; init; }
    public required IReadOnlyList<string> ItemSummary { get; init; }
    public DateTime? LastTrackingUpdateUtc { get; init; }
    public decimal? LastTrackingAccuracyMetres { get; init; }
    public bool HasActiveTracking { get; init; }
    public bool HasProof { get; init; }
}

public sealed class MobileDeliveryEventRequest
{
    [Required, MaxLength(1000)]
    public string Notes { get; set; } = string.Empty;

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;
}

public sealed class StartTrackingRequest
{
    [Range(typeof(bool), "true", "true")]
    public bool ConsentConfirmed { get; set; }

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;
}

public sealed class StopTrackingRequest
{
    [Required, MinLength(3), MaxLength(300)]
    public string Reason { get; set; } = string.Empty;

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;
}

public sealed class DriverLocationRequest
{
    [Range(-90, 90)]
    public decimal Latitude { get; set; }

    [Range(-180, 180)]
    public decimal Longitude { get; set; }

    [Range(0, 10000)]
    public decimal AccuracyMetres { get; set; }

    [Range(0, 300)]
    public decimal? SpeedMetresPerSecond { get; set; }

    [Range(0, 360)]
    public decimal? HeadingDegrees { get; set; }

    public DateTime CapturedAtUtc { get; set; }

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;
}

public sealed class TrackingSessionDto
{
    public long TrackingSessionId { get; init; }
    public int DeliveryId { get; init; }
    public int DriverId { get; init; }
    public required string DriverName { get; init; }
    public required string Status { get; init; }
    public DateTime StartedAtUtc { get; init; }
    public DateTime? EndedAtUtc { get; init; }
    public DriverLocationDto? LatestLocation { get; init; }
}

public sealed class DriverLocationDto
{
    public decimal Latitude { get; init; }
    public decimal Longitude { get; init; }
    public decimal AccuracyMetres { get; init; }
    public decimal? SpeedMetresPerSecond { get; init; }
    public decimal? HeadingDegrees { get; init; }
    public DateTime CapturedAtUtc { get; init; }
    public DateTime ReceivedAtUtc { get; init; }
}

public sealed class CalculateRouteRequest
{
    [Range(-90, 90)]
    public decimal OriginLatitude { get; set; }

    [Range(-180, 180)]
    public decimal OriginLongitude { get; set; }

    [Range(-90, 90)]
    public decimal DestinationLatitude { get; set; }

    [Range(-180, 180)]
    public decimal DestinationLongitude { get; set; }

    public bool ForceRefresh { get; set; }
}

public sealed class DeliveryRouteDto
{
    public long? RouteCalculationId { get; init; }
    public int DeliveryId { get; init; }
    public bool ProviderConfigured { get; init; }
    public bool FromCache { get; init; }
    public string Provider { get; init; } = "GoogleRoutes";
    public long DistanceMetres { get; init; }
    public int DurationSeconds { get; init; }
    public int? TrafficDurationSeconds { get; init; }
    public string? EncodedPolyline { get; init; }
    public DateTime? CalculatedAtUtc { get; init; }
    public DateTime? ExpiresAtUtc { get; init; }
    public string? ConfigurationMessage { get; init; }
}

public sealed class NotificationDto
{
    public long NotificationRecipientId { get; init; }
    public long NotificationId { get; init; }
    public required string Type { get; init; }
    public required string Severity { get; init; }
    public required string Title { get; init; }
    public required string Message { get; init; }
    public string? ActionRoute { get; init; }
    public DateTime CreatedAtUtc { get; init; }
    public DateTime? ReadAtUtc { get; init; }
    public required string PushStatus { get; init; }
}

public sealed class NotificationInboxDto
{
    public int UnreadCount { get; init; }
    public required IReadOnlyList<NotificationDto> Items { get; init; }
}

public sealed class NotificationPreferenceDto
{
    public bool PushEnabled { get; set; } = true;
    public bool EmailFallbackEnabled { get; set; }
    public bool CriticalAlertsEnabled { get; set; } = true;

    [RegularExpression(@"^([01]\d|2[0-3]):[0-5]\d$")]
    public string? QuietHoursStart { get; set; }

    [RegularExpression(@"^([01]\d|2[0-3]):[0-5]\d$")]
    public string? QuietHoursEnd { get; set; }
}

public sealed class RegisterMobileDeviceRequest
{
    [Required, MinLength(16), MaxLength(300)]
    public string DeviceIdentifier { get; set; } = string.Empty;

    [Required, MaxLength(30)]
    public string Platform { get; set; } = "Android";

    [MaxLength(120)]
    public string? DeviceName { get; set; }

    [MaxLength(40)]
    public string? AppVersion { get; set; }

    [MaxLength(2048)]
    public string? PushToken { get; set; }
}

public sealed class MobileDeviceDto
{
    public long MobileDeviceRegistrationId { get; init; }
    public required string Platform { get; init; }
    public string? DeviceName { get; init; }
    public string? AppVersion { get; init; }
    public DateTime RegisteredAtUtc { get; init; }
    public DateTime LastSeenAtUtc { get; init; }
    public bool IsActive { get; init; }
    public DateTime? RevokedAtUtc { get; init; }
}

public sealed class BuyingListDto
{
    public int BuyerProcurementId { get; init; }
    public required string ReferenceNumber { get; init; }
    public string? Title { get; init; }
    public DateTime BuyingDateUtc { get; init; }
    public int? AssignedBuyerUserId { get; init; }
    public required string BuyerName { get; init; }
    public required string Priority { get; init; }
    public required string Status { get; init; }
    public string? Notes { get; init; }
    public DateTime? PublishedAtUtc { get; init; }
    public DateTime? SubmittedAtUtc { get; init; }
    public long? DocketStoredFileId { get; init; }
    public required string RowVersion { get; init; }
    public required IReadOnlyList<BuyingListItemDto> Items { get; init; }
}

public sealed class CreateBuyingListRequest
{
    [Range(1, int.MaxValue)]
    public int AssignedBuyerUserId { get; set; }

    public DateTime BuyingDateUtc { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [MinLength(1)]
    public List<CreateBuyingListItemRequest> Items { get; set; } = [];
}

public sealed class CreateBuyingListItemRequest
{
    public int? ProductId { get; set; }
    public int? RawStockItemId { get; set; }

    [Range(typeof(decimal), "0", "1000000")]
    public decimal RecommendedQuantity { get; set; }

    [Range(typeof(decimal), "0.01", "1000000")]
    public decimal RequiredQuantity { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = "kg";
}

public sealed class BuyingListItemDto
{
    public int BuyerProcurementItemId { get; init; }
    public int? ProductId { get; init; }
    public int? RawStockItemId { get; init; }
    public required string ProductCode { get; init; }
    public required string ProductName { get; init; }
    public required string CategoryName { get; init; }
    public decimal CurrentStockKg { get; init; }
    public decimal RecommendedQuantity { get; init; }
    public decimal RequiredQuantity { get; init; }
    public decimal? ActualQuantity { get; init; }
    public decimal? ActualUnitPrice { get; init; }
    public decimal ReceivedQuantity { get; init; }
    public decimal OutstandingQuantity { get; init; }
    public int? SupplierId { get; init; }
    public string? SupplierName { get; init; }
    public int? PreferredSupplierId { get; init; }
    public string? PreferredSupplierName { get; init; }
    public required string UnitOfMeasure { get; init; }
    public required string Priority { get; init; }
    public required string Status { get; init; }
    public bool IsPromotionalItem { get; init; }
    public string? ManagementNotes { get; init; }
    public string? BuyerNotes { get; init; }
    public string? UnavailableReason { get; init; }
    public int? SubstituteRawStockItemId { get; init; }
    public string? SubstituteItemName { get; init; }
    public string? SubstituteNotes { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class UpdateBuyingListItemRequest
{
    [Required, MaxLength(30)]
    public string Status { get; set; } = string.Empty;

    [Range(0, 1_000_000)]
    public decimal? ActualQuantity { get; set; }

    [Range(0, 1_000_000)]
    public decimal? ActualUnitPrice { get; set; }

    public int? SupplierId { get; set; }

    [MaxLength(1000)]
    public string? BuyerNotes { get; set; }

    [MaxLength(500)]
    public string? UnavailableReason { get; set; }

    public int? SubstituteRawStockItemId { get; set; }

    [MaxLength(500)]
    public string? SubstituteNotes { get; set; }

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;

    public string? RowVersion { get; set; }
}

public sealed class AddBuyingListItemRequest
{
    public int? ProductId { get; set; }
    public int? RawStockItemId { get; set; }

    [Range(typeof(decimal), "0.01", "1000000")]
    public decimal RequiredQuantity { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = "kg";

    [Range(1, int.MaxValue)]
    public int SupplierId { get; set; }

    [Range(typeof(decimal), "0.01", "1000000")]
    public decimal ActualQuantity { get; set; }

    [Range(typeof(decimal), "0", "1000000")]
    public decimal ActualUnitPrice { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;
}

public sealed class CreateStockReceiptRequest
{
    [Range(1, int.MaxValue)]
    public int SupplierId { get; set; }

    public int? SupplierOrderId { get; set; }

    [Range(1, int.MaxValue)]
    public int WarehouseSectionId { get; set; }

    [MaxLength(100)]
    public string? SupplierDocketNumber { get; set; }

    public DateTime PurchaseDateUtc { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;
}

public sealed class StockReceiptItemRequest
{
    [Range(1, int.MaxValue)]
    public int ProductId { get; set; }

    [Range(typeof(decimal), "0.01", "1000000")]
    public decimal QuantityReceivedKg { get; set; }

    [Range(typeof(decimal), "0", "1000000")]
    public decimal AcceptedQuantityKg { get; set; }

    [Range(typeof(decimal), "0", "1000000")]
    public decimal RejectedQuantityKg { get; set; }

    [Required]
    [Range(typeof(decimal), "0.01", "1000000")]
    public decimal? UnitCost { get; set; }

    [Range(0, 1_000_000)]
    public int? ContainerCount { get; set; }

    [MaxLength(30)]
    public string? ContainerType { get; set; }

    [MaxLength(80)]
    public string? BatchReference { get; set; }

    public DateTime ReceivedAtUtc { get; set; }
    public DateTime BestBeforeAtUtc { get; set; }

    [Required, MaxLength(30)]
    public string QualityStatus { get; set; } = "Accepted";

    [MaxLength(1000)]
    public string? Notes { get; set; }
}

public sealed class StockReceiptDto
{
    public int StockReceiptId { get; init; }
    public required string ReceiptNumber { get; init; }
    public required string SupplierName { get; init; }
    public required string WarehouseSection { get; init; }
    public required string ReceiverName { get; init; }
    public required string Status { get; init; }
    public DateTime PurchaseDateUtc { get; init; }
    public DateTime? SubmittedAtUtc { get; init; }
    public required string CorrelationId { get; init; }
    public required string RowVersion { get; init; }
    public required IReadOnlyList<StockReceiptLineDto> Items { get; init; }
}

public sealed class StockReceiptLineDto
{
    public int StockReceiptItemId { get; init; }
    public int ProductId { get; init; }
    public required string ProductName { get; init; }
    public decimal QuantityReceivedKg { get; init; }
    public decimal AcceptedQuantityKg { get; init; }
    public decimal RejectedQuantityKg { get; init; }
    public decimal? UnitCost { get; init; }
    public string? BatchReference { get; init; }
    public DateTime BestBeforeAtUtc { get; init; }
    public required string QualityStatus { get; init; }
}

public sealed class PackingTaskDto
{
    public int SalesOrderId { get; init; }
    public required string OrderNumber { get; init; }
    public required string CustomerName { get; init; }
    public required string Status { get; init; }
    public DateTime? RequestedDeliveryDateUtc { get; init; }
    public decimal CompletionPercentage { get; init; }
    public int RemainingLineCount { get; init; }
}

public sealed class PackingTaskDetailDto
{
    public int SalesOrderId { get; init; }
    public required string OrderNumber { get; init; }
    public required string CustomerName { get; init; }
    public required string Status { get; init; }
    public required IReadOnlyList<PackingLineDto> Lines { get; init; }
    public required IReadOnlyList<PackingScanDto> Scans { get; init; }
}

public sealed class PackingLineDto
{
    public int SalesOrderItemId { get; init; }
    public int ProductId { get; init; }
    public required string ProductName { get; init; }
    public required string ProductSize { get; init; }
    public decimal OrderedQuantityUnits { get; init; }
    public required string SellingUnit { get; init; }
    public decimal? KilogramsPerUnit { get; init; }
    public decimal? RequiredQuantityKg { get; init; }
    public decimal AvailableQuantityKg { get; init; }
    public decimal PackedQuantityKg { get; init; }
    public decimal? RemainingQuantityKg { get; init; }
}

public sealed class PackingScanDto
{
    public long PackingScanId { get; init; }
    public int ProductBatchId { get; init; }
    public required string BatchCode { get; init; }
    public required string ProductName { get; init; }
    public required string ProductSize { get; init; }
    public DateTime BestBeforeAtUtc { get; init; }
    public decimal AvailableQuantity { get; init; }
    public decimal QuantityPackedKg { get; init; }
    public DateTime ScannedAtUtc { get; init; }
    public bool IsRemoved { get; init; }
}

public sealed class PackingScanRequest
{
    [Required, MaxLength(500)]
    public string Code { get; set; } = string.Empty;

    [Range(typeof(decimal), "0.01", "1000000")]
    public decimal QuantityKg { get; set; }

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;
}

public sealed class ReasonRequest
{
    [Required, MinLength(3), MaxLength(1000)]
    public string Reason { get; set; } = string.Empty;

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;

    public string? RowVersion { get; set; }
}

public sealed class DispatchOrderDto
{
    public int SalesOrderId { get; init; }
    public required string OrderNumber { get; init; }
    public required string CustomerName { get; init; }
    public required string Status { get; init; }
    public DateTime? PackedAtUtc { get; init; }
    public string? PackerName { get; init; }
    public int ScanCount { get; init; }
    public decimal PackedQuantityKg { get; init; }
    public int? DeliveryId { get; init; }
    public string? DriverName { get; init; }
    public string? Vehicle { get; init; }
}

public sealed class CreateWriteOffRequest
{
    [Range(1, int.MaxValue)]
    public int ProductBatchId { get; set; }

    [Range(typeof(decimal), "0.01", "1000000")]
    public decimal QuantityKg { get; set; }

    [Range(typeof(decimal), "0.01", "1000000")]
    public decimal? EstimatedUnitCost { get; set; }

    [Required, MaxLength(80)]
    public string ReasonCode { get; set; } = string.Empty;

    [MaxLength(120)]
    public string? Condition { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;
}

public sealed class StockWriteOffDto
{
    public long StockWriteOffId { get; init; }
    public int ProductBatchId { get; init; }
    public required string ProductName { get; init; }
    public required string ProductCode { get; init; }
    public required string BatchCode { get; init; }
    public required string WarehouseSection { get; init; }
    public decimal AvailableQuantityKg { get; init; }
    public decimal QuantityKg { get; init; }
    public decimal? EstimatedUnitCost { get; init; }
    public decimal? EstimatedTotalLoss { get; init; }
    public required string ReasonCode { get; init; }
    public string? Condition { get; init; }
    public string? Notes { get; init; }
    public required string Status { get; init; }
    public required string SubmittedBy { get; init; }
    public DateTime SubmittedAtUtc { get; init; }
    public string? DecidedBy { get; init; }
    public DateTime? DecidedAtUtc { get; init; }
    public int EvidenceCount { get; init; }
    public bool RequiresPhoto { get; init; }
    public bool RequiresApproval { get; init; }
    public required string CorrelationId { get; init; }
    public required string RowVersion { get; init; }
}
