using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Auth;

// Authentication requests carry one-time plaintext values only long enough for server-side hash checks.

public sealed class VerifyOtpRequest
{
    [Required, MaxLength(200)]
    public string ChallengeToken { get; set; } = string.Empty;

    [Required, RegularExpression(@"^\d{6}$")]
    public string Otp { get; set; } = string.Empty;

    public bool TrustDevice { get; set; }

    [MaxLength(120)]
    public string? DeviceName { get; set; }
}

public sealed class ResendOtpRequest
{
    [Required, MaxLength(200)]
    public string ChallengeToken { get; set; } = string.Empty;
}

public sealed class VerifyRecoveryCodeRequest
{
    [Required, MaxLength(200)]
    public string ChallengeToken { get; set; } = string.Empty;

    [Required, MinLength(8), MaxLength(40)]
    public string RecoveryCode { get; set; } = string.Empty;

    public bool TrustDevice { get; set; }

    [MaxLength(120)]
    public string? DeviceName { get; set; }
}

public sealed class RegenerateRecoveryCodesRequest
{
    [Required, MinLength(8), MaxLength(200)]
    public string CurrentPassword { get; set; } = string.Empty;
}

public sealed record TwoFactorChallengeResponse(
    bool RequiresTwoFactor,
    string ChallengeToken,
    string MaskedDestination,
    DateTime ExpiresAtUtc,
    int ResendAfterSeconds,
    int AttemptsRemaining,
    bool EmailDeliveryFailed = false,
    string? Message = null);

public sealed record AuthenticationResponse(
    string Token,
    int UserId,
    string Email,
    string FirstName,
    string LastName,
    string Role,
    IReadOnlyList<string>? RecoveryCodes = null);

public sealed record TrustedDeviceDto(
    long TrustedDeviceId,
    string DeviceName,
    string? UserAgentSummary,
    DateTime CreatedAtUtc,
    DateTime LastUsedAtUtc,
    DateTime ExpiresAtUtc,
    bool IsCurrent);

public sealed record RecoveryCodeStatusDto(
    int RemainingCount,
    DateTime? LastGeneratedAtUtc);
