using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Auth;

public sealed class MyProfileDto
{
    public int UserId { get; init; }
    public string FirstName { get; init; } = string.Empty;
    public string LastName { get; init; } = string.Empty;
    public string Username { get; init; } = string.Empty;
    public string Email { get; init; } = string.Empty;
    public string? PhoneNumber { get; init; }
    public string RoleCode { get; init; } = string.Empty;
    public string RoleName { get; init; } = string.Empty;
    public string? LicenseNumber { get; init; }
    public DateTime? LicenseExpiryDate { get; init; }
    public string? VehicleAssigned { get; init; }
    public string? AvailabilityStatus { get; init; }
    public string RowVersion { get; init; } = string.Empty;
}

public sealed class UpdateMyProfileRequest
{
    // Self-service profile editing is deliberately narrow. Identity, login,
    // role and Driver licence fields are maintained through authorised admin
    // workflows, so the browser cannot bind them to this request model.
    [MaxLength(20)]
    public string? PhoneNumber { get; init; }

    [Required]
    public string RowVersion { get; init; } = string.Empty;
}

public sealed class ChangeMyPasswordRequest
{
    [Required]
    public string CurrentPassword { get; init; } = string.Empty;

    [Required, MinLength(8)]
    public string NewPassword { get; init; } = string.Empty;

    [Required]
    public string ConfirmPassword { get; init; } = string.Empty;
}
