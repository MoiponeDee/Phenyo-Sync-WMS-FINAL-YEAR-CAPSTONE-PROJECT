﻿namespace PhenyoSyncAPI.DTOs.Auth
{
// Defines the authentication boundary without exposing credential-storage details.
    public class LoginDto
    {
        public string Email { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;

        public string Client { get; set; } = AuthenticationClients.Web;
    }

    public static class AuthenticationClients
    {
        public const string Web = "Web";
        public const string Mobile = "Mobile";

        public static IReadOnlySet<string> Allowed { get; } =
            new HashSet<string>(
                [Web, Mobile],
                StringComparer.OrdinalIgnoreCase);
    }
}
