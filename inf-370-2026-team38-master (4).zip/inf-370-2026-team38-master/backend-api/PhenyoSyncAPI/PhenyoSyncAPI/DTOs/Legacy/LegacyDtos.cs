using System.ComponentModel.DataAnnotations;

// Compatibility contracts isolate legacy client shapes from the current domain model.
namespace PhenyoSyncAPI.DTOs.Legacy;

public sealed class SaveSupplierRequest
{
    [Required, StringLength(150, MinimumLength = 2)]
    public string SupplierName { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? ContactPerson { get; set; }

    [EmailAddress, MaxLength(150)]
    public string? Email { get; set; }

    [Phone, MaxLength(30)]
    public string? Phone { get; set; }

    [MaxLength(300)]
    public string? Address { get; set; }
}

public sealed class StartStockTakeRequest
{
    [Range(1, int.MaxValue)]
    public int SectionId { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }
}

public sealed class CreateDriverRequest
{
    [Range(1, int.MaxValue)]
    public int UserId { get; set; }

    [Required, StringLength(100, MinimumLength = 3)]
    public string LicenseNumber { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? VehicleAssigned { get; set; }

    [Required]
    [RegularExpression(
        "^(Available|Unavailable)$",
        ErrorMessage = "Availability status must be Available or Unavailable.")]
    public string AvailabilityStatus { get; set; } = "Available";
}
