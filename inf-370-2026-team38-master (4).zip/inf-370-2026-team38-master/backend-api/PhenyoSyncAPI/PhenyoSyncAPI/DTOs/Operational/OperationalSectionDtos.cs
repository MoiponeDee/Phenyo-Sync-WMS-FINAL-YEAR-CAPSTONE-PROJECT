using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Operational;

// Operational contracts keep user-entered quantities/reasons separate from calculated ledger data.

public sealed class PagedResult<T>
{
    public required IReadOnlyList<T> Items { get; init; }
    public int Page { get; init; }
    public int PageSize { get; init; }
    public int Total { get; init; }
}

public sealed class RawStockSearchRequest
{
    public string? Search { get; set; }
    public string? CategoryCode { get; set; }
    public string? UnitOfMeasure { get; set; }
    public int? WarehouseSectionId { get; set; }
    public bool IncludeInactive { get; set; }
    [Range(1, 100000)]
    public int Page { get; set; } = 1;
    [Range(1, 100)]
    public int PageSize { get; set; } = 20;
}

public sealed class RawStockSummaryDto
{
    public int RawStockItemId { get; init; }
    public required string ItemCode { get; init; }
    public required string ItemName { get; init; }
    public required string CategoryCode { get; init; }
    public required string UnitOfMeasure { get; init; }
    public bool IsProduce { get; init; }
    public bool IsActive { get; init; }
    public int RawStockBalanceId { get; init; }
    public int WarehouseSectionId { get; init; }
    public required string WarehouseSection { get; init; }
    public decimal QuantityOnHand { get; init; }
    public decimal ReservedQuantity { get; init; }
    public decimal? WeightedAverageUnitCost { get; init; }
    public DateTime? LastReceiptAtUtc { get; init; }
    public DateTime? LastStockTakeAtUtc { get; init; }
    public bool HasCriticalAlert { get; init; }
    public bool CanDelete { get; init; }
    public bool CanDeactivate { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class CreateRawStockRequest
{
    [Required, MaxLength(40)]
    public string ItemCode { get; set; } = string.Empty;

    [Required, MaxLength(160)]
    public string ItemName { get; set; } = string.Empty;

    [Required, MaxLength(30)]
    public string CategoryCode { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int WarehouseSectionId { get; set; }

    [Range(typeof(decimal), "0", "1000000000")]
    public decimal InitialQuantity { get; set; }

    [Range(typeof(decimal), "0.001", "1000000000")]
    public decimal? InitialUnitCost { get; set; }

    [MaxLength(80)]
    public string? BatchReference { get; set; }

    public DateTime? BestBeforeAtUtc { get; set; }

    [Required, MaxLength(1000)]
    public string Reason { get; set; } = string.Empty;
}

public sealed class CreateRawStockReceiptRequest
{
    [Required, MaxLength(30)]
    public string SourceType { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int? SupplierId { get; set; }

    public int? SupplierOrderId { get; set; }
    public int? BuyerProcurementId { get; set; }

    [Range(1, int.MaxValue)]
    public int WarehouseSectionId { get; set; }

    [Required, MaxLength(120)]
    public string DocketReference { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? AdHocExplanation { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public DateTime ReceivedAtUtc { get; set; }

    [Required, MaxLength(80)]
    public string OperationId { get; set; } = string.Empty;

    [MinLength(1)]
    public List<CreateRawStockReceiptLineRequest> Lines { get; set; } = [];
}

public sealed class CreateRawStockReceiptLineRequest
{
    [Range(1, int.MaxValue)]
    public int RawStockItemId { get; set; }

    public int? SupplierOrderLineId { get; set; }

    public int? BuyerProcurementItemId { get; set; }

    [Range(typeof(decimal), "0.001", "1000000000")]
    public decimal QuantityReceived { get; set; }

    [Range(typeof(decimal), "0", "1000000000")]
    public decimal AcceptedQuantity { get; set; }

    [Range(typeof(decimal), "0", "1000000000")]
    public decimal RejectedQuantity { get; set; }

    [Range(typeof(decimal), "0.001", "1000000000")]
    public decimal UnitCost { get; set; }

    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = string.Empty;

    [MaxLength(80)]
    public string? SupplierBatchReference { get; set; }

    public DateTime? BestBeforeAtUtc { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }
}

public sealed class RawStockReceiptDto
{
    public long RawStockReceiptId { get; init; }
    public required string ReceiptNumber { get; init; }
    public required string SourceType { get; init; }
    public required string SupplierName { get; init; }
    public string? SupplierOrderNumber { get; init; }
    public int? BuyerProcurementId { get; init; }
    public required string WarehouseSection { get; init; }
    public required string DocketReference { get; init; }
    public required string Status { get; init; }
    public DateTime ReceivedAtUtc { get; init; }
    public DateTime? PostedAtUtc { get; init; }
    public required string CorrelationId { get; init; }
    public required IReadOnlyList<RawStockReceiptLineDto> Lines { get; init; }
}

public sealed class RawStockReceiptLineDto
{
    public long RawStockReceiptLineId { get; init; }
    public int RawStockItemId { get; init; }
    public int? SupplierOrderLineId { get; init; }
    public int? BuyerProcurementItemId { get; init; }
    public required string ItemCode { get; init; }
    public required string ItemName { get; init; }
    public decimal QuantityReceived { get; init; }
    public decimal AcceptedQuantity { get; init; }
    public decimal RejectedQuantity { get; init; }
    public decimal UnitCost { get; init; }
    public required string UnitOfMeasure { get; init; }
    public string? BatchCode { get; init; }
    public string? QrCodeValue { get; init; }
}

public sealed class OperationalReasonSearchRequest
{
    public string? Search { get; set; }
    public string? CategoryCode { get; set; }
    public bool IncludeInactive { get; set; }
    [Range(1, 100000)]
    public int Page { get; set; } = 1;
    [Range(1, 100)]
    public int PageSize { get; set; } = 20;
}

public sealed class SaveOperationalReasonRequest
{
    [Required, MaxLength(40)]
    public string ReasonCode { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string ReasonName { get; set; } = string.Empty;

    [Required, MaxLength(40)]
    public string CategoryCode { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Description { get; set; }

    public bool IsActive { get; set; } = true;
    public string? RowVersion { get; set; }
}

public sealed class OperationalReasonDto
{
    public int OperationalReasonId { get; init; }
    public required string ReasonCode { get; init; }
    public required string ReasonName { get; init; }
    public required string CategoryCode { get; init; }
    public string? Description { get; init; }
    public bool IsActive { get; init; }
    public bool IsInUse { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class CreateRawStockTakeRequest
{
    [Range(1, int.MaxValue)]
    public int WarehouseSectionId { get; set; }
    public DateTime PeriodStartUtc { get; set; }
    public DateTime PeriodEndUtc { get; set; }
    [MaxLength(1000)]
    public string? Notes { get; set; }
}

public sealed class SaveRawStockCountRequest
{
    [Range(typeof(decimal), "0", "1000000000")]
    public decimal PhysicalStockCount { get; set; }
    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class RawStockTakeReviewRequest
{
    [Required, MinLength(3), MaxLength(1000)]
    public string Notes { get; set; } = string.Empty;
    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class RawStockTakeDecisionRequest
{
    public bool Approved { get; set; }
    [Required, MinLength(3), MaxLength(1000)]
    public string Reason { get; set; } = string.Empty;
    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class RowVersionRequest
{
    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class RawStockTakeDto
{
    public long RawStockTakeSessionId { get; init; }
    public required string WarehouseSection { get; init; }
    public required string StartedBy { get; init; }
    public DateTime CreatedAtUtc { get; init; }
    public DateTime? SubmittedAtUtc { get; init; }
    public string? ReviewedBy { get; init; }
    public DateTime? ReviewedAtUtc { get; init; }
    public string? DecidedBy { get; init; }
    public DateTime? DecidedAtUtc { get; init; }
    public DateTime PeriodStartUtc { get; init; }
    public DateTime PeriodEndUtc { get; init; }
    public required string Status { get; init; }
    public bool ManagementApprovalRequired { get; init; }
    public string? AdministratorReviewNotes { get; init; }
    public string? ManagementDecisionReason { get; init; }
    public required string CorrelationId { get; init; }
    public required string RowVersion { get; init; }
    public DateTime EstimateGeneratedAtUtc { get; init; }
    public required IReadOnlyList<RawStockTakeLineDto> Lines { get; init; }
}

public sealed class RawStockTakeLineDto
{
    public long RawStockTakeLineId { get; init; }
    public int RawStockItemId { get; init; }
    public required string ItemCode { get; init; }
    public required string ItemName { get; init; }
    public string? ReconciliationGroup { get; init; }
    public bool IsMapped { get; init; }
    public decimal OpeningRawStock { get; init; }
    public decimal RawStockReceived { get; init; }
    public decimal ApprovedPositiveAdjustments { get; init; }
    public decimal ExistingPackedProductWeight { get; init; }
    public decimal RecordedRawStockWriteOffs { get; init; }
    public decimal ApprovedNegativeAdjustments { get; init; }
    public decimal EstimatedRawStockRemaining { get; init; }
    public decimal? PhysicalStockCount { get; init; }
    public decimal? UnexplainedStockDifference { get; init; }
    public decimal? EstimatedFinancialImpact { get; init; }
    public bool ManagementApprovalRequired { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class CreateRawStockWriteOffRequest
{
    [Range(1, int.MaxValue)]
    public int RawStockBalanceId { get; set; }
    public long? RawStockBatchId { get; set; }
    [Range(1, int.MaxValue)]
    public int OperationalReasonId { get; set; }
    [Range(typeof(decimal), "0.001", "1000000000")]
    public decimal Quantity { get; set; }
    [MaxLength(120)]
    public string? Condition { get; set; }
    [MaxLength(1000)]
    public string? Notes { get; set; }
}

public sealed class RawStockWriteOffDecisionRequest
{
    public bool Approved { get; set; }
    [Required, MinLength(3), MaxLength(1000)]
    public string Reason { get; set; } = string.Empty;
    [Required]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class RawStockWriteOffDto
{
    public long RawStockWriteOffId { get; init; }
    public required string ItemName { get; init; }
    public required string WarehouseSection { get; init; }
    public decimal Quantity { get; init; }
    public decimal? EstimatedUnitCost { get; init; }
    public decimal? EstimatedTotalLoss { get; init; }
    public required string Reason { get; init; }
    public required string Status { get; init; }
    public bool RequiresManagementApproval { get; init; }
    public required string CorrelationId { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class ReconciliationGroupRequest
{
    [Required, MaxLength(40)]
    public string GroupCode { get; set; } = string.Empty;
    [Required, MaxLength(120)]
    public string GroupName { get; set; } = string.Empty;
    [MaxLength(1000)]
    public string? Description { get; set; }
    [MinLength(1)]
    public List<int> RawStockItemIds { get; set; } = [];
    [MinLength(1)]
    public List<int> ProductIds { get; set; } = [];
}

public sealed class ReconciliationGroupDto
{
    public int RawStockReconciliationGroupId { get; init; }
    public required string GroupCode { get; init; }
    public required string GroupName { get; init; }
    public required IReadOnlyList<string> RawStockItems { get; init; }
    public required IReadOnlyList<string> Products { get; init; }
}

public sealed class SaveCustomerRequest
{
    [Required, MaxLength(150)]
    public string CustomerName { get; set; } = string.Empty;
    [Required, EmailAddress, MaxLength(254)]
    public string Email { get; set; } = string.Empty;
    [MaxLength(150)]
    public string? ContactPerson { get; set; }
    [MaxLength(30)]
    public string? PhoneNumber { get; set; }
    [MaxLength(500)]
    public string? BillingAddress { get; set; }
    [MaxLength(500)]
    public string? DeliveryAddress { get; set; }
    [Required, MaxLength(20)]
    public string Status { get; set; } = "Active";
    public string? RowVersion { get; set; }
}

public sealed class CustomerSummaryDto
{
    public int CustomerId { get; init; }
    public required string CustomerNumber { get; init; }
    public required string CustomerName { get; init; }
    public required string Email { get; init; }
    public string? ContactPerson { get; init; }
    public string? PhoneNumber { get; init; }
    public string? BillingAddress { get; init; }
    public string? DeliveryAddress { get; init; }
    public required string Status { get; init; }
    public int OrderCount { get; init; }
    public decimal OutstandingBalance { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class SaveSupplierRequest
{
    [Required, MaxLength(160)]
    public string SupplierName { get; set; } = string.Empty;
    [Required, MaxLength(40)]
    public string SupplierTypeCode { get; set; } = string.Empty;
    [MaxLength(150)]
    public string? ContactPerson { get; set; }
    [EmailAddress, MaxLength(254)]
    public string? Email { get; set; }
    [MaxLength(30)]
    public string? Phone { get; set; }
    [MaxLength(500)]
    public string? Address { get; set; }
    [Required, MaxLength(20)]
    public string Status { get; set; } = "Active";
    public string? RowVersion { get; set; }
}

public sealed class SupplierSummaryDto
{
    public int SupplierId { get; init; }
    public required string SupplierCode { get; init; }
    public required string SupplierName { get; init; }
    public required string SupplierTypeCode { get; init; }
    public string? ContactPerson { get; init; }
    public string? Email { get; init; }
    public string? Phone { get; init; }
    public string? Address { get; init; }
    public required string Status { get; init; }
    public int OrderCount { get; init; }
    public decimal OutstandingBalance { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class CreateSupplierOrderRequest
{
    [Range(1, int.MaxValue)]
    public int SupplierId { get; set; }
    [Range(1, int.MaxValue)]
    public int WarehouseSectionId { get; set; }
    public DateTime? ExpectedDeliveryAtUtc { get; set; }
    [MaxLength(1000)]
    public string? Notes { get; set; }
    [MinLength(1)]
    public List<SupplierOrderLineRequest> Lines { get; set; } = [];
}

public sealed class SupplierOrderLineRequest
{
    [Range(1, int.MaxValue)]
    public int RawStockItemId { get; set; }
    [Range(typeof(decimal), "0.001", "1000000000")]
    public decimal OrderedQuantity { get; set; }
    [Range(typeof(decimal), "0", "1000000000")]
    public decimal ExpectedUnitPrice { get; set; }
    [Required, MaxLength(20)]
    public string UnitOfMeasure { get; set; } = string.Empty;
    [MaxLength(500)]
    public string? Notes { get; set; }
}

public sealed class SupplierOrderRawStockOptionDto
{
    public int RawStockItemId { get; init; }
    public required string ItemCode { get; init; }
    public required string ItemName { get; init; }
    public required string UnitOfMeasure { get; init; }
}

public sealed class SupplierOrderDto
{
    public int SupplierOrderId { get; init; }
    public int SupplierId { get; init; }
    public required string OrderNumber { get; init; }
    public required string SupplierName { get; init; }
    public string? SupplierContactPerson { get; init; }
    public string? SupplierEmail { get; init; }
    public string? SupplierPhone { get; init; }
    public int WarehouseSectionId { get; init; }
    public required string WarehouseSection { get; init; }
    public required string Status { get; init; }
    public DateTime OrderDateUtc { get; init; }
    public DateTime? ExpectedDeliveryAtUtc { get; init; }
    public decimal TotalAmount { get; init; }
    public decimal OutstandingBalance { get; init; }
    public required string RowVersion { get; init; }
    public required IReadOnlyList<SupplierOrderLineDto> Lines { get; init; }
}

public sealed class DeleteOperationalPartyRequest
{
    [Required, MinLength(5), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    public string? RowVersion { get; set; }
}

public sealed class ChangeRawStockStatusRequest
{
    public bool IsActive { get; set; }

    [Required, MinLength(5), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;
}

public sealed class SupplierOrderCommandRequest
{
    [Required]
    public string RowVersion { get; set; } = string.Empty;

    [Required, MinLength(3), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;
}

public sealed class SupplierOrderLineDto
{
    public int SupplierOrderLineId { get; init; }
    public int RawStockItemId { get; init; }
    public required string ItemName { get; init; }
    public decimal OrderedQuantity { get; init; }
    public decimal ReceivedQuantity { get; init; }
    public decimal ExpectedUnitPrice { get; init; }
    public required string UnitOfMeasure { get; init; }
}

public sealed class PaymentRequest
{
    public int? CustomerId { get; set; }
    public int? SalesOrderId { get; set; }
    public int? SupplierId { get; set; }
    public int? InvoiceId { get; set; }
    public int? SupplierOrderId { get; set; }
    [Range(typeof(decimal), "0.01", "1000000000")]
    public decimal Amount { get; set; }
    public DateTime PaymentDateUtc { get; set; }
    [Required, MaxLength(40)]
    public string PaymentMethodCode { get; set; } = string.Empty;
    [MaxLength(120)]
    public string? Reference { get; set; }
    [MaxLength(1000)]
    public string? Notes { get; set; }
}

public sealed class PaymentCustomerOptionDto
{
    public int CustomerId { get; init; }
    public required string CustomerNumber { get; init; }
    public required string CustomerName { get; init; }
    public string? ContactPerson { get; init; }
    public string? PhoneNumber { get; init; }
    public string? Email { get; init; }
}

public sealed class PaymentCustomerOrderOptionDto
{
    public int SalesOrderId { get; init; }
    public int CustomerId { get; init; }
    public required string OrderNumber { get; init; }
    public required string Status { get; init; }
    public decimal TotalAmount { get; init; }
    public DateTime OrderDateUtc { get; init; }
}

public sealed class PaymentInvoiceOptionDto
{
    public int InvoiceId { get; init; }
    public int SalesOrderId { get; init; }
    public int CustomerId { get; init; }
    public required string InvoiceNumber { get; init; }
    public decimal TotalAmount { get; init; }
    public decimal PaidAmount { get; init; }
    public decimal OutstandingAmount { get; init; }
    public DateTime IssuedAtUtc { get; init; }
}

public sealed class PaymentSupplierOptionDto
{
    public int SupplierId { get; init; }
    public required string SupplierCode { get; init; }
    public required string SupplierName { get; init; }
    public string? ContactPerson { get; init; }
    public string? PhoneNumber { get; init; }
    public string? Email { get; init; }
}

public sealed class PaymentSupplierOrderOptionDto
{
    public int SupplierOrderId { get; init; }
    public int SupplierId { get; init; }
    public required string OrderNumber { get; init; }
    public required string Status { get; init; }
    public decimal TotalAmount { get; init; }
    public decimal PaidAmount { get; init; }
    public decimal OutstandingAmount { get; init; }
    public DateTime? ExpectedDeliveryAtUtc { get; init; }
}

public sealed class PaymentCaptureOptionsDto
{
    public required IReadOnlyList<PaymentCustomerOptionDto> Customers { get; init; }
    public required IReadOnlyList<PaymentCustomerOrderOptionDto> CustomerOrders { get; init; }
    public required IReadOnlyList<PaymentInvoiceOptionDto> Invoices { get; init; }
    public required IReadOnlyList<PaymentSupplierOptionDto> Suppliers { get; init; }
    public required IReadOnlyList<PaymentSupplierOrderOptionDto> SupplierOrders { get; init; }
}

public sealed class PaymentDecisionRequest
{
    [Required, MinLength(3), MaxLength(1000)]
    public string Reason { get; set; } = string.Empty;
    public string? RowVersion { get; set; }
}

public sealed class PaymentSearchRequest
{
    [MaxLength(20)]
    public string? CounterpartyType { get; set; }
    [MaxLength(120)]
    public string? Search { get; set; }
    [MaxLength(40)]
    public string? Status { get; set; }
    [MaxLength(40)]
    public string? PaymentMethodCode { get; set; }
    public DateTime? FromUtc { get; set; }
    public DateTime? ToUtc { get; set; }
}

public sealed class PaymentDto
{
    public long FinancialPaymentId { get; init; }
    public long? OriginalPaymentId { get; init; }
    public required string PaymentNumber { get; init; }
    public required string CounterpartyType { get; init; }
    public required string CounterpartyName { get; init; }
    public string? CounterpartyNumber { get; init; }
    public string? DocumentNumber { get; init; }
    public string? Reference { get; init; }
    public string? OriginalPaymentNumber { get; init; }
    public decimal Amount { get; init; }
    public decimal OutstandingBeforePosting { get; init; }
    public decimal OutstandingAfterPosting { get; init; }
    public required string PaymentMethodCode { get; init; }
    public required string Status { get; init; }
    public string? ReversalReason { get; init; }
    public int CreatedByUserId { get; init; }
    public DateTime PaymentDateUtc { get; init; }
    public required string RowVersion { get; init; }
}

public sealed class DashboardGraphPointDto
{
    public required string Label { get; init; }
    public decimal Value { get; init; }
    public int Count { get; init; }
}

public sealed class ManagementDashboardDto
{
    public int PendingDispatches { get; init; }
    public int ActiveDeliveries { get; init; }
    public int PendingWriteOffApprovals { get; init; }
    public int PendingStockTakeApprovals { get; init; }
    public int CriticalExpiryAlerts { get; init; }
    public int BuyingListsAwaitingReceipt { get; init; }
    public required IReadOnlyList<DashboardGraphPointDto> WasteByReason { get; init; }
    public required IReadOnlyList<DashboardGraphPointDto> DeliveriesByStatus { get; init; }
}
