using System.ComponentModel.DataAnnotations;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.DTOs.PhaseB;

// Exchange DTOs expose validation summaries and opaque tokens rather than trusting parsed client rows.

public sealed class DataExchangeValidationResponseDto
{
    public string ValidationToken { get; set; } = string.Empty;
    public DateTime ExpiresAtUtc { get; set; }
    public int TotalRows { get; set; }
    public int ValidRows { get; set; }
    public int WarningRows { get; set; }
    public int InvalidRows { get; set; }
    public List<DataExchangePreviewRowDto> Rows { get; set; } = [];
}

public sealed class DataExchangePreviewRowDto
{
    public int RowNumber { get; set; }
    public string Status { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string RecordKey { get; set; } = string.Empty;
    public List<string> Messages { get; set; } = [];
    public decimal? ExpectedQuantity { get; set; }
    public decimal? CountedQuantity { get; set; }
    public decimal? Variance { get; set; }
}

public sealed class ApplyDataExchangeRequest
{
    [Required, StringLength(500, MinimumLength = 5)]
    public string Reason { get; set; } = string.Empty;
}

public sealed class DataExchangeApplyResponseDto
{
    public string Message { get; set; } = string.Empty;
    public string ResultToken { get; set; } = string.Empty;
    public int CreatedCount { get; set; }
    public int UpdatedCount { get; set; }
    public int AdjustmentCount { get; set; }
    public string CorrelationId { get; set; } = string.Empty;
}

public sealed class ProductExcelExportQueryDto
{
    public int? ProductCategoryId { get; set; }
    public int? ProductTypeId { get; set; }
    public string? ProductStatus { get; set; }
    public string? PriceStatus { get; set; }
    public bool IncludeInactive { get; set; }
    public DateTime? EffectiveAtUtc { get; set; }
}

public sealed class ProductExcelStagedPayload
{
    public string TemplateVersion { get; set; } = "2.1";
    public List<ProductExcelStagedRow> Rows { get; set; } = [];
}

public sealed class ProductExcelStagedRow
{
    public int RowNumber { get; set; }
    public int? ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string CategoryCode { get; set; } = string.Empty;
    public string ProductTypeCode { get; set; } = string.Empty;
    public string Size { get; set; } = string.Empty;
    public string UnitOfMeasure { get; set; } = "KG";
    public string SellingUnit { get; set; } = "kg";
    public decimal? KilogramsPerUnit { get; set; }
    public bool IsVariableWeight { get; set; } = true;
    public int ShelfLifeDays { get; set; }
    public string ProductStatus { get; set; } = "Active";
    public string PriceBasis { get; set; } = ProductPriceBases.PerKilogram;
    public decimal CurrentSellingPrice { get; set; }
    public DateTime? PriceEffectiveFromUtc { get; set; }
    public string PriceChangeReason { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string ValidationStatus { get; set; } = string.Empty;
    public List<string> Messages { get; set; } = [];
}

public sealed class StockCountExportQueryDto
{
    [Range(1, int.MaxValue)]
    public int WarehouseSectionId { get; set; }
    public int? ProductCategoryId { get; set; }
    public int? ProductTypeId { get; set; }
    public bool ActiveProductsOnly { get; set; } = true;
    public bool IncludeExpectedQuantities { get; set; } = true;
}

public sealed class StockCountPackageDto
{
    public string SchemaVersion { get; set; } = "2.0";
    public string ExportId { get; set; } = string.Empty;
    public DateTime ExportedAtUtc { get; set; }
    public StockCountExportedByDto ExportedBy { get; set; } = new();
    public StockCountWarehouseSectionDto WarehouseSection { get; set; } = new();
    public List<StockCountPackageItemDto> Items { get; set; } = [];
}

public sealed class StockCountExportedByDto
{
    public string DisplayName { get; set; } = string.Empty;
}

public sealed class StockCountWarehouseSectionDto
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}

public sealed class StockCountPackageItemDto
{
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string UnitOfMeasure { get; set; } = "KG";
    public decimal? ExpectedQuantity { get; set; }
    public decimal? CountedQuantity { get; set; }
}

public sealed class StockCountStagedPayload
{
    public string ExportId { get; set; } = string.Empty;
    public DateTime ExportedAtUtc { get; set; }
    public int WarehouseSectionId { get; set; }
    public List<StockCountStagedRow> Rows { get; set; } = [];
}

public sealed class StockCountStagedRow
{
    public int RowNumber { get; set; }
    public int ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string UnitOfMeasure { get; set; } = string.Empty;
    public decimal ExpectedQuantity { get; set; }
    public decimal CountedQuantity { get; set; }
    public decimal Variance { get; set; }
    public string ValidationStatus { get; set; } = string.Empty;
    public List<string> Messages { get; set; } = [];
}

public sealed class OperationsCalendarQueryDto
{
    [Required]
    public DateTime StartUtc { get; set; }

    [Required]
    public DateTime EndUtc { get; set; }

    public string? EventType { get; set; }
    public int? DriverId { get; set; }
    public int? CustomerId { get; set; }
    public string? DeliveryStatus { get; set; }
    public string? RiskLevel { get; set; }
    public int? WarehouseSectionId { get; set; }
    public int? ProductCategoryId { get; set; }
}

public sealed class OperationsCalendarResponseDto
{
    public DateTime StartUtc { get; set; }
    public DateTime EndUtc { get; set; }
    public string DefaultView { get; set; } = "month";
    public List<OperationsCalendarEventDto> Events { get; set; } = [];
}

public sealed class OperationsCalendarEventDto
{
    public string EventId { get; set; } = string.Empty;
    public string EventType { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public DateTime StartUtc { get; set; }
    public DateTime EndUtc { get; set; }
    public bool AllDay { get; set; }
    public string Status { get; set; } = string.Empty;
    public string RiskLevel { get; set; } = string.Empty;
    public string DetailRoute { get; set; } = string.Empty;
    public string AccessibleLabel { get; set; } = string.Empty;
    public int? DeliveryId { get; set; }
    public int? SalesOrderId { get; set; }
    public int? ProductBatchId { get; set; }
    public int? DriverId { get; set; }
}

public sealed class ProductBatchQrResultDto
{
    public int ProductBatchId { get; set; }
    public int ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string CategoryName { get; set; } = string.Empty;
    public string ProductTypeName { get; set; } = string.Empty;
    public string BatchCode { get; set; } = string.Empty;
    public string QrSummary { get; set; } = string.Empty;
    public DateTime PackedAtUtc { get; set; }
    public DateTime EffectiveExpiryAtUtc { get; set; }
    public string ExpiryRisk { get; set; } = string.Empty;
    public string BatchStatus { get; set; } = string.Empty;
    public string ProductStatus { get; set; } = string.Empty;
    public decimal AvailableQuantityKg { get; set; }
    public int WarehouseSectionId { get; set; }
    public string WarehouseSectionName { get; set; } = string.Empty;
}
