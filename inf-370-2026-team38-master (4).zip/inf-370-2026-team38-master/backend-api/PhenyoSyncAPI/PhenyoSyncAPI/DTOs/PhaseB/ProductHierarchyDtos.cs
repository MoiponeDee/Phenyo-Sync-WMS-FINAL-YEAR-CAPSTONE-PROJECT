using System.ComponentModel.DataAnnotations;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.DTOs.PhaseB;

// Hierarchy responses are purpose-built tree projections, not tracked EF navigation graphs.

public sealed class ProductHierarchyResponseDto
{
    public List<ProductHierarchyCategoryDto> Categories { get; set; } = [];
    public int CategoryCount { get; set; }
    public int TypeCount { get; set; }
    public int ProductCount { get; set; }
}

public sealed class ProductHierarchyCategoryDto
{
    public int ProductCategoryId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Status { get; set; } = string.Empty;
    public string RowVersion { get; set; } = string.Empty;
    public List<ProductHierarchyTypeDto> Types { get; set; } = [];
}

public sealed class ProductHierarchyTypeDto
{
    public int ProductCategoryTypeId { get; set; }
    public int ProductTypeId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Status { get; set; } = string.Empty;
    public string RowVersion { get; set; } = string.Empty;
    public List<ProductHierarchyProductDto> Products { get; set; } = [];
}

public sealed class ProductHierarchyProductDto
{
    public int ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Size { get; set; } = string.Empty;
    public int ShelfLifeDays { get; set; }
    public string Status { get; set; } = string.Empty;
    public decimal? CurrentSellingPrice { get; set; }
    public string CurrentPriceBasis { get; set; } = ProductPriceBases.PerKilogram;
    public string SellingUnit { get; set; } = "kg";
    public decimal? KilogramsPerUnit { get; set; }
    public bool IsVariableWeight { get; set; }
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class SaveHierarchyCategoryRequest
{
    [Required, StringLength(100, MinimumLength = 2)]
    public string Name { get; set; } = string.Empty;

    [StringLength(255)]
    public string? Description { get; set; }

    [RegularExpression("^(Active|Inactive)$")]
    public string Status { get; set; } = "Active";

    public string? RowVersion { get; set; }
}

public sealed class SaveHierarchyTypeRequest
{
    [Required, StringLength(100, MinimumLength = 2)]
    public string Name { get; set; } = string.Empty;

    [StringLength(255)]
    public string? Description { get; set; }

    [RegularExpression("^(Active|Inactive)$")]
    public string Status { get; set; } = "Active";

    public string? RowVersion { get; set; }
}

public sealed class MoveHierarchyTypeRequest
{
    [Range(1, int.MaxValue)]
    public int TargetCategoryId { get; set; }

    [Required, StringLength(500, MinimumLength = 5)]
    public string Reason { get; set; } = string.Empty;

    public string? RowVersion { get; set; }
}

public sealed class CreateHierarchyProductRequest
{
    [Required, StringLength(150, MinimumLength = 2)]
    public string ProductName { get; set; } = string.Empty;

    [Required, StringLength(50, MinimumLength = 1)]
    public string Size { get; set; } = string.Empty;

    [Range(1, 3650)]
    public int ShelfLifeDays { get; set; }

    [Range(typeof(decimal), "0.01", "999999999999.99")]
    public decimal? InitialSellingPrice { get; set; }

    [Required, RegularExpression("^(PerKilogram|PerSellableUnit)$")]
    public string InitialPriceBasis { get; set; } = ProductPriceBases.PerKilogram;

    [Required, StringLength(30, MinimumLength = 1)]
    public string SellingUnit { get; set; } = "kg";

    [Range(typeof(decimal), "0.001", "999999.999")]
    public decimal? KilogramsPerUnit { get; set; }

    public bool IsVariableWeight { get; set; } = true;

    [StringLength(500)]
    public string? PriceReason { get; set; }

    [Required, RegularExpression("^(Active|Inactive)$")]
    public string Status { get; set; } = ProductStatuses.Active;
}

public sealed class ReclassifyHierarchyProductRequest
{
    [Range(1, int.MaxValue)]
    public int ProductCategoryId { get; set; }

    [Range(1, int.MaxValue)]
    public int ProductTypeId { get; set; }

    [Required, StringLength(500, MinimumLength = 5)]
    public string Reason { get; set; } = string.Empty;

    public string? RowVersion { get; set; }
}

public sealed class ChangeHierarchyStatusRequest
{
    [Required, RegularExpression("^(Active|Inactive)$")]
    public string Status { get; set; } = string.Empty;

    [Required, StringLength(500, MinimumLength = 5)]
    public string Reason { get; set; } = string.Empty;

    public string? RowVersion { get; set; }
}

public sealed class DeleteHierarchyNodeRequest
{
    [Required, StringLength(500, MinimumLength = 5)]
    public string Reason { get; set; } = string.Empty;

    public string? RowVersion { get; set; }
}
