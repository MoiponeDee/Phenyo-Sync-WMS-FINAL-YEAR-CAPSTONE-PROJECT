using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Security;

// Security contracts expose friendly role data but never password hashes, OTP hashes or reset tokens.

public sealed class UserSearchQuery
{
    [MaxLength(150)]
    public string? Search { get; set; }

    [MaxLength(80)]
    public string? Role { get; set; }

    [RegularExpression(
        "^(Active|Inactive)$",
        ErrorMessage = "Status must be Active or Inactive.")]
    public string? Status { get; set; }

    [Range(1, int.MaxValue)]
    public int Page { get; set; } = 1;

    [Range(1, 100)]
    public int PageSize { get; set; } = 20;
}

public sealed class CreateUserRequest
{
    [Required, StringLength(50, MinimumLength = 2)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(50, MinimumLength = 2)]
    public string LastName { get; set; } = string.Empty;

    [Required, EmailAddress, MaxLength(100)]
    public string Email { get; set; } = string.Empty;

    [Phone, MaxLength(20)]
    public string? PhoneNumber { get; set; }

    [Range(1, int.MaxValue)]
    public int RoleId { get; set; }

    [StringLength(100, MinimumLength = 3)]
    public string? LicenseNumber { get; set; }

    public DateTime? LicenseExpiryDate { get; set; }

    [MaxLength(100)]
    public string? VehicleAssigned { get; set; }
}

public sealed class UpdateUserRequest
{
    [Required, StringLength(50, MinimumLength = 2)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(50, MinimumLength = 2)]
    public string LastName { get; set; } = string.Empty;

    [Required, EmailAddress, MaxLength(100)]
    public string Email { get; set; } = string.Empty;

    [Phone, MaxLength(20)]
    public string? PhoneNumber { get; set; }

    [Range(1, int.MaxValue)]
    public int? RoleId { get; set; }

    [MaxLength(500)]
    public string? RoleChangeReason { get; set; }

    [StringLength(100, MinimumLength = 3)]
    public string? LicenseNumber { get; set; }

    public DateTime? LicenseExpiryDate { get; set; }

    [MaxLength(100)]
    public string? VehicleAssigned { get; set; }

    [Required, MaxLength(200)]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class ChangeUserRoleRequest
{
    [Range(1, int.MaxValue)]
    public int RoleId { get; set; }

    [Required, MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class UserStatusRequest
{
    [Required, MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class RoleSearchQuery
{
    [MaxLength(150)]
    public string? Search { get; set; }
    public bool IncludeInactive { get; set; }
}

public sealed class CreateRoleRequest
{
    [Required]
    [RegularExpression(
        "^[A-Za-z][A-Za-z0-9._-]{2,49}$",
        ErrorMessage =
            "Role code must start with a letter and contain only letters, numbers, dots, underscores or hyphens.")]
    public string RoleCode { get; set; } = string.Empty;

    [Required, StringLength(80, MinimumLength = 3)]
    public string RoleName { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }

    public int? CopyFromRoleId { get; set; }
}

public sealed class UpdateRoleRequest
{
    [Required, StringLength(80, MinimumLength = 3)]
    public string RoleName { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }

    [Required, MaxLength(200)]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class RoleStatusRequest
{
    public bool IsActive { get; set; }

    [Required, MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class AssignRolePermissionsRequest
{
    public IReadOnlyCollection<int> PermissionIds { get; set; } =
        Array.Empty<int>();

    [Required, MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class PermissionSearchQuery
{
    [MaxLength(150)]
    public string? Search { get; set; }

    [MaxLength(80)]
    public string? Module { get; set; }

    public bool IncludeInactive { get; set; }
}

public sealed class CreatePermissionRequest
{
    [Required]
    [RegularExpression(
        "^[A-Za-z][A-Za-z0-9]+\\.[A-Za-z][A-Za-z0-9]+$",
        ErrorMessage = "Permission code must use the Module.Action format.")]
    public string PermissionCode { get; set; } = string.Empty;

    [Required, StringLength(120, MinimumLength = 3)]
    public string DisplayName { get; set; } = string.Empty;

    [Required, StringLength(80, MinimumLength = 2)]
    public string Module { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }
}

public sealed class UpdatePermissionRequest
{
    [Required, StringLength(120, MinimumLength = 3)]
    public string DisplayName { get; set; } = string.Empty;

    [Required, StringLength(80, MinimumLength = 2)]
    public string Module { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }

    [Required, MaxLength(200)]
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class PermissionStatusRequest
{
    public bool IsActive { get; set; }

    [Required, MaxLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string RowVersion { get; set; } = string.Empty;
}
