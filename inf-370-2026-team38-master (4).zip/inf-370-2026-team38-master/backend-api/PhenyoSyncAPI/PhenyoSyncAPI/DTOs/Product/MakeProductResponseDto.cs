namespace PhenyoSyncAPI.DTOs.Product
{
// Describes the creation result without exposing tracked entity state.
    public class MakeProductResponseDto
    {
        public string Message { get; set; } = string.Empty;
        public bool ProductCreated { get; set; }
        public int ProductId { get; set; }
        public string ProductCode { get; set; } = string.Empty;
        public int ProductBatchId { get; set; }
        public string BatchCode { get; set; } = string.Empty;
        public string QRCodeValue { get; set; } = string.Empty;
        public decimal QuantityAddedKg { get; set; }
        public decimal AggregateQuantityAvailableKg { get; set; }
        public DateTime PackedAtUtc { get; set; }
        public DateTime EffectiveExpiryAtUtc { get; set; }
        public long PackingConversionId { get; set; }
        public string CorrelationId { get; set; } = string.Empty;
        public decimal RawStockQuantityConsumed { get; set; }
    }

    public sealed class PackableRawStockRequirementDto
    {
        public int RawStockItemId { get; set; }
        public string ItemCode { get; set; } = string.Empty;
        public string ItemName { get; set; } = string.Empty;
        public string UnitOfMeasure { get; set; } = string.Empty;
        public decimal QuantityPerProductUnit { get; set; }
        public decimal AdjustedQuantityPerProductUnit { get; set; }
        public decimal AvailableQuantity { get; set; }
    }

    public sealed class PackableProductDto
    {
        public int ProductId { get; set; }
        public string ProductCode { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public string Size { get; set; } = string.Empty;
        public int ShelfLifeDays { get; set; }
        public decimal MaximumPackableQuantity { get; set; }
        public IReadOnlyList<PackableRawStockRequirementDto> Requirements
            { get; set; } = [];
    }
}
