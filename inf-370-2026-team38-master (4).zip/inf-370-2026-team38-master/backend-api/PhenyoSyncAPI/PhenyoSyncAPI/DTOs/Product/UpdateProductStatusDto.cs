using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Product
{
    public class UpdateProductStatusDto
    {
        [Required]
        [RegularExpression("^(Active|Inactive)$", ErrorMessage = "Status must be Active or Inactive.")]
        public string Status { get; set; } = string.Empty;
    }
}
