﻿using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Product
{
    public class CreateProductDto
    {
        [Range(1, int.MaxValue)]
        public int ProductId { get; set; }

        // Retained for source compatibility with older API clients. Production
        // now selects an existing Product by ProductId and ignores these fields.
        public string ProductName { get; set; } = string.Empty;
        public int ProductTypeId { get; set; }
        public int ProductCategoryId { get; set; }
        public string Size { get; set; } = string.Empty;
        public int ShelfLifeDays { get; set; }

        [Range(typeof(decimal), "0.01", "999999999999.99")]
        public decimal QuantityProducedKg { get; set; }

        [Range(1, int.MaxValue)]
        public int SectionId { get; set; }

        public DateTime? PackedAtUtc { get; set; }
    }
}
