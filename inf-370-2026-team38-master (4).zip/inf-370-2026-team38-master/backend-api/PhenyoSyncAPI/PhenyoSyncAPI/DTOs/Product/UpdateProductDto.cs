﻿using System.ComponentModel.DataAnnotations;

// Validates mutable fields while stock and pricing remain separate workflows.
namespace PhenyoSyncAPI.DTOs.Product
{
    public class UpdateProductDto
    {
        [Required]
        [StringLength(150)]
        public string ProductName { get; set; } = string.Empty;

        [Required]
        [Range(1, int.MaxValue)]
        public int ProductTypeId { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int ProductCategoryId { get; set; }

        [Required]
        [StringLength(50)]
        public string Size { get; set; } = string.Empty;

        [Required]
        [Range(1, 3650)]
        public int ShelfLifeDays { get; set; }

        [Required]
        [RegularExpression(
            "^(Active|Inactive)$",
            ErrorMessage = "Status must be Active or Inactive."
        )]
        public string Status { get; set; } = "Active";
    }
}
