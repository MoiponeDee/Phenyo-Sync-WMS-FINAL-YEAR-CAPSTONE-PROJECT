using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.DTOs.Product
{
// Provides the master-product projection used by hierarchy, search, and details.
    public class ProductResponseDto
    {
        public int ProductId { get; set; }

        public string ProductName { get; set; } = string.Empty;

        public int ProductTypeId { get; set; }

        public string ProductTypeName { get; set; } = string.Empty;

        public int ProductCategoryId { get; set; }

        public string ProductCategoryName { get; set; } = string.Empty;

        public string Size { get; set; } = string.Empty;

        public int ShelfLifeDays { get; set; }

        public decimal SellingPricePerKg { get; set; }

        public string CurrentPriceBasis { get; set; } =
            ProductPriceBases.PerKilogram;

        public string SellingUnit { get; set; } = "kg";

        public decimal? KilogramsPerUnit { get; set; }

        public bool IsVariableWeight { get; set; }

        public string? QRCodeValue { get; set; }

        public string Status { get; set; } = string.Empty;

        public DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

        public decimal TotalAvailableQuantityKg { get; set; }

        public DateTime? NearestExpiryAtUtc { get; set; }

        public string AlertLevel { get; set; } = "Normal";

        public bool CanDelete { get; set; }

        public string? DeleteBlockedReason { get; set; }

        public bool IsCommitted { get; set; }

        public bool CanDeactivate { get; set; }
    }
}
