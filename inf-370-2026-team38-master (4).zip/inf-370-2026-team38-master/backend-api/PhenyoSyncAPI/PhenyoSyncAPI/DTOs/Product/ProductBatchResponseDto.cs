namespace PhenyoSyncAPI.DTOs.Product
{
// Presents availability and expiry data required by safe fulfilment decisions.
    public class ProductBatchResponseDto
    {
        public int ProductBatchId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string ProductTypeName { get; set; } = string.Empty;
        public string ProductCategoryName { get; set; } = string.Empty;
        public string Size { get; set; } = string.Empty;
        public int SectionId { get; set; }
        public string SectionName { get; set; } = string.Empty;
        public string ProductCode { get; set; } = string.Empty;
        public string BatchCode { get; set; } = string.Empty;
        public string QRCodeValue { get; set; } = string.Empty;
        public decimal QuantityProducedKg { get; set; }
        public decimal QuantityRemainingKg { get; set; }
        public DateTime PackedAtUtc { get; set; }
        public DateTime OriginalExpiryAtUtc { get; set; }
        public DateTime EffectiveExpiryAtUtc { get; set; }
        public string Status { get; set; } = string.Empty;
        public bool ShelfLifeExtended { get; set; }
        public string AlertLevel { get; set; } = string.Empty;
        public double RemainingHours { get; set; }
    }
}
