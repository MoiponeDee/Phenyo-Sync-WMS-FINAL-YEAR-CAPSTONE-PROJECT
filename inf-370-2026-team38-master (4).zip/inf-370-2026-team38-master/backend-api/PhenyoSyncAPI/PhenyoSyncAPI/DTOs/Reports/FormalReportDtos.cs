namespace PhenyoSyncAPI.DTOs.Reports;

// Report DTOs are immutable preview snapshots shared by screen rendering and PDF generation.

public sealed record ReportCriterionDto(string Label, string Value);

public sealed record ReportOptionDto(int Id, string Label);

public sealed record ReportCodeOptionDto(string Code, string Label);

public sealed class ReportOptionsDto
{
    public IReadOnlyList<ReportOptionDto> Products { get; init; } = [];
    public IReadOnlyList<ReportOptionDto> ProductCategories { get; init; } = [];
    public IReadOnlyList<ReportOptionDto> ProductTypes { get; init; } = [];
    public IReadOnlyList<ReportOptionDto> WarehouseSections { get; init; } = [];
    public IReadOnlyList<ReportOptionDto> Customers { get; init; } = [];
    public IReadOnlyList<ReportOptionDto> Suppliers { get; init; } = [];
    public IReadOnlyList<ReportCodeOptionDto> OrderStatuses { get; init; } = [];
    public IReadOnlyList<ReportCodeOptionDto> DeliveryStatuses { get; init; } = [];
    public IReadOnlyList<ReportCodeOptionDto> PaymentStatuses { get; init; } = [];
    public IReadOnlyList<ReportCodeOptionDto> PaymentMethods { get; init; } = [];
    public IReadOnlyList<ReportCodeOptionDto> MovementTypes { get; init; } = [];
    public IReadOnlyList<ReportCodeOptionDto> WriteOffReasons { get; init; } = [];
}

public sealed class ReportMetadataDto
{
    public required string ReportKey { get; init; }
    public required string Title { get; init; }
    public required string Classification { get; init; }
    public DateTime GeneratedAtUtc { get; init; }
    public required string GeneratedBy { get; init; }
    public required IReadOnlyList<ReportCriterionDto> Criteria { get; init; }
    public int RecordCount { get; init; }
    public string PreviewToken { get; set; } = string.Empty;
}

public abstract class PagedReportCriteriaDto
{
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 50;
    public string SortBy { get; set; } = string.Empty;
    public string SortDirection { get; set; } = "asc";
}

public sealed class InventoryReportCriteriaDto : PagedReportCriteriaDto
{
    public string? Search { get; set; }
    public int? ProductId { get; set; }
    public int? ProductCategoryId { get; set; }
    public int? ProductTypeId { get; set; }
    public int? WarehouseSectionId { get; set; }
    public string? StockStatus { get; set; }
    public bool IncludeInactive { get; set; }
    public bool IncludeZeroQuantity { get; set; }
}

public sealed record InventoryReportRowDto(
    string ItemCode,
    string Product,
    string ProductCategory,
    string ProductType,
    string WarehouseSection,
    decimal AvailableQuantityKg,
    decimal ReservedQuantityKg,
    decimal TotalQuantityKg,
    decimal ReorderLevelKg,
    DateTime? BestBeforeDateUtc,
    string StockStatus);

public sealed class InventoryReportDto
{
    public required ReportMetadataDto Metadata { get; init; }
    public required IReadOnlyList<InventoryReportRowDto> Rows { get; init; }
    public int TotalRecords { get; init; }
    public decimal TotalAvailableQuantityKg { get; init; }
    public decimal TotalReservedQuantityKg { get; init; }
}

public sealed class ExpiryWasteReportCriteriaDto : PagedReportCriteriaDto
{
    public DateTime? AsOfDateUtc { get; set; }
    public int DaysToExpiryThreshold { get; set; } = 30;
    public int? WarehouseSectionId { get; set; }
    public int? ProductId { get; set; }
    public int? ProductCategoryId { get; set; }
    public string? RiskStatus { get; set; }
    public string? WriteOffReason { get; set; }
    public bool IncludeCompletedWriteOffs { get; set; } = true;
}

public sealed record ExpiryWasteReportRowDto(
    string RecordType,
    string ItemCode,
    string Item,
    string WarehouseSection,
    decimal QuantityKg,
    string UnitOfMeasure,
    DateTime? BestBeforeDateUtc,
    int? DaysRemaining,
    string RiskStatus,
    string? WriteOffReason,
    decimal? EstimatedUnitCost,
    decimal? EstimatedLossValue,
    string ResponsibleUser,
    DateTime RecordedAtUtc,
    string CostAvailability);

public sealed class ExpiryWasteReportDto
{
    public required ReportMetadataDto Metadata { get; init; }
    public required IReadOnlyList<ExpiryWasteReportRowDto> Rows { get; init; }
    public int TotalRecords { get; init; }
    public decimal TotalQuantityAtRiskKg { get; init; }
    public decimal? TotalKnownLossValue { get; init; }
}

public sealed class MarkupReportCriteriaDto : PagedReportCriteriaDto
{
    public DateTime? FromUtc { get; set; }
    public DateTime? ToUtc { get; set; }
    public int? ProductId { get; set; }
    public int? ProductCategoryId { get; set; }
    public string? CostSource { get; set; }
    public string? DataQualityStatus { get; set; }
}

public sealed record MarkupReportRowDto(
    string ProductCode,
    string Product,
    string ProductCategory,
    decimal TotalQuantitySoldKg,
    decimal AverageSellingPrice,
    decimal? AverageCost,
    string CostSource,
    decimal? MarkupAmountPerKg,
    decimal? MarkupPercentage,
    decimal? GrossMarginPercentage,
    string DataQualityStatus);

public sealed class MarkupReportDto
{
    public required ReportMetadataDto Metadata { get; init; }
    public required IReadOnlyList<MarkupReportRowDto> Rows { get; init; }
    public int TotalRecords { get; init; }
}

public sealed class SalesReportCriteriaDto
{
    public DateTime? FromUtc { get; set; }
    public DateTime? ToUtc { get; set; }
    public int? CustomerId { get; set; }
    public int? ProductId { get; set; }
    public int? ProductCategoryId { get; set; }
    public string? OrderStatus { get; set; }
    public string? DeliveryStatus { get; set; }
    public string SortOrder { get; set; } = "month-asc";
}

public sealed record SalesReportLineDto(
    int SalesOrderItemId,
    DateTime OrderDateUtc,
    string OrderNumber,
    string InvoiceNumber,
    string Product,
    string ProductCategory,
    decimal QuantityKg,
    decimal StoredUnitPrice,
    decimal LineTotal,
    string OrderStatus,
    string DeliveryStatus);

public sealed class SalesOrderReportGroupDto
{
    public int SalesOrderId { get; init; }
    public required string OrderNumber { get; init; }
    public required IReadOnlyList<SalesReportLineDto> Lines { get; init; }
    public decimal OrderQuantitySubtotalKg { get; init; }
    public decimal OrderValueSubtotal { get; init; }
}

public sealed class SalesCustomerReportGroupDto
{
    public int CustomerId { get; init; }
    public required string Customer { get; init; }
    public required IReadOnlyList<SalesOrderReportGroupDto> Orders { get; init; }
    public decimal CustomerQuantitySubtotalKg { get; init; }
    public decimal CustomerValueSubtotal { get; init; }
}

public sealed class SalesMonthReportGroupDto
{
    public required string MonthKey { get; init; }
    public required string MonthLabel { get; init; }
    public required IReadOnlyList<SalesCustomerReportGroupDto> Customers { get; init; }
    public decimal MonthQuantitySubtotalKg { get; init; }
    public decimal MonthValueSubtotal { get; init; }
}

public sealed class SalesReportDto
{
    public required ReportMetadataDto Metadata { get; init; }
    public required IReadOnlyList<SalesMonthReportGroupDto> Months { get; init; }
    public decimal GrandQuantitySoldKg { get; init; }
    public decimal GrandSalesValue { get; init; }
    public int TotalOrders { get; init; }
    public decimal AverageOrderValue { get; init; }
}

public sealed class StockMovementReportCriteriaDto
{
    public DateTime? FromUtc { get; set; }
    public DateTime? ToUtc { get; set; }
    public string? StockDomain { get; set; }
    public int? ProductId { get; set; }
    public int? ProductCategoryId { get; set; }
    public int? WarehouseSectionId { get; set; }
    public string? MovementType { get; set; }
}

public sealed record StockMovementReportRowDto(
    DateTime MovementDateUtc,
    string MovementType,
    string Reference,
    string Item,
    string WarehouseSection,
    decimal QuantityInKg,
    decimal QuantityOutKg,
    decimal NetMovementKg,
    string UnitOfMeasure,
    decimal? UnitCost,
    decimal? MovementValue,
    string Reason,
    string Actor);

public sealed class StockMovementItemGroupDto
{
    public required string Item { get; init; }
    public required IReadOnlyList<StockMovementReportRowDto> Movements { get; init; }
    public decimal TotalInKg { get; init; }
    public decimal TotalOutKg { get; init; }
    public decimal NetMovementKg { get; init; }
    public decimal? MovementValue { get; init; }
}

public sealed class StockMovementCategoryGroupDto
{
    public required string Category { get; init; }
    public required IReadOnlyList<StockMovementItemGroupDto> Items { get; init; }
    public decimal TotalInKg { get; init; }
    public decimal TotalOutKg { get; init; }
    public decimal NetMovementKg { get; init; }
    public decimal? MovementValue { get; init; }
}

public sealed class StockMovementDomainGroupDto
{
    public required string StockDomain { get; init; }
    public required IReadOnlyList<StockMovementCategoryGroupDto> Categories { get; init; }
    public decimal TotalInKg { get; init; }
    public decimal TotalOutKg { get; init; }
    public decimal NetMovementKg { get; init; }
    public decimal? MovementValue { get; init; }
}

public sealed class StockMovementReportDto
{
    public required ReportMetadataDto Metadata { get; init; }
    public required IReadOnlyList<StockMovementDomainGroupDto> Domains { get; init; }
    public decimal GrandTotalInKg { get; init; }
    public decimal GrandTotalOutKg { get; init; }
    public decimal GrandNetMovementKg { get; init; }
    public decimal? GrandMovementValue { get; init; }
}

public sealed class FinancialReportCriteriaDto : PagedReportCriteriaDto
{
    public DateTime? FromUtc { get; set; }
    public DateTime? ToUtc { get; set; }
    public IReadOnlyList<string> TransactionTypes { get; set; } = [];
    public int? CustomerId { get; set; }
    public int? SupplierId { get; set; }
    public string? TransactionStatus { get; set; }
    public string? PaymentMethod { get; set; }
    public decimal? MinimumAmount { get; set; }
    public decimal? MaximumAmount { get; set; }
    public string GroupBy { get; set; } = "transaction-type";
    public bool IncludeReversedOrVoided { get; set; }
}

public sealed record FinancialReportRowDto(
    DateTime TransactionDateUtc,
    string TransactionType,
    string Reference,
    string Counterparty,
    string Status,
    string PaymentMethod,
    decimal? Amount,
    string Direction,
    string Notes);

public sealed record FinancialReportSummaryDto(
    decimal SalesValue,
    decimal CustomerReceipts,
    decimal SupplierPayments,
    decimal? WriteOffLoss,
    decimal NetCashMovement,
    decimal? CustomerOutstandingBalance,
    decimal? SupplierOutstandingBalance);

public sealed class FinancialReportDto
{
    public required ReportMetadataDto Metadata { get; init; }
    public required FinancialReportSummaryDto Summary { get; init; }
    public required IReadOnlyList<FinancialReportRowDto> Rows { get; init; }
    public int TotalRecords { get; init; }
}

public sealed class PricingReportCriteriaDto
{
    public string ViewMode { get; set; } = "monthly";
    public int Year { get; set; } = DateTime.UtcNow.Year;
    public int? Month { get; set; } = DateTime.UtcNow.Month;
    public int? ProductId { get; set; }
    public int? ProductCategoryId { get; set; }
    public int? CustomerId { get; set; }
    public string? QualifyingSalesStatus { get; set; }
}

public sealed record PricingObservationDto(
    DateTime TransactionDateUtc,
    int ProductId,
    string Product,
    string OrderNumber,
    string InvoiceNumber,
    string Customer,
    decimal QuantitySoldKg,
    decimal StoredUnitPrice,
    decimal LineTotal,
    string QualifyingStatus);

public sealed record PriceDistributionDto(
    decimal Minimum,
    decimal Q1,
    decimal Median,
    decimal Q3,
    decimal Maximum,
    decimal Iqr,
    IReadOnlyList<decimal> Outliers,
    int ObservationCount,
    bool IsReliable,
    string Message);

public sealed record MonthlyPricingSummaryDto(
    int ProductId,
    string Product,
    decimal TotalQuantitySoldKg,
    int PriceObservationCount,
    decimal MinimumPrice,
    decimal MaximumPrice,
    decimal MedianPrice,
    decimal QuantityWeightedMonthlyAverage,
    decimal? CurrentActivePrice,
    decimal? DifferenceFromCurrentPrice,
    PriceDistributionDto Distribution);

public sealed record AnnualPricingSummaryDto(
    int ProductId,
    string Product,
    IReadOnlyList<decimal?> MonthlyWeightedAverages,
    int MonthsWithData,
    int MonthsWithoutData,
    decimal? AnnualAverage,
    PriceDistributionDto? Distribution);

public sealed record ReportChartPointDto(
    string Label,
    decimal? Value,
    string Tooltip,
    int Sequence);

public sealed class ReportChartSeriesDto
{
    public required string Name { get; init; }
    public required IReadOnlyList<ReportChartPointDto> Points { get; init; }
}

public sealed class ReportBoxPlotDto
{
    public required string Label { get; init; }
    public required PriceDistributionDto Distribution { get; init; }
}

public sealed class ReportChartDto
{
    public required string ChartType { get; init; }
    public required string Title { get; init; }
    public required string XAxisLabel { get; init; }
    public required string YAxisLabel { get; init; }
    public required string Unit { get; init; }
    public IReadOnlyList<ReportChartSeriesDto> Series { get; init; } = [];
    public IReadOnlyList<ReportBoxPlotDto> BoxPlots { get; init; } = [];
}

public sealed class PricingReportDto
{
    public required ReportMetadataDto Metadata { get; init; }
    public required string ViewMode { get; init; }
    public required IReadOnlyList<PricingObservationDto> Observations { get; init; }
    public required IReadOnlyList<MonthlyPricingSummaryDto> MonthlySummaries { get; init; }
    public required IReadOnlyList<AnnualPricingSummaryDto> AnnualSummaries { get; init; }
    public required IReadOnlyList<ReportChartDto> Charts { get; init; }
}

public sealed class ReportPdfRequestDto
{
    public string PreviewToken { get; set; } = string.Empty;
}

public sealed record GeneratedReportFile(byte[] Content, string FileName);
