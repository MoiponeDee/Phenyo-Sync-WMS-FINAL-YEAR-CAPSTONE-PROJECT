namespace PhenyoSyncAPI.DTOs.Order;

// Google intake contracts preserve source-row identity for idempotent synchronization.
public sealed class GoogleOrderSyncResultDto
{
    public int RowsRead { get; set; }
    public int Imported { get; set; }
    public int SkippedAsDuplicate { get; set; }
    public int NeedsAttention { get; set; }
    public int Failed { get; set; }
    public DateTime SyncedAtUtc { get; set; }
    public List<ExternalOrderSubmissionDto> Submissions { get; set; } = [];
}

public sealed class ExternalOrderSubmissionDto
{
    public long ExternalOrderSubmissionId { get; set; }
    public string Source { get; set; } = string.Empty;
    public string ExternalSourceKey { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string? SafeIssueSummary { get; set; }
    public DateTime? SubmittedAtUtc { get; set; }
    public DateTime ImportedAtUtc { get; set; }
    public int? SalesOrderId { get; set; }
    public string? OrderNumber { get; set; }
}
