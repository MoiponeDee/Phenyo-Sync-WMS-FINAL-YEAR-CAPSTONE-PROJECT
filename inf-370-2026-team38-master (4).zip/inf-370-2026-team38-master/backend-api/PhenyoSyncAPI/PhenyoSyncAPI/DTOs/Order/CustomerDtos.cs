using System.ComponentModel.DataAnnotations;

// Customer contracts validate contact data while orders retain their own snapshots.
namespace PhenyoSyncAPI.DTOs.Order;

public sealed class SaveCustomerDto
{
    [Required, StringLength(150)]
    public string CustomerName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(254)]
    public string Email { get; set; } = string.Empty;

    [StringLength(30)]
    public string? PhoneNumber { get; set; }

    [StringLength(500)]
    public string? BillingAddress { get; set; }

    [StringLength(500)]
    public string? DeliveryAddress { get; set; }

    [RegularExpression("^(Active|Inactive)$", ErrorMessage = "Status must be Active or Inactive.")]
    public string Status { get; set; } = "Active";
}

public sealed class CustomerDto
{
    public int CustomerId { get; set; }
    public string CustomerNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public string? BillingAddress { get; set; }
    public string? DeliveryAddress { get; set; }
    public string Status { get; set; } = string.Empty;
}
