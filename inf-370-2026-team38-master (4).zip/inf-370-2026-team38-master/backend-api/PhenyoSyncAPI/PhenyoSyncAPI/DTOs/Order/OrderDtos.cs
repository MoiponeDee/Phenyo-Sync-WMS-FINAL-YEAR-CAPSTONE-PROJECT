using System.ComponentModel.DataAnnotations;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.DTOs.Order;

// Order requests identify products and quantities only; prices, totals and workflow eligibility
// are resolved by the backend so a caller cannot submit trusted commercial calculations.

public sealed class OrderItemRequestDto
{
    [Range(1, int.MaxValue)]
    public int ProductId { get; set; }

    public decimal? QuantityUnits { get; set; }

    // Compatibility input for legacy kilogram clients. New clients submit QuantityUnits.
    public decimal? QuantityKg { get; set; }

    [StringLength(500)]
    public string? Notes { get; set; }
}

public class CreateSalesOrderDto
{
    [Range(1, int.MaxValue)]
    public int CustomerId { get; set; }

    public DateTime? RequestedDeliveryDateUtc { get; set; }

    [Required, StringLength(500)]
    public string DeliveryAddress { get; set; } = string.Empty;

    [Required, StringLength(500)]
    public string BillingAddress { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Notes { get; set; }

    [Required, MinLength(1)]
    public List<OrderItemRequestDto> Items { get; set; } = [];
}

public sealed class UpdateSalesOrderDto : CreateSalesOrderDto
{
    public string? RowVersion { get; set; }
}

public sealed class PublicCreateSalesOrderDto
{
    [Required]
    public string Token { get; set; } = string.Empty;

    public DateTime? RequestedDeliveryDateUtc { get; set; }

    [Required, StringLength(500)]
    public string DeliveryAddress { get; set; } = string.Empty;

    [Required, StringLength(500)]
    public string BillingAddress { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Notes { get; set; }

    [Required, MinLength(1)]
    public List<OrderItemRequestDto> Items { get; set; } = [];
}

public sealed class OrderItemDto
{
    public int SalesOrderItemId { get; set; }
    public int ProductId { get; set; }
    public int? ProductPriceId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string ProductSize { get; set; } = string.Empty;
    public decimal? QuantityKg { get; set; }
    public decimal? UnitPricePerKg { get; set; }
    public decimal QuantityUnits { get; set; }
    public string SellingUnit { get; set; } = "kg";
    public decimal? KilogramsPerUnit { get; set; }
    public decimal UnitPrice { get; set; }
    public string PriceBasis { get; set; } = "PerKilogram";
    public decimal LineTotal { get; set; }
    public string? Notes { get; set; }
}

public sealed class OrderStatusHistoryDto
{
    public string? PreviousStatus { get; set; }
    public string NewStatus { get; set; } = string.Empty;
    public DateTime ChangedAtUtc { get; set; }
    public string? ChangedBy { get; set; }
    public string? Reason { get; set; }
}

public sealed class OrderReservationDto
{
    public long OrderStockReservationId { get; set; }
    public int SalesOrderItemId { get; set; }
    public int ProductBatchId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string ProductSize { get; set; } = string.Empty;
    public string BatchCode { get; set; } = string.Empty;
    public string BatchQrValue { get; set; } = string.Empty;
    public int SectionId { get; set; }
    public string SectionName { get; set; } = string.Empty;
    public decimal QuantityReservedKg { get; set; }
    public DateTime PackedAtUtc { get; set; }
    public DateTime EffectiveExpiryAtUtc { get; set; }
    public string Status { get; set; } = string.Empty;
}

public sealed class SalesOrderDetailDto
{
    public int SalesOrderId { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public int CustomerId { get; set; }
    public string CustomerNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public DateTime OrderDateUtc { get; set; }
    public DateTime? RequestedDeliveryDateUtc { get; set; }
    public string DeliveryAddress { get; set; } = string.Empty;
    public string BillingAddress { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string ValidationStatus { get; set; } = string.Empty;
    public string? ValidationMessage { get; set; }
    public decimal Subtotal { get; set; }
    public decimal TaxRatePercent { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string? Notes { get; set; }
    public string RowVersion { get; set; } = string.Empty;
    public int? InvoiceId { get; set; }
    public List<OrderItemDto> Items { get; set; } = [];
    public List<OrderReservationDto> Reservations { get; set; } = [];
    public List<OrderStatusHistoryDto> StatusHistory { get; set; } = [];
}

public sealed class SalesOrderSummaryDto
{
    public int SalesOrderId { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public DateTime OrderDateUtc { get; set; }
    public DateTime? RequestedDeliveryDateUtc { get; set; }
    public string Status { get; set; } = string.Empty;
    public string ValidationStatus { get; set; } = string.Empty;
    public int ItemCount { get; set; }
    public decimal TotalAmount { get; set; }
    public bool HasInvoice { get; set; }
    public bool CanUpdate { get; set; }
    public bool CanValidate { get; set; }
    public bool CanCancel { get; set; }
    public bool CanViewPackingList { get; set; }
}

public sealed class PagedResultDto<T>
{
    public List<T> Items { get; set; } = [];
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public int TotalPages { get; set; }
}

public sealed class OrderSearchQueryDto
{
    public string? SearchTerm { get; set; }
    public string? Status { get; set; }
    public string? ValidationStatus { get; set; }
    public DateTime? FromDateUtc { get; set; }
    public DateTime? ToDateUtc { get; set; }
    public DateTime? DeliveryFromUtc { get; set; }
    public DateTime? DeliveryToUtc { get; set; }
    [Range(1, int.MaxValue)] public int Page { get; set; } = 1;
    [Range(1, 100)] public int PageSize { get; set; } = 20;
}

public sealed class OrderShortageDto
{
    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public decimal RequestedQuantityKg { get; set; }
    public decimal AvailableQuantityKg { get; set; }
    public decimal ShortageQuantityKg { get; set; }
}

public sealed class ValidateOrderResponseDto
{
    public string Message { get; set; } = string.Empty;
    public bool Approved { get; set; }
    public List<OrderShortageDto> Shortages { get; set; } = [];
    public List<OrderReservationDto> Reservations { get; set; } = [];
}

public sealed class CancelOrderDto
{
    [Required, MinLength(5), StringLength(500)]
    public string Reason { get; set; } = string.Empty;

    [Range(typeof(bool), "true", "true", ErrorMessage = "Explicit cancellation confirmation is required.")]
    public bool Confirmed { get; set; }

    [Required]
    public string ConfirmationText { get; set; } = string.Empty;
}

public sealed class OrderDecisionDto
{
    [MaxLength(500)]
    public string? Reason { get; set; }
}

public sealed class UpdateOrderStatusDto
{
    [Required]
    public string NewStatus { get; set; } = string.Empty;

    [StringLength(500)]
    public string? Reason { get; set; }

    [StringLength(80)]
    public string? OperationId { get; set; }
}

public sealed class InvoiceDto
{
    public int InvoiceId { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public string OrderNumber { get; set; } = string.Empty;
    public DateTime IssuedAtUtc { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string BillingAddress { get; set; } = string.Empty;
    public decimal Subtotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string InvoiceStatus { get; set; } = string.Empty;
    public string OrderStatus { get; set; } = string.Empty;
    public List<OrderItemDto> Items { get; set; } = [];
}

public sealed class PackingListDto
{
    public int SalesOrderId { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string DeliveryAddress { get; set; } = string.Empty;
    public DateTime? RequestedDeliveryDateUtc { get; set; }
    public string Status { get; set; } = string.Empty;
    public List<PackingWorkloadLineDto> Lines { get; set; } = [];
    public List<OrderReservationDto> Allocations { get; set; } = [];
}

public sealed class PackingWorkloadLineDto
{
    public int SalesOrderItemId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string ProductSize { get; set; } = string.Empty;
    public decimal OrderedQuantityUnits { get; set; }
    public string SellingUnit { get; set; } = "kg";
    public decimal? RequiredQuantityKg { get; set; }
    public decimal AvailableQuantityKg { get; set; }
    public decimal PackedQuantityKg { get; set; }
    public decimal? RemainingQuantityKg { get; set; }
}

public sealed class SendOrderLinkDto
{
    [Range(1, int.MaxValue)]
    public int CustomerId { get; set; }
}

public sealed class OrderLinkDto
{
    public long CustomerOrderLinkId { get; set; }
    public int CustomerId { get; set; }
    public string CustomerNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public DateTime CreatedAtUtc { get; set; }
    public DateTime ExpiresAtUtc { get; set; }
    public DateTime? UsedAtUtc { get; set; }
    public DateTime? RevokedAtUtc { get; set; }
    public DateTime? EmailSentAtUtc { get; set; }
    public int? SalesOrderId { get; set; }
    public string Status { get; set; } = string.Empty;
}

public sealed class PublicOrderProductDto
{
    public int ProductId { get; set; }
    public int ProductPriceId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public string Size { get; set; } = string.Empty;
    public decimal SellingPricePerKg { get; set; }
    public decimal? SellingPricePerUnit { get; set; }
    public string PriceBasis { get; set; } = ProductPriceBases.PerKilogram;
    public string SellingUnit { get; set; } = "kg";
    public decimal? KilogramsPerUnit { get; set; }
    public bool IsVariableWeight { get; set; }
}

public sealed class PublicOrderLinkValidationDto
{
    public string CustomerName { get; set; } = string.Empty;
    public DateTime ExpiresAtUtc { get; set; }
    public string DeliveryAddress { get; set; } = string.Empty;
    public string BillingAddress { get; set; } = string.Empty;
    public List<PublicOrderProductDto> Products { get; set; } = [];
}

public sealed class CustomerOrderIntakeConfigurationDto
{
    public string GoogleFormUrl { get; set; } = string.Empty;
    public bool IsConfigured { get; set; }
    public string Guidance { get; set; } = string.Empty;
}
