using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Delivery;

// Delivery contracts separate client requests from server-owned assignment, status and proof data.

public sealed class DeliverySearchQueryDto
{
    [MaxLength(200)]
    public string? SearchTerm { get; set; }
    public int? DriverId { get; set; }
    [MaxLength(30)]
    public string? Status { get; set; }
    public DateTime? ScheduledFromUtc { get; set; }
    public DateTime? ScheduledToUtc { get; set; }
    public bool? Assigned { get; set; }
    public bool? Completed { get; set; }
    [Range(1, int.MaxValue)]
    public int Page { get; set; } = 1;
    [Range(1, 100)]
    public int PageSize { get; set; } = 20;
}

public sealed class ScheduleDeliveryDto
{
    [Range(1, int.MaxValue)]
    public int SalesOrderId { get; set; }
    public DateTime ScheduledStartUtc { get; set; }
    public DateTime? ScheduledEndUtc { get; set; }
}

public sealed class AssignDriverDto
{
    [Range(1, int.MaxValue)]
    public int DriverId { get; set; }
    [MaxLength(500)]
    public string? AssignmentNotes { get; set; }
    [MaxLength(500)]
    public string? ReassignmentReason { get; set; }
    public string? RowVersion { get; set; }
}

public sealed class UnassignDriverDto
{
    [Required, MinLength(5), MaxLength(500)]
    public string Reason { get; set; } = string.Empty;
    public string? RowVersion { get; set; }
}

public sealed class CompleteDeliveryDto
{
    [Required, MinLength(2), MaxLength(200)]
    public string RecipientName { get; set; } = string.Empty;
    public bool RecipientConfirmed { get; set; }
    public bool FulfillmentConfirmed { get; set; }
    [MaxLength(1000)]
    public string? Notes { get; set; }
    [MaxLength(500)]
    public string? ProofReference { get; set; }
    [MaxLength(500)]
    public string? ManagementOverrideReason { get; set; }
    public string? RowVersion { get; set; }
}

public sealed class AvailableDriverDto
{
    public int DriverId { get; set; }
    public string DriverName { get; set; } = string.Empty;
    public string AvailabilityStatus { get; set; } = string.Empty;
    public DateTime? LicenseExpiryDate { get; set; }
    public bool LicenseValidForWindow { get; set; }
    public string? VehicleAssigned { get; set; }
}

public class DeliveryListItemDto
{
    public int DeliveryId { get; set; }
    public int SalesOrderId { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string DeliveryAddress { get; set; } = string.Empty;
    public DateTime ScheduledStartUtc { get; set; }
    public DateTime ScheduledEndUtc { get; set; }
    public string Status { get; set; } = string.Empty;
    public int? DriverId { get; set; }
    public string? DriverName { get; set; }
    public DateTime? CompletedAtUtc { get; set; }
    public bool CanAssign { get; set; }
    public bool CanStart { get; set; }
    public bool CanComplete { get; set; }
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class DeliveryDetailDto : DeliveryListItemDto
{
    public string CustomerNumber { get; set; } = string.Empty;
    public DateTime? RequestedDeliveryDateUtc { get; set; }
    public DateTime? AssignedAtUtc { get; set; }
    public DateTime? StartedAtUtc { get; set; }
    public string OrderStatus { get; set; } = string.Empty;
    public List<DeliveryAssignmentHistoryDto> AssignmentHistory { get; set; } = [];
    public List<DeliveryStatusHistoryDto> StatusHistory { get; set; } = [];
}

public sealed class DeliveryAssignmentHistoryDto
{
    public long DeliveryDriverAssignmentId { get; set; }
    public int DriverId { get; set; }
    public string DriverName { get; set; } = string.Empty;
    public DateTime AssignedAtUtc { get; set; }
    public string? AssignedBy { get; set; }
    public DateTime? UnassignedAtUtc { get; set; }
    public string? UnassignedBy { get; set; }
    public string? AssignmentNotes { get; set; }
    public string? ReassignmentReason { get; set; }
    public bool IsCurrent { get; set; }
}

public sealed class DeliveryStatusHistoryDto
{
    public string? PreviousStatus { get; set; }
    public string NewStatus { get; set; } = string.Empty;
    public DateTime ChangedAtUtc { get; set; }
    public string? ChangedBy { get; set; }
    public string? Reason { get; set; }
    public string Source { get; set; } = string.Empty;
}

public sealed class DeliveryProofDto
{
    public long DeliveryCompletionRecordId { get; set; }
    public int DeliveryId { get; set; }
    public string OrderNumber { get; set; } = string.Empty;
    public DateTime CompletedAtUtc { get; set; }
    public string CompletedBy { get; set; } = string.Empty;
    public string? AssignedDriver { get; set; }
    public bool CompletedOnBehalfOfDriver { get; set; }
    public string? ManagementOverrideReason { get; set; }
    public string RecipientName { get; set; } = string.Empty;
    public bool RecipientConfirmed { get; set; }
    public bool FulfillmentConfirmed { get; set; }
    public string? Notes { get; set; }
    public string? ProofReference { get; set; }
}

public sealed class DeliveryPagedResultDto
{
    public List<DeliveryListItemDto> Items { get; set; } = [];
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public int TotalPages { get; set; }
}
