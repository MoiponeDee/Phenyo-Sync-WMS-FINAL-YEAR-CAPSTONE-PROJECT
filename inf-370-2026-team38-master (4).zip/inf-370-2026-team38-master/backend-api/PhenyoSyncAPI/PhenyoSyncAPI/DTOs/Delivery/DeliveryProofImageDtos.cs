using System.ComponentModel.DataAnnotations;

// Validated proof-image contracts limit metadata accepted at the delivery boundary.
namespace PhenyoSyncAPI.DTOs.Delivery;

public sealed class UploadDeliveryProofImageRequest
{
    [MaxLength(300)]
    public string? Caption { get; set; }
    public bool IsPrimary { get; set; }
}

public sealed record DeliveryProofImageDto(
    long DeliveryProofImageId,
    int DeliveryId,
    string FileName,
    string ContentType,
    long SizeBytes,
    string? Caption,
    bool IsPrimary,
    DateTime UploadedAtUtc,
    string UploadedBy,
    bool IsRemoved,
    string RowVersion);

public sealed class RemoveDeliveryProofImageRequest
{
    [MaxLength(500)]
    public string? Reason { get; set; }
}
