namespace PhenyoSyncAPI.DTOs.Dashboard;

// Stable dashboard contracts keep role-specific aggregation separate from presentation code.
public sealed record RoleDashboardMetricDto(
    string Label,
    decimal Value,
    string ValueKind,
    string Detail,
    string? Route = null);

public sealed record RoleDashboardPointDto(
    string Label,
    decimal Value,
    int Count);

public sealed record RoleDashboardChartDto(
    string Title,
    string Description,
    string ValueKind,
    IReadOnlyList<RoleDashboardPointDto> Points);

public sealed record RoleDashboardAttentionDto(
    string Label,
    decimal Value,
    string Detail,
    string Route,
    string Severity);

public sealed record RoleDashboardActivityDto(
    long AuditLogId,
    DateTime OccurredAtUtc,
    string OperationName,
    string SystemModule,
    string? EntityDisplay,
    string? ActorDisplayName,
    bool Success);

public sealed class RoleDashboardDto
{
    public required string RoleCode { get; init; }
    public required string Title { get; init; }
    public required string Subtitle { get; init; }
    public DateTime FromUtc { get; init; }
    public DateTime ToUtc { get; init; }
    public required IReadOnlyList<RoleDashboardMetricDto> Metrics { get; init; }
    public required RoleDashboardChartDto BarChart { get; init; }
    public required RoleDashboardChartDto LineChart { get; init; }
    public required IReadOnlyList<RoleDashboardAttentionDto> AttentionItems { get; init; }
    public required IReadOnlyList<RoleDashboardActivityDto> RecentActivity { get; init; }
}
