using System.ComponentModel.DataAnnotations;

namespace PhenyoSyncAPI.DTOs.Help;

// Help responses expose published content while management requests retain version information.

public sealed record HelpCategoryDto(
    int HelpCategoryId,
    string SystemCode,
    string DisplayName,
    string? Description,
    int SortOrder,
    bool IsActive,
    string RowVersion);

public sealed record HelpTopicSummaryDto(
    int HelpTopicId,
    string Slug,
    string Title,
    string Summary,
    string CategoryName,
    string? Snippet,
    bool IsPublic,
    bool IsPublished,
    int SortOrder);

public sealed record HelpTopicDto(
    int HelpTopicId,
    int HelpCategoryId,
    string CategoryName,
    string Slug,
    string Title,
    string Summary,
    string BodyContent,
    string? Keywords,
    IReadOnlyList<string> AudienceRoles,
    bool IsPublic,
    bool IsPublished,
    int SortOrder,
    string RowVersion,
    HelpTopicSummaryDto? Previous,
    HelpTopicSummaryDto? Next,
    IReadOnlyList<HelpTopicSummaryDto> Related);

public sealed record HelpHomeDto(
    IReadOnlyList<HelpCategoryDto> Categories,
    IReadOnlyList<HelpTopicSummaryDto> Recommended,
    FeaturedHelpMediaDto? FeaturedMedia);

public sealed record FeaturedHelpMediaDto(
    long HelpMediaId,
    string Title,
    string? Description,
    string? Transcript,
    bool HasCaptions);

public sealed class SaveHelpCategoryRequest
{
    [Required, MaxLength(80), RegularExpression(@"^[A-Z0-9_]+$")]
    public string SystemCode { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string DisplayName { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }

    [Range(0, 10000)]
    public int SortOrder { get; set; }

    public bool IsActive { get; set; } = true;
    public string? RowVersion { get; set; }
}

public sealed class SaveHelpTopicRequest
{
    [Range(1, int.MaxValue)]
    public int HelpCategoryId { get; set; }

    [Required, MaxLength(160), RegularExpression(@"^[a-z0-9]+(?:-[a-z0-9]+)*$")]
    public string Slug { get; set; } = string.Empty;

    [Required, MaxLength(180)]
    public string Title { get; set; } = string.Empty;

    [Required, MaxLength(600)]
    public string Summary { get; set; } = string.Empty;

    [Required, MinLength(40)]
    public string BodyContent { get; set; } = string.Empty;

    [MaxLength(800)]
    public string? Keywords { get; set; }

    public List<string> AudienceRoles { get; set; } = [];
    public bool IsPublic { get; set; }
    public bool IsPublished { get; set; } = true;

    [Range(0, 10000)]
    public int SortOrder { get; set; }

    public string? RowVersion { get; set; }
}

public sealed class SaveHelpContextRequest
{
    [Range(1, int.MaxValue)]
    public int HelpTopicId { get; set; }

    [Required, MaxLength(240)]
    public string RoutePattern { get; set; } = string.Empty;

    [MaxLength(120)]
    public string? ComponentKey { get; set; }

    [Range(0, 10000)]
    public int Priority { get; set; } = 100;

    public bool IsActive { get; set; } = true;
}

public sealed record HelpContextResultDto(
    string Slug,
    string Title,
    string Summary);

public sealed class HelpSearchQuery
{
    [MaxLength(200)]
    public string? Query { get; set; }
    public int? CategoryId { get; set; }
    [Range(1, int.MaxValue)]
    public int Page { get; set; } = 1;
    [Range(1, 50)]
    public int PageSize { get; set; } = 20;
}

public sealed record HelpSearchResultDto(
    IReadOnlyList<HelpTopicSummaryDto> Items,
    int Page,
    int PageSize,
    int TotalCount,
    int TotalPages);

public sealed class UploadHelpMediaRequest
{
    [Required, MaxLength(180)]
    public string Title { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Description { get; set; }

    public string? Transcript { get; set; }
    public int? HelpTopicId { get; set; }
    public bool IsFeatured { get; set; }
    public bool IsPublished { get; set; }
    [Range(0, 10000)]
    public int SortOrder { get; set; }
}

public sealed class UpdateHelpMediaRequest
{
    [Required, MaxLength(180)]
    public string Title { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Description { get; set; }

    public string? Transcript { get; set; }
    public int? HelpTopicId { get; set; }
    public bool IsFeatured { get; set; }
    public bool IsPublished { get; set; }

    [Range(0, 10000)]
    public int SortOrder { get; set; }

    public string? RowVersion { get; set; }
}

public sealed record HelpMediaDto(
    long HelpMediaId,
    int? HelpTopicId,
    string Title,
    string? Description,
    string? Transcript,
    bool IsFeatured,
    bool IsPublished,
    int SortOrder,
    DateTime CreatedAtUtc,
    bool HasCaptions,
    string RowVersion);
