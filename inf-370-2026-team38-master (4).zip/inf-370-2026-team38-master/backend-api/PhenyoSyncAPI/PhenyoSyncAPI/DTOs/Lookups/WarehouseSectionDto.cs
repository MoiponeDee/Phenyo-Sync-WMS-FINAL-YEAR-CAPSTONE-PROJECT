namespace PhenyoSyncAPI.DTOs.Lookups
{
    public class WarehouseSectionDto
    {
        public int SectionId { get; set; }
        public string SectionCode { get; set; } = string.Empty;
        public string SectionName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedAtUtc { get; set; }
        public DateTime? UpdatedAtUtc { get; set; }
        public string RowVersion { get; set; } = string.Empty;
    }
}
