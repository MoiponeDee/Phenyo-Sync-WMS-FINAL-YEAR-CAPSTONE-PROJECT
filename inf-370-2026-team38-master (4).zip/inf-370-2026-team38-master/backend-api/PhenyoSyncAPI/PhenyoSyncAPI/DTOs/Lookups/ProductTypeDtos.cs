using System.ComponentModel.DataAnnotations;

// Product-type requests protect the category-to-type hierarchy boundary.
namespace PhenyoSyncAPI.DTOs.Lookups
{
    public class SaveProductTypeDto
    {
        [Required, StringLength(100)]
        public string ProductTypeName { get; set; } = string.Empty;

        [StringLength(255)]
        public string? Description { get; set; }

        [RegularExpression("^(Active|Inactive)$")]
        public string Status { get; set; } = "Active";
    }

    public class ProductTypeDto
    {
        public int ProductTypeId { get; set; }
        public string ProductTypeName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}
