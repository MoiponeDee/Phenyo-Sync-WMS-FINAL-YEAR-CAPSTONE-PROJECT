using System.ComponentModel.DataAnnotations;

// Category requests validate input before hierarchy services run.
namespace PhenyoSyncAPI.DTOs.Lookups
{
    public class SaveProductCategoryDto
    {
        [Required, StringLength(100)]
        public string ProductCategoryName { get; set; } = string.Empty;

        [StringLength(255)]
        public string? Description { get; set; }

        [RegularExpression("^(Active|Inactive)$")]
        public string Status { get; set; } = "Active";
    }

    public class ProductCategoryDto
    {
        public int ProductCategoryId { get; set; }
        public string ProductCategoryName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}
