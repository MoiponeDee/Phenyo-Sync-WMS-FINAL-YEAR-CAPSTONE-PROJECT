using System.ComponentModel.DataAnnotations;
using PhenyoSyncAPI.Entities;

namespace PhenyoSyncAPI.DTOs.Pricing;

// Pricing requests carry effective dates and versions; the service owns overlap/current-price rules.

public sealed class CreateProductPriceDto
{
    [Range(1, int.MaxValue)]
    public int ProductId { get; set; }

    [Range(typeof(decimal), "0.01", "999999999999.99")]
    public decimal SellingPrice { get; set; }

    [Required, RegularExpression("^(PerKilogram|PerSellableUnit)$")]
    public string PriceBasis { get; set; } = ProductPriceBases.PerKilogram;

    public DateTime? EffectiveFromUtc { get; set; }

    [StringLength(500)]
    public string? Reason { get; set; }
}

public sealed class UpdateProductPriceDto
{
    [Range(typeof(decimal), "0.01", "999999999999.99")]
    public decimal SellingPrice { get; set; }

    [Required, RegularExpression("^(PerKilogram|PerSellableUnit)$")]
    public string PriceBasis { get; set; } = ProductPriceBases.PerKilogram;

    public DateTime? EffectiveFromUtc { get; set; }

    [StringLength(500)]
    public string? ChangeReason { get; set; }

    public string? RowVersion { get; set; }
}

public sealed class DeleteProductPriceDto
{
    [Range(typeof(bool), "true", "true", ErrorMessage = "Explicit confirmation is required.")]
    public bool Confirmed { get; set; }

    [Required, MinLength(5), StringLength(500)]
    public string Reason { get; set; } = string.Empty;
}

public sealed class ProductPriceSearchDto
{
    public string? SearchTerm { get; set; }
    public int? ProductId { get; set; }
    public int? ProductTypeId { get; set; }
    public int? ProductCategoryId { get; set; }
    public decimal? MinimumPrice { get; set; }
    public decimal? MaximumPrice { get; set; }
    public string Status { get; set; } = PriceRecordStatuses.Current;
    public DateTime? EffectiveFromUtc { get; set; }
    public DateTime? EffectiveToUtc { get; set; }

    [Range(1, int.MaxValue)]
    public int Page { get; set; } = 1;

    [Range(1, 100)]
    public int PageSize { get; set; } = 20;
}

public sealed class ProductPriceResponseDto
{
    public int ProductPriceId { get; set; }
    public int ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string ProductTypeName { get; set; } = string.Empty;
    public string ProductCategoryName { get; set; } = string.Empty;
    public string Size { get; set; } = string.Empty;
    public string ProductStatus { get; set; } = string.Empty;
    public decimal SellingPrice { get; set; }
    public string PriceBasis { get; set; } = ProductPriceBases.PerKilogram;
    public DateTime EffectiveFromUtc { get; set; }
    public DateTime? EffectiveToUtc { get; set; }
    public bool IsCurrent { get; set; }
    public bool IsScheduled { get; set; }
    public bool IsDeleted { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public string? CreatedBy { get; set; }
    public string? ChangeReason { get; set; }
    public DateTime? DeletedAtUtc { get; set; }
    public string? DeletedBy { get; set; }
    public string? DeleteReason { get; set; }
    public int LinkedOrderCount { get; set; }
    public bool IsCommitted { get; set; }
    public bool CanSoftDelete { get; set; }
    public string? DeleteBlockedReason { get; set; }
    public string RowVersion { get; set; } = string.Empty;
}

public sealed class ProductPriceChangeResponseDto
{
    public string Message { get; set; } = string.Empty;
    public ProductPriceResponseDto? PreviousPrice { get; set; }
    public ProductPriceResponseDto CurrentPrice { get; set; } = null!;
}

public sealed class ProductPricePageDto
{
    public List<ProductPriceResponseDto> Items { get; set; } = [];
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public int TotalPages { get; set; }
}

public sealed class OrderableProductPriceDto
{
    public int ProductId { get; set; }
    public int ProductPriceId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string ProductTypeName { get; set; } = string.Empty;
    public string ProductCategoryName { get; set; } = string.Empty;
    public string Size { get; set; } = string.Empty;
    public decimal SellingPrice { get; set; }
    public string PriceBasis { get; set; } = ProductPriceBases.PerKilogram;
    public decimal? SellingPricePerUnit { get; set; }
    public string SellingUnit { get; set; } = "kg";
    public decimal? KilogramsPerUnit { get; set; }
    public bool IsVariableWeight { get; set; }
    public decimal AvailableQuantityKg { get; set; }
}

public static class PriceRecordStatuses
{
    public const string Current = "Current";
    public const string Historical = "Historical";
    public const string Scheduled = "Scheduled";
    public const string Deleted = "Deleted";
    public const string All = "All";

    public static readonly IReadOnlySet<string> AllValues = new HashSet<string>(
        [Current, Historical, Scheduled, Deleted, All],
        StringComparer.OrdinalIgnoreCase);
}
