using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using PhenyoSyncAPI.Auditing;
using PhenyoSyncAPI.Contracts;
using PhenyoSyncAPI.Data;
using PhenyoSyncAPI.Filters;
using PhenyoSyncAPI.Middleware;
using PhenyoSyncAPI.Options;
using PhenyoSyncAPI.Security;
using PhenyoSyncAPI.Services;
using PhenyoSyncAPI.Services.Reports;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Http.Features;
using QuestPDF.Infrastructure;

var builder = WebApplication.CreateBuilder(args);
QuestPDF.Settings.License = LicenseType.Community;

// Fail during startup when the signing key is missing. Starting with an
// invented fallback key would make issued sessions insecure and unpredictable.
var jwtKey = builder.Configuration["Jwt:Key"]
    ?? throw new InvalidOperationException(
        "JWT signing key configuration is required.");
// Add services to the container.

builder.Services
    .AddControllers(options =>
    {
        options.Filters.Add<ApiEnvelopeResultFilter>();
    })
    .ConfigureApiBehaviorOptions(options =>
    {
        options.InvalidModelStateResponseFactory = context =>
        {
            var errors = context.ModelState
                .Where(item => item.Value?.Errors.Count > 0)
                .ToDictionary(
                    item => item.Key,
                    item => item.Value!.Errors
                        .Select(error =>
                            string.IsNullOrWhiteSpace(error.ErrorMessage)
                                ? "The supplied value is invalid."
                                : error.ErrorMessage)
                        .ToArray(),
                    StringComparer.OrdinalIgnoreCase);

            return new BadRequestObjectResult(
                ApiResponses.Error(
                    context.HttpContext,
                    "Check the highlighted fields and try again.",
                    "VALIDATION_FAILED",
                    errors));
        };
    });
builder.Services.AddHttpContextAccessor();
builder.Services.Configure<FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = 510L * 1024 * 1024;
});
builder.Services.AddScoped<ApiEnvelopeResultFilter>();
builder.Services.AddScoped<IAuditContextAccessor, AuditContextAccessor>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IAuditLogQueryService, AuditLogQueryService>();
builder.Services.AddMemoryCache(options =>
{
    options.SizeLimit = 512;
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.CustomSchemaIds(type =>
        type.FullName?.Replace("+", ".") ?? type.Name);

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header
    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        [new OpenApiSecurityScheme
        {
            Reference = new OpenApiReference
            {
                Type = ReferenceType.SecurityScheme,
                Id = "Bearer"
            }
        }] = Array.Empty<string>()
    });
});
builder.Services.AddDbContext<PhenyoSyncDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddScoped<JwtService>();

// Authentication proves who the caller is. The token validation event also
// re-checks live account state so deactivation and SecurityVersion changes can
// invalidate a previously issued JWT before its normal expiry time.
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(jwtKey)
            )
    };
    options.Events = new JwtBearerEvents
    {
        OnTokenValidated = async context =>
        {
            var userIdValue = context.Principal?.FindFirstValue(
                ClaimTypes.NameIdentifier);
            if (!int.TryParse(userIdValue, out var userId))
            {
                context.Fail("The session identity is invalid.");
                return;
            }

            var db = context.HttpContext.RequestServices
                .GetRequiredService<PhenyoSyncDbContext>();
            var user = await db.Users
                .AsNoTracking()
                .Include(item => item.Role)
                .SingleOrDefaultAsync(
                    item => item.UserId == userId,
                    context.HttpContext.RequestAborted);

            if (user is null ||
                !string.Equals(
                    user.Status,
                    "Active",
                    StringComparison.OrdinalIgnoreCase) ||
                user.Role is not { IsActive: true })
            {
                context.Fail("The user account is inactive.");
                return;
            }

            var tokenVersion = context.Principal?.FindFirstValue(
                JwtService.SecurityVersionClaim);
            if (int.TryParse(tokenVersion, out var version) &&
                version != user.SecurityVersion)
            {
                context.Fail("The session is no longer current.");
                return;
            }

            if (context.Principal?.Identity is ClaimsIdentity identity &&
                identity.HasClaim(
                    ClaimTypes.Role,
                    RoleCodes.LegacyAdminClerk) &&
                !identity.HasClaim(ClaimTypes.Role, RoleCodes.Admin))
            {
                identity.AddClaim(
                    new Claim(ClaimTypes.Role, RoleCodes.Admin));
            }
        }
    };
});
builder.Services.AddCors(options =>
{
    var frontendUrl = builder.Configuration["FrontendUrl"]
        ?? "http://localhost:4200";
    var mobileOrigins = builder.Configuration
        .GetSection($"{MobileOperationsOptions.SectionName}:AllowedCorsOrigins")
        .Get<string[]>() ?? Array.Empty<string>();
    var allowedOrigins = mobileOrigins
        .Append(frontendUrl)
        .Concat(builder.Environment.IsDevelopment()
            ? new[]
            {
        "http://localhost:8100",
        "http://localhost",
        "https://localhost",
        "capacitor://localhost"
            }
            : Array.Empty<string>())
        .Where(value => !string.IsNullOrWhiteSpace(value))
        .Select(value => value.TrimEnd('/'))
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .ToArray();
    options.AddPolicy("AllowAngular",
        policy =>
        {
            policy.WithOrigins(allowedOrigins)
                  .AllowAnyHeader()
                  .AllowAnyMethod()
                  .AllowCredentials();
        });
});

builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
});
// Permission policies are resolved dynamically from the permission code used
// on a controller. This keeps the API—not Angular navigation—as the authority.
builder.Services.AddSingleton<IAuthorizationPolicyProvider, PermissionPolicyProvider>();
builder.Services.AddScoped<IAuthorizationHandler, PermissionAuthorizationHandler>();
builder.Services.AddScoped<IAuthorizationHandler, AnyPermissionAuthorizationHandler>();
builder.Services.AddScoped<IPermissionService, PermissionService>();
builder.Services.AddSingleton<IAuthorizationMiddlewareResultHandler, ApiAuthorizationResultHandler>();
builder.Services.AddRateLimiter(options =>
{
    options.AddPolicy("public-orders", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 20,
            Window = TimeSpan.FromMinutes(1),
            QueueLimit = 0,
            AutoReplenishment = true
        }));
    options.AddPolicy("login", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 12,
            Window = TimeSpan.FromMinutes(5),
            QueueLimit = 0,
            AutoReplenishment = true
        }));
    options.AddPolicy("two-factor", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 30,
            Window = TimeSpan.FromMinutes(5),
            QueueLimit = 0,
            AutoReplenishment = true
        }));
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.OnRejected = async (context, cancellationToken) =>
    {
        context.HttpContext.Response.ContentType = "application/json";
        await context.HttpContext.Response.WriteAsJsonAsync(
            ApiResponses.Error(
                context.HttpContext,
                "Too many requests were received. Wait a moment and try again.",
                "RATE_LIMITED"),
            cancellationToken);
    };
});
if (builder.Environment.IsDevelopment() &&
    builder.Configuration.GetValue<bool>(
        "EmailSettings:UseDevelopmentSink"))
{
    builder.Services.AddScoped<
        IEmailService,
        DevelopmentEmailSinkService>();
}
else
{
    builder.Services.AddScoped<IEmailService, EmailService>();
}
builder.Services.AddScoped<ITwoFactorService, TwoFactorService>();

// Business services are registered against interfaces so controllers stay
// thin and tests can exercise rules without duplicating HTTP plumbing.
builder.Services.Configure<ProtectedStorageOptions>(
    builder.Configuration.GetSection(ProtectedStorageOptions.SectionName));
builder.Services.AddSingleton<IProtectedFileStorage, ProtectedFileStorage>();
builder.Services.AddScoped<IDeliveryProofImageService, DeliveryProofImageService>();
builder.Services.AddScoped<IHelpService, HelpService>();
builder.Services.AddScoped<IHelpMediaService, HelpMediaService>();
builder.Services.Configure<ExpiryAlertOptions>(
    builder.Configuration.GetSection(ExpiryAlertOptions.SectionName));
builder.Services.AddSingleton<ISystemSettingProvider, SystemSettingProvider>();
builder.Services.AddScoped<IProductionService, ProductionService>();
builder.Services.AddScoped<IExpiryService, ExpiryService>();
builder.Services.Configure<OrderManagementOptions>(
    builder.Configuration.GetSection(OrderManagementOptions.SectionName));
builder.Services.AddScoped<IOrderService, OrderService>();
builder.Services.Configure<GoogleOrderIntakeOptions>(
    builder.Configuration.GetSection(GoogleOrderIntakeOptions.SectionName));
builder.Services.AddHttpClient<IGoogleOrderIntakeService, GoogleOrderIntakeService>();
builder.Services.AddScoped<IOrderStockService, OrderStockService>();
builder.Services.AddScoped<IOrderWorkflowService, OrderWorkflowService>();
builder.Services.AddScoped<IOrderLinkService, OrderLinkService>();
builder.Services.AddScoped<IProductPricingService, ProductPricingService>();
builder.Services.AddScoped<IDeliveryService, DeliveryService>();
builder.Services.AddScoped<IProductHierarchyService, ProductHierarchyService>();
builder.Services.AddScoped<IDataExchangeJobService, DataExchangeJobService>();
builder.Services.AddScoped<IProductExcelExchangeService, ProductExcelExchangeService>();
builder.Services.AddScoped<IStockCountJsonExchangeService, StockCountJsonExchangeService>();
builder.Services.AddScoped<IOperationsCalendarService, OperationsCalendarService>();
builder.Services.AddScoped<IQrResolutionService, QrResolutionService>();
builder.Services.Configure<GoogleMapsOptions>(
    builder.Configuration.GetSection(GoogleMapsOptions.SectionName));
builder.Services.Configure<FirebaseMessagingOptions>(
    builder.Configuration.GetSection(FirebaseMessagingOptions.SectionName));
builder.Services.Configure<MobileOperationsOptions>(
    builder.Configuration.GetSection(MobileOperationsOptions.SectionName));
builder.Services.AddHttpClient<IDeliveryRouteProvider, GoogleMapsRouteProvider>();
builder.Services.AddScoped<IDeliveryRouteService, DeliveryRouteService>();
builder.Services.AddHttpClient<IPushNotificationChannel, FirebasePushNotificationChannel>();
builder.Services.AddScoped<IOperationalNotificationService, OperationalNotificationService>();
builder.Services.AddScoped<IMobileDashboardService, MobileDashboardService>();
builder.Services.AddScoped<IDriverTrackingService, DriverTrackingService>();
builder.Services.AddScoped<IMobileBuyingListService, MobileBuyingListService>();
builder.Services.AddScoped<
    IBuyingListManagementService,
    BuyingListManagementService>();
builder.Services.AddScoped<IMobileStockReceiptService, MobileStockReceiptService>();
builder.Services.AddScoped<IMobilePackingDispatchService, MobilePackingDispatchService>();
builder.Services.AddScoped<IMobileWriteOffService, MobileWriteOffService>();
builder.Services.AddScoped<IRawStockService, RawStockService>();
builder.Services.AddScoped<IRawStockControlService, RawStockControlService>();
builder.Services.AddScoped<IOperationalPartyService, OperationalPartyService>();
builder.Services.AddScoped<IProcurementPlanningService, ProcurementPlanningService>();
builder.Services.AddScoped<IManagementDashboardService, ManagementDashboardService>();
builder.Services.AddScoped<IRoleDashboardService, RoleDashboardService>();
builder.Services.AddScoped<IFormalReportService, FormalReportService>();
builder.Services.AddSingleton<IReportSnapshotStore, ReportSnapshotStore>();
builder.Services.AddScoped<IReportPdfService, ReportPdfService>();
builder.Services.AddScoped<ILecturerDatasetService, LecturerDatasetService>();

// These workers start with the API. The expiry worker evaluates batches and
// the outbox worker retries queued notifications using bounded polling.
builder.Services.AddHostedService<ExpiryAlertBackgroundService>();
builder.Services.AddHostedService<NotificationOutboxProcessor>();
var app = builder.Build();

var requestedLecturerSeed = args.Contains(
    "--seed-lecturer-dataset",
    StringComparer.OrdinalIgnoreCase);
var requestedLecturerVerification = args.Contains(
    "--verify-lecturer-dataset",
    StringComparer.OrdinalIgnoreCase);
if (requestedLecturerSeed || requestedLecturerVerification)
{
    if (requestedLecturerSeed && requestedLecturerVerification)
    {
        Console.Error.WriteLine(
            "Choose either the lecturer dataset seed command or the verification command.");
        Environment.ExitCode = 2;
        return;
    }

    var mode = requestedLecturerVerification
        ? LecturerDatasetMode.Verify
        : args.Contains("--dry-run", StringComparer.OrdinalIgnoreCase)
            ? LecturerDatasetMode.DryRun
            : LecturerDatasetMode.Seed;
    await using var scope = app.Services.CreateAsyncScope();
    var service = scope.ServiceProvider
        .GetRequiredService<ILecturerDatasetService>();
    var result = await service.ExecuteAsync(mode);
    Console.WriteLine(JsonSerializer.Serialize(
        result,
        new JsonSerializerOptions { WriteIndented = true }));
    Environment.ExitCode = result.Success ? 0 : 1;
    return;
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

if (!app.Environment.IsDevelopment())
{
    app.UseHttpsRedirection();
}

app.UseCors("AllowAngular");

app.UseMiddleware<CorrelationIdMiddleware>();
app.UseMiddleware<ApiExceptionMiddleware>();

app.UseRateLimiter();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();
app.MapGet("/health", () => Results.Ok(new
{
    status = "healthy",
    service = "PhenyoSync API",
    checkedAtUtc = DateTime.UtcNow
})).AllowAnonymous();

app.Run();
