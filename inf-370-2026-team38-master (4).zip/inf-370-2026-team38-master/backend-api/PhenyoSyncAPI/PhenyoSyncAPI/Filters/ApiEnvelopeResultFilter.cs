using System.Collections;
using System.Reflection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using PhenyoSyncAPI.Contracts;

namespace PhenyoSyncAPI.Filters;

public sealed class ApiEnvelopeResultFilter : IAsyncResultFilter
{
    public async Task OnResultExecutionAsync(
        ResultExecutingContext context,
        ResultExecutionDelegate next)
    {
        if (context.Result is ObjectResult objectResult &&
            objectResult.Value is not IApiEnvelope &&
            IsJsonResult(objectResult))
        {
            var statusCode = objectResult.StatusCode ??
                StatusCodes.Status200OK;

            if (statusCode >= StatusCodes.Status400BadRequest)
            {
                objectResult.Value = ApiResponses.Error(
                    context.HttpContext,
                    ReadMessage(objectResult.Value) ??
                        DefaultErrorMessage(statusCode),
                    ReadCode(objectResult.Value) ??
                        $"HTTP_{statusCode}",
                    ReadErrors(objectResult.Value));
            }
            else
            {
                objectResult.Value = ApiResponses.Ok(
                    context.HttpContext,
                    objectResult.Value,
                    ReadMessage(objectResult.Value) ??
                        DefaultSuccessMessage(statusCode),
                    ReadCode(objectResult.Value) ??
                        (statusCode == StatusCodes.Status201Created
                            ? "RESOURCE_CREATED"
                            : "REQUEST_COMPLETED"));
            }

            // Endpoint signatures may declare a concrete DTO return type.
            // Once the result is wrapped, retaining that declared type makes
            // System.Text.Json try to serialize the envelope as the DTO.
            objectResult.DeclaredType = null;
        }

        await next();
    }

    private static bool IsJsonResult(ObjectResult result) =>
        result.ContentTypes.Count == 0 ||
        result.ContentTypes.Any(item =>
            item.Contains("json", StringComparison.OrdinalIgnoreCase));

    private static string? ReadMessage(object? value) =>
        ReadProperty(value, "message")?.ToString();

    private static string? ReadCode(object? value) =>
        ReadProperty(value, "code")?.ToString();

    private static IReadOnlyDictionary<string, string[]>? ReadErrors(
        object? value)
    {
        var errors = ReadProperty(value, "errors");
        if (errors is IReadOnlyDictionary<string, string[]> typed)
        {
            return typed;
        }

        if (errors is IDictionary dictionary)
        {
            return dictionary.Keys
                .Cast<object>()
                .ToDictionary(
                    key => key.ToString() ?? string.Empty,
                    key => dictionary[key] switch
                    {
                        string[] messages => messages,
                        IEnumerable<string> messages => messages.ToArray(),
                        object message => [message.ToString() ?? string.Empty],
                        _ => Array.Empty<string>()
                    },
                    StringComparer.OrdinalIgnoreCase);
        }

        return null;
    }

    private static object? ReadProperty(object? value, string name)
    {
        if (value is null)
        {
            return null;
        }

        if (value is IDictionary<string, object?> dictionary &&
            dictionary.TryGetValue(name, out var dictionaryValue))
        {
            return dictionaryValue;
        }

        return value.GetType()
            .GetProperty(
                name,
                BindingFlags.Public |
                BindingFlags.Instance |
                BindingFlags.IgnoreCase)
            ?.GetValue(value);
    }

    private static string DefaultSuccessMessage(int statusCode) =>
        statusCode == StatusCodes.Status201Created
            ? "The record was created successfully."
            : "The request was completed successfully.";

    private static string DefaultErrorMessage(int statusCode) =>
        statusCode switch
        {
            StatusCodes.Status400BadRequest =>
                "Check the supplied information and try again.",
            StatusCodes.Status401Unauthorized =>
                "Sign in to continue.",
            StatusCodes.Status403Forbidden =>
                "You do not have permission to perform this action.",
            StatusCodes.Status404NotFound =>
                "The requested record was not found.",
            StatusCodes.Status409Conflict =>
                "The request conflicts with the current record state.",
            _ => "The request could not be completed."
        };
}
