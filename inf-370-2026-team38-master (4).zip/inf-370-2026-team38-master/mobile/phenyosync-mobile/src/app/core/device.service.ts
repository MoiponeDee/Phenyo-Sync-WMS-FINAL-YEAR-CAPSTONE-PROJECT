/**
 * Reviewer guide: Centralises the device mobile concern for pages and device integrations.
 * Client checks improve offline UX; the API remains authoritative for permissions and workflow rules.
 */
import { Injectable } from '@angular/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Capacitor } from '@capacitor/core';
import { Geolocation } from '@capacitor/geolocation';
import { Preferences } from '@capacitor/preferences';
import { PushNotifications } from '@capacitor/push-notifications';

@Injectable({ providedIn: 'root' })
/** Wraps device capabilities and keeps browser fallbacks explicit for mobile workflows. */
export class DeviceService {
  /**
   * Reviewer note: Centralises supports push notifications for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  supportsPushNotifications(): boolean {
    return Capacitor.isNativePlatform();
  }

  /**
   * Reviewer note: Centralises take delivery photo for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  async takeDeliveryPhoto(): Promise<Blob> {
    const photo = await Camera.getPhoto({
      quality: 82,
      allowEditing: false,
      resultType: CameraResultType.Uri,
      source: CameraSource.Camera,
      correctOrientation: true
    });
    if (!photo.webPath) throw new Error('The camera did not return an image.');
    return await fetch(photo.webPath).then(response => response.blob());
  }

  /**
   * Reviewer note: Centralises current position for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  async currentPosition(): Promise<{
    latitude: number;
    longitude: number;
    accuracyMetres: number;
    speedMetresPerSecond?: number;
    headingDegrees?: number;
    capturedAtUtc: string;
  }> {
    if (!Capacitor.isNativePlatform()) {
      return await this.currentBrowserPosition();
    }

    const position = await Geolocation.getCurrentPosition({
      enableHighAccuracy: true,
      timeout: 15000
    });
    return {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracyMetres: position.coords.accuracy,
      speedMetresPerSecond: position.coords.speed ?? undefined,
      headingDegrees: position.coords.heading ?? undefined,
      capturedAtUtc: new Date(position.timestamp).toISOString()
    };
  }

  /**
   * Reviewer note: Centralises current browser position for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  private currentBrowserPosition(): Promise<{
    latitude: number;
    longitude: number;
    accuracyMetres: number;
    speedMetresPerSecond?: number;
    headingDegrees?: number;
    capturedAtUtc: string;
  }> {
    if (!navigator.geolocation) {
      return Promise.reject(new Error(
        'Location sharing is not supported by this browser. Use the installed mobile app or a supported browser.'));
    }

    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        position => resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracyMetres: position.coords.accuracy,
          speedMetresPerSecond: position.coords.speed ?? undefined,
          headingDegrees: position.coords.heading ?? undefined,
          capturedAtUtc: new Date(position.timestamp).toISOString()
        }),
        error => reject(new Error(this.browserLocationMessage(error))),
        {
          enableHighAccuracy: true,
          timeout: 15_000,
          maximumAge: 10_000
        }
      );
    });
  }

  /**
   * Reviewer note: Centralises browser location message for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  private browserLocationMessage(error: GeolocationPositionError): string {
    if (error.code === error.PERMISSION_DENIED) {
      return 'Location permission is blocked. Allow location access in the browser and retry.';
    }
    if (error.code === error.POSITION_UNAVAILABLE) {
      return 'Your current location is unavailable. Move to an open area and retry.';
    }
    if (error.code === error.TIMEOUT) {
      return 'Location capture timed out. The next foreground update will retry automatically.';
    }
    return 'Your current location could not be captured.';
  }

  /**
   * Reviewer note: Centralises enable push for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  async enablePush(): Promise<string> {
    if (!this.supportsPushNotifications()) {
      throw new Error(
        'Push registration is available in the installed Android app. In-app notifications remain available in this browser.'
      );
    }
    const permission = await PushNotifications.requestPermissions();
    if (permission.receive !== 'granted') {
      throw new Error('Push notifications were not permitted.');
    }
    return await new Promise<string>(async (resolve, reject) => {
      const registration = await PushNotifications.addListener(
        'registration',
        async token => {
          await registration.remove();
          await registrationError.remove();
          resolve(token.value);
        });
      const registrationError = await PushNotifications.addListener(
        'registrationError',
        async error => {
          await registration.remove();
          await registrationError.remove();
          reject(new Error(error.error));
        });
      await PushNotifications.register();
    });
  }

  /**
   * Reviewer note: Centralises save draft for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  async saveDraft(key: string, value: unknown): Promise<void> {
    await Preferences.set({ key, value: JSON.stringify(value) });
  }

  /**
   * Reviewer note: Centralises read draft for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  async readDraft<T>(key: string): Promise<T | null> {
    const { value } = await Preferences.get({ key });
    return value ? JSON.parse(value) as T : null;
  }

  /**
   * Reviewer note: Centralises remove draft for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  async removeDraft(key: string): Promise<void> {
    await Preferences.remove({ key });
  }
}
