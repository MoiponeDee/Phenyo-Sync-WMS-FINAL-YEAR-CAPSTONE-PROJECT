/**
 * Reviewer guide: Centralises the dashboard presentation mobile concern for pages and device integrations.
 * Client checks improve offline UX; the API remains authoritative for permissions and workflow rules.
 */
export function isFocusedMobileTaskRole(
  roleCode: string | null | undefined
): boolean {
  return roleCode === 'MarketBuyer' || roleCode === 'Packer';
}

export function shouldShowManagementDashboard(
  roleCode: string | null | undefined
): boolean {
  return !!roleCode &&
    !isFocusedMobileTaskRole(roleCode) &&
    roleCode !== 'Driver';
}

export function shouldPromotePacking(
  roleCode: string | null | undefined,
  moduleCodes: readonly string[]
): boolean {
  return roleCode === 'Packer' && moduleCodes.includes('packing');
}
