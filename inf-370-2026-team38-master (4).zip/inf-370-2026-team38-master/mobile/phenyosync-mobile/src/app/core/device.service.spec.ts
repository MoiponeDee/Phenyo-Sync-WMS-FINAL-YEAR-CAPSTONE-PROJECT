import { Capacitor } from '@capacitor/core';
import { vi } from 'vitest';
import { DeviceService } from './device.service';

describe('DeviceService location fallbacks', () => {
  afterEach(() => vi.restoreAllMocks());

  function installFailure(code: number): void {
    Object.defineProperty(navigator, 'geolocation', {
      configurable: true,
      value: {
        getCurrentPosition: (_success: PositionCallback, failure: PositionErrorCallback) =>
          failure({ code, PERMISSION_DENIED: 1, POSITION_UNAVAILABLE: 2, TIMEOUT: 3 } as GeolocationPositionError)
      }
    });
  }

  it('explains denied location permission and offers a retry path', async () => {
    vi.spyOn(Capacitor, 'isNativePlatform').mockReturnValue(false);
    installFailure(1);
    await expect(new DeviceService().currentPosition()).rejects.toThrow('Allow location access');
  });

  it('distinguishes an unavailable position from a denied permission', async () => {
    vi.spyOn(Capacitor, 'isNativePlatform').mockReturnValue(false);
    installFailure(2);
    await expect(new DeviceService().currentPosition()).rejects.toThrow('Move to an open area');
  });
});
