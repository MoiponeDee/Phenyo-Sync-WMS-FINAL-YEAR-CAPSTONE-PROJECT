/**
 * Reviewer guide: Centralises the auth mobile concern for pages and device integrations.
 * Client checks improve offline UX; the API remains authoritative for permissions and workflow rules.
 */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthenticationResult } from './models';
import { SessionService } from './session.service';

interface ApiResponse<T> {
  // Reviewer note: Holds safe user-facing feedback from API, scanner, GPS, or device operations.
  // It is refreshed for each attempt so stale outcomes are not presented as current.
  success: boolean;
  // Reviewer note: Holds safe user-facing feedback from API, scanner, GPS, or device operations.
  // It is refreshed for each attempt so stale outcomes are not presented as current.
  message: string;
  // Reviewer note: Captures mobile workflow input before a narrow DTO is sent through the API service.
  // Local checks improve usability; the server revalidates values and permissions.
  code: string;
  data: T;
  traceId?: string;
}

type ApiOrData<T> = ApiResponse<T> | T;

@Injectable({ providedIn: 'root' })
/** Owns mobile sign-in/sign-out calls and local session persistence. */
export class MobileAuthService {
  private readonly base = `${environment.apiUrl}/auth`;

  /**
   * Reviewer note: Centralises constructor for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  constructor(
    private readonly http: HttpClient,
    private readonly session: SessionService
  ) {}

  /**
   * Reviewer note: Centralises login for mobile pages so API, session, and device contracts are not duplicated.
   * The server still authenticates, authorises, and validates every workflow transition.
   */
  login(
    email: string,
    password: string
  ): Observable<AuthenticationResult> {
    return this.http.post<ApiOrData<AuthenticationResult>>(
      `${this.base}/login`,
      { email, password, client: 'Mobile' },
      { withCredentials: true }
    ).pipe(
      map(response =>
        'data' in response ? response.data : response
      ),
      tap(result => this.session.save(result))
    );
  }

  forgotPassword(email: string): Observable<string> {
    return this.http.post<{ message?: string }>(
      `${this.base}/forgot-password`,
      { email }
    ).pipe(map(response => response.message ??
      'If the account exists, a password reset link will be sent.'));
  }
}
