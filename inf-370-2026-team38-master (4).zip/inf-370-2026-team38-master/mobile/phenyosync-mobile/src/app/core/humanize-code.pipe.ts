/**
 * Reviewer guide: Centralises the humanize code pipe mobile concern for pages and device integrations.
 * Client checks improve offline UX; the API remains authoritative for permissions and workflow rules.
 */
import { Pipe, PipeTransform } from '@angular/core';
import { humanizeCode } from './mobile-errors';

@Pipe({
  name: 'humanizeCode',
  standalone: true
})
export class HumanizeCodePipe implements PipeTransform {
  /**
   * Reviewer note: Encapsulates transform so the mobile template remains declarative and workflow state stays testable.
   * This helper prepares or presents data without replacing server-side validation.
   */
  transform(value: string | null | undefined): string {
    return humanizeCode(value);
  }
}
