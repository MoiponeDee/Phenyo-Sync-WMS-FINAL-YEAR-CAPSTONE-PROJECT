/**
 * Reviewer guide: Centralises the auth guard mobile concern for pages and device integrations.
 * Client checks improve offline UX; the API remains authoritative for permissions and workflow rules.
 */
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { SessionService } from './session.service';

export const authGuard: CanActivateFn = () => {
  const session = inject(SessionService);
  // Fast local gate only; every mobile API call is still authenticated by the backend.
  return session.authenticated
    ? true
    : inject(Router).createUrlTree(['/login']);
};
