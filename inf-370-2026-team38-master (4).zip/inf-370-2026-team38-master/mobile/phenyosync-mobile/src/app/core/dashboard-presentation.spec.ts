/**
 * Reviewer guide: Verifies the dashboard presentation mobile contract and its regression-sensitive behaviour.
 * Each test records an observable workflow rule rather than a private implementation detail.
 */
import {
  isFocusedMobileTaskRole,
  shouldPromotePacking,
  shouldShowManagementDashboard
} from './dashboard-presentation';

// Locks the mobile dashboard's friendly labels and presentation-only role mapping.
describe('mobile dashboard presentation', () => {
  it.each(['MarketBuyer', 'Packer'])(
    'keeps %s focused on tasks without management KPIs',
    roleCode => {
      expect(isFocusedMobileTaskRole(roleCode)).toBe(true);
      expect(shouldShowManagementDashboard(roleCode)).toBe(false);
    }
  );

  // Reviewer note: Guards the observable rule that keeps the Driver dashboard free of management KPIs.
  it('keeps the Driver dashboard free of management KPIs', () => {
    expect(shouldShowManagementDashboard('Driver')).toBe(false);
  });

  // Reviewer note: Guards the observable rule that retains management metrics for a management role.
  it('retains management metrics for a management role', () => {
    expect(shouldShowManagementDashboard('OperationsManager')).toBe(true);
  });

  it('promotes the scan-first packing action only for a permitted Packer workspace', () => {
    expect(shouldPromotePacking('Packer', ['packing'])).toBe(true);
    expect(shouldPromotePacking('Packer', ['deliveries'])).toBe(false);
    expect(shouldPromotePacking('Admin', ['packing'])).toBe(false);
  });
});
