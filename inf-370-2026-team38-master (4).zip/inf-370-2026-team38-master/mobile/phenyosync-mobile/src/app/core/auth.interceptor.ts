/**
 * Reviewer guide: Centralises the auth interceptor mobile concern for pages and device integrations.
 * Client checks improve offline UX; the API remains authoritative for permissions and workflow rules.
 */
import { HttpErrorResponse, HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, map, throwError } from 'rxjs';
import { SessionService } from './session.service';

interface Envelope<T> {
  // Reviewer note: Holds safe user-facing feedback from API, scanner, GPS, or device operations.
  // It is refreshed for each attempt so stale outcomes are not presented as current.
  success: boolean;
  // Reviewer note: Captures mobile workflow input before a narrow DTO is sent through the API service.
  // Local checks improve usability; the server revalidates values and permissions.
  code: string;
  data: T;
}

export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const session = inject(SessionService);
  const router = inject(Router);
  // Attach session credentials centrally so workflow pages contain no token handling.
  const token = session.token;
  if (token) {
    request = request.clone({
      setHeaders: { Authorization: `Bearer ${token}` }
    });
  }
  return next(request).pipe(
    /**
     * Reviewer note: Handles map consistently for mobile API requests rather than duplicating token plumbing.
     * It attaches session context but cannot grant access; the server validates the token and permission.
     */
    map(event => {
      // Mobile services consume response DTOs directly while the API keeps a uniform envelope.
      if (event instanceof HttpResponse && isEnvelope(event.body)) {
        return event.clone({ body: event.body.data });
      }
      return event;
    }),
    /**
     * Reviewer note: Handles catch error consistently for mobile API requests rather than duplicating token plumbing.
     * It attaches session context but cannot grant access; the server validates the token and permission.
     */
    catchError((error: HttpErrorResponse) => {
      // Clear stale device state when the backend rejects the session.
      if (error.status === 401 && !request.url.includes('/auth/login')) {
        session.clear();
        void router.navigate(['/login']);
      }
      return throwError(() => error);
    })
  );
};

function isEnvelope(value: unknown): value is Envelope<unknown> {
  return !!value &&
    typeof value === 'object' &&
    'success' in value &&
    'data' in value &&
    'code' in value;
}
