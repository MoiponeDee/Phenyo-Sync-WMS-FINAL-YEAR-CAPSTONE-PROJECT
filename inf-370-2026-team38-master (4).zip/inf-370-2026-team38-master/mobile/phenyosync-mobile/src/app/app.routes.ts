/**
 * Reviewer guide: Defines public and protected Ionic routes from session and permission state.
 * Route visibility is defence-in-depth; mobile API endpoints independently enforce authorization.
 */
import { Routes } from '@angular/router';
import { authGuard } from './core/auth.guard';
import { permissionGuard } from './core/permission.guard';

// Route metadata controls mobile visibility and early navigation. The API independently
// enforces every permission because a user can call an endpoint without this router.
export const routes: Routes = [
  // Login sits outside the guarded shell because a user cannot establish a session from inside that shell.
  {
    path: 'login',
    loadComponent: () =>
      import('./pages/login.page').then(module => module.LoginPage)
  },
  // Every operational child first requires an authenticated session, then its own least-privilege permission.
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./pages/shell.page').then(module => module.ShellPage),
    children: [
      {
        path: 'home',
        canActivate: [permissionGuard],
        data: { permission: 'Mobile.Access' },
        loadComponent: () =>
          import('./pages/dashboard.page').then(module => module.DashboardPage)
      },
      {
        path: 'deliveries',
        canActivate: [permissionGuard],
        data: {
          anyPermissions: [
            'Mobile.Delivery.ViewOwn',
            'Mobile.Delivery.ViewAll'
          ]
        },
        loadComponent: () =>
          import('./pages/deliveries.page').then(module => module.DeliveriesPage)
      },
      {
        path: 'buying-list',
        canActivate: [permissionGuard],
        data: {
          anyPermissions: [
            'Mobile.BuyingList.View',
            'Mobile.BuyingList.ViewAll'
          ]
        },
        loadComponent: () =>
          import('./pages/buying-list.page').then(module => module.BuyingListPage)
      },
      {
        path: 'stock-receipts',
        canActivate: [permissionGuard],
        data: { permission: 'Mobile.StockReceipt.View' },
        loadComponent: () =>
          import('./pages/stock-receipts.page').then(module => module.StockReceiptsPage)
      },
      {
        path: 'packing',
        canActivate: [permissionGuard],
        data: { permission: 'Mobile.Packing.View' },
        loadComponent: () =>
          import('./pages/packing.page').then(module => module.PackingPage)
      },
      {
        path: 'dispatch',
        canActivate: [permissionGuard],
        data: { permission: 'Mobile.Dispatch.View' },
        loadComponent: () =>
          import('./pages/dispatch.page').then(module => module.DispatchPage)
      },
      {
        path: 'write-offs',
        canActivate: [permissionGuard],
        data: { permission: 'Mobile.WriteOff.View' },
        loadComponent: () =>
          import('./pages/write-offs.page').then(module => module.WriteOffsPage)
      },
      {
        path: 'notifications',
        canActivate: [permissionGuard],
        data: { permission: 'Mobile.Notification.View' },
        loadComponent: () =>
          import('./pages/notifications.page').then(module => module.NotificationsPage)
      },
      {
        path: 'help',
        canActivate: [permissionGuard],
        data: { permission: 'Mobile.Help.View' },
        loadComponent: () =>
          import('./pages/help.page').then(module => module.HelpPage)
      },
      {
        path: 'access-denied',
        loadComponent: () =>
          import('./pages/access-denied.page')
            .then(module => module.AccessDeniedPage)
      },
      { path: '', pathMatch: 'full', redirectTo: 'home' }
    ]
  },
  { path: '**', redirectTo: '' }
];
