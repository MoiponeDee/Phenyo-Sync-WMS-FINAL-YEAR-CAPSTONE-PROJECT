package za.co.phenyosync.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
