# PhenyoSync Warehouse Management System

PhenyoSync is Team 38's INF370 warehouse management system. It connects customer order intake, product and pricing administration, production planning, raw and finished stock, packing, procurement, delivery tracking, payments, reporting, audit history, and mobile execution in one permission-controlled workflow.

## Team 38

- Mohamed Yaseen Munshi
- Linah Ndimande
- Moipone Dikobe
- Palesa Mokapela
- Zafar Ahmed Suliman

Individual review and work-allocation material is maintained separately from the source repository.

## Architecture at a glance

```text
Angular web client ─┐
                    ├─ HTTPS/JSON ─> ASP.NET Core API ─> EF Core ─> SQL Server (WMS_DB)
Ionic mobile client ┘                       │
                                            ├─ SMTP email
                                            ├─ Google Forms/Sheets intake
                                            ├─ XLSX/JSON exchange
                                            └─ QuestPDF reports / protected files
```

The API is authoritative. Angular and Ionic hide unavailable actions for usability, but controllers apply authentication/permission policies and services re-check business rules, current status, ownership, quantities, concurrency tokens, and separation of duties.

## Technology stack

| Layer | Technology |
|---|---|
| API | .NET 8, ASP.NET Core controllers, JWT bearer authentication |
| Data | Entity Framework Core 8, SQL Server, migrations, SQLite test databases |
| Security | BCrypt password hashes, OTP/recovery codes, permission policies, audit sanitisation |
| Web | Angular 21, TypeScript 5.9, RxJS, Leaflet, ZXing |
| Mobile | Ionic 8, Angular 21, Capacitor 8, camera/barcode/geolocation/push plugins |
| Exchange/reporting | ClosedXML, JSON exchange, QuestPDF, ImageSharp, QRCoder |
| Tests | xUnit, Angular/Vitest, Ionic/Vitest |

## Repository structure

| Path | Purpose |
|---|---|
| `backend-api/PhenyoSyncAPI/PhenyoSyncAPI` | API controllers, services, DTOs, entities, security, migrations and startup |
| `backend-api/PhenyoSyncAPI/PhenyoSyncAPI.Tests` | Focused backend business, security and integration-style tests |
| `frontend/phenyosync` | Angular management web application |
| `mobile/phenyosync-mobile` | Ionic/Capacitor operations application |
| `database` | Reviewed SQL scripts and final demo seed assets; never run automatically |
| `deployment-safety` | Deployment and database safety material |
| `docs` | implementation evidence, matrices, demo checklists and individual-review guides |
| `tools` | repository tooling such as Google Form field generation support |

## Roles and friendly labels

Persisted role codes stay compatible with the existing database. The web label **Super Admin** maps to persisted `Admin`; the web label **Admin** maps to persisted `AdminClerk`. No separate persisted `SuperAdmin` role is introduced.

| User-facing role | Persisted role code | Main responsibility |
|---|---|---|
| Super Admin | `Admin` | commercial/security/customer/pricing administration |
| Admin | `AdminClerk` | day-to-day administrative processing |
| Operations Manager | `OperationsManager` | operations oversight; no Raw Stock permission |
| Warehouse Manager | `WarehouseManager` | warehouse, production and Raw Stock controls |
| Packer | `Packer` | packing tasks and authorised scans |
| Driver | `Driver` | own deliveries and delivery execution |
| Buyer | `MarketBuyer` | buying lists and supply activity |
| Stock Taker | `StockTaker` | stock-count capture where assigned |

The definitive mappings are `Security/RoleCodes.cs`, `Security/SecurityRoleMatrix.cs`, `Security/Permissions.cs`, `navigation/navigation.config.ts`, route guards, and controller permission attributes.

## Main subsystems

- Authentication and account security: login, logout, OTP, recovery codes, forgot/reset password, trusted devices, profile and password change.
- Product management: categories, types, hierarchy, product CRUD/status, prices, batches, QR lookup and product data exchange.
- Customer orders: secure order links, Google intake, internal/public creation, search, editing, validation, commercial approval, invoices and status history.
- Supply and stock: production requirements, procurement shortages, buying lists, suppliers/orders, raw-stock receipts, stock takes, reconciliation and write-offs.
- Packing and dispatch: available batches, packing scans/manual fallback, idempotent completion, reservations, dispatch and exact-once stock consumption.
- Delivery: scheduling, driver assignment, own jobs, route calculation, location sessions, proof images and completion.
- Finance and reporting: customer/supplier payments, reversals, seven formal reports, charts, filters and PDF snapshots.
- Governance: backend permissions, least privilege, system settings, lookups, help content and searchable audit logs.

## Authentication and security flow

1. `POST /api/auth/login` validates credentials and client type.
2. Web users complete OTP unless an eligible trusted device is accepted; mobile access follows the configured mobile policy.
3. JWT claims identify the user. `PermissionService` loads active database mappings and intersects protected system roles with `SecurityRoleMatrix`.
4. `[HasPermission]` / `[HasAnyPermission]` policies protect API actions. Angular `permissionGuard` and Ionic presentation state provide matching navigation only.
5. Sensitive actions also enforce lifecycle and separation-of-duty rules in services.
6. Audit events contain safe business metadata. Tokens, passwords, OTPs, SMTP credentials and Google credentials are not logged.

Self-service profile editing intentionally accepts only `PhoneNumber` and `RowVersion`. Names, login identifiers, email, role, status, permissions, licence and vehicle data use authorised administrator workflows.

## Source locations reviewers usually open

- API startup/DI: `backend-api/PhenyoSyncAPI/PhenyoSyncAPI/Program.cs`
- EF model: `backend-api/PhenyoSyncAPI/PhenyoSyncAPI/Data/PhenyoSyncDbContext*.cs`
- Authentication: `Controllers/AuthController.cs`, `Services/JwtService.cs`, `Services/TwoFactorService.cs`
- Permissions: `Security/PermissionAuthorization.cs`, `Security/SecurityRoleMatrix.cs`
- Orders/stock: `Services/OrderService.cs`, `OrderWorkflowService.cs`, `OrderStockService.cs`
- Mobile packing/delivery: `Services/MobilePackingDispatchService.cs`, `DeliveryService.cs`, `DriverTrackingService.cs`
- Raw stock/payments: `Services/RawStockControlService.cs`, `OperationalPartyService.cs`
- Reports/PDF: `Services/Reports/FormalReportService.cs`, `ReportPdfService.cs`
- Angular routes/navigation: `frontend/phenyosync/src/app/app.routes.ts`, `navigation/navigation.config.ts`
- Ionic routes/workflows: `mobile/phenyosync-mobile/src/app/app.routes.ts`, `src/app/core/mobile-api.service.ts`

## Configuration without secrets

Tracked configuration contains structure and safe defaults only. Developer secrets belong in .NET User Secrets for the API project's `UserSecretsId`.

Required runtime key names depend on the feature being demonstrated and can include:

- `ConnectionStrings:DefaultConnection`
- `Jwt:Key`, `Jwt:Issuer`, `Jwt:Audience`
- `FrontendUrl`
- `Email:SmtpHost`, `Email:SmtpPort`, `Email:SmtpUser`, `Email:SmtpPassword`, `Email:FromAddress`, `Email:FromName`
- `GoogleOrderIntake:SpreadsheetId`, `GoogleOrderIntake:ApiKey`, `GoogleOrderIntake:Range`

Example commands set values without printing or committing them:

```powershell
cd backend-api/PhenyoSyncAPI/PhenyoSyncAPI
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "<local SQL Server connection>"
dotnet user-secrets set "GoogleOrderIntake:ApiKey" "<Google API key>"
```

Do not add real values to `appsettings*.json`, source files, screenshots, test output or documentation.

## Build and test

From the repository root:

```powershell
dotnet restore backend-api/PhenyoSyncAPI/PhenyoSyncAPI.sln
dotnet build backend-api/PhenyoSyncAPI/PhenyoSyncAPI.sln -c Release --no-restore
dotnet test backend-api/PhenyoSyncAPI/PhenyoSyncAPI.sln -c Release --no-build

cd frontend/phenyosync
npm ci
npm test -- --watch=false
npm run build -- --configuration production

cd ../../mobile/phenyosync-mobile
npm ci
npm test -- --watch=false
npm run build -- --configuration production
```

Check that the EF model matches the committed migrations without applying anything to `WMS_DB`:

```powershell
dotnet ef migrations has-pending-model-changes `
  --project backend-api/PhenyoSyncAPI/PhenyoSyncAPI/PhenyoSyncAPI.csproj `
  --startup-project backend-api/PhenyoSyncAPI/PhenyoSyncAPI/PhenyoSyncAPI.csproj
```

The final review-readiness run is recorded as 208 backend tests, 135 Angular tests and 25 Ionic tests; see the task hand-off for the exact pass/build/EF result from the current working tree.

## Database and migrations

- The application database is `WMS_DB`.
- Never drop, recreate, automatically reseed or automatically apply migrations to the presentation database.
- Review migration files and `PhenyoSyncDbContextModelSnapshot.cs` together.
- Create a migration only for a genuine persisted-model change. A DTO/UI-only profile restriction does not require one.
- Use the final demo seed only by explicit team decision and only against the intended environment.

## Individual review path

1. Start with this README and the architecture diagram.
2. Open your externally stored individual-review brief.
3. Follow the exact UI → Angular service → API → service → EF/table flow.
4. Open the recommended method and its focused test side by side.
5. Use the externally stored review code map for follow-up endpoint and entity questions.
6. Demonstrate with presentation data; do not change security settings, secrets, migrations or the database during review.

## Presentation notes

- A successful build proves compilation, not external SMTP or Google connectivity.
- Password-reset delivery is only verified when a configured sender accepts the message.
- The repository documents the ten canonical Google Form choices; a live form is changed only through an authenticated external operation.
- Browser route visibility is a convenience. Backend policy enforcement is the security boundary.
- Exact-once workflows use transactions, state checks, unique/idempotency keys and row-version concurrency rather than timeouts or retry guesses.

