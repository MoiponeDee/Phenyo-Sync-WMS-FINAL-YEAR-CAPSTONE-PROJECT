import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    // Angular TestBed compilation is CPU and memory intensive in this suite.
    // Serial files make the documented command deterministic on developer and
    // lecturer laptops without relaxing individual assertion failures.
    fileParallelism: false,
    maxWorkers: 1
  }
});
