/**
 * Reviewer guide: Wires the main frontend concern into the Angular application.
 * Business state remains server-authoritative and is exchanged through typed service contracts.
 */
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';
import { registerLocaleData } from '@angular/common';
import localeEnZa from '@angular/common/locales/en-ZA';

registerLocaleData(localeEnZa);

bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
