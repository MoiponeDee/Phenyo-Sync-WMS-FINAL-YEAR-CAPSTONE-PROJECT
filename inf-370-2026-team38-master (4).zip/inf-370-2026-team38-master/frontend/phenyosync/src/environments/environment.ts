/**
 * Reviewer guide: Supplies non-secret build-time environment configuration.
 * Runtime credentials, tokens and API secrets must never be stored in this tracked file.
 */
export const environment = {
  production: false,
  apiUrl: 'https://localhost:7038/api'
};
