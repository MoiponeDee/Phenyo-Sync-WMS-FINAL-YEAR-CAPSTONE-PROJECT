/**
 * Reviewer guide: Wires the humanize code pipe frontend concern into the Angular application.
 * Business state remains server-authoritative and is exchanged through typed service contracts.
 */
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'humanizeCode',
  standalone: true
})
// Converts persisted machine codes into readable UI labels without changing stored values.
export class HumanizeCodePipe implements PipeTransform {
  /**
   * Reviewer note: Encapsulates transform so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  transform(value: string | null | undefined): string {
    if (!value) {
      return 'Not available';
    }

    const normalized = value.trim();
    if (['Admin', 'BusinessManager'].includes(normalized)) {
      return 'Super Admin';
    }
    if (normalized === 'AdminClerk') {
      return 'Admin';
    }
    if (normalized === 'ExpiredPendingDecision') {
      return 'Expired — awaiting decision';
    }

    return normalized
      .replace(/[_-]+/g, ' ')
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
      .replace(/\bQr\b/gi, 'QR')
      .replace(/\s+/g, ' ')
      .trim();
  }
}
