/**
 * Reviewer guide: Verifies the humanize code pipe frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { HumanizeCodePipe } from './humanize-code.pipe';

describe('HumanizeCodePipe', () => {
  // Reviewer note: Guards the observable rule that turns stored workflow codes into readable labels.
  it('turns stored workflow codes into readable labels', () => {
    const pipe = new HumanizeCodePipe();
    expect(pipe.transform('ReadyForDispatch')).toBe('Ready For Dispatch');
    expect(pipe.transform('PendingApproval')).toBe('Pending Approval');
    expect(pipe.transform('Admin')).toBe('Super Admin');
    expect(pipe.transform('AdminClerk')).toBe('Admin');
    expect(pipe.transform('ExpiredPendingDecision'))
      .toBe('Expired — awaiting decision');
  });
});
