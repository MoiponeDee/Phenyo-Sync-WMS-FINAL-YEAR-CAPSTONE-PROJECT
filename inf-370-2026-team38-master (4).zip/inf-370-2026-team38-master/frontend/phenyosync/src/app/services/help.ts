/**
 * Reviewer guide: Centralises help HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface HelpCategory {
  helpCategoryId: number;
  systemCode: string;
  displayName: string;
  description?: string;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  sortOrder: number;
  isActive: boolean;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface HelpTopicSummary {
  helpTopicId: number;
  slug: string;
  title: string;
  summary: string;
  categoryName: string;
  snippet?: string;
  isPublic: boolean;
  isPublished: boolean;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  sortOrder: number;
}

export interface HelpTopic extends HelpTopicSummary {
  helpCategoryId: number;
  bodyContent: string;
  keywords?: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  audienceRoles: string[];
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
  previous?: HelpTopicSummary;
  next?: HelpTopicSummary;
  related: HelpTopicSummary[];
}

export interface HelpMedia {
  helpMediaId: number;
  helpTopicId?: number;
  title: string;
  description?: string;
  transcript?: string;
  isFeatured: boolean;
  isPublished: boolean;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  sortOrder: number;
  createdAtUtc: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  hasCaptions: boolean;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface HelpHome {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  categories: HelpCategory[];
  recommended: HelpTopicSummary[];
  featuredMedia?: HelpMedia;
}

export interface HelpSearchResult {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: HelpTopicSummary[];
  page: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

@Injectable({ providedIn: 'root' })
/** Resolves route-aware help content and protected media from the backend. */
export class HelpService {
  private readonly apiUrl = `${environment.apiUrl}/help`;
  private readonly manageUrl = `${environment.apiUrl}/help-management`;
  private readonly mediaManageUrl =
    `${environment.apiUrl}/help-media-management`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the home service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  home(): Observable<HelpHome> {
    return this.http.get<HelpHome>(this.apiUrl);
  }

  /**
   * Reviewer note: Centralises the search service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  search(query = '', categoryId?: number): Observable<HelpSearchResult> {
    let params = new HttpParams().set('query', query);
    if (categoryId) params = params.set('categoryId', categoryId);
    return this.http.get<HelpSearchResult>(
      `${this.apiUrl}/search`,
      { params }
    );
  }

  /**
   * Reviewer note: Transforms topic at the DTO boundary so callers receive a consistent representation.
   * The conversion does not make the client authoritative for persisted business data.
   */
  topic(slug: string): Observable<HelpTopic> {
    return this.http.get<HelpTopic>(
      `${this.apiUrl}/topics/${encodeURIComponent(slug)}`
    ).pipe(map(topic => this.currentTopicPresentation(topic)));
  }

  /**
   * Keeps legacy persisted Help copy aligned with the current report UI without
   * mutating WMS_DB during an application release.
   */
  private currentTopicPresentation(topic: HelpTopic): HelpTopic {
    if (topic.slug !== 'pricing-management-report') return topic;

    return {
      ...topic,
      summary: 'Interpret weighted monthly and annual price trends with line and bar charts.',
      bodyContent: `# Pricing management report
Monthly average selling price is quantity weighted from stored order-item price snapshots. The annual value is the arithmetic mean of the available monthly averages; months without observations are shown as N/A and are never treated as zero.

Use the line chart to follow actual selling-price observations and the bar chart to compare quantity-weighted averages by product. Visible value labels and the accessible support tables contain the exact values used by each chart.

Choose the analysis view, period, product or category, then generate the preview. The PDF export uses the same selected criteria and report result.`
    };
  }

  /**
   * Reviewer note: Centralises the context service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  context(route: string, componentKey?: string): Observable<{
    slug: string;
    title: string;
    summary: string;
  }> {
    let params = new HttpParams().set('route', route);
    if (componentKey) params = params.set('componentKey', componentKey);
    return this.http.get<{
      slug: string;
      title: string;
      summary: string;
    }>(`${this.apiUrl}/context`, { params });
  }

  /**
   * Reviewer note: Centralises the download pdf service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  downloadPdf(): Observable<Blob> {
    return this.http.get(
      `${this.apiUrl}/user-guide.pdf`,
      { responseType: 'blob' }
    );
  }

  /**
   * Reviewer note: Centralises the media service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  media(includeUnpublished = false): Observable<HelpMedia[]> {
    return this.http.get<HelpMedia[]>(
      includeUnpublished ? this.mediaManageUrl : `${this.apiUrl}/media`
    );
  }

  /**
   * Reviewer note: Centralises the media blob service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  mediaBlob(id: number): Observable<Blob> {
    return this.http.get(
      `${this.apiUrl}/media/${id}/stream`,
      { responseType: 'blob' }
    );
  }

  /**
   * Reviewer note: Centralises the captions blob service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  captionsBlob(id: number): Observable<Blob> {
    return this.http.get(
      `${this.apiUrl}/media/${id}/captions`,
      { responseType: 'blob' }
    );
  }

  /**
   * Reviewer note: Centralises the manage categories service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  manageCategories(): Observable<HelpCategory[]> {
    return this.http.get<HelpCategory[]>(
      `${this.manageUrl}/categories`
    );
  }

  /**
   * Reviewer note: Centralises the save category service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  saveCategory(
    value: Partial<HelpCategory> & {
      systemCode: string;
      displayName: string;
    }
  ): Observable<HelpCategory> {
    const url = value.helpCategoryId
      ? `${this.manageUrl}/categories/${value.helpCategoryId}`
      : `${this.manageUrl}/categories`;
    return value.helpCategoryId
      ? this.http.put<HelpCategory>(url, value)
      : this.http.post<HelpCategory>(url, value);
  }

  /**
   * Reviewer note: Centralises the manage topics service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  manageTopics(): Observable<HelpTopicSummary[]> {
    return this.http.get<HelpTopicSummary[]>(
      `${this.manageUrl}/topics`
    );
  }

  /**
   * Reviewer note: Centralises the manage topic service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  manageTopic(id: number): Observable<HelpTopic> {
    return this.http.get<HelpTopic>(
      `${this.manageUrl}/topics/${id}`
    );
  }

  /**
   * Reviewer note: Centralises the save topic service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  saveTopic(value: any): Observable<HelpTopic> {
    const url = value.helpTopicId
      ? `${this.manageUrl}/topics/${value.helpTopicId}`
      : `${this.manageUrl}/topics`;
    return value.helpTopicId
      ? this.http.put<HelpTopic>(url, value)
      : this.http.post<HelpTopic>(url, value);
  }

  /**
   * Reviewer note: Centralises the save context service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  saveContext(value: any): Observable<any> {
    const url = value.helpContextMappingId
      ? `${this.manageUrl}/contexts/${value.helpContextMappingId}`
      : `${this.manageUrl}/contexts`;
    return value.helpContextMappingId
      ? this.http.put(url, value)
      : this.http.post(url, value);
  }

  /**
   * Reviewer note: Centralises the upload media service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  uploadMedia(
    video: File,
    captions: File | null,
    value: {
      title: string;
      description?: string;
      transcript?: string;
      helpTopicId?: number | null;
      isFeatured: boolean;
      isPublished: boolean;
      sortOrder: number;
    }
  ): Observable<{ message: string; media: HelpMedia }> {
    const form = new FormData();
    form.append('video', video);
    if (captions) form.append('captions', captions);
    Object.entries(value).forEach(([key, item]) => {
      if (item !== undefined && item !== null) form.append(key, `${item}`);
    });
    return this.http.post<{ message: string; media: HelpMedia }>(
      this.mediaManageUrl,
      form
    );
  }

  /**
   * Reviewer note: Centralises the remove media service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  removeMedia(id: number, reason: string): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      `${this.mediaManageUrl}/${id}`,
      { body: { reason } }
    );
  }

  /**
   * Reviewer note: Centralises the update media service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateMedia(
    item: HelpMedia,
    changes: Partial<HelpMedia>
  ): Observable<HelpMedia> {
    const updated = { ...item, ...changes };
    return this.http.put<HelpMedia>(
      `${this.mediaManageUrl}/${item.helpMediaId}`,
      {
        title: updated.title,
        description: updated.description,
        transcript: updated.transcript,
        helpTopicId: updated.helpTopicId,
        isFeatured: updated.isFeatured,
        isPublished: updated.isPublished,
        sortOrder: updated.sortOrder,
        rowVersion: item.rowVersion
      }
    );
  }
}
