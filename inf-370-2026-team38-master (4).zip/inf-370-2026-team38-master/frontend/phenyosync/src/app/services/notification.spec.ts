/**
 * Reviewer guide: Verifies the notification frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TestBed } from '@angular/core/testing';
import { NotificationService } from './notification';

// Covers the notification behavior most likely to regress across permissions and workflow changes.
describe('NotificationService', () => {
  let service: NotificationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NotificationService);
  });

  // Reviewer note: Guards the observable rule that shows a user-friendly application notification.
  it('shows a user-friendly application notification', () => {
    service.success('  User saved successfully.  ');

    expect(service.notifications()).toEqual([
      expect.objectContaining({
        kind: 'success',
        message: 'User saved successfully.'
      })
    ]);
  });

  // Reviewer note: Guards the observable rule that suppresses duplicates and supports dismissal.
  it('suppresses duplicates and supports dismissal', () => {
    service.error('Unable to save the user.');
    service.error('Unable to save the user.');

    expect(service.notifications()).toHaveLength(1);
    service.dismiss(service.notifications()[0].id);
    expect(service.notifications()).toHaveLength(0);
  });
});
