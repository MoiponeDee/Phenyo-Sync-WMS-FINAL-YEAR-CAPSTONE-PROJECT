/**
 * Reviewer guide: Centralises security admin HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthorizationSession } from './authorization';

export interface UserSummary {
  userId: number;
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber?: string;
  status: 'Active' | 'Inactive';
  roleId: number;
  role: string;
  roleCode: string;
  driverId?: number | null;
  licenseNumber?: string | null;
  licenseExpiryDate?: string | null;
  vehicleAssigned?: string | null;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface SaveUserRequest {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string | null;
  roleId: number;
  roleChangeReason?: string | null;
  licenseNumber?: string | null;
  licenseExpiryDate?: string | null;
  vehicleAssigned?: string | null;
  rowVersion?: string;
}

export interface UserSearchResult {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: UserSummary[];
  page: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface RoleSummary {
  roleId: number;
  roleCode: string;
  roleName: string;
  description?: string;
  isSystemRole: boolean;
  isActive: boolean;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  assignedUsers: number;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  effectivePermissionCount: number;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  permissionIds?: number[];
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface PermissionSummary {
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  permissionId: number;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  permissionCode: string;
  displayName: string;
  module: string;
  description?: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  isSystemPermission: boolean;
  isActive: boolean;
  assignedRoleCount: number;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

@Injectable({ providedIn: 'root' })
/** Provides administrative role, permission and session-revocation operations. */
export class SecurityAdminService {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  private readonly usersUrl = `${environment.apiUrl}/users`;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  private readonly rolesUrl = `${environment.apiUrl}/roles`;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  private readonly permissionsUrl = `${environment.apiUrl}/permissions`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the search users service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  searchUsers(filters: {
    search?: string;
    role?: string;
    status?: string;
    page?: number;
    pageSize?: number;
  }): Observable<UserSearchResult> {
    let params = new HttpParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== '') params = params.set(key, value);
    });
    return this.http.get<UserSearchResult>(this.usersUrl, { params });
  }

  /**
   * Reviewer note: Centralises the create user service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createUser(request: SaveUserRequest): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(this.usersUrl, request);
  }

  /**
   * Reviewer note: Centralises the update user service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateUser(id: number, request: SaveUserRequest): Observable<{ message: string; rowVersion: string }> {
    return this.http.put<{ message: string; rowVersion: string }>(`${this.usersUrl}/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the change user status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changeUserStatus(
    id: number,
    active: boolean,
    reason: string,
    rowVersion: string
  ): Observable<{ message: string }> {
    const action = active ? 'reactivate' : 'deactivate';
    return this.http.post<{ message: string }>(
      `${this.usersUrl}/${id}/${action}`,
      { reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the assign role service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  assignRole(
    id: number,
    roleId: number,
    reason: string,
    rowVersion: string
  ): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.usersUrl}/${id}/assign-role`,
      { roleId, reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the trigger password reset service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  triggerPasswordReset(id: number): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.usersUrl}/${id}/password-reset`,
      {}
    );
  }

  /**
   * Reviewer note: Centralises the user permissions service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  userPermissions(id: number): Observable<AuthorizationSession> {
    return this.http.get<AuthorizationSession>(`${this.usersUrl}/${id}/permissions`);
  }

  /**
   * Reviewer note: Centralises the roles service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  roles(includeInactive = true, search = ''): Observable<RoleSummary[]> {
    return this.http.get<RoleSummary[]>(this.rolesUrl, {
      params: { includeInactive, search }
    });
  }

  /**
   * Reviewer note: Centralises the active roles service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  activeRoles(): Observable<RoleSummary[]> {
    return this.http.get<RoleSummary[]>(`${this.rolesUrl}/active`);
  }

  /**
   * Reviewer note: Centralises the role service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  role(id: number): Observable<RoleSummary> {
    return this.http.get<RoleSummary>(`${this.rolesUrl}/${id}`);
  }

  /**
   * Reviewer note: Centralises the create role service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createRole(request: Record<string, unknown>): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(this.rolesUrl, request);
  }

  /**
   * Reviewer note: Centralises the update role service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateRole(id: number, request: Record<string, unknown>): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.rolesUrl}/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the change role status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changeRoleStatus(
    id: number,
    isActive: boolean,
    reason: string,
    rowVersion: string
  ): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.rolesUrl}/${id}/status`,
      { isActive, reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the assign permissions service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  assignPermissions(
    id: number,
    permissionIds: number[],
    reason: string,
    rowVersion: string
  ): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(
      `${this.rolesUrl}/${id}/permissions`,
      { permissionIds, reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the delete role service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteRole(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.rolesUrl}/${id}`);
  }

  /**
   * Reviewer note: Centralises the permissions service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  permissions(
    includeInactive = true,
    search = '',
    module = ''
  ): Observable<PermissionSummary[]> {
    return this.http.get<PermissionSummary[]>(this.permissionsUrl, {
      params: { includeInactive, search, module }
    });
  }

  /**
   * Reviewer note: Centralises the create permission service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createPermission(request: Record<string, unknown>): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(this.permissionsUrl, request);
  }

  /**
   * Reviewer note: Centralises the update permission service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updatePermission(
    id: number,
    request: Record<string, unknown>
  ): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(
      `${this.permissionsUrl}/${id}`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the change permission status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changePermissionStatus(
    id: number,
    isActive: boolean,
    reason: string,
    rowVersion: string
  ): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.permissionsUrl}/${id}/status`,
      { isActive, reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the delete permission service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deletePermission(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.permissionsUrl}/${id}`);
  }
}
