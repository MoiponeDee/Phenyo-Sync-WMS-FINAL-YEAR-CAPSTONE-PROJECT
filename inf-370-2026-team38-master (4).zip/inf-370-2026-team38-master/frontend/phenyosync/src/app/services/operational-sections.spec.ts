/**
 * Reviewer guide: Verifies the operational sections frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { DashboardRouteService } from './dashboard-route';
import { OperationalSectionsService } from './operational-sections';

// Verifies raw-stock, procurement and payment clients preserve endpoint and DTO contracts.
describe('Operational sections integration', () => {
  let http: HttpTestingController;
  let service: OperationalSectionsService;
  let dashboards: DashboardRouteService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    http = TestBed.inject(HttpTestingController);
    service = TestBed.inject(OperationalSectionsService);
    dashboards = TestBed.inject(DashboardRouteService);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that resolves every operational role to its authoritative dashboard.
  it('resolves every operational role to its authoritative dashboard', () => {
    const revisedRoles = [
      'Admin',
      'WarehouseManager',
      'OperationsManager',
      'BusinessManager',
      'Packer',
      'Driver',
      'MarketBuyer'
    ];
    const legacyRoles = [
      'AdminClerk',
      'StockTaker',
      'CEO',
      'COO'
    ];

    [...revisedRoles, ...legacyRoles].forEach(role => {
      expect(dashboards.forRole(role)).toBe('/dashboard');
    });
    expect(dashboards.forRole('Unknown')).toBe('/dashboard');
  });

  // Reviewer note: Guards the observable rule that queries raw stock with server-side search and inactive filtering.
  it('queries raw stock with server-side search and inactive filtering', () => {
    service.rawStock('carrot', true).subscribe();
    const request = http.expectOne(pending =>
      pending.url === `${environment.apiUrl}/raw-stock` &&
      pending.params.get('search') === 'carrot' &&
      pending.params.get('includeInactive') === 'true' &&
      pending.params.get('pageSize') === '100');
    expect(request.request.method).toBe('GET');
    request.flush({ items: [], page: 1, pageSize: 100, total: 0 });
  });

  // Reviewer note: Guards the observable rule that posts an idempotent source-aware raw-stock receipt payload unchanged.
  it('posts an idempotent source-aware raw-stock receipt payload unchanged', () => {
    const payload = {
      sourceType: 'SupplierOrder',
      supplierId: 3,
      supplierOrderId: 9,
      operationId: 'operation-1',
      lines: [{ rawStockItemId: 4, acceptedQuantity: 25 }]
    };
    service.receive(payload).subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/raw-stock/receipts`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(payload);
    request.flush({
      rawStockReceiptId: 1,
      receiptNumber: 'RAWREC-1',
      sourceType: 'SupplierOrder',
      supplierName: 'Supplier',
      warehouseSection: 'Raw',
      docketReference: 'D-1',
      status: 'Posted',
      receivedAtUtc: new Date().toISOString(),
      correlationId: 'c-1'
    });
  });

  // Reviewer note: Guards the observable rule that preserves row version when submitting a stock take.
  it('preserves row version when submitting a stock take', () => {
    service.submitStockTake(42, 'row-version').subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/raw-stock-takes/42/submit`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({ rowVersion: 'row-version' });
    request.flush({});
  });

  // Reviewer note: Guards the observable rule that passes payment reversal decisions as explicit query criteria.
  it('passes payment reversal decisions as explicit query criteria', () => {
    const payload = {
      reason: 'Duplicate bank capture',
      rowVersion: 'payment-row-version'
    };
    service.decidePaymentReversal(18, true, payload).subscribe();
    const request = http.expectOne(pending =>
      pending.url ===
        `${environment.apiUrl}/financial-payments/18/reversal-decision` &&
      pending.params.get('approved') === 'true');
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(payload);
    request.flush({});
  });
});
