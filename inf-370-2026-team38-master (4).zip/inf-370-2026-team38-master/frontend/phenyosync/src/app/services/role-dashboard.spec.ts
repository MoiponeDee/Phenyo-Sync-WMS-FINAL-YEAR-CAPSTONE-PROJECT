/**
 * Reviewer guide: Verifies the role dashboard frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { RoleDashboardService } from './role-dashboard';

// Covers the role dashboard behavior most likely to regress across permissions and workflow changes.
describe('RoleDashboardService', () => {
  let service: RoleDashboardService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(RoleDashboardService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that requests role-scoped dashboard data with the selected period.
  it('requests role-scoped dashboard data with the selected period', () => {
    const fromUtc = '2026-08-01T00:00:00.000Z';
    const toUtc = '2026-08-02T23:59:59.999Z';
    let title = '';

    service.load(fromUtc, toUtc).subscribe(result => title = result.title);
    const request = http.expectOne(value =>
      value.url === `${environment.apiUrl}/dashboards/me` &&
      value.params.get('fromUtc') === fromUtc &&
      value.params.get('toUtc') === toUtc
    );
    request.flush({
      roleCode: 'WarehouseManager',
      title: 'Warehouse Manager dashboard',
      subtitle: 'Live warehouse activity.',
      fromUtc,
      toUtc,
      metrics: [],
      barChart: {
        title: 'Stock',
        description: 'Available stock.',
        valueKind: 'kilograms',
        points: []
      },
      lineChart: {
        title: 'Movements',
        description: 'Stock movement trend.',
        valueKind: 'kilograms',
        points: []
      },
      attentionItems: [],
      recentActivity: []
    });

    expect(title).toBe('Warehouse Manager dashboard');
  });
});

