import { HttpErrorResponse } from '@angular/common/http';

/** Converts API failures to actionable text without exposing server exception details. */
export function httpErrorMessage(error: unknown, fallback = 'The request could not be completed.'): string {
  if (!(error instanceof HttpErrorResponse)) return fallback;
  if (error.status === 0) {
    return 'The server could not be reached. Check your connection and try again.';
  }
  if (error.status === 401) return 'Your session has ended. Sign in and try again.';
  if (error.status === 403) return 'You do not have permission to perform this action.';
  if (error.status === 404) return 'The requested record was not found.';

  const validationErrors = error.status === 400 ? error.error?.errors : null;
  if (validationErrors && typeof validationErrors === 'object') {
    const messages = Object.values(validationErrors)
      .flatMap(value => Array.isArray(value) ? value : [value])
      .filter((value): value is string => typeof value === 'string' && !!value.trim());
    if (messages.length) return [...new Set(messages)].join(' ');
  }

  const serverMessage = error.error?.message;
  if ((error.status === 400 || error.status === 409) &&
      typeof serverMessage === 'string' && serverMessage.trim()) {
    return serverMessage;
  }
  if (error.status === 409) {
    return 'This record changed or is in use. Refresh the page and try again.';
  }
  if (error.status >= 500) {
    return 'The server could not complete the request. Try again, or contact support if it continues.';
  }
  return fallback;
}
