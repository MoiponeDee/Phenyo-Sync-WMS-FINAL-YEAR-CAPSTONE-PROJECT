/**
 * Reviewer guide: Centralises product data exchange HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface DataExchangePreviewRow {
  rowNumber: number;
  status: string;
  action: string;
  recordKey: string;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  messages: string[];
  expectedQuantity?: number;
  countedQuantity?: number;
  variance?: number;
}

export interface DataExchangeValidation {
  // Reviewer note: Keeps sensitive authentication state within the session or authentication boundary.
  // Possession of a client value never bypasses backend verification.
  validationToken: string;
  expiresAtUtc: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  totalRows: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  validRows: number;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  warningRows: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  invalidRows: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  rows: DataExchangePreviewRow[];
}

export interface DataExchangeResult {
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  // Reviewer note: Keeps sensitive authentication state within the session or authentication boundary.
  // Possession of a client value never bypasses backend verification.
  resultToken: string;
  createdCount: number;
  updatedCount: number;
  adjustmentCount: number;
  correlationId: string;
}

@Injectable({ providedIn: 'root' })
/** Implements the validate-then-import exchange protocol without duplicating workbook rules. */
export class ProductDataExchangeService {
  private readonly apiUrl = `${environment.apiUrl}/product-data-exchange/excel`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the template service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  template(): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/template`, { responseType: 'blob' });
  }

  /**
   * Reviewer note: Centralises the export service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  export(filters: Record<string, string | number | boolean | null | undefined>): Observable<Blob> {
    let params = new HttpParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== '') {
        params = params.set(key, value);
      }
    });
    return this.http.get(`${this.apiUrl}/export`, { params, responseType: 'blob' });
  }

  /**
   * Reviewer note: Centralises the validate service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  validate(file: File): Observable<DataExchangeValidation> {
    // Validation uploads the workbook but does not mutate product data.
    const form = new FormData();
    form.append('file', file, file.name);
    return this.http.post<DataExchangeValidation>(`${this.apiUrl}/validate`, form);
  }

  /**
   * Reviewer note: Centralises the import service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  import(validationToken: string, reason: string): Observable<DataExchangeResult> {
    // Import references the server-owned validation job, preventing client-side row tampering.
    const params = new HttpParams().set('validationToken', validationToken);
    return this.http.post<DataExchangeResult>(
      `${this.apiUrl}/import`,
      { reason },
      { params }
    );
  }

  /**
   * Reviewer note: Centralises the result service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  result(token: string): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/results/${encodeURIComponent(token)}`, {
      responseType: 'blob'
    });
  }
}
