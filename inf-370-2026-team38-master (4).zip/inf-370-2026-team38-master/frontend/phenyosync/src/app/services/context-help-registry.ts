/** Maps current routes to the persisted context keys used by the central Help registry. */
const ROUTE_ALIASES: Readonly<Record<string, string>> = {
  '/reports/inventory': '/reports/inventory-availability',
  '/reports/sales': '/reports/sales-transactions',
  '/reports/financial': '/reports/financial-summary',
  '/reports/stock-movement': '/reports/stock-movements',
  '/reports/pricing': '/reports/pricing-management',
  '/reports/markup': '/reports/markup-analysis'
};

export function registeredHelpRoute(route: string): string {
  return ROUTE_ALIASES[route] ?? route;
}

/** Ensures every application page has a useful maintained Help destination. */
export function registeredHelpSlug(route: string): string | null {
  const path = route.split('?', 1)[0].replace(/\/$/, '') || '/';
  if (/^\/deliveries\/\d+\/(complete|proof)$/.test(path)) {
    return 'complete-delivery-proof';
  }
  const rules: ReadonlyArray<[string[], string]> = [
    [['/dashboard', '/workspace'], 'getting-started'],
    [['/access-denied'], 'permission-denied'],
    [['/account-security', '/profile'], 'trusted-devices'],
    [['/manage-users'], 'manage-users'],
    [['/manage-roles', '/manage-permissions'], 'roles-and-permissions'],
    [['/manage-lookups'], 'operational-lookups'],
    [['/manage-warehouse-sections'], 'warehouse-sections'],
    [['/manage-system-settings'], 'system-settings'],
    [['/manage-help', '/help'], 'getting-started'],
    [['/add-product', '/make-product'], 'product-production-lifecycle'],
    [['/product-hierarchy', '/manage-product-types', '/manage-product-categories'], 'product-types-categories'],
    [['/search-product', '/update-product', '/delete-product', '/update-product-status', '/products/'], 'search-update-products'],
    [['/product-data-exchange'], 'product-data-exchange'],
    [['/stock-count-data-exchange'], 'offline-data-exchange'],
    [['/raw-stock/approvals'], 'stock-take'],
    [['/raw-stock', '/buying-lists'], 'procurement-shortages'],
    [['/expiry-'], 'expiry-actions'],
    [['/customers', '/suppliers', '/payments'], 'customers-suppliers-payments'],
    [['/send-order-link'], 'order-links'],
    [['/create-order', '/validate-order'], 'create-validate-orders'],
    [['/order-management', '/search-orders', '/order-details/', '/update-order/', '/cancel-order/', '/update-order-status/'], 'order-status-cancel'],
    [['/view-pick-list', '/pack-customer-order', '/update-packing-status', '/order-invoice/'], 'packing-invoices'],
    [['/pricing'], 'pricing'],
    [['/reports'], 'formal-reports'],
    [['/audit-logs'], 'audit-logs'],
    [['/deliveries'], 'assign-drivers'],
    [['/my-deliveries'], 'my-deliveries'],
    [['/complete-delivery', '/delivery-proof'], 'complete-delivery-proof'],
    [['/scan-product-batch', '/mobile-operations-control'], 'mobile-scanning-and-tracking'],
    [['/operations-calendar'], 'getting-started']
  ];

  return rules.find(([prefixes]) => prefixes.some(prefix => path.startsWith(prefix)))?.[1] ??
    (path === '/login' ? 'login-and-otp' : path === '/reset-password' ? 'password-reset' : null);
}
