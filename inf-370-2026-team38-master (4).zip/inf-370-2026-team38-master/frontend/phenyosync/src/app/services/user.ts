/**
 * Reviewer guide: Centralises user HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})

/** Typed client for user administration and the current user's profile operations. */
export class UserService {

  private apiUrl = `${environment.apiUrl}/users`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) { }

  /**
   * Reviewer note: Centralises the get users service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getUsers() {
    return this.http.get(this.apiUrl);
  }
 
  /**
   * Reviewer note: Centralises the get users by role service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getUsersByRole(role: string) {
    return this.http.get(`${this.apiUrl}/role/${role}`);
  }

  /**
   * Reviewer note: Centralises the create user service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createUser(user: any) {
    return this.http.post(this.apiUrl, user);
  }

  /**
   * Reviewer note: Centralises the update user service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateUser(id: number, user: any) {

  return this.http.put(
    `${this.apiUrl}/${id}`,
    user
  );

}

   deleteUser(id: number) { 
    return this.http.delete(`${this.apiUrl}/${id}`); 
  }

}
