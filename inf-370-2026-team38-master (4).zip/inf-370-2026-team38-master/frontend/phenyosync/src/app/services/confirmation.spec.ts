/**
 * Reviewer guide: Verifies the confirmation frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TestBed } from '@angular/core/testing';
import { ConfirmationService } from './confirmation';

// Covers the confirmation behavior most likely to regress across permissions and workflow changes.
describe('ConfirmationService', () => {
  // Reviewer note: Guards the observable rule that returns the modal decision and trimmed reason.
  it('returns the modal decision and trimmed reason', async () => {
    TestBed.configureTestingModule({});
    const service = TestBed.inject(ConfirmationService);
    const result = service.ask({
      title: 'Deactivate user',
      message: 'This user will no longer be able to sign in.',
      reasonLabel: 'Reason',
      reasonRequired: true
    });

    service.complete(true, '  Account no longer required.  ');

    await expect(result).resolves.toEqual({
      confirmed: true,
      reason: 'Account no longer required.'
    });
    expect(service.current()).toBeNull();
  });
});
