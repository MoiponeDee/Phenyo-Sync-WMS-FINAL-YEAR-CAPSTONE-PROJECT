/**
 * Reviewer guide: Centralises order HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export type OrderStatus =
  | 'Submitted' | 'Approved' | 'Confirmed' | 'Packing' | 'Packed' | 'ReadyForDispatch'
  | 'OutForDelivery' | 'Delivered' | 'Rejected' | 'Cancelled';

export interface OrderItemRequest { productId: number; quantityUnits: number; notes?: string; }
export interface CreateOrderRequest {
  customerId: number;
  // Reviewer note: Defines the client-side input or request boundary before a narrow DTO reaches the API.
  // Client validation improves feedback; the backend validates business constraints independently.
  requestedDeliveryDateUtc?: string;
  deliveryAddress: string;
  billingAddress: string;
  notes?: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: OrderItemRequest[];
}
export interface UpdateOrderRequest extends CreateOrderRequest { rowVersion?: string; }
export interface OrderItem {
  salesOrderItemId: number; productId: number; productPriceId?: number; productName: string; productSize: string;
  quantityKg: number | null; unitPricePerKg: number | null; quantityUnits: number; sellingUnit: string;
  kilogramsPerUnit?: number; unitPrice: number; priceBasis: string; lineTotal: number; notes?: string;
}
export interface OrderReservation {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  orderStockReservationId: number; salesOrderItemId: number; productBatchId: number;
  productName: string; productSize: string; batchCode: string; batchQrValue: string;
  sectionId: number; sectionName: string; quantityReservedKg: number;
  packedAtUtc: string; effectiveExpiryAtUtc: string; status: string;
}
export interface OrderHistory {
  previousStatus?: string; newStatus: string; changedAtUtc: string; changedBy?: string; reason?: string;
}
export interface SalesOrderDetail {
  salesOrderId: number; orderNumber: string; customerId: number; customerNumber: string;
  customerName: string; customerEmail: string; orderDateUtc: string; requestedDeliveryDateUtc?: string;
  deliveryAddress: string; billingAddress: string; status: OrderStatus; validationStatus: string;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  validationMessage?: string; subtotal: number; taxRatePercent: number; taxAmount: number; totalAmount: number; notes?: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string; invoiceId?: number; items: OrderItem[]; reservations: OrderReservation[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  statusHistory: OrderHistory[];
}
export interface SalesOrderSummary {
  salesOrderId: number; orderNumber: string; customerName: string; customerEmail: string;
  orderDateUtc: string; requestedDeliveryDateUtc?: string; status: OrderStatus; validationStatus: string;
  itemCount: number; totalAmount: number; hasInvoice: boolean; canUpdate: boolean; canValidate: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canCancel: boolean; canViewPackingList: boolean;
}
export interface PagedOrders { items: SalesOrderSummary[]; page: number; pageSize: number; totalCount: number; totalPages: number; }
export interface OrderSearchFilters {
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  searchTerm?: string; status?: string; validationStatus?: string; fromDateUtc?: string; toDateUtc?: string;
  deliveryFromUtc?: string; deliveryToUtc?: string; page?: number; pageSize?: number;
}
export interface OrderShortage {
  productId: number; productName: string; requestedQuantityKg: number; availableQuantityKg: number; shortageQuantityKg: number;
}
export interface ValidationResult { message: string; approved: boolean; shortages: OrderShortage[]; reservations: OrderReservation[]; }
export interface Invoice {
  invoiceId: number; invoiceNumber: string; orderNumber: string; issuedAtUtc: string;
  customerName: string; customerEmail: string; billingAddress: string; subtotal: number;
  taxAmount: number; totalAmount: number; invoiceStatus: string; orderStatus: string; items: OrderItem[];
}
export interface PackingList {
  salesOrderId: number; orderNumber: string; customerName: string; deliveryAddress: string;
  // Reviewer note: Defines the client-side input or request boundary before a narrow DTO reaches the API.
  // Client validation improves feedback; the backend validates business constraints independently.
  requestedDeliveryDateUtc?: string; status: OrderStatus; lines: PackingWorkloadLine[]; allocations: OrderReservation[];
}
export interface PackingWorkloadLine {
  salesOrderItemId: number; productName: string; productSize: string;
  orderedQuantityUnits: number; sellingUnit: string; requiredQuantityKg?: number;
  availableQuantityKg: number; packedQuantityKg: number; remainingQuantityKg?: number;
}
export interface CustomerOrderIntakeConfiguration {
  // Reviewer note: Defines the client-side input or request boundary before a narrow DTO reaches the API.
  // Client validation improves feedback; the backend validates business constraints independently.
  googleFormUrl: string;
  isConfigured: boolean;
  guidance: string;
}
export interface ExternalOrderSubmission {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  externalOrderSubmissionId: number;
  source: string;
  externalSourceKey: string;
  status: 'Processing' | 'Imported' | 'NeedsAttention' | 'Failed';
  safeIssueSummary?: string;
  submittedAtUtc?: string;
  importedAtUtc: string;
  salesOrderId?: number;
  orderNumber?: string;
}
export interface GoogleOrderSyncResult {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  rowsRead: number;
  imported: number;
  skippedAsDuplicate: number;
  needsAttention: number;
  failed: number;
  syncedAtUtc: string;
  submissions: ExternalOrderSubmission[];
}

@Injectable({ providedIn: 'root' })
/** Typed HTTP boundary for order lifecycle, fulfilment documents and external intake. */
export class OrderService {
  private readonly orderUrl = `${environment.apiUrl}/orders`;
  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the create service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  create(request: CreateOrderRequest): Observable<{ message: string; order: SalesOrderDetail }> {
    return this.http.post<{ message: string; order: SalesOrderDetail }>(this.orderUrl, request);
  }
  /**
   * Reviewer note: Centralises the update service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  update(id: number, request: UpdateOrderRequest): Observable<{ message: string; order: SalesOrderDetail }> {
    return this.http.put<{ message: string; order: SalesOrderDetail }>(`${this.orderUrl}/${id}`, request);
  }
  /**
   * Reviewer note: Centralises the get service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  get(id: number): Observable<SalesOrderDetail> { return this.http.get<SalesOrderDetail>(`${this.orderUrl}/${id}`); }
  /**
   * Reviewer note: Centralises the search service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  search(filters: OrderSearchFilters): Observable<PagedOrders> {
    let params = new HttpParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && `${value}`.trim()) params = params.set(key, `${value}`);
    });
    return this.http.get<PagedOrders>(`${this.orderUrl}/search`, { params });
  }
  /**
   * Reviewer note: Centralises the validate service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  validate(id: number): Observable<ValidationResult> {
    // Validation is server-side: clients never infer approval from displayed stock figures.
    return this.http.post<ValidationResult>(`${this.orderUrl}/${id}/validate`, {});
  }
  /**
   * Reviewer note: Centralises the approve service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  approve(id: number, reason: string): Observable<{ message: string; order: SalesOrderDetail }> {
    return this.http.post<{ message: string; order: SalesOrderDetail }>(
      `${this.orderUrl}/${id}/approve`,
      { reason }
    );
  }
  /**
   * Reviewer note: Centralises the reject service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  reject(id: number, reason: string): Observable<{ message: string; order: SalesOrderDetail }> {
    return this.http.post<{ message: string; order: SalesOrderDetail }>(
      `${this.orderUrl}/${id}/reject`,
      { reason }
    );
  }
  /**
   * Reviewer note: Centralises the confirm warehouse ready service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  confirmWarehouseReady(
    id: number,
    reason: string
  ): Observable<{ message: string; order: SalesOrderDetail }> {
    return this.http.post<{
      message: string;
      order: SalesOrderDetail;
    }>(`${this.orderUrl}/${id}/warehouse-ready`, { reason });
  }
  /**
   * Reviewer note: Calculates cancel for client presentation and routing.
   * This result improves UX but never substitutes for the backend permission check.
   */
  cancel(id: number, reason: string, confirmationText: string): Observable<{ message: string; order: SalesOrderDetail }> {
    return this.http.post<{ message: string; order: SalesOrderDetail }>(`${this.orderUrl}/${id}/cancel`, {
      reason, confirmationText, confirmed: true
    });
  }
  /**
   * Reviewer note: Centralises the update status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateStatus(id: number, newStatus: OrderStatus, reason?: string): Observable<{ message: string; order: SalesOrderDetail }> {
    return this.http.patch<{ message: string; order: SalesOrderDetail }>(`${this.orderUrl}/${id}/status`, { newStatus, reason });
  }
  /**
   * Reviewer note: Centralises the get invoice service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getInvoice(id: number): Observable<Invoice> { return this.http.get<Invoice>(`${this.orderUrl}/${id}/invoice`); }
  /**
   * Reviewer note: Centralises the get packing queue service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getPackingQueue(searchTerm = ''): Observable<SalesOrderSummary[]> {
    const params = searchTerm.trim() ? new HttpParams().set('searchTerm', searchTerm.trim()) : undefined;
    return this.http.get<SalesOrderSummary[]>(`${this.orderUrl}/packing-list`, { params });
  }
  /**
   * Reviewer note: Centralises the get packing list service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getPackingList(id: number): Observable<PackingList> { return this.http.get<PackingList>(`${this.orderUrl}/${id}/packing-list`); }

  /**
   * Reviewer note: Centralises the get customer intake configuration service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getCustomerIntakeConfiguration(): Observable<CustomerOrderIntakeConfiguration> {
    return this.http.get<CustomerOrderIntakeConfiguration>(
      `${this.orderUrl}/customer-intake-configuration`
    );
  }

  /**
   * Reviewer note: Centralises the sync google form orders service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  syncGoogleFormOrders(): Observable<GoogleOrderSyncResult> {
    // The backend owns source authentication, exact product matching and idempotency.
    return this.http.post<GoogleOrderSyncResult>(
      `${environment.apiUrl}/google-order-intake/sync`,
      {}
    );
  }

  /**
   * Reviewer note: Centralises the recent external submissions service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  recentExternalSubmissions(take = 25): Observable<ExternalOrderSubmission[]> {
    return this.http.get<ExternalOrderSubmission[]>(
      `${environment.apiUrl}/google-order-intake/submissions`,
      { params: { take } }
    );
  }

}
