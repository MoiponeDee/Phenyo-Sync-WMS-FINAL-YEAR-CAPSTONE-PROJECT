/**
 * Reviewer guide: Centralises buying lists HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface BuyingListSummary {
  buyerProcurementId: number;
  referenceNumber: string;
  title?: string;
  buyingDateUtc: string;
  assignedBuyerUserId?: number;
  buyerName?: string;
  priority: string;
  status: string;
  itemCount: number;
  resolvedItemCount: number;
  requiredQuantity: number;
  purchasedQuantity: number;
  receivedQuantity: number;
  updatedAtUtc: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface BuyingListLine {
  buyerProcurementItemId: number;
  productId?: number;
  rawStockItemId?: number;
  itemCode: string;
  itemName: string;
  category: string;
  unitOfMeasure: string;
  currentStock: number;
  recommendedQuantity: number;
  requiredQuantity: number;
  actualQuantity?: number;
  actualUnitPrice?: number;
  receivedQuantity: number;
  outstandingQuantity: number;
  priority: string;
  preferredSupplierId?: number;
  preferredSupplierName?: string;
  supplierId?: number;
  supplierName?: string;
  status: string;
  isPromotionalItem: boolean;
  managementNotes?: string;
  buyerNotes?: string;
  unavailableReason?: string;
  substituteRawStockItemId?: number;
  substituteItemName?: string;
  substituteNotes?: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface BuyingListDetail extends BuyingListSummary {
  notes?: string;
  createdAtUtc: string;
  publishedAtUtc?: string;
  submittedAtUtc?: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  cancelledAtUtc?: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  cancellationReason?: string;
  createdByName?: string;
  docketStoredFileId?: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: BuyingListLine[];
}

export interface BuyingListSearchResult {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: BuyingListSummary[];
  page: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize: number;
  total: number;
}

export interface BuyingListOptions {
  statuses: Array<{ code: string; name: string }>;
  priorities: Array<{ code: string; name: string }>;
  buyers: Array<{ userId: number; displayName: string; email: string }>;
  rawStockItems: Array<{
    rawStockItemId: number;
    itemCode: string;
    itemName: string;
    categoryCode: string;
    unitOfMeasure: string;
    currentBalance: number;
  }>;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  suppliers: Array<{ supplierId: number; supplierName: string }>;
}

export interface BuyingListSearch {
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  search?: string;
  status?: string;
  assignedBuyerUserId?: number;
  fromDateUtc?: string;
  toDateUtc?: string;
  page?: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize?: number;
}

export interface BuyingListLineInput {
  productId?: number;
  rawStockItemId?: number;
  recommendedQuantity: number;
  requiredQuantity: number;
  unitOfMeasure: string;
  priority: string;
  preferredSupplierId?: number;
  managementNotes?: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion?: string;
}

export interface BuyingListInput {
  buyingDateUtc: string;
  title?: string;
  priority: string;
  notes?: string;
  assignedBuyerUserId?: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: BuyingListLineInput[];
}

export interface ProcurementDemandBreakdown {
  productId: number;
  productName: string;
  unfulfilledDemand: number;
  finishedStockAvailable: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  finishedProductShortage: number;
  rawQuantityPerProductUnit: number;
  wastePercentage: number;
  yieldPercentage: number;
  rawQuantityRequired: number;
}

export interface ProcurementShortageSuggestion {
  rawStockItemId: number;
  itemCode: string;
  itemName: string;
  unitOfMeasure: string;
  grossRawRequirement: number;
  usableRawStock: number;
  supplierOrderOutstanding: number;
  buyingListOutstanding: number;
  suggestedPurchaseQuantity: number;
  demandBreakdown: ProcurementDemandBreakdown[];
}

export interface UnmappedProductDemand {
  productId: number;
  productName: string;
  unfulfilledDemand: number;
  guidance: string;
}

export interface ProductRawStockRequirement {
  productRawStockRequirementId: number;
  productId: number;
  productName: string;
  rawStockItemId: number;
  rawStockItemCode: string;
  rawStockItemName: string;
  rawQuantityPerProductUnit: number;
  unitOfMeasure: string;
  wastePercentage: number;
  yieldPercentage: number;
  isActive: boolean;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

@Injectable({ providedIn: 'root' })
/** Typed client for management Buying Lists; lifecycle rules remain in the API. */
export class BuyingListService {
  private readonly base = `${environment.apiUrl}/buying-lists`;
  private readonly planningBase =
    `${environment.apiUrl}/procurement-planning`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private readonly http: HttpClient) {}

  /**
   * Reviewer note: Centralises the search service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  search(criteria: BuyingListSearch): Observable<BuyingListSearchResult> {
    let params = new HttpParams();
    for (const [key, value] of Object.entries(criteria)) {
      if (value !== undefined && value !== null && value !== '') {
        params = params.set(key, String(value));
      }
    }
    return this.http.get<BuyingListSearchResult>(this.base, { params });
  }

  /**
   * Reviewer note: Centralises the options service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  options(): Observable<BuyingListOptions> {
    return this.http.get<BuyingListOptions>(`${this.base}/options`);
  }

  /**
   * Reviewer note: Centralises the shortage suggestions service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  shortageSuggestions(): Observable<ProcurementShortageSuggestion[]> {
    return this.http.get<ProcurementShortageSuggestion[]>(
      `${this.planningBase}/shortages`
    );
  }

  /**
   * Reviewer note: Centralises the unmapped demand service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  unmappedDemand(): Observable<UnmappedProductDemand[]> {
    return this.http.get<UnmappedProductDemand[]>(
      `${this.planningBase}/unmapped-demand`
    );
  }

  /**
   * Reviewer note: Centralises the product requirements service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  productRequirements(
    productId: number,
    includeInactive = true
  ): Observable<ProductRawStockRequirement[]> {
    return this.http.get<ProductRawStockRequirement[]>(
      `${this.planningBase}/products/${productId}/requirements`,
      { params: new HttpParams().set('includeInactive', includeInactive) });
  }

  /**
   * Reviewer note: Centralises the save product requirement service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  saveProductRequirement(
    productId: number,
    requirementId: number | null,
    request: object
  ): Observable<ProductRawStockRequirement> {
    const url = `${this.planningBase}/products/${productId}/requirements`;
    return requirementId
      ? this.http.put<ProductRawStockRequirement>(
          `${url}/${requirementId}`,
          request)
      : this.http.post<ProductRawStockRequirement>(url, request);
  }

  /**
   * Reviewer note: Centralises the get service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  get(id: number): Observable<BuyingListDetail> {
    return this.http.get<BuyingListDetail>(`${this.base}/${id}`);
  }

  /**
   * Reviewer note: Centralises the create service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  create(request: BuyingListInput): Observable<BuyingListDetail> {
    return this.http.post<BuyingListDetail>(this.base, request);
  }

  /**
   * Reviewer note: Centralises the update header service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateHeader(
    id: number,
    request: Omit<BuyingListInput, 'assignedBuyerUserId' | 'items'> & {
      rowVersion: string;
    }
  ): Observable<BuyingListDetail> {
    return this.http.put<BuyingListDetail>(`${this.base}/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the add line service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  addLine(
    id: number,
    request: BuyingListLineInput
  ): Observable<BuyingListDetail> {
    return this.http.post<BuyingListDetail>(
      `${this.base}/${id}/items`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the update line service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateLine(
    id: number,
    lineId: number,
    request: BuyingListLineInput
  ): Observable<BuyingListDetail> {
    return this.http.put<BuyingListDetail>(
      `${this.base}/${id}/items/${lineId}`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the remove line service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  removeLine(
    id: number,
    lineId: number,
    rowVersion: string,
    reason: string
  ): Observable<BuyingListDetail> {
    return this.http.delete<BuyingListDetail>(
      `${this.base}/${id}/items/${lineId}`,
      { body: { rowVersion, reason } }
    );
  }

  /**
   * Reviewer note: Centralises the assign service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  assign(
    id: number,
    assignedBuyerUserId: number,
    rowVersion: string,
    reason: string
  ): Observable<BuyingListDetail> {
    return this.http.post<BuyingListDetail>(
      `${this.base}/${id}/assign`,
      { assignedBuyerUserId, rowVersion, reason }
    );
  }

  /**
   * Reviewer note: Centralises the publish service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  publish(
    id: number,
    rowVersion: string,
    reason: string
  ): Observable<BuyingListDetail> {
    return this.command(id, 'publish', rowVersion, reason);
  }

  /**
   * Reviewer note: Calculates cancel for client presentation and routing.
   * This result improves UX but never substitutes for the backend permission check.
   */
  cancel(
    id: number,
    rowVersion: string,
    reason: string
  ): Observable<BuyingListDetail> {
    return this.command(id, 'cancel', rowVersion, reason);
  }

  /**
   * Reviewer note: Centralises the command service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  private command(
    id: number,
    action: string,
    rowVersion: string,
    reason: string
  ): Observable<BuyingListDetail> {
    return this.http.post<BuyingListDetail>(
      `${this.base}/${id}/${action}`,
      { rowVersion, reason }
    );
  }
}
