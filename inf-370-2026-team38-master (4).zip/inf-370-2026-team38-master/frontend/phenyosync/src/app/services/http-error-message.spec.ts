import { HttpErrorResponse } from '@angular/common/http';
import { httpErrorMessage } from './http-error-message';

describe('httpErrorMessage', () => {
  it('surfaces field validation without exposing internal server failures', () => {
    expect(httpErrorMessage(new HttpErrorResponse({
      status: 400,
      error: { errors: { Email: ['Enter a valid email address.'] } }
    }))).toBe('Enter a valid email address.');

    expect(httpErrorMessage(new HttpErrorResponse({
      status: 500,
      error: { message: 'SqlException: secret connection details' }
    }))).toBe('The server could not complete the request. Try again, or contact support if it continues.');
  });

  it('maps authorization and missing records consistently', () => {
    expect(httpErrorMessage(new HttpErrorResponse({ status: 403 })))
      .toBe('You do not have permission to perform this action.');
    expect(httpErrorMessage(new HttpErrorResponse({ status: 404 })))
      .toBe('The requested record was not found.');
  });
});
