/**
 * Reviewer guide: Centralises notification HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { Injectable, signal } from '@angular/core';

export type NotificationKind = 'success' | 'error' | 'warning' | 'info';

export interface AppNotification {
  id: number;
  kind: NotificationKind;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  duration: number;
}

@Injectable({ providedIn: 'root' })
/** Loads and acknowledges the current user's operational notification inbox. */
export class NotificationService {
  private nextId = 1;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  readonly notifications = signal<AppNotification[]>([]);

  /**
   * Reviewer note: Centralises the success service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  success(message: string): void {
    this.show('success', message, 5000);
  }

  /**
   * Reviewer note: Centralises the error service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  error(message: string): void {
    this.show('error', message, 9000);
  }

  /**
   * Reviewer note: Centralises the warning service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  warning(message: string): void {
    this.show('warning', message, 7000);
  }

  /**
   * Reviewer note: Centralises the info service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  info(message: string): void {
    this.show('info', message, 5000);
  }

  /**
   * Reviewer note: Centralises the dismiss service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  dismiss(id: number): void {
    this.notifications.update(items => items.filter(item => item.id !== id));
  }

  /**
   * Reviewer note: Calculates show for client presentation and routing.
   * This result improves UX but never substitutes for the backend permission check.
   */
  private show(kind: NotificationKind, message: string, duration: number): void {
    const text = message.trim();
    if (!text) return;

    const duplicate = this.notifications().find(
      item => item.kind === kind && item.message === text
    );
    if (duplicate) return;

    const notification: AppNotification = {
      id: this.nextId++,
      kind,
      message: text,
      duration
    };
    this.notifications.update(items => [...items, notification]);
    window.setTimeout(() => this.dismiss(notification.id), duration);
  }
}
