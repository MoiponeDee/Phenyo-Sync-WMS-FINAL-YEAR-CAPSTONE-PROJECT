/**
 * Reviewer guide: Centralises product lookups HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export type LookupStatus = 'Active' | 'Inactive';

export interface ProductType {
  productTypeId: number;
  productTypeName: string;
  description?: string;
  status: LookupStatus;
  createdAt: string;
  updatedAt?: string;
}

export interface ProductCategory {
  productCategoryId: number;
  productCategoryName: string;
  description?: string;
  status: LookupStatus;
  createdAt: string;
  updatedAt?: string;
}

export interface WarehouseSection {
  sectionId: number;
  sectionName: string;
  description?: string;
  status: LookupStatus;
}

export interface SaveProductTypeRequest {
  productTypeName: string;
  description?: string;
  status: LookupStatus;
}

export interface SaveProductCategoryRequest {
  productCategoryName: string;
  description?: string;
  status: LookupStatus;
}

@Injectable({ providedIn: 'root' })
/** Supplies reusable active product/category/type choices from backend lookup endpoints. */
export class ProductLookupService {
  private readonly typeUrl = `${environment.apiUrl}/ProductType`;
  private readonly categoryUrl = `${environment.apiUrl}/ProductCategory`;
  private readonly sectionUrl = `${environment.apiUrl}/WarehouseSection`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the get product types service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getProductTypes(searchTerm = '', status = ''): Observable<ProductType[]> {
    return this.http.get<ProductType[]>(this.typeUrl, { params: this.filters(searchTerm, status) });
  }

  /**
   * Reviewer note: Centralises the get active product types service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getActiveProductTypes(): Observable<ProductType[]> {
    return this.http.get<ProductType[]>(`${this.typeUrl}/active`);
  }

  /**
   * Reviewer note: Centralises the create product type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createProductType(request: SaveProductTypeRequest): Observable<{ message: string; productTypeId: number }> {
    return this.http.post<{ message: string; productTypeId: number }>(this.typeUrl, request);
  }

  /**
   * Reviewer note: Centralises the update product type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateProductType(id: number, request: SaveProductTypeRequest): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.typeUrl}/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the delete product type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteProductType(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.typeUrl}/${id}`);
  }

  /**
   * Reviewer note: Centralises the get product categories service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getProductCategories(searchTerm = '', status = ''): Observable<ProductCategory[]> {
    return this.http.get<ProductCategory[]>(this.categoryUrl, { params: this.filters(searchTerm, status) });
  }

  /**
   * Reviewer note: Centralises the get active product categories service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getActiveProductCategories(): Observable<ProductCategory[]> {
    return this.http.get<ProductCategory[]>(`${this.categoryUrl}/active`);
  }

  /**
   * Reviewer note: Centralises the create product category service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createProductCategory(request: SaveProductCategoryRequest): Observable<{ message: string; productCategoryId: number }> {
    return this.http.post<{ message: string; productCategoryId: number }>(this.categoryUrl, request);
  }

  /**
   * Reviewer note: Centralises the update product category service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateProductCategory(id: number, request: SaveProductCategoryRequest): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.categoryUrl}/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the delete product category service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteProductCategory(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.categoryUrl}/${id}`);
  }

  /**
   * Reviewer note: Centralises the get active warehouse sections service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getActiveWarehouseSections(): Observable<WarehouseSection[]> {
    return this.http.get<WarehouseSection[]>(`${this.sectionUrl}/active`);
  }

  /**
   * Reviewer note: Centralises the filters service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  private filters(searchTerm: string, status: string): HttpParams {
    let params = new HttpParams();
    if (searchTerm.trim()) params = params.set('searchTerm', searchTerm.trim());
    if (status) params = params.set('status', status);
    return params;
  }
}
