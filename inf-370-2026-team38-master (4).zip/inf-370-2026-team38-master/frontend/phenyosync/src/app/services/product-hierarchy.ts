/**
 * Reviewer guide: Centralises product hierarchy HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface HierarchyProduct {
  productId: number;
  productCode: string;
  name: string;
  size: string;
  shelfLifeDays: number;
  status: 'Active' | 'Inactive';
  currentSellingPrice?: number;
  currentPriceBasis: 'PerKilogram' | 'PerSellableUnit';
  sellingUnit: string;
  kilogramsPerUnit?: number;
  isVariableWeight: boolean;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface HierarchyType {
  productCategoryTypeId: number;
  productTypeId: number;
  name: string;
  description?: string;
  status: 'Active' | 'Inactive';
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  products: HierarchyProduct[];
}

export interface HierarchyCategory {
  productCategoryId: number;
  name: string;
  description?: string;
  status: 'Active' | 'Inactive';
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  types: HierarchyType[];
}

export interface ProductHierarchyResponse {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  categories: HierarchyCategory[];
  categoryCount: number;
  typeCount: number;
  productCount: number;
}

export interface HierarchyMutationResponse {
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  productId?: number;
  productCategoryId?: number;
  productTypeId?: number;
}

@Injectable({ providedIn: 'root' })
/** Typed client for hierarchy views and governed category/type associations. */
export class ProductHierarchyService {
  private readonly apiUrl = `${environment.apiUrl}/product-hierarchy`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the get service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  get(search = '', includeInactive = false): Observable<ProductHierarchyResponse> {
    let params = new HttpParams().set('includeInactive', includeInactive);
    if (search.trim()) params = params.set('search', search.trim());
    return this.http.get<ProductHierarchyResponse>(this.apiUrl, { params });
  }

  /**
   * Reviewer note: Centralises the create category service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createCategory(request: Record<string, unknown>): Observable<HierarchyMutationResponse> {
    return this.http.post<HierarchyMutationResponse>(`${this.apiUrl}/categories`, request);
  }

  /**
   * Reviewer note: Centralises the update category service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateCategory(id: number, request: Record<string, unknown>): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.apiUrl}/categories/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the delete category service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteCategory(id: number, reason: string, rowVersion: string): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${this.apiUrl}/categories/${id}/delete`, {
      reason,
      rowVersion
    });
  }

  /**
   * Reviewer note: Centralises the create type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createType(categoryId: number, request: Record<string, unknown>): Observable<HierarchyMutationResponse> {
    return this.http.post<HierarchyMutationResponse>(
      `${this.apiUrl}/categories/${categoryId}/types`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the update type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateType(id: number, request: Record<string, unknown>): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.apiUrl}/types/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the move type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  moveType(
    associationId: number,
    targetCategoryId: number,
    reason: string,
    rowVersion: string
  ): Observable<HierarchyMutationResponse> {
    return this.http.post<HierarchyMutationResponse>(
      `${this.apiUrl}/associations/${associationId}/move`,
      { targetCategoryId, reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the delete type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteType(id: number, reason: string, rowVersion: string): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${this.apiUrl}/types/${id}/delete`, {
      reason,
      rowVersion
    });
  }

  /**
   * Reviewer note: Centralises the create product service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createProduct(
    categoryId: number,
    typeId: number,
    request: Record<string, unknown>
  ): Observable<HierarchyMutationResponse> {
    return this.http.post<HierarchyMutationResponse>(
      `${this.apiUrl}/categories/${categoryId}/types/${typeId}/products`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the reclassify product service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  reclassifyProduct(
    productId: number,
    request: Record<string, unknown>
  ): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(
      `${this.apiUrl}/products/${productId}/classification`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the change product status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changeProductStatus(
    productId: number,
    status: 'Active' | 'Inactive',
    reason: string,
    rowVersion: string
  ): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(
      `${this.apiUrl}/products/${productId}/status`,
      { status, reason, rowVersion }
    );
  }
}
