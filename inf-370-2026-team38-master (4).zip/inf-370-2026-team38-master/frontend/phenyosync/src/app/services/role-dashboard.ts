/**
 * Reviewer guide: Centralises role dashboard HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface DashboardMetric {
  label: string;
  value: number;
  valueKind: 'number' | 'currency' | 'kilograms' | 'percentage';
  detail: string;
  route?: string;
}

export interface DashboardPoint {
  label: string;
  value: number;
  count: number;
}

export interface DashboardChart {
  title: string;
  description: string;
  valueKind: DashboardMetric['valueKind'];
  points: DashboardPoint[];
}

export interface DashboardAttentionItem {
  label: string;
  value: number;
  detail: string;
  route: string;
  severity: 'info' | 'warning' | 'critical';
}

export interface DashboardActivity {
  auditLogId: number;
  occurredAtUtc: string;
  operationName: string;
  systemModule: string;
  entityDisplay?: string;
  actorDisplayName?: string;
  success: boolean;
}

export interface RoleDashboardData {
  roleCode: string;
  title: string;
  subtitle: string;
  fromUtc: string;
  toUtc: string;
  metrics: DashboardMetric[];
  barChart: DashboardChart;
  lineChart: DashboardChart;
  attentionItems: DashboardAttentionItem[];
  recentActivity: DashboardActivity[];
}

@Injectable({ providedIn: 'root' })
/** Loads permission-filtered dashboard cards rather than deriving access from role labels. */
export class RoleDashboardService {
  private readonly apiUrl = `${environment.apiUrl}/dashboards/me`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private readonly http: HttpClient) {}

  /**
   * Reviewer note: Centralises the load service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  load(fromUtc?: string, toUtc?: string): Observable<RoleDashboardData> {
    let params = new HttpParams();
    if (fromUtc) params = params.set('fromUtc', fromUtc);
    if (toUtc) params = params.set('toUtc', toUtc);
    return this.http.get<RoleDashboardData>(this.apiUrl, { params });
  }
}
