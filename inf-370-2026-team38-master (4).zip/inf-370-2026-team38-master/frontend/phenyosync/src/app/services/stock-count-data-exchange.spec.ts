import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { StockCountDataExchangeService } from './stock-count-data-exchange';

describe('StockCountDataExchangeService', () => {
  let service: StockCountDataExchangeService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(StockCountDataExchangeService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('downloads the active schema and matching sample from protected API endpoints', () => {
    service.schema().subscribe();
    const schema = http.expectOne(`${environment.apiUrl}/stock-count-data-exchange/json/schema`);
    expect(schema.request.responseType).toBe('blob');
    schema.flush(new Blob(['{}'], { type: 'application/json' }));

    service.sample().subscribe();
    const sample = http.expectOne(`${environment.apiUrl}/stock-count-data-exchange/json/sample`);
    expect(sample.request.responseType).toBe('blob');
    sample.flush(new Blob(['{}'], { type: 'application/json' }));
  });
});
