/**
 * Reviewer guide: Centralises product HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface CreateProductRequest {
  productId: number;
  quantityProducedKg: number;
  sectionId: number;
  packedAtUtc?: string;
}

export interface CreateProductResponse {
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  productCreated: boolean;
  productId: number;
  productCode: string;
  productBatchId: number;
  batchCode: string;
  qrCodeValue: string;
  quantityAddedKg: number;
  aggregateQuantityAvailableKg: number;
  packedAtUtc: string;
  effectiveExpiryAtUtc: string;
  packingConversionId: number;
  correlationId: string;
  rawStockQuantityConsumed: number;
}

export interface PackableRawStockRequirement {
  rawStockItemId: number;
  itemCode: string;
  itemName: string;
  unitOfMeasure: string;
  quantityPerProductUnit: number;
  adjustedQuantityPerProductUnit: number;
  availableQuantity: number;
}

export interface PackableProduct {
  productId: number;
  productCode: string;
  productName: string;
  size: string;
  shelfLifeDays: number;
  maximumPackableQuantity: number;
  requirements: PackableRawStockRequirement[];
}

export interface UpdateProductRequest {
  productName: string;
  productTypeId: number;
  productCategoryId: number;
  size: string;
  shelfLifeDays: number;
  status: 'Active' | 'Inactive';
}

export interface ProductResponse {
  productId: number;
  productName: string;
  productTypeId: number;
  productTypeName: string;
  productCategoryId: number;
  productCategoryName: string;
  size: string;
  shelfLifeDays: number;
  sellingPricePerKg: number;
  currentPriceBasis?: 'PerKilogram' | 'PerSellableUnit';
  sellingUnit?: string;
  kilogramsPerUnit?: number;
  isVariableWeight?: boolean;
  qrCodeValue?: string;
  status: 'Active' | 'Inactive';
  createdAt: string;
  updatedAt?: string;
  totalAvailableQuantityKg: number;
  nearestExpiryAtUtc?: string;
  alertLevel: 'Normal' | 'Warning' | 'Urgent' | 'Expired';
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canDelete: boolean;
  deleteBlockedReason?: string;
  isCommitted: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canDeactivate: boolean;
}

export interface ProductSearchFilters {
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  searchTerm?: string;
  productTypeId?: number | null;
  productCategoryId?: number | null;
  status?: string;
}

export interface ProductBatchResponse {
  productBatchId: number;
  productId: number;
  productName: string;
  batchCode: string;
  qrCodeValue: string;
  sectionId: number;
  sectionName: string;
  quantityProducedKg: number;
  quantityRemainingKg: number;
  packedAtUtc: string;
  originalExpiryAtUtc: string;
  effectiveExpiryAtUtc: string;
  status: string;
  shelfLifeExtended: boolean;
}

export interface DeleteProductResponse {
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  productId?: number;
  code?: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canDelete?: boolean;
  deleteBlockedReason?: string;
  isCommitted?: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canDeactivate?: boolean;
}

@Injectable({ providedIn: 'root' })
/** Typed client for the finished-product master and detail views. */
export class ProductService {
  private readonly apiUrl = `${environment.apiUrl}/Product`;
  private readonly batchUrl = `${environment.apiUrl}/ProductBatch`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the create product service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createProduct(request: CreateProductRequest): Observable<CreateProductResponse> {
    return this.http.post<CreateProductResponse>(this.apiUrl, request);
  }

  /**
   * Reviewer note: Centralises the get packable products service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getPackableProducts(sectionId: number): Observable<PackableProduct[]> {
    return this.http.get<PackableProduct[]>(`${this.apiUrl}/packable`, {
      params: { sectionId }
    });
  }

  /**
   * Reviewer note: Centralises the get products service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getProducts(): Observable<ProductResponse[]> {
    return this.http.get<ProductResponse[]>(this.apiUrl);
  }

  /**
   * Reviewer note: Centralises the get product by id service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getProductById(id: number): Observable<ProductResponse> {
    return this.http.get<ProductResponse>(`${this.apiUrl}/${id}`);
  }

  /**
   * Reviewer note: Centralises the search products service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  searchProducts(filters: ProductSearchFilters): Observable<ProductResponse[]> {
    let params = new HttpParams();
    if (filters.searchTerm?.trim()) params = params.set('searchTerm', filters.searchTerm.trim());
    if (filters.productTypeId != null) params = params.set('productTypeId', filters.productTypeId);
    if (filters.productCategoryId != null) params = params.set('productCategoryId', filters.productCategoryId);
    if (filters.status?.trim()) params = params.set('status', filters.status.trim());
    return this.http.get<ProductResponse[]>(`${this.apiUrl}/search`, { params });
  }

  /**
   * Reviewer note: Centralises the update product service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateProduct(id: number, request: UpdateProductRequest): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.apiUrl}/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the change product status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changeProductStatus(id: number, status: 'Active' | 'Inactive'): Observable<{ message: string }> {
    return this.http.patch<{ message: string }>(`${this.apiUrl}/${id}/status`, { status });
  }

  /**
   * Reviewer note: Centralises the delete product service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteProduct(id: number): Observable<DeleteProductResponse> {
    return this.http.delete<DeleteProductResponse>(`${this.apiUrl}/${id}`);
  }

  /**
   * Reviewer note: Centralises the get product qr code service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getProductQrCode(id: number): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/${id}/qr-code`, { responseType: 'blob' });
  }

  /**
   * Reviewer note: Centralises the get product batches service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getProductBatches(productId?: number): Observable<ProductBatchResponse[]> {
    const params = productId == null ? undefined : new HttpParams().set('productId', productId);
    return this.http.get<ProductBatchResponse[]>(this.batchUrl, { params });
  }

  /**
   * Reviewer note: Centralises the get batch qr code service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getBatchQrCode(id: number): Observable<Blob> {
    return this.http.get(`${this.batchUrl}/${id}/qr-code`, { responseType: 'blob' });
  }
}
