/**
 * Reviewer guide: Centralises product batch scanner HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface ProductBatchScanResult {
  productBatchId: number;
  productId: number;
  productCode: string;
  productName: string;
  categoryName: string;
  productTypeName: string;
  batchCode: string;
  qrSummary: string;
  packedAtUtc: string;
  effectiveExpiryAtUtc: string;
  expiryRisk: string;
  batchStatus: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  productStatus: string;
  availableQuantityKg: number;
  warehouseSectionId: number;
  warehouseSectionName: string;
}

@Injectable({ providedIn: 'root' })
/** Resolves scanned or manually entered batch codes through the same API validation. */
export class ProductBatchScannerService {
  private readonly apiUrl = `${environment.apiUrl}/product-batches/resolve-qr`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Transforms resolve at the DTO boundary so callers receive a consistent representation.
   * The conversion does not make the client authoritative for persisted business data.
   */
  resolve(value: string): Observable<ProductBatchScanResult> {
    return this.http.get<ProductBatchScanResult>(this.apiUrl, {
      params: new HttpParams().set('value', value)
    });
  }
}
