/**
 * Reviewer guide: Centralises stock count data exchange HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  DataExchangeResult,
  DataExchangeValidation
} from './product-data-exchange';

@Injectable({ providedIn: 'root' })
/** Implements the validate-then-apply workflow for offline stock-count files. */
export class StockCountDataExchangeService {
  private readonly apiUrl = `${environment.apiUrl}/stock-count-data-exchange/json`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  schema(): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/schema`, { responseType: 'blob' });
  }

  sample(): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/sample`, { responseType: 'blob' });
  }

  /**
   * Reviewer note: Centralises the export service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  export(filters: {
    warehouseSectionId: number;
    productCategoryId?: number | null;
    productTypeId?: number | null;
    activeProductsOnly: boolean;
    includeExpectedQuantities: boolean;
  }): Observable<Blob> {
    let params = new HttpParams()
      .set('warehouseSectionId', filters.warehouseSectionId)
      .set('activeProductsOnly', filters.activeProductsOnly)
      .set('includeExpectedQuantities', filters.includeExpectedQuantities);
    if (filters.productCategoryId) {
      params = params.set('productCategoryId', filters.productCategoryId);
    }
    if (filters.productTypeId) {
      params = params.set('productTypeId', filters.productTypeId);
    }
    return this.http.get(`${this.apiUrl}/export`, { params, responseType: 'blob' });
  }

  /**
   * Reviewer note: Centralises the validate service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  validate(file: File): Observable<DataExchangeValidation> {
    const form = new FormData();
    form.append('file', file, file.name);
    return this.http.post<DataExchangeValidation>(`${this.apiUrl}/validate`, form);
  }

  /**
   * Reviewer note: Centralises the import service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  import(validationToken: string, reason: string): Observable<DataExchangeResult> {
    return this.http.post<DataExchangeResult>(
      `${this.apiUrl}/import`,
      { reason },
      { params: new HttpParams().set('validationToken', validationToken) }
    );
  }

  /**
   * Reviewer note: Centralises the result service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  result(token: string): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/results/${encodeURIComponent(token)}`, {
      responseType: 'blob'
    });
  }
}
