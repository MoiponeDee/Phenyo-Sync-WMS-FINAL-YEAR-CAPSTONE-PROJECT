/**
 * Reviewer guide: Verifies the audit log frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { AuditLogService } from './audit-log';

// Covers the audit log behavior most likely to regress across permissions and workflow changes.
describe('AuditLogService', () => {
  let service: AuditLogService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(AuditLogService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that serializes only submitted search filters.
  it('serializes only submitted search filters', () => {
    service.search({
      actionType: 'Update',
      systemModule: 'Pricing',
      success: false,
      pageNumber: 2,
      pageSize: 25
    }).subscribe();

    const request = http.expectOne(item =>
      item.url === `${environment.apiUrl}/audit-logs`);
    expect(request.request.params.get('actionType')).toBe('Update');
    expect(request.request.params.get('systemModule')).toBe('Pricing');
    expect(request.request.params.get('success')).toBe('false');
    expect(request.request.params.get('pageNumber')).toBe('2');
    expect(request.request.params.has('userSearch')).toBe(false);
    request.flush({
      items: [],
      pageNumber: 2,
      pageSize: 25,
      totalCount: 0,
      totalPages: 0,
      hasPreviousPage: true,
      hasNextPage: false
    });
  });

  // Reviewer note: Guards the observable rule that exposes read-only metadata and detail requests.
  it('exposes read-only metadata and detail requests', () => {
    service.metadata().subscribe();
    http.expectOne(`${environment.apiUrl}/audit-logs/metadata`).flush({
      actionTypes: [],
      systemModules: [],
      entityTypes: [],
      users: []
    });

    service.get(42).subscribe();
    http.expectOne(`${environment.apiUrl}/audit-logs/42`).flush({
      auditLogId: 42,
      occurredAtUtc: new Date().toISOString(),
      actorType: 'System',
      actionType: 'Create',
      systemModule: 'ProductManagement',
      operationName: 'CreateProduct',
      description: 'Created product',
      success: true,
      correlationId: 'test',
      eventSource: 'EntityChange',
      relatedLogs: []
    });
  });
});
