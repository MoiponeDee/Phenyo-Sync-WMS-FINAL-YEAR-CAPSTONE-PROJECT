/**
 * Reviewer guide: Verifies the formal reports frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { FormalReportsService } from './formal-reports';

// Covers the formal reports behavior most likely to regress across permissions and workflow changes.
describe('FormalReportsService', () => {
  let service: FormalReportsService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(FormalReportsService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that loads server-backed report criteria options.
  it('loads server-backed report criteria options', () => {
    service.options().subscribe();

    const pending = http.expectOne(`${environment.apiUrl}/reports/options`);
    expect(pending.request.method).toBe('GET');
    pending.flush({ products: [], productCategories: [] });
  });

  // Reviewer note: Guards the observable rule that posts selected criteria to the requested preview endpoint.
  it('posts selected criteria to the requested preview endpoint', () => {
    service.preview('sales', {
      fromUtc: '2026-01-01',
      toUtc: '2026-08-01',
      customerId: 14
    }).subscribe();

    const pending = http.expectOne(
      `${environment.apiUrl}/reports/sales/preview`
    );
    expect(pending.request.method).toBe('POST');
    expect(pending.request.body).toEqual({
      fromUtc: '2026-01-01',
      toUtc: '2026-08-01',
      customerId: 14
    });
    pending.flush({ metadata: {} });
  });

  // Reviewer note: Guards the observable rule that uses the reviewed preview token for binary PDF export.
  it('uses the reviewed preview token for binary PDF export', () => {
    service.pdf('inventory', 'reviewed-token').subscribe();

    const pending = http.expectOne(
      `${environment.apiUrl}/reports/inventory/pdf`
    );
    expect(pending.request.method).toBe('POST');
    expect(pending.request.body).toEqual({
      previewToken: 'reviewed-token'
    });
    expect(pending.request.responseType).toBe('blob');
    pending.flush(new Blob(['%PDF'], { type: 'application/pdf' }));
  });
});
