/**
 * Reviewer guide: Verifies the configuration admin frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { ConfigurationAdminService } from './configuration-admin';

// Covers the configuration admin behavior most likely to regress across permissions and workflow changes.
describe('ConfigurationAdminService', () => {
  let service: ConfigurationAdminService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(ConfigurationAdminService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that searches lookup types with server-side filters.
  it('searches lookup types with server-side filters', () => {
    service.lookupTypes({ search: 'reason', isActive: true, pageSize: 50 }).subscribe();

    const request = http.expectOne(value =>
      value.url === `${environment.apiUrl}/lookups/types`);
    expect(request.request.params.get('search')).toBe('reason');
    expect(request.request.params.get('isActive')).toBe('true');
    expect(request.request.params.get('pageSize')).toBe('50');
    request.flush({ items: [], page: 1, pageSize: 50, total: 0, totalPages: 0 });
  });

  // Reviewer note: Guards the observable rule that requests only active lookup values for operational forms.
  it('requests only active lookup values for operational forms', () => {
    service.activeValues('ORDER_CANCELLATION_REASON').subscribe();

    const request = http.expectOne(
      `${environment.apiUrl}/lookups/types/ORDER_CANCELLATION_REASON/active-values`
    );
    expect(request.request.method).toBe('GET');
    request.flush([]);
  });

  // Reviewer note: Guards the observable rule that updates a setting with reason and row version.
  it('updates a setting with reason and row version', () => {
    service.updateSetting(
      'Expiry.YellowThresholdHours',
      '96',
      'Seasonal operations',
      'row-version'
    ).subscribe();

    const request = http.expectOne(
      `${environment.apiUrl}/system-settings/Expiry.YellowThresholdHours`
    );
    expect(request.request.method).toBe('PUT');
    expect(request.request.body).toEqual({
      value: '96',
      reason: 'Seasonal operations',
      rowVersion: 'row-version'
    });
    request.flush({ message: 'Updated.', appliedImmediately: true });
  });

  // Reviewer note: Guards the observable rule that sends concurrency data for warehouse-section status changes.
  it('sends concurrency data for warehouse-section status changes', () => {
    service.changeWarehouseSectionStatus(
      4,
      false,
      'Maintenance',
      'version'
    ).subscribe();

    const request = http.expectOne(
      `${environment.apiUrl}/WarehouseSection/4/status`
    );
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({
      isActive: false,
      reason: 'Maintenance',
      rowVersion: 'version'
    });
    request.flush({ message: 'Updated.' });
  });

  // Reviewer note: Guards the observable rule that does not send empty search parameters.
  it('does not send empty search parameters', () => {
    service.settings('', '').subscribe();

    const request = http.expectOne(`${environment.apiUrl}/system-settings`);
    expect(request.request.params.keys()).toEqual([]);
    request.flush([]);
  });
});
