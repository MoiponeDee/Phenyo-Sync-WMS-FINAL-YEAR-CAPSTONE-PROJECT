/**
 * Reviewer guide: Verifies the authorization frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { AuthorizationService } from './authorization';

// Covers the authorization behavior most likely to regress across permissions and workflow changes.
describe('AuthorizationService', () => {
  let service: AuthorizationService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(AuthorizationService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    http.verify();
    localStorage.removeItem('role');
  });

  // Reviewer note: Guards the observable rule that loads and evaluates database-issued permissions.
  it('loads and evaluates database-issued permissions', () => {
    let loaded = false;
    service.ensureLoaded().subscribe(() => loaded = true);

    http.expectOne(`${environment.apiUrl}/users/me/permissions`).flush({
      userId: 1,
      email: 'manager@example.test',
      role: 'Business Manager',
      roleCode: 'BusinessManager',
      isActive: true,
      permissions: [{
        permissionId: 7,
        code: 'Roles.AssignPermissions',
        displayName: 'Assign role permissions',
        module: 'Security'
      }]
    });

    expect(loaded).toBe(true);
    expect(service.has('Roles.AssignPermissions')).toBe(true);
    expect(service.has('Pricing.Manage')).toBe(false);
    expect(localStorage.getItem('role')).toBe('BusinessManager');
  });

  // Reviewer note: Guards the observable rule that clears the in-memory authorization session.
  it('clears the in-memory authorization session', () => {
    service.session.set({
      userId: 1,
      email: 'driver@example.test',
      role: 'Driver',
      roleCode: 'Driver',
      isActive: true,
      permissions: []
    });

    service.clear();

    expect(service.session()).toBeNull();
  });

  // Reviewer note: Guards the observable rule that refreshes effective permissions even when a session is cached.
  it('refreshes effective permissions even when a session is cached', () => {
    service.session.set({
      userId: 1,
      email: 'manager@example.test',
      role: 'Business Manager',
      roleCode: 'BusinessManager',
      isActive: true,
      permissions: []
    });

    service.refresh().subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/users/me/permissions`);
    expect(request.request.method).toBe('GET');
    request.flush({
      userId: 1,
      email: 'manager@example.test',
      role: 'Business Manager',
      roleCode: 'BusinessManager',
      isActive: true,
      permissions: [{
        permissionId: 9,
        code: 'Customers.Manage',
        displayName: 'Manage customers',
        module: 'Customers'
      }]
    });

    expect(service.has('Customers.Manage')).toBe(true);
  });
});
