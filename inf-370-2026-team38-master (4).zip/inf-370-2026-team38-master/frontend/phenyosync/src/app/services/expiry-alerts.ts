/**
 * Reviewer guide: Centralises expiry alerts HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export type ExpiryAlertLevel = 'Warning' | 'Urgent' | 'Expired';

export interface ExpiryAlert {
  productBatchId: number;
  productId: number;
  productName: string;
  productCategoryName: string;
  batchCode: string;
  sectionName: string;
  quantityRemainingKg: number;
  packedAtUtc: string;
  effectiveExpiryAtUtc: string;
  remainingHours: number;
  alertLevel: ExpiryAlertLevel;
  batchStatus: string;
  shelfLifeExtended: boolean;
}

export interface ExpiryAlertSummary {
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  warningCount: number;
  urgentCount: number;
  expiredCount: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  batches: ExpiryAlert[];
}

export interface ExpiryActionReview extends ExpiryAlert {
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canExtend: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canWriteOff: boolean;
  shelfLifeExtensionDays: number;
  // Reviewer note: Keeps sensitive authentication state within the session or authentication boundary.
  // Possession of a client value never bypasses backend verification.
  tokenExpiresAtUtc: string;
}

export interface ExpiryFilters {
  level?: string;
  productId?: number | null;
  categoryId?: number | null;
  sectionId?: number | null;
}

@Injectable({ providedIn: 'root' })
/** Loads expiry work queues and submits controlled batch decisions. */
export class ExpiryAlertService {
  private readonly apiUrl = `${environment.apiUrl}/expiry-alerts`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the get alerts service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getAlerts(filters: ExpiryFilters = {}): Observable<ExpiryAlertSummary> {
    let params = new HttpParams();
    if (filters.level) params = params.set('level', filters.level);
    if (filters.productId != null) params = params.set('productId', filters.productId);
    if (filters.categoryId != null) params = params.set('categoryId', filters.categoryId);
    if (filters.sectionId != null) params = params.set('sectionId', filters.sectionId);
    return this.http.get<ExpiryAlertSummary>(this.apiUrl, { params });
  }

  /**
   * Reviewer note: Centralises the run scan service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  runScan(): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${this.apiUrl}/run-scan`, {});
  }

  /**
   * Reviewer note: Centralises the get action review service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getActionReview(token: string): Observable<ExpiryActionReview> {
    return this.http.get<ExpiryActionReview>(`${this.apiUrl}/action`, {
      params: new HttpParams().set('token', token)
    });
  }

  /**
   * Reviewer note: Centralises the write off service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  writeOff(token: string, reason: string): Observable<{ message: string }> {
    return this.decision('write-off', token, reason);
  }

  /**
   * Reviewer note: Centralises the extend service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  extend(token: string, reason: string, newExpiryAtUtc: string): Observable<{ message: string }> {
    return this.decision('extend', token, reason, newExpiryAtUtc);
  }

  /**
   * Reviewer note: Centralises the decision service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  private decision(
    action: 'write-off' | 'extend',
    token: string,
    reason: string,
    newExpiryAtUtc?: string
  ): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.apiUrl}/action/${action}`,
      { reason, confirmed: true, newExpiryAtUtc },
      { params: new HttpParams().set('token', token) }
    );
  }
}
