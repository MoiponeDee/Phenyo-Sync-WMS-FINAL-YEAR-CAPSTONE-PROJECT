/**
 * Reviewer guide: Centralises auth HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface TwoFactorChallenge {
  requiresTwoFactor: true;
  // Reviewer note: Keeps sensitive authentication state within the session or authentication boundary.
  // Possession of a client value never bypasses backend verification.
  challengeToken: string;
  maskedDestination: string;
  expiresAtUtc: string;
  resendAfterSeconds: number;
  attemptsRemaining: number;
  emailDeliveryFailed?: boolean;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message?: string;
}

export interface AuthenticationResult {
  // Reviewer note: Keeps sensitive authentication state within the session or authentication boundary.
  // Possession of a client value never bypasses backend verification.
  token: string;
  userId: number;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  // Reviewer note: Keeps sensitive authentication state within the session or authentication boundary.
  // Possession of a client value never bypasses backend verification.
  recoveryCodes?: string[];
}

export interface TrustedDevice {
  trustedDeviceId: number;
  deviceName: string;
  userAgentSummary?: string;
  createdAtUtc: string;
  lastUsedAtUtc: string;
  expiresAtUtc: string;
  isCurrent: boolean;
}

export interface RecoveryCodeStatus {
  remainingCount: number;
  lastGeneratedAtUtc?: string;
}

export interface MyProfile {
  userId: number;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  phoneNumber?: string;
  roleCode: string;
  roleName: string;
  licenseNumber?: string;
  licenseExpiryDate?: string;
  vehicleAssigned?: string;
  availabilityStatus?: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

@Injectable({ providedIn: 'root' })
/** Owns browser authentication state and the forgot/reset-password API flow. */
export class AuthService {
  private readonly apiUrl = `${environment.apiUrl}/auth`;
  // Reviewer note: Reuses the credential option so secure session cookies accompany authentication calls.
  // The cookie remains browser-managed and is never treated as a client-side permission grant.
  private readonly credentials = { withCredentials: true };

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the login service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  login(data: {
    email: string;
    password: string;
  }): Observable<TwoFactorChallenge | AuthenticationResult> {
    return this.http.post<TwoFactorChallenge | AuthenticationResult>(
      `${this.apiUrl}/login`,
      {
        ...data,
        client: 'Web'
      },
      this.credentials
    );
  }

  /**
   * Reviewer note: Centralises the verify otp service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  verifyOtp(data: {
    challengeToken: string;
    otp: string;
    trustDevice: boolean;
    deviceName?: string;
  }): Observable<AuthenticationResult> {
    return this.http.post<AuthenticationResult>(
      `${this.apiUrl}/verify-otp`,
      data,
      this.credentials
    );
  }

  /**
   * Reviewer note: Centralises the verify recovery code service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  verifyRecoveryCode(data: {
    challengeToken: string;
    recoveryCode: string;
    trustDevice: boolean;
    deviceName?: string;
  }): Observable<AuthenticationResult> {
    return this.http.post<AuthenticationResult>(
      `${this.apiUrl}/verify-recovery-code`,
      data,
      this.credentials
    );
  }

  /**
   * Reviewer note: Centralises the resend otp service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  resendOtp(challengeToken: string): Observable<TwoFactorChallenge> {
    return this.http.post<TwoFactorChallenge>(
      `${this.apiUrl}/resend-otp`,
      { challengeToken },
      this.credentials
    );
  }

  /**
   * Reviewer note: Centralises the trusted devices service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  trustedDevices(): Observable<TrustedDevice[]> {
    return this.http.get<TrustedDevice[]>(
      `${this.apiUrl}/trusted-devices`,
      this.credentials
    );
  }

  /**
   * Reviewer note: Centralises the revoke trusted device service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  revokeTrustedDevice(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      `${this.apiUrl}/trusted-devices/${id}`,
      this.credentials
    );
  }

  /**
   * Reviewer note: Centralises the revoke all trusted devices service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  revokeAllTrustedDevices(): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      `${this.apiUrl}/trusted-devices`,
      this.credentials
    );
  }

  /**
   * Reviewer note: Centralises the recovery code status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  recoveryCodeStatus(): Observable<RecoveryCodeStatus> {
    return this.http.get<RecoveryCodeStatus>(
      `${this.apiUrl}/recovery-codes/status`
    );
  }

  /**
   * Reviewer note: Centralises the regenerate recovery codes service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  regenerateRecoveryCodes(currentPassword: string): Observable<{
    message: string;
    recoveryCodes: string[];
    status: RecoveryCodeStatus;
  }> {
    return this.http.post<{
      message: string;
      recoveryCodes: string[];
      status: RecoveryCodeStatus;
    }>(
      `${this.apiUrl}/recovery-codes/regenerate`,
      { currentPassword }
    );
  }

  /**
   * Reviewer note: Centralises the my profile service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  myProfile(): Observable<MyProfile> {
    return this.http.get<MyProfile>(`${this.apiUrl}/profile`);
  }

  /**
   * Reviewer note: Centralises the update my profile service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateMyProfile(request: {
    phoneNumber?: string | null;
    rowVersion: string;
  }): Observable<MyProfile> {
    return this.http.put<MyProfile>(`${this.apiUrl}/profile`, request);
  }

  /**
   * Reviewer note: Centralises the change password service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changePassword(request: {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
  }): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.apiUrl}/change-password`,
      request);
  }

  /**
   * Reviewer note: Centralises the forgot password service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  forgotPassword(email: string) {
    return this.http.post(
      `${this.apiUrl}/forgot-password`,
      { email }
    );
  }

  /**
   * Reviewer note: Centralises the reset password service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  resetPassword(data: {
    email: string;
    token: string;
    newPassword: string;
    confirmPassword: string;
  }) {
    return this.http.post(
      `${this.apiUrl}/reset-password`,
      data
    );
  }
}
