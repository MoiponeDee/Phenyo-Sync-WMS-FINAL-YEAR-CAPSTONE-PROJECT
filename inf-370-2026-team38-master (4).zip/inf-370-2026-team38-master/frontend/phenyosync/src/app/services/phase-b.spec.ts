/**
 * Reviewer guide: Verifies the phase b frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { OperationsCalendarService } from './operations-calendar';
import { ProductBatchScannerService } from './product-batch-scanner';
import { ProductDataExchangeService } from './product-data-exchange';
import { ProductHierarchyService } from './product-hierarchy';
import { StockCountDataExchangeService } from './stock-count-data-exchange';

// Verifies hierarchy, QR and exchange clients call the intended protected API boundaries.
describe('Phase B API services', () => {
  let http: HttpTestingController;
  let hierarchy: ProductHierarchyService;
  let excel: ProductDataExchangeService;
  let stockCount: StockCountDataExchangeService;
  let calendar: OperationsCalendarService;
  let scanner: ProductBatchScannerService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    http = TestBed.inject(HttpTestingController);
    hierarchy = TestBed.inject(ProductHierarchyService);
    excel = TestBed.inject(ProductDataExchangeService);
    stockCount = TestBed.inject(StockCountDataExchangeService);
    calendar = TestBed.inject(OperationsCalendarService);
    scanner = TestBed.inject(ProductBatchScannerService);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that queries the hierarchy with server-side search and inactive filtering.
  it('queries the hierarchy with server-side search and inactive filtering', () => {
    hierarchy.get('carrot', true).subscribe();
    const request = http.expectOne(pending =>
      pending.url === `${environment.apiUrl}/product-hierarchy` &&
      pending.params.get('search') === 'carrot' &&
      pending.params.get('includeInactive') === 'true');
    expect(request.request.method).toBe('GET');
    request.flush({ categories: [], categoryCount: 0, typeCount: 0, productCount: 0 });
  });

  // Reviewer note: Guards the observable rule that sends structural reasons and concurrency tokens for hierarchy moves.
  it('sends structural reasons and concurrency tokens for hierarchy moves', () => {
    hierarchy.moveType(11, 4, 'Catalogue correction', 'row-version').subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/product-hierarchy/associations/11/move`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({
      targetCategoryId: 4,
      reason: 'Catalogue correction',
      rowVersion: 'row-version'
    });
    request.flush({ message: 'Moved' });
  });

  // Reviewer note: Guards the observable rule that uploads a workbook as multipart data for validation.
  it('uploads a workbook as multipart data for validation', () => {
    const file = new File(['PK'], 'products.xlsx', {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
    excel.validate(file).subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/product-data-exchange/excel/validate`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body instanceof FormData).toBe(true);
    const uploaded = (request.request.body as FormData).get('file') as File;
    expect(uploaded.name).toBe(file.name);
    expect(uploaded.type).toBe(file.type);
    request.flush({
      validationToken: 'token',
      expiresAtUtc: new Date().toISOString(),
      totalRows: 1,
      validRows: 1,
      warningRows: 0,
      invalidRows: 0,
      rows: []
    });
  });

  // Reviewer note: Guards the observable rule that applies the exact staged Excel token with a business reason.
  it('applies the exact staged Excel token with a business reason', () => {
    excel.import('validated-token', 'Annual catalogue update').subscribe();
    const request = http.expectOne(pending =>
      pending.url === `${environment.apiUrl}/product-data-exchange/excel/import` &&
      pending.params.get('validationToken') === 'validated-token');
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({ reason: 'Annual catalogue update' });
    request.flush({
      message: 'Applied',
      resultToken: 'result',
      createdCount: 1,
      updatedCount: 2,
      adjustmentCount: 0,
      correlationId: 'correlation'
    });
  });

  // Reviewer note: Guards the observable rule that exports stock-count JSON using warehouse and product filters.
  it('exports stock-count JSON using warehouse and product filters', () => {
    stockCount.export({
      warehouseSectionId: 3,
      productCategoryId: 7,
      productTypeId: 8,
      activeProductsOnly: true,
      includeExpectedQuantities: true
    }).subscribe();
    const request = http.expectOne(pending =>
      pending.url === `${environment.apiUrl}/stock-count-data-exchange/json/export` &&
      pending.params.get('warehouseSectionId') === '3' &&
      pending.params.get('productCategoryId') === '7' &&
      pending.params.get('productTypeId') === '8');
    expect(request.request.method).toBe('GET');
    expect(request.request.responseType).toBe('blob');
    request.flush(new Blob(['{}'], { type: 'application/json' }));
  });

  // Reviewer note: Guards the observable rule that queries only the requested calendar range and active filters.
  it('queries only the requested calendar range and active filters', () => {
    calendar.events({
      startUtc: '2026-08-01T00:00:00.000Z',
      endUtc: '2026-09-01T00:00:00.000Z',
      eventType: 'Expiry',
      riskLevel: 'Urgent',
      customerId: null
    }).subscribe();
    const request = http.expectOne(pending =>
      pending.url === `${environment.apiUrl}/operations-calendar/events` &&
      pending.params.get('startUtc') === '2026-08-01T00:00:00.000Z' &&
      pending.params.get('endUtc') === '2026-09-01T00:00:00.000Z' &&
      pending.params.get('eventType') === 'Expiry' &&
      pending.params.get('riskLevel') === 'Urgent' &&
      !pending.params.has('customerId'));
    expect(request.request.method).toBe('GET');
    request.flush({
      startUtc: '2026-08-01T00:00:00.000Z',
      endUtc: '2026-09-01T00:00:00.000Z',
      defaultView: 'month',
      events: []
    });
  });

  // Reviewer note: Guards the observable rule that resolves a scanned QR value without mutating stock.
  it('resolves a scanned QR value without mutating stock', () => {
    scanner.resolve('PHENYOSYNC:BATCH:B-001').subscribe();
    const request = http.expectOne(pending =>
      pending.url === `${environment.apiUrl}/product-batches/resolve-qr` &&
      pending.params.get('value') === 'PHENYOSYNC:BATCH:B-001');
    expect(request.request.method).toBe('GET');
    expect(request.request.body).toBeNull();
    request.flush({
      productBatchId: 1,
      productId: 2,
      productCode: 'P-2',
      productName: 'Carrots',
      categoryName: 'Vegetables',
      productTypeName: 'Root',
      batchCode: 'B-001',
      qrSummary: 'PHENYOSYNC:BATCH:B-001',
      packedAtUtc: new Date().toISOString(),
      effectiveExpiryAtUtc: new Date().toISOString(),
      expiryRisk: 'Normal',
      batchStatus: 'Available',
      productStatus: 'Active',
      availableQuantityKg: 10,
      warehouseSectionId: 1,
      warehouseSectionName: 'Cold room'
    });
  });
});
