/**
 * Reviewer guide: Centralises configuration admin HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface LookupTypeSummary {
  lookupTypeId: number;
  systemCode: string;
  displayName: string;
  description?: string;
  isSystemType: boolean;
  isActive: boolean;
  valueCount: number;
  activeValueCount: number;
  createdAtUtc: string;
  updatedAtUtc?: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface LookupValueSummary {
  lookupValueId: number;
  lookupTypeId: number;
  systemCode: string;
  displayName: string;
  description?: string;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  sortOrder: number;
  isSystemValue: boolean;
  isActive: boolean;
  createdAtUtc: string;
  updatedAtUtc?: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface LookupTypeDetail extends LookupTypeSummary {
  values: LookupValueSummary[];
  page: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface PageResult<T> {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: T[];
  page: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface LookupHistory {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  lookupValueHistoryId: number;
  changeType: string;
  beforeValuesJson?: string;
  afterValuesJson?: string;
  changedAtUtc: string;
  changedBy: string;
  reason: string;
  correlationId: string;
}

export interface WarehouseSectionRecord {
  sectionId: number;
  sectionCode: string;
  sectionName: string;
  description?: string;
  status: 'Active' | 'Inactive';
  createdAtUtc: string;
  updatedAtUtc?: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface SystemSettingRecord {
  systemSettingId: number;
  key: string;
  category: string;
  displayName: string;
  description: string;
  valueType: string;
  value: string;
  defaultValue: string;
  unit?: string;
  minimumValue?: string;
  maximumValue?: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  allowedValuesJson?: string;
  isSystemSetting?: boolean;
  requiresRestart?: boolean;
  updatedAtUtc: string;
  updatedBy: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
  appliesImmediately: boolean;
}

export interface SystemSettingHistory {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  systemSettingHistoryId: number;
  previousValue: string;
  newValue: string;
  changedAtUtc: string;
  changedBy: string;
  reason: string;
  correlationId: string;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  appliedSuccessfully: boolean;
  failureReason?: string;
}

@Injectable({ providedIn: 'root' })
/** Provides typed access to governed operational settings and reason configuration. */
export class ConfigurationAdminService {
  private readonly lookupUrl = `${environment.apiUrl}/lookups`;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  private readonly sectionsUrl = `${environment.apiUrl}/WarehouseSection`;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  private readonly settingsUrl = `${environment.apiUrl}/system-settings`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the lookup types service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  lookupTypes(filters: {
    search?: string;
    isActive?: boolean | null;
    page?: number;
    pageSize?: number;
  } = {}): Observable<PageResult<LookupTypeSummary>> {
    return this.http.get<PageResult<LookupTypeSummary>>(
      `${this.lookupUrl}/types`,
      { params: this.params(filters) }
    );
  }

  /**
   * Reviewer note: Centralises the lookup type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  lookupType(
    code: string,
    filters: {
      search?: string;
      isActive?: boolean | null;
      page?: number;
      pageSize?: number;
    } = {}
  ): Observable<LookupTypeDetail> {
    return this.http.get<LookupTypeDetail>(
      `${this.lookupUrl}/types/${encodeURIComponent(code)}`,
      { params: this.params(filters) }
    );
  }

  /**
   * Reviewer note: Centralises the active values service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  activeValues(code: string): Observable<LookupValueSummary[]> {
    return this.http.get<LookupValueSummary[]>(
      `${this.lookupUrl}/types/${encodeURIComponent(code)}/active-values`
    );
  }

  /**
   * Reviewer note: Centralises the create lookup type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createLookupType(request: Record<string, unknown>): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${this.lookupUrl}/types`, request);
  }

  /**
   * Reviewer note: Centralises the update lookup type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateLookupType(
    id: number,
    request: Record<string, unknown>
  ): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.lookupUrl}/types/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the change lookup type status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changeLookupTypeStatus(
    id: number,
    isActive: boolean,
    reason: string,
    rowVersion: string
  ): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.lookupUrl}/types/${id}/status`,
      { isActive, reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the delete lookup type service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteLookupType(id: number, reason: string): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      `${this.lookupUrl}/types/${id}`,
      { body: { reason } }
    );
  }

  /**
   * Reviewer note: Centralises the create lookup value service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createLookupValue(
    typeCode: string,
    request: Record<string, unknown>
  ): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.lookupUrl}/types/${encodeURIComponent(typeCode)}/values`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the update lookup value service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateLookupValue(
    id: number,
    request: Record<string, unknown>
  ): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.lookupUrl}/values/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the change lookup value status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changeLookupValueStatus(
    id: number,
    isActive: boolean,
    reason: string,
    rowVersion: string
  ): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.lookupUrl}/values/${id}/status`,
      { isActive, reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the delete lookup value service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteLookupValue(id: number, reason: string): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      `${this.lookupUrl}/values/${id}`,
      { body: { reason } }
    );
  }

  /**
   * Reviewer note: Centralises the lookup value history service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  lookupValueHistory(id: number): Observable<LookupHistory[]> {
    return this.http.get<LookupHistory[]>(`${this.lookupUrl}/values/${id}/history`);
  }

  /**
   * Reviewer note: Centralises the warehouse sections service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  warehouseSections(filters: {
    search?: string;
    status?: string;
    page?: number;
    pageSize?: number;
  } = {}): Observable<PageResult<WarehouseSectionRecord>> {
    return this.http.get<PageResult<WarehouseSectionRecord>>(
      this.sectionsUrl,
      { params: this.params(filters) }
    );
  }

  /**
   * Reviewer note: Centralises the create warehouse section service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createWarehouseSection(request: Record<string, unknown>): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(this.sectionsUrl, request);
  }

  /**
   * Reviewer note: Centralises the update warehouse section service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateWarehouseSection(
    id: number,
    request: Record<string, unknown>
  ): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.sectionsUrl}/${id}`, request);
  }

  /**
   * Reviewer note: Centralises the change warehouse section status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changeWarehouseSectionStatus(
    id: number,
    isActive: boolean,
    reason: string,
    rowVersion: string
  ): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.sectionsUrl}/${id}/status`,
      { isActive, reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the delete warehouse section service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteWarehouseSection(id: number, reason: string): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      `${this.sectionsUrl}/${id}`,
      { body: { reason } }
    );
  }

  /**
   * Reviewer note: Centralises the settings service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  settings(search = '', category = ''): Observable<SystemSettingRecord[]> {
    return this.http.get<SystemSettingRecord[]>(this.settingsUrl, {
      params: this.params({ search, category })
    });
  }

  /**
   * Reviewer note: Centralises the validate setting service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  validateSetting(
    key: string,
    value: string,
    reason: string
  ): Observable<{ normalizedValue: string }> {
    return this.http.post<{ normalizedValue: string }>(
      `${this.settingsUrl}/${encodeURIComponent(key)}/validate`,
      { value, reason, rowVersion: 'validation-only' }
    );
  }

  /**
   * Reviewer note: Centralises the update setting service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateSetting(
    key: string,
    value: string,
    reason: string,
    rowVersion: string
  ): Observable<{ message: string; appliedImmediately: boolean }> {
    return this.http.put<{ message: string; appliedImmediately: boolean }>(
      `${this.settingsUrl}/${encodeURIComponent(key)}`,
      { value, reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the reset setting service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  resetSetting(
    key: string,
    reason: string,
    rowVersion: string
  ): Observable<{ message: string; appliedImmediately: boolean }> {
    return this.http.post<{ message: string; appliedImmediately: boolean }>(
      `${this.settingsUrl}/${encodeURIComponent(key)}/reset`,
      { reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the setting history service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  settingHistory(key: string): Observable<SystemSettingHistory[]> {
    return this.http.get<SystemSettingHistory[]>(
      `${this.settingsUrl}/${encodeURIComponent(key)}/history`
    );
  }

  /**
   * Reviewer note: Centralises the params service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  private params(values: Record<string, unknown>): HttpParams {
    let params = new HttpParams();
    Object.entries(values).forEach(([key, value]) => {
      if (value !== undefined && value !== null && `${value}`.trim() !== '') {
        params = params.set(key, `${value}`);
      }
    });
    return params;
  }
}
