/**
 * Reviewer guide: Centralises authorization HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient } from '@angular/common/http';
import { Injectable, signal } from '@angular/core';
import { finalize, Observable, of, shareReplay, tap } from 'rxjs';
import { environment } from '../../environments/environment';

export interface EffectivePermission {
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  permissionId: number;
  code: string;
  displayName: string;
  module: string;
  description?: string;
}

export interface AuthorizationSession {
  userId: number;
  email: string;
  role: string;
  roleCode: string;
  isActive: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  permissions: EffectivePermission[];
}

@Injectable({ providedIn: 'root' })
/** Caches the backend-computed effective permission snapshot for presentation decisions. */
export class AuthorizationService {
  private readonly apiUrl = `${environment.apiUrl}/users/me/permissions`;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  private loading?: Observable<AuthorizationSession>;
  readonly session = signal<AuthorizationSession | null>(null);

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the ensure loaded service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  ensureLoaded(force = false): Observable<AuthorizationSession> {
    if (!force && this.session()) return of(this.session()!);
    if (!force && this.loading) return this.loading;

    // Share concurrent callers so the shell, guards and pages observe one snapshot request.
    this.loading = this.http.get<AuthorizationSession>(this.apiUrl).pipe(
      tap(session => {
        this.session.set(session);
        localStorage.setItem('role', session.roleCode);
      }),
      finalize(() => this.loading = undefined),
      shareReplay({ bufferSize: 1, refCount: true })
    );
    return this.loading;
  }

  /**
   * Reviewer note: Centralises the refresh service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  refresh(): Observable<AuthorizationSession> {
    return this.ensureLoaded(true);
  }

  /**
   * Reviewer note: Calculates has for client presentation and routing.
   * This result improves UX but never substitutes for the backend permission check.
   */
  has(permission: string): boolean {
    // UI permission checks improve navigation only; API policies remain authoritative.
    return this.session()?.permissions.some(item => item.code === permission) ?? false;
  }

  /**
   * Reviewer note: Calculates has any for client presentation and routing.
   * This result improves UX but never substitutes for the backend permission check.
   */
  hasAny(...permissions: string[]): boolean {
    return permissions.some(permission => this.has(permission));
  }

  /**
   * Reviewer note: Centralises the clear service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  clear(): void {
    this.loading = undefined;
    this.session.set(null);
  }
}
