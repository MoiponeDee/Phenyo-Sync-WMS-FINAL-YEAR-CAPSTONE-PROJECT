/**
 * Reviewer guide: Centralises field help HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';

type EditableElement = HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;

@Injectable({ providedIn: 'root' })
/** Resolves concise field guidance while keeping validation messages next to their controls. */
export class FieldHelpService {
  private observer?: MutationObserver;
  private sequence = 0;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(@Inject(DOCUMENT) private readonly document: Document) {}

  /**
   * Reviewer note: Centralises the start service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  start(): void {
    if (this.observer) return;
    this.enhance(this.document.body);
    this.observer = new MutationObserver(records => {
      for (const record of records) {
        record.addedNodes.forEach(node => {
          if (node instanceof HTMLElement) this.enhance(node);
        });
      }
    });
    this.observer.observe(this.document.body, {
      childList: true,
      subtree: true
    });
  }

  /**
   * Reviewer note: Centralises the stop service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  stop(): void {
    this.observer?.disconnect();
    this.observer = undefined;
  }

  /**
   * Reviewer note: Centralises the enhance service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  private enhance(root: HTMLElement): void {
    const fields = [
      ...(root.matches('input, select, textarea') ? [root] : []),
      ...Array.from(root.querySelectorAll<HTMLElement>('input, select, textarea'))
    ];

    fields.forEach(field => this.addHelp(field as EditableElement));
  }

  /**
   * Reviewer note: Centralises the add help service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  private addHelp(field: EditableElement): void {
    if (
      field.dataset['fieldHelpApplied'] ||
      field.hasAttribute('data-no-field-help') ||
      !field.dataset['help'] ||
      field instanceof HTMLInputElement &&
        ['hidden', 'button', 'submit', 'reset', 'checkbox', 'radio', 'file'].includes(field.type)
    ) {
      return;
    }

    field.dataset['fieldHelpApplied'] = 'true';
    const help = this.document.createElement('small');
    const helpId = `field-help-${++this.sequence}`;
    help.id = helpId;
    help.className = 'field-help-text';
    help.textContent = field.dataset['help'];

    const descriptions = (field.getAttribute('aria-describedby') || '')
      .split(/\s+/)
      .filter(Boolean);
    field.setAttribute(
      'aria-describedby',
      [...new Set([...descriptions, helpId])].join(' ')
    );

    const passwordWrapper = field.closest('.password-container');
    if (passwordWrapper) {
      passwordWrapper.insertAdjacentElement('afterend', help);
    } else {
      field.insertAdjacentElement('afterend', help);
    }
  }

}
