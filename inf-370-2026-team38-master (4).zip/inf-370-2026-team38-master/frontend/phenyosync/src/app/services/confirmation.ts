/**
 * Reviewer guide: Centralises confirmation HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { Injectable, signal } from '@angular/core';

export interface ConfirmationOptions {
  title: string;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  confirmLabel?: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  cancelLabel?: string;
  tone?: 'default' | 'danger' | 'warning';
  reasonLabel?: string;
  reasonRequired?: boolean;
}

export interface ConfirmationResult {
  confirmed: boolean;
  reason: string;
}

interface ConfirmationState extends ConfirmationOptions {
  resolve: (result: ConfirmationResult) => void;
}

@Injectable({ providedIn: 'root' })
/** Presents reusable confirmation prompts without embedding domain authorization decisions. */
export class ConfirmationService {
  readonly current = signal<ConfirmationState | null>(null);

  /**
   * Reviewer note: Centralises the ask service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  ask(options: ConfirmationOptions): Promise<ConfirmationResult> {
    this.cancel();
    return new Promise(resolve => this.current.set({ ...options, resolve }));
  }

  /**
   * Reviewer note: Centralises the complete service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  complete(confirmed: boolean, reason = ''): void {
    const state = this.current();
    if (!state) return;
    this.current.set(null);
    state.resolve({ confirmed, reason: reason.trim() });
  }

  /**
   * Reviewer note: Calculates cancel for client presentation and routing.
   * This result improves UX but never substitutes for the backend permission check.
   */
  cancel(): void {
    this.complete(false);
  }
}
