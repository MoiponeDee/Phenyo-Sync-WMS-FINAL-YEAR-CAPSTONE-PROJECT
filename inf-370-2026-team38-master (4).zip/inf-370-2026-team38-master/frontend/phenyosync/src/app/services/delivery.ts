/**
 * Reviewer guide: Centralises delivery HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export type DeliveryStatus = 'Scheduled' | 'Assigned' | 'InTransit' | 'Completed' | 'Cancelled';

export interface DeliverySearchFilters {
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  searchTerm?: string;
  driverId?: number | null;
  status?: string;
  scheduledFromUtc?: string;
  scheduledToUtc?: string;
  assigned?: boolean | null;
  completed?: boolean | null;
  page?: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize?: number;
}

export interface DeliveryListItem {
  deliveryId: number;
  salesOrderId: number;
  orderNumber: string;
  customerName: string;
  deliveryAddress: string;
  scheduledStartUtc: string;
  scheduledEndUtc: string;
  status: DeliveryStatus;
  driverId?: number;
  driverName?: string;
  completedAtUtc?: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canAssign: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canStart: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canComplete: boolean;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface DeliveryAssignmentHistory {
  deliveryDriverAssignmentId: number;
  driverId: number;
  driverName: string;
  assignedAtUtc: string;
  assignedBy?: string;
  unassignedAtUtc?: string;
  unassignedBy?: string;
  assignmentNotes?: string;
  reassignmentReason?: string;
  isCurrent: boolean;
}

export interface DeliveryStatusHistory {
  previousStatus?: string;
  newStatus: string;
  changedAtUtc: string;
  changedBy?: string;
  reason?: string;
  source: string;
}

export interface DeliveryDetail extends DeliveryListItem {
  customerNumber: string;
  // Reviewer note: Defines the client-side input or request boundary before a narrow DTO reaches the API.
  // Client validation improves feedback; the backend validates business constraints independently.
  requestedDeliveryDateUtc?: string;
  assignedAtUtc?: string;
  startedAtUtc?: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  orderStatus: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  assignmentHistory: DeliveryAssignmentHistory[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  statusHistory: DeliveryStatusHistory[];
}

export interface AvailableDriver {
  driverId: number;
  driverName: string;
  availabilityStatus: string;
  licenseExpiryDate?: string;
  licenseValidForWindow: boolean;
  vehicleAssigned?: string;
}

export interface DeliveryProof {
  deliveryCompletionRecordId: number;
  deliveryId: number;
  orderNumber: string;
  completedAtUtc: string;
  completedBy: string;
  assignedDriver?: string;
  completedOnBehalfOfDriver: boolean;
  managementOverrideReason?: string;
  recipientName: string;
  recipientConfirmed: boolean;
  fulfillmentConfirmed: boolean;
  notes?: string;
  proofReference?: string;
}

export interface DeliveryProofImage {
  deliveryProofImageId: number;
  deliveryId: number;
  fileName: string;
  contentType: string;
  sizeBytes: number;
  caption?: string;
  isPrimary: boolean;
  uploadedAtUtc: string;
  uploadedBy: string;
  isRemoved: boolean;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface DeliveryPage {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: DeliveryListItem[];
  page: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

export interface CompleteDeliveryRequest {
  recipientName: string;
  recipientConfirmed: boolean;
  fulfillmentConfirmed: boolean;
  notes?: string;
  proofReference?: string;
  managementOverrideReason?: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion?: string;
}

@Injectable({ providedIn: 'root' })
/** Typed client for scheduling, assignment, tracking and proof-of-delivery workflows. */
export class DeliveryService {
  private readonly apiUrl = `${environment.apiUrl}/deliveries`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the search service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  search(filters: DeliverySearchFilters): Observable<DeliveryPage> {
    return this.http.get<DeliveryPage>(this.apiUrl, { params: this.params(filters) });
  }

  /**
   * Reviewer note: Centralises the get service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  get(id: number): Observable<DeliveryDetail> {
    return this.http.get<DeliveryDetail>(`${this.apiUrl}/${id}`);
  }

  /**
   * Reviewer note: Centralises the schedule service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  schedule(request: {
    salesOrderId: number;
    scheduledStartUtc: string;
    scheduledEndUtc: string;
  }): Observable<{ message: string; delivery: DeliveryDetail }> {
    return this.http.post<{ message: string; delivery: DeliveryDetail }>(
      `${this.apiUrl}/schedule`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the available drivers service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  availableDrivers(id: number): Observable<AvailableDriver[]> {
    return this.http.get<AvailableDriver[]>(`${this.apiUrl}/${id}/available-drivers`);
  }

  /**
   * Reviewer note: Centralises the assign driver service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  assignDriver(
    id: number,
    request: {
      driverId: number;
      assignmentNotes?: string;
      reassignmentReason?: string;
      rowVersion?: string;
    }
  ): Observable<{ message: string; delivery: DeliveryDetail }> {
    return this.http.post<{ message: string; delivery: DeliveryDetail }>(
      `${this.apiUrl}/${id}/assign-driver`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the unassign driver service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  unassignDriver(
    id: number,
    reason: string,
    rowVersion?: string
  ): Observable<{ message: string; delivery: DeliveryDetail }> {
    return this.http.post<{ message: string; delivery: DeliveryDetail }>(
      `${this.apiUrl}/${id}/unassign-driver`,
      { reason, rowVersion }
    );
  }

  /**
   * Reviewer note: Centralises the my service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  my(status = '', fromUtc?: string, toUtc?: string): Observable<DeliveryListItem[]> {
    let params = new HttpParams();
    if (status) params = params.set('status', status);
    if (fromUtc) params = params.set('fromUtc', fromUtc);
    if (toUtc) params = params.set('toUtc', toUtc);
    return this.http.get<DeliveryListItem[]>(`${this.apiUrl}/my`, { params });
  }

  /**
   * Reviewer note: Centralises the start service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  start(id: number): Observable<{ message: string; delivery: DeliveryDetail }> {
    return this.http.post<{ message: string; delivery: DeliveryDetail }>(
      `${this.apiUrl}/${id}/start`,
      {}
    );
  }

  /**
   * Reviewer note: Centralises the complete service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  complete(
    id: number,
    request: CompleteDeliveryRequest
  ): Observable<{ message: string; proof: DeliveryProof }> {
    return this.http.post<{ message: string; proof: DeliveryProof }>(
      `${this.apiUrl}/${id}/complete`,
      request
    );
  }

  /**
   * Reviewer note: Centralises the proof service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  proof(id: number): Observable<DeliveryProof> {
    return this.http.get<DeliveryProof>(`${this.apiUrl}/${id}/proof`);
  }

  /**
   * Reviewer note: Centralises the proof images service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  proofImages(id: number): Observable<DeliveryProofImage[]> {
    return this.http.get<DeliveryProofImage[]>(
      `${this.apiUrl}/${id}/proof-images`
    );
  }

  /**
   * Reviewer note: Centralises the upload proof image service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  uploadProofImage(
    id: number,
    file: File,
    caption: string,
    isPrimary: boolean
  ): Observable<{ message: string; image: DeliveryProofImage }> {
    const form = new FormData();
    form.append('file', file);
    form.append('caption', caption);
    form.append('isPrimary', `${isPrimary}`);
    return this.http.post<{ message: string; image: DeliveryProofImage }>(
      `${this.apiUrl}/${id}/proof-images`,
      form
    );
  }

  /**
   * Reviewer note: Centralises the proof image blob service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  proofImageBlob(
    deliveryId: number,
    imageId: number,
    thumbnail = false
  ): Observable<Blob> {
    return this.http.get(
      `${this.apiUrl}/${deliveryId}/proof-images/${imageId}/file`,
      {
        params: new HttpParams().set('thumbnail', `${thumbnail}`),
        responseType: 'blob'
      }
    );
  }

  /**
   * Reviewer note: Centralises the remove proof image service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  removeProofImage(
    deliveryId: number,
    imageId: number,
    reason: string
  ): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      `${this.apiUrl}/${deliveryId}/proof-images/${imageId}`,
      { body: { reason } }
    );
  }

  /**
   * Reviewer note: Centralises the params service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  private params(filters: DeliverySearchFilters): HttpParams {
    let params = new HttpParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && `${value}`.trim() !== '') {
        params = params.set(key, `${value}`);
      }
    });
    return params;
  }
}
