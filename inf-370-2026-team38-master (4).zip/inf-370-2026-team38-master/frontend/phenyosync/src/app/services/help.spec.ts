/**
 * Reviewer guide: Verifies the help frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { HelpService } from './help';

// Covers the help behavior most likely to regress across permissions and workflow changes.
describe('HelpService', () => {
  let service: HelpService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        HelpService,
        provideHttpClient(),
        provideHttpClientTesting()
      ]
    });
    service = TestBed.inject(HelpService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that searches Help using server-side criteria.
  it('searches Help using server-side criteria', () => {
    service.search('packing', 5).subscribe();
    const request = http.expectOne(item =>
      item.url === `${environment.apiUrl}/help/search` &&
      item.params.get('query') === 'packing' &&
      item.params.get('categoryId') === '5');
    expect(request.request.method).toBe('GET');
    request.flush({
      items: [],
      page: 1,
      pageSize: 20,
      totalCount: 0,
      totalPages: 0
    });
  });

  // Reviewer note: Guards the observable rule that resolves context-sensitive Help from the current route.
  it('resolves context-sensitive Help from the current route', () => {
    service.context('/deliveries/9/complete', 'CompleteDelivery').subscribe();
    const request = http.expectOne(item =>
      item.url === `${environment.apiUrl}/help/context` &&
      item.params.get('route') === '/deliveries/9/complete' &&
      item.params.get('componentKey') === 'CompleteDelivery');
    expect(request.request.method).toBe('GET');
    request.flush({ slug: 'complete-delivery', title: 'Complete', summary: '' });
  });

  it('removes legacy box-plot guidance from the pricing report topic', () => {
    let topic: any;
    service.topic('pricing-management-report').subscribe(value => topic = value);
    const request = http.expectOne(
      `${environment.apiUrl}/help/topics/pricing-management-report`);
    request.flush({
      slug: 'pricing-management-report',
      title: 'Pricing management report',
      summary: 'Legacy box plot summary',
      bodyContent: 'Legacy box plot and whisker guidance.',
      related: []
    });

    expect(topic.summary).toContain('line and bar charts');
    expect(topic.bodyContent).not.toMatch(/box|whisker/i);
    expect(topic.bodyContent).toMatch(/visible value labels/i);
  });

  // Reviewer note: Guards the observable rule that downloads the Help guide as a PDF blob.
  it('downloads the Help guide as a PDF blob', () => {
    service.downloadPdf().subscribe();
    const request = http.expectOne(`${environment.apiUrl}/help/user-guide.pdf`);
    expect(request.request.responseType).toBe('blob');
    request.flush(new Blob(['pdf'], { type: 'application/pdf' }));
  });

  // Reviewer note: Guards the observable rule that uploads protected training video and optional captions.
  it('uploads protected training video and optional captions', () => {
    service.uploadMedia(
      new File(['video'], 'training.mp4', { type: 'video/mp4' }),
      new File(['WEBVTT'], 'training.vtt', { type: 'text/vtt' }),
      {
        title: 'Training',
        isFeatured: true,
        isPublished: false,
        sortOrder: 100
      }
    ).subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/help-media-management`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body instanceof FormData).toBe(true);
    expect((request.request.body as FormData).get('title')).toBe('Training');
    request.flush({ message: 'ok', media: {} });
  });

  // Reviewer note: Guards the observable rule that removes training media with an audited reason.
  it('removes training media with an audited reason', () => {
    service.removeMedia(7, 'Outdated workflow').subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/help-media-management/7`);
    expect(request.request.method).toBe('DELETE');
    expect(request.request.body.reason).toBe('Outdated workflow');
    request.flush({ message: 'removed' });
  });
});
