/**
 * Reviewer guide: Centralises mobile operations HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface ManagementDashboard {
  displayName: string;
  role: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  deliveriesToday: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  activeDeliveries: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  unreadNotifications: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  buyingItemsRemaining: number;
  // Reviewer note: Defines the client-side input or request boundary before a narrow DTO reaches the API.
  // Client validation improves feedback; the backend validates business constraints independently.
  draftStockReceipts: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  packingTasks: number;
  dispatchQueue: number;
  criticalExpiryAlerts: number;
  pendingWriteOffApprovals: number;
}

export interface DriverLocation {
  latitude: number;
  longitude: number;
  accuracyMetres: number;
  capturedAtUtc: string;
  receivedAtUtc: string;
}

export interface ActiveTrackingSession {
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  trackingSessionId: number;
  deliveryId: number;
  driverId: number;
  driverName: string;
  status: string;
  startedAtUtc: string;
  latestLocation?: DriverLocation;
}

export interface DispatchQueueItem {
  salesOrderId: number;
  orderNumber: string;
  customerName: string;
  status: string;
  packedAtUtc?: string;
  packerName?: string;
  scanCount: number;
  packedQuantityKg: number;
  deliveryId?: number;
  driverName?: string;
  vehicle?: string;
}

export interface WriteOffItem {
  stockWriteOffId: number;
  productName: string;
  batchCode: string;
  warehouseSection: string;
  quantityKg: number;
  estimatedTotalLoss?: number | null;
  reasonCode: string;
  status: string;
  submittedBy: string;
  submittedAtUtc: string;
  evidenceCount: number;
}

export interface OperationalNotificationItem {
  recipientId: number;
  type: string;
  severity: string;
  title: string;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  actionRoute?: string;
  createdAtUtc: string;
  readAtUtc?: string;
}

export interface OperationalInbox {
  unreadCount: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: OperationalNotificationItem[];
}

@Injectable({ providedIn: 'root' })
/** Supplies desktop oversight screens for mobile operational activity. */
export class MobileOperationsService {
  private readonly base = `${environment.apiUrl}/mobile`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private readonly http: HttpClient) {}

  /**
   * Reviewer note: Centralises the dashboard service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  dashboard(): Observable<ManagementDashboard> {
    return this.http.get<ManagementDashboard>(`${this.base}/dashboard`);
  }

  /**
   * Reviewer note: Centralises the active tracking service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  activeTracking(): Observable<ActiveTrackingSession[]> {
    return this.http.get<ActiveTrackingSession[]>(`${this.base}/tracking/active`);
  }

  /**
   * Reviewer note: Centralises the tracking history service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  trackingHistory(sessionId: number): Observable<DriverLocation[]> {
    return this.http.get<DriverLocation[]>(
      `${this.base}/tracking/sessions/${sessionId}/locations`
    );
  }

  /**
   * Reviewer note: Centralises the dispatch queue service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  dispatchQueue(): Observable<DispatchQueueItem[]> {
    return this.http.get<DispatchQueueItem[]>(`${this.base}/dispatch`);
  }

  /**
   * Reviewer note: Centralises the confirm dispatch service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  confirmDispatch(orderId: number, reason: string): Observable<DispatchQueueItem> {
    return this.http.post<DispatchQueueItem>(
      `${this.base}/dispatch/${orderId}/confirm`,
      { reason, operationId: crypto.randomUUID() }
    );
  }

  /**
   * Reviewer note: Centralises the write offs service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  writeOffs(approvalsOnly = false): Observable<WriteOffItem[]> {
    return this.http.get<WriteOffItem[]>(`${this.base}/write-offs`, {
      params: { approvalsOnly }
    });
  }

  /**
   * Reviewer note: Centralises the decide write off service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  decideWriteOff(
    id: number,
    approved: boolean,
    reason: string
  ): Observable<WriteOffItem> {
    return this.http.post<WriteOffItem>(
      `${this.base}/write-offs/${id}/${approved ? 'approve' : 'reject'}`,
      { reason, operationId: crypto.randomUUID() }
    );
  }

  /**
   * Reviewer note: Centralises the notifications service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  notifications(): Observable<OperationalInbox> {
    return this.http.get<OperationalInbox>(`${this.base}/notifications`);
  }
}
