/**
 * Reviewer guide: Verifies the field help frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TestBed } from '@angular/core/testing';
import { FieldHelpService } from './field-help';

// Covers the field help behavior most likely to regress across permissions and workflow changes.
describe('FieldHelpService', () => {
  let service: FieldHelpService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FieldHelpService);
    document.body.innerHTML = '';
  });

  afterEach(() => {
    service.stop();
    document.body.innerHTML = '';
  });

  // Reviewer note: Guards the observable rule that adds visible and accessible help to editable fields.
  it('adds visible and accessible help to editable fields', async () => {
    document.body.innerHTML = `
      <label for="quantity">Quantity</label>
      <input id="quantity" type="number" data-help="Enter kilograms received.">
    `;

    service.start();
    await Promise.resolve();

    const input = document.querySelector<HTMLInputElement>('#quantity')!;
    const helpId = input.getAttribute('aria-describedby')!;
    expect(helpId).toBeTruthy();
    expect(document.getElementById(helpId)?.textContent)
      .toBe('Enter kilograms received.');
  });

  it('does not inject generic text that merely repeats a dropdown label', async () => {
    document.body.innerHTML = `
      <label for="status">Status</label>
      <select id="status"><option>Active</option></select>
    `;

    service.start();
    await Promise.resolve();

    expect(document.querySelector('.field-help-text')).toBeNull();
    expect(document.querySelector('#status')?.hasAttribute('aria-describedby')).toBe(false);
  });
});

