import { registeredHelpRoute, registeredHelpSlug } from './context-help-registry';

describe('registeredHelpRoute', () => {
  it('keeps each formal report linked to its specific persisted Help topic', () => {
    expect(registeredHelpRoute('/reports/inventory'))
      .toBe('/reports/inventory-availability');
    expect(registeredHelpRoute('/reports/financial'))
      .toBe('/reports/financial-summary');
    expect(registeredHelpRoute('/reports/markup'))
      .toBe('/reports/markup-analysis');
  });

  it('leaves routes with current mappings unchanged', () => {
    expect(registeredHelpRoute('/manage-users')).toBe('/manage-users');
  });

  it('covers operational, financial and dynamic detail pages with maintained topics', () => {
    expect(registeredHelpSlug('/payments')).toBe('customers-suppliers-payments');
    expect(registeredHelpSlug('/products/42/details')).toBe('search-update-products');
    expect(registeredHelpSlug('/raw-stock/approvals')).toBe('stock-take');
    expect(registeredHelpSlug('/reports/pricing')).toBe('formal-reports');
    expect(registeredHelpSlug('/mobile-operations-control')).toBe('mobile-scanning-and-tracking');
  });
});
