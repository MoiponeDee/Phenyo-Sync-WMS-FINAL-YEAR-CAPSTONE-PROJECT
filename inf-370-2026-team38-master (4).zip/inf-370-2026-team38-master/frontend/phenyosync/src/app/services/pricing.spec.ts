/**
 * Reviewer guide: Verifies the pricing frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { PricingService } from './pricing';

// Covers the pricing behavior most likely to regress across permissions and workflow changes.
describe('PricingService', () => {
  let service: PricingService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(PricingService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that creates an initial price with an explicit effective date.
  it('creates an initial price with an explicit effective date', () => {
    const effectiveFromUtc = '2026-08-15T06:00:00.000Z';
    service.create(7, 25.5, 'PerSellableUnit', effectiveFromUtc, 'Initial price').subscribe();
    const pending = http.expectOne(`${environment.apiUrl}/prices`);
    expect(pending.request.method).toBe('POST');
    expect(pending.request.body).toEqual({
      productId: 7,
      sellingPrice: 25.5,
      priceBasis: 'PerSellableUnit',
      effectiveFromUtc,
      reason: 'Initial price'
    });
    pending.flush({ message: 'Created', price: {} });
  });

  // Reviewer note: Guards the observable rule that updates a price with its concurrency token.
  it('updates a price with its concurrency token', () => {
    const effectiveFromUtc = '2026-08-16T06:00:00.000Z';
    service.update(12, 30, 'PerKilogram', effectiveFromUtc, 'Review', 'row-token').subscribe();
    const pending = http.expectOne(`${environment.apiUrl}/prices/12`);
    expect(pending.request.method).toBe('PUT');
    expect(pending.request.body).toEqual({
      sellingPrice: 30,
      priceBasis: 'PerKilogram',
      effectiveFromUtc,
      changeReason: 'Review',
      rowVersion: 'row-token'
    });
    pending.flush({ message: 'Updated', currentPrice: {} });
  });

  // Reviewer note: Guards the observable rule that searches current and historical records using server filters.
  it('searches current and historical records using server filters', () => {
    service.search({ searchTerm: 'apple', status: 'All', page: 2, pageSize: 10 }).subscribe();
    const pending = http.expectOne(request =>
      request.url === `${environment.apiUrl}/prices` &&
      request.params.get('searchTerm') === 'apple' &&
      request.params.get('status') === 'All' &&
      request.params.get('page') === '2'
    );
    expect(pending.request.method).toBe('GET');
    pending.flush({ items: [], page: 2, pageSize: 10, totalCount: 0, totalPages: 0 });
  });

  // Reviewer note: Guards the observable rule that uses explicit confirmation for soft delete.
  it('uses explicit confirmation for soft delete', () => {
    service.softDelete(4, 'Historic correction').subscribe();
    const pending = http.expectOne(`${environment.apiUrl}/prices/4/soft-delete`);
    expect(pending.request.method).toBe('POST');
    expect(pending.request.body).toEqual({
      confirmed: true,
      reason: 'Historic correction'
    });
    pending.flush({ message: 'Deleted', price: {} });
  });
});
