/**
 * Reviewer guide: Verifies the user frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { UserService } from './user';

describe('UserService', () => {
  // Reviewer note: Guards the observable rule that should be created.
  it('should be created', () => {
    TestBed.configureTestingModule({ providers: [provideHttpClient()] });
    expect(TestBed.inject(UserService)).toBeTruthy();
  });
});
