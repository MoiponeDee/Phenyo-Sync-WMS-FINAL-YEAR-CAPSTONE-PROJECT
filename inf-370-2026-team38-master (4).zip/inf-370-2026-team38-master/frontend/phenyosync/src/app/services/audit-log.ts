/**
 * Reviewer guide: Centralises audit log HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface AuditLogSearchFilters {
  userId?: number | null;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  userSearch?: string;
  dateFromUtc?: string;
  dateToUtc?: string;
  actionType?: string;
  systemModule?: string;
  operationName?: string;
  entityType?: string;
  entityId?: string;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  success?: boolean | null;
  correlationId?: string;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  searchTerm?: string;
  pageNumber?: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize?: number;
}

export interface AuditLogListItem {
  auditLogId: number;
  occurredAtUtc: string;
  userId?: number;
  userEmail?: string;
  userDisplayName?: string;
  userRole?: string;
  actorType: string;
  actionType: string;
  systemModule: string;
  operationName: string;
  entityType?: string;
  entityId?: string;
  entityDisplay?: string;
  description: string;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  success: boolean;
  correlationId: string;
}

export interface AuditLogDetail extends AuditLogListItem {
  beforeValuesJson?: string;
  afterValuesJson?: string;
  changedFieldsJson?: string;
  failureReason?: string;
  // Reviewer note: Defines the client-side input or request boundary before a narrow DTO reaches the API.
  // Client validation improves feedback; the backend validates business constraints independently.
  requestPath?: string;
  httpMethod?: string;
  ipAddress?: string;
  userAgent?: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  eventSource: string;
  relatedLogs: AuditLogListItem[];
}

export interface AuditUserOption {
  userId: number;
  displayName: string;
  email: string;
}

export interface AuditLogMetadata {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  actionTypes: string[];
  systemModules: string[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  entityTypes: string[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  users: AuditUserOption[];
}

export interface PagedResult<T> {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: T[];
  pageNumber: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize: number;
  totalCount: number;
  totalPages: number;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  hasPreviousPage: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  hasNextPage: boolean;
}

@Injectable({ providedIn: 'root' })
/** Typed client for permission-filtered audit search, detail and export endpoints. */
export class AuditLogService {
  private readonly apiUrl = `${environment.apiUrl}/audit-logs`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the search service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  search(filters: AuditLogSearchFilters): Observable<PagedResult<AuditLogListItem>> {
    let params = new HttpParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && `${value}`.trim() !== '') {
        params = params.set(key, `${value}`);
      }
    });
    return this.http.get<PagedResult<AuditLogListItem>>(this.apiUrl, { params });
  }

  /**
   * Reviewer note: Centralises the get service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  get(id: number): Observable<AuditLogDetail> {
    return this.http.get<AuditLogDetail>(`${this.apiUrl}/${id}`);
  }

  /**
   * Reviewer note: Centralises the metadata service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  metadata(): Observable<AuditLogMetadata> {
    return this.http.get<AuditLogMetadata>(`${this.apiUrl}/metadata`);
  }
}
