/**
 * Reviewer guide: Verifies the delivery frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { DeliveryService } from './delivery';
import { environment } from '../../environments/environment';

// Covers the delivery behavior most likely to regress across permissions and workflow changes.
describe('DeliveryService', () => {
  let service: DeliveryService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DeliveryService, provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(DeliveryService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that uses server-side delivery filters.
  it('uses server-side delivery filters', () => {
    service.search({ status: 'Assigned', assigned: true, page: 2, pageSize: 10 }).subscribe();
    const request = http.expectOne(item =>
      item.url === `${environment.apiUrl}/deliveries` &&
      item.params.get('status') === 'Assigned' &&
      item.params.get('assigned') === 'true' &&
      item.params.get('page') === '2');
    expect(request.request.method).toBe('GET');
    request.flush({ items: [], page: 2, pageSize: 10, totalCount: 0, totalPages: 0 });
  });

  // Reviewer note: Guards the observable rule that does not send actor, driver or completion time when completing.
  it('does not send actor, driver or completion time when completing', () => {
    service.complete(4, {
      recipientName: 'Receiver',
      recipientConfirmed: true,
      fulfillmentConfirmed: true
    }).subscribe();
    const request = http.expectOne(`${environment.apiUrl}/deliveries/4/complete`);
    expect(request.request.body.completedAtUtc).toBeUndefined();
    expect(request.request.body.completedByUserId).toBeUndefined();
    expect(request.request.body.driverId).toBeUndefined();
    request.flush({ message: 'ok', proof: {} });
  });

  // Reviewer note: Guards the observable rule that uploads proof images as multipart form data.
  it('uploads proof images as multipart form data', () => {
    const file = new File(['image'], 'proof.jpg', { type: 'image/jpeg' });
    service.uploadProofImage(4, file, 'Delivered safely', true).subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/deliveries/4/proof-images`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body instanceof FormData).toBe(true);
    expect((request.request.body as FormData).get('caption'))
      .toBe('Delivered safely');
    request.flush({ message: 'ok', image: {} });
  });

  // Reviewer note: Guards the observable rule that requests a protected thumbnail as a blob.
  it('requests a protected thumbnail as a blob', () => {
    service.proofImageBlob(4, 12, true).subscribe();
    const request = http.expectOne(item =>
      item.url ===
        `${environment.apiUrl}/deliveries/4/proof-images/12/file` &&
      item.params.get('thumbnail') === 'true');
    expect(request.request.responseType).toBe('blob');
    request.flush(new Blob(['image'], { type: 'image/jpeg' }));
  });

  // Reviewer note: Guards the observable rule that requires a reason when removing proof-image metadata.
  it('requires a reason when removing proof-image metadata', () => {
    service.removeProofImage(4, 12, 'Incorrect photograph').subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/deliveries/4/proof-images/12`);
    expect(request.request.method).toBe('DELETE');
    expect(request.request.body.reason).toBe('Incorrect photograph');
    request.flush({ message: 'removed' });
  });
});
