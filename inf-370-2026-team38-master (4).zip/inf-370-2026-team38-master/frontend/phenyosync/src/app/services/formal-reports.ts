/**
 * Reviewer guide: Centralises formal reports HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export type ReportKey =
  | 'inventory'
  | 'sales'
  | 'financial'
  | 'stock-movement'
  | 'expiry-waste'
  | 'pricing'
  | 'markup';

export interface ReportCriterion {
  label: string;
  value: string;
}

export interface ReportMetadata {
  reportKey: ReportKey;
  title: string;
  classification: string;
  generatedAtUtc: string;
  generatedBy: string;
  // Reviewer note: Defines the client-side input or request boundary before a narrow DTO reaches the API.
  // Client validation improves feedback; the backend validates business constraints independently.
  criteria: ReportCriterion[];
  recordCount: number;
  // Reviewer note: Keeps sensitive authentication state within the session or authentication boundary.
  // Possession of a client value never bypasses backend verification.
  previewToken: string;
}

export interface ReportOption {
  id: number;
  label: string;
}

export interface ReportCodeOption {
  code: string;
  label: string;
}

export interface ReportOptions {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  products: ReportOption[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  productCategories: ReportOption[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  productTypes: ReportOption[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  warehouseSections: ReportOption[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  customers: ReportOption[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  suppliers: ReportOption[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  orderStatuses: ReportCodeOption[];
  deliveryStatuses: ReportCodeOption[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  paymentStatuses: ReportCodeOption[];
  paymentMethods: ReportCodeOption[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  movementTypes: ReportCodeOption[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  writeOffReasons: ReportCodeOption[];
}

export interface InventoryReportRow {
  itemCode: string;
  product: string;
  productCategory: string;
  productType: string;
  warehouseSection: string;
  availableQuantityKg: number;
  reservedQuantityKg: number;
  totalQuantityKg: number;
  reorderLevelKg: number;
  bestBeforeDateUtc?: string;
  stockStatus: string;
}

export interface ExpiryWasteReportRow {
  recordType: string;
  itemCode: string;
  item: string;
  warehouseSection: string;
  quantityKg: number;
  unitOfMeasure: string;
  bestBeforeDateUtc?: string;
  daysRemaining?: number;
  riskStatus: string;
  writeOffReason?: string;
  estimatedUnitCost?: number;
  estimatedLossValue?: number;
  responsibleUser: string;
  recordedAtUtc: string;
  costAvailability: string;
}

export interface MarkupReportRow {
  productCode: string;
  product: string;
  productCategory: string;
  totalQuantitySoldKg: number;
  averageSellingPrice: number;
  averageCost?: number;
  costSource: string;
  markupAmountPerKg?: number;
  markupPercentage?: number;
  grossMarginPercentage?: number;
  dataQualityStatus: string;
}

export interface SalesReportLine {
  salesOrderItemId: number;
  orderDateUtc: string;
  orderNumber: string;
  invoiceNumber: string;
  product: string;
  productCategory: string;
  quantityKg: number;
  storedUnitPrice: number;
  lineTotal: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  orderStatus: string;
  deliveryStatus: string;
}

export interface SalesOrderGroup {
  salesOrderId: number;
  orderNumber: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  lines: SalesReportLine[];
  orderQuantitySubtotalKg: number;
  orderValueSubtotal: number;
}

export interface SalesCustomerGroup {
  customerId: number;
  customer: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  orders: SalesOrderGroup[];
  customerQuantitySubtotalKg: number;
  customerValueSubtotal: number;
}

export interface SalesMonthGroup {
  monthKey: string;
  monthLabel: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  customers: SalesCustomerGroup[];
  monthQuantitySubtotalKg: number;
  monthValueSubtotal: number;
}

export interface StockMovementRow {
  movementDateUtc: string;
  movementType: string;
  reference: string;
  item: string;
  warehouseSection: string;
  quantityInKg: number;
  quantityOutKg: number;
  netMovementKg: number;
  unitOfMeasure: string;
  unitCost?: number;
  movementValue?: number;
  reason: string;
  actor: string;
}

export interface StockMovementItemGroup {
  item: string;
  movements: StockMovementRow[];
  totalInKg: number;
  totalOutKg: number;
  netMovementKg: number;
  movementValue?: number;
}

export interface StockMovementCategoryGroup {
  category: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: StockMovementItemGroup[];
  totalInKg: number;
  totalOutKg: number;
  netMovementKg: number;
  movementValue?: number;
}

export interface StockMovementDomainGroup {
  stockDomain: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  categories: StockMovementCategoryGroup[];
  totalInKg: number;
  totalOutKg: number;
  netMovementKg: number;
  movementValue?: number;
}

export interface FinancialReportRow {
  transactionDateUtc: string;
  transactionType: string;
  reference: string;
  counterparty: string;
  status: string;
  paymentMethod: string;
  amount?: number | null;
  direction: string;
  notes: string;
}

export interface FinancialSummary {
  salesValue: number;
  customerReceipts: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  supplierPayments: number;
  writeOffLoss?: number | null;
  netCashMovement: number;
  customerOutstandingBalance?: number;
  supplierOutstandingBalance?: number;
}

export interface PriceDistribution {
  minimum: number;
  q1: number;
  median: number;
  q3: number;
  maximum: number;
  iqr: number;
  outliers: number[];
  observationCount: number;
  isReliable: boolean;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
}

export interface PricingObservation {
  transactionDateUtc: string;
  productId: number;
  product: string;
  orderNumber: string;
  invoiceNumber: string;
  customer: string;
  quantitySoldKg: number;
  storedUnitPrice: number;
  lineTotal: number;
  qualifyingStatus: string;
}

export interface MonthlyPricingSummary {
  productId: number;
  product: string;
  totalQuantitySoldKg: number;
  priceObservationCount: number;
  minimumPrice: number;
  maximumPrice: number;
  medianPrice: number;
  quantityWeightedMonthlyAverage: number;
  currentActivePrice?: number;
  differenceFromCurrentPrice?: number;
  distribution: PriceDistribution;
}

export interface AnnualPricingSummary {
  productId: number;
  product: string;
  monthlyWeightedAverages: Array<number | null>;
  monthsWithData: number;
  monthsWithoutData: number;
  annualAverage?: number;
  distribution?: PriceDistribution;
}

export interface ReportChartPoint {
  label: string;
  value?: number;
  tooltip: string;
  sequence: number;
}

export interface ReportChartSeries {
  name: string;
  points: ReportChartPoint[];
}

export interface ReportBoxPlot {
  label: string;
  distribution: PriceDistribution;
}

export interface ReportChart {
  chartType: 'line' | 'bar' | 'box';
  title: string;
  xAxisLabel: string;
  yAxisLabel: string;
  unit: string;
  series: ReportChartSeries[];
  boxPlots: ReportBoxPlot[];
}

export interface FormalReportResult {
  metadata: ReportMetadata;
  rows?: InventoryReportRow[] | ExpiryWasteReportRow[] |
    MarkupReportRow[] | FinancialReportRow[];
  months?: SalesMonthGroup[];
  domains?: StockMovementDomainGroup[];
  summary?: FinancialSummary;
  observations?: PricingObservation[];
  monthlySummaries?: MonthlyPricingSummary[];
  annualSummaries?: AnnualPricingSummary[];
  charts?: ReportChart[];
  viewMode?: string;
  totalRecords?: number;
  totalAvailableQuantityKg?: number;
  totalReservedQuantityKg?: number;
  totalQuantityAtRiskKg?: number;
  totalKnownLossValue?: number;
  grandQuantitySoldKg?: number;
  grandSalesValue?: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  totalOrders?: number;
  averageOrderValue?: number;
  grandTotalInKg?: number;
  grandTotalOutKg?: number;
  grandNetMovementKg?: number;
  grandMovementValue?: number;
}

@Injectable({ providedIn: 'root' })
/** Uses a server-generated preview token so downloaded PDFs match the reviewed data snapshot. */
export class FormalReportsService {
  private readonly apiUrl = `${environment.apiUrl}/reports`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private readonly http: HttpClient) {}

  /**
   * Reviewer note: Centralises the options service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  options(): Observable<ReportOptions> {
    return this.http.get<ReportOptions>(`${this.apiUrl}/options`);
  }

  /**
   * Reviewer note: Centralises the preview service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  preview(
    reportKey: ReportKey,
    criteria: Record<string, unknown>
  ): Observable<FormalReportResult> {
    return this.http.post<FormalReportResult>(
      `${this.apiUrl}/${reportKey}/preview`,
      criteria
    );
  }

  /**
   * Reviewer note: Centralises the pdf service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  pdf(
    reportKey: ReportKey,
    previewToken: string
  ): Observable<HttpResponse<Blob>> {
    // The server resolves the token; report criteria and sensitive totals are not recomputed here.
    return this.http.post(
      `${this.apiUrl}/${reportKey}/pdf`,
      { previewToken },
      {
        observe: 'response',
        responseType: 'blob'
      }
    );
  }
}
