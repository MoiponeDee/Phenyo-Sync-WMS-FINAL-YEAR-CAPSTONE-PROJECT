/**
 * Reviewer guide: Centralises operational sections HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface PagedResult<T> {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: T[];
  page: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize: number;
  total: number;
}

export interface RawStockSummary {
  rawStockItemId: number;
  rawStockBalanceId: number;
  itemCode: string;
  itemName: string;
  categoryCode: string;
  unitOfMeasure: string;
  warehouseSectionId: number;
  warehouseSection: string;
  quantityOnHand: number;
  reservedQuantity: number;
  weightedAverageUnitCost?: number;
  lastReceiptAtUtc?: string;
  lastStockTakeAtUtc?: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  hasCriticalAlert: boolean;
  isProduce: boolean;
  isActive: boolean;
  canDelete: boolean;
  canDeactivate: boolean;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface RawStockReceipt {
  rawStockReceiptId: number;
  receiptNumber: string;
  sourceType: string;
  supplierName: string;
  supplierOrderNumber?: string;
  warehouseSection: string;
  docketReference: string;
  status: string;
  receivedAtUtc: string;
  correlationId: string;
}

export interface OperationalReason {
  operationalReasonId: number;
  reasonCode: string;
  reasonName: string;
  categoryCode: string;
  description?: string;
  isActive: boolean;
  isInUse: boolean;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface RawStockTakeLine {
  rawStockTakeLineId: number;
  rawStockItemId: number;
  itemCode: string;
  itemName: string;
  reconciliationGroup?: string;
  // Reviewer note: Retains a disposable browser resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  isMapped: boolean;
  openingRawStock: number;
  rawStockReceived: number;
  approvedPositiveAdjustments: number;
  existingPackedProductWeight: number;
  recordedRawStockWriteOffs: number;
  approvedNegativeAdjustments: number;
  estimatedRawStockRemaining: number;
  physicalStockCount?: number;
  unexplainedStockDifference?: number;
  estimatedFinancialImpact?: number | null;
  managementApprovalRequired: boolean;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface RawStockTake {
  rawStockTakeSessionId: number;
  warehouseSection: string;
  startedBy: string;
  createdAtUtc: string;
  submittedAtUtc?: string;
  reviewedBy?: string;
  reviewedAtUtc?: string;
  decidedBy?: string;
  decidedAtUtc?: string;
  administratorReviewNotes?: string;
  managementDecisionReason?: string;
  periodStartUtc: string;
  periodEndUtc: string;
  status: string;
  managementApprovalRequired: boolean;
  correlationId: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  lines: RawStockTakeLine[];
}

export interface RawStockWriteOff {
  rawStockWriteOffId: number;
  itemName: string;
  warehouseSection: string;
  quantity: number;
  estimatedUnitCost?: number | null;
  estimatedTotalLoss?: number | null;
  reason: string;
  status: string;
  requiresManagementApproval: boolean;
  correlationId: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface CustomerSummary {
  customerId: number;
  customerNumber: string;
  customerName: string;
  email: string;
  contactPerson?: string;
  phoneNumber?: string;
  billingAddress?: string;
  deliveryAddress?: string;
  status: string;
  orderCount: number;
  outstandingBalance: number;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface SupplierSummary {
  supplierId: number;
  supplierCode: string;
  supplierName: string;
  supplierTypeCode: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  address?: string;
  status: string;
  orderCount: number;
  outstandingBalance: number;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface PartyDeleteResult {
  deleted: boolean;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  deleteBlockedReason?: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canDeactivate: boolean;
}

export interface SupplierOrder {
  supplierOrderId: number;
  supplierId: number;
  orderNumber: string;
  supplierName: string;
  supplierContactPerson?: string;
  supplierEmail?: string;
  supplierPhone?: string;
  warehouseSectionId: number;
  warehouseSection: string;
  status: string;
  orderDateUtc: string;
  expectedDeliveryAtUtc?: string;
  totalAmount: number;
  outstandingBalance: number;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  lines: SupplierOrderLine[];
}

export interface SupplierOrderLine {
  supplierOrderLineId: number;
  rawStockItemId: number;
  itemName: string;
  orderedQuantity: number;
  receivedQuantity: number;
  expectedUnitPrice: number;
  unitOfMeasure: string;
}

export interface FinancialPayment {
  financialPaymentId: number;
  originalPaymentId?: number;
  paymentNumber: string;
  counterpartyType: 'Customer' | 'Supplier';
  counterpartyName: string;
  counterpartyNumber?: string;
  documentNumber?: string;
  reference?: string;
  originalPaymentNumber?: string;
  amount: number;
  outstandingBeforePosting: number;
  outstandingAfterPosting: number;
  paymentMethodCode: string;
  status: string;
  reversalReason?: string;
  createdByUserId: number;
  paymentDateUtc: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface PaymentCaptureOptions {
  customers: Array<{
    customerId: number;
    customerNumber: string;
    customerName: string;
    contactPerson?: string;
    phoneNumber?: string;
    email?: string;
  }>;
  customerOrders: Array<{
    salesOrderId: number;
    customerId: number;
    orderNumber: string;
    status: string;
    totalAmount: number;
    orderDateUtc: string;
  }>;
  invoices: Array<{
    invoiceId: number;
    salesOrderId: number;
    customerId: number;
    invoiceNumber: string;
    totalAmount: number;
    paidAmount: number;
    outstandingAmount: number;
    issuedAtUtc: string;
  }>;
  suppliers: Array<{
    supplierId: number;
    supplierCode: string;
    supplierName: string;
    contactPerson?: string;
    phoneNumber?: string;
    email?: string;
  }>;
  supplierOrders: Array<{
    supplierOrderId: number;
    supplierId: number;
    orderNumber: string;
    status: string;
    totalAmount: number;
    paidAmount: number;
    outstandingAmount: number;
    expectedDeliveryAtUtc?: string | null;
  }>;
}

export interface SupplierOrderRawStockOption {
  rawStockItemId: number;
  itemCode: string;
  itemName: string;
  unitOfMeasure: string;
}

export interface PaymentSearchOptions {
  counterpartyType?: string;
  search?: string;
  status?: string;
  paymentMethodCode?: string;
  fromUtc?: string;
  toUtc?: string;
}

export interface DashboardGraphPoint {
  label: string;
  value: number;
  count: number;
}

export interface ManagementDashboard {
  pendingDispatches: number;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  activeDeliveries: number;
  pendingWriteOffApprovals: number;
  pendingStockTakeApprovals: number;
  criticalExpiryAlerts: number;
  buyingListsAwaitingReceipt: number;
  wasteByReason: DashboardGraphPoint[];
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  deliveriesByStatus: DashboardGraphPoint[];
}

@Injectable({ providedIn: 'root' })
/** Consolidates typed clients for raw stock, parties, procurement and payments. */
export class OperationalSectionsService {
  private readonly base = environment.apiUrl;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the raw stock service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  rawStock(search = '', includeInactive = false):
      Observable<PagedResult<RawStockSummary>> {
    let params = new HttpParams()
      .set('includeInactive', includeInactive)
      .set('pageSize', 100);
    if (search.trim()) params = params.set('search', search.trim());
    return this.http.get<PagedResult<RawStockSummary>>(
      `${this.base}/raw-stock`, { params });
  }

  /**
   * Reviewer note: Centralises the create raw stock service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createRawStock(request: object): Observable<{ rawStockItemId: number }> {
    return this.http.post<{ rawStockItemId: number }>(
      `${this.base}/raw-stock`, request);
  }

  /**
   * Reviewer note: Centralises the receipts service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  receipts(): Observable<RawStockReceipt[]> {
    return this.http.get<RawStockReceipt[]>(
      `${this.base}/raw-stock/receipts`);
  }

  /**
   * Reviewer note: Centralises the receive service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  receive(request: object): Observable<RawStockReceipt> {
    return this.http.post<RawStockReceipt>(
      `${this.base}/raw-stock/receipts`, request);
  }

  /**
   * Reviewer note: Centralises the reasons service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  reasons(categoryCode?: string): Observable<PagedResult<OperationalReason>> {
    let params = new HttpParams().set('pageSize', 100);
    if (categoryCode) params = params.set('categoryCode', categoryCode);
    return this.http.get<PagedResult<OperationalReason>>(
      `${this.base}/operational-reasons`, { params });
  }

  /**
   * Reviewer note: Centralises the save reason service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  saveReason(id: number | null, request: object):
      Observable<OperationalReason> {
    return id
      ? this.http.put<OperationalReason>(
          `${this.base}/operational-reasons/${id}`, request)
      : this.http.post<OperationalReason>(
          `${this.base}/operational-reasons`, request);
  }

  /**
   * Reviewer note: Centralises the stock takes service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  stockTakes(): Observable<RawStockTake[]> {
    return this.http.get<RawStockTake[]>(`${this.base}/raw-stock-takes`);
  }

  /**
   * Reviewer note: Centralises the create stock take service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createStockTake(request: object): Observable<RawStockTake> {
    return this.http.post<RawStockTake>(
      `${this.base}/raw-stock-takes`, request);
  }

  /**
   * Reviewer note: Centralises the save count service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  saveCount(sessionId: number, lineId: number, request: object):
      Observable<RawStockTake> {
    return this.http.put<RawStockTake>(
      `${this.base}/raw-stock-takes/${sessionId}/lines/${lineId}/count`,
      request);
  }

  /**
   * Reviewer note: Centralises the submit stock take service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  submitStockTake(id: number, rowVersion: string):
      Observable<RawStockTake> {
    return this.http.post<RawStockTake>(
      `${this.base}/raw-stock-takes/${id}/submit`, { rowVersion });
  }

  /**
   * Reviewer note: Centralises the review stock take service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  reviewStockTake(id: number, request: object): Observable<RawStockTake> {
    return this.http.post<RawStockTake>(
      `${this.base}/raw-stock-takes/${id}/review`, request);
  }

  /**
   * Reviewer note: Centralises the decide stock take service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  decideStockTake(id: number, request: object): Observable<RawStockTake> {
    return this.http.post<RawStockTake>(
      `${this.base}/raw-stock-takes/${id}/decision`, request);
  }

  /**
   * Reviewer note: Centralises the write offs service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  writeOffs(): Observable<RawStockWriteOff[]> {
    return this.http.get<RawStockWriteOff[]>(
      `${this.base}/raw-stock-write-offs`);
  }

  /**
   * Reviewer note: Centralises the create write off service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createWriteOff(request: object): Observable<RawStockWriteOff> {
    return this.http.post<RawStockWriteOff>(
      `${this.base}/raw-stock-write-offs`, request);
  }

  /**
   * Reviewer note: Centralises the decide write off service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  decideWriteOff(id: number, request: object):
      Observable<RawStockWriteOff> {
    return this.http.post<RawStockWriteOff>(
      `${this.base}/raw-stock-write-offs/${id}/decision`, request);
  }

  /**
   * Reviewer note: Centralises the customers service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  customers(search = '', includeInactive = false):
      Observable<CustomerSummary[]> {
    let params = new HttpParams().set('includeInactive', includeInactive);
    if (search.trim()) params = params.set('search', search.trim());
    return this.http.get<CustomerSummary[]>(
      `${this.base}/operational/customers`, { params });
  }

  /**
   * Reviewer note: Centralises the delete raw stock service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteRawStock(id: number, reason: string): Observable<PartyDeleteResult> {
    return this.http.post<PartyDeleteResult>(
      `${this.base}/raw-stock/${id}/delete`, { reason });
  }

  /**
   * Reviewer note: Centralises the change raw stock status service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  changeRawStockStatus(
    id: number,
    isActive: boolean,
    reason: string
  ): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(
      `${this.base}/raw-stock/${id}/status`,
      { isActive, reason });
  }

  /**
   * Reviewer note: Centralises the customer service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  customer(id: number): Observable<CustomerSummary> {
    return this.http.get<CustomerSummary>(
      `${this.base}/operational/customers/${id}`);
  }

  /**
   * Reviewer note: Centralises the save customer service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  saveCustomer(id: number | null, request: object):
      Observable<CustomerSummary> {
    return id
      ? this.http.put<CustomerSummary>(
          `${this.base}/operational/customers/${id}`, request)
      : this.http.post<CustomerSummary>(
          `${this.base}/operational/customers`, request);
  }

  /**
   * Reviewer note: Centralises the delete customer service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteCustomer(id: number, reason: string, rowVersion: string):
      Observable<PartyDeleteResult> {
    return this.http.post<PartyDeleteResult>(
      `${this.base}/operational/customers/${id}/delete`,
      { reason, rowVersion });
  }

  /**
   * Reviewer note: Centralises the suppliers service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  suppliers(search = '', includeInactive = false):
      Observable<SupplierSummary[]> {
    let params = new HttpParams().set('includeInactive', includeInactive);
    if (search.trim()) params = params.set('search', search.trim());
    return this.http.get<SupplierSummary[]>(
      `${this.base}/operational/suppliers`, { params });
  }

  /**
   * Reviewer note: Centralises the save supplier service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  saveSupplier(id: number | null, request: object):
      Observable<SupplierSummary> {
    return id
      ? this.http.put<SupplierSummary>(
          `${this.base}/operational/suppliers/${id}`, request)
      : this.http.post<SupplierSummary>(
          `${this.base}/operational/suppliers`, request);
  }

  /**
   * Reviewer note: Centralises the delete supplier service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  deleteSupplier(id: number, reason: string, rowVersion: string):
      Observable<PartyDeleteResult> {
    return this.http.post<PartyDeleteResult>(
      `${this.base}/operational/suppliers/${id}/delete`,
      { reason, rowVersion });
  }

  /**
   * Reviewer note: Centralises the supplier orders service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  supplierOrders(): Observable<SupplierOrder[]> {
    return this.http.get<SupplierOrder[]>(`${this.base}/supplier-orders`);
  }

  supplierOrderRawStockOptions(): Observable<SupplierOrderRawStockOption[]> {
    return this.http.get<SupplierOrderRawStockOption[]>(
      `${this.base}/supplier-orders/raw-stock-options`);
  }

  /**
   * Reviewer note: Centralises the create supplier order service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  createSupplierOrder(request: object): Observable<SupplierOrder> {
    return this.http.post<SupplierOrder>(
      `${this.base}/supplier-orders`, request);
  }

  /**
   * Reviewer note: Centralises the approve supplier order service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  approveSupplierOrder(id: number, rowVersion: string):
      Observable<SupplierOrder> {
    return this.http.post<SupplierOrder>(
      `${this.base}/supplier-orders/${id}/place`, { rowVersion });
  }

  /**
   * Reviewer note: Centralises the update supplier order service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  updateSupplierOrder(
    id: number,
    rowVersion: string,
    request: object
  ): Observable<SupplierOrder> {
    return this.http.put<SupplierOrder>(
      `${this.base}/supplier-orders/${id}`,
      request,
      { params: new HttpParams().set('rowVersion', rowVersion) });
  }

  /**
   * Reviewer note: Calculates cancel supplier order for client presentation and routing.
   * This result improves UX but never substitutes for the backend permission check.
   */
  cancelSupplierOrder(
    id: number,
    rowVersion: string,
    reason: string
  ): Observable<SupplierOrder> {
    return this.http.post<SupplierOrder>(
      `${this.base}/supplier-orders/${id}/cancel`,
      { rowVersion, reason });
  }

  /**
   * Reviewer note: Centralises the payments service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  payments(options: PaymentSearchOptions = {}): Observable<FinancialPayment[]> {
    let params = new HttpParams();
    for (const [key, value] of Object.entries(options)) {
      if (value) params = params.set(key, value);
    }
    return this.http.get<FinancialPayment[]>(
      `${this.base}/financial-payments`, { params });
  }

  /**
   * Reviewer note: Centralises the payment capture options service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  paymentCaptureOptions(): Observable<PaymentCaptureOptions> {
    return this.http.get<PaymentCaptureOptions>(
      `${this.base}/financial-payments/capture-options`);
  }

  /**
   * Reviewer note: Centralises the capture payment service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  capturePayment(request: object): Observable<FinancialPayment> {
    return this.http.post<FinancialPayment>(
      `${this.base}/financial-payments`, request);
  }

  /**
   * Reviewer note: Centralises the request payment reversal service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  requestPaymentReversal(id: number, request: object):
      Observable<FinancialPayment> {
    return this.http.post<FinancialPayment>(
      `${this.base}/financial-payments/${id}/request-reversal`, request);
  }

  /**
   * Reviewer note: Centralises the decide payment reversal service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  decidePaymentReversal(
    id: number,
    approved: boolean,
    request: object
  ): Observable<FinancialPayment> {
    return this.http.post<FinancialPayment>(
      `${this.base}/financial-payments/${id}/reversal-decision`,
      request,
      { params: new HttpParams().set('approved', approved) });
  }

  /**
   * Reviewer note: Centralises the dashboard service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  dashboard(fromUtc?: string, toUtc?: string):
      Observable<ManagementDashboard> {
    let params = new HttpParams();
    if (fromUtc) params = params.set('fromUtc', fromUtc);
    if (toUtc) params = params.set('toUtc', toUtc);
    return this.http.get<ManagementDashboard>(
      `${this.base}/management-dashboard`, { params });
  }
}
