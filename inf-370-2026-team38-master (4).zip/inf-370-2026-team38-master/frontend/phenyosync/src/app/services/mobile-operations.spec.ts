/**
 * Reviewer guide: Verifies the mobile operations frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { MobileOperationsService } from './mobile-operations';

// Covers the mobile operations behavior most likely to regress across permissions and workflow changes.
describe('MobileOperationsService', () => {
  let http: HttpTestingController;
  let service: MobileOperationsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    http = TestBed.inject(HttpTestingController);
    service = TestBed.inject(MobileOperationsService);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that loads the management dashboard from the mobile API.
  it('loads the management dashboard from the mobile API', () => {
    service.dashboard().subscribe();
    const request = http.expectOne(`${environment.apiUrl}/mobile/dashboard`);
    expect(request.request.method).toBe('GET');
    request.flush({});
  });

  // Reviewer note: Guards the observable rule that loads active tracking sessions without client-side driver filtering.
  it('loads active tracking sessions without client-side driver filtering', () => {
    service.activeTracking().subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/mobile/tracking/active`);
    expect(request.request.method).toBe('GET');
    request.flush([]);
  });

  // Reviewer note: Guards the observable rule that loads the authorised route history for a tracking session.
  it('loads the authorised route history for a tracking session', () => {
    service.trackingHistory(42).subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/mobile/tracking/sessions/42/locations`);
    expect(request.request.method).toBe('GET');
    request.flush([]);
  });

  // Reviewer note: Guards the observable rule that confirms dispatch with a reason and idempotency operation id.
  it('confirms dispatch with a reason and idempotency operation id', () => {
    service.confirmDispatch(28, 'Vehicle and load checked.').subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/mobile/dispatch/28/confirm`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body.reason).toBe('Vehicle and load checked.');
    expect(request.request.body.operationId).toBeTruthy();
    request.flush({});
  });

  // Reviewer note: Guards the observable rule that requests approval-only write-offs from the server.
  it('requests approval-only write-offs from the server', () => {
    service.writeOffs(true).subscribe();
    const request = http.expectOne(pending =>
      pending.url === `${environment.apiUrl}/mobile/write-offs` &&
      pending.params.get('approvalsOnly') === 'true');
    expect(request.request.method).toBe('GET');
    request.flush([]);
  });

  // Reviewer note: Guards the observable rule that sends a write-off decision with its management reason.
  it('sends a write-off decision with its management reason', () => {
    service.decideWriteOff(12, false, 'Photo is unclear.').subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/mobile/write-offs/12/reject`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body.reason).toBe('Photo is unclear.');
    expect(request.request.body.operationId).toBeTruthy();
    request.flush({});
  });
});
