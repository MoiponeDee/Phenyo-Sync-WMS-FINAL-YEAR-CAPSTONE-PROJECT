/**
 * Reviewer guide: Verifies the order frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { CreateOrderRequest, OrderService } from './order';

// Covers the order behavior most likely to regress across permissions and workflow changes.
describe('OrderService', () => {
  let service: OrderService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });

    service = TestBed.inject(OrderService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that submits a server-priced order without client totals.
  it('submits a server-priced order without client totals', () => {
    const request: CreateOrderRequest = {
      customerId: 7,
      deliveryAddress: '1 Market Street',
      billingAddress: '1 Market Street',
      items: [{ productId: 3, quantityUnits: 5 }]
    };

    service.create(request).subscribe();

    const pending = http.expectOne(`${environment.apiUrl}/orders`);
    expect(pending.request.method).toBe('POST');
    expect(pending.request.body).toEqual(request);
    expect(pending.request.body.totalAmount).toBeUndefined();
    pending.flush({ message: 'Created', order: {} });
  });

  // Reviewer note: Guards the observable rule that sends explicit cancellation confirmation and reason.
  it('sends explicit cancellation confirmation and reason', () => {
    service.cancel(12, 'Customer requested cancellation', 'SO-2026-000012').subscribe();

    const pending = http.expectOne(`${environment.apiUrl}/orders/12/cancel`);
    expect(pending.request.method).toBe('POST');
    expect(pending.request.body).toEqual({
      reason: 'Customer requested cancellation',
      confirmationText: 'SO-2026-000012',
      confirmed: true
    });
    pending.flush({ message: 'Cancelled', order: {} });
  });

  // Reviewer note: Guards the observable rule that filters the packing queue without sending an empty query.
  it('filters the packing queue without sending an empty query', () => {
    service.getPackingQueue('  apple  ').subscribe();

    const pending = http.expectOne(request =>
      request.url === `${environment.apiUrl}/orders/packing-list` &&
      request.params.get('searchTerm') === 'apple'
    );
    expect(pending.request.method).toBe('GET');
    pending.flush([]);
  });
});
