/**
 * Reviewer guide: Centralises pricing HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export type PriceRecordStatus =
  'Current' | 'Scheduled' | 'Historical' | 'Deleted' | 'All';

export type PriceBasis = 'PerKilogram' | 'PerSellableUnit';

export interface ProductPrice {
  productPriceId: number;
  productId: number;
  productCode: string;
  productName: string;
  productTypeName: string;
  productCategoryName: string;
  size: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  productStatus: 'Active' | 'Inactive';
  sellingPrice: number;
  priceBasis: PriceBasis;
  effectiveFromUtc: string;
  effectiveToUtc?: string;
  isCurrent: boolean;
  isScheduled: boolean;
  isDeleted: boolean;
  createdAtUtc: string;
  createdBy?: string;
  changeReason?: string;
  deletedAtUtc?: string;
  deletedBy?: string;
  deleteReason?: string;
  linkedOrderCount: number;
  isCommitted: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  canSoftDelete: boolean;
  deleteBlockedReason?: string;
  // Reviewer note: Carries the server concurrency token so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database.
  rowVersion: string;
}

export interface PriceSearchFilters {
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  searchTerm?: string;
  productId?: number | null;
  productTypeId?: number | null;
  productCategoryId?: number | null;
  minimumPrice?: number | null;
  maximumPrice?: number | null;
  status?: PriceRecordStatus;
  page?: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize?: number;
}

export interface ProductPricePage {
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  items: ProductPrice[];
  page: number;
  // Reviewer note: Stores current view criteria passed through the typed service when data is refreshed.
  // The server validates identifiers, ranges, and permissions.
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

export interface OrderableProduct {
  productId: number;
  productPriceId: number;
  productCode: string;
  productName: string;
  productTypeName: string;
  productCategoryName: string;
  size: string;
  sellingPrice: number;
  sellingPricePerUnit: number | null;
  priceBasis: PriceBasis;
  sellingUnit: string;
  kilogramsPerUnit?: number;
  isVariableWeight: boolean;
  availableQuantityKg: number;
}

export interface PriceChangeResult {
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  previousPrice?: ProductPrice;
  currentPrice: ProductPrice;
}

@Injectable({ providedIn: 'root' })
/** Typed client for effective-dated product prices and pricing history. */
export class PricingService {
  private readonly apiUrl = `${environment.apiUrl}/prices`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the search service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  search(filters: PriceSearchFilters): Observable<ProductPricePage> {
    let params = new HttpParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && `${value}`.trim()) {
        params = params.set(key, `${value}`);
      }
    });
    return this.http.get<ProductPricePage>(this.apiUrl, { params });
  }

  /**
   * Reviewer note: Centralises the get service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  get(id: number): Observable<ProductPrice> {
    return this.http.get<ProductPrice>(`${this.apiUrl}/${id}`);
  }

  /**
   * Reviewer note: Centralises the get history service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getHistory(productId: number): Observable<ProductPrice[]> {
    return this.http.get<ProductPrice[]>(`${this.apiUrl}/product/${productId}/history`);
  }

  /**
   * Reviewer note: Centralises the get orderable products service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  getOrderableProducts(): Observable<OrderableProduct[]> {
    return this.http.get<OrderableProduct[]>(`${this.apiUrl}/orderable-products`);
  }

  /**
   * Reviewer note: Centralises the create service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  create(
    productId: number,
    sellingPrice: number,
    priceBasis: PriceBasis,
    effectiveFromUtc: string,
    reason?: string
  ):
    Observable<{ message: string; price: ProductPrice }> {
    return this.http.post<{ message: string; price: ProductPrice }>(this.apiUrl, {
      productId,
      sellingPrice,
      priceBasis,
      effectiveFromUtc,
      reason
    });
  }

  /**
   * Reviewer note: Centralises the update service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  update(
    id: number,
    sellingPrice: number,
    priceBasis: PriceBasis,
    effectiveFromUtc: string,
    changeReason?: string,
    rowVersion?: string
  ):
    Observable<PriceChangeResult> {
    return this.http.put<PriceChangeResult>(`${this.apiUrl}/${id}`, {
      sellingPrice,
      priceBasis,
      effectiveFromUtc,
      changeReason,
      rowVersion
    });
  }

  /**
   * Reviewer note: Centralises the soft delete service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  softDelete(id: number, reason: string):
    Observable<{ message: string; price: ProductPrice }> {
    return this.http.post<{ message: string; price: ProductPrice }>(
      `${this.apiUrl}/${id}/soft-delete`,
      { confirmed: true, reason }
    );
  }
}
