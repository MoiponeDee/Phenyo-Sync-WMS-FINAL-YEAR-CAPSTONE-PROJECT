/**
 * Reviewer guide: Centralises operations calendar HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface OperationsCalendarEvent {
  eventId: string;
  eventType: 'Delivery' | 'Order' | 'Expiry';
  title: string;
  startUtc: string;
  endUtc: string;
  allDay: boolean;
  status: string;
  riskLevel: string;
  detailRoute: string;
  accessibleLabel: string;
  deliveryId?: number;
  salesOrderId?: number;
  productBatchId?: number;
  driverId?: number;
}

export interface OperationsCalendarResponse {
  startUtc: string;
  endUtc: string;
  defaultView: 'month' | 'week' | 'day' | 'agenda';
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  events: OperationsCalendarEvent[];
}

@Injectable({ providedIn: 'root' })
/** Loads read-only operational milestones for the shared calendar view. */
export class OperationsCalendarService {
  private readonly apiUrl = `${environment.apiUrl}/operations-calendar/events`;

  /**
   * Reviewer note: Injects HttpClient and related collaborators once so request construction stays centralised and testable.
   * Components depend on this typed service instead of duplicating URLs, headers or DTO handling.
   */
  constructor(private http: HttpClient) {}

  /**
   * Reviewer note: Centralises the events service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  events(filters: Record<string, string | number | null | undefined>): Observable<OperationsCalendarResponse> {
    let params = new HttpParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== '') {
        params = params.set(key, value);
      }
    });
    return this.http.get<OperationsCalendarResponse>(this.apiUrl, { params });
  }
}
