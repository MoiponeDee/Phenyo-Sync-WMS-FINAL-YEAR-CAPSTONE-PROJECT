/**
 * Reviewer guide: Centralises dashboard route HTTP and DTO coordination so pages do not duplicate API contracts.
 * Client checks improve feedback; the API remains authoritative for permissions and business rules.
 */
import { Injectable } from '@angular/core';

const ROLE_DASHBOARDS: Readonly<Record<string, string>> = {
  Admin: '/dashboard',
  Administrator: '/dashboard',
  Packer: '/dashboard',
  Driver: '/dashboard',
  WarehouseManager: '/dashboard',
  MarketBuyer: '/dashboard',
  BusinessManager: '/dashboard',
  OperationsManager: '/dashboard',
  AdminClerk: '/dashboard',
  Buyer: '/dashboard',
  CEO: '/dashboard',
  COO: '/dashboard'
};

@Injectable({ providedIn: 'root' })
/** Selects the first dashboard route permitted by the backend authorization snapshot. */
export class DashboardRouteService {
  /**
   * Reviewer note: Centralises the for role service operation so components share one typed session/API boundary.
   * The backend validates authorization, data integrity, concurrency and workflow transitions.
   */
  forRole(role?: string | null): string {
    const normalized = role?.trim();
    return normalized
      ? ROLE_DASHBOARDS[normalized] ?? '/dashboard'
      : '/dashboard';
  }
}
