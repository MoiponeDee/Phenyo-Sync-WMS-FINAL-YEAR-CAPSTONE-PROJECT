/**
 * Reviewer guide: Verifies the buying lists frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { BuyingListService } from './buying-lists';

// Covers the buying lists behavior most likely to regress across permissions and workflow changes.
describe('Buying List management API', () => {
  let http: HttpTestingController;
  let service: BuyingListService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    http = TestBed.inject(HttpTestingController);
    service = TestBed.inject(BuyingListService);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that uses server-side search, status and buyer filters.
  it('uses server-side search, status and buyer filters', () => {
    service.search({
      search: 'carrot',
      status: 'Open',
      assignedBuyerUserId: 12,
      page: 2,
      pageSize: 25
    }).subscribe();

    const request = http.expectOne(pending =>
      pending.url === `${environment.apiUrl}/buying-lists` &&
      pending.params.get('search') === 'carrot' &&
      pending.params.get('status') === 'Open' &&
      pending.params.get('assignedBuyerUserId') === '12' &&
      pending.params.get('page') === '2' &&
      pending.params.get('pageSize') === '25');
    expect(request.request.method).toBe('GET');
    request.flush({ items: [], page: 2, pageSize: 25, total: 0 });
  });

  // Reviewer note: Guards the observable rule that creates a database-backed draft with its line items.
  it('creates a database-backed draft with its line items', () => {
    const payload = {
      buyingDateUtc: '2026-07-31T00:00:00.000Z',
      title: 'Fresh produce buying list',
      priority: 'Urgent',
      notes: 'Morning market collection.',
      assignedBuyerUserId: 12,
      items: [
        {
          rawStockItemId: 9,
          recommendedQuantity: 8,
          requiredQuantity: 10,
          unitOfMeasure: 'kg',
          priority: 'Urgent',
          managementNotes: 'Select good quality stock.'
        }
      ]
    };

    service.create(payload).subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/buying-lists`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(payload);
    request.flush({});
  });

  // Reviewer note: Guards the observable rule that preserves concurrency and reason data when publishing.
  it('preserves concurrency and reason data when publishing', () => {
    service.publish(18, 'row-version', 'Ready for purchasing.').subscribe();
    const request = http.expectOne(
      `${environment.apiUrl}/buying-lists/18/publish`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({
      rowVersion: 'row-version',
      reason: 'Ready for purchasing.'
    });
    request.flush({});
  });

  // Reviewer note: Guards the observable rule that uses an explicit DELETE body for a draft-line removal.
  it('uses an explicit DELETE body for a draft-line removal', () => {
    service.removeLine(
      18,
      4,
      'row-version',
      'The quantity is no longer required.'
    ).subscribe();

    const request = http.expectOne(
      `${environment.apiUrl}/buying-lists/18/items/4`);
    expect(request.request.method).toBe('DELETE');
    expect(request.request.body).toEqual({
      rowVersion: 'row-version',
      reason: 'The quantity is no longer required.'
    });
    request.flush({});
  });
});
