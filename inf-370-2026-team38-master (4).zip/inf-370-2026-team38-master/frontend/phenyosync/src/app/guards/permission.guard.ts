/**
 * Reviewer guide: Applies the permission guard client-side access policy before protected UI work begins.
 * This is defence-in-depth for navigation; backend authorization remains the actual security boundary.
 */
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { catchError, map, of } from 'rxjs';
import { AuthorizationService } from '../services/authorization';
import { WMS_NAVIGATION } from '../navigation/navigation.config';

function requiredPermissions(route: Parameters<CanActivateFn>[0]): string[] | null {
  const configured = (route.data['permissions'] as string[] | undefined) ??
    (route.data['permission'] ? [route.data['permission'] as string] : []);

  if (configured.length > 0) {
    return configured;
  }

  if (route.routeConfig?.path !== 'workspace/:section') {
    return [];
  }

  // Generic workspace routes inherit the union of permissions from their navigation section.
  const section = WMS_NAVIGATION.find(item =>
    item.key === route.paramMap.get('section'));

  if (!section) {
    return null;
  }

  if (section.items.some(item => !item.permissions?.length)) {
    return [];
  }

  return [...new Set(section.items.flatMap(item => item.permissions ?? []))];
}

// Resolve the required route permissions from the latest backend-derived snapshot before navigation.
// Redirecting here improves UX; only the API permission attribute prevents a manually issued request.
export const permissionGuard: CanActivateFn = (route, state) => {
  const authorization = inject(AuthorizationService);
  const router = inject(Router);
  const required = requiredPermissions(route);

  // Refresh before every guarded navigation so stale browser role data cannot grant a route.
  return authorization.refresh().pipe(
    /**
     * Reviewer note: Evaluates map before navigation so protected screens are not presented without the required session state.
     * This is defence-in-depth; the backend permission policy remains the actual security boundary.
     */
    map(() => {
      if (required !== null &&
          (required.length === 0 || required.some(code => authorization.has(code)))) {
        return true;
      }

      return router.createUrlTree(['/access-denied'], {
        queryParams: { returnUrl: state.url }
      });
    }),
    /**
     * Reviewer note: Evaluates catch error before navigation so protected screens are not presented without the required session state.
     * This is defence-in-depth; the backend permission policy remains the actual security boundary.
     */
    catchError(() => of(router.createUrlTree(['/login'], {
      queryParams: { returnUrl: state.url }
    })))
  );
};
