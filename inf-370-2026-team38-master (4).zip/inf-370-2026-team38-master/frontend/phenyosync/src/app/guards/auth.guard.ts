/**
 * Reviewer guide: Applies the auth guard client-side access policy before protected UI work begins.
 * This is defence-in-depth for navigation; backend authorization remains the actual security boundary.
 */
import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';

export const authGuard: CanActivateFn = (_route, state) => {
  const router = inject(Router);

  // This is an early navigation check only; the API still validates the JWT and live account.
  const token = localStorage.getItem('token');

  if (token) {
    return true;
  }

  return router.createUrlTree(['/login'], {
    queryParams: { returnUrl: state.url }
  });
};
