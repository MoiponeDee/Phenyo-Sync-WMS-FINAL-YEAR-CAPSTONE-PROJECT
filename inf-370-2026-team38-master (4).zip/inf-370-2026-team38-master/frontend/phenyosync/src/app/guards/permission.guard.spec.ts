/**
 * Reviewer guide: Verifies the permission guard frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TestBed } from '@angular/core/testing';
import {
  ActivatedRouteSnapshot,
  Router,
  RouterStateSnapshot,
  provideRouter
} from '@angular/router';
import { Observable, firstValueFrom, of } from 'rxjs';
import { permissionGuard } from './permission.guard';
import {
  AuthorizationService,
  AuthorizationSession
} from '../services/authorization';

class AuthorizationStub {
  allowed = false;
  requestedPermissions: string[] = [];

  refresh(): Observable<AuthorizationSession> {
    return of({
      userId: 9,
      email: 'packer@example.test',
      role: 'Packer',
      roleCode: 'Packer',
      isActive: true,
      permissions: []
    });
  }

  has(permission: string): boolean {
    this.requestedPermissions.push(permission);
    return this.allowed;
  }
}

// Protects against stale/local role data granting a route without a fresh permission snapshot.
describe('permissionGuard', () => {
  let authorization: AuthorizationStub;
  let router: Router;

  beforeEach(() => {
    authorization = new AuthorizationStub();
    TestBed.configureTestingModule({
      providers: [
        provideRouter([]),
        {
          provide: AuthorizationService,
          useValue: authorization
        }
      ]
    });
    router = TestBed.inject(Router);
  });

  // Reviewer note: Guards the observable rule that allows a route when the effective permission is present.
  it('allows a route when the effective permission is present', async () => {
    authorization.allowed = true;

    const result = TestBed.runInInjectionContext(() =>
      permissionGuard(
        {
          data: { permission: 'Products.Make' }
        } as unknown as ActivatedRouteSnapshot,
        {
          url: '/make-product'
        } as RouterStateSnapshot
      )
    );

    expect(await firstValueFrom(
      result as Observable<boolean>
    )).toBe(true);
  });

  // Reviewer note: Guards the observable rule that redirects a denied route to the dedicated access-denied page.
  it('redirects a denied route to the dedicated access-denied page', async () => {
    const result = TestBed.runInInjectionContext(() =>
      permissionGuard(
        {
          data: { permission: 'Users.View' }
        } as unknown as ActivatedRouteSnapshot,
        {
          url: '/manage-users'
        } as RouterStateSnapshot
      )
    );

    const denied = await firstValueFrom(
      result as Observable<ReturnType<Router['parseUrl']>>
    );

    expect(router.serializeUrl(denied))
      .toBe('/access-denied?returnUrl=%2Fmanage-users');
  });

  // Reviewer note: Guards the observable rule that requires at least one child permission for a workspace route.
  it('requires at least one child permission for a workspace route', async () => {
    const result = TestBed.runInInjectionContext(() =>
      permissionGuard(
        {
          routeConfig: { path: 'workspace/:section' },
          data: {},
          paramMap: {
            get: () => 'warehouse-operations'
          }
        } as unknown as ActivatedRouteSnapshot,
        {
          url: '/workspace/warehouse-operations'
        } as RouterStateSnapshot
      )
    );

    const denied = await firstValueFrom(
      result as Observable<ReturnType<Router['parseUrl']>>
    );

    expect(router.serializeUrl(denied))
      .toBe('/access-denied?returnUrl=%2Fworkspace%2Fwarehouse-operations');
    expect(authorization.requestedPermissions)
      .toContain('RawStock.View');
  });
});
