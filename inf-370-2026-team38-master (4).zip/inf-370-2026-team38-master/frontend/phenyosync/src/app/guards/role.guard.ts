/**
 * Reviewer guide: Applies the role guard client-side access policy before protected UI work begins.
 * This is defence-in-depth for navigation; backend authorization remains the actual security boundary.
 */
import { permissionGuard } from './permission.guard';

/**
 * Backwards-compatible alias for older imports.
 * Authorization is permission-based and is always confirmed by the API.
 */
export const roleGuard = permissionGuard;
