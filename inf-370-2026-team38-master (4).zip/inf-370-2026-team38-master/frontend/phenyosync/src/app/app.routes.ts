/**
 * Reviewer guide: Defines app routes routing and visibility from authenticated role/permission state.
 * Hidden links and route guards improve UX, but the API independently rejects unauthorised calls.
 */
import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';
import { permissionGuard } from './guards/permission.guard';
import { AuditLogs } from './pages/audit-logs/audit-logs';
import { CompleteDelivery } from './pages/complete-delivery/complete-delivery';
import { DeleteProduct } from './pages/delete-product/delete-product';
import { DeliveryDetails } from './pages/delivery-details/delivery-details';
import { DeliveryManagement } from './pages/delivery-management/delivery-management';
import { DeliveryProof } from './pages/delivery-proof/delivery-proof';
import { ExpiryAction } from './pages/expiry-action/expiry-action';
import { ExpiryAlerts } from './pages/expiry-alerts/expiry-alerts';
import { LoginComponent } from './pages/login/login';
import { AccountSecurity } from './pages/account-security/account-security';
import { HelpCenter } from './pages/help-center/help-center';
import { MakeProduct } from './pages/make-product/make-product';
import { ManagePermissions } from './pages/manage-permissions/manage-permissions';
import { ManageLookups } from './pages/manage-lookups/manage-lookups';
import { ManageHelp } from './pages/manage-help/manage-help';
import { ManageHelpMedia } from './pages/manage-help-media/manage-help-media';
import { ManageProductCategories } from './pages/manage-product-categories/manage-product-categories';
import { ManageProductTypes } from './pages/manage-product-types/manage-product-types';
import { ManageRoles } from './pages/manage-roles/manage-roles';
import { ManageSystemSettings } from './pages/manage-system-settings/manage-system-settings';
import { ManageUsers } from './pages/manage-users/manage-users';
import { ManageWarehouseSections } from './pages/manage-warehouse-sections/manage-warehouse-sections';
import { MyDeliveries } from './pages/my-deliveries/my-deliveries';
import { OrderInvoice } from './pages/order-invoice/order-invoice';
import { PackingOrders } from './pages/packing-orders/packing-orders';
import { PricingManagement } from './pages/pricing-management/pricing-management';
import { ProductDataExchange } from './pages/product-data-exchange/product-data-exchange';
import { ProductHierarchy } from './pages/product-hierarchy/product-hierarchy';
import { ProductDetails } from './pages/product-details/product-details';
import { ScanProductBatch } from './pages/scan-product-batch/scan-product-batch';
import { SearchOrders } from './pages/search-orders/search-orders';
import { SearchProduct } from './pages/search-product/search-product';
import { StockCountDataExchange } from './pages/stock-count-data-exchange/stock-count-data-exchange';
import { UpdateProductStatus } from './pages/update-product-status/update-product-status';
import { UpdateProduct } from './pages/update-product/update-product';
import { AppShell } from './components/app-shell/app-shell';
import { WorkspaceLanding } from './pages/workspace-landing/workspace-landing';

// Apply authentication and effective-permission checks consistently to protected pages.
// These guards control navigation convenience; every API endpoint enforces its own policy.
const protectedBy = (permission: string | string[]) => ({
  canActivate: [authGuard, permissionGuard],
  data: Array.isArray(permission)
    ? { permissions: permission }
    : { permission }
});

const applicationRoutes: Routes = [
  // Shared account and help routes require a valid session, with permissions added where the feature needs one.
  {
    path: 'dashboard',
    loadComponent: () => import('./pages/role-dashboard/role-dashboard')
      .then(module => module.RoleDashboard),
    ...protectedBy('Dashboards.View')
  },
  {
    path: 'access-denied',
    loadComponent: () => import('./pages/access-denied/access-denied')
      .then(module => module.AccessDenied),
    canActivate: [authGuard]
  },
  { path: 'workspace/:section', component: WorkspaceLanding, canActivate: [authGuard, permissionGuard] },
  { path: 'help', component: HelpCenter, ...protectedBy('Help.View') },
  { path: 'help/:slug', component: HelpCenter, ...protectedBy('Help.View') },
  { path: 'account-security', component: AccountSecurity, canActivate: [authGuard] },
  {
    path: 'profile',
    loadComponent: () => import('./pages/profile/profile')
      .then(module => module.Profile),
    canActivate: [authGuard]
  },
  {
    path: 'profile/edit',
    loadComponent: () => import('./pages/profile/profile')
      .then(module => module.Profile),
    data: { edit: true },
    canActivate: [authGuard]
  },
  { path: 'manage-help', component: ManageHelp, ...protectedBy('Help.Manage') },
  { path: 'manage-help-media', component: ManageHelpMedia, ...protectedBy('HelpMedia.Manage') },

  // Legacy role-specific URLs converge on the database-backed dashboard without duplicating dashboard logic.
  { path: 'admin-dashboard', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'packer-dashboard', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'driver-dashboard', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'stocktaker-dashboard', redirectTo: 'dashboard', pathMatch: 'full' },
  {
    path: 'buyer-dashboard',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: 'management-dashboard',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  // Operational directories are lazy-loaded and each route declares the least permission needed to enter it.
  {
    path: 'raw-stock',
    loadComponent: () => import('./pages/raw-stock/raw-stock')
      .then(module => module.RawStockComponent),
    ...protectedBy('RawStock.View')
  },
  {
    path: 'raw-stock/approvals',
    loadComponent: () => import('./pages/raw-stock/raw-stock')
      .then(module => module.RawStockComponent),
    ...protectedBy([
      'RawStockTakes.View',
      'RawStock.ApproveWriteOff'])
  },
  {
    path: 'buying-lists',
    loadComponent: () => import('./pages/buying-lists/buying-lists')
      .then(module => module.BuyingListsComponent),
    ...protectedBy('BuyingList.View')
  },
  {
    path: 'customers',
    loadComponent: () => import('./pages/customers/customers')
      .then(module => module.CustomersComponent),
    ...protectedBy('Customers.View')
  },
  {
    path: 'customers/create',
    loadComponent: () => import('./pages/customer-form/customer-form')
      .then(module => module.CustomerForm),
    ...protectedBy('Customers.Manage')
  },
  {
    path: 'customers/:id/edit',
    loadComponent: () => import('./pages/customer-form/customer-form')
      .then(module => module.CustomerForm),
    ...protectedBy('Customers.Manage')
  },
  {
    path: 'customers/:id',
    loadComponent: () => import('./pages/customer-details/customer-details')
      .then(module => module.CustomerDetails),
    ...protectedBy('Customers.View')
  },
  {
    path: 'suppliers',
    loadComponent: () => import('./pages/suppliers/suppliers')
      .then(module => module.SuppliersComponent),
    ...protectedBy('Suppliers.View')
  },
  {
    path: 'payments',
    loadComponent: () => import('./pages/payments/payments')
      .then(module => module.PaymentsComponent),
    ...protectedBy([
      'CustomerPayments.View',
      'SupplierPayments.View',
      'Payments.View'
    ])
  },

  // Administration pages remain independently guarded because their permissions are intentionally separable.
  { path: 'manage-users', component: ManageUsers, ...protectedBy('Users.View') },
  { path: 'manage-roles', component: ManageRoles, ...protectedBy('Roles.View') },
  { path: 'manage-permissions', component: ManagePermissions, ...protectedBy('Permissions.View') },
  { path: 'manage-lookups', component: ManageLookups, ...protectedBy('Lookups.View') },
  { path: 'manage-warehouse-sections', component: ManageWarehouseSections, ...protectedBy('WarehouseSections.View') },
  { path: 'manage-system-settings', component: ManageSystemSettings, ...protectedBy('SystemSettings.View') },
  { path: 'make-product', component: MakeProduct, ...protectedBy('Products.Make') },
  { path: 'search-product', component: SearchProduct, ...protectedBy('Products.View') },
  { path: 'update-product', component: UpdateProduct, ...protectedBy('Products.Update') },
  { path: 'delete-product', component: DeleteProduct, ...protectedBy('Products.Delete') },
  { path: 'update-product-status', component: UpdateProductStatus, ...protectedBy('Products.ChangeStatus') },
  { path: 'expiry-alerts', component: ExpiryAlerts, ...protectedBy('Expiry.View') },
  { path: 'expiry-action', component: ExpiryAction, ...protectedBy('Expiry.Resolve') },
  { path: 'manage-product-types', component: ManageProductTypes, ...protectedBy('ProductTypes.Manage') },
  { path: 'manage-product-categories', component: ManageProductCategories, ...protectedBy('ProductCategories.Manage') },
  { path: 'product-hierarchy', component: ProductHierarchy, ...protectedBy('ProductHierarchy.View') },
  {
    path: 'add-product',
    loadComponent: () => import('./pages/add-product/add-product').then(module => module.AddProduct),
    ...protectedBy('ProductHierarchy.Manage')
  },
  { path: 'products/:id/details', component: ProductDetails, ...protectedBy('Products.View') },
  {
    path: 'product-data-exchange',
    component: ProductDataExchange,
    ...protectedBy(['ProductDataExchange.Export', 'ProductDataExchange.Import'])
  },
  {
    path: 'stock-count-data-exchange',
    component: StockCountDataExchange,
    ...protectedBy(['StockCountExchange.Export', 'StockCountExchange.Import'])
  },
  {
    path: 'operations-calendar',
    loadComponent: () => import('./pages/operations-calendar/operations-calendar')
      .then(module => module.OperationsCalendar),
    ...protectedBy('OperationsCalendar.View')
  },
  {
    path: 'mobile-operations-control',
    loadComponent: () =>
      import('./pages/mobile-operations-control/mobile-operations-control')
        .then(module => module.MobileOperationsControl),
    ...protectedBy('Mobile.Tracking.ViewAll')
  },
  { path: 'scan-product-batch', component: ScanProductBatch, ...protectedBy('ProductBatchScanner.View') },

  // Order routes reuse editor/detail pages while route metadata identifies the exact permitted workflow action.
  {
    path: 'order-management',
    loadComponent: () => import('./pages/order-management/order-management')
      .then(module => module.OrderManagement),
    ...protectedBy('Orders.View')
  },
  {
    path: 'send-order-link',
    loadComponent: () => import('./pages/send-order-link/send-order-link')
      .then(module => module.SendOrderLink),
    ...protectedBy('Orders.SendLink')
  },
  {
    path: 'create-order',
    loadComponent: () => import('./pages/order-editor/order-editor')
      .then(module => module.OrderEditor),
    ...protectedBy('Orders.Create')
  },
  { path: 'search-orders', component: SearchOrders, ...protectedBy('Orders.View') },
  {
    path: 'order-details/:id',
    loadComponent: () => import('./pages/order-details/order-details')
      .then(module => module.OrderDetails),
    ...protectedBy('Orders.View')
  },
  {
    path: 'update-order/:id',
    loadComponent: () => import('./pages/order-editor/order-editor')
      .then(module => module.OrderEditor),
    ...protectedBy('Orders.Update')
  },
  {
    path: 'validate-order/:id',
    loadComponent: () => import('./pages/order-details/order-details')
      .then(module => module.OrderDetails),
    ...protectedBy('Orders.Validate')
  },
  {
    path: 'cancel-order/:id',
    loadComponent: () => import('./pages/order-details/order-details')
      .then(module => module.OrderDetails),
    ...protectedBy('Orders.Cancel')
  },
  { path: 'order-invoice/:id', component: OrderInvoice, ...protectedBy('Invoices.View') },
  {
    path: 'update-order-status/:id',
    loadComponent: () => import('./pages/order-details/order-details')
      .then(module => module.OrderDetails),
    ...protectedBy('Orders.ChangeStatus')
  },
  { path: 'view-pick-list', component: PackingOrders, ...protectedBy('Packing.View') },
  { path: 'pack-customer-order', component: PackingOrders, ...protectedBy('Packing.Confirm') },
  { path: 'pack-customer-order/:id', component: PackingOrders, ...protectedBy('Packing.Confirm') },
  { path: 'update-packing-status', component: PackingOrders, ...protectedBy('Packing.Confirm') },
  { path: 'update-packing-status/:id', component: PackingOrders, ...protectedBy('Packing.Confirm') },

  // Pricing and reporting use distinct view/export permissions so navigation mirrors backend least privilege.
  { path: 'pricing', component: PricingManagement, ...protectedBy('Pricing.View') },
  {
    path: 'pricing/create',
    component: PricingManagement,
    ...protectedBy(['Pricing.Create', 'Pricing.Manage'])
  },
  {
    path: 'pricing/:id/history',
    component: PricingManagement,
    ...protectedBy(['Pricing.ViewHistory', 'Pricing.Manage'])
  },
  { path: 'pricing/:id', component: PricingManagement, ...protectedBy('Pricing.View') },
  { path: 'pricing-management', redirectTo: 'pricing', pathMatch: 'full' },
  {
    path: 'reports',
    loadComponent: () => import('./pages/reports/reports-landing')
      .then(module => module.ReportsLanding),
    ...protectedBy('Reports.View')
  },
  {
    path: 'reports/inventory',
    loadComponent: () => import('./pages/reports/formal-report-page')
      .then(module => module.FormalReportPage),
    ...protectedBy('Reports.Inventory.View'),
    data: {
      permission: 'Reports.Inventory.View',
      reportKey: 'inventory'
    }
  },
  {
    path: 'reports/sales',
    loadComponent: () => import('./pages/reports/formal-report-page')
      .then(module => module.FormalReportPage),
    ...protectedBy('Reports.Sales.View'),
    data: {
      permission: 'Reports.Sales.View',
      reportKey: 'sales'
    }
  },
  {
    path: 'reports/financial',
    loadComponent: () => import('./pages/reports/formal-report-page')
      .then(module => module.FormalReportPage),
    ...protectedBy('Reports.Financial.View'),
    data: {
      permission: 'Reports.Financial.View',
      reportKey: 'financial'
    }
  },
  {
    path: 'reports/stock-movement',
    loadComponent: () => import('./pages/reports/formal-report-page')
      .then(module => module.FormalReportPage),
    ...protectedBy('Reports.StockMovement.View'),
    data: {
      permission: 'Reports.StockMovement.View',
      reportKey: 'stock-movement'
    }
  },
  {
    path: 'reports/expiry-waste',
    loadComponent: () => import('./pages/reports/formal-report-page')
      .then(module => module.FormalReportPage),
    ...protectedBy('Reports.ExpiryWaste.View'),
    data: {
      permission: 'Reports.ExpiryWaste.View',
      reportKey: 'expiry-waste'
    }
  },
  {
    path: 'reports/pricing',
    loadComponent: () => import('./pages/reports/formal-report-page')
      .then(module => module.FormalReportPage),
    ...protectedBy('Reports.Pricing.View'),
    data: {
      permission: 'Reports.Pricing.View',
      reportKey: 'pricing'
    }
  },
  {
    path: 'reports/markup',
    loadComponent: () => import('./pages/reports/formal-report-page')
      .then(module => module.FormalReportPage),
    ...protectedBy('Reports.Markup.View'),
    data: {
      permission: 'Reports.Markup.View',
      reportKey: 'markup'
    }
  },
  // Oversight and delivery routes expose sensitive evidence only behind their dedicated API-aligned permissions.
  { path: 'audit-logs', component: AuditLogs, ...protectedBy('AuditLogs.View') },
  {
    path: 'deliveries',
    component: DeliveryManagement,
    ...protectedBy(['Deliveries.View', 'Deliveries.AssignDriver'])
  },
  { path: 'my-deliveries', component: MyDeliveries, ...protectedBy('Deliveries.ViewOwn') },
  {
    path: 'deliveries/:id/complete',
    component: CompleteDelivery,
    ...protectedBy(['Deliveries.CompleteOwn', 'Deliveries.CompleteAny'])
  },
  { path: 'deliveries/:id/proof', component: DeliveryProof, ...protectedBy('Deliveries.ViewProof') },
  {
    path: 'deliveries/:id',
    component: DeliveryDetails,
    ...protectedBy(['Deliveries.View', 'Deliveries.ViewOwn'])
  },
  { path: '**', redirectTo: 'dashboard' }
];

// Route metadata is the single source used by guards and lazy-loaded workflow pages.
export const routes: Routes = [
  // Login and reset-password must remain outside the authenticated shell so recovery works without a session.
  { path: '', component: LoginComponent, pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  {
    path: 'reset-password',
    loadComponent: () => import('./pages/reset-password/reset-password')
      .then(module => module.ResetPassword)
  },
  // The shell requires authentication once; child routes then add their feature-specific permission guards.
  {
    path: '',
    component: AppShell,
    canActivate: [authGuard],
    children: applicationRoutes
  },
  { path: '**', redirectTo: 'login' }
];
