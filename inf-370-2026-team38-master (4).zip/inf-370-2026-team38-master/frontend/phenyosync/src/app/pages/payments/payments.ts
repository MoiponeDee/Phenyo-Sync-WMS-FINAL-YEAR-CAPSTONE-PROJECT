/**
 * Reviewer guide: Coordinates the payments page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { finalize, forkJoin, of } from 'rxjs';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import {
  FinancialPayment,
  OperationalSectionsService,
  PaymentCaptureOptions
} from '../../services/operational-sections';
import { httpErrorMessage } from '../../services/http-error-message';

@Component({
  selector: 'app-payments',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TopbarComponent,
    SidebarComponent,
    SearchFieldComponent
  ],
  templateUrl: './payments.html',
  styleUrl: './payments.css'
})
/** Captures and reviews payments while posting/reversal rules remain backend-controlled. */
export class PaymentsComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  payments: FinancialPayment[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  options: PaymentCaptureOptions = {
    customers: [],
    customerOrders: [],
    invoices: [],
    suppliers: [],
    supplierOrders: []
  };
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  filter = '';
  paymentSearch = '';
  statusFilter = '';
  methodFilter = '';
  fromDate = '';
  toDate = '';
  selectedPayment: FinancialPayment | null = null;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  customerSearch = '';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  supplierSearch = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Payments', route: '/payments', active: true },
    { name: 'Customers', route: '/customers' },
    { name: 'Suppliers', route: '/suppliers' },
    { name: 'Audit Trail', route: '/audit-logs' },
    { name: 'Management Overview', route: '/management-dashboard' }
  ];
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly form = this.fb.nonNullable.group({
    counterpartyType: ['Customer', Validators.required],
    customerId: [''],
    salesOrderId: [''],
    supplierId: [''],
    invoiceId: [''],
    supplierOrderId: [''],
    amount: [0, Validators.min(.01)],
    paymentDateUtc: [this.localDateTime(), Validators.required],
    paymentMethodCode: ['EFT', Validators.required],
    reference: [''],
    notes: ['']
  });

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private operational: OperationalSectionsService,
    private confirmation: ConfirmationService,
    private notifications: NotificationService,
    private changeDetector: ChangeDetectorRef,
    readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    if (!this.authorization.has('CustomerPayments.Capture') &&
        this.authorization.has('SupplierPayments.Capture')) {
      this.form.controls.counterpartyType.setValue('Supplier');
    }
    this.syncCounterpartyValidators();
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      payments: this.operational.payments({
        counterpartyType: this.filter || undefined,
        search: this.paymentSearch.trim() || undefined,
        status: this.statusFilter || undefined,
        paymentMethodCode: this.methodFilter || undefined,
        fromUtc: this.fromDate
          ? new Date(`${this.fromDate}T00:00:00`).toISOString()
          : undefined,
        toUtc: this.toDate
          ? new Date(`${this.toDate}T23:59:59.999`).toISOString()
          : undefined
      }),
      options: this.canCaptureAny()
        ? this.operational.paymentCaptureOptions()
        : of(this.options)
    }).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.payments = result.payments;
        this.options = result.options;
      },
      error: error => this.notifications.error(
        httpErrorMessage(error, 'Payments could not be loaded.'))
    });
  }

  /**
   * Reviewer note: Encapsulates the capture view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  capture(): void {
    // The browser submits references and amounts; posting status and accounting links are server-owned.
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      queueMicrotask(() =>
        document.querySelector<HTMLElement>('form .ng-invalid')?.focus());
      return;
    }
    const value = this.form.getRawValue();
    const customer = value.counterpartyType === 'Customer';
    const request = {
      customerId: customer ? this.number(value.customerId) : null,
      salesOrderId: customer ? this.number(value.salesOrderId) : null,
      supplierId: customer ? null : this.number(value.supplierId),
      invoiceId: customer ? this.number(value.invoiceId) : null,
      supplierOrderId: customer
        ? null
        : this.number(value.supplierOrderId),
      amount: value.amount,
      paymentDateUtc: new Date(value.paymentDateUtc).toISOString(),
      paymentMethodCode: value.paymentMethodCode,
      reference: value.reference || null,
      notes: value.notes || null
    };
    if ((!request.customerId || !request.salesOrderId || !request.invoiceId) &&
        (!request.supplierId || !request.supplierOrderId)) {
      this.notifications.warning(
        'Select a matching customer, order and invoice, or a supplier and Supplier Order.');
      return;
    }
    this.run(
      this.operational.capturePayment(request),
      'Payment posted successfully.',
      true);
  }

  /**
   * Reviewer note: Encapsulates the request reversal view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  async requestReversal(item: FinancialPayment): Promise<void> {
    const result = await this.confirmation.ask({
      title: 'Request payment reversal',
      message: `${item.paymentNumber} · ${item.counterpartyName} · R ${Math.abs(item.amount).toFixed(2)} · ${new Date(item.paymentDateUtc).toLocaleDateString('en-ZA')} · ${item.paymentMethodCode}. The original transaction remains in the ledger.`,
      confirmLabel: 'Confirm reversal',
      reasonLabel: 'Reversal reason',
      reasonRequired: true,
      tone: 'danger'
    });
    if (!result.confirmed) return;
    this.run(this.operational.requestPaymentReversal(
      item.financialPaymentId,
      { reason: result.reason, rowVersion: item.rowVersion }
    ), 'Payment reversal sent for approval.');
  }

  /**
   * Reviewer note: Encapsulates the decide view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  async decide(item: FinancialPayment, approved: boolean): Promise<void> {
    const result = await this.confirmation.ask({
      title: approved ? 'Approve reversal' : 'Reject reversal',
      message: `${approved ? 'Approve' : 'Reject'} reversal of ${item.paymentNumber}?`,
      confirmLabel: approved ? 'Approve reversal' : 'Reject reversal',
      reasonLabel: 'Decision reason',
      reasonRequired: true,
      tone: approved ? 'warning' : 'danger'
    });
    if (!result.confirmed) return;
    this.run(this.operational.decidePaymentReversal(
      item.financialPaymentId,
      approved,
      { reason: result.reason, rowVersion: item.rowVersion }
    ), `Payment reversal ${approved ? 'approved' : 'rejected'}.`);
  }

  /**
   * Reviewer note: Calculates can capture for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canCapture(): boolean {
    const type = this.form.controls.counterpartyType.value;
    return this.authorization.has(
      type === 'Customer'
        ? 'CustomerPayments.Capture'
        : 'SupplierPayments.Capture');
  }

  /**
   * Reviewer note: Calculates can reverse for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canReverse(item: FinancialPayment): boolean {
    const reversalExists = this.payments.some(payment =>
      payment.originalPaymentId === item.financialPaymentId &&
      (payment.status === 'PendingReversalApproval' || payment.status === 'Posted'));
    return !item.originalPaymentId && !reversalExists && this.authorization.has(
      item.counterpartyType === 'Customer'
        ? 'CustomerPayments.Reverse'
        : 'SupplierPayments.Reverse');
  }

  /**
   * Reviewer note: Calculates can capture any for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canCaptureAny(): boolean {
    return this.authorization.hasAny(
      'CustomerPayments.Capture',
      'SupplierPayments.Capture');
  }

  /**
   * Reviewer note: Encapsulates the customer orders view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  customerOrders() {
    const customerId = this.number(this.form.controls.customerId.value);
    return customerId
      ? this.options.customerOrders.filter(item => item.customerId === customerId)
      : [];
  }

  /**
   * Reviewer note: Encapsulates the customers view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  customers() {
    const search = this.customerSearch.trim().toLowerCase();
    return search
      ? this.options.customers.filter(item =>
          `${item.customerNumber} ${item.customerName} ${item.contactPerson ?? ''} ${item.phoneNumber ?? ''} ${item.email ?? ''}`
            .toLowerCase()
            .includes(search))
      : this.options.customers;
  }

  selectedCustomer() {
    const customerId = this.number(this.form.controls.customerId.value);
    return this.options.customers.find(item => item.customerId === customerId);
  }

  /**
   * Reviewer note: Encapsulates the customer invoices view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  customerInvoices() {
    const orderId = this.number(this.form.controls.salesOrderId.value);
    return orderId
      ? this.options.invoices.filter(item => item.salesOrderId === orderId)
      : [];
  }

  /**
   * Reviewer note: Encapsulates the supplier orders view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  supplierOrders() {
    const supplierId = this.number(this.form.controls.supplierId.value);
    return supplierId
      ? this.options.supplierOrders.filter(item => item.supplierId === supplierId)
      : [];
  }

  /**
   * Reviewer note: Encapsulates the suppliers view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  suppliers() {
    const search = this.supplierSearch.trim().toLowerCase();
    return search
      ? this.options.suppliers.filter(item =>
          `${item.supplierCode} ${item.supplierName} ${item.contactPerson ?? ''} ${item.phoneNumber ?? ''} ${item.email ?? ''}`
            .toLowerCase()
            .includes(search))
      : this.options.suppliers;
  }

  selectedSupplier() {
    const supplierId = this.number(this.form.controls.supplierId.value);
    return this.options.suppliers.find(item => item.supplierId === supplierId);
  }

  clearCustomerSearch(): void {
    this.customerSearch = '';
  }

  clearSupplierSearch(): void {
    this.supplierSearch = '';
  }

  clearPaymentFilters(): void {
    this.paymentSearch = '';
    this.filter = '';
    this.statusFilter = '';
    this.methodFilter = '';
    this.fromDate = '';
    this.toDate = '';
    this.load();
  }

  viewPayment(item: FinancialPayment): void {
    this.selectedPayment = this.selectedPayment?.financialPaymentId ===
      item.financialPaymentId ? null : item;
  }

  /**
   * Reviewer note: Coordinates the change payment direction interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  changePaymentDirection(): void {
    this.customerSearch = '';
    this.supplierSearch = '';
    this.form.patchValue({
      customerId: '',
      salesOrderId: '',
      invoiceId: '',
      supplierId: '',
      supplierOrderId: '',
      amount: 0
    });
    this.syncCounterpartyValidators();
  }

  /**
   * Reviewer note: Coordinates the change customer interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  changeCustomer(): void {
    this.form.patchValue({ salesOrderId: '', invoiceId: '', amount: 0 });
  }

  /**
   * Reviewer note: Coordinates the change customer order interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  changeCustomerOrder(): void {
    this.form.patchValue({ invoiceId: '', amount: 0 });
  }

  /**
   * Reviewer note: Coordinates the change invoice interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  changeInvoice(): void {
    const invoiceId = this.number(this.form.controls.invoiceId.value);
    const invoice = this.options.invoices.find(item => item.invoiceId === invoiceId);
    this.form.controls.amount.setValue(invoice?.outstandingAmount ?? 0);
  }

  /**
   * Reviewer note: Coordinates the change supplier interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  changeSupplier(): void {
    this.form.patchValue({ supplierOrderId: '', amount: 0 });
  }

  /**
   * Reviewer note: Coordinates the change supplier order interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  changeSupplierOrder(): void {
    const orderId = this.number(this.form.controls.supplierOrderId.value);
    const order = this.options.supplierOrders.find(item =>
      item.supplierOrderId === orderId);
    this.form.controls.amount.setValue(order?.outstandingAmount ?? 0);
  }

  /**
   * Reviewer note: Calculates can approve for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canApprove(item: FinancialPayment): boolean {
    // Hiding approval is convenience only; the endpoint also blocks self-approval and missing permission.
    return item.createdByUserId !== this.authorization.session()?.userId &&
      this.authorization.has(
      item.counterpartyType === 'Customer'
        ? 'CustomerPayments.ApproveReversal'
        : 'SupplierPayments.ApproveReversal');
  }

  /**
   * Reviewer note: Encapsulates the run view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private run(
    request: import('rxjs').Observable<FinancialPayment>,
    message: string,
    resetCapture = false
  ): void {
    this.loading = true;
    request.pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: () => {
        this.notifications.success(message);
        if (resetCapture) {
          this.customerSearch = '';
          this.supplierSearch = '';
          this.form.patchValue({
            customerId: '',
            salesOrderId: '',
            invoiceId: '',
            supplierId: '',
            supplierOrderId: '',
            amount: 0,
            reference: '',
            notes: ''
          });
        }
        this.load();
      },
      error: error => this.notifications.error(
        httpErrorMessage(error, 'The payment operation could not be completed.'))
    });
  }

  /** Keeps the visible relationship fields required while clearing hidden-direction rules. */
  private syncCounterpartyValidators(): void {
    const customer = this.form.controls.counterpartyType.value === 'Customer';
    const requiredControls = customer
      ? ['customerId', 'salesOrderId', 'invoiceId'] as const
      : ['supplierId', 'supplierOrderId'] as const;
    const optionalControls = customer
      ? ['supplierId', 'supplierOrderId'] as const
      : ['customerId', 'salesOrderId', 'invoiceId'] as const;

    requiredControls.forEach(name => {
      this.form.controls[name].setValidators(Validators.required);
      this.form.controls[name].updateValueAndValidity({ emitEvent: false });
    });
    optionalControls.forEach(name => {
      this.form.controls[name].clearValidators();
      this.form.controls[name].updateValueAndValidity({ emitEvent: false });
    });
  }

  /**
   * Reviewer note: Encapsulates the number view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private number(value: string): number | null {
    const parsed = Number(value);
    return Number.isInteger(parsed) && parsed > 0 ? parsed : null;
  }

  /**
   * Reviewer note: Encapsulates the local date time view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private localDateTime(): string {
    const value = new Date();
    return new Date(value.getTime() - value.getTimezoneOffset() * 60000)
      .toISOString().slice(0, 16);
  }
}
