import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { OperationalSectionsService } from '../../services/operational-sections';
import { PaymentsComponent } from './payments';

describe('PaymentsComponent search', () => {
  let fixture: ComponentFixture<PaymentsComponent>;
  let component: PaymentsComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PaymentsComponent],
      providers: [{
        provide: OperationalSectionsService,
        useValue: {
          payments: () => of([]),
          paymentCaptureOptions: () => of({
            customers: [], customerOrders: [], invoices: [], suppliers: [], supplierOrders: []
          }),
          capturePayment: vi.fn()
        }
      }]
    }).overrideComponent(PaymentsComponent, { set: { template: '' } }).compileComponents();
    fixture = TestBed.createComponent(PaymentsComponent);
    component = fixture.componentInstance;
    component.options = {
      customers: [
        {
          customerId: 1,
          customerNumber: 'CUS-001',
          customerName: 'Alpha Foods',
          contactPerson: 'Ada Buyer',
          phoneNumber: '0825550101',
          email: 'ada@alpha.example'
        },
        { customerId: 2, customerNumber: 'CUS-002', customerName: 'Beta Market' }
      ],
      customerOrders: [],
      invoices: [],
      suppliers: [
        {
          supplierId: 3,
          supplierCode: 'SUP-001',
          supplierName: 'Fresh Produce Agency',
          contactPerson: 'Sam Supplier',
          phoneNumber: '0115550102',
          email: 'sam@fresh.example'
        },
        { supplierId: 4, supplierCode: 'SUP-002', supplierName: 'Dry Goods Agency' }
      ],
      supplierOrders: []
    };
  });

  it('searches customers and suppliers by their existing identifiers', () => {
    component.customerSearch = 'cus-002';
    component.supplierSearch = 'fresh';

    expect(component.customers().map(item => item.customerName)).toEqual(['Beta Market']);
    expect(component.suppliers().map(item => item.supplierCode)).toEqual(['SUP-001']);
  });

  it('also searches the returned contact details', () => {
    component.customerSearch = '0825550101';
    component.supplierSearch = 'sam@fresh.example';

    expect(component.customers().map(item => item.customerNumber)).toEqual(['CUS-001']);
    expect(component.suppliers().map(item => item.supplierCode)).toEqual(['SUP-001']);
  });

  it('returns an empty result and supports clearing both searches', () => {
    component.customerSearch = 'missing';
    component.supplierSearch = 'missing';
    expect(component.customers()).toEqual([]);
    expect(component.suppliers()).toEqual([]);

    component.clearCustomerSearch();
    component.clearSupplierSearch();
    expect(component.customers()).toHaveLength(2);
    expect(component.suppliers()).toHaveLength(2);
  });

  it('clears dependent payment state when the counterparty changes', () => {
    component.form.patchValue({
      customerId: '1', salesOrderId: '9', invoiceId: '7', amount: 125,
      supplierId: '3', supplierOrderId: '11'
    });
    component.changeCustomer();
    expect(component.form.controls.salesOrderId.value).toBe('');
    expect(component.form.controls.invoiceId.value).toBe('');
    expect(component.form.controls.amount.value).toBe(0);

    component.form.patchValue({ supplierOrderId: '11', amount: 85 });
    component.changeSupplier();
    expect(component.form.controls.supplierOrderId.value).toBe('');
    expect(component.form.controls.amount.value).toBe(0);
  });

  it('validates only the relationship fields for the selected payment direction', () => {
    component.changePaymentDirection();
    expect(component.form.controls.customerId.hasError('required')).toBe(true);
    expect(component.form.controls.supplierId.hasError('required')).toBe(false);

    component.form.controls.counterpartyType.setValue('Supplier');
    component.changePaymentDirection();
    expect(component.form.controls.supplierId.hasError('required')).toBe(true);
    expect(component.form.controls.supplierOrderId.hasError('required')).toBe(true);
    expect(component.form.controls.customerId.hasError('required')).toBe(false);
  });

  it('does not offer another reversal when a linked adjustment already exists', () => {
    vi.spyOn(component.authorization, 'has').mockReturnValue(true);
    const original = {
      financialPaymentId: 10,
      paymentNumber: 'PAY-010',
      counterpartyType: 'Customer' as const,
      counterpartyName: 'Alpha Foods',
      amount: 100,
      outstandingBeforePosting: 100,
      outstandingAfterPosting: 0,
      paymentMethodCode: 'EFT',
      status: 'Posted',
      createdByUserId: 1,
      paymentDateUtc: '2026-09-24T08:00:00Z',
      rowVersion: 'one'
    };
    component.payments = [original, {
      ...original,
      financialPaymentId: 11,
      originalPaymentId: 10,
      paymentNumber: 'REV-011',
      amount: -100,
      status: 'PendingReversalApproval',
      rowVersion: 'two'
    }];

    expect(component.canReverse(original)).toBe(false);
  });
});
