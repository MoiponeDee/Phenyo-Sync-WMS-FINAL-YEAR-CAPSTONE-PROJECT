/**
 * Reviewer guide: Coordinates the order invoice page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { finalize, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { Invoice, OrderService } from '../../services/order';

// Displays the immutable order and price snapshot used for invoice review.
@Component({
  selector: 'app-order-invoice', standalone: true,
  imports: [CommonModule, RouterLink, TopbarComponent], templateUrl: './order-invoice.html'
})
export class OrderInvoice implements OnInit {
  invoice: Invoice | null = null;
  orderId = 0;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = true;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private route: ActivatedRoute,
    private orders: OrderService,
    private changeDetector: ChangeDetectorRef
  ) {}
  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.orderId = Number(this.route.snapshot.paramMap.get('id'));
    this.orders.getInvoice(this.orderId).pipe(take(1), finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: invoice => this.invoice = invoice,
      error: error => this.errorMessage = error instanceof HttpErrorResponse ? error.error?.message || 'Unable to load invoice.' : 'Unable to load invoice.'
    });
  }
  /**
   * Reviewer note: Encapsulates the print view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  print(): void { window.print(); }
}
