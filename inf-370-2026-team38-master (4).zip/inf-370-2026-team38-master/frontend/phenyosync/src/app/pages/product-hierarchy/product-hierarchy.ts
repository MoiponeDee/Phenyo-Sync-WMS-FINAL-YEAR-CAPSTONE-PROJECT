/**
 * Reviewer guide: Coordinates the product hierarchy page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import { httpErrorMessage } from '../../services/http-error-message';
import {
  BuyingListService,
  ProductRawStockRequirement
} from '../../services/buying-lists';
import {
  OperationalSectionsService,
  RawStockSummary
} from '../../services/operational-sections';
import {
  HierarchyCategory,
  HierarchyProduct,
  HierarchyType,
  ProductHierarchyResponse,
  ProductHierarchyService
} from '../../services/product-hierarchy';

type SelectedNode =
  | { kind: 'category'; category: HierarchyCategory }
  | { kind: 'type'; category: HierarchyCategory; type: HierarchyType }
  | { kind: 'product'; category: HierarchyCategory; type: HierarchyType; product: HierarchyProduct };

type EditorMode = 'category' | 'type' | 'product' | 'reclassify' | 'move' | null;

@Component({
  selector: 'app-product-hierarchy',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent, SearchFieldComponent],
  templateUrl: './product-hierarchy.html',
  styleUrls: ['../phase-b.css', './product-hierarchy.css']
})
/** Displays the master Category-to-Type-to-Product tree and links to Product Details. */
export class ProductHierarchy implements OnInit {
  hierarchy: ProductHierarchyResponse = {
    categories: [],
    categoryCount: 0,
    typeCount: 0,
    productCount: 0
  };
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search = '';
  includeInactive = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  editorError = '';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selected: SelectedNode | null = null;
  editorMode: EditorMode = null;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  expandedCategories = new Set<number>();
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  expandedTypes = new Set<number>();

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  categoryForm = { name: '', description: '', status: 'Active' as 'Active' | 'Inactive' };
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  typeForm = { name: '', description: '', status: 'Active' as 'Active' | 'Inactive' };
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  productForm = {
    productName: '',
    size: '',
    shelfLifeDays: 30,
    initialSellingPrice: 0.01,
    initialPriceBasis: 'PerKilogram' as 'PerKilogram' | 'PerSellableUnit',
    sellingUnit: 'kg',
    kilogramsPerUnit: null as number | null,
    isVariableWeight: true,
    priceReason: '',
    status: 'Active' as 'Active' | 'Inactive'
  };
  createdProductId: number | null = null;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  showProductSuccess = false;
  targetCategoryId: number | null = null;
  targetTypeId: number | null = null;
  structuralReason = '';
  rawStock: RawStockSummary[] = [];
  requirements: ProductRawStockRequirement[] = [];
  editingRequirementId: number | null = null;
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  requirementForm = {
    rawStockItemId: 0,
    rawQuantityPerProductUnit: 0,
    unitOfMeasure: 'kg',
    wastePercentage: 5,
    yieldPercentage: 95,
    isActive: true,
    rowVersion: ''
  };

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private hierarchyService: ProductHierarchyService,
    readonly authorization: AuthorizationService,
    private confirmations: ConfirmationService,
    private notifications: NotificationService,
    private planning: BuyingListService,
    private operational: OperationalSectionsService,
    private changeDetector: ChangeDetectorRef,
    private location: Location,
    private router: Router
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
    if (this.canManageRequirements) {
      this.operational.rawStock('', false).subscribe({
        next: result => this.rawStock = result.items,
        error: () => this.notifications.error(
          'Raw-stock choices could not be loaded for product requirements.')
      });
    }
  }

  /**
   * Reviewer note: Calculates can manage for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canManage(): boolean {
    return this.authorization.has('ProductHierarchy.Manage');
  }

  /**
   * Reviewer note: Calculates can manage requirements for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canManageRequirements(): boolean {
    return this.authorization.has('Reconciliation.Manage') &&
      this.authorization.has('RawStock.View');
  }

  /**
   * Reviewer note: Coordinates selected category so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  get selectedCategory(): HierarchyCategory | null {
    return this.selected?.category ?? null;
  }

  /**
   * Reviewer note: Coordinates selected type so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  get selectedType(): HierarchyType | null {
    return this.selected && this.selected.kind !== 'category' ? this.selected.type : null;
  }

  /**
   * Reviewer note: Coordinates selected product so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  get selectedProduct(): HierarchyProduct | null {
    return this.selected?.kind === 'product' ? this.selected.product : null;
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    if (this.loading) return;
    this.loading = true;
    this.errorMessage = '';
    this.hierarchyService.get(this.search, this.includeInactive).pipe(
      take(1),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: hierarchy => {
        this.hierarchy = hierarchy;
        if (this.createdProductId) {
          this.selectCreatedProduct(this.createdProductId);
        }
        if (!this.selected && hierarchy.categories.length) {
          this.selectCategory(hierarchy.categories[0]);
        }
      },
      error: error => this.errorMessage = this.errorText(error, 'Unable to load the product hierarchy.')
    });
  }

  /**
   * Reviewer note: Encapsulates the clear search view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearSearch(): void {
    this.search = '';
    this.includeInactive = false;
    this.load();
  }

  /**
   * Reviewer note: Encapsulates the toggle category view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  toggleCategory(id: number): void {
    this.toggle(this.expandedCategories, id);
  }

  /**
   * Reviewer note: Encapsulates the toggle type view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  toggleType(id: number): void {
    this.toggle(this.expandedTypes, id);
  }

  /**
   * Reviewer note: Calculates is category expanded for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  isCategoryExpanded(id: number): boolean {
    return this.expandedCategories.has(id);
  }

  /**
   * Reviewer note: Calculates is type expanded for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  isTypeExpanded(id: number): boolean {
    return this.expandedTypes.has(id);
  }

  /**
   * Reviewer note: Coordinates select category so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectCategory(category: HierarchyCategory): void {
    this.selected = { kind: 'category', category };
  }

  /**
   * Reviewer note: Coordinates select type so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectType(category: HierarchyCategory, type: HierarchyType): void {
    this.selected = { kind: 'type', category, type };
  }

  /**
   * Reviewer note: Coordinates select product so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectProduct(category: HierarchyCategory, type: HierarchyType, product: HierarchyProduct): void {
    this.selected = { kind: 'product', category, type, product };
    this.requirements = [];
    if (this.canManageRequirements) this.loadRequirements(product.productId);
  }

  /**
   * Reviewer note: Coordinates load requirements so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadRequirements(productId: number): void {
    this.planning.productRequirements(productId, true).subscribe({
      next: items => this.requirements = items,
      error: error => this.notifications.error(
        this.errorText(error, 'Raw-stock requirements could not be loaded.'))
    });
  }

  /**
   * Reviewer note: Encapsulates the edit requirement view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  editRequirement(item?: ProductRawStockRequirement): void {
    this.editingRequirementId = item?.productRawStockRequirementId ?? null;
    this.requirementForm = {
      rawStockItemId: item?.rawStockItemId ?? 0,
      rawQuantityPerProductUnit: item?.rawQuantityPerProductUnit ?? 0,
      unitOfMeasure: item?.unitOfMeasure ?? 'kg',
      wastePercentage: item?.wastePercentage ?? 5,
      yieldPercentage: item?.yieldPercentage ?? 95,
      isActive: item?.isActive ?? true,
      rowVersion: item?.rowVersion ?? ''
    };
  }

  /**
   * Reviewer note: Coordinates the save requirement interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveRequirement(): void {
    const product = this.selectedProduct;
    if (!product || !this.canManageRequirements ||
        this.requirementForm.rawStockItemId <= 0 ||
        this.requirementForm.rawQuantityPerProductUnit <= 0 ||
        this.requirementForm.yieldPercentage <= 0) {
      this.notifications.warning(
        'Select raw stock and enter valid quantity and yield values.');
      return;
    }
    this.saving = true;
    this.planning.saveProductRequirement(
      product.productId,
      this.editingRequirementId,
      this.requirementForm
    ).pipe(finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: () => {
        this.notifications.success('Raw-stock requirement saved.');
        this.editingRequirementId = null;
        this.loadRequirements(product.productId);
      },
      error: error => this.notifications.error(
        this.errorText(error, 'The raw-stock requirement could not be saved.'))
    });
  }

  /**
   * Reviewer note: Encapsulates the raw stock choices view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  rawStockChoices(): RawStockSummary[] {
    const choices = new Map<number, RawStockSummary>();
    for (const item of this.rawStock) {
      if (!choices.has(item.rawStockItemId)) choices.set(item.rawStockItemId, item);
    }
    return [...choices.values()].sort((left, right) =>
      left.itemName.localeCompare(right.itemName));
  }

  /**
   * Reviewer note: Coordinates selected raw stock available so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectedRawStockAvailable(): number {
    return this.rawStock
      .filter(item => item.rawStockItemId === this.requirementForm.rawStockItemId)
      .reduce((total, item) =>
        total + Math.max(0, item.quantityOnHand - item.reservedQuantity), 0);
  }

  /**
   * Reviewer note: Coordinates select requirement raw stock so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectRequirementRawStock(): void {
    const selected = this.rawStock.find(item =>
      item.rawStockItemId === this.requirementForm.rawStockItemId);
    if (selected) this.requirementForm.unitOfMeasure = selected.unitOfMeasure;
  }

  /**
   * Reviewer note: Coordinates open category editor so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openCategoryEditor(category?: HierarchyCategory): void {
    this.editorError = '';
    this.editorMode = 'category';
    this.selected = category ? { kind: 'category', category } : this.selected;
    this.categoryForm = {
      name: category?.name ?? '',
      description: category?.description ?? '',
      status: category?.status ?? 'Active'
    };
  }

  /**
   * Reviewer note: Coordinates open type editor so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openTypeEditor(category: HierarchyCategory, type?: HierarchyType): void {
    this.editorError = '';
    this.editorMode = 'type';
    this.selected = type ? { kind: 'type', category, type } : { kind: 'category', category };
    this.typeForm = {
      name: type?.name ?? '',
      description: type?.description ?? '',
      status: type?.status ?? 'Active'
    };
  }

  /**
   * Reviewer note: Coordinates open product editor so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openProductEditor(category: HierarchyCategory, type: HierarchyType): void {
    this.editorError = '';
    this.editorMode = 'product';
    this.selected = { kind: 'type', category, type };
    this.productForm = {
      productName: '',
      size: '',
      shelfLifeDays: 30,
      initialSellingPrice: 0.01,
      initialPriceBasis: 'PerKilogram',
      sellingUnit: 'kg',
      kilogramsPerUnit: null,
      isVariableWeight: true,
      priceReason: '',
      status: 'Active'
    };
  }

  /**
   * Reviewer note: Coordinates open move editor so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openMoveEditor(category: HierarchyCategory, type: HierarchyType): void {
    this.editorError = '';
    this.editorMode = 'move';
    this.selected = { kind: 'type', category, type };
    this.targetCategoryId = null;
    this.structuralReason = '';
  }

  /**
   * Reviewer note: Coordinates open reclassify editor so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openReclassifyEditor(category: HierarchyCategory, type: HierarchyType, product: HierarchyProduct): void {
    this.editorError = '';
    this.editorMode = 'reclassify';
    this.selected = { kind: 'product', category, type, product };
    this.targetCategoryId = category.productCategoryId;
    this.targetTypeId = type.productTypeId;
    this.structuralReason = '';
  }

  /**
   * Reviewer note: Encapsulates the close editor view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  closeEditor(): void {
    if (!this.saving) {
      this.editorMode = null;
      this.editorError = '';
    }
  }

  /**
   * Reviewer note: Coordinates the save editor interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveEditor(form?: NgForm): void {
    if (!this.canManage || this.saving || !this.editorMode) return;
    form?.control.markAllAsTouched();
    if (form?.invalid) {
      this.editorError = 'Complete the highlighted required fields before saving.';
      setTimeout(() => document.querySelector<HTMLElement>(
        '.hierarchy-editor-form .ng-invalid')?.focus());
      return;
    }
    const completingMode = this.editorMode;
    this.editorError = '';
    const request = this.editorRequest();
    if (!request) return;
    this.saving = true;
    request.pipe(
      take(1),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.notifications.success(response.message);
        const productId = 'productId' in response &&
            typeof response.productId === 'number'
          ? response.productId
          : undefined;
        if (completingMode === 'product' && productId) {
          this.createdProductId = productId;
          this.showProductSuccess = true;
        }
        this.editorMode = null;
        this.selected = null;
        this.load();
      },
      error: error => {
        this.editorError = this.errorText(
          error,
          'The hierarchy change could not be saved.'
        );
      }
    });
  }

  /**
   * Reviewer note: Coordinates the change product status interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async changeProductStatus(product: HierarchyProduct): Promise<void> {
    const status = product.status === 'Active' ? 'Inactive' : 'Active';
    const result = await this.confirmations.ask({
      title: `${status} product`,
      message: `Confirm that ${product.name} should be ${status.toLowerCase()}.`,
      confirmLabel: status,
      tone: status === 'Inactive' ? 'warning' : 'default',
      reasonLabel: 'Business reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.saving = true;
    this.hierarchyService.changeProductStatus(product.productId, status, result.reason, product.rowVersion).pipe(
      take(1),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.selected = null;
        this.load();
      },
      error: error => this.notifications.error(this.errorText(error, 'The product status could not be changed.'))
    });
  }

  /**
   * Reviewer note: Coordinates the delete selected interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async deleteSelected(): Promise<void> {
    if (!this.selected || this.selected.kind === 'product') return;
    const label = this.selected.kind === 'category' ? this.selected.category.name : this.selected.type.name;
    const result = await this.confirmations.ask({
      title: 'Delete unused hierarchy node',
      message: `${label} can only be deleted when it has no dependent records.`,
      confirmLabel: 'Delete',
      tone: 'danger',
      reasonLabel: 'Deletion reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    const call = this.selected.kind === 'category'
      ? this.hierarchyService.deleteCategory(
          this.selected.category.productCategoryId,
          result.reason,
          this.selected.category.rowVersion)
      : this.hierarchyService.deleteType(
          this.selected.type.productTypeId,
          result.reason,
          this.selected.type.rowVersion);
    this.saving = true;
    call.pipe(
      take(1),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.selected = null;
        this.load();
      },
      error: error => void this.handleNodeDeleteError(error, label)
    });
  }

  /**
   * Reviewer note: Converts handle node delete error into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private async handleNodeDeleteError(error: unknown, label: string): Promise<void> {
    const status = (error as { status?: number })?.status;
    if (status !== 409 || !this.selected || this.selected.kind === 'product') {
      this.notifications.error(this.errorText(error, 'The node could not be deleted.'));
      return;
    }

    const selected = this.selected;
    const result = await this.confirmations.ask({
      title: `Deactivate ${label}?`,
      message:
        'This hierarchy record has dependent data and cannot be permanently deleted. Deactivation preserves its history and hides it from new work.',
      confirmLabel: 'Deactivate',
      tone: 'warning',
      reasonLabel: 'Deactivation reason',
      reasonRequired: true
    });
    if (!result.confirmed) {
      return;
    }

    const item = selected.kind === 'category' ? selected.category : selected.type;
    const request = {
      name: item.name,
      description: item.description ?? '',
      status: 'Inactive',
      rowVersion: item.rowVersion,
      reason: result.reason
    };
    const call = selected.kind === 'category'
      ? this.hierarchyService.updateCategory(
          selected.category.productCategoryId,
          request
        )
      : this.hierarchyService.updateType(selected.type.productTypeId, request);

    this.saving = true;
    call.pipe(
      take(1),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.selected = null;
        this.load();
      },
      error: updateError => this.notifications.error(
        this.errorText(updateError, 'The hierarchy record could not be deactivated.')
      )
    });
  }

  /**
   * Reviewer note: Encapsulates the types for target category view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  typesForTargetCategory(): HierarchyType[] {
    return this.hierarchy.categories.find(
      category => category.productCategoryId === this.targetCategoryId
    )?.types ?? [];
  }

  /**
   * Reviewer note: Coordinates open product details so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openProductDetails(productId: number): void {
    this.router.navigate(['/products', productId, 'details']);
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.location.back();
  }

  /**
   * Reviewer note: Encapsulates the configure created product view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  configureCreatedProduct(): void {
    this.showProductSuccess = false;
    if (this.createdProductId) this.selectCreatedProduct(this.createdProductId);
    /**
     * Reviewer note: Encapsulates the set timeout view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    setTimeout(() => document.querySelector('.requirement-panel')?.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    }));
  }

  /**
   * Reviewer note: Encapsulates the close product success view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  closeProductSuccess(): void {
    this.showProductSuccess = false;
  }

  trackCategory = (_: number, value: HierarchyCategory) => value.productCategoryId;
  trackType = (_: number, value: HierarchyType) => value.productCategoryTypeId;
  trackProduct = (_: number, value: HierarchyProduct) => value.productId;

  /**
   * Reviewer note: Encapsulates the editor request view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private editorRequest() {
    if (this.editorMode === 'category') {
      const existing = this.selected?.kind === 'category' ? this.selected.category : null;
      const payload = { ...this.categoryForm, rowVersion: existing?.rowVersion || undefined };
      return existing
        ? this.hierarchyService.updateCategory(existing.productCategoryId, payload)
        : this.hierarchyService.createCategory(payload);
    }
    if (this.editorMode === 'type' && this.selected) {
      const existing = this.selected.kind === 'type' ? this.selected.type : null;
      const category = this.selected.category;
      const payload = { ...this.typeForm, rowVersion: existing?.rowVersion || undefined };
      return existing
        ? this.hierarchyService.updateType(existing.productTypeId, payload)
        : this.hierarchyService.createType(category.productCategoryId, payload);
    }
    if (this.editorMode === 'product' && this.selected?.kind === 'type') {
      if (this.productForm.initialSellingPrice < 0.01 ||
          this.productForm.priceReason.trim().length < 5) {
        this.editorError =
          'Enter an initial selling price and a price reason of at least five characters.';
        return null;
      }
      if (!this.productForm.isVariableWeight && this.productForm.initialPriceBasis === 'PerKilogram' &&
          (!this.productForm.kilogramsPerUnit || this.productForm.kilogramsPerUnit <= 0)) {
        this.editorError = 'Enter a positive kilograms-per-unit value for the packaged product.';
        return null;
      }
      return this.hierarchyService.createProduct(
        this.selected.category.productCategoryId,
        this.selected.type.productTypeId,
        this.productForm);
    }
    if (this.editorMode === 'move' && this.selected?.kind === 'type' && this.targetCategoryId) {
      return this.hierarchyService.moveType(
        this.selected.type.productCategoryTypeId,
        this.targetCategoryId,
        this.structuralReason,
        this.selected.type.rowVersion);
    }
    if (this.editorMode === 'reclassify' && this.selected?.kind === 'product' &&
        this.targetCategoryId && this.targetTypeId) {
      return this.hierarchyService.reclassifyProduct(this.selected.product.productId, {
        productCategoryId: this.targetCategoryId,
        productTypeId: this.targetTypeId,
        reason: this.structuralReason,
        rowVersion: this.selected.product.rowVersion
      });
    }
    this.editorError = 'Complete all required fields before saving.';
    return null;
  }

  /**
   * Reviewer note: Encapsulates the toggle view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private toggle(set: Set<number>, id: number): void {
    if (set.has(id)) set.delete(id);
    else set.add(id);
  }

  /**
   * Reviewer note: Coordinates select created product so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private selectCreatedProduct(productId: number): void {
    for (const category of this.hierarchy.categories) {
      for (const type of category.types) {
        const product = type.products.find(item => item.productId === productId);
        if (!product) continue;
        this.expandedCategories.add(category.productCategoryId);
        this.expandedTypes.add(type.productCategoryTypeId);
        this.selectProduct(category, type, product);
        return;
      }
    }
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    return httpErrorMessage(error, fallback);
  }
}
