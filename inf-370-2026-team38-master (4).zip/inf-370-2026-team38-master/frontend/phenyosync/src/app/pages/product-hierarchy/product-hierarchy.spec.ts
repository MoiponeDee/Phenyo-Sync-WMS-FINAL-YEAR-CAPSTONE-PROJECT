/**
 * Reviewer guide: Verifies the product hierarchy frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ChangeDetectorRef } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { vi } from 'vitest';
import { AuthorizationService } from '../../services/authorization';
import { BuyingListService } from '../../services/buying-lists';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import { OperationalSectionsService } from '../../services/operational-sections';
import { ProductHierarchyService } from '../../services/product-hierarchy';
import { ProductHierarchy } from './product-hierarchy';

// Prevents hierarchy actions from regressing to the obsolete Product Overview destination.
describe('ProductHierarchy details navigation', () => {
  // Reviewer note: Guards the observable rule that opens master Product Details instead of Product Overview.
  it('opens master Product Details instead of Product Overview', () => {
    const router = {
      navigate: vi.fn()
    } as unknown as Router;
    const component = new ProductHierarchy(
      {} as ProductHierarchyService,
      {} as AuthorizationService,
      {} as ConfirmationService,
      {} as NotificationService,
      {} as BuyingListService,
      {} as OperationalSectionsService,
      {} as ChangeDetectorRef,
      {} as Location,
      router);

    component.openProductDetails(42);

    expect(router.navigate).toHaveBeenCalledWith(['/products', 42, 'details']);
    expect(router.navigate).not.toHaveBeenCalledWith(['/search-product']);
  });
});
