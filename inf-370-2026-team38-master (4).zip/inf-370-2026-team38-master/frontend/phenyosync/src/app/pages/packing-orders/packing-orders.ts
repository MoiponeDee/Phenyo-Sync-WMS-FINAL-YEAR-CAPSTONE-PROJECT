/**
 * Reviewer guide: Coordinates the packing orders page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { finalize, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { OrderService, PackingList, SalesOrderSummary } from '../../services/order';
import { HumanizeCodePipe } from '../../pipes/humanize-code.pipe';

@Component({
  selector: 'app-packing-orders', standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, TopbarComponent, HumanizeCodePipe, SearchFieldComponent],
  templateUrl: './packing-orders.html',
  styleUrl: './packing-orders.css'
})
/** Displays approved packing workload even when available finished batches are insufficient. */
export class PackingOrders implements OnInit {
  queue: SalesOrderSummary[] = [];
  packingList: PackingList | null = null;
  orderId: number | null = null;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  searchTerm = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  message = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private orders: OrderService,
    private changeDetector: ChangeDetectorRef
  ) {}
  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    const value = Number(this.route.snapshot.paramMap.get('id'));
    this.orderId = Number.isInteger(value) && value > 0 ? value : null;
    this.orderId ? this.loadList() : this.loadQueue();
  }
  /**
   * Reviewer note: Coordinates load queue so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadQueue(): void {
    this.loading = true; this.errorMessage = '';
    this.orders.getPackingQueue(this.searchTerm).pipe(take(1), finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({ next: queue => this.queue = queue, error: error => this.fail(error) });
  }
  /**
   * Reviewer note: Coordinates load list so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadList(): void {
    if (!this.orderId) return;
    this.loading = true; this.errorMessage = '';
    this.orders.getPackingList(this.orderId).pipe(take(1), finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({ next: list => this.packingList = list, error: error => this.fail(error) });
  }
  /**
   * Reviewer note: Coordinates open so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  open(order: SalesOrderSummary): void { this.router.navigate(['/pack-customer-order', order.salesOrderId]); }
  /**
   * Reviewer note: Encapsulates the print view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  print(): void { window.print(); }
  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown): void { this.errorMessage = error instanceof HttpErrorResponse ? error.error?.message || 'The packing request failed.' : 'The packing request failed.'; }
}
