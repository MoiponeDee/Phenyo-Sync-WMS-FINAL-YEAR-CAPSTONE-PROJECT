import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { PackingOrders } from './packing-orders';

describe('PackingOrders', () => {
  let component: PackingOrders;
  let fixture: ComponentFixture<PackingOrders>;

  beforeEach(async () => {
    vi.spyOn(PackingOrders.prototype, 'loadQueue').mockImplementation(() => undefined);
    await TestBed.configureTestingModule({
      imports: [PackingOrders],
      providers: [provideHttpClient(), provideRouter([])]
    }).compileComponents();
    fixture = TestBed.createComponent(PackingOrders);
    component = fixture.componentInstance;
  });

  it('renders the approved queue with a human date and action', () => {
    component.queue = [{
      salesOrderId: 12,
      orderNumber: 'SO-0012',
      customerName: 'Mabena Market',
      customerEmail: 'orders@example.invalid',
      orderDateUtc: '2026-08-15T07:00:00Z',
      requestedDeliveryDateUtc: '2026-08-16T07:00:00Z',
      status: 'Approved',
      validationStatus: 'Approved',
      itemCount: 2,
      totalAmount: 100,
      hasInvoice: false,
      canUpdate: false,
      canValidate: false,
      canCancel: false,
      canViewPackingList: true
    }];

    fixture.detectChanges();

    const text = fixture.nativeElement.textContent;
    expect(text).toContain('16 Aug 2026');
    expect(text).toContain('Open packing list');
  });

  it('shows required, available, packed and remaining quantities even when stock is short', () => {
    component.orderId = 12;
    component.packingList = {
      salesOrderId: 12,
      orderNumber: 'SO-0012',
      customerName: 'Mabena Market',
      deliveryAddress: '1 Main Road',
      status: 'Approved',
      requestedDeliveryDateUtc: '2026-08-16T07:00:00Z',
      lines: [{
        salesOrderItemId: 21,
        productName: 'Spinach Bag',
        productSize: '1 kg',
        orderedQuantityUnits: 4,
        sellingUnit: 'bag',
        requiredQuantityKg: 4,
        availableQuantityKg: 1,
        packedQuantityKg: 0,
        remainingQuantityKg: 4
      }],
      allocations: []
    };

    fixture.detectChanges();

    const row = fixture.nativeElement.querySelector('.workload-table tbody tr');
    expect(row.textContent).toContain('Spinach Bag');
    expect(row.textContent).toContain('4 kg');
    expect(row.textContent).toContain('1 kg');
    expect(fixture.nativeElement.textContent).toContain('No finished Product Batch can be allocated yet');
  });
});
