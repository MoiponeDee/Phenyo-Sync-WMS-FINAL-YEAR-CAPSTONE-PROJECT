/**
 * Reviewer guide: Coordinates the admin dashboard page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';
import { AuthorizationService } from '../../services/authorization';
import { SecurityAdminService } from '../../services/security-admin';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, TopbarComponent, SidebarComponent],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
/** Presents Super Admin-labelled navigation backed by the persisted Admin permission set. */
export class AdminDashboardComponent implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  totalUsers: number | null = null;
  currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  menuItems: { name: string; route: string; active?: boolean }[] = [];

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    readonly authorization: AuthorizationService,
    private securityAdmin: SecurityAdminService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.buildMenu();
    if (this.can('Users.View')) {
      this.securityAdmin.searchUsers({ page: 1, pageSize: 1 }).subscribe({
        next: result => this.totalUsers = result.total
      });
    }
  }

  /**
   * Reviewer note: Calculates can for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  can(permission: string): boolean {
    return this.authorization.has(permission);
  }

  /**
   * Reviewer note: Encapsulates the build menu view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private buildMenu(): void {
    const items = [
      { name: 'Super Admin Dashboard', route: '/admin-dashboard', active: true, permission: 'Orders.View' },
      { name: 'Manage Users', route: '/manage-users', permission: 'Users.View' },
      { name: 'Manage Roles', route: '/manage-roles', permission: 'Roles.View' },
      { name: 'Manage Permissions', route: '/manage-permissions', permission: 'Permissions.View' },
      { name: 'Operational Lookups', route: '/manage-lookups', permission: 'Lookups.View' },
      { name: 'Warehouse Sections', route: '/manage-warehouse-sections', permission: 'WarehouseSections.View' },
      { name: 'System Settings', route: '/manage-system-settings', permission: 'SystemSettings.View' },
      { name: 'Manage Help', route: '/manage-help', permission: 'Help.Manage' },
      { name: 'Training Media', route: '/manage-help-media', permission: 'HelpMedia.Manage' },
      { name: 'Make Product', route: '/make-product', permission: 'Products.Make' },
      { name: 'Raw Stock', route: '/raw-stock', permission: 'RawStock.View' },
      { name: 'Buying Lists', route: '/buying-lists', permission: 'BuyingList.View' },
      { name: 'Customers', route: '/customers', permission: 'Customers.View' },
      { name: 'Suppliers & Orders', route: '/suppliers', permission: 'Suppliers.View' },
      { name: 'Payments', route: '/payments', permission: 'Payments.View' },
      { name: 'Product Overview', route: '/search-product', permission: 'Products.View' },
      { name: 'Expiry Alerts', route: '/expiry-alerts', permission: 'Expiry.View' },
      { name: 'Product Types', route: '/manage-product-types', permission: 'ProductTypes.Manage' },
      { name: 'Product Categories', route: '/manage-product-categories', permission: 'ProductCategories.Manage' },
      { name: 'Product Hierarchy', route: '/product-hierarchy', permission: 'ProductHierarchy.View' },
      { name: 'Add Product', route: '/add-product', permission: 'ProductHierarchy.Manage' },
      { name: 'Product Excel Exchange', route: '/product-data-exchange', permission: 'ProductDataExchange.Export' },
      { name: 'Stock Count Exchange', route: '/stock-count-data-exchange', permission: 'StockCountExchange.Export' },
      { name: 'Operations Calendar', route: '/operations-calendar', permission: 'OperationsCalendar.View' },
      { name: 'Track Driver', route: '/mobile-operations-control', permission: 'Mobile.Tracking.ViewAll' },
      { name: 'Scan Product Batch', route: '/scan-product-batch', permission: 'ProductBatchScanner.View' },
      { name: 'Order Management', route: '/order-management', permission: 'Orders.View' },
      { name: 'Pricing Management', route: '/pricing', permission: 'Pricing.View' },
      { name: 'Delivery Management', route: '/deliveries', permission: 'Deliveries.AssignDriver' },
      { name: 'Audit Logs', route: '/audit-logs', permission: 'AuditLogs.View' }
    ];
    this.menuItems = items
      .filter(item => this.can(item.permission))
      .map(({ permission: _permission, ...item }) => item);
  }
}
