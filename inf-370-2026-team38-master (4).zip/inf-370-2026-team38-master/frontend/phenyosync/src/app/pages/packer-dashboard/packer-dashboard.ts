/**
 * Reviewer guide: Coordinates the packer dashboard page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SidebarComponent } from '../../components/sidebar/sidebar';

// Summarizes packing workload while the API remains authoritative for allocation state.
@Component({
  selector: 'app-packer-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, TopbarComponent, SidebarComponent],
  templateUrl: './packer-dashboard.component.html',
  styleUrls: ['./packer-dashboard.component.css']
})
export class PackerDashboardComponent {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  menuItems = [
    { name: 'Packer Dashboard', route: '/packer-dashboard', active: true },
    { name: 'Make Product', route: '/make-product' },
    { name: 'Product Overview', route: '/search-product' },
    { name: 'Expiry Alerts', route: '/expiry-alerts' },
    { name: 'Product Hierarchy', route: '/product-hierarchy' },
    { name: 'Operations Calendar', route: '/operations-calendar' },
    { name: 'Scan Product Batch', route: '/scan-product-batch' },
    { name: 'View Pick List', route: '/view-pick-list' },
    { name: 'Pack Customer Order', route: '/pack-customer-order' },
    { name: 'Update Packing Status', route: '/update-packing-status' },
    { name: 'Report Damaged Item' },
    { name: 'Logout' }
  ];

  actions = [
    { title: 'Make Product', description: 'Record a production batch, increase stock, and print its QR label.', route: '/make-product', icon: '+' },
    { title: 'Product Overview', description: 'Find Products by name, category, Product code or Batch QR.', route: '/search-product', icon: '⌕' },
    { title: 'Expiry Alerts', description: 'View yellow warning, urgent red, and expired batches.', route: '/expiry-alerts', icon: '⚠' },
    { title: 'View Pick List', description: 'View items that need to be packed.', route: '/view-pick-list', icon: '▤' },
    { title: 'Pack Customer Order', description: 'Confirm products packed for delivery.', route: '/pack-customer-order', icon: '□' },
    { title: 'Update Packing Status', description: 'Update order packing progress.', route: '/update-packing-status', icon: '✓' },
    { title: 'Report Damaged Item', description: 'Record damaged items found while packing.', route: '/report-damaged-item', icon: '!' }
  ];
}
