/**
 * Reviewer guide: Verifies the customer form frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ChangeDetectorRef } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, provideRouter, Router } from '@angular/router';
import { TestBed } from '@angular/core/testing';
import { Observable, Subject, of } from 'rxjs';
import { NotificationService } from '../../services/notification';
import {
  CustomerSummary,
  OperationalSectionsService
} from '../../services/operational-sections';
import { CustomerForm } from './customer-form';

const existingCustomer: CustomerSummary = {
  customerId: 12,
  customerNumber: 'CUS-000012',
  customerName: 'Fresh Foods',
  email: 'accounts@freshfoods.example',
  contactPerson: 'A. Buyer',
  phoneNumber: '0123456789',
  billingAddress: '12 Market Street',
  deliveryAddress: '34 Warehouse Road',
  status: 'Active',
  orderCount: 2,
  outstandingBalance: 120,
  rowVersion: 'row-version'
};

// Protects normalized customer input and create/edit payload boundaries.
describe('CustomerForm', () => {
  function createComponent(
    id: string | null,
    saveResult: Observable<CustomerSummary> = of(existingCustomer)
  ) {
    const customerCalls: number[] = [];
    const saveCalls: Array<{ id: number | null; request: Record<string, unknown> }> = [];
    const navigationCalls: unknown[][] = [];
    const operational = {
      customer: (customerId: number) => {
        customerCalls.push(customerId);
        return of(existingCustomer);
      },
      saveCustomer: (customerId: number | null, request: Record<string, unknown>) => {
        saveCalls.push({ id: customerId, request });
        return saveResult;
      }
    };
    const router = {
      navigate: (commands: unknown[]) => navigationCalls.push(commands)
    };
    const notifications = {
      success: () => undefined,
      error: () => undefined
    };

    TestBed.configureTestingModule({
      providers: [FormBuilder]
    });

    const component = TestBed.runInInjectionContext(() => new CustomerForm(
      {
        snapshot: {
          paramMap: { get: () => id }
        }
      } as unknown as ActivatedRoute,
      router as unknown as Router,
      operational as unknown as OperationalSectionsService,
      notifications as unknown as NotificationService,
      { detectChanges: () => undefined } as ChangeDetectorRef
    ));

    return {
      component,
      customerCalls,
      saveCalls,
      navigationCalls
    };
  }

  // Reviewer note: Guards the observable rule that loads and preserves both customer addresses when editing.
  it('loads and preserves both customer addresses when editing', () => {
    const { component, customerCalls, saveCalls } = createComponent('12');

    component.ngOnInit();
    component.save();

    expect(customerCalls).toEqual([12]);
    expect(saveCalls).toHaveLength(1);
    expect(saveCalls[0].id).toBe(12);
    expect(saveCalls[0].request).toEqual(expect.objectContaining({
      billingAddress: '12 Market Street',
      deliveryAddress: '34 Warehouse Road',
      rowVersion: 'row-version'
    }));
  });

  // Reviewer note: Guards the observable rule that blocks duplicate submissions while a save is in progress.
  it('blocks duplicate submissions while a save is in progress', () => {
    const pending = new Subject<CustomerSummary>();
    const { component, saveCalls } = createComponent(null, pending);
    component.ngOnInit();
    component.form.patchValue({
      customerName: 'Fresh Foods',
      email: 'accounts@freshfoods.example'
    });

    component.save();
    component.save();

    expect(saveCalls).toHaveLength(1);
    pending.next(existingCustomer);
    pending.complete();
  });

  // Reviewer note: Guards the observable rule that renders one submit action without exposing a customer primary key.
  it('renders one submit action without exposing a customer primary key', async () => {
    await TestBed.configureTestingModule({
      imports: [CustomerForm],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              paramMap: { get: () => null }
            }
          }
        },
        {
          provide: OperationalSectionsService,
          useValue: {
            customer: () => of(existingCustomer),
            saveCustomer: () => of(existingCustomer)
          }
        },
        {
          provide: NotificationService,
          useValue: {
            success: () => undefined,
            error: () => undefined
          }
        }
      ]
    }).compileComponents();

    const fixture = TestBed.createComponent(CustomerForm);
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    const submitButtons = element.querySelectorAll('button[type="submit"]');

    expect(submitButtons).toHaveLength(1);
    expect(submitButtons[0].textContent?.trim()).toBe('Create customer');
    expect(element.textContent).not.toContain('Customer ID');
  });
});
