/**
 * Reviewer guide: Coordinates the customer form page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { finalize, take } from 'rxjs';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';
import { NotificationService } from '../../services/notification';
import { OperationalSectionsService } from '../../services/operational-sections';

@Component({
  selector: 'app-customer-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink,
    TopbarComponent,
    SidebarComponent
  ],
  templateUrl: './customer-form.html',
  styleUrl: './customer-form.css'
})
/** Creates or edits customer master data using server validation and concurrency responses. */
export class CustomerForm implements OnInit {
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  private readonly formBuilder = inject(FormBuilder);

  customerId: number | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  loadFailed = false;

  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Customers', route: '/customers' },
    { name: 'Sales Orders', route: '/order-management' },
    { name: 'Customer Payments', route: '/payments' }
  ];

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly form = this.formBuilder.nonNullable.group({
    customerName: ['', [Validators.required, Validators.maxLength(150)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(254)]],
    contactPerson: ['', Validators.maxLength(150)],
    phoneNumber: ['', Validators.maxLength(30)],
    billingAddress: ['', Validators.maxLength(500)],
    deliveryAddress: ['', Validators.maxLength(500)],
    status: ['Active', Validators.required],
    rowVersion: ['']
  });

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly operational: OperationalSectionsService,
    private readonly notifications: NotificationService,
    private readonly changeDetector: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.customerId = Number.isInteger(id) && id > 0 ? id : null;

    if (this.customerId) {
      this.loadCustomer(this.customerId);
    }
  }

  /**
   * Reviewer note: Encapsulates the title view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get title(): string {
    return this.customerId ? 'Edit customer' : 'Create customer';
  }

  /**
   * Reviewer note: Coordinates the save interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  save(): void {
    if (this.form.invalid || this.loading || this.saving || this.loadFailed) {
      this.form.markAllAsTouched();
      queueMicrotask(() =>
        document.querySelector<HTMLElement>('.customer-form-card .ng-invalid')?.focus());
      return;
    }

    this.saving = true;
    this.operational.saveCustomer(
      this.customerId,
      this.form.getRawValue()
    ).pipe(
      take(1),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: customer => {
        this.notifications.success(
          this.customerId ? 'Customer updated.' : 'Customer created.');
        this.router.navigate(['/customers', customer.customerId]);
      },
      error: error => this.notifications.error(
        error?.error?.message || 'The customer could not be saved.')
    });
  }

  /**
   * Reviewer note: Coordinates load customer so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private loadCustomer(customerId: number): void {
    this.loading = true;
    this.operational.customer(customerId).pipe(
      take(1),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: customer => this.form.reset({
        customerName: customer.customerName,
        email: customer.email,
        contactPerson: customer.contactPerson ?? '',
        phoneNumber: customer.phoneNumber ?? '',
        billingAddress: customer.billingAddress ?? '',
        deliveryAddress: customer.deliveryAddress ?? '',
        status: customer.status,
        rowVersion: customer.rowVersion
      }),
      error: error => {
        this.loadFailed = true;
        this.notifications.error(
          error?.error?.message || 'The customer could not be loaded.');
      }
    });
  }
}
