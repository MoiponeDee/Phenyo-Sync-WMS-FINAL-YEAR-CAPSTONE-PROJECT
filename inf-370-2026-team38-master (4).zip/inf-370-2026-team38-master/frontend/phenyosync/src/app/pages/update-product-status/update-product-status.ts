/**
 * Reviewer guide: Coordinates the update product status page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { finalize, take } from 'rxjs';
import { ProductResponse, ProductService } from '../../services/product';

@Component({
  selector: 'app-update-product-status',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './update-product-status.html',
  styleUrl: './update-product-status.css'
})
/** Requests an audited product activation/deactivation while relationship checks remain server-side. */
export class UpdateProductStatus implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  products: ProductResponse[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedProductId: number | null = null;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selected: ProductResponse | null = null;
  newStatus: 'Active' | 'Inactive' = 'Active';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  showConfirmation = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(private service: ProductService, private cdr: ChangeDetectorRef, private router: Router) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.loading = true;
    this.service.getProducts().pipe(finalize(() => { this.loading = false; this.cdr.detectChanges(); }))
      .subscribe({
        next: products => this.products = products.sort((a, b) => a.productName.localeCompare(b.productName)),
        error: error => this.fail(error, 'Unable to load products.')
      });
  }

  /**
   * Reviewer note: Encapsulates the on selected view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  onSelected(): void {
    this.selected = this.products.find(item => item.productId === this.selectedProductId) ?? null;
    if (this.selected) this.newStatus = this.selected.status === 'Active' ? 'Inactive' : 'Active';
    this.successMessage = '';
    this.errorMessage = '';
  }

  /**
   * Reviewer note: Encapsulates the request update view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  requestUpdate(): void {
    if (!this.selected) { this.errorMessage = 'Select a product first.'; return; }
    if (this.selected.status === this.newStatus) { this.errorMessage = `The product is already ${this.newStatus}.`; return; }
    this.showConfirmation = true;
  }

  /**
   * Reviewer note: Encapsulates the confirm update view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  confirmUpdate(): void {
    if (!this.selected || this.saving) return;
    this.saving = true;
    this.service.changeProductStatus(this.selected.productId, this.newStatus).pipe(
      take(1), finalize(() => { this.saving = false; this.cdr.detectChanges(); })
    ).subscribe({
      next: response => {
        if (this.selected) this.selected.status = this.newStatus;
        this.showConfirmation = false;
        this.successMessage = response.message;
        this.errorMessage = '';
      },
      error: error => this.fail(error, 'Unable to update product status.')
    });
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void { this.router.navigate(['/admin-dashboard']); }
  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown, fallback: string): void {
    console.error('Product status error:', error);
    this.errorMessage = error instanceof HttpErrorResponse ? error.error?.message || fallback : fallback;
  }
}
