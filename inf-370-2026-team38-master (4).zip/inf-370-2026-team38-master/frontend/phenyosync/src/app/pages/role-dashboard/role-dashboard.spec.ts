/**
 * Reviewer guide: Verifies the Super Admin overview composition and preserves permission filtering.
 * The tests use the same typed dashboard response consumed by the running route.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of, Subject } from 'rxjs';
import { AuthorizationService } from '../../services/authorization';
import {
  RoleDashboardData,
  RoleDashboardService
} from '../../services/role-dashboard';
import { RoleDashboard } from './role-dashboard';

const adminDashboard: RoleDashboardData = {
  roleCode: 'Admin',
  title: 'Administrator dashboard',
  subtitle: 'Prioritise customer orders, pricing, procurement and administration.',
  fromUtc: '2026-09-01T00:00:00Z',
  toUtc: '2026-09-24T23:59:59Z',
  metrics: [
    { label: 'Awaiting order decision', value: 3, valueKind: 'number', detail: 'Orders requiring review.', route: '/order-management' },
    { label: 'Active customers', value: 11, valueKind: 'number', detail: 'Current customers.', route: '/customers' },
    { label: 'Products without a current price', value: 2, valueKind: 'number', detail: 'Pricing attention.', route: '/pricing' },
    { label: 'Active users', value: 9, valueKind: 'number', detail: 'Enabled accounts.', route: '/manage-users' }
  ],
  attentionItems: [
    { label: 'Orders awaiting a decision', value: 3, detail: 'Review submitted orders.', route: '/order-management', severity: 'warning' },
    { label: 'Products without a current price', value: 2, detail: 'Publish a valid price.', route: '/pricing', severity: 'critical' },
    { label: 'Open buying lists', value: 0, detail: 'Keep procurement moving.', route: '/buying-lists', severity: 'warning' }
  ],
  recentActivity: [
    {
      auditLogId: 42,
      occurredAtUtc: '2026-09-24T08:30:00Z',
      operationName: 'UpdateUserAccess',
      systemModule: 'SecurityAdministration',
      entityDisplay: 'User #8',
      actorDisplayName: 'Miranda Jones',
      success: true
    }
  ],
  barChart: {
    title: 'Customer orders by status',
    description: 'Current workflow position.',
    valueKind: 'number',
    points: [{ label: 'Submitted', value: 3, count: 3 }]
  },
  lineChart: {
    title: 'Customer orders',
    description: 'Orders created during the selected period.',
    valueKind: 'number',
    points: [{ label: '2026-09-24', value: 2, count: 2 }]
  }
};

describe('RoleDashboard Super Admin overview', () => {
  let fixture: ComponentFixture<RoleDashboard>;
  let component: RoleDashboard;
  let granted: Set<string>;
  let dashboardService: { load: ReturnType<typeof vi.fn> };

  const render = (response = adminDashboard): HTMLElement => {
    dashboardService.load.mockReturnValue(of(response));
    fixture = TestBed.createComponent(RoleDashboard);
    component = fixture.componentInstance;
    fixture.detectChanges();
    return fixture.nativeElement as HTMLElement;
  };

  beforeEach(async () => {
    granted = new Set([
      'Orders.View', 'Orders.Create', 'Customers.View', 'Pricing.View',
      'Users.View', 'Users.Create', 'BuyingList.View', 'Reports.View',
      'ProductHierarchy.Manage', 'SystemSettings.View', 'AuditLogs.View'
    ]);
    dashboardService = { load: vi.fn() };

    await TestBed.configureTestingModule({
      imports: [RoleDashboard],
      providers: [
        provideRouter([]),
        { provide: RoleDashboardService, useValue: dashboardService },
        {
          provide: AuthorizationService,
          useValue: { has: (permission: string) => granted.has(permission) }
        }
      ]
    }).compileComponents();
  });

  it('binds live Super Admin KPIs into the approved overview structure', () => {
    const element = render();

    expect(element.querySelector('.command-surface')).not.toBeNull();
    expect(element.querySelector('.overview-header h1')?.textContent).toContain('Administrator dashboard');
    expect(element.querySelectorAll('.admin-metrics .metric-card').length).toBe(4);
    expect(element.textContent).toContain('Awaiting order decision');
    expect(element.textContent).toContain('Customer orders');
  });

  it('renders a visible y-axis title and five numeric trend ticks', () => {
    const element = render();
    const chart = element.querySelector('.line-chart');
    const ticks = chart?.querySelectorAll('.y-axis-tick text') ?? [];

    expect(chart?.querySelector('.y-axis-title')?.textContent).toContain('Number of records');
    expect(ticks.length).toBe(5);
    expect(Array.from(ticks).map(tick => tick.textContent?.trim()))
      .toEqual(['2', '1,5', '1', '0,5', '0']);
  });

  it('filters quick actions and command search by effective permissions', () => {
    granted = new Set(['Users.Create', 'Reports.View']);
    const element = render();

    const actions = Array.from(element.querySelectorAll('.quick-action-list a'))
      .map(item => item.textContent?.trim());
    expect(actions.some(item => item?.includes('Create user'))).toBe(true);
    expect(actions.some(item => item?.includes('Reports'))).toBe(true);
    expect(actions.some(item => item?.includes('System settings'))).toBe(false);

    component.commandQuery = 'report';
    expect(component.commandMatches.map(item => item.label)).toEqual(['Reports']);
  });

  it('renders only actionable, permitted attention links', () => {
    granted = new Set(['Orders.View']);
    const element = render();
    const attention = Array.from(element.querySelectorAll('.attention-item'));

    expect(attention.length).toBe(1);
    expect(attention[0].textContent).toContain('Orders awaiting a decision');
    expect(attention[0].getAttribute('href')).toBe('/order-management');
  });

  it('shows safe recent activity summaries and the audit destination', () => {
    const element = render();

    expect(element.querySelector('.activity-row')?.textContent).toContain('Update User Access');
    expect(element.querySelector('.activity-row')?.textContent).toContain('User #8');
    expect(element.querySelector('.activity-card a')?.getAttribute('href')).toBe('/audit-logs');
  });

  it('shows deliberate empty states for metrics, attention and activity', () => {
    const element = render({
      ...adminDashboard,
      metrics: [],
      attentionItems: [],
      recentActivity: [],
      barChart: { ...adminDashboard.barChart, points: [] },
      lineChart: { ...adminDashboard.lineChart, points: [] }
    });

    expect(element.textContent).toContain('No KPI data is available for this period.');
    expect(element.textContent).toContain('No outstanding attention items');
    expect(element.textContent).toContain('No audited activity was recorded for this period.');
  });

  it('surfaces loading and API failure states without stale success content', () => {
    const request = new Subject<RoleDashboardData>();
    dashboardService.load.mockReturnValue(request);
    fixture = TestBed.createComponent(RoleDashboard);
    fixture.detectChanges();

    expect((fixture.nativeElement as HTMLElement).textContent)
      .toContain('Loading current operational data…');

    request.error({ error: { message: 'Dashboard service unavailable.' } });
    fixture.detectChanges();
    expect((fixture.nativeElement as HTMLElement).querySelector('[role="alert"]')?.textContent)
      .toContain('Dashboard service unavailable.');
  });

  it('retains exact navigation permission checks for metric routes', () => {
    render();
    expect(component.canOpenMetric('/customers')).toBe(true);
    granted.add('RawStockTakes.View');
    expect(component.canOpenMetric('/raw-stock/approvals?tab=takes')).toBe(true);
    expect(component.canOpenMetric('/unknown-page')).toBe(false);
    expect(component.canOpenMetric()).toBe(false);
  });

  it('keeps approval query parameters separate from the protected route path', () => {
    render();

    expect(component.routePath('/raw-stock/approvals?tab=takes'))
      .toBe('/raw-stock/approvals');
    expect(component.routeQueryParams('/raw-stock/approvals?tab=takes'))
      .toEqual({ tab: 'takes' });
    expect(component.routeQueryParams('/customers')).toBeNull();
  });

  it('renders the Warehouse Manager operational overview with warehouse-only actions', () => {
    granted = new Set([
      'RawStock.View', 'RawStock.Receive', 'RawStockTakes.Capture',
      'Expiry.View', 'Packing.View'
    ]);
    const element = render({
      ...adminDashboard,
      roleCode: 'WarehouseManager',
      title: 'Warehouse Manager dashboard',
      metrics: [
        ...adminDashboard.metrics,
        { label: 'Low raw stock', value: 2, valueKind: 'number', detail: 'Needs replenishment.', route: '/raw-stock' },
        { label: 'Packing workload', value: 4, valueKind: 'number', detail: 'Approved orders.', route: '/view-pick-list' }
      ]
    });

    expect(element.querySelector('.command-surface')).not.toBeNull();
    expect(element.querySelector('.command-surface h2')?.textContent).toContain('Global Search');
    expect(element.querySelector('.overview-header h1')?.textContent)
      .toContain('Warehouse Manager dashboard');
    expect(element.textContent).toContain('Receive stock');
    expect(element.textContent).toContain('Start stock take');
    expect(element.textContent).not.toContain('Create user');
  });

  it('renders the Operations Manager overview with permission-filtered management actions', () => {
    granted = new Set([
      'BuyingList.View', 'Reports.View', 'Orders.View',
      'Deliveries.View', 'CustomerPayments.View', 'Mobile.Tracking.ViewAll',
      'RawStockTakes.View', 'RawStockTakes.Approve'
    ]);
    const element = render({
      ...adminDashboard,
      roleCode: 'OperationsManager',
      title: 'Operations Manager dashboard'
    });
    const actions = Array.from(element.querySelectorAll('.quick-action-list a'))
      .map(item => item.textContent?.trim());

    expect(element.querySelector('.command-surface')).not.toBeNull();
    expect(element.querySelector('.command-surface h2')?.textContent).toContain('Global Search');
    expect(actions.some(item => item?.includes('Buying Lists'))).toBe(true);
    expect(actions.some(item => item?.includes('Track driver'))).toBe(true);
    expect(actions.some(item => item?.includes('Review stock takes'))).toBe(true);
    expect(actions.some(item => item?.includes('Raw stock'))).toBe(false);
    expect(element.querySelector<HTMLAnchorElement>(
      'a[href="/raw-stock/approvals?tab=takes"]')).not.toBeNull();
  });
});
