/**
 * Reviewer guide: Coordinates the role dashboard page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import {
  DashboardAttentionItem,
  DashboardChart,
  RoleDashboardData,
  RoleDashboardService
} from '../../services/role-dashboard';
import { AuthorizationService } from '../../services/authorization';
import { WMS_NAVIGATION } from '../../navigation/navigation.config';
import { HumanizeCodePipe } from '../../pipes/humanize-code.pipe';
import { SearchFieldComponent } from '../../components/search-field/search-field';

interface DashboardCommand {
  label: string;
  description: string;
  route: string;
  permission: string;
  icon: string;
  roleCodes: readonly string[];
}

@Component({
  selector: 'app-role-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, HumanizeCodePipe, SearchFieldComponent],
  templateUrl: './role-dashboard.html',
  styleUrl: './role-dashboard.css'
})
/** Displays backend-selected cards and actions for the current effective role. */
export class RoleDashboard implements OnInit {
  data?: RoleDashboardData;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  fromDate = '';
  toDate = '';
  commandQuery = '';

  readonly commandCatalog: readonly DashboardCommand[] = [
    {
      label: 'Create user',
      description: 'Open user administration and create a secure account.',
      route: '/manage-users',
      permission: 'Users.Create',
      icon: '＋',
      roleCodes: ['Admin']
    },
    {
      label: 'Create customer order',
      description: 'Start a new customer order using the supported order workflow.',
      route: '/create-order',
      permission: 'Orders.Create',
      icon: '▤',
      roleCodes: ['Admin']
    },
    {
      label: 'Add product',
      description: 'Add a product to the configured category and type hierarchy.',
      route: '/add-product',
      permission: 'ProductHierarchy.Manage',
      icon: '＋',
      roleCodes: ['Admin']
    },
    {
      label: 'Buying Lists',
      description: 'Review current procurement requirements and buying work.',
      route: '/buying-lists',
      permission: 'BuyingList.View',
      icon: '✓',
      roleCodes: ['Admin', 'OperationsManager']
    },
    {
      label: 'Pricing',
      description: 'Review current prices and controlled price history.',
      route: '/pricing',
      permission: 'Pricing.View',
      icon: 'R',
      roleCodes: ['Admin']
    },
    {
      label: 'Reports',
      description: 'Open operational and management reports.',
      route: '/reports',
      permission: 'Reports.View',
      icon: '▥',
      roleCodes: ['Admin', 'OperationsManager']
    },
    {
      label: 'System settings',
      description: 'Maintain authorised configurable business rules.',
      route: '/manage-system-settings',
      permission: 'SystemSettings.View',
      icon: '⚙',
      roleCodes: ['Admin']
    },
    {
      label: 'Receive stock',
      description: 'Receive a controlled Supplier Order or Buying List source.',
      route: '/raw-stock', permission: 'RawStock.Receive', icon: '↓',
      roleCodes: ['WarehouseManager']
    },
    {
      label: 'Start stock take',
      description: 'Open a movement-ledger reconciliation session.',
      route: '/raw-stock', permission: 'RawStockTakes.Capture', icon: '≋',
      roleCodes: ['WarehouseManager']
    },
    {
      label: 'Raw stock',
      description: 'Review balances, batches and warehouse stock activity.',
      route: '/raw-stock', permission: 'RawStock.View', icon: '◇',
      roleCodes: ['WarehouseManager']
    },
    {
      label: 'Expiry alerts',
      description: 'Inspect product batches requiring expiry action.',
      route: '/expiry-alerts', permission: 'Expiry.View', icon: '!',
      roleCodes: ['WarehouseManager']
    },
    {
      label: 'Packing queue',
      description: 'Review approved fulfilment work and shortages.',
      route: '/view-pick-list', permission: 'Packing.View', icon: '□',
      roleCodes: ['WarehouseManager']
    },
    {
      label: 'Customer orders',
      description: 'Review operational order progress and exceptions.',
      route: '/search-orders', permission: 'Orders.View', icon: '▤',
      roleCodes: ['OperationsManager']
    },
    {
      label: 'Deliveries',
      description: 'Review assignment and in-progress delivery work.',
      route: '/deliveries', permission: 'Deliveries.View', icon: '➜',
      roleCodes: ['OperationsManager']
    },
    {
      label: 'Payments',
      description: 'Review customer and supplier payments and exceptions.',
      route: '/payments', permission: 'CustomerPayments.View', icon: 'R',
      roleCodes: ['OperationsManager']
    },
    {
      label: 'Review stock takes',
      description: 'Decide reviewed reconciliation discrepancies awaiting management approval.',
      route: '/raw-stock/approvals?tab=takes', permission: 'RawStockTakes.Approve', icon: '≋',
      roleCodes: ['OperationsManager']
    },
    {
      label: 'Review write-offs',
      description: 'Decide controlled raw-stock loss requests.',
      route: '/raw-stock/approvals?tab=writeoffs', permission: 'RawStock.ApproveWriteOff', icon: '!',
      roleCodes: ['OperationsManager']
    },
    {
      label: 'Track driver',
      description: 'Open the authorised live delivery tracking workspace.',
      route: '/mobile-operations-control', permission: 'Mobile.Tracking.ViewAll', icon: '◉',
      roleCodes: ['OperationsManager']
    }
  ];

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly dashboards: RoleDashboardService,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    const today = new Date();
    const from = new Date(today);
    from.setDate(from.getDate() - 29);
    this.fromDate = this.localDate(from);
    this.toDate = this.localDate(today);
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    if (!this.fromDate || !this.toDate || this.fromDate > this.toDate) {
      this.errorMessage = 'Choose a valid date range.';
      return;
    }

    this.loading = true;
    this.errorMessage = '';
    const fromUtc = new Date(`${this.fromDate}T00:00:00`).toISOString();
    const to = new Date(`${this.toDate}T23:59:59.999`);

    this.dashboards.load(fromUtc, to.toISOString()).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: data => {
        this.data = data;
        this.changeDetector.detectChanges();
      },
      error: error => {
        this.errorMessage = error.error?.message ||
          'Dashboard data could not be loaded. Try again.';
        this.changeDetector.detectChanges();
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the formatted view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  formatted(value: number, kind: string): string {
    if (kind === 'currency') {
      return new Intl.NumberFormat('en-ZA', {
        style: 'currency',
        currency: 'ZAR',
        maximumFractionDigits: 2
      }).format(value);
    }
    if (kind === 'kilograms') {
      return `${new Intl.NumberFormat('en-ZA', { maximumFractionDigits: 2 }).format(value)} kg`;
    }
    if (kind === 'percentage') {
      return `${new Intl.NumberFormat('en-ZA', { maximumFractionDigits: 1 }).format(value)}%`;
    }
    return new Intl.NumberFormat('en-ZA', { maximumFractionDigits: 2 }).format(value);
  }

  /**
   * Reviewer note: Encapsulates the bar width view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  barWidth(value: number, chart: DashboardChart): number {
    const maximum = Math.max(...chart.points.map(point => Math.abs(point.value)), 1);
    return Math.max(value !== 0 ? 3 : 0, Math.round((Math.abs(value) / maximum) * 100));
  }

  /**
   * Reviewer note: Encapsulates the line points view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  linePoints(chart: DashboardChart): string {
    if (!chart.points.length) return '';
    const left = 90;
    const right = 640;
    const span = Math.max(chart.points.length - 1, 1);

    return chart.points.map((point, index) => {
      const x = left + (index / span) * (right - left);
      const y = this.lineY(point.value, chart);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
  }

  /** Provides visible, evenly spaced numeric y-axis values for management trend charts. */
  lineYTicks(chart: DashboardChart): Array<{ value: number; y: number; label: string }> {
    const maximum = this.lineMaximum(chart);
    return [1, .75, .5, .25, 0].map(fraction => {
      const value = maximum * fraction;
      return {
        value,
        y: this.lineY(value, chart),
        label: this.compactAxisValue(value, chart.valueKind)
      };
    });
  }

  private lineY(value: number, chart: DashboardChart): number {
    const top = 15;
    const bottom = 160;
    return bottom - (Math.max(value, 0) / this.lineMaximum(chart)) * (bottom - top);
  }

  private lineMaximum(chart: DashboardChart): number {
    return Math.max(...chart.points.map(point => point.value), 1);
  }

  private compactAxisValue(value: number, kind: string): string {
    const formatted = new Intl.NumberFormat('en-ZA', {
      notation: Math.abs(value) >= 1000 ? 'compact' : 'standard',
      maximumFractionDigits: value < 10 ? 1 : 0
    }).format(value);
    if (kind === 'currency') return `R${formatted}`;
    if (kind === 'kilograms') return `${formatted} kg`;
    if (kind === 'percentage') return `${formatted}%`;
    return formatted;
  }

  axisLabel(kind: string): string {
    if (kind === 'currency') return 'Value (rand)';
    if (kind === 'kilograms') return 'Quantity (kg)';
    if (kind === 'percentage') return 'Percentage (%)';
    return 'Number of records';
  }

  /**
   * Reviewer note: Calculates can open metric for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canOpenMetric(route?: string): boolean {
    if (!route) return false;

    if (route.startsWith('/raw-stock/approvals?tab=takes')) {
      return this.authorization.has('RawStockTakes.View');
    }
    if (route.startsWith('/raw-stock/approvals?tab=writeoffs')) {
      return this.authorization.has('RawStock.ApproveWriteOff');
    }

    const item = WMS_NAVIGATION
      .flatMap(section => section.items)
      .find(candidate => candidate.route === route.split('?')[0]);

    return item !== undefined &&
      (!item.permissions?.length ||
        item.permissions.some(permission =>
          this.authorization.has(permission)));
  }

  /** Presentation helper only; API policies remain authoritative for every destination. */
  can(permission: string): boolean {
    return this.authorization.has(permission);
  }

  /** Returns only the route path so Angular does not encode a query string as a path segment. */
  routePath(route: string): string {
    return route.split('?')[0];
  }

  /** Converts the dashboard DTO query string into Angular Router query parameters. */
  routeQueryParams(route: string): Record<string, string> | null {
    const query = route.split('?')[1];
    if (!query) return null;

    return Object.fromEntries(new URLSearchParams(query).entries());
  }

  /** Selects the approved overview composition only for the persisted Super Admin role. */
  isAdministratorDashboard(dashboard: RoleDashboardData): boolean {
    return dashboard.roleCode === 'Admin';
  }

  usesOperationsOverview(dashboard: RoleDashboardData): boolean {
    return ['Admin', 'WarehouseManager', 'OperationsManager']
      .includes(dashboard.roleCode);
  }

  dashboardEyebrow(dashboard: RoleDashboardData): string {
    if (dashboard.roleCode === 'WarehouseManager') return 'Warehouse operations';
    if (dashboard.roleCode === 'OperationsManager') return 'Management oversight';
    return 'Operations command centre';
  }

  /** Keeps dashboard shortcuts aligned with the current backend-derived permission snapshot. */
  get quickActions(): DashboardCommand[] {
    const roleCode = this.data?.roleCode;
    return this.commandCatalog.filter(command =>
      Boolean(roleCode) && command.roleCodes.includes(roleCode!) &&
      this.authorization.has(command.permission));
  }

  /** Turns the prominent search treatment into a real, scoped workspace command finder. */
  get commandMatches(): DashboardCommand[] {
    const query = this.commandQuery.trim().toLocaleLowerCase();
    if (!query) return [];

    return this.quickActions.filter(command =>
      `${command.label} ${command.description}`.toLocaleLowerCase().includes(query));
  }

  /** Shows only non-zero work that the current user can actually open. */
  visibleAttentionItems(dashboard: RoleDashboardData): DashboardAttentionItem[] {
    return dashboard.attentionItems.filter(item =>
      item.value > 0 && this.canOpenMetric(item.route));
  }

  /** Presents the active reporting period without exposing UTC formatting details. */
  dateContext(): string {
    if (!this.fromDate || !this.toDate) return 'Current operational period';

    const from = new Date(`${this.fromDate}T12:00:00`);
    const to = new Date(`${this.toDate}T12:00:00`);
    const fromLabel = new Intl.DateTimeFormat('en-ZA', {
      day: 'numeric',
      month: 'short'
    }).format(from);
    const toLabel = new Intl.DateTimeFormat('en-ZA', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    }).format(to);
    return `${fromLabel} – ${toLabel}`;
  }

  /** Formats safe audit-list timestamps for the latest-activity panel. */
  activityTime(value: string): string {
    return new Intl.DateTimeFormat('en-ZA', {
      dateStyle: 'medium',
      timeStyle: 'short'
    }).format(new Date(value));
  }

  /**
   * Reviewer note: Encapsulates the local date view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private localDate(value: Date): string {
    const offset = value.getTimezoneOffset() * 60_000;
    return new Date(value.getTime() - offset).toISOString().slice(0, 10);
  }
}
