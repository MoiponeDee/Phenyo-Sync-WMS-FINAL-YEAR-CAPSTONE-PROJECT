/**
 * Reviewer guide: Coordinates the report catalog page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { ReportKey } from '../../services/formal-reports';

export interface ReportDefinition {
  key: ReportKey;
  title: string;
  eyebrow: string;
  classification: string;
  summary: string;
  route: string;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  viewPermission: string;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  exportPermission: string;
  icon: string;
}

// Central report metadata keeps route labels, required permissions and criteria UI consistent.
export const REPORT_CATALOG: readonly ReportDefinition[] = [
  {
    key: 'inventory',
    title: 'Inventory Position',
    eyebrow: 'Warehouse visibility',
    classification: 'Simple list report',
    summary: 'Review available, reserved and total quantities by product and section.',
    route: '/reports/inventory',
    viewPermission: 'Reports.Inventory.View',
    exportPermission: 'Reports.Inventory.ExportPdf',
    icon: 'INV'
  },
  {
    key: 'sales',
    title: 'Sales by Customer and Product',
    eyebrow: 'Commercial performance',
    classification: 'Transactional control-break report',
    summary: 'Analyse historical sales snapshots with month, customer and order control breaks.',
    route: '/reports/sales',
    viewPermission: 'Reports.Sales.View',
    exportPermission: 'Reports.Sales.ExportPdf',
    icon: 'SAL'
  },
  {
    key: 'financial',
    title: 'Financial Activity',
    eyebrow: 'Cash and obligations',
    classification: 'Adjustable-criteria report',
    summary: 'Combine invoice, receipt, supplier-payment and write-off activity using selected criteria.',
    route: '/reports/financial',
    viewPermission: 'Reports.Financial.View',
    exportPermission: 'Reports.Financial.ExportPdf',
    icon: 'FIN'
  },
  {
    key: 'stock-movement',
    title: 'Stock Movement',
    eyebrow: 'Traceability',
    classification: 'Transactional control-break report',
    summary: 'Trace finished and raw-stock movements by domain, category and item.',
    route: '/reports/stock-movement',
    viewPermission: 'Reports.StockMovement.View',
    exportPermission: 'Reports.StockMovement.ExportPdf',
    icon: 'MOV'
  },
  {
    key: 'expiry-waste',
    title: 'Expiry and Waste Risk',
    eyebrow: 'Loss prevention',
    classification: 'Simple list report',
    summary: 'Identify expiry exposure, completed write-offs and known financial loss.',
    route: '/reports/expiry-waste',
    viewPermission: 'Reports.ExpiryWaste.View',
    exportPermission: 'Reports.ExpiryWaste.ExportPdf',
    icon: 'EXP'
  },
  {
    key: 'pricing',
    title: 'Product Pricing Analysis',
    eyebrow: 'Management insight',
    classification: 'Management graph report',
    summary: 'Compare historical selling-price observations using clear line and bar views.',
    route: '/reports/pricing',
    viewPermission: 'Reports.Pricing.View',
    exportPermission: 'Reports.Pricing.ExportPdf',
    icon: 'PRI'
  },
  {
    key: 'markup',
    title: 'Product Markup and Margin',
    eyebrow: 'Cost quality',
    classification: 'Simple list report',
    summary: 'Review weighted selling price, traceable cost and product-level margin quality.',
    route: '/reports/markup',
    viewPermission: 'Reports.Markup.View',
    exportPermission: 'Reports.Markup.ExportPdf',
    icon: 'MAR'
  }
];

export function findReport(key: string | null): ReportDefinition {
  return REPORT_CATALOG.find(report => report.key === key) ?? REPORT_CATALOG[0];
}
