/**
 * Reviewer guide: Verifies the formal report page frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { environment } from '../../../environments/environment';
import { AuthorizationService } from '../../services/authorization';
import { FormalReportPage } from './formal-report-page';

// Proves PDF download uses the exact preview token associated with reviewed criteria.
describe('FormalReportPage', () => {
  let fixture: ComponentFixture<FormalReportPage>;
  let component: FormalReportPage;
  let http: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormalReportPage],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([]),
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              data: { reportKey: 'inventory' }
            }
          }
        }
      ]
    }).compileComponents();

    TestBed.inject(AuthorizationService).session.set({
      userId: 1,
      email: 'operations.manager@example.test',
      role: 'Operations Manager',
      roleCode: 'OperationsManager',
      isActive: true,
      permissions: [
        {
          permissionId: 1,
          code: 'Reports.Inventory.View',
          displayName: 'View inventory report',
          module: 'Reports'
        },
        {
          permissionId: 2,
          code: 'Reports.Inventory.ExportPdf',
          displayName: 'Export inventory report PDF',
          module: 'Reports'
        }
      ]
    });

    fixture = TestBed.createComponent(FormalReportPage);
    component = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    fixture.detectChanges();

    http.expectOne(`${environment.apiUrl}/reports/options`).flush({
      products: [],
      productCategories: [],
      productTypes: [],
      warehouseSections: [],
      customers: [],
      suppliers: [],
      orderStatuses: [],
      deliveryStatuses: [],
      paymentStatuses: [],
      paymentMethods: [],
      movementTypes: [],
      writeOffReasons: []
    });
    await fixture.whenStable();
    fixture.detectChanges();
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that renders the inventory report as a single flat table.
  it('renders the inventory report as a single flat table', () => {
    component.runPreview();
    const preview = http.expectOne(`${environment.apiUrl}/reports/inventory/preview`);
    expect(preview.request.body.search).toBeUndefined();
    expect(preview.request.body.fromUtc).toBeUndefined();
    expect(preview.request.body.productId).toBeUndefined();
    preview.flush(inventoryReport());
    fixture.detectChanges();

    const captions = fixture.nativeElement.querySelectorAll('table caption');
    expect(captions.length).toBe(2);
    expect([...captions].some((caption: Element) =>
      caption.textContent?.includes('flat inventory-position table'))).toBe(true);
    expect([...captions].some((caption: Element) =>
      caption.textContent?.includes('accessible support data'))).toBe(true);
  });

  it('does not render the removed generic inventory search control', () => {
    expect(fixture.nativeElement.querySelector('app-search-field')).toBeNull();
    expect(fixture.nativeElement.textContent).not.toContain('Search products');
  });

  it('sends retained inventory filters and omits cleared or unrelated criteria', () => {
    component.criteria.productId = 17;
    component.criteria.stockStatus = 'Low Stock';
    component.criteria.customerId = 99;

    component.runPreview();
    const filtered = http.expectOne(`${environment.apiUrl}/reports/inventory/preview`);
    expect(filtered.request.body.productId).toBe(17);
    expect(filtered.request.body.stockStatus).toBe('Low Stock');
    expect(filtered.request.body.customerId).toBeUndefined();
    filtered.flush(inventoryReport());

    component.clearCriteria();
    component.runPreview();
    const cleared = http.expectOne(`${environment.apiUrl}/reports/inventory/preview`);
    expect(cleared.request.body.productId).toBeUndefined();
    expect(cleared.request.body.stockStatus).toBeUndefined();
    cleared.flush(inventoryReport());
  });

  // Reviewer note: Guards the observable rule that renders a fully labelled inventory chart with business units.
  it('renders a fully labelled inventory chart with business units', () => {
    component.runPreview();
    http.expectOne(`${environment.apiUrl}/reports/inventory/preview`).flush(
      inventoryReport()
    );
    fixture.detectChanges();

    const chart = component.charts()[0];
    expect(chart.title).toBe('Inventory Quantity by Product');
    expect(chart.xAxisLabel).toBe('Product');
    expect(chart.yAxisLabel).toBe(
      'Total Finished Product Quantity (units)'
    );
    expect(chart.series[0].name).toBe('Total Stock');
    expect(chart.series[0].points[0].tooltip).toContain('100.00 units');
    expect(fixture.nativeElement.querySelector('app-report-chart')).toBeTruthy();
  });

  // Reviewer note: Guards the observable rule that marks a reviewed preview stale after criteria change.
  it('marks a reviewed preview stale after criteria change', () => {
    component.runPreview();
    http.expectOne(`${environment.apiUrl}/reports/inventory/preview`).flush(
      inventoryReport()
    );
    expect(component.previewStale).toBe(false);

    component.criteria.search = 'carrots';
    component.markStale();

    expect(component.previewStale).toBe(true);
  });

  // Reviewer note: Guards the observable rule that does not request a PDF when the preview is stale.
  it('does not request a PDF when the preview is stale', () => {
    component.runPreview();
    http.expectOne(`${environment.apiUrl}/reports/inventory/preview`).flush(
      inventoryReport()
    );
    component.markStale();

    component.downloadPdf();

    http.expectNone(`${environment.apiUrl}/reports/inventory/pdf`);
  });

  it('uses one South African currency presentation for preview values', () => {
    expect(component.money(1250)).toBe('R 1,250.00');
    expect(component.money(0)).toBe('R 0.00');
    expect(component.money(null)).toBe('N/A');
  });

  function inventoryReport() {
    return {
      metadata: {
        reportKey: 'inventory',
        title: 'Inventory Position Report',
        classification: 'Simple list report',
        generatedAtUtc: '2026-08-02T12:00:00Z',
        generatedBy: 'Operations Manager',
        criteria: [{ label: 'Stock status', value: 'All' }],
        recordCount: 1,
        previewToken: 'reviewed-token'
      },
      rows: [
        {
          itemCode: 'CARROT-1KG',
          product: 'Premium Carrots',
          productCategory: 'Fresh Produce',
          productType: 'Root Vegetables',
          warehouseSection: 'Cold Room',
          availableQuantityKg: 85,
          reservedQuantityKg: 15,
          totalQuantityKg: 100,
          reorderLevelKg: 20,
          bestBeforeDateUtc: '2026-08-15T00:00:00Z',
          stockStatus: 'Available'
        }
      ],
      totalRecords: 1,
      totalAvailableQuantityKg: 85,
      totalReservedQuantityKg: 15
    };
  }
});
