/**
 * Reviewer guide: Coordinates the report chart page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import {
  ReportChart,
  ReportChartPoint,
  ReportChartSeries
} from '../../services/formal-reports';

@Component({
  selector: 'app-report-chart',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './report-chart.html',
  styleUrl: './report-chart.css'
})
/** Renders server-supplied chart series without recalculating protected report totals. */
export class ReportChartComponent {
  @Input({ required: true }) chart!: ReportChart;
  readonly colours = ['#176b3a', '#e08b2d', '#2469a0', '#9a4d8b'];

  get hasRenderableData(): boolean {
    return this.chart.series.some(series =>
      series.points.some(point => point.value !== null && point.value !== undefined));
  }

  dataLabel(value: number | null | undefined): string {
    if (value === null || value === undefined) return '';
    return this.format(value);
  }

  /**
   * Reviewer note: Encapsulates the values view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  values(): number[] {
    const values = this.chart.series
      .flatMap(series => series.points)
      .map(point => point.value)
      .filter((value): value is number => value !== null && value !== undefined);
    return values.length ? values : [0];
  }

  /**
   * Reviewer note: Encapsulates the maximum view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  maximum(): number {
    return Math.max(1, ...this.values());
  }

  /**
   * Reviewer note: Encapsulates the y ticks view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  yTicks(): number[] {
    const maximum = this.maximum();
    return [maximum, maximum * .75, maximum * .5, maximum * .25, 0];
  }

  /**
   * Reviewer note: Encapsulates the x view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  x(index: number, count: number): number {
    return 75 + index * 760 / Math.max(1, count - 1);
  }

  /**
   * Reviewer note: Encapsulates the y view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  y(value: number | null | undefined): number {
    return 195 - (value ?? 0) * 145 / this.maximum();
  }

  /**
   * Reviewer note: Encapsulates the polyline view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  polyline(series: ReportChartSeries): string {
    return series.points
      .map((point, index) =>
        `${this.x(index, series.points.length)},${this.y(point.value)}`)
      .join(' ');
  }

  /**
   * Reviewer note: Encapsulates the bar x view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  barX(
    pointIndex: number,
    pointCount: number,
    seriesIndex: number,
    seriesCount: number
  ): number {
    const groupWidth = 720 / Math.max(1, pointCount);
    const barWidth = Math.min(30, (groupWidth - 8) / Math.max(1, seriesCount));
    return 80 + pointIndex * groupWidth + seriesIndex * barWidth;
  }

  /**
   * Reviewer note: Encapsulates the bar width view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  barWidth(pointCount: number, seriesCount: number): number {
    const groupWidth = 720 / Math.max(1, pointCount);
    return Math.max(5, Math.min(30, (groupWidth - 8) / Math.max(1, seriesCount)));
  }

  /**
   * Reviewer note: Encapsulates the height view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  height(point: ReportChartPoint): number {
    return Math.max(0, 195 - this.y(point.value));
  }

  /**
   * Reviewer note: Encapsulates the format view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  format(value: number | null | undefined): string {
    if (value === null || value === undefined) return 'N/A';
    if (this.chart.unit === 'R' || this.chart.unit.startsWith('ZAR')) {
      const suffix = this.chart.unit === 'R'
        ? ''
        : this.chart.unit.slice(3).trim();
      return `R ${new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }).format(value)}${suffix ? ` ${suffix}` : ''}`;
    }
    const formatted = new Intl.NumberFormat('en-US', {
      maximumFractionDigits: 2
    }).format(value);
    return this.chart.unit === '%' ? `${formatted}%` :
      `${formatted} ${this.chart.unit}`.trim();
  }

  /**
   * Reviewer note: Encapsulates the point tooltip view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  pointTooltip(series: ReportChartSeries, point: ReportChartPoint): string {
    return point.tooltip ||
      `${point.label} — ${series.name}: ${this.format(point.value)}`;
  }

  /**
   * Reviewer note: Encapsulates the display label view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  displayLabel(value: string): string {
    return value.length > 24 ? `${value.slice(0, 21)}…` : value;
  }
}
