/**
 * Reviewer guide: Coordinates the reports landing page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthorizationService } from '../../services/authorization';
import { REPORT_CATALOG } from './report-catalog';

@Component({
  selector: 'app-reports-landing',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './reports-landing.html',
  styleUrl: './reports-landing.css'
})
export class ReportsLanding {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly reports = REPORT_CATALOG;

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(readonly authorization: AuthorizationService) {}
}
