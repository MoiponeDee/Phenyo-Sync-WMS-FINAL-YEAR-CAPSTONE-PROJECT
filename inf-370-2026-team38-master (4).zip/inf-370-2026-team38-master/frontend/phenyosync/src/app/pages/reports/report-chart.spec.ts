/**
 * Reviewer guide: Verifies the report chart frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReportChartComponent } from './report-chart';

// Covers the report chart behavior most likely to regress across permissions and workflow changes.
describe('ReportChartComponent', () => {
  let fixture: ComponentFixture<ReportChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReportChartComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(ReportChartComponent);
    fixture.componentInstance.chart = {
      chartType: 'bar',
      title: 'Monthly Sales Revenue',
      xAxisLabel: 'Month',
      yAxisLabel: 'Sales Revenue (R)',
      unit: 'R',
      series: [{
        name: 'Sales Revenue',
        points: [{
          label: 'Aug 2026',
          value: 48250,
          tooltip: 'Aug 2026 — Sales Revenue: R 48,250.00',
          sequence: 1
        }]
      }],
      boxPlots: []
    };
    fixture.detectChanges();
  });

  // Reviewer note: Guards the observable rule that renders title, axes, legend, unit and exact accessible values.
  it('renders title, axes, legend, unit and exact accessible values', () => {
    const text = fixture.nativeElement.textContent;
    expect(text).toContain('Monthly Sales Revenue');
    expect(text).toContain('Month');
    expect(text).toContain('Sales Revenue (R)');
    expect(text).toContain('Sales Revenue');
    expect(text).toContain('R 48,250.00');
    expect(fixture.nativeElement.querySelector('svg title').textContent)
      .toContain('Monthly Sales Revenue');
    expect(fixture.nativeElement.querySelector('.data-label').textContent)
      .toContain('R 48,250.00');
  });

  it('shows a useful empty state instead of meaningless axes', () => {
    fixture.componentRef.setInput('chart', {
      chartType: 'bar', title: 'Empty report', xAxisLabel: 'Month',
      yAxisLabel: 'Sales', unit: 'R', series: [], boxPlots: []
    });
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('svg')).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('No chart data for the selected filters');
  });
});
