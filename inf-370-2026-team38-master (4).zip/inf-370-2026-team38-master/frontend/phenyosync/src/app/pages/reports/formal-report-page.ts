/**
 * Reviewer guide: Coordinates the formal report page page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule, Location } from '@angular/common';
import { HttpResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { finalize, take } from 'rxjs';
import { AuthorizationService } from '../../services/authorization';
import {
  AnnualPricingSummary,
  ExpiryWasteReportRow,
  FinancialReportRow,
  FormalReportResult,
  FormalReportsService,
  InventoryReportRow,
  MarkupReportRow,
  MonthlyPricingSummary,
  PricingObservation,
  ReportChart,
  ReportChartPoint,
  ReportChartSeries,
  ReportOptions,
  SalesMonthGroup,
  StockMovementDomainGroup
} from '../../services/formal-reports';
import { ReportDefinition, findReport } from './report-catalog';
import { ReportChartComponent } from './report-chart';
import { HumanizeCodePipe } from '../../pipes/humanize-code.pipe';
import { httpErrorMessage } from '../../services/http-error-message';

interface ReportCriteriaForm {
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search: string;
  fromUtc: string;
  toUtc: string;
  asOfDateUtc: string;
  productId: number | null;
  productCategoryId: number | null;
  productTypeId: number | null;
  warehouseSectionId: number | null;
  customerId: number | null;
  supplierId: number | null;
  stockStatus: string;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  orderStatus: string;
  deliveryStatus: string;
  movementType: string;
  stockDomain: string;
  riskStatus: string;
  writeOffReason: string;
  transactionStatus: string;
  paymentMethod: string;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  transactionTypes: string[];
  minimumAmount: number | null;
  maximumAmount: number | null;
  groupBy: string;
  includeReversedOrVoided: boolean;
  includeInactive: boolean;
  includeZeroQuantity: boolean;
  includeCompletedWriteOffs: boolean;
  daysToExpiryThreshold: number;
  costSource: string;
  dataQualityStatus: string;
  viewMode: string;
  year: number;
  month: number | null;
  qualifyingSalesStatus: string;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  sortOrder: string;
  pageNumber: number;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  pageSize: number;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  sortBy: string;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  sortDirection: string;
}

const EMPTY_OPTIONS: ReportOptions = {
  products: [],
  productCategories: [],
  productTypes: [],
  warehouseSections: [],
  customers: [],
  suppliers: [],
  orderStatuses: [],
  deliveryStatuses: [],
  paymentStatuses: [],
  paymentMethods: [],
  movementTypes: [],
  writeOffReasons: []
};

@Component({
  selector: 'app-formal-report-page',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    ReportChartComponent,
    HumanizeCodePipe
  ],
  templateUrl: './formal-report-page.html',
  styleUrl: './formal-report-page.css'
})
/** Builds criteria, reviews a server snapshot and downloads the PDF for that exact preview token. */
export class FormalReportPage implements OnInit {
  definition!: ReportDefinition;
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  criteria = this.defaultCriteria();
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  options = EMPTY_OPTIONS;
  report: FormalReportResult | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  optionsLoading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  previewLoading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  pdfLoading = false;
  // Reviewer note: Retains a disposable browser or device resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  previewStale = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  criteriaError = '';

  readonly currentYear = new Date().getUTCFullYear();
  readonly maximumReportDate = new Date().toISOString().slice(0, 10);
  readonly years = Array.from(
    { length: 8 },
    (_, index) => this.currentYear - index
  );
  readonly monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly financialTransactionTypes = [
    'Invoice',
    'Customer Receipt',
    'Supplier Payment',
    'Stock Write-Off'
  ];

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly route: ActivatedRoute,
    private readonly reports: FormalReportsService,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly location: Location,
    readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.definition = findReport(this.route.snapshot.data['reportKey']);
    this.criteria = this.defaultCriteria();
    this.loadOptions();
  }

  /**
   * Reviewer note: Coordinates load options so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadOptions(): void {
    this.optionsLoading = true;
    this.reports.options().pipe(
      take(1),
      finalize(() => {
        this.optionsLoading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: options => this.options = options,
      error: error => {
        this.errorMessage = this.errorText(
          error,
          'The report criteria could not be loaded.'
        );
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the run preview view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  runPreview(): void {
    if (this.previewLoading || !this.validateCriteria()) {
      return;
    }

    this.previewLoading = true;
    this.errorMessage = '';
    this.successMessage = '';
    this.reports.preview(
      this.definition.key,
      this.requestCriteria()
    ).pipe(
      take(1),
      finalize(() => {
        this.previewLoading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: report => {
        this.report = report;
        this.previewStale = false;
        this.successMessage =
          `${report.metadata.title} generated from ${report.metadata.recordCount} records.`;
      },
      error: error => {
        this.errorMessage = this.errorText(
          error,
          'The report could not be generated.'
        );
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the download pdf view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  downloadPdf(): void {
    // Require the latest preview token so the PDF cannot silently represent different filters.
    const token = this.report?.metadata.previewToken;
    if (
      !token ||
      this.previewStale ||
      this.pdfLoading ||
      !this.authorization.has(this.definition.exportPermission)
    ) {
      return;
    }

    this.pdfLoading = true;
    this.errorMessage = '';
    this.reports.pdf(this.definition.key, token).pipe(
      take(1),
      finalize(() => {
        this.pdfLoading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => this.savePdf(response),
      error: error => {
        this.errorMessage = this.errorText(
          error,
          'The PDF could not be downloaded. Generate a fresh preview and try again.'
        );
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the clear criteria view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearCriteria(): void {
    this.criteria = this.defaultCriteria();
    this.markStale();
    this.criteriaError = '';
  }

  /**
   * Reviewer note: Encapsulates the mark stale view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  markStale(): void {
    this.criteriaError = '';
    this.successMessage = '';
    if (this.report) {
      this.previewStale = true;
    }
  }

  /**
   * Reviewer note: Encapsulates the toggle transaction type view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  toggleTransactionType(type: string, checked: boolean): void {
    this.criteria.transactionTypes = checked
      ? [...this.criteria.transactionTypes, type]
      : this.criteria.transactionTypes.filter(value => value !== type);
    this.markStale();
  }

  /**
   * Reviewer note: Encapsulates the transaction type selected view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  transactionTypeSelected(type: string): boolean {
    return this.criteria.transactionTypes.includes(type);
  }

  /**
   * Reviewer note: Encapsulates the inventory rows view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  inventoryRows(): InventoryReportRow[] {
    return (this.report?.rows ?? []) as InventoryReportRow[];
  }

  /**
   * Reviewer note: Encapsulates the expiry rows view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  expiryRows(): ExpiryWasteReportRow[] {
    return (this.report?.rows ?? []) as ExpiryWasteReportRow[];
  }

  /**
   * Reviewer note: Encapsulates the markup rows view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  markupRows(): MarkupReportRow[] {
    return (this.report?.rows ?? []) as MarkupReportRow[];
  }

  /**
   * Reviewer note: Encapsulates the financial rows view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  financialRows(): FinancialReportRow[] {
    return (this.report?.rows ?? []) as FinancialReportRow[];
  }

  /**
   * Reviewer note: Encapsulates the sales months view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  salesMonths(): SalesMonthGroup[] {
    return this.report?.months ?? [];
  }

  /**
   * Reviewer note: Encapsulates the movement domains view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  movementDomains(): StockMovementDomainGroup[] {
    return this.report?.domains ?? [];
  }

  /**
   * Reviewer note: Encapsulates the pricing observations view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  pricingObservations(): PricingObservation[] {
    return this.report?.observations ?? [];
  }

  /**
   * Reviewer note: Encapsulates the monthly summaries view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  monthlySummaries(): MonthlyPricingSummary[] {
    return this.report?.monthlySummaries ?? [];
  }

  /**
   * Reviewer note: Encapsulates the annual summaries view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  annualSummaries(): AnnualPricingSummary[] {
    return this.report?.annualSummaries ?? [];
  }

  /**
   * Reviewer note: Encapsulates the charts view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  charts(): ReportChart[] {
    if (this.report?.charts?.length) return this.report.charts;
    if (!this.report) return [];

    switch (this.definition.key) {
      case 'inventory':
        return [this.categoryChart(
          'Inventory Quantity by Product',
          'Product',
          'Total Finished Product Quantity (units)',
          'units',
          'Total Stock',
          this.topGroups(
            this.inventoryRows(),
            item => item.product,
            item => item.totalQuantityKg))];
      case 'expiry-waste':
        return [this.categoryChart(
          'Stock Quantity by Expiry and Waste Risk',
          'Risk Category',
          'Quantity at Risk (applicable units)',
          '',
          'Quantity at Risk',
          this.groupValues(
            this.expiryRows(),
            item => this.humanize(item.riskStatus),
            item => item.quantityKg))];
      case 'markup':
        return [this.categoryChart(
          'Gross Margin by Product',
          'Product',
          'Gross Margin (%)',
          '%',
          'Gross Margin',
          this.markupRows()
            .filter(item => item.grossMarginPercentage != null)
            .slice(0, 12)
            .map(item => ({
              label: item.product,
              value: item.grossMarginPercentage ?? 0
            })))];
      case 'sales':
        return [this.categoryChart(
          'Monthly Sales Revenue',
          'Month',
          'Sales Revenue (R)',
          'R',
          'Sales Revenue',
          this.salesMonths().map(item => ({
            label: item.monthLabel,
            value: item.monthValueSubtotal
          })))];
      case 'stock-movement':
        return [this.multiSeriesChart(
          'Stock Received and Issued by Domain',
          'Stock Domain',
          'Stock Movement Quantity (applicable units)',
          '',
          this.movementDomains().map(item => item.stockDomain),
          [
            {
              name: 'Stock Received',
              values: this.movementDomains().map(item => item.totalInKg)
            },
            {
              name: 'Stock Issued',
              values: this.movementDomains().map(item => item.totalOutKg)
            }
          ])];
      case 'financial': {
        const summary = this.report.summary;
        if (!summary) return [];
        return [this.categoryChart(
          'Financial Activity by Transaction Category',
          'Transaction Category',
          'Financial Value (R)',
          'R',
          'Financial Value',
          [
            { label: 'Sales', value: summary.salesValue },
            { label: 'Customer receipts', value: summary.customerReceipts },
            { label: 'Supplier payments', value: summary.supplierPayments },
            { label: 'Write-off loss', value: summary.writeOffLoss ?? 0 }
          ])];
      }
      default:
        return [];
    }
  }

  /**
   * Reviewer note: Encapsulates the category chart view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private categoryChart(
    title: string,
    xAxisLabel: string,
    yAxisLabel: string,
    unit: string,
    seriesName: string,
    values: Array<{ label: string; value: number }>
  ): ReportChart {
    return this.multiSeriesChart(
      title,
      xAxisLabel,
      yAxisLabel,
      unit,
      values.map(item => item.label),
      [{ name: seriesName, values: values.map(item => item.value) }]);
  }

  /**
   * Reviewer note: Encapsulates the multi series chart view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private multiSeriesChart(
    title: string,
    xAxisLabel: string,
    yAxisLabel: string,
    unit: string,
    labels: string[],
    series: Array<{ name: string; values: number[] }>
  ): ReportChart {
    return {
      chartType: 'bar',
      title,
      xAxisLabel,
      yAxisLabel,
      unit,
      series: series.map(item => ({
        name: item.name,
        points: item.values.map((value, index) => ({
          label: labels[index] || `Item ${index + 1}`,
          value,
          sequence: index + 1,
          tooltip: `${labels[index] || `Item ${index + 1}`} — ${item.name}: ${this.chartFormatted(value, unit)}`
        }))
      })),
      boxPlots: []
    };
  }

  /**
   * Reviewer note: Encapsulates the group values view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private groupValues<T>(
    items: T[],
    label: (item: T) => string,
    value: (item: T) => number
  ): Array<{ label: string; value: number }> {
    const grouped = new Map<string, number>();
    for (const item of items) {
      const key = label(item) || 'Not specified';
      grouped.set(key, (grouped.get(key) ?? 0) + value(item));
    }
    return [...grouped].map(([key, total]) => ({ label: key, value: total }));
  }

  /**
   * Reviewer note: Encapsulates the top groups view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private topGroups<T>(
    items: T[],
    label: (item: T) => string,
    value: (item: T) => number
  ): Array<{ label: string; value: number }> {
    return this.groupValues(items, label, value)
      .sort((left, right) => right.value - left.value)
      .slice(0, 12);
  }

  /**
   * Reviewer note: Encapsulates the chart formatted view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private chartFormatted(value: number, unit: string): string {
    if (unit === 'R') return this.money(value);
    if (unit === '%') return this.percentage(value);
    return `${this.number(value)} ${unit}`.trim();
  }

  /**
   * Reviewer note: Encapsulates the humanize view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private humanize(value: string): string {
    return value
      .replace(/[_-]+/g, ' ')
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Reviewer note: Encapsulates the chart polyline view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  chartPolyline(chart: ReportChart, series: ReportChartSeries): string {
    const values = this.chartValues(chart);
    const minimum = Math.min(0, ...values);
    const maximum = Math.max(1, ...values);
    const range = Math.max(1, maximum - minimum);
    const pointCount = Math.max(1, series.points.length - 1);
    return series.points
      .filter(point => point.value !== null && point.value !== undefined)
      .map((point, index) => {
        const x = 55 + index * 800 / pointCount;
        const y = 205 - ((point.value ?? 0) - minimum) * 155 / range;
        return `${x},${y}`;
      })
      .join(' ');
  }

  /**
   * Reviewer note: Encapsulates the bar x view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  barX(index: number, pointCount: number): number {
    return 60 + index * 800 / Math.max(1, pointCount);
  }

  /**
   * Reviewer note: Encapsulates the bar y view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  barY(chart: ReportChart, point: ReportChartPoint): number {
    const values = this.chartValues(chart);
    const maximum = Math.max(1, ...values);
    return 205 - (point.value ?? 0) * 155 / maximum;
  }

  /**
   * Reviewer note: Encapsulates the bar height view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  barHeight(chart: ReportChart, point: ReportChartPoint): number {
    return 205 - this.barY(chart, point);
  }

  /**
   * Reviewer note: Encapsulates the annual month view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  annualMonth(summary: AnnualPricingSummary, index: number): string {
    return this.money(summary.monthlyWeightedAverages[index]);
  }

  /**
   * Reviewer note: Encapsulates the money view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  money(value: number | null | undefined): string {
    if (value === null || value === undefined) {
      return 'N/A';
    }
    return `R ${new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value)}`;
  }

  /**
   * Reviewer note: Encapsulates the number view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  number(value: number | null | undefined, digits = 2): string {
    if (value === null || value === undefined) {
      return 'N/A';
    }
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits
    }).format(value);
  }

  /**
   * Reviewer note: Encapsulates the percentage view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  percentage(value: number | null | undefined): string {
    return value === null || value === undefined
      ? 'N/A'
      : `${this.number(value)}%`;
  }

  /**
   * Reviewer note: Encapsulates the stock domain unit view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  stockDomainUnit(stockDomain: string | null | undefined): string {
    return stockDomain?.toLowerCase().includes('raw')
      ? 'configured units'
      : 'units';
  }

  /**
   * Reviewer note: Encapsulates the date view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  date(value: string | null | undefined): string {
    if (!value) {
      return 'N/A';
    }
    return new Date(value).toLocaleDateString('en-ZA');
  }

  /**
   * Reviewer note: Encapsulates the date time view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  dateTime(value: string | null | undefined): string {
    if (!value) {
      return 'N/A';
    }
    return new Date(value).toLocaleString('en-ZA');
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.location.back();
  }

  /**
   * Reviewer note: Encapsulates the validate criteria view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private validateCriteria(): boolean {
    this.criteriaError = '';
    if (
      this.criteria.fromUtc &&
      this.criteria.toUtc &&
      this.criteria.fromUtc > this.criteria.toUtc
    ) {
      this.criteriaError = 'The From date cannot be later than the To date.';
      return false;
    }
    if ((this.criteria.fromUtc &&
         this.criteria.fromUtc > this.maximumReportDate) ||
        (this.criteria.toUtc &&
         this.criteria.toUtc > this.maximumReportDate) ||
        (this.criteria.asOfDateUtc &&
         this.criteria.asOfDateUtc > this.maximumReportDate)) {
      this.criteriaError = 'Report date criteria cannot be in the future.';
      return false;
    }
    if (
      this.criteria.minimumAmount !== null &&
      this.criteria.maximumAmount !== null &&
      this.criteria.minimumAmount > this.criteria.maximumAmount
    ) {
      this.criteriaError = 'The minimum amount cannot exceed the maximum amount.';
      return false;
    }
    if (this.criteria.daysToExpiryThreshold < 0) {
      this.criteriaError = 'Days to expiry cannot be negative.';
      return false;
    }
    return true;
  }

  /**
   * Reviewer note: Encapsulates the request criteria view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private requestCriteria(): Record<string, unknown> {
    const fieldsByReport: Record<string, Array<keyof ReportCriteriaForm>> = {
      inventory: [
        'productId', 'productCategoryId', 'stockStatus',
        'pageNumber', 'pageSize', 'sortBy', 'sortDirection'
      ],
      sales: [
        'fromUtc', 'toUtc', 'customerId', 'productId', 'productCategoryId',
        'orderStatus'
      ],
      financial: [
        'fromUtc', 'toUtc', 'transactionTypes', 'customerId', 'supplierId',
        'pageNumber', 'pageSize', 'sortBy', 'sortDirection'
      ],
      'stock-movement': [
        'fromUtc', 'toUtc', 'stockDomain', 'productId',
        'warehouseSectionId', 'movementType'
      ],
      'expiry-waste': [
        'asOfDateUtc', 'daysToExpiryThreshold', 'productId', 'riskStatus',
        'writeOffReason', 'pageNumber', 'pageSize',
        'sortBy', 'sortDirection'
      ],
      pricing: [
        'viewMode', 'year', 'month', 'productId', 'productCategoryId'
      ],
      markup: [
        'fromUtc', 'toUtc', 'productId', 'productCategoryId',
        'pageNumber', 'pageSize', 'sortBy', 'sortDirection'
      ]
    };
    const fields = fieldsByReport[this.definition.key] ?? [];
    return Object.fromEntries(
      fields
        .map(field => [field, this.criteria[field]])
        .filter(([, value]) => value !== '' && value !== null && value !== undefined)
    );
  }

  /**
   * Reviewer note: Encapsulates the default criteria view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private defaultCriteria(): ReportCriteriaForm {
    const today = new Date();
    const yearStart = `${today.getUTCFullYear()}-01-01`;
    const todayValue = today.toISOString().slice(0, 10);
    return {
      search: '',
      fromUtc: yearStart,
      toUtc: todayValue,
      asOfDateUtc: todayValue,
      productId: null,
      productCategoryId: null,
      productTypeId: null,
      warehouseSectionId: null,
      customerId: null,
      supplierId: null,
      stockStatus: '',
      orderStatus: '',
      deliveryStatus: '',
      movementType: '',
      stockDomain: '',
      riskStatus: '',
      writeOffReason: '',
      transactionStatus: '',
      paymentMethod: '',
      transactionTypes: [],
      minimumAmount: null,
      maximumAmount: null,
      groupBy: 'transaction-type',
      includeReversedOrVoided: false,
      includeInactive: false,
      includeZeroQuantity: false,
      includeCompletedWriteOffs: true,
      daysToExpiryThreshold: 30,
      costSource: '',
      dataQualityStatus: '',
      viewMode: 'monthly',
      year: today.getUTCFullYear(),
      month: today.getUTCMonth() + 1,
      qualifyingSalesStatus: '',
      sortOrder: 'month-asc',
      pageNumber: 1,
      pageSize: 100,
      sortBy: '',
      sortDirection: 'asc'
    };
  }

  /**
   * Reviewer note: Encapsulates the chart values view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private chartValues(chart: ReportChart): number[] {
    const values = chart.series
      .flatMap(series => series.points)
      .map(point => point.value)
      .filter((value): value is number => value !== null && value !== undefined);
    return values.length ? values : [0];
  }

  /**
   * Reviewer note: Coordinates the save pdf interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private savePdf(response: HttpResponse<Blob>): void {
    if (!response.body) {
      this.errorMessage = 'The PDF response did not contain a file.';
      return;
    }
    const disposition = response.headers.get('content-disposition') ?? '';
    const encoded = /filename\*=UTF-8''([^;]+)/i.exec(disposition)?.[1];
    const basic = /filename="?([^";]+)"?/i.exec(disposition)?.[1];
    const fileName = encoded
      ? decodeURIComponent(encoded)
      : basic ?? `PhenyoSync-${this.definition.key}-report.pdf`;
    const url = URL.createObjectURL(response.body);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(url);
    this.successMessage = `${this.report?.metadata.title} PDF downloaded.`;
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    return httpErrorMessage(error, fallback);
  }
}
