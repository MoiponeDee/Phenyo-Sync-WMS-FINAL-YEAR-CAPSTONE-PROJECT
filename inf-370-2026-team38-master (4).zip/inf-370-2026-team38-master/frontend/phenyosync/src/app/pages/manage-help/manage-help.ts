/**
 * Reviewer guide: Coordinates the manage help page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, forkJoin } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import {
  HelpCategory,
  HelpService,
  HelpTopic,
  HelpTopicSummary
} from '../../services/help';
import { NotificationService } from '../../services/notification';

@Component({
  selector: 'app-manage-help',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent, SearchFieldComponent],
  templateUrl: './manage-help.html',
  styleUrl: './manage-help.css'
})
/** Edits versioned help topics and route context used by the in-app help experience. */
export class ManageHelp implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  categories: HelpCategory[] = [];
  topics: HelpTopicSummary[] = [];
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  topicFilter = '';
  activeTab: 'topics' | 'categories' | 'contexts' = 'topics';
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  categoryForm = this.emptyCategory();
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  topicForm = this.emptyTopic();
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  contextForm = {
    helpTopicId: null as number | null,
    routePattern: '',
    componentKey: '',
    priority: 100,
    isActive: true
  };

  /**
   * Reviewer note: Encapsulates the filtered topics view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get filteredTopics(): HelpTopicSummary[] {
    const filter = this.topicFilter.trim().toLocaleLowerCase();
    if (!filter) return this.topics;
    return this.topics.filter(topic =>
      topic.title.toLocaleLowerCase().includes(filter) ||
      topic.categoryName.toLocaleLowerCase().includes(filter) ||
      topic.summary.toLocaleLowerCase().includes(filter));
  }

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private help: HelpService,
    private notifications: NotificationService,
    private changeDetector: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      categories: this.help.manageCategories(),
      topics: this.help.manageTopics()
    }).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.categories = result.categories;
        this.topics = result.topics;
      },
      error: error => this.errorMessage =
        error.error?.message || 'Unable to load Help administration.'
    });
  }

  /**
   * Reviewer note: Encapsulates the edit category view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  editCategory(category: HelpCategory): void {
    this.categoryForm = { ...category };
    this.activeTab = 'categories';
  }

  /**
   * Reviewer note: Coordinates the save category interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveCategory(): void {
    this.errorMessage = '';
    if (!this.categoryForm.systemCode.trim() ||
        !this.categoryForm.displayName.trim()) {
      this.errorMessage = 'Enter the category code and display name.';
      return;
    }
    this.saving = true;
    this.help.saveCategory(this.categoryForm).pipe(
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: () => {
        this.notifications.success('Help category saved.');
        this.categoryForm = this.emptyCategory();
        this.load();
      },
      error: error => this.errorMessage =
        error.error?.message || 'The Help category could not be saved.'
    });
  }

  /**
   * Reviewer note: Encapsulates the edit topic view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  editTopic(item: HelpTopicSummary): void {
    this.loading = true;
    this.help.manageTopic(item.helpTopicId).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: topic => {
        this.topicForm = this.formFromTopic(topic);
        this.activeTab = 'topics';
      },
      error: error => this.errorMessage =
        error.error?.message || 'The Help topic could not be loaded.'
    });
  }

  /**
   * Reviewer note: Coordinates the save topic interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveTopic(): void {
    this.errorMessage = '';
    if (!this.topicForm.helpCategoryId ||
        !this.topicForm.slug.trim() ||
        !this.topicForm.title.trim() ||
        this.topicForm.bodyContent.trim().length < 40) {
      this.errorMessage =
        'Select a category and provide a slug, title and substantive content.';
      return;
    }
    const audienceRoles = this.topicForm.audienceRolesText
      .split(',')
      .map((value: string) => value.trim())
      .filter(Boolean);
    this.saving = true;
    this.help.saveTopic({
      ...this.topicForm,
      audienceRoles
    }).pipe(
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: () => {
        this.notifications.success('Help topic saved.');
        this.topicForm = this.emptyTopic();
        this.load();
      },
      error: error => this.errorMessage =
        error.error?.message || 'The Help topic could not be saved.'
    });
  }

  /**
   * Reviewer note: Coordinates the save context interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveContext(): void {
    this.errorMessage = '';
    if (!this.contextForm.helpTopicId ||
        !this.contextForm.routePattern.trim()) {
      this.errorMessage = 'Select a topic and enter a route pattern.';
      return;
    }
    this.saving = true;
    this.help.saveContext(this.contextForm).pipe(
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: () => {
        this.notifications.success('Context-sensitive Help mapping saved.');
        this.contextForm = {
          helpTopicId: null,
          routePattern: '',
          componentKey: '',
          priority: 100,
          isActive: true
        };
      },
      error: error => this.errorMessage =
        error.error?.message || 'The context mapping could not be saved.'
    });
  }

  /**
   * Reviewer note: Encapsulates the new category view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  newCategory(): void {
    this.categoryForm = this.emptyCategory();
  }

  /**
   * Reviewer note: Encapsulates the new topic view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  newTopic(): void {
    this.topicForm = this.emptyTopic();
  }

  /**
   * Reviewer note: Encapsulates the empty category view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private emptyCategory(): any {
    return {
      helpCategoryId: null,
      systemCode: '',
      displayName: '',
      description: '',
      sortOrder: 100,
      isActive: true,
      rowVersion: ''
    };
  }

  /**
   * Reviewer note: Encapsulates the empty topic view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private emptyTopic(): any {
    return {
      helpTopicId: null,
      helpCategoryId: null,
      slug: '',
      title: '',
      summary: '',
      bodyContent: '',
      keywords: '',
      audienceRolesText:
        'OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer',
      isPublic: false,
      isPublished: true,
      sortOrder: 100,
      rowVersion: ''
    };
  }

  /**
   * Reviewer note: Encapsulates the form from topic view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private formFromTopic(topic: HelpTopic): any {
    return {
      helpTopicId: topic.helpTopicId,
      helpCategoryId: topic.helpCategoryId,
      slug: topic.slug,
      title: topic.title,
      summary: topic.summary,
      bodyContent: topic.bodyContent,
      keywords: topic.keywords || '',
      audienceRolesText: topic.audienceRoles.join(','),
      isPublic: topic.isPublic,
      isPublished: topic.isPublished,
      sortOrder: topic.sortOrder,
      rowVersion: topic.rowVersion
    };
  }
}
