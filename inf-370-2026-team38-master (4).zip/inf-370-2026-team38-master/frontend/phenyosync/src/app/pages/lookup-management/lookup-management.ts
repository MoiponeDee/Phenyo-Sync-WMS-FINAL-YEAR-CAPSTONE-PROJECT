/**
 * Reviewer guide: Coordinates the lookup management page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { ChangeDetectorRef, Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { finalize, map, Observable, take } from 'rxjs';
import {
  LookupStatus,
  ProductLookupService,
} from '../../services/product-lookups';

interface LookupRow {
  id: number;
  name: string;
  description?: string;
  status: LookupStatus;
  createdAt: string;
}

@Component({
  selector: 'app-lookup-management',
  standalone: true,
  imports: [CommonModule, FormsModule, SearchFieldComponent],
  templateUrl: './lookup-management.html',
  styleUrl: './lookup-management.css'
})
/** Reuses lookup editing UI while preserving the parent page's selected governed type. */
export class LookupManagement implements OnChanges {
  @Input({ required: true }) kind: 'type' | 'category' = 'type';
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  rows: LookupRow[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  searchTerm = '';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  statusFilter = '';
  name = '';
  description = '';
  status: LookupStatus = 'Active';
  editingId: number | null = null;
  deleteCandidate: LookupRow | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private service: ProductLookupService,
    private cdr: ChangeDetectorRef,
    private router: Router
  ) {}

  /**
   * Reviewer note: Encapsulates the title view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get title(): string { return this.kind === 'type' ? 'Product Types' : 'Product Categories'; }
  /**
   * Reviewer note: Encapsulates the singular view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get singular(): string { return this.kind === 'type' ? 'product type' : 'product category'; }

  /**
   * Reviewer note: Encapsulates the ng on changes view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['kind']) this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.errorMessage = '';
    const request: Observable<LookupRow[]> = this.kind === 'type'
      ? this.service.getProductTypes(this.searchTerm, this.statusFilter).pipe(map(values =>
          values.map(item => ({ id: item.productTypeId, name: item.productTypeName, description: item.description, status: item.status, createdAt: item.createdAt }))))
      : this.service.getProductCategories(this.searchTerm, this.statusFilter).pipe(map(values =>
          values.map(item => ({ id: item.productCategoryId, name: item.productCategoryName, description: item.description, status: item.status, createdAt: item.createdAt }))));
    request.pipe(finalize(() => { this.loading = false; this.cdr.detectChanges(); })).subscribe({
      next: values => this.rows = values,
      error: error => this.fail(error, `Unable to load ${this.title.toLowerCase()}.`)
    });
  }

  /**
   * Reviewer note: Encapsulates the edit view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  edit(row: LookupRow): void {
    this.editingId = row.id;
    this.name = row.name;
    this.description = row.description ?? '';
    this.status = row.status;
    this.successMessage = '';
    this.errorMessage = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /**
   * Reviewer note: Coordinates the cancel edit interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  cancelEdit(): void {
    this.editingId = null;
    this.name = '';
    this.description = '';
    this.status = 'Active';
  }

  /**
   * Reviewer note: Coordinates the save interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  save(): void {
    const name = this.name.trim();
    if (!name) { this.errorMessage = `A ${this.singular} name is required.`; return; }
    this.saving = true;
    this.errorMessage = '';
    this.successMessage = '';
    const payload = this.kind === 'type'
      ? { productTypeName: name, description: this.description.trim(), status: this.status }
      : { productCategoryName: name, description: this.description.trim(), status: this.status };
    const request: Observable<{ message: string }> = this.kind === 'type'
      ? (this.editingId == null
        ? this.service.createProductType(payload as never)
        : this.service.updateProductType(this.editingId, payload as never))
      : (this.editingId == null
        ? this.service.createProductCategory(payload as never)
        : this.service.updateProductCategory(this.editingId, payload as never));
    request.pipe(take(1), finalize(() => { this.saving = false; this.cdr.detectChanges(); })).subscribe({
      next: response => { this.successMessage = response.message; this.cancelEdit(); this.load(); },
      error: error => this.fail(error, `Unable to save the ${this.singular}.`)
    });
  }

  /**
   * Reviewer note: Encapsulates the confirm delete view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  confirmDelete(): void {
    if (!this.deleteCandidate || this.saving) return;
    this.saving = true;
    const candidate = this.deleteCandidate;
    const request = this.kind === 'type'
      ? this.service.deleteProductType(candidate.id)
      : this.service.deleteProductCategory(candidate.id);
    request.pipe(finalize(() => { this.saving = false; this.cdr.detectChanges(); })).subscribe({
      next: response => { this.successMessage = response.message; this.deleteCandidate = null; this.load(); },
      error: error => this.fail(error, `Unable to delete the ${this.singular}.`)
    });
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void { this.router.navigate(['/admin-dashboard']); }

  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown, fallback: string): void {
    console.error('Lookup management error:', error);
    this.errorMessage = error instanceof HttpErrorResponse ? error.error?.message || fallback : fallback;
  }
}
