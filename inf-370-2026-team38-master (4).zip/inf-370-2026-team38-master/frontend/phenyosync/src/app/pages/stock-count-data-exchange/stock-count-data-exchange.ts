/**
 * Reviewer guide: Coordinates the stock count data exchange page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule, Location } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, forkJoin, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import {
  DataExchangeResult,
  DataExchangeValidation
} from '../../services/product-data-exchange';
import {
  ProductCategory,
  ProductLookupService,
  ProductType,
  WarehouseSection
} from '../../services/product-lookups';
import { StockCountDataExchangeService } from '../../services/stock-count-data-exchange';

@Component({
  selector: 'app-stock-count-data-exchange',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  templateUrl: './stock-count-data-exchange.html',
  styleUrls: ['../phase-b.css']
})
/** Guides export, validation preview and controlled application of offline stock counts. */
export class StockCountDataExchange implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  categories: ProductCategory[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  types: ProductType[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  sections: WarehouseSection[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  filters = {
    warehouseSectionId: null as number | null,
    productCategoryId: null as number | null,
    productTypeId: null as number | null,
    activeProductsOnly: true,
    includeExpectedQuantities: true
  };
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedFile: File | null = null;
  validation: DataExchangeValidation | null = null;
  result: DataExchangeResult | null = null;
  importReason = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  busy = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private exchange: StockCountDataExchangeService,
    private lookups: ProductLookupService,
    readonly authorization: AuthorizationService,
    private confirmations: ConfirmationService,
    private notifications: NotificationService,
    private changeDetector: ChangeDetectorRef,
    private location: Location
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.busy = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      categories: this.lookups.getProductCategories('', ''),
      types: this.lookups.getProductTypes('', ''),
      sections: this.lookups.getActiveWarehouseSections()
    }).pipe(
      take(1),
      finalize(() => {
        this.busy = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.categories = result.categories;
        this.types = result.types;
        this.sections = result.sections;
        this.filters.warehouseSectionId = result.sections[0]?.sectionId ?? null;
      },
      error: error => this.errorMessage = this.errorText(error, 'Unable to load stock-count options.')
    });
  }

  /**
   * Reviewer note: Calculates can export for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canExport(): boolean {
    return this.authorization.has('StockCountExchange.Export');
  }

  /**
   * Reviewer note: Calculates can import for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canImport(): boolean {
    return this.authorization.has('StockCountExchange.Import');
  }

  /**
   * Reviewer note: Coordinates the export json interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  exportJson(): void {
    if (!this.filters.warehouseSectionId || this.busy) {
      this.notifications.warning('Select a warehouse section first.');
      return;
    }
    this.busy = true;
    this.exchange.export({
      warehouseSectionId: this.filters.warehouseSectionId,
      productCategoryId: this.filters.productCategoryId,
      productTypeId: this.filters.productTypeId,
      activeProductsOnly: this.filters.activeProductsOnly,
      includeExpectedQuantities: this.filters.includeExpectedQuantities
    }).pipe(
      take(1),
      finalize(() => {
        this.busy = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: blob => {
        this.download(blob, `PhenyoSync-StockCount-${new Date().toISOString().slice(0, 10)}.json`);
        this.notifications.success('The stock-count JSON package was exported.');
      },
      error: error => this.notifications.error(this.errorText(error, 'The stock-count package could not be exported.'))
    });
  }

  downloadSchema(): void {
    this.exchange.schema().pipe(take(1)).subscribe({
      next: blob => this.download(blob, 'PhenyoSync-StockCount-Schema-2.0.json'),
      error: error => this.notifications.error(this.errorText(error, 'The JSON schema could not be downloaded.'))
    });
  }

  downloadSample(): void {
    this.exchange.sample().pipe(take(1)).subscribe({
      next: blob => this.download(blob, 'PhenyoSync-StockCount-Sample-2.0.json'),
      error: error => this.notifications.error(this.errorText(error, 'The JSON sample could not be downloaded.'))
    });
  }

  /**
   * Reviewer note: Encapsulates the choose file view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  chooseFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.selectedFile = input.files?.[0] ?? null;
    this.validation = null;
    this.result = null;
    this.errorMessage = '';
  }

  /**
   * Reviewer note: Encapsulates the validate json view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  validateJson(): void {
    if (!this.selectedFile || this.busy) return;
    this.busy = true;
    this.exchange.validate(this.selectedFile).pipe(
      take(1),
      finalize(() => {
        this.busy = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.validation = result;
        if (result.invalidRows) this.notifications.warning('Some count rows are invalid and cannot be imported.');
        else this.notifications.success('The stock-count package is ready for confirmation.');
      },
      error: error => this.errorMessage = this.errorText(error, 'The JSON package could not be validated.')
    });
  }

  /**
   * Reviewer note: Encapsulates the apply import view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  async applyImport(): Promise<void> {
    if (!this.validation || this.validation.invalidRows || this.busy) return;
    if (this.importReason.trim().length < 5) {
      this.notifications.warning('Enter a stock-adjustment reason of at least five characters.');
      return;
    }
    const confirmation = await this.confirmations.ask({
      title: 'Apply stock-count adjustments',
      message: 'Confirmed variances will create a completed stock take and traceable batch-level stock movements.',
      confirmLabel: 'Apply adjustments',
      tone: 'warning'
    });
    if (!confirmation.confirmed) return;
    this.busy = true;
    this.exchange.import(this.validation.validationToken, this.importReason).pipe(
      take(1),
      finalize(() => {
        this.busy = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.result = result;
        this.validation = null;
        this.notifications.success(result.message);
      },
      error: error => this.notifications.error(this.errorText(error, 'The stock-count adjustments could not be applied.'))
    });
  }

  /**
   * Reviewer note: Encapsulates the download result view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  downloadResult(): void {
    if (!this.result) return;
    this.exchange.result(this.result.resultToken).pipe(take(1)).subscribe({
      next: blob => this.download(blob, `PhenyoSync-StockCount-Result-${new Date().toISOString().slice(0, 10)}.json`),
      error: error => this.notifications.error(this.errorText(error, 'The result JSON could not be downloaded.'))
    });
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.location.back();
  }

  /**
   * Reviewer note: Encapsulates the download view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private download(blob: Blob, fileName: string): void {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(url);
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    const response = error as HttpErrorResponse;
    return response.error?.message || response.error?.title || fallback;
  }
}
