/**
 * Reviewer guide: Coordinates the scan product batch page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule, Location } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { NotificationService } from '../../services/notification';
import {
  ProductBatchScanResult,
  ProductBatchScannerService
} from '../../services/product-batch-scanner';

interface DetectedBarcode {
  rawValue: string;
}

interface BarcodeDetectorInstance {
  /**
   * Reviewer note: Encapsulates the detect view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  detect(source: ImageBitmapSource): Promise<DetectedBarcode[]>;
}

type BarcodeDetectorConstructor = new (options?: { formats?: string[] }) => BarcodeDetectorInstance;

@Component({
  selector: 'app-scan-product-batch',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  templateUrl: './scan-product-batch.html',
  styleUrls: ['../phase-b.css']
})
/** Resolves native/browser/manual batch input through one authoritative lookup endpoint. */
export class ScanProductBatch implements AfterViewInit, OnDestroy {
  @ViewChild('cameraVideo') video?: ElementRef<HTMLVideoElement>;

  supported = !!navigator.mediaDevices?.getUserMedia;
  nativeDetectorSupported = 'BarcodeDetector' in window;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  scanning = false;
  resolving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  cameraError = '';
  manualValue = '';
  result: ProductBatchScanResult | null = null;
  // Reviewer note: Retains a disposable browser or device resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  private stream?: MediaStream;
  private detector?: BarcodeDetectorInstance;
  private animationFrame = 0;
  // Reviewer note: Retains a disposable browser or device resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  private fallbackControls?: import('@zxing/browser').IScannerControls;
  private lastValue = '';
  private lastDetectedAt = 0;
  private readonly duplicateDelayMs = 2500;

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private scanner: ProductBatchScannerService,
    private notifications: NotificationService,
    private changeDetector: ChangeDetectorRef,
    private location: Location
  ) {}

  /**
   * Reviewer note: Encapsulates the ng after view init view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  ngAfterViewInit(): void {
    if (this.nativeDetectorSupported) {
      const Constructor = (window as unknown as { BarcodeDetector: BarcodeDetectorConstructor }).BarcodeDetector;
      this.detector = new Constructor({ formats: ['qr_code'] });
    }
  }

  /**
   * Reviewer note: Releases subscriptions or device resources when the view is left to prevent duplicate background work.
   * Cleanup stops stale callbacks from mutating a page that is no longer active.
   */
  ngOnDestroy(): void {
    this.stopCamera();
  }

  /**
   * Reviewer note: Coordinates the start camera interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async startCamera(): Promise<void> {
    if (!this.supported || this.scanning) return;
    this.cameraError = '';
    this.result = null;
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
        audio: false
      });
      const video = this.video?.nativeElement;
      if (!video) throw new Error('Camera preview is unavailable.');
      video.srcObject = this.stream;
      await video.play();
      this.scanning = true;
      if (this.detector) this.detectFrame();
      else await this.startFallbackDetection(video);
      this.changeDetector.detectChanges();
    } catch (error) {
      const exception = error as DOMException;
      this.cameraError = exception.name === 'NotAllowedError'
        ? 'Camera permission was denied. Allow camera access in the browser settings or use manual entry.'
        : exception.name === 'NotFoundError'
          ? 'No usable camera was found on this device.'
          : 'The camera could not be started. Use HTTPS or localhost and check the device camera.';
      this.stopCamera();
      this.changeDetector.detectChanges();
    }
  }

  /**
   * Reviewer note: Coordinates the stop camera interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  stopCamera(): void {
    /**
     * Reviewer note: Coordinates the cancel animation frame interaction in one place and keeps any pending or error feedback visible.
     * Persistent changes still flow through typed services and backend validation when required.
     */
    cancelAnimationFrame(this.animationFrame);
    this.fallbackControls?.stop();
    this.fallbackControls = undefined;
    this.stream?.getTracks().forEach(track => track.stop());
    this.stream = undefined;
    if (this.video?.nativeElement) this.video.nativeElement.srcObject = null;
    this.scanning = false;
  }

  /**
   * Reviewer note: Encapsulates the resolve manual view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  resolveManual(): void {
    this.resolve(this.manualValue);
  }

  /**
   * Reviewer note: Coordinates the scan again interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  scanAgain(): void {
    this.result = null;
    this.manualValue = '';
    this.lastValue = '';
    this.lastDetectedAt = 0;
    if (this.scanning && this.detector) this.detectFrame();
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.location.back();
  }

  /**
   * Reviewer note: Encapsulates the detect frame view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private detectFrame(): void {
    if (!this.scanning || !this.detector || !this.video?.nativeElement) return;
    const video = this.video.nativeElement;
    if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && !this.resolving) {
      this.detector.detect(video).then(codes => {
        const value = codes[0]?.rawValue?.trim();
        const now = Date.now();
        if (value && (value !== this.lastValue || now - this.lastDetectedAt >= this.duplicateDelayMs)) {
          this.lastValue = value;
          this.lastDetectedAt = now;
          this.resolve(value);
        }
      }).catch(() => {
        this.cameraError = 'The current video frame could not be analysed.';
        this.changeDetector.detectChanges();
      });
    }
    this.animationFrame = requestAnimationFrame(() => this.detectFrame());
  }

  /**
   * Reviewer note: Coordinates the start fallback detection interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private async startFallbackDetection(video: HTMLVideoElement): Promise<void> {
    const { BrowserQRCodeReader } = await import('@zxing/browser');
    const fallbackReader = new BrowserQRCodeReader(undefined, {
      delayBetweenScanAttempts: 180,
      delayBetweenScanSuccess: this.duplicateDelayMs
    });
    this.fallbackControls = await fallbackReader.decodeFromStream(
      this.stream!,
      video,
      result => {
        const value = result?.getText().trim();
        const now = Date.now();
        if (value &&
            (value !== this.lastValue ||
             now - this.lastDetectedAt >= this.duplicateDelayMs)) {
          this.lastValue = value;
          this.lastDetectedAt = now;
          this.resolve(value);
        }
      }
    );
  }

  /**
   * Reviewer note: Encapsulates the resolve view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private resolve(value: string): void {
    const normalized = value.trim();
    if (!normalized || this.resolving) {
      if (!normalized) this.notifications.warning('Enter or scan a PhenyoSync batch QR value.');
      return;
    }
    this.resolving = true;
    this.cameraError = '';
    this.scanner.resolve(normalized).pipe(
      take(1),
      finalize(() => {
        this.resolving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.result = result;
        this.stopCamera();
        this.notifications.success(`Batch ${result.batchCode} was identified.`);
      },
      error: error => {
        this.result = null;
        this.cameraError = this.errorText(error, 'The QR code did not identify a valid product batch.');
      }
    });
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    const response = error as HttpErrorResponse;
    return response.error?.message || response.error?.title || fallback;
  }
}
