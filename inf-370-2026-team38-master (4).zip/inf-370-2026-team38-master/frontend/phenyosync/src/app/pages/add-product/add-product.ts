import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import {
  HierarchyCategory,
  ProductHierarchyService
} from '../../services/product-hierarchy';
import { httpErrorMessage } from '../../services/http-error-message';

@Component({
  selector: 'app-add-product',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, TopbarComponent],
  templateUrl: './add-product.html',
  styleUrl: './add-product.css'
})
/** Creates a catalogue product through the existing governed hierarchy service. */
export class AddProduct implements OnInit {
  categories: HierarchyCategory[] = [];
  categoryId: number | null = null;
  typeId: number | null = null;
  loading = false;
  saving = false;
  errorMessage = '';
  form = {
    productName: '',
    size: '',
    shelfLifeDays: 30,
    initialSellingPrice: null as number | null,
    initialPriceBasis: 'PerKilogram' as 'PerKilogram' | 'PerSellableUnit',
    sellingUnit: 'kg',
    kilogramsPerUnit: null as number | null,
    isVariableWeight: true,
    priceReason: '',
    status: 'Active' as 'Active' | 'Inactive'
  };

  constructor(
    private readonly hierarchy: ProductHierarchyService,
    private readonly router: Router,
    private readonly changeDetector: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loading = true;
    this.hierarchy.get('', false).pipe(
      take(1),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => this.categories = result.categories,
      error: error => this.fail(error)
    });
  }

  get types() {
    return this.categories.find(item => item.productCategoryId === this.categoryId)?.types ?? [];
  }

  categoryChanged(): void {
    this.typeId = null;
  }

  variableWeightChanged(): void {
    if (this.form.isVariableWeight) {
      this.form.sellingUnit = 'kg';
      this.form.kilogramsPerUnit = null;
      this.form.initialPriceBasis = 'PerKilogram';
    }
  }

  save(productForm: NgForm): void {
    this.errorMessage = '';
    productForm.form.markAllAsTouched();
    if (productForm.invalid || !this.categoryId || !this.typeId) {
      this.errorMessage = 'Complete every required product and hierarchy field.';
      queueMicrotask(() =>
        document.querySelector<HTMLElement>('.form-card .ng-invalid')?.focus());
      return;
    }
    if (this.form.initialSellingPrice != null &&
        this.form.initialSellingPrice <= 0) {
      this.errorMessage = 'Selling price must be greater than zero when supplied.';
      return;
    }
    if (!this.form.isVariableWeight && this.form.initialPriceBasis === 'PerKilogram' &&
        (!this.form.kilogramsPerUnit || this.form.kilogramsPerUnit <= 0)) {
      this.errorMessage = 'Enter a positive kilograms-per-unit value for a packaged product.';
      return;
    }
    if (this.form.initialSellingPrice != null &&
        this.form.priceReason.trim().length < 5) {
      this.errorMessage = 'Enter a price reason of at least five characters when adding an initial price.';
      return;
    }

    this.saving = true;
    this.hierarchy.createProduct(this.categoryId, this.typeId, this.form).pipe(
      take(1),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => this.router.navigate(['/products', result.productId, 'details']),
      error: error => this.fail(error)
    });
  }

  private fail(error: unknown): void {
    this.errorMessage = httpErrorMessage(error, 'The product could not be saved.');
  }
}
