import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { ProductHierarchyService } from '../../services/product-hierarchy';
import { AddProduct } from './add-product';

describe('AddProduct', () => {
  it('starts with a blank price so a one-cent value cannot be saved accidentally', () => {
    const component = new AddProduct(
      { createProduct: vi.fn() } as unknown as ProductHierarchyService,
      { navigate: vi.fn() } as unknown as Router,
      { detectChanges: vi.fn() } as any);

    expect(component.form.initialSellingPrice).toBeNull();
  });

  it('creates a packaged product through the existing hierarchy service and opens its details', () => {
    const hierarchy = {
      createProduct: vi.fn().mockReturnValue(of({
        message: 'Product created.',
        productId: 42
      }))
    } as unknown as ProductHierarchyService;
    const router = { navigate: vi.fn() } as unknown as Router;
    const component = new AddProduct(
      hierarchy,
      router,
      { detectChanges: vi.fn() } as any);
    component.categoryId = 3;
    component.typeId = 7;
    component.form = {
      productName: 'Washed Potatoes',
      size: '10 kg bag',
      shelfLifeDays: 30,
      initialSellingPrice: 12.5,
      initialPriceBasis: 'PerKilogram',
      sellingUnit: 'bag',
      kilogramsPerUnit: 10,
      isVariableWeight: false,
      priceReason: 'Approved launch price',
      status: 'Active'
    };
    const productForm = {
      invalid: false,
      form: { markAllAsTouched: vi.fn() }
    } as unknown as NgForm;

    component.save(productForm);

    expect(hierarchy.createProduct).toHaveBeenCalledWith(3, 7, component.form);
    expect(router.navigate).toHaveBeenCalledWith(['/products', 42, 'details']);
  });

  it('creates a product without an initial selling price', () => {
    const hierarchy = {
      createProduct: vi.fn().mockReturnValue(of({ message: 'Product created.', productId: 43 }))
    } as unknown as ProductHierarchyService;
    const router = { navigate: vi.fn() } as unknown as Router;
    const component = new AddProduct(hierarchy, router, { detectChanges: vi.fn() } as any);
    component.categoryId = 3;
    component.typeId = 7;
    component.form.productName = 'Unpriced Product';
    component.form.size = '1 kg';
    component.form.initialSellingPrice = null;
    component.form.priceReason = '';
    const productForm = {
      invalid: false,
      form: { markAllAsTouched: vi.fn() }
    } as unknown as NgForm;

    component.save(productForm);

    expect(hierarchy.createProduct).toHaveBeenCalledWith(3, 7,
      expect.objectContaining({ initialSellingPrice: null, priceReason: '' }));
    expect(router.navigate).toHaveBeenCalledWith(['/products', 43, 'details']);
  });

  it('rejects a packaged product without a positive kilograms-per-unit conversion', () => {
    const hierarchy = { createProduct: vi.fn() } as unknown as ProductHierarchyService;
    const component = new AddProduct(
      hierarchy,
      { navigate: vi.fn() } as unknown as Router,
      { detectChanges: vi.fn() } as any);
    component.categoryId = 3;
    component.typeId = 7;
    component.form.isVariableWeight = false;
    component.form.sellingUnit = 'bag';
    component.form.initialSellingPrice = 12.5;
    component.form.kilogramsPerUnit = 0;
    const productForm = {
      invalid: false,
      form: { markAllAsTouched: vi.fn() }
    } as unknown as NgForm;

    component.save(productForm);

    expect(hierarchy.createProduct).not.toHaveBeenCalled();
    expect(component.errorMessage).toContain('positive kilograms-per-unit');
  });
});
