/**
 * Reviewer guide: Coordinates the manage system settings page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { finalize } from 'rxjs';
import {
  ConfigurationAdminService,
  SystemSettingHistory,
  SystemSettingRecord
} from '../../services/configuration-admin';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';

@Component({
  selector: 'app-manage-system-settings',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, SearchFieldComponent],
  templateUrl: './manage-system-settings.html',
  styleUrl: '../configuration-management.css'
})
/** Edits validated operational settings and displays their change history. */
export class ManageSystemSettings implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  settings: SystemSettingRecord[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  history: SystemSettingHistory[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  categories: string[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selected?: SystemSettingRecord;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search = '';
  category = '';
  editValue = '';
  reason = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  showEditor = false;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  showHistory = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private api: ConfigurationAdminService,
    private notifications: NotificationService,
    private confirmation: ConfirmationService,
    private cdr: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.errorMessage = '';
    this.api.settings(this.search, this.category).pipe(finalize(() => {
      this.loading = false;
      this.cdr.detectChanges();
    })).subscribe({
      next: settings => {
        this.settings = settings;
        this.categories = [...new Set(settings.map(setting => setting.category))].sort();
      },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Encapsulates the edit view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  edit(setting: SystemSettingRecord): void {
    this.selected = setting;
    this.editValue = setting.value;
    this.reason = '';
    this.errorMessage = '';
    this.showEditor = true;
  }

  /**
   * Reviewer note: Coordinates the save interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  save(): void {
    if (!this.selected || !this.editValue.trim() || !this.reason.trim()) {
      this.errorMessage = 'A value and change reason are required.';
      queueMicrotask(() =>
        document.querySelector<HTMLElement>('.editor-modal [required]:invalid')?.focus());
      return;
    }
    this.saving = true;
    this.errorMessage = '';
    this.api.updateSetting(
      this.selected.key,
      this.editValue,
      this.reason,
      this.selected.rowVersion
    ).pipe(finalize(() => {
      this.saving = false;
      this.cdr.detectChanges();
    })).subscribe({
      next: response => {
        this.notifications.success(
          response.appliedImmediately
            ? `${response.message} The new value is active immediately.`
            : response.message
        );
        this.showEditor = false;
        this.load();
      },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates the reset interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async reset(setting: SystemSettingRecord): Promise<void> {
    const result = await this.confirmation.ask({
      title: 'Reset system setting',
      message: `${setting.displayName} will return to its safe default value (${setting.defaultValue}${setting.unit ? ` ${setting.unit}` : ''}).`,
      confirmLabel: 'Reset to default',
      tone: 'warning',
      reasonLabel: 'Reason for reset',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.api.resetSetting(setting.key, result.reason, setting.rowVersion).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.load();
      },
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Encapsulates the view history view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  viewHistory(setting: SystemSettingRecord): void {
    this.selected = setting;
    this.history = [];
    this.showHistory = true;
    this.api.settingHistory(setting.key).subscribe({
      next: history => this.history = history,
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Calculates allowed values for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  allowedValues(setting: SystemSettingRecord): string[] {
    if (!setting.allowedValuesJson) return [];
    try {
      return JSON.parse(setting.allowedValuesJson) as string[];
    } catch {
      return [];
    }
  }

  /**
   * Reviewer note: Encapsulates the display value view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  displayValue(setting: SystemSettingRecord): string {
    if (setting.valueType !== 'Json') {
      return `${setting.value}${setting.unit ? ` ${setting.unit}` : ''}`;
    }
    try {
      return (JSON.parse(setting.value) as string[]).join(', ');
    } catch {
      return setting.value;
    }
  }

  /**
   * Reviewer note: Encapsulates the read error view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private readError(error: any): string {
    const fields = error?.error?.errors;
    if (fields) return Object.values(fields).flat().join(' ');
    return error?.error?.message ?? 'The setting action could not be completed.';
  }
}
