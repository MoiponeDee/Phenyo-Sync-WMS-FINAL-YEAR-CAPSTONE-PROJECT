/**
 * Reviewer guide: Coordinates the manage product categories page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { Component } from '@angular/core';
import { LookupManagement } from '../lookup-management/lookup-management';

@Component({
  selector: 'app-manage-product-categories',
  standalone: true,
  imports: [LookupManagement],
  template: '<app-lookup-management kind="category" />'
})
export class ManageProductCategories {}
