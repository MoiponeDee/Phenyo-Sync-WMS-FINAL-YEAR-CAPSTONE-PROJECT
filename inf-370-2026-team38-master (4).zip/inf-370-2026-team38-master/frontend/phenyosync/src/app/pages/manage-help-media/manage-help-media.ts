/**
 * Reviewer guide: Coordinates the manage help media page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, forkJoin, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { ConfirmationService } from '../../services/confirmation';
import {
  HelpMedia,
  HelpService,
  HelpTopicSummary
} from '../../services/help';
import { NotificationService } from '../../services/notification';

@Component({
  selector: 'app-manage-help-media',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  templateUrl: './manage-help-media.html',
  styleUrl: './manage-help-media.css'
})
/** Uploads and publishes protected help media with explicit object-URL cleanup. */
export class ManageHelpMedia implements OnInit, OnDestroy {
  media: HelpMedia[] = [];
  topics: HelpTopicSummary[] = [];
  video: File | null = null;
  captions: File | null = null;
  // Reviewer note: Retains a disposable browser or device resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  previewUrl: string | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  form = {
    title: '',
    description: '',
    transcript: '',
    helpTopicId: null as number | null,
    isFeatured: true,
    isPublished: false,
    sortOrder: 100
  };

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly help: HelpService,
    private readonly confirmations: ConfirmationService,
    private readonly notifications: NotificationService,
    private readonly changeDetector: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      media: this.help.media(true),
      topics: this.help.manageTopics()
    }).pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: result => {
        this.media = result.media;
        this.topics = result.topics;
      },
      error: error => this.errorMessage =
        error.error?.message || 'Unable to load training media.'
    });
  }

  /**
   * Reviewer note: Encapsulates the choose video view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  chooseVideo(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.video = input.files?.[0] || null;
    if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
    this.previewUrl = this.video ? URL.createObjectURL(this.video) : null;
  }

  /**
   * Reviewer note: Encapsulates the choose captions view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  chooseCaptions(event: Event): void {
    this.captions =
      (event.target as HTMLInputElement).files?.[0] || null;
  }

  /**
   * Reviewer note: Coordinates the upload interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  upload(): void {
    this.errorMessage = '';
    if (!this.video || this.form.title.trim().length < 3) {
      this.errorMessage = 'Select an MP4 or WebM video and enter a title.';
      return;
    }
    this.saving = true;
    this.help.uploadMedia(this.video, this.captions, {
      ...this.form,
      title: this.form.title.trim(),
      description: this.form.description.trim() || undefined,
      transcript: this.form.transcript.trim() || undefined
    }).pipe(
      take(1),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: () => {
        this.notifications.success('Training media uploaded securely.');
        this.reset();
        this.load();
      },
      error: error => this.errorMessage =
        error.error?.message || 'The training media could not be uploaded.'
    });
  }

  /**
   * Reviewer note: Coordinates the remove interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async remove(item: HelpMedia): Promise<void> {
    const result = await this.confirmations.ask({
      title: 'Remove training media?',
      message: `"${item.title}" will stop being available in Help. The audit history remains.`,
      confirmLabel: 'Remove media',
      tone: 'danger',
      reasonLabel: 'Reason for removal',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.help.removeMedia(item.helpMediaId, result.reason).pipe(take(1)).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.load();
      },
      error: error => this.notifications.error(
        error.error?.message || 'The media could not be removed.')
    });
  }

  /**
   * Reviewer note: Coordinates the update status interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  updateStatus(
    item: HelpMedia,
    changes: Partial<HelpMedia>,
    message: string
  ): void {
    this.help.updateMedia(item, changes).pipe(take(1)).subscribe({
      next: () => {
        this.notifications.success(message);
        this.load();
      },
      error: error => this.notifications.error(
        error.error?.message || 'The media status could not be updated.')
    });
  }

  /**
   * Reviewer note: Coordinates the reset interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  reset(): void {
    if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
    this.previewUrl = null;
    this.video = null;
    this.captions = null;
    this.form = {
      title: '',
      description: '',
      transcript: '',
      helpTopicId: null,
      isFeatured: true,
      isPublished: false,
      sortOrder: 100
    };
  }

  /**
   * Reviewer note: Releases subscriptions or device resources when the view is left to prevent duplicate background work.
   * Cleanup stops stale callbacks from mutating a page that is no longer active.
   */
  ngOnDestroy(): void {
    if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
  }
}
