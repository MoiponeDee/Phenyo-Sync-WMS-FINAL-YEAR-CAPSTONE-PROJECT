/**
 * Reviewer guide: Coordinates the delivery proof page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize, take, timeout } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import {
  DeliveryProof as DeliveryProofModel,
  DeliveryProofImage,
  DeliveryService
} from '../../services/delivery';
import { AuthorizationService } from '../../services/authorization';

@Component({
  selector: 'app-delivery-proof',
  standalone: true,
  imports: [CommonModule, TopbarComponent],
  templateUrl: './delivery-proof.html',
  styleUrl: './delivery-proof.css'
})
/** Reviews protected proof images and completion data with object-URL cleanup. */
export class DeliveryProof implements OnInit, OnDestroy {
  deliveryId = 0;
  proof: DeliveryProofModel | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  images: Array<DeliveryProofImage & { imageUrl?: string }> = [];
  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private deliveriesApi: DeliveryService,
    private changeDetector: ChangeDetectorRef,
    private authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.deliveryId = Number(this.route.snapshot.paramMap.get('id'));
    this.loading = true;
    this.deliveriesApi.proof(this.deliveryId).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: proof => {
        this.proof = proof;
        this.loadImages();
      },
      error: error => this.errorMessage = this.errorText(error)
    });
  }

  /**
   * Reviewer note: Coordinates load images so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private loadImages(): void {
    this.deliveriesApi.proofImages(this.deliveryId).pipe(take(1)).subscribe({
      next: images => {
        this.clearImageUrls();
        this.images = images.map(image => ({ ...image }));
        this.images.forEach(image => {
          this.deliveriesApi.proofImageBlob(
            this.deliveryId,
            image.deliveryProofImageId
          ).pipe(take(1)).subscribe({
            next: blob => {
              image.imageUrl = URL.createObjectURL(blob);
              this.changeDetector.detectChanges();
            }
          });
        });
      },
      error: error => this.errorMessage = this.errorText(error)
    });
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.router.navigate([
      this.authorization.session()?.roleCode === 'Driver'
        ? '/my-deliveries'
        : '/deliveries'
    ]);
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown): string {
    if (error instanceof Error && error.name === 'TimeoutError') return 'The request timed out.';
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) return 'Cannot connect to the backend API.';
      if (error.status === 403) return error.error?.message || 'You cannot view this proof record.';
      if (error.status === 404) return error.error?.message || 'Proof of delivery was not found.';
      return error.error?.message || 'Unable to load proof of delivery.';
    }
    return 'Unable to load proof of delivery.';
  }

  /**
   * Reviewer note: Encapsulates the clear image urls view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private clearImageUrls(): void {
    this.images.forEach(image => {
      if (image.imageUrl) URL.revokeObjectURL(image.imageUrl);
    });
  }

  /**
   * Reviewer note: Releases subscriptions or device resources when the view is left to prevent duplicate background work.
   * Cleanup stops stale callbacks from mutating a page that is no longer active.
   */
  ngOnDestroy(): void {
    this.clearImageUrls();
  }
}
