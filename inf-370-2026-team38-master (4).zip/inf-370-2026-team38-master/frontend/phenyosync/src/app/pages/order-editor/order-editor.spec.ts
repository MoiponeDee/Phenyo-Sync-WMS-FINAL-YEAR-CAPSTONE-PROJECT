/**
 * Reviewer guide: Verifies the order editor frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { vi } from 'vitest';
import { environment } from '../../../environments/environment';
import { OrderEditor } from './order-editor';

// Proves the editor submits product/quantity input without trusting browser-calculated prices.
describe('OrderEditor', () => {
  let fixture: ComponentFixture<OrderEditor>;
  let component: OrderEditor;
  let http: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OrderEditor],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              paramMap: {
                get: () => null
              }
            }
          }
        },
        {
          provide: Router,
          useValue: {
            navigate: vi.fn().mockResolvedValue(true)
          }
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(OrderEditor);
    component = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    fixture.detectChanges();

    http.expectOne(request =>
      request.url === `${environment.apiUrl}/operational/customers`)
      .flush([{
        customerId: 7,
        customerNumber: 'CUS-000007',
        customerName: 'Test Customer',
        email: 'customer@example.test',
        billingAddress: '1 Billing Road',
        deliveryAddress: '2 Delivery Road',
        status: 'Active',
        orderCount: 0,
        outstandingBalance: 0,
        rowVersion: ''
      }]);
    http.expectOne(`${environment.apiUrl}/prices/orderable-products`)
      .flush([product(1, 10), product(2, 20), product(3, 30)]);
    await fixture.whenStable();
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that adds and removes independent order lines.
  it('adds and removes independent order lines', () => {
    expect(component.lines.length).toBe(1);

    component.addLine();
    component.addLine();
    expect(component.lines.length).toBe(3);

    component.removeLine(1);
    expect(component.lines.length).toBe(2);
  });

  // Reviewer note: Guards the observable rule that rejects duplicate products before calling the backend.
  it('rejects duplicate products before calling the backend', () => {
    component.addLine();
    component.lines.at(0).patchValue({ productId: 1, quantityUnits: 1 });
    component.lines.at(1).patchValue({ productId: 1, quantityUnits: 2 });
    component.orderForm.patchValue({
      customerId: 7,
      billingAddress: '1 Billing Road',
      deliveryAddress: '2 Delivery Road'
    });

    component.save();

    expect(component.errorMessage).toContain('only once');
    http.expectNone(`${environment.apiUrl}/orders`);
  });

  // Reviewer note: Guards the observable rule that submits all three distinct lines without client-controlled prices.
  it('submits all three distinct lines without client-controlled prices', () => {
    component.addLine();
    component.addLine();
    component.orderForm.patchValue({
      customerId: 7,
      billingAddress: '1 Billing Road',
      deliveryAddress: '2 Delivery Road'
    });
    component.lines.at(0).patchValue({ productId: 1, quantityUnits: 1 });
    component.lines.at(1).patchValue({ productId: 2, quantityUnits: 2 });
    component.lines.at(2).patchValue({ productId: 3, quantityUnits: 3 });

    component.save();

    const request = http.expectOne(`${environment.apiUrl}/orders`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body.items).toHaveLength(3);
    expect(request.request.body.items[2]).toEqual({
      productId: 3,
      quantityUnits: 3,
      notes: undefined
    });
    expect(request.request.body.totalAmount).toBeUndefined();
    request.flush({
      message: 'Order created.',
      order: { salesOrderId: 42 }
    });
  });
});

function product(productId: number, sellingPrice: number) {
  return {
    productId,
    productPriceId: productId,
    productCode: `PRODUCT-${productId}`,
    productName: `Product ${productId}`,
    productTypeName: 'Fresh',
    productCategoryName: 'Produce',
    size: '1 KG',
    sellingPrice,
    sellingPricePerUnit: sellingPrice,
    priceBasis: 'PerSellableUnit',
    sellingUnit: 'box',
    kilogramsPerUnit: undefined,
    isVariableWeight: false,
    availableQuantityKg: 100
  };
}
