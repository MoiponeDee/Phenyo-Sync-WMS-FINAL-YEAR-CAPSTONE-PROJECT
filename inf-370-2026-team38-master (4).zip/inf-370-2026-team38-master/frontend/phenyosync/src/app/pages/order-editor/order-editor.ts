/**
 * Reviewer guide: Coordinates the order editor page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormArray,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { finalize, forkJoin, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import {
  CustomerSummary,
  OperationalSectionsService
} from '../../services/operational-sections';
import {
  CreateOrderRequest,
  OrderService,
  SalesOrderDetail
} from '../../services/order';
import { OrderableProduct, PricingService } from '../../services/pricing';

type OrderLineForm = FormGroup<{
  productId: FormControl<number | null>;
  quantityUnits: FormControl<number | null>;
  notes: FormControl<string>;
}>;

@Component({
  selector: 'app-order-editor',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, TopbarComponent],
  templateUrl: './order-editor.html'
})
/** Captures customer/order lines while prices and totals are resolved authoritatively by the API. */
export class OrderEditor implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  customers: CustomerSummary[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  products: OrderableProduct[] = [];
  order: SalesOrderDetail | null = null;
  orderId: number | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly orderForm = new FormGroup({
    customerId: new FormControl<number | null>(null, Validators.required),
    requestedDeliveryLocal: new FormControl('', { nonNullable: true }),
    deliveryAddress: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(500)]
    }),
    billingAddress: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(500)]
    }),
    notes: new FormControl('', {
      nonNullable: true,
      validators: [Validators.maxLength(1000)]
    }),
    items: new FormArray<OrderLineForm>([this.createLine()])
  });

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly customersApi: OperationalSectionsService,
    private readonly pricingApi: PricingService,
    private readonly orders: OrderService,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly changeDetector: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    const value = Number(this.route.snapshot.paramMap.get('id'));
    this.orderId = Number.isInteger(value) && value > 0 ? value : null;
    this.orderForm.controls.customerId.valueChanges.subscribe(() => {
      this.customerChanged();
    });
    this.load();
  }

  /**
   * Reviewer note: Encapsulates the title view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get title(): string {
    return this.orderId ? 'Update Order' : 'Create Order';
  }

  /**
   * Reviewer note: Encapsulates the lines view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get lines(): FormArray<OrderLineForm> {
    return this.orderForm.controls.items;
  }

  /**
   * Reviewer note: Encapsulates the estimated total view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get estimatedTotal(): number {
    // This estimate helps the user; the server resolves effective prices and final totals on save.
    return this.lines.controls.reduce((total, line) => {
      const product = this.product(line.controls.productId.value);
      const quantity = line.controls.quantityUnits.value ?? 0;
      return total + (product?.sellingPricePerUnit ?? 0) * quantity;
    }, 0);
  }

  /**
   * Reviewer note: Coordinates the add line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend permission/business validation when required.
   */
  addLine(): void {
    this.lines.push(this.createLine());
  }

  /**
   * Reviewer note: Coordinates the remove line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend permission/business validation when required.
   */
  removeLine(index: number): void {
    if (this.lines.length > 1) {
      this.lines.removeAt(index);
    }
  }

  /**
   * Reviewer note: Encapsulates the customer changed view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  customerChanged(): void {
    if (this.order) return;
    const selected = this.customers.find(
      item => item.customerId === this.orderForm.controls.customerId.value
    );
    if (!selected) return;

    this.orderForm.patchValue({
      deliveryAddress: selected.deliveryAddress ?? '',
      billingAddress: selected.billingAddress ?? ''
    });
  }

  /**
   * Reviewer note: Encapsulates the product view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  product(productId: number | null): OrderableProduct | undefined {
    return this.products.find(item => item.productId === productId);
  }

  priceLabel(product: OrderableProduct): string {
    const suffix = product.priceBasis === 'PerKilogram'
      ? 'kg'
      : product.sellingUnit;
    return `R${product.sellingPrice.toFixed(2)}/${suffix}`;
  }

  cannotPrice(product: OrderableProduct): boolean {
    return product.sellingPricePerUnit === null;
  }

  /**
   * Reviewer note: Encapsulates the product already selected view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  productAlreadySelected(productId: number, currentIndex: number): boolean {
    return this.lines.controls.some((line, index) =>
      index !== currentIndex && line.controls.productId.value === productId
    );
  }

  /**
   * Reviewer note: Coordinates the save interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend permission/business validation when required.
   */
  save(): void {
    // Submit product identifiers/quantities only and refresh from the authoritative response DTO.
    this.errorMessage = '';
    this.successMessage = '';
    this.orderForm.markAllAsTouched();

    const selectedIds = this.lines.controls
      .map(line => line.controls.productId.value)
      .filter((id): id is number => id !== null);
    if (new Set(selectedIds).size !== selectedIds.length) {
      this.errorMessage =
        'Each product may appear only once. Combine duplicate quantities into one line.';
      return;
    }

    if (this.orderForm.invalid || this.lines.length === 0) {
      this.errorMessage =
        'Select a customer and complete every product, quantity, and address field.';
      queueMicrotask(() =>
        document.querySelector<HTMLElement>('.order-card .ng-invalid')?.focus());
      return;
    }

    const form = this.orderForm.getRawValue();
    const request: CreateOrderRequest = {
      customerId: form.customerId!,
      requestedDeliveryDateUtc: form.requestedDeliveryLocal
        ? new Date(form.requestedDeliveryLocal).toISOString()
        : undefined,
      deliveryAddress: form.deliveryAddress.trim(),
      billingAddress: form.billingAddress.trim(),
      notes: form.notes.trim() || undefined,
      items: form.items.map(line => ({
        productId: line.productId!,
        quantityUnits: line.quantityUnits!,
        notes: line.notes.trim() || undefined
      }))
    };

    this.saving = true;
    const operation = this.orderId
      ? this.orders.update(this.orderId, {
          ...request,
          rowVersion: this.order?.rowVersion
        })
      : this.orders.create(request);

    operation.pipe(
      take(1),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.successMessage = response.message;
        this.router.navigate(['/order-details', response.order.salesOrderId]);
      },
      error: error => this.fail(error)
    });
  }

  /**
   * Reviewer note: Coordinates the create line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend permission/business validation when required.
   */
  private createLine(): OrderLineForm {
    return new FormGroup({
      productId: new FormControl<number | null>(null, Validators.required),
      quantityUnits: new FormControl<number | null>(null, [
        Validators.required,
        Validators.min(0.01)
      ]),
      notes: new FormControl('', {
        nonNullable: true,
        validators: [Validators.maxLength(500)]
      })
    });
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private load(): void {
    this.loading = true;
    const sources = this.orderId
      ? forkJoin({
          customers: this.customersApi.customers('', false),
          products: this.pricingApi.getOrderableProducts(),
          order: this.orders.get(this.orderId)
        })
      : forkJoin({
          customers: this.customersApi.customers('', false),
          products: this.pricingApi.getOrderableProducts()
        });

    sources.pipe(
      take(1),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: data => {
        this.customers = data.customers;
        this.products = data.products;
        if ('order' in data && data.order) {
          this.populate(data.order as SalesOrderDetail);
        }
      },
      error: error => this.fail(error)
    });
  }

  /**
   * Reviewer note: Encapsulates the populate view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private populate(order: SalesOrderDetail): void {
    this.order = order;
    this.orderForm.patchValue({
      customerId: order.customerId,
      requestedDeliveryLocal: order.requestedDeliveryDateUtc
        ? this.localDate(order.requestedDeliveryDateUtc)
        : '',
      deliveryAddress: order.deliveryAddress,
      billingAddress: order.billingAddress,
      notes: order.notes ?? ''
    });
    this.lines.clear();
    order.items.forEach(item => {
      const line = this.createLine();
      line.setValue({
        productId: item.productId,
        quantityUnits: item.quantityUnits,
        notes: item.notes ?? ''
      });
      this.lines.push(line);
    });
    if (this.lines.length === 0) {
      this.addLine();
    }
  }

  /**
   * Reviewer note: Encapsulates the local date view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private localDate(value: string): string {
    const date = new Date(value);
    return new Date(date.getTime() - date.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 16);
  }

  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown): void {
    this.errorMessage = error instanceof HttpErrorResponse
      ? error.error?.message ||
        (error.status === 409
          ? 'The order changed or cannot be edited in its current state.'
          : 'The request failed.')
      : 'The request failed.';
  }
}
