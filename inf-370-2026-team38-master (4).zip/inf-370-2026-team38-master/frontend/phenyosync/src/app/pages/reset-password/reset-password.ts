/**
 * Reviewer guide: Coordinates the reset password page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reset-password.html',
  styleUrl: './reset-password.css',
})
/** Consumes the reset token and email from the URL once, then submits them to the API. */
export class ResetPassword implements OnInit {

  email = '';
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  token = '';

  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  newPassword = '';
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  confirmPassword = '';

  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  showNewPassword = false;
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  showConfirmPassword = false;

  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  submitted = false;

  get passwordLengthValid(): boolean {
    return this.newPassword.length >= 8;
  }

  get passwordsMatch(): boolean {
    return this.confirmPassword.length > 0 &&
      this.newPassword === this.confirmPassword;
  }

  get linkIsValid(): boolean {
    return Boolean(this.email && this.token);
  }

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.email =
      this.route.snapshot.queryParamMap.get('email') ?? '';

    this.token =
      this.route.snapshot.queryParamMap.get('token') ?? '';

    if (!this.email || !this.token) {
      this.errorMessage =
        'The password reset link is invalid or incomplete.';
    }
  }

  /**
   * Reviewer note: Encapsulates the toggle new password visibility view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  toggleNewPasswordVisibility(): void {
    this.showNewPassword = !this.showNewPassword;
  }

  /**
   * Reviewer note: Encapsulates the toggle confirm password visibility view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  toggleConfirmPasswordVisibility(): void {
    this.showConfirmPassword =
      !this.showConfirmPassword;
  }

  /**
   * Reviewer note: Coordinates the reset password interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  resetPassword(): void {
    this.submitted = true;
    this.errorMessage = '';
    this.successMessage = '';

    if (!this.email || !this.token) {
      this.errorMessage =
        'The password reset link is invalid or incomplete.';
      return;
    }

    if (!this.newPassword || !this.confirmPassword) {
      this.errorMessage =
        'Please complete both password fields.';
      this.focusField(!this.newPassword ? 'newPassword' : 'confirmPassword');
      return;
    }

    if (this.newPassword.length < 8) {
      this.errorMessage =
        'Password must contain at least 8 characters.';
      this.focusField('newPassword');
      return;
    }

    if (this.newPassword !== this.confirmPassword) {
      this.errorMessage = 'Passwords do not match.';
      this.focusField('confirmPassword');
      return;
    }

    this.loading = true;

    this.authService.resetPassword({
      email: this.email,
      token: this.token,
      newPassword: this.newPassword,
      confirmPassword: this.confirmPassword
    }).subscribe({
      next: (response: any) => {
        this.loading = false;

        this.successMessage =
          response.message ||
          'Password reset successfully.';

        this.newPassword = '';
        this.confirmPassword = '';
        this.submitted = false;

        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 2000);
      },
      error: (error) => {
        this.loading = false;

        this.errorMessage =
          error.error?.message ||
          'The password could not be reset.';
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the return to login view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  returnToLogin(): void {
    this.router.navigate(['/login']);
  }

  private focusField(id: string): void {
    queueMicrotask(() => document.getElementById(id)?.focus());
  }
}
