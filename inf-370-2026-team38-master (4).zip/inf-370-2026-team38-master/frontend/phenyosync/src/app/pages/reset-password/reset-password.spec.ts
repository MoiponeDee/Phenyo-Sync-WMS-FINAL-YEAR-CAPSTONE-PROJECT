/**
 * Reviewer guide: Verifies the reset password frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetPassword } from './reset-password';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { ActivatedRoute, Router, convertToParamMap } from '@angular/router';
import { AuthService } from '../../services/auth';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

// Guards the email-plus-token handoff, including addresses that contain a Gmail plus alias.
describe('ResetPassword', () => {
  let component: ResetPassword;
  let fixture: ComponentFixture<ResetPassword>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ResetPassword],
      providers: [provideHttpClient(), provideRouter([])]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ResetPassword);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  // Reviewer note: Guards the observable rule that should create.
  it('should create', () => {
    expect(component).toBeTruthy();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.auth-shell')).not.toBeNull();
    expect(fixture.nativeElement.textContent).toContain('Create a new password');
  });

  // Reviewer note: Guards the observable rule that preserves a decoded Gmail plus alias and the single-decoded token.
  it('preserves a decoded Gmail plus alias and the single-decoded token', () => {
    const page = new ResetPassword(
      {
        snapshot: {
          queryParamMap: convertToParamMap({
            email: 'zafarsuliman+warehousemanager5@gmail.com',
            token: 'reset-token_-123'
          })
        }
      } as ActivatedRoute,
      {} as Router,
      {} as AuthService
    );

    page.ngOnInit();

    expect(page.email).toBe('zafarsuliman+warehousemanager5@gmail.com');
    expect(page.token).toBe('reset-token_-123');
    expect(page.errorMessage).toBe('');
  });

  it('rejects short or mismatched passwords before calling the API', () => {
    const resetPassword = vi.fn().mockReturnValue(of({ message: 'done' }));
    const page = pageWith(resetPassword);
    page.newPassword = 'short';
    page.confirmPassword = 'short';

    page.resetPassword();
    expect(page.errorMessage).toContain('at least 8 characters');
    expect(resetPassword).not.toHaveBeenCalled();

    page.newPassword = 'long-enough';
    page.confirmPassword = 'different';
    page.resetPassword();
    expect(page.errorMessage).toBe('Passwords do not match.');
    expect(resetPassword).not.toHaveBeenCalled();
  });

  it('submits the exact email and token once and shows API success', () => {
    vi.useFakeTimers();
    const resetPassword = vi.fn().mockReturnValue(of({ message: 'Password changed.' }));
    const page = pageWith(resetPassword);
    page.newPassword = 'new-password';
    page.confirmPassword = 'new-password';

    page.resetPassword();

    expect(resetPassword).toHaveBeenCalledWith({
      email: 'zafarsuliman+warehousemanager5@gmail.com',
      token: 'reset-token_-123',
      newPassword: 'new-password',
      confirmPassword: 'new-password'
    });
    expect(page.successMessage).toBe('Password changed.');
    expect(page.newPassword).toBe('');
    vi.runAllTimers();
    vi.useRealTimers();
  });

  it('surfaces the safe API error without changing the token', () => {
    const resetPassword = vi.fn().mockReturnValue(throwError(() => ({
      error: { message: 'The reset link has expired or was already used.' }
    })));
    const page = pageWith(resetPassword);
    page.newPassword = 'new-password';
    page.confirmPassword = 'new-password';

    page.resetPassword();

    expect(page.errorMessage).toContain('expired or was already used');
    expect(page.token).toBe('reset-token_-123');
  });

  function pageWith(resetPassword: ReturnType<typeof vi.fn>): ResetPassword {
    const page = new ResetPassword(
      {
        snapshot: {
          queryParamMap: convertToParamMap({
            email: 'zafarsuliman+warehousemanager5@gmail.com',
            token: 'reset-token_-123'
          })
        }
      } as ActivatedRoute,
      { navigate: vi.fn() } as unknown as Router,
      { resetPassword } as unknown as AuthService
    );
    page.ngOnInit();
    return page;
  }
});
