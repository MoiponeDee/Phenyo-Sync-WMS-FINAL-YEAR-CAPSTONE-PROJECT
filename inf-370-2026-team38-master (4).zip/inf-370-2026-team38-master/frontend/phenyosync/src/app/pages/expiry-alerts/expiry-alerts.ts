/**
 * Reviewer guide: Coordinates the expiry alerts page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { finalize, forkJoin, take } from 'rxjs';
import { ExpiryAlertService, ExpiryAlertSummary } from '../../services/expiry-alerts';
import { ProductResponse, ProductService } from '../../services/product';
import { ProductCategory, ProductLookupService, WarehouseSection } from '../../services/product-lookups';
import { AuthorizationService } from '../../services/authorization';
import { HumanizeCodePipe } from '../../pipes/humanize-code.pipe';

@Component({
  selector: 'app-expiry-alerts', standalone: true,
  imports: [CommonModule, FormsModule, HumanizeCodePipe],
  templateUrl: './expiry-alerts.html', styleUrl: './expiry-alerts.css'
})
/** Presents the backend-classified expiry queue and controlled decision links. */
export class ExpiryAlerts implements OnInit {
  summary: ExpiryAlertSummary = { warningCount: 0, urgentCount: 0, expiredCount: 0, batches: [] };
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  products: ProductResponse[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  categories: ProductCategory[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  sections: WarehouseSection[] = [];
  level = '';
  productId: number | null = null;
  categoryId: number | null = null;
  sectionId: number | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  scanning = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private alerts: ExpiryAlertService,
    private productsService: ProductService,
    private lookups: ProductLookupService,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Calculates can run scan for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canRunScan(): boolean {
    return this.authorization.has('Expiry.Resolve');
  }

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      products: this.productsService.getProducts(),
      categories: this.lookups.getActiveProductCategories(),
      sections: this.lookups.getActiveWarehouseSections()
    }).pipe(take(1)).subscribe({
      next: data => { this.products = data.products; this.categories = data.categories; this.sections = data.sections; },
      error: error => this.fail(error, 'Some alert filters could not be loaded.')
    });
    this.loadAlerts();
  }

  /**
   * Reviewer note: Coordinates load alerts so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadAlerts(): void {
    this.loading = true;
    this.errorMessage = '';
    this.alerts.getAlerts({ level: this.level, productId: this.productId, categoryId: this.categoryId, sectionId: this.sectionId })
      .pipe(finalize(() => { this.loading = false; this.cdr.detectChanges(); }))
      .subscribe({ next: summary => this.summary = summary, error: error => this.fail(error, 'Unable to load expiry alerts.') });
  }

  /**
   * Reviewer note: Encapsulates the clear filters view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearFilters(): void {
    this.level = ''; this.productId = null; this.categoryId = null; this.sectionId = null; this.loadAlerts();
  }

  /**
   * Reviewer note: Encapsulates the run scan view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  runScan(): void {
    if (!this.canRunScan || this.scanning) return;
    this.scanning = true;
    this.successMessage = '';
    this.alerts.runScan().pipe(finalize(() => { this.scanning = false; this.cdr.detectChanges(); }))
      .subscribe({
        next: response => { this.successMessage = response.message; this.loadAlerts(); },
        error: error => this.fail(error, 'Unable to run the expiry scan.')
      });
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.router.navigate(['/dashboard']);
  }

  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown, fallback: string): void {
    console.error('Expiry alert error:', error);
    this.errorMessage = error instanceof HttpErrorResponse ? error.error?.message || fallback : fallback;
  }
}
