import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import { OperationalSectionsService } from '../../services/operational-sections';
import { ProductLookupService } from '../../services/product-lookups';
import { SuppliersComponent } from './suppliers';

describe('SuppliersComponent', () => {
  let fixture: ComponentFixture<SuppliersComponent>;
  let component: SuppliersComponent;
  let authorization: AuthorizationService;
  const operational = {
    suppliers: vi.fn(() => of([])),
    supplierOrders: vi.fn(() => of([])),
    supplierOrderRawStockOptions: vi.fn(() => of([{
      rawStockItemId: 7,
      itemCode: 'RAW-CARROT',
      itemName: 'Loose carrots',
      unitOfMeasure: 'kg'
    }]))
  };
  const lookups = {
    getActiveWarehouseSections: vi.fn(() => of([{
      sectionId: 2,
      sectionName: 'Receiving Area'
    }]))
  };

  beforeEach(async () => {
    vi.clearAllMocks();
    await TestBed.configureTestingModule({
      imports: [SuppliersComponent],
      providers: [
        provideRouter([]),
        { provide: OperationalSectionsService, useValue: operational },
        { provide: ProductLookupService, useValue: lookups },
        { provide: NotificationService, useValue: { error: vi.fn(), warning: vi.fn() } },
        { provide: ConfirmationService, useValue: { ask: vi.fn() } }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(SuppliersComponent);
    component = fixture.componentInstance;
    authorization = TestBed.inject(AuthorizationService);
  });

  it('loads narrow Supplier Order options for an administrator without RawStock.View', () => {
    authorization.session.set({
      userId: 8,
      email: 'admin@example.invalid',
      role: 'Super Admin',
      roleCode: 'Admin',
      isActive: true,
      permissions: [
        { permissionId: 1, code: 'SupplierOrders.View', displayName: 'View orders', module: 'Suppliers' },
        { permissionId: 2, code: 'SupplierOrders.Manage', displayName: 'Manage orders', module: 'Suppliers' },
        { permissionId: 3, code: 'WarehouseSections.View', displayName: 'View sections', module: 'Warehouse' }
      ]
    });

    fixture.detectChanges();

    expect(component.canEditOrders).toBe(true);
    expect(operational.supplierOrderRawStockOptions).toHaveBeenCalledOnce();
    expect(component.rawStock[0].itemCode).toBe('RAW-CARROT');
  });

  it('keeps Warehouse Manager view-only even with Raw Stock access', () => {
    authorization.session.set({
      userId: 9,
      email: 'warehouse@example.invalid',
      role: 'Warehouse Manager',
      roleCode: 'WarehouseManager',
      isActive: true,
      permissions: [
        { permissionId: 1, code: 'SupplierOrders.View', displayName: 'View orders', module: 'Suppliers' },
        { permissionId: 2, code: 'RawStock.View', displayName: 'View raw stock', module: 'Raw Stock' },
        { permissionId: 3, code: 'WarehouseSections.View', displayName: 'View sections', module: 'Warehouse' }
      ]
    });

    fixture.detectChanges();

    expect(component.canEditOrders).toBe(false);
    expect(operational.supplierOrderRawStockOptions).not.toHaveBeenCalled();
  });
});
