/**
 * Reviewer guide: Coordinates the suppliers page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { finalize, forkJoin, of } from 'rxjs';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import {
  OperationalSectionsService,
  SupplierOrder,
  SupplierOrderRawStockOption,
  SupplierSummary
} from '../../services/operational-sections';
import {
  ProductLookupService,
  WarehouseSection
} from '../../services/product-lookups';

type SupplierTab = 'directory' | 'orders';

@Component({
  selector: 'app-suppliers',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TopbarComponent,
    SidebarComponent,
    SearchFieldComponent
  ],
  templateUrl: './suppliers.html',
  styleUrl: './suppliers.css'
})
/** Manages supplier master data and supplier-order actions under effective permissions. */
export class SuppliersComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  tab: SupplierTab = 'directory';
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  suppliers: SupplierSummary[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  orders: SupplierOrder[] = [];
  rawStock: SupplierOrderRawStockOption[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  sections: WarehouseSection[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selected: SupplierSummary | null = null;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedOrder: SupplierOrder | null = null;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search = '';
  includeInactive = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Suppliers', route: '/suppliers', active: true },
    { name: 'Raw Stock Receiving', route: '/raw-stock', permissions: ['RawStock.View'] },
    { name: 'Supplier Payments', route: '/payments', permissions: ['SupplierPayments.View', 'Payments.View'] },
    { name: 'Management Overview', route: '/management-dashboard' }
  ];
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly supplierForm = this.fb.nonNullable.group({
    supplierName: ['', Validators.required],
    supplierTypeCode: ['PRODUCER', Validators.required],
    contactPerson: [''],
    email: ['', Validators.email],
    phone: [''],
    address: [''],
    status: ['Active', Validators.required],
    rowVersion: ['']
  });
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly orderForm = this.fb.nonNullable.group({
    supplierId: [0, Validators.min(1)],
    warehouseSectionId: [0, Validators.min(1)],
    expectedDeliveryAtUtc: [''],
    notes: [''],
    lines: this.fb.array([this.createOrderLine()])
  });

  /**
   * Reviewer note: Encapsulates the order lines view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get orderLines(): FormArray {
    return this.orderForm.controls.lines as FormArray;
  }

  /**
   * Reviewer note: Encapsulates the order total view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get orderTotal(): number {
    return this.orderLines.controls.reduce((total, control) => {
      const quantity = Number(control.get('orderedQuantity')?.value) || 0;
      const price = Number(control.get('expectedUnitPrice')?.value) || 0;
      return total + quantity * price;
    }, 0);
  }

  /**
   * Reviewer note: Encapsulates the active suppliers view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get activeSuppliers(): SupplierSummary[] {
    return this.suppliers.filter(item => item.status === 'Active');
  }

  /**
   * Reviewer note: Coordinates selected order supplier so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  get selectedOrderSupplier(): SupplierSummary | undefined {
    return this.suppliers.find(item =>
      item.supplierId === this.orderForm.controls.supplierId.value);
  }

  /**
   * Reviewer note: Calculates can view orders for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canViewOrders(): boolean {
    return this.authorization.has('SupplierOrders.View');
  }

  /**
   * Reviewer note: Calculates can manage orders for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canManageOrders(): boolean {
    return this.authorization.has('SupplierOrders.Manage');
  }

  /**
   * Reviewer note: Calculates can edit orders for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canEditOrders(): boolean {
    return this.canManageOrders &&
      this.authorization.has('WarehouseSections.View');
  }

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private operational: OperationalSectionsService,
    private lookups: ProductLookupService,
    private notifications: NotificationService,
    private confirmation: ConfirmationService,
    private changeDetector: ChangeDetectorRef,
    readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Encapsulates the set tab view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  setTab(tab: SupplierTab): void {
    if (tab === 'orders' && !this.canViewOrders) return;

    this.tab = tab;
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      suppliers: this.operational.suppliers(this.search, this.includeInactive),
      orders: this.canViewOrders
        ? this.operational.supplierOrders()
        : of([] as SupplierOrder[]),
      rawStock: this.canEditOrders
        ? this.operational.supplierOrderRawStockOptions()
        : of([] as SupplierOrderRawStockOption[]),
      sections: this.canEditOrders
        ? this.lookups.getActiveWarehouseSections()
        : of([] as WarehouseSection[])
    }).pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: data => {
        this.suppliers = data.suppliers;
        this.orders = data.orders;
        this.rawStock = data.rawStock;
        this.sections = data.sections;
      },
      error: error => this.notifications.error(
        error?.error?.message || 'Supplier operations could not be loaded.')
    });
  }

  /**
   * Reviewer note: Encapsulates the edit view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  edit(item: SupplierSummary): void {
    this.selected = item;
    this.supplierForm.reset({
      supplierName: item.supplierName,
      supplierTypeCode: item.supplierTypeCode,
      contactPerson: item.contactPerson || '',
      email: item.email || '',
      phone: item.phone || '',
      address: item.address || '',
      status: item.status,
      rowVersion: item.rowVersion
    });
  }

  /**
   * Reviewer note: Encapsulates the clear supplier view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearSupplier(): void {
    this.selected = null;
    this.supplierForm.reset({
      supplierTypeCode: 'PRODUCER',
      status: 'Active',
      rowVersion: ''
    });
  }

  /**
   * Reviewer note: Coordinates the save supplier interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveSupplier(): void {
    // The API owns duplicate detection; the page only performs immediate form validation.
    if (this.supplierForm.invalid) {
      this.supplierForm.markAllAsTouched();
      queueMicrotask(() =>
        document.querySelector<HTMLElement>('.ops-form-grid .ng-invalid')?.focus());
      return;
    }
    this.run(this.operational.saveSupplier(
      this.selected?.supplierId ?? null,
      this.supplierForm.getRawValue()
    ), this.selected ? 'Supplier updated.' : 'Supplier created.', () => {
      this.clearSupplier();
      this.load();
    });
  }

  /**
   * Reviewer note: Coordinates the create order interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  createOrder(): void {
    // Line totals are displayed for review, but supplier-order totals are recalculated server-side.
    if (!this.canEditOrders) return;

    if (this.orderForm.invalid) {
      this.orderForm.markAllAsTouched();
      queueMicrotask(() =>
        document.querySelector<HTMLElement>('.order-header-fields .ng-invalid, .order-lines .ng-invalid')?.focus());
      return;
    }
    const value = this.orderForm.getRawValue();
    const itemIds = value.lines.map(line => Number(line['rawStockItemId']));
    if (new Set(itemIds).size !== itemIds.length) {
      this.notifications.warning(
        'Each raw-stock item may appear only once on a supplier order.');
      return;
    }
    const request = {
      supplierId: value.supplierId,
      warehouseSectionId: value.warehouseSectionId,
      expectedDeliveryAtUtc: value.expectedDeliveryAtUtc
        ? new Date(value.expectedDeliveryAtUtc).toISOString()
        : null,
      notes: value.notes || null,
      lines: value.lines.map(line => ({
        rawStockItemId: line['rawStockItemId'],
        orderedQuantity: line['orderedQuantity'],
        expectedUnitPrice: line['expectedUnitPrice'],
        unitOfMeasure: line['unitOfMeasure'],
        notes: line['notes'] || null
      }))
    };
    const operation = this.selectedOrder
      ? this.operational.updateSupplierOrder(
          this.selectedOrder.supplierOrderId,
          this.selectedOrder.rowVersion,
          request)
      : this.operational.createSupplierOrder(request);
    this.run(operation,
      this.selectedOrder
        ? 'Draft supplier order updated.'
        : 'Supplier order created as a draft.', () => {
      this.resetOrderForm();
      this.load();
    });
  }

  /**
   * Reviewer note: Coordinates the remove supplier interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async removeSupplier(item: SupplierSummary): Promise<void> {
    const decision = await this.confirmation.ask({
      title: `Delete ${item.supplierName}?`,
      message: 'Unused suppliers are permanently deleted. Suppliers with business history can only be deactivated.',
      confirmLabel: 'Review and delete',
      tone: 'danger',
      reasonLabel: 'Deletion reason',
      reasonRequired: true
    });
    if (!decision.confirmed) return;

    this.run(
      this.operational.deleteSupplier(
        item.supplierId,
        decision.reason,
        item.rowVersion),
      'Unused supplier permanently deleted.',
      () => this.load(),
      async error => {
        if (error?.status === 409 && error?.error?.canDeactivate) {
          const fallback = await this.confirmation.ask({
            title: 'Deactivate supplier instead?',
            message: error.error.deleteBlockedReason ||
              'Supplier business history must be retained.',
            confirmLabel: 'Deactivate',
            tone: 'warning'
          });
          if (!fallback.confirmed) return;
          this.run(
            this.operational.saveSupplier(item.supplierId, {
              supplierName: item.supplierName,
              supplierTypeCode: item.supplierTypeCode,
              contactPerson: item.contactPerson,
              email: item.email,
              phone: item.phone,
              address: item.address,
              status: 'Inactive',
              rowVersion: item.rowVersion
            }),
            'Supplier deactivated. Business history was preserved.',
            () => this.load());
          return;
        }
        this.notifications.error(
          error?.error?.message || 'The supplier could not be deleted.');
      });
  }

  /**
   * Reviewer note: Encapsulates the edit order view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  editOrder(item: SupplierOrder): void {
    if (!this.canEditOrders) return;

    if (item.status !== 'Draft') {
      this.notifications.warning('Only draft supplier orders can be edited.');
      return;
    }
    this.selectedOrder = item;
    this.orderLines.clear();
    for (const line of item.lines) {
      this.orderLines.push(this.fb.nonNullable.group({
        rawStockItemId: [line.rawStockItemId, Validators.min(1)],
        orderedQuantity: [line.orderedQuantity, Validators.min(0.001)],
        expectedUnitPrice: [line.expectedUnitPrice, Validators.min(0)],
        unitOfMeasure: [line.unitOfMeasure, Validators.required],
        notes: ['']
      }));
    }
    this.orderForm.patchValue({
      supplierId: item.supplierId,
      warehouseSectionId: item.warehouseSectionId,
      expectedDeliveryAtUtc: item.expectedDeliveryAtUtc
        ? item.expectedDeliveryAtUtc.slice(0, 16)
        : '',
      notes: ''
    });
  }

  /**
   * Reviewer note: Coordinates the add order line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  addOrderLine(): void {
    this.orderLines.push(this.createOrderLine());
  }

  /**
   * Reviewer note: Coordinates the remove order line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  removeOrderLine(index: number): void {
    if (this.orderLines.length <= 1) {
      return;
    }

    this.orderLines.removeAt(index);
  }

  /**
   * Reviewer note: Encapsulates the line total view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  lineTotal(index: number): number {
    const line = this.orderLines.at(index);
    const quantity = Number(line.get('orderedQuantity')?.value) || 0;
    const price = Number(line.get('expectedUnitPrice')?.value) || 0;
    return quantity * price;
  }

  /**
   * Reviewer note: Coordinates the approve interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async approve(item: SupplierOrder): Promise<void> {
    const result = await this.confirmation.ask({
      title: 'Place supplier order',
      message: `Place ${item.orderNumber} for ${item.totalAmount.toFixed(2)}? The warehouse can receive it after this step.`,
      confirmLabel: 'Place order',
      tone: 'warning'
    });
    if (!result.confirmed) return;
    this.run(
      this.operational.approveSupplierOrder(
        item.supplierOrderId,
        item.rowVersion),
      'Supplier order placed.',
      () => this.load());
  }

  /**
   * Reviewer note: Coordinates the cancel order interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async cancelOrder(item: SupplierOrder): Promise<void> {
    const result = await this.confirmation.ask({
      title: 'Cancel supplier order',
      message: `Cancel ${item.orderNumber}? This preserves the order history and prevents further receiving.`,
      confirmLabel: 'Cancel order',
      tone: 'danger',
      reasonLabel: 'Cancellation reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.run(
      this.operational.cancelSupplierOrder(
        item.supplierOrderId,
        item.rowVersion,
        result.reason),
      'Supplier order cancelled.',
      () => this.load());
  }

  /**
   * Reviewer note: Encapsulates the run view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private run<T>(
    request: import('rxjs').Observable<T>,
    message: string,
    next: () => void,
    onError?: (error: any) => void
  ): void {
    this.loading = true;
    request.pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: () => {
        this.notifications.success(message);
        next();
      },
      error: error => onError
        ? onError(error)
        : this.notifications.error(
            error?.error?.message || 'The operation could not be completed.')
    });
  }

  /**
   * Reviewer note: Coordinates the create order line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private createOrderLine(): FormGroup {
    return this.fb.nonNullable.group({
      rawStockItemId: [0, Validators.min(1)],
      orderedQuantity: [0, Validators.min(0.001)],
      expectedUnitPrice: [0, Validators.min(0)],
      unitOfMeasure: ['kg', Validators.required],
      notes: ['']
    });
  }

  /**
   * Reviewer note: Coordinates the reset order form interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private resetOrderForm(): void {
    this.selectedOrder = null;
    this.orderForm.reset({
      supplierId: 0,
      warehouseSectionId: 0,
      expectedDeliveryAtUtc: '',
      notes: ''
    });

    this.orderLines.clear();
    this.orderLines.push(this.createOrderLine());
  }
}
