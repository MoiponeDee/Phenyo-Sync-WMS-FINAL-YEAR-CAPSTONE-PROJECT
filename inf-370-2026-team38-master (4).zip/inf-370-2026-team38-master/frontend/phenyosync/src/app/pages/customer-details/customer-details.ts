/**
 * Reviewer guide: Coordinates the customer details page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { finalize, take } from 'rxjs';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';
import { AuthorizationService } from '../../services/authorization';
import { NotificationService } from '../../services/notification';
import {
  CustomerSummary,
  OperationalSectionsService
} from '../../services/operational-sections';

@Component({
  selector: 'app-customer-details',
  standalone: true,
  imports: [CommonModule, RouterLink, TopbarComponent, SidebarComponent],
  templateUrl: './customer-details.html',
  styleUrl: './customer-details.css'
})
/** Displays customer master data and related order history from API projections. */
export class CustomerDetails implements OnInit {
  customer: CustomerSummary | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = true;

  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Customers', route: '/customers' },
    { name: 'Sales Orders', route: '/order-management' },
    { name: 'Customer Payments', route: '/payments' }
  ];

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly route: ActivatedRoute,
    private readonly operational: OperationalSectionsService,
    private readonly notifications: NotificationService,
    private readonly changeDetector: ChangeDetectorRef,
    readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!Number.isInteger(id) || id <= 0) {
      this.loading = false;
      this.notifications.error('The customer reference is invalid.');
      return;
    }

    this.operational.customer(id).pipe(
      take(1),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: customer => this.customer = customer,
      error: error => this.notifications.error(
        error?.error?.message || 'The customer could not be loaded.')
    });
  }
}
