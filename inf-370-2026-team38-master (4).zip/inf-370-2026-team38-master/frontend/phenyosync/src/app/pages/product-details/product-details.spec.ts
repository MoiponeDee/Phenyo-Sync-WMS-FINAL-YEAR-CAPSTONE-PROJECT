/**
 * Reviewer guide: Verifies the product details frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { ProductResponse, ProductService } from '../../services/product';
import { ProductDetails } from './product-details';

// Covers the product details behavior most likely to regress across permissions and workflow changes.
describe('ProductDetails', () => {
  // Reviewer note: Guards the observable rule that loads master details using only Products.View-compatible API data.
  it('loads master details using only Products.View-compatible API data', () => {
    const product = {
      productId: 12,
      productName: 'Granny Smith Apples',
      productTypeId: 2,
      productTypeName: 'Packed Produce',
      productCategoryId: 1,
      productCategoryName: 'Fruit',
      size: '3 KG',
      shelfLifeDays: 10,
      sellingPricePerKg: 42,
      qrCodeValue: 'APPLE-GS-3KG',
      status: 'Active',
      createdAt: '2026-09-05T08:00:00Z',
      totalAvailableQuantityKg: 0,
      alertLevel: 'Normal',
      canDelete: false,
      isCommitted: true,
      canDeactivate: true
    } as ProductResponse;
    let requestedId = 0;
    const component = new ProductDetails(
      {
        snapshot: {
          paramMap: { get: () => '12' }
        }
      } as unknown as ActivatedRoute,
      {
        getProductById: (id: number) => {
          requestedId = id;
          return of(product);
        }
      } as ProductService,
      {} as Location
    );

    component.ngOnInit();

    expect(requestedId).toBe(12);
    expect(component.product).toBe(product);
    expect(component.loading).toBe(false);
    expect(component.errorMessage).toBe('');
  });
});
