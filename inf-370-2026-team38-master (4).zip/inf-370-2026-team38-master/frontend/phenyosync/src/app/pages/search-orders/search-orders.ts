/**
 * Reviewer guide: Coordinates the search orders page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { OrderSearchFilters, OrderService, PagedOrders, SalesOrderSummary } from '../../services/order';
import { AuthorizationService } from '../../services/authorization';
import { HumanizeCodePipe } from '../../pipes/humanize-code.pipe';

@Component({
  selector: 'app-search-orders', standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    TopbarComponent,
    SearchFieldComponent,
    HumanizeCodePipe
  ],
  templateUrl: './search-orders.html'
})
/** Provides filterable order discovery and links into the authoritative detail workflow. */
export class SearchOrders implements OnInit {
  result: PagedOrders = { items: [], page: 1, pageSize: 20, totalCount: 0, totalPages: 0 };
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  filters: OrderSearchFilters = { page: 1, pageSize: 20 };
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  readonly statuses = ['', 'Submitted', 'Approved', 'Confirmed', 'Packing', 'Packed', 'ReadyForDispatch', 'OutForDelivery', 'Delivered', 'Rejected', 'Cancelled'];

  statusLabel(status: string): string {
    return status === 'Submitted' || status === 'PendingValidation'
      ? 'Pending Validation'
      : status;
  }

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private orders: OrderService,
    private router: Router,
    readonly authorization: AuthorizationService,
    private changeDetector: ChangeDetectorRef
  ) {}
  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void { this.search(); }
  /**
   * Reviewer note: Coordinates search so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  search(page = 1): void {
    this.loading = true; this.errorMessage = ''; this.filters.page = page;
    this.orders.search(this.filters).pipe(take(1), finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: result => this.result = result,
      error: error => this.errorMessage = error instanceof HttpErrorResponse ? error.error?.message || 'Unable to search orders.' : 'Unable to search orders.'
    });
  }
  /**
   * Reviewer note: Encapsulates the clear view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clear(): void { this.filters = { page: 1, pageSize: 20 }; this.search(); }
  /**
   * Reviewer note: Coordinates open so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  open(order: SalesOrderSummary): void { this.router.navigate(['/order-details', order.salesOrderId]); }
  /**
   * Reviewer note: Encapsulates the review view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  review(order: SalesOrderSummary): void {
    if (!this.canReview(order)) return;
    this.router.navigate(['/order-details', order.salesOrderId], {
      queryParams: { returnUrl: '/search-orders' }
    });
  }
  /**
   * Reviewer note: Coordinates the update interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  update(order: SalesOrderSummary): void {
    if (this.canUpdate(order)) {
      this.router.navigate(['/update-order', order.salesOrderId]);
    }
  }
  /**
   * Reviewer note: Encapsulates the invoice view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  invoice(order: SalesOrderSummary): void {
    if (this.canInvoice(order)) {
      this.router.navigate(['/order-invoice', order.salesOrderId]);
    }
  }
  /**
   * Reviewer note: Encapsulates the packing view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  packing(order: SalesOrderSummary): void {
    if (this.canViewPacking(order)) {
      this.router.navigate(['/pack-customer-order', order.salesOrderId]);
    }
  }
  /**
   * Reviewer note: Calculates can review for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canReview(order: SalesOrderSummary): boolean {
    return order.canValidate &&
      this.authorization.has('Orders.Validate') &&
      this.authorization.has('Orders.Confirm') &&
      order.status === 'Submitted';
  }

  /**
   * Reviewer note: Calculates can update for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canUpdate(order: SalesOrderSummary): boolean {
    return order.canUpdate &&
      this.authorization.has('Orders.Update') &&
      !this.isFinalManagementRole();
  }

  /**
   * Reviewer note: Calculates can invoice for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canInvoice(order: SalesOrderSummary): boolean {
    return order.hasInvoice &&
      this.roleCode === 'OperationsManager' &&
      this.authorization.has('Invoices.View');
  }

  /**
   * Reviewer note: Calculates can view packing for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canViewPacking(order: SalesOrderSummary): boolean {
    return order.canViewPackingList &&
      this.roleCode === 'Packer' &&
      this.authorization.has('Packing.View');
  }

  /**
   * Reviewer note: Calculates is final management role for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  private isFinalManagementRole(): boolean {
    return ['Admin', 'OperationsManager', 'WarehouseManager']
      .includes(this.roleCode);
  }

  /**
   * Reviewer note: Encapsulates the role code view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private get roleCode(): string {
    return this.authorization.session()?.roleCode ?? '';
  }
}
