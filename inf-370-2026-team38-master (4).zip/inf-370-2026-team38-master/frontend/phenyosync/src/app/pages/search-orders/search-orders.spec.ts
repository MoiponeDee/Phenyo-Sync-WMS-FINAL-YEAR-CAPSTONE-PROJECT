/**
 * Reviewer guide: Verifies the search orders frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { AuthorizationService } from '../../services/authorization';
import { OrderService, SalesOrderSummary } from '../../services/order';
import { SearchOrders } from './search-orders';

// Covers the search orders behavior most likely to regress across permissions and workflow changes.
describe('SearchOrders final role actions', () => {
  const order = {
    salesOrderId: 12,
    status: 'Submitted',
    canValidate: true,
    canUpdate: true,
    hasInvoice: true,
    canViewPackingList: true
  } as SalesOrderSummary;

  function component(roleCode: string, permissions: string[]): SearchOrders {
    const allowed = new Set(permissions);
    const authorization = {
      session: () => ({ roleCode }),
      has: (permission: string) => allowed.has(permission)
    } as unknown as AuthorizationService;

    return new SearchOrders(
      {} as OrderService,
      {} as Router,
      authorization,
      {} as ChangeDetectorRef
    );
  }

  // Reviewer note: Guards the observable rule that limits Warehouse Manager results to Details.
  it('limits Warehouse Manager results to Details', () => {
    const page = component('WarehouseManager', [
      'Orders.Update',
      'Invoices.View',
      'Packing.View'
    ]);

    expect(page.canUpdate(order)).toBe(false);
    expect(page.canInvoice(order)).toBe(false);
    expect(page.canViewPacking(order)).toBe(false);
    expect(page.canReview(order)).toBe(false);
  });

  // Reviewer note: Guards the observable rule that allows Operations Manager to open an available invoice only.
  it('allows Operations Manager to open an available invoice only', () => {
    const page = component('OperationsManager', [
      'Orders.Update',
      'Invoices.View',
      'Packing.View'
    ]);

    expect(page.canInvoice(order)).toBe(true);
    expect(page.canUpdate(order)).toBe(false);
    expect(page.canViewPacking(order)).toBe(false);
    expect(page.canReview(order)).toBe(false);
  });

  // Reviewer note: Guards the observable rule that shows eligible commercial validation to Super Admin.
  it('shows eligible commercial validation to Super Admin', () => {
    const page = component('Admin', [
      'Orders.Update',
      'Orders.Validate',
      'Orders.Confirm',
      'Invoices.View'
    ]);

    expect(page.canReview(order)).toBe(true);
    expect(page.canUpdate(order)).toBe(false);
    expect(page.canInvoice(order)).toBe(false);
  });

  // Reviewer note: Guards the observable rule that keeps Packing navigation available to Packer.
  it('keeps Packing navigation available to Packer', () => {
    const page = component('Packer', ['Packing.View']);

    expect(page.canViewPacking(order)).toBe(true);
  });
});
