/**
 * Reviewer guide: Coordinates the send order link page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { finalize, forkJoin, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { AuthorizationService } from '../../services/authorization';
import {
  CustomerSummary,
  OperationalSectionsService
} from '../../services/operational-sections';
import {
  CustomerOrderIntakeConfiguration,
  OrderService
} from '../../services/order';

@Component({
  selector: 'app-send-order-link',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, TopbarComponent],
  templateUrl: './send-order-link.html'
})
/** Requests an expiring customer order link; raw tokens are never persisted in the browser. */
export class SendOrderLink implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  customers: CustomerSummary[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedCustomerId: number | null = null;
  configuration: CustomerOrderIntakeConfiguration | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  message = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly customersApi: OperationalSectionsService,
    private readonly orders: OrderService,
    private readonly changeDetector: ChangeDetectorRef,
    readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      customers: this.customersApi.customers('', false),
      configuration: this.orders.getCustomerIntakeConfiguration()
    }).pipe(
      take(1),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.customers = result.customers;
        this.configuration = result.configuration;
      },
      error: error => this.fail(error)
    });
  }

  /**
   * Reviewer note: Coordinates open form so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openForm(): void {
    const url = this.formUrl();
    if (!url) return;
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  /**
   * Reviewer note: Encapsulates the copy link view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  async copyLink(): Promise<void> {
    const url = this.formUrl();
    if (!url) return;

    try {
      await navigator.clipboard.writeText(url);
      this.message = 'Customer request form link copied.';
      this.errorMessage = '';
    } catch {
      this.errorMessage =
        'The browser could not copy the link. Open the form and copy its address manually.';
    }
  }

  /**
   * Reviewer note: Encapsulates the share on whats app view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  shareOnWhatsApp(): void {
    const url = this.formUrl();
    if (!url) return;

    const customer = this.customers.find(
      item => item.customerId === this.selectedCustomerId
    );
    const greeting = customer
      ? `Hello ${customer.customerName}, `
      : 'Hello, ';
    const text = `${greeting}please use this form to send your order request to PhenyoSync WMS. Our staff will verify availability and capture the official order: ${url}`;
    window.open(
      `https://wa.me/?text=${encodeURIComponent(text)}`,
      '_blank',
      'noopener,noreferrer'
    );
  }

  /**
   * Reviewer note: Encapsulates the form url view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private formUrl(): string | null {
    if (this.configuration?.isConfigured && this.configuration.googleFormUrl) {
      return this.configuration.googleFormUrl;
    }

    this.message = '';
    this.errorMessage =
      'The customer request form is not configured. A Super Admin must add a genuine Google Forms URL in System Settings.';
    return null;
  }

  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown): void {
    this.errorMessage = error instanceof HttpErrorResponse
      ? error.error?.message || 'The customer request form could not be loaded.'
      : 'The customer request form could not be loaded.';
  }
}
