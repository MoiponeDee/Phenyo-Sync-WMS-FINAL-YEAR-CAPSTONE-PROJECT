/**
 * Reviewer guide: Coordinates the buying lists page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, forkJoin } from 'rxjs';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { AuthorizationService } from '../../services/authorization';
import {
  BuyingListDetail,
  BuyingListInput,
  BuyingListLine,
  BuyingListLineInput,
  BuyingListOptions,
  BuyingListService,
  BuyingListSummary,
  ProcurementShortageSuggestion,
  UnmappedProductDemand
} from '../../services/buying-lists';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';

interface HeaderDraft {
  buyingDateUtc: string;
  title: string;
  priority: string;
  notes: string;
}

interface LineDraft {
  rawStockItemId: number;
  recommendedQuantity: number;
  requiredQuantity: number;
  unitOfMeasure: string;
  priority: string;
  preferredSupplierId?: number;
  managementNotes: string;
  // Reviewer note: Carries the server concurrency token back on mutation so stale screens cannot overwrite newer data.
  // Conflict detection is performed by the API and database, not by this component.
  rowVersion?: string;
}

@Component({
  selector: 'app-buying-lists',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    TopbarComponent,
    SidebarComponent,
    SearchFieldComponent
  ],
  templateUrl: './buying-lists.html',
  styleUrl: './buying-lists.css'
})
/** Manages draft Buying Lists through assignment/publication without duplicating lifecycle rules. */
export class BuyingListsComponent implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Buying Lists', route: '/buying-lists', active: true },
    { name: 'Raw Stock Control', route: '/raw-stock', permissions: ['RawStock.View'] },
    { name: 'Suppliers', route: '/suppliers', permissions: ['Suppliers.View'] },
    { name: 'Management Overview', route: '/management-dashboard' },
    { name: 'Audit Trail', route: '/audit-logs', permissions: ['AuditLogs.View'] }
  ];

  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  options?: BuyingListOptions;
  suggestions: ProcurementShortageSuggestion[] = [];
  // Reviewer note: Retains a disposable browser or device resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  unmappedDemand: UnmappedProductDemand[] = [];
  lists: BuyingListSummary[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selected?: BuyingListDetail;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loadingDetail = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  total = 0;
  page = 1;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  pageSize = 20;
  showCreate = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  createError = '';
  editingLineId?: number;

  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  filters = {
    search: '',
    status: '',
    assignedBuyerUserId: 0,
    fromDateUtc: '',
    toDateUtc: ''
  };

  createDraft: HeaderDraft & {
    assignedBuyerUserId: number;
    items: LineDraft[];
  } = {
    buyingDateUtc: this.dateValue(new Date()),
    title: '',
    priority: 'Standard',
    notes: '',
    assignedBuyerUserId: 0,
    items: []
  };

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  headerDraft: HeaderDraft = {
    buyingDateUtc: '',
    title: '',
    priority: 'Standard',
    notes: ''
  };

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  lineDraft = this.blankLine();
  assignedBuyerUserId = 0;

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly buyingLists: BuyingListService,
    private readonly notifications: NotificationService,
    private readonly confirmation: ConfirmationService,
    readonly authorization: AuthorizationService,
    private readonly changeDetector: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Calculates can for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  can(permission: string): boolean {
    return this.authorization.has(permission);
  }

  /**
   * Reviewer note: Coordinates open list count so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openListCount(): number {
    return this.lists.filter(item =>
      item.status !== 'Completed' && item.status !== 'Cancelled'
    ).length;
  }

  /**
   * Reviewer note: Encapsulates the total pages view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  totalPages(): number {
    return Math.max(1, Math.ceil(this.total / this.pageSize));
  }

  /**
   * Reviewer note: Encapsulates the raw stock name view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  rawStockName(rawStockItemId: number): string {
    const item = this.options?.rawStockItems.find(candidate =>
      candidate.rawStockItemId === Number(rawStockItemId));
    return item
      ? `${item.itemCode} · ${item.itemName}`
      : `Raw Stock item ${rawStockItemId}`;
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.errorMessage = '';
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      result: this.buyingLists.search({
        search: this.filters.search,
        status: this.filters.status,
        assignedBuyerUserId:
          this.filters.assignedBuyerUserId || undefined,
        fromDateUtc: this.filters.fromDateUtc
          ? new Date(`${this.filters.fromDateUtc}T00:00:00`).toISOString()
          : undefined,
        toDateUtc: this.filters.toDateUtc
          ? new Date(`${this.filters.toDateUtc}T23:59:59`).toISOString()
          : undefined,
        page: this.page,
        pageSize: this.pageSize
      }),
      options: this.buyingLists.options(),
      suggestions: this.buyingLists.shortageSuggestions(),
      unmappedDemand: this.buyingLists.unmappedDemand()
    }).pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: ({ result, options, suggestions, unmappedDemand }) => {
        this.lists = result.items;
        this.total = result.total;
        this.options = options;
        this.suggestions = suggestions;
        this.unmappedDemand = unmappedDemand;
        if (this.selected) {
          const stillVisible = this.lists.some(item =>
            item.buyerProcurementId === this.selected?.buyerProcurementId);
          if (!stillVisible) this.selected = undefined;
        }
      },
      error: error => this.errorMessage =
        error.error?.message ?? 'Buying Lists could not be loaded.'
    });
  }

  /**
   * Reviewer note: Encapsulates the clear filters view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearFilters(): void {
    this.filters = {
      search: '',
      status: '',
      assignedBuyerUserId: 0,
      fromDateUtc: '',
      toDateUtc: ''
    };
    this.page = 1;
    this.load();
  }

  /**
   * Reviewer note: Coordinates open so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  open(list: BuyingListSummary): void {
    this.loadingDetail = true;
    this.errorMessage = '';
    this.buyingLists.get(list.buyerProcurementId).pipe(
      finalize(() => {
        this.loadingDetail = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: value => this.setSelected(value),
      error: error => this.errorMessage =
        error.error?.message ?? 'The Buying List could not be opened.'
    });
  }

  /**
   * Reviewer note: Coordinates open create so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openCreate(): void {
    this.showCreate = true;
    this.createError = '';
    this.createDraft = {
      buyingDateUtc: this.dateValue(new Date()),
      title: '',
      priority: 'Standard',
      notes: '',
      assignedBuyerUserId: 0,
      items: []
    };
    this.lineDraft = this.blankLine();
  }

  /**
   * Reviewer note: Coordinates the add create line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  addCreateLine(): void {
    const input = this.normalizedLine(this.lineDraft);
    if (!this.validLine(input, true)) {
      this.focusFirstInvalid('.create-modal .modal-line-builder');
      return;
    }
    const duplicate = this.createDraft.items.some(item =>
      item.rawStockItemId === input.rawStockItemId);
    if (duplicate) {
      this.createError = 'That Raw Stock item is already in this draft.';
      return;
    }
    this.createDraft.items.push({ ...this.lineDraft });
    this.lineDraft = this.blankLine();
  }

  /**
   * Reviewer note: Coordinates the remove create line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  removeCreateLine(index: number): void {
    this.createDraft.items.splice(index, 1);
  }

  /**
   * Reviewer note: Coordinates the add suggestion interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  addSuggestion(suggestion: ProcurementShortageSuggestion): void {
    // A suggestion pre-fills a draft only; management still reviews quantity and supplier before creation.
    if (this.createDraft.items.some(item =>
      item.rawStockItemId === suggestion.rawStockItemId)) {
      return;
    }
    this.createDraft.items.push({
      rawStockItemId: suggestion.rawStockItemId,
      recommendedQuantity: suggestion.suggestedPurchaseQuantity,
      requiredQuantity: suggestion.suggestedPurchaseQuantity,
      unitOfMeasure: suggestion.unitOfMeasure,
      priority: 'Standard',
      managementNotes:
        'Suggested from active customer demand, available stock and open procurement commitments.'
    });
  }

  /**
   * Reviewer note: Coordinates the add all suggestions interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  addAllSuggestions(): void {
    for (const suggestion of this.suggestions) {
      this.addSuggestion(suggestion);
    }
  }

  /**
   * Reviewer note: Encapsulates the suggestion added view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  suggestionAdded(suggestion: ProcurementShortageSuggestion): boolean {
    return this.createDraft.items.some(item =>
      item.rawStockItemId === suggestion.rawStockItemId);
  }

  /**
   * Reviewer note: Coordinates the create interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  create(): void {
    // Send one aggregate request so the API can validate header and lines before persisting either.
    this.createError = '';
    if (!this.createDraft.buyingDateUtc || !this.createDraft.priority) {
      this.createError = 'Enter a Buying date and select a priority.';
      this.focusFirstInvalid('.create-modal');
      return;
    }
    if (!this.createDraft.items.length) {
      this.createError = 'Add at least one required item.';
      this.focusFirstInvalid('.create-modal .modal-line-builder');
      return;
    }
    const request: BuyingListInput = {
      buyingDateUtc:
        new Date(`${this.createDraft.buyingDateUtc}T12:00:00`).toISOString(),
      title: this.createDraft.title.trim() || undefined,
      priority: this.createDraft.priority,
      notes: this.createDraft.notes.trim() || undefined,
      assignedBuyerUserId:
        this.createDraft.assignedBuyerUserId || undefined,
      items: this.createDraft.items.map(item => this.normalizedLine(item))
    };
    this.runSave(
      this.buyingLists.create(request),
      'Buying List draft created.',
      value => {
        this.showCreate = false;
        this.setSelected(value);
        this.load();
      },
      true
    );
  }

  /**
   * Reviewer note: Coordinates the save header interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveHeader(): void {
    if (!this.selected) return;
    if (!this.headerDraft.buyingDateUtc || !this.headerDraft.priority) {
      this.notifications.warning('Enter a Buying date and select a priority.');
      this.focusFirstInvalid('.editable-section');
      return;
    }
    this.runSave(
      this.buyingLists.updateHeader(
        this.selected.buyerProcurementId,
        {
          buyingDateUtc:
            new Date(`${this.headerDraft.buyingDateUtc}T12:00:00`)
              .toISOString(),
          title: this.headerDraft.title.trim() || undefined,
          priority: this.headerDraft.priority,
          notes: this.headerDraft.notes.trim() || undefined,
          rowVersion: this.selected.rowVersion
        }
      ),
      'Buying List header saved.'
    );
  }

  /**
   * Reviewer note: Coordinates the start add line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  startAddLine(): void {
    this.editingLineId = 0;
    this.lineDraft = this.blankLine();
  }

  /**
   * Reviewer note: Coordinates the start edit line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  startEditLine(line: BuyingListLine): void {
    this.editingLineId = line.buyerProcurementItemId;
    this.lineDraft = {
      rawStockItemId: line.rawStockItemId ?? 0,
      recommendedQuantity: line.recommendedQuantity,
      requiredQuantity: line.requiredQuantity,
      unitOfMeasure: line.unitOfMeasure,
      priority: line.priority,
      preferredSupplierId: line.preferredSupplierId,
      managementNotes: line.managementNotes ?? '',
      rowVersion: line.rowVersion
    };
  }

  /**
   * Reviewer note: Coordinates the save line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveLine(): void {
    if (!this.selected || this.editingLineId === undefined) return;
    const request = this.normalizedLine(this.lineDraft);
    if (!this.validLine(request)) {
      this.focusFirstInvalid('.line-editor');
      return;
    }
    const call = this.editingLineId === 0
      ? this.buyingLists.addLine(
          this.selected.buyerProcurementId,
          request
        )
      : this.buyingLists.updateLine(
          this.selected.buyerProcurementId,
          this.editingLineId,
          request
        );
    this.runSave(call, 'Required item saved.', () => {
      this.editingLineId = undefined;
      this.lineDraft = this.blankLine();
    });
  }

  /**
   * Reviewer note: Coordinates the remove line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async removeLine(line: BuyingListLine): Promise<void> {
    if (!this.selected) return;
    const result = await this.confirmation.ask({
      title: 'Remove required item?',
      message:
        `${line.itemName} will be removed from this draft Buying List.`,
      confirmLabel: 'Remove item',
      tone: 'danger',
      reasonLabel: 'Reason for removal',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.runSave(
      this.buyingLists.removeLine(
        this.selected.buyerProcurementId,
        line.buyerProcurementItemId,
        this.selected.rowVersion,
        result.reason
      ),
      'Required item removed.'
    );
  }

  /**
   * Reviewer note: Coordinates the assign interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async assign(): Promise<void> {
    if (!this.selected || !this.assignedBuyerUserId) {
      this.notifications.warning('Select an eligible Market Buyer.');
      return;
    }
    const result = await this.confirmation.ask({
      title: 'Assign Buying List?',
      message: 'The selected user will own this market buying task.',
      confirmLabel: 'Assign buyer',
      reasonLabel: 'Assignment reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.runSave(
      this.buyingLists.assign(
        this.selected.buyerProcurementId,
        this.assignedBuyerUserId,
        this.selected.rowVersion,
        result.reason
      ),
      'Market Buyer assigned.'
    );
  }

  /**
   * Reviewer note: Coordinates the publish interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async publish(): Promise<void> {
    if (!this.selected) return;
    const result = await this.confirmation.ask({
      title: 'Publish Buying List?',
      message:
        'Required quantities become read-only and the assigned buyer will ' +
        'receive the task.',
      confirmLabel: 'Publish list',
      tone: 'warning',
      reasonLabel: 'Publication note',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.runSave(
      this.buyingLists.publish(
        this.selected.buyerProcurementId,
        this.selected.rowVersion,
        result.reason
      ),
      'Buying List published.'
    );
  }

  /**
   * Reviewer note: Coordinates the cancel interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async cancel(): Promise<void> {
    if (!this.selected) return;
    const result = await this.confirmation.ask({
      title: 'Cancel Buying List?',
      message:
        'No further purchasing or receiving will be allowed. History is kept.',
      confirmLabel: 'Cancel list',
      tone: 'danger',
      reasonLabel: 'Cancellation reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.runSave(
      this.buyingLists.cancel(
        this.selected.buyerProcurementId,
        this.selected.rowVersion,
        result.reason
      ),
      'Buying List cancelled.'
    );
  }

  /**
   * Reviewer note: Coordinates select raw stock so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectRawStock(draft: LineDraft): void {
    const selected = this.options?.rawStockItems.find(item =>
      item.rawStockItemId === Number(draft.rawStockItemId));
    if (selected) draft.unitOfMeasure = selected.unitOfMeasure;
  }

  /**
   * Reviewer note: Encapsulates the run save view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private runSave(
    request: ReturnType<BuyingListService['get']>,
    successMessage: string,
    after?: (value: BuyingListDetail) => void,
    showErrorInCreateModal = false
  ): void {
    this.saving = true;
    this.errorMessage = '';
    request.pipe(finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: value => {
        this.setSelected(value);
        this.notifications.success(successMessage);
        after?.(value);
        this.refreshSummary(value);
      },
      error: error => {
        const message = error.error?.message ??
          'The Buying List change could not be saved.';
        if (showErrorInCreateModal) {
          this.createError = message;
        } else {
          this.errorMessage = message;
          this.notifications.error(message);
        }
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the set selected view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private setSelected(value: BuyingListDetail): void {
    this.selected = value;
    this.headerDraft = {
      buyingDateUtc: this.dateValue(new Date(value.buyingDateUtc)),
      title: value.title ?? '',
      priority: value.priority,
      notes: value.notes ?? ''
    };
    this.assignedBuyerUserId = value.assignedBuyerUserId ?? 0;
  }

  /**
   * Reviewer note: Coordinates refresh summary so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private refreshSummary(value: BuyingListDetail): void {
    const index = this.lists.findIndex(item =>
      item.buyerProcurementId === value.buyerProcurementId);
    if (index >= 0) this.lists[index] = value;
  }

  /**
   * Reviewer note: Encapsulates the valid line view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private validLine(
    request: BuyingListLineInput,
    showErrorInCreateModal = false
  ): boolean {
    if (
      !request.rawStockItemId ||
      request.requiredQuantity <= 0 ||
      !request.unitOfMeasure.trim() ||
      !request.priority
    ) {
      const message =
        'Select Raw Stock, enter a required quantity greater than zero, and provide its unit and priority.';
      if (showErrorInCreateModal) {
        this.createError = message;
      } else {
        this.notifications.warning(message);
      }
      return false;
    }
    return true;
  }

  /**
   * Reviewer note: Encapsulates the normalized line view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private normalizedLine(draft: LineDraft): BuyingListLineInput {
    return {
      rawStockItemId: Number(draft.rawStockItemId),
      recommendedQuantity: Number(draft.recommendedQuantity) || 0,
      requiredQuantity: Number(draft.requiredQuantity) || 0,
      unitOfMeasure: draft.unitOfMeasure.trim(),
      priority: draft.priority,
      preferredSupplierId:
        draft.preferredSupplierId
          ? Number(draft.preferredSupplierId)
          : undefined,
      managementNotes: draft.managementNotes.trim() || undefined,
      rowVersion: draft.rowVersion
    };
  }

  /** Moves keyboard focus to the first browser-invalid field in the active editor. */
  private focusFirstInvalid(scope: string): void {
    setTimeout(() => {
      const element = document.querySelector<HTMLElement>(
        `${scope} [required]:invalid`
      );
      element?.focus();
    });
  }

  /**
   * Reviewer note: Encapsulates the blank line view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private blankLine(): LineDraft {
    return {
      rawStockItemId: 0,
      recommendedQuantity: 0,
      requiredQuantity: 0,
      unitOfMeasure: 'kg',
      priority: 'Standard',
      managementNotes: ''
    };
  }

  /**
   * Reviewer note: Encapsulates the date value view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private dateValue(value: Date): string {
    return value.toISOString().slice(0, 10);
  }
}
