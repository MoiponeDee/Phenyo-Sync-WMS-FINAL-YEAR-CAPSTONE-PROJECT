import { of } from 'rxjs';
import { BuyingListsComponent } from './buying-lists';

describe('BuyingListsComponent runtime change detection', () => {
  it('renders the completed Buying List load in the zoneless application', () => {
    const buyingLists = {
      search: () => of({ items: [{ buyerProcurementId: 7 }], total: 1 }),
      options: () => of({ statuses: [], priorities: [], buyers: [], rawStockItems: [], suppliers: [] }),
      shortageSuggestions: () => of([]),
      unmappedDemand: () => of([])
    };
    const changeDetector = { detectChanges: vi.fn() };
    const component = new BuyingListsComponent(
      buyingLists as never,
      {} as never,
      {} as never,
      { has: () => true } as never,
      changeDetector as never
    );

    component.load();

    expect(component.loading).toBe(false);
    expect(component.total).toBe(1);
    expect(component.lists).toHaveLength(1);
    expect(changeDetector.detectChanges).toHaveBeenCalledOnce();
  });
});
