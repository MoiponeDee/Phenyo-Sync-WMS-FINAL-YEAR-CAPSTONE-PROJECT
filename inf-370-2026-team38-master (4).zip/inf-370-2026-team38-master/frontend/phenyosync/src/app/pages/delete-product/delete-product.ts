/**
 * Reviewer guide: Coordinates the delete product page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { finalize, take } from 'rxjs';
import { ProductResponse, ProductService } from '../../services/product';

@Component({
  selector: 'app-delete-product',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './delete-product.html',
  styleUrl: './delete-product.css'
})
/** Requests a controlled product deletion and surfaces relationship conflicts from the API. */
export class DeleteProduct implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  products: ProductResponse[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  filteredProducts: ProductResponse[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  searchTerm = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  deleting = false;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selected: ProductResponse | null = null;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  canDeactivate = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private productService: ProductService,
    private changeDetector: ChangeDetectorRef,
    private router: Router
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void { this.loadProducts(); }

  /**
   * Reviewer note: Coordinates load products so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadProducts(): void {
    this.loading = true;
    this.productService.getProducts().pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: products => {
        this.products = products;
        this.applySearch();
      },
      error: error => this.showError(error, 'Unable to load products.')
    });
  }

  /**
   * Reviewer note: Encapsulates the apply search view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  applySearch(): void {
    const term = this.searchTerm.trim().toLowerCase();
    this.filteredProducts = this.products.filter(product => !term ||
      product.productName.toLowerCase().includes(term) ||
      product.size.toLowerCase().includes(term) ||
      (product.qrCodeValue ?? '').toLowerCase().includes(term));
  }

  /**
   * Reviewer note: Coordinates open delete so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openDelete(product: ProductResponse): void {
    this.selected = product;
    this.canDeactivate = !product.canDelete && product.canDeactivate;
    this.errorMessage = '';
    this.successMessage = '';
  }

  /**
   * Reviewer note: Encapsulates the close modal view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  closeModal(): void {
    if (!this.deleting) this.selected = null;
  }

  /**
   * Reviewer note: Encapsulates the confirm delete view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  confirmDelete(): void {
    if (!this.selected || this.deleting) return;
    const product = this.selected;
    this.deleting = true;
    this.productService.deleteProduct(product.productId).pipe(
      take(1),
      finalize(() => {
        this.deleting = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.products = this.products.filter(item => item.productId !== product.productId);
        this.applySearch();
        this.selected = null;
        this.successMessage = response.message;
      },
      error: (error: HttpErrorResponse) => {
        this.canDeactivate = error.status === 409 && error.error?.canDeactivate === true;
        this.showError(error, 'Unable to delete this product.');
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the deactivate instead view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  deactivateInstead(): void {
    if (!this.selected || this.deleting) return;
    const product = this.selected;
    this.deleting = true;
    this.productService.changeProductStatus(product.productId, 'Inactive').pipe(
      finalize(() => {
        this.deleting = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        product.status = 'Inactive';
        this.selected = null;
        this.successMessage = `${response.message} Inventory history was preserved.`;
      },
      error: error => this.showError(error, 'Unable to deactivate this product.')
    });
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void { this.router.navigate(['/dashboard']); }

  /**
   * Reviewer note: Calculates show error for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  private showError(error: unknown, fallback: string): void {
    console.error('Delete product error:', error);
    this.errorMessage = error instanceof HttpErrorResponse ? error.error?.message || fallback : fallback;
  }
}
