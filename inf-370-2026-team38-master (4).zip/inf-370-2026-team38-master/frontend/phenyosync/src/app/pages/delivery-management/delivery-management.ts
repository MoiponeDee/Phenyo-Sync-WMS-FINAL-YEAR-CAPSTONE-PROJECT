/**
 * Reviewer guide: Coordinates the delivery management page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { finalize, forkJoin, take, timeout } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import {
  AvailableDriver,
  DeliveryDetail,
  DeliveryListItem,
  DeliveryService
} from '../../services/delivery';
import { OrderService, SalesOrderSummary } from '../../services/order';
import { AuthorizationService } from '../../services/authorization';

@Component({
  selector: 'app-delivery-management',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent, SidebarComponent, SearchFieldComponent],
  templateUrl: './delivery-management.html',
  styleUrl: './delivery-management.css'
})
/** Presents scheduling and assignment controls while the API enforces conflicts and transitions. */
export class DeliveryManagement implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Dashboard', route: '/admin-dashboard' },
    { name: 'Delivery Management', route: '/deliveries', active: true },
    { name: 'Order Management', route: '/order-management' },
    { name: 'Audit Logs', route: '/audit-logs' }
  ];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  deliveries: DeliveryListItem[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  packedOrders: SalesOrderSummary[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  availableDrivers: AvailableDriver[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedDelivery: DeliveryDetail | null = null;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedDriverId: number | null = null;
  assignmentNotes = '';
  reassignmentReason = '';
  unassignReason = '';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  searchTerm = '';
  status = '';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  assignedFilter = '';
  page = 1;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  pageSize = 10;
  totalCount = 0;
  totalPages = 0;
  orderId: number | null = null;
  scheduledStart = '';
  scheduledEnd = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  modalLoading = false;
  scheduling = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  showAssignmentModal = false;
  showScheduleModal = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  modalError = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private deliveriesApi: DeliveryService,
    private orders: OrderService,
    private authorization: AuthorizationService,
    private changeDetector: ChangeDetectorRef,
    private router: Router
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.search();
    if (this.canSchedule) this.loadReadyOrders();
  }

  /**
   * Reviewer note: Calculates can schedule for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canSchedule(): boolean {
    return this.authorization.has('Deliveries.AssignDriver');
  }

  /**
   * Reviewer note: Calculates can view proof for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canViewProof(): boolean {
    return this.authorization.has('Deliveries.ViewProof');
  }

  /**
   * Reviewer note: Calculates can manage assignment for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  canManageAssignment(delivery: DeliveryListItem): boolean {
    return delivery.canAssign && (delivery.driverId
      ? this.authorization.has('Deliveries.ReassignDriver')
      : this.authorization.has('Deliveries.AssignDriver'));
  }

  /**
   * Reviewer note: Coordinates search so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  search(resetPage = false): void {
    if (this.loading) return;
    if (resetPage) this.page = 1;
    this.loading = true;
    this.errorMessage = '';
    this.deliveriesApi.search({
      searchTerm: this.searchTerm.trim(),
      status: this.status,
      assigned: this.assignedFilter === '' ? null : this.assignedFilter === 'true',
      page: this.page,
      pageSize: this.pageSize
    }).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.deliveries = result.items;
        this.totalCount = result.totalCount;
        this.totalPages = result.totalPages;
        this.page = result.page;
      },
      error: error => this.errorMessage = this.errorText(error, 'Unable to load deliveries.')
    });
  }

  /**
   * Reviewer note: Encapsulates the clear filters view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearFilters(): void {
    this.searchTerm = '';
    this.status = '';
    this.assignedFilter = '';
    this.search(true);
  }

  /**
   * Reviewer note: Coordinates open schedule so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openSchedule(): void {
    if (!this.canSchedule) return;

    this.orderId = null;
    this.scheduledStart = '';
    this.scheduledEnd = '';
    this.modalError = '';
    this.showScheduleModal = true;
  }

  /**
   * Reviewer note: Encapsulates the schedule view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  schedule(): void {
    // The backend snapshots the order address and rejects duplicate delivery records.
    if (!this.canSchedule) return;

    if (!this.orderId || !this.scheduledStart || !this.scheduledEnd) {
      this.modalError = 'Select a packed order and provide the full scheduled window.';
      queueMicrotask(() =>
        document.querySelector<HTMLElement>('.modal [required]:invalid')?.focus());
      return;
    }
    const start = new Date(this.scheduledStart);
    const end = new Date(this.scheduledEnd);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) {
      this.modalError = 'Scheduled end must be later than the start time.';
      return;
    }
    this.scheduling = true;
    this.modalError = '';
    this.deliveriesApi.schedule({
      salesOrderId: this.orderId,
      scheduledStartUtc: start.toISOString(),
      scheduledEndUtc: end.toISOString()
    }).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.scheduling = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.successMessage = result.message;
        this.showScheduleModal = false;
        this.search(true);
        this.loadReadyOrders();
      },
      error: error => this.modalError = this.errorText(error, 'Unable to schedule delivery.')
    });
  }

  /**
   * Reviewer note: Coordinates open assignment so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openAssignment(item: DeliveryListItem): void {
    if (!this.canManageAssignment(item)) return;

    this.modalLoading = true;
    this.modalError = '';
    this.selectedDriverId = null;
    this.assignmentNotes = '';
    this.reassignmentReason = '';
    this.unassignReason = '';
    this.showAssignmentModal = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      detail: this.deliveriesApi.get(item.deliveryId),
      drivers: this.deliveriesApi.availableDrivers(item.deliveryId)
    }).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.modalLoading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.selectedDelivery = result.detail;
        this.availableDrivers = result.drivers;
      },
      error: error => this.modalError = this.errorText(error, 'Unable to load assignment details.')
    });
  }

  /**
   * Reviewer note: Coordinates the assign interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  assign(): void {
    // Availability is rechecked transactionally; this displayed driver list may become stale.
    if (!this.selectedDelivery || !this.selectedDriverId) {
      this.modalError = 'Select an available driver.';
      queueMicrotask(() => document.getElementById('availableDriver')?.focus());
      return;
    }
    if (this.selectedDelivery.driverId && this.reassignmentReason.trim().length < 5) {
      this.modalError = 'Provide a meaningful reason for replacing the current driver.';
      queueMicrotask(() => document.getElementById('reassignmentReason')?.focus());
      return;
    }
    this.saving = true;
    this.modalError = '';
    this.deliveriesApi.assignDriver(this.selectedDelivery.deliveryId, {
      driverId: this.selectedDriverId,
      assignmentNotes: this.assignmentNotes.trim() || undefined,
      reassignmentReason: this.reassignmentReason.trim() || undefined,
      rowVersion: this.selectedDelivery.rowVersion || undefined
    }).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.successMessage = result.message;
        this.showAssignmentModal = false;
        this.search();
      },
      error: error => this.modalError = this.errorText(error, 'Unable to assign driver.')
    });
  }

  /**
   * Reviewer note: Encapsulates the unassign view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  unassign(): void {
    if (!this.selectedDelivery || this.unassignReason.trim().length < 5) {
      this.modalError = 'A meaningful unassignment reason is required.';
      return;
    }
    this.saving = true;
    this.deliveriesApi.unassignDriver(
      this.selectedDelivery.deliveryId,
      this.unassignReason.trim(),
      this.selectedDelivery.rowVersion || undefined
    ).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.successMessage = result.message;
        this.showAssignmentModal = false;
        this.search();
      },
      error: error => this.modalError = this.errorText(error, 'Unable to unassign driver.')
    });
  }

  /**
   * Reviewer note: Encapsulates the proof view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  proof(item: DeliveryListItem): void {
    if (!this.canViewProof) return;

    this.router.navigate(['/deliveries', item.deliveryId, 'proof']);
  }

  /**
   * Reviewer note: Encapsulates the previous view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  previous(): void {
    if (this.page > 1 && !this.loading) {
      this.page--;
      this.search();
    }
  }

  /**
   * Reviewer note: Encapsulates the next view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  next(): void {
    if (this.page < this.totalPages && !this.loading) {
      this.page++;
      this.search();
    }
  }

  /**
   * Reviewer note: Encapsulates the close modal view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  closeModal(): void {
    if (!this.saving && !this.scheduling) {
      this.showAssignmentModal = false;
      this.showScheduleModal = false;
      this.selectedDelivery = null;
      this.modalError = '';
    }
  }

  /**
   * Reviewer note: Coordinates load ready orders so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private loadReadyOrders(): void {
    this.orders.search({ status: 'ReadyForDispatch', page: 1, pageSize: 100 }).pipe(take(1)).subscribe({
      next: result => this.packedOrders = result.items,
      error: () => this.packedOrders = []
    });
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    if (error instanceof Error && error.name === 'TimeoutError') return 'The request timed out.';
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) return 'Cannot connect to the backend API.';
      if (error.status === 401) return 'Your session has expired. Please log in again.';
      if (error.status === 403) return 'You are not authorized for this delivery action.';
      if (error.status === 409) return error.error?.message || 'The driver or delivery changed. Refresh and try again.';
      return error.error?.message || fallback;
    }
    return fallback;
  }
}
