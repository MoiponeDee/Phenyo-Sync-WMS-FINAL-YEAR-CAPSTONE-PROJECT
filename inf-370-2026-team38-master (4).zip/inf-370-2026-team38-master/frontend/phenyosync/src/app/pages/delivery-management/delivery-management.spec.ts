/**
 * Reviewer guide: Verifies the delivery management frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { DeliveryManagement } from './delivery-management';
import { environment } from '../../../environments/environment';

// Covers the delivery management behavior most likely to regress across permissions and workflow changes.
describe('DeliveryManagement', () => {
  // Reviewer note: Guards the observable rule that loads a server-paged delivery list and empty state data.
  it('loads a server-paged delivery list and empty state data', async () => {
    await TestBed.configureTestingModule({
      imports: [DeliveryManagement],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])]
    }).compileComponents();
    const fixture = TestBed.createComponent(DeliveryManagement);
    const component = fixture.componentInstance;
    const http = TestBed.inject(HttpTestingController);

    component.search();
    const request = http.expectOne(item => item.url === `${environment.apiUrl}/deliveries`);
    expect(request.request.params.get('page')).toBe('1');
    request.flush({ items: [], page: 1, pageSize: 10, totalCount: 0, totalPages: 0 });
    expect(component.deliveries).toEqual([]);
    http.verify();
  });

  // Reviewer note: Guards the observable rule that does not request the restricted scheduling feed without assignment permission.
  it('does not request the restricted scheduling feed without assignment permission', async () => {
    localStorage.clear();
    await TestBed.configureTestingModule({
      imports: [DeliveryManagement],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])]
    }).compileComponents();
    const fixture = TestBed.createComponent(DeliveryManagement);
    const component = fixture.componentInstance;
    const http = TestBed.inject(HttpTestingController);

    component.ngOnInit();
    http.expectOne(item => item.url === `${environment.apiUrl}/deliveries`).flush({
      items: [],
      page: 1,
      pageSize: 10,
      totalCount: 0,
      totalPages: 0
    });

    http.expectNone(item => item.url === `${environment.apiUrl}/orders`);
    http.verify();
  });
});
