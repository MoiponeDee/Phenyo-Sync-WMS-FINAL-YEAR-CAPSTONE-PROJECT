/**
 * Reviewer guide: Coordinates the pricing management page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { finalize, forkJoin, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import {
  PriceRecordStatus,
  PriceBasis,
  PricingService,
  ProductPrice,
  ProductPricePage
} from '../../services/pricing';
import {
  ProductCategory,
  ProductLookupService,
  ProductType
} from '../../services/product-lookups';
import { ProductResponse, ProductService } from '../../services/product';
import { AuthorizationService } from '../../services/authorization';

@Component({
  selector: 'app-pricing-management',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, TopbarComponent, SearchFieldComponent],
  templateUrl: './pricing-management.html',
  styleUrl: './pricing-management.css'
})
/** Manages effective-dated prices and refreshes the server-calculated current-price view. */
export class PricingManagement implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  products: ProductResponse[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  productTypes: ProductType[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  productCategories: ProductCategory[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  prices: ProductPrice[] = [];
  page = 1;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  pageSize = 20;
  totalCount = 0;
  totalPages = 0;

  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  searchTerm = '';
  status: PriceRecordStatus = 'Current';
  productTypeId: number | null = null;
  productCategoryId: number | null = null;
  minimumPrice: number | null = null;
  maximumPrice: number | null = null;

  createProductId: number | null = null;
  createPrice: number | null = null;
  createPriceBasis: PriceBasis = 'PerKilogram';
  createEffectiveFrom = this.localDateTime();
  createReason = '';

  updateTarget: ProductPrice | null = null;
  updatePrice: number | null = null;
  updatePriceBasis: PriceBasis = 'PerKilogram';
  updateEffectiveFrom = this.localDateTime();
  updateReason = '';

  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  historyProduct: ProductPrice | null = null;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  history: ProductPrice[] = [];

  deleteTarget: ProductPrice | null = null;
  deleteReason = '';

  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  historyLoading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private pricing: PricingService,
    private productsApi: ProductService,
    private lookups: ProductLookupService,
    private changeDetector: ChangeDetectorRef,
    private authorization: AuthorizationService,
    private route: ActivatedRoute
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.loadInitial();
  }

  /**
   * Reviewer note: Calculates can manage for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canManage(): boolean {
    return this.authorization.hasAny('Pricing.Create', 'Pricing.Manage');
  }

  /**
   * Reviewer note: Calculates can cancel for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canCancel(): boolean {
    return this.authorization.hasAny('Pricing.Cancel', 'Pricing.Manage');
  }

  /**
   * Reviewer note: Encapsulates the active products view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get activeProducts(): ProductResponse[] {
    return this.products.filter(product => product.status === 'Active');
  }

  /**
   * Reviewer note: Calculates has current price for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  hasCurrentPrice(productId: number): boolean {
    return (this.products.find(product => product.productId === productId)?.sellingPricePerKg ?? 0) > 0 ||
      this.prices.some(price =>
        price.productId === productId && price.isCurrent && !price.isDeleted);
  }

  /**
   * Reviewer note: Encapsulates the product label view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  productLabel(product: ProductResponse): string {
    return `${product.productName} · ${product.size} · ${product.productTypeName} · ${product.productCategoryName}`;
  }

  /**
   * Reviewer note: Coordinates search so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  search(resetPage = true): void {
    if (this.loading) return;
    if (resetPage) this.page = 1;
    this.loading = true;
    this.errorMessage = '';
    this.pricing.search({
      searchTerm: this.searchTerm,
      status: this.status,
      productTypeId: this.productTypeId,
      productCategoryId: this.productCategoryId,
      minimumPrice: this.minimumPrice,
      maximumPrice: this.maximumPrice,
      page: this.page,
      pageSize: this.pageSize
    }).pipe(take(1), finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: result => this.acceptPage(result),
      error: error => this.fail(error, 'Unable to search price records.')
    });
  }

  /**
   * Reviewer note: Encapsulates the clear filters view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearFilters(): void {
    this.searchTerm = '';
    this.status = 'Current';
    this.productTypeId = null;
    this.productCategoryId = null;
    this.minimumPrice = null;
    this.maximumPrice = null;
    this.search();
  }

  /**
   * Reviewer note: Encapsulates the previous page view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  previousPage(): void {
    if (this.page > 1) {
      this.page--;
      this.search(false);
    }
  }

  /**
   * Reviewer note: Encapsulates the next page view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  nextPage(): void {
    if (this.page < this.totalPages) {
      this.page++;
      this.search(false);
    }
  }

  /**
   * Reviewer note: Coordinates the create interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  create(): void {
    this.resetMessages();
    if (!this.canManage) {
      this.errorMessage = 'Only an authorised Super Admin may create prices.';
      return;
    }
    if (
      !this.createProductId ||
      this.createPrice == null ||
      this.createPrice <= 0 ||
      !this.createEffectiveFrom
    ) {
      this.errorMessage =
        'Select an active product, enter a positive price, and choose its effective date.';
      return;
    }
    if (!this.hasTwoDecimalPlaces(this.createPrice)) {
      this.errorMessage = 'Price may contain no more than two decimal places.';
      return;
    }

    this.saving = true;
    this.pricing.create(
      this.createProductId,
      this.createPrice,
      this.createPriceBasis,
      new Date(this.createEffectiveFrom).toISOString(),
      this.createReason.trim() || undefined
    ).pipe(take(1), finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: response => {
        this.successMessage = response.message;
        const product = this.products.find(
          item => item.productId === response.price.productId
        );
        if (product) {
          product.sellingPricePerKg = response.price.sellingPrice;
        }
        this.createProductId = null;
        this.createPrice = null;
        this.createPriceBasis = 'PerKilogram';
        this.createEffectiveFrom = this.localDateTime();
        this.createReason = '';
        this.search();
      },
      error: error => this.fail(error, 'Unable to create the price.')
    });
  }

  /**
   * Reviewer note: Coordinates open update so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openUpdate(price: ProductPrice): void {
    this.updateTarget = price;
    this.updatePrice = price.sellingPrice;
    this.updatePriceBasis = price.priceBasis;
    this.updateEffectiveFrom = this.localDateTime();
    this.updateReason = '';
    this.resetMessages();
  }

  /**
   * Reviewer note: Encapsulates the close update view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  closeUpdate(): void {
    if (!this.saving) this.updateTarget = null;
  }

  /**
   * Reviewer note: Coordinates the update interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  update(): void {
    this.resetMessages();
    if (
      !this.updateTarget ||
      this.updatePrice == null ||
      this.updatePrice <= 0 ||
      !this.updateEffectiveFrom
    ) {
      this.errorMessage = 'Enter a positive new price and choose its effective date.';
      return;
    }
    if (!this.hasTwoDecimalPlaces(this.updatePrice)) {
      this.errorMessage = 'Price may contain no more than two decimal places.';
      return;
    }
    this.saving = true;
    this.pricing.update(
      this.updateTarget.productPriceId,
      this.updatePrice,
      this.updatePriceBasis,
      new Date(this.updateEffectiveFrom).toISOString(),
      this.updateReason.trim() || undefined,
      this.updateTarget.rowVersion
    ).pipe(take(1), finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: response => {
        this.successMessage = response.message;
        const product = this.products.find(
          item => item.productId === response.currentPrice.productId
        );
        if (product) {
          product.sellingPricePerKg = response.currentPrice.sellingPrice;
        }
        this.updateTarget = null;
        this.search();
      },
      error: error => this.fail(error, 'Unable to update the price.')
    });
  }

  priceSuffix(price: Pick<ProductPrice, 'priceBasis'>): string {
    return price.priceBasis === 'PerSellableUnit' ? 'sellable unit' : 'kg';
  }

  /**
   * Reviewer note: Encapsulates the view history view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  viewHistory(price: ProductPrice): void {
    this.historyProduct = price;
    this.history = [];
    this.historyLoading = true;
    this.resetMessages();
    this.pricing.getHistory(price.productId).pipe(take(1), finalize(() => {
      this.historyLoading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: history => this.history = history,
      error: error => this.fail(error, 'Unable to load price history.')
    });
  }

  /**
   * Reviewer note: Coordinates open delete so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openDelete(price: ProductPrice): void {
    this.deleteTarget = price;
    this.deleteReason = '';
    this.resetMessages();
  }

  /**
   * Reviewer note: Encapsulates the close delete view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  closeDelete(): void {
    if (!this.saving) this.deleteTarget = null;
  }

  /**
   * Reviewer note: Encapsulates the soft delete view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  softDelete(): void {
    this.resetMessages();
    if (!this.deleteTarget || this.deleteReason.trim().length < 5) {
      this.errorMessage = 'Enter a deletion reason of at least 5 characters.';
      return;
    }
    this.saving = true;
    this.pricing.softDelete(
      this.deleteTarget.productPriceId,
      this.deleteReason.trim()
    ).pipe(take(1), finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: response => {
        this.successMessage = response.message;
        this.deleteTarget = null;
        this.search();
      },
      error: error => this.fail(error, 'Unable to soft delete the price.')
    });
  }

  /**
   * Reviewer note: Coordinates load initial so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private loadInitial(): void {
    this.loading = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      products: this.productsApi.getProducts(),
      types: this.lookups.getActiveProductTypes(),
      categories: this.lookups.getActiveProductCategories(),
      pricePage: this.pricing.search({ status: 'Current', page: 1, pageSize: this.pageSize })
    }).pipe(take(1), finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: result => {
        this.products = result.products.sort((a, b) =>
          this.productLabel(a).localeCompare(this.productLabel(b)));
        this.productTypes = result.types;
        this.productCategories = result.categories;
        this.acceptPage(result.pricePage);
        this.openRequestedRoute();
      },
      error: error => this.fail(error, 'Unable to load Pricing Management.')
    });
  }

  /**
   * Reviewer note: Encapsulates the accept page view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private acceptPage(result: ProductPricePage): void {
    this.prices = result.items;
    this.page = result.page;
    this.pageSize = result.pageSize;
    this.totalCount = result.totalCount;
    this.totalPages = result.totalPages;
  }

  /**
   * Reviewer note: Coordinates the reset messages interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private resetMessages(): void {
    this.successMessage = '';
    this.errorMessage = '';
  }

  /**
   * Reviewer note: Calculates has two decimal places for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  private hasTwoDecimalPlaces(value: number): boolean {
    return Math.abs(value * 100 - Math.round(value * 100)) < 1e-7;
  }

  /**
   * Reviewer note: Encapsulates the local date time view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private localDateTime(): string {
    const value = new Date();
    return new Date(value.getTime() - value.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 16);
  }

  /**
   * Reviewer note: Coordinates open requested route so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private openRequestedRoute(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!Number.isInteger(id) || id <= 0) return;

    this.pricing.get(id).pipe(take(1)).subscribe({
      next: price => this.viewHistory(price),
      error: error => this.fail(error, 'Unable to load the requested price record.')
    });
  }

  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown, fallback: string): void {
    if (error instanceof HttpErrorResponse) {
      this.errorMessage = error.error?.message ||
        (error.status === 0
          ? 'Cannot connect to the backend API.'
          : error.status === 403
            ? 'You do not have permission to perform this pricing action.'
            : error.status === 409
              ? 'The price changed or is protected by active business activity.'
              : fallback);
      return;
    }
    this.errorMessage = fallback;
  }
}
