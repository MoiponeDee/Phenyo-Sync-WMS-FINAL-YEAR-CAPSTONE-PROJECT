/**
 * Reviewer guide: Verifies the pricing management frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { environment } from '../../../environments/environment';
import { AuthorizationService } from '../../services/authorization';
import { PricingManagement } from './pricing-management';

// Protects effective-price create/cancel interactions and refreshed history presentation.
describe('PricingManagement', () => {
  let fixture: ComponentFixture<PricingManagement>;
  let component: PricingManagement;
  let http: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PricingManagement],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([])
      ]
    }).compileComponents();

    TestBed.inject(AuthorizationService).session.set({
      userId: 1,
      email: 'manager@example.test',
      role: 'Business Manager',
      roleCode: 'BusinessManager',
      isActive: true,
      permissions: [{
        permissionId: 1,
        code: 'Pricing.Manage',
        displayName: 'Manage pricing',
        module: 'Pricing'
      }]
    });

    fixture = TestBed.createComponent(PricingManagement);
    component = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    fixture.detectChanges();

    http.expectOne(`${environment.apiUrl}/Product`).flush([]);
    http.expectOne(`${environment.apiUrl}/ProductType/active`).flush([]);
    http.expectOne(`${environment.apiUrl}/ProductCategory/active`).flush([]);
    http.expectOne(request => request.url === `${environment.apiUrl}/prices`).flush({
      items: [], page: 1, pageSize: 20, totalCount: 0, totalPages: 0
    });
    await fixture.whenStable();
    fixture.detectChanges();
  });

  afterEach(() => {
    http.verify();
  });

  // Reviewer note: Guards the observable rule that creates the pricing management component for a pricing manager.
  it('creates the pricing management component for a pricing manager', () => {
    expect(component).toBeTruthy();
    expect(component.canManage).toBe(true);
  });

  // Reviewer note: Guards the observable rule that validates required and positive initial price fields before calling the API.
  it('validates required and positive initial price fields before calling the API', () => {
    component.create();
    expect(component.errorMessage).toContain('Select an active product');
    http.expectNone(`${environment.apiUrl}/prices`);
  });

  it('allows an unpriced active product to receive its first price record', () => {
    component.products = [{
      productId: 9,
      productName: 'New Product',
      productTypeId: 2,
      productTypeName: 'Fresh',
      productCategoryId: 3,
      productCategoryName: 'Produce',
      size: '1 kg',
      shelfLifeDays: 30,
      sellingPricePerKg: 0,
      status: 'Active',
      createdAt: new Date().toISOString(),
      totalAvailableQuantityKg: 0,
      alertLevel: 'Normal',
      canDelete: true,
      isCommitted: false,
      canDeactivate: true
    }];

    expect(component.hasCurrentPrice(9)).toBe(false);
    component.createProductId = 9;
    component.createPrice = 12.34;
    component.create();

    const request = http.expectOne(`${environment.apiUrl}/prices`);
    expect(request.request.body).toEqual(expect.objectContaining({
      productId: 9,
      sellingPrice: 12.34,
      priceBasis: 'PerKilogram'
    }));
    request.flush({
      message: 'Price created.',
      price: {
        productPriceId: 1,
        productId: 9,
        sellingPrice: 12.34,
        priceBasis: 'PerKilogram'
      }
    });
    http.expectOne(candidate => candidate.url === `${environment.apiUrl}/prices`).flush({
      items: [], page: 1, pageSize: 20, totalCount: 0, totalPages: 0
    });
  });

  // Reviewer note: Guards the observable rule that resets saving state after an update conflict.
  it('resets saving state after an update conflict', async () => {
    component.updateTarget = {
      productPriceId: 1,
      productId: 2,
      productCode: 'PRODUCT-000002',
      productName: 'Apples',
      productTypeName: 'Fresh',
      productCategoryName: 'Fruit',
      size: '1 KG',
      productStatus: 'Active',
      sellingPrice: 10,
      priceBasis: 'PerKilogram',
      effectiveFromUtc: new Date().toISOString(),
      isCurrent: true,
      isScheduled: false,
      isDeleted: false,
      createdAtUtc: new Date().toISOString(),
      linkedOrderCount: 0,
      isCommitted: false,
      canSoftDelete: false,
      deleteBlockedReason: 'Current prices must be replaced first.',
      rowVersion: ''
    };
    component.updatePrice = 11;
    component.update();

    http.expectOne(`${environment.apiUrl}/prices/1`).flush(
      { message: 'Another manager changed this price.' },
      { status: 409, statusText: 'Conflict' }
    );
    await fixture.whenStable();
    expect(component.saving).toBe(false);
    expect(component.errorMessage).toContain('Another manager');
  });
});
