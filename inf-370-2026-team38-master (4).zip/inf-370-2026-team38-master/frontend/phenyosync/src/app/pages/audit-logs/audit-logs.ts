/**
 * Reviewer guide: Coordinates the audit logs page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule, Location } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize, forkJoin, take, timeout } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import {
  AuditLogDetail,
  AuditLogListItem,
  AuditLogMetadata,
  AuditLogService,
  PagedResult
} from '../../services/audit-log';

@Component({
  selector: 'app-audit-logs',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent, SearchFieldComponent],
  templateUrl: './audit-logs.html',
  styleUrl: './audit-logs.css'
})
/** Provides filterable audit review while detail/export access remains backend-authorized. */
export class AuditLogs implements OnInit {
  logs: AuditLogListItem[] = [];
  metadata: AuditLogMetadata = {
    actionTypes: [],
    systemModules: [],
    entityTypes: [],
    users: []
  };

  userId: number | null = null;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  userSearch = '';
  dateFrom = '';
  dateTo = '';
  actionType = '';
  systemModule = '';
  operationName = '';
  entityType = '';
  entityId = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successFilter = '';
  correlationId = '';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  searchTerm = '';

  pageNumber = 1;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  readonly pageSize = 25;
  totalCount = 0;
  totalPages = 0;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  hasPreviousPage = false;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  hasNextPage = false;

  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedLog: AuditLogDetail | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  detailLoading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  detailError = '';

  /**
   * Reviewer note: Encapsulates the maximum date time local view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get maximumDateTimeLocal(): string {
    const now = new Date();
    const local = new Date(
      now.getTime() - now.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 16);
  }

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private auditLogs: AuditLogService,
    private changeDetector: ChangeDetectorRef,
    private location: Location,
    private router: Router
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.loadInitial();
  }

  /**
   * Reviewer note: Coordinates load initial so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadInitial(): void {
    this.loading = true;
    this.errorMessage = '';

    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      metadata: this.auditLogs.metadata(),
      page: this.auditLogs.search({
        pageNumber: 1,
        pageSize: this.pageSize
      })
    }).pipe(
      take(1),
      timeout(60000),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.metadata = result.metadata;
        this.acceptPage(result.page);
      },
      error: error => this.fail(error, 'Unable to load the audit log.')
    });
  }

  /**
   * Reviewer note: Coordinates search so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  search(resetPage = true): void {
    if (this.loading) return;
    this.errorMessage = '';

    if (this.dateFrom && this.dateTo &&
        new Date(this.dateFrom).getTime() > new Date(this.dateTo).getTime()) {
      this.errorMessage = 'The start date cannot be after the end date.';
      return;
    }

    if ((this.dateFrom && new Date(this.dateFrom).getTime() > Date.now()) ||
        (this.dateTo && new Date(this.dateTo).getTime() > Date.now())) {
      this.errorMessage = 'Audit searches cannot use future dates.';
      return;
    }

    if (resetPage) this.pageNumber = 1;
    this.loading = true;
    this.auditLogs.search({
      userId: this.userId,
      userSearch: this.userSearch.trim(),
      dateFromUtc: this.toUtc(this.dateFrom),
      dateToUtc: this.toUtc(this.dateTo),
      actionType: this.actionType,
      systemModule: this.systemModule,
      operationName: this.operationName.trim(),
      entityType: this.entityType,
      entityId: this.entityId.trim(),
      success: this.successFilter === '' ? null : this.successFilter === 'true',
      correlationId: this.correlationId.trim(),
      searchTerm: this.searchTerm.trim(),
      pageNumber: this.pageNumber,
      pageSize: this.pageSize
    }).pipe(
      take(1),
      timeout(60000),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: page => this.acceptPage(page),
      error: error => this.fail(error, 'Unable to search audit logs.')
    });
  }

  /**
   * Reviewer note: Encapsulates the clear filters view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearFilters(): void {
    if (this.loading) return;
    this.userId = null;
    this.userSearch = '';
    this.dateFrom = '';
    this.dateTo = '';
    this.actionType = '';
    this.systemModule = '';
    this.operationName = '';
    this.entityType = '';
    this.entityId = '';
    this.successFilter = '';
    this.correlationId = '';
    this.searchTerm = '';
    this.pageNumber = 1;
    this.search(false);
  }

  /**
   * Reviewer note: Encapsulates the previous page view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  previousPage(): void {
    if (this.hasPreviousPage && !this.loading) {
      this.pageNumber--;
      this.search(false);
    }
  }

  /**
   * Reviewer note: Encapsulates the next page view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  nextPage(): void {
    if (this.hasNextPage && !this.loading) {
      this.pageNumber++;
      this.search(false);
    }
  }

  /**
   * Reviewer note: Encapsulates the view details view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  viewDetails(log: AuditLogListItem): void {
    if (this.detailLoading) return;
    this.detailLoading = true;
    this.detailError = '';
    this.auditLogs.get(log.auditLogId).pipe(
      take(1),
      timeout(60000),
      finalize(() => {
        this.detailLoading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: detail => this.selectedLog = detail,
      error: error => this.detailError = this.errorText(
        error,
        'Unable to load the audit-log details.')
    });
  }

  /**
   * Reviewer note: Encapsulates the close details view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  closeDetails(): void {
    if (!this.detailLoading) {
      this.selectedLog = null;
      this.detailError = '';
    }
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    if (window.history.length > 1) {
      this.location.back();
      return;
    }
    this.router.navigate(['/admin-dashboard']);
  }

  /**
   * Reviewer note: Encapsulates the actor view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  actor(log: AuditLogListItem): string {
    return log.userDisplayName || log.userEmail || log.actorType;
  }

  /**
   * Reviewer note: Encapsulates the formatted json view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  formattedJson(value?: string): string {
    if (!value) return 'Not recorded';
    try {
      return JSON.stringify(JSON.parse(value), null, 2);
    } catch {
      return value;
    }
  }

  /**
   * Reviewer note: Encapsulates the accept page view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private acceptPage(page: PagedResult<AuditLogListItem>): void {
    this.logs = page.items;
    this.pageNumber = page.pageNumber;
    this.totalCount = page.totalCount;
    this.totalPages = page.totalPages;
    this.hasPreviousPage = page.hasPreviousPage;
    this.hasNextPage = page.hasNextPage;
  }

  /**
   * Reviewer note: Encapsulates the to utc view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private toUtc(value: string): string | undefined {
    if (!value) return undefined;
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? undefined : parsed.toISOString();
  }

  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown, fallback: string): void {
    this.logs = [];
    this.errorMessage = this.errorText(error, fallback);
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    if (error instanceof Error && error.name === 'TimeoutError') {
      return 'The request timed out. Check that the backend API is running.';
    }
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) return 'Cannot connect to the backend API.';
      if (error.status === 400) return error.error?.message || 'The search filters are invalid.';
      if (error.status === 401) return 'Your login session has expired. Please log in again.';
      if (error.status === 403) return 'You are not authorized to view audit logs.';
      if (error.status === 404) return error.error?.message || 'Audit log record not found.';
      if (error.status >= 500) return error.error?.message || 'A server error occurred.';
    }
    return fallback;
  }
}
