/**
 * Reviewer guide: Verifies the audit logs frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { environment } from '../../../environments/environment';
import { AuditLogs } from './audit-logs';

// Proves filters and sensitive detail actions use the audit service rather than local assumptions.
describe('AuditLogs', () => {
  let fixture: ComponentFixture<AuditLogs>;
  let component: AuditLogs;
  let http: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AuditLogs],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([])
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AuditLogs);
    component = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    fixture.detectChanges();

    http.expectOne(`${environment.apiUrl}/audit-logs/metadata`).flush({
      actionTypes: ['Create', 'Update'],
      systemModules: ['ProductManagement'],
      entityTypes: ['Product'],
      users: []
    });
    http.expectOne(request =>
      request.url === `${environment.apiUrl}/audit-logs` &&
      request.params.get('pageNumber') === '1').flush({
      items: [],
      pageNumber: 1,
      pageSize: 25,
      totalCount: 0,
      totalPages: 0,
      hasPreviousPage: false,
      hasNextPage: false
    });
    await fixture.whenStable();
    fixture.detectChanges();
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that loads newest audit logs and renders read-only controls.
  it('loads newest audit logs and renders read-only controls', () => {
    expect(component).toBeTruthy();
    expect(component.loading).toBe(false);
    const text = fixture.nativeElement.textContent;
    expect(text).toContain('Audit Logs');
    expect(text).toContain('Read only');
    expect(text).not.toContain('Delete Log');
    expect(text).not.toContain('Edit Log');
  });

  // Reviewer note: Guards the observable rule that validates the date range before sending a request.
  it('validates the date range before sending a request', () => {
    component.dateFrom = '2026-07-24T10:00';
    component.dateTo = '2026-07-23T10:00';
    component.search();
    expect(component.errorMessage).toContain('start date');
    http.expectNone(request => request.url === `${environment.apiUrl}/audit-logs`);
  });

  // Reviewer note: Guards the observable rule that preserves filters while navigating pages and resets loading after an error.
  it('preserves filters while navigating pages and resets loading after an error', async () => {
    component.actionType = 'Update';
    component.pageNumber = 2;
    component.search(false);

    const request = http.expectOne(item =>
      item.url === `${environment.apiUrl}/audit-logs` &&
      item.params.get('pageNumber') === '2' &&
      item.params.get('actionType') === 'Update');
    request.flush(
      { message: 'Temporary server error.' },
      { status: 500, statusText: 'Server Error' }
    );
    await fixture.whenStable();
    expect(component.loading).toBe(false);
    expect(component.errorMessage).toContain('Temporary server error');
  });

  // Reviewer note: Guards the observable rule that opens sanitized read-only detail data.
  it('opens sanitized read-only detail data', async () => {
    component.viewDetails({
      auditLogId: 7,
      occurredAtUtc: new Date().toISOString(),
      actorType: 'User',
      actionType: 'Update',
      systemModule: 'Pricing',
      operationName: 'UpdateProductPrice',
      description: 'Updated price',
      success: true,
      correlationId: 'correlation-7'
    });

    http.expectOne(`${environment.apiUrl}/audit-logs/7`).flush({
      auditLogId: 7,
      occurredAtUtc: new Date().toISOString(),
      actorType: 'User',
      actionType: 'Update',
      systemModule: 'Pricing',
      operationName: 'UpdateProductPrice',
      description: 'Updated price',
      success: true,
      correlationId: 'correlation-7',
      eventSource: 'EntityChange',
      beforeValuesJson: '{"SellingPrice":10}',
      afterValuesJson: '{"SellingPrice":12}',
      changedFieldsJson: '["SellingPrice"]',
      relatedLogs: []
    });
    await fixture.whenStable();
    fixture.detectChanges();
    expect(component.selectedLog?.auditLogId).toBe(7);
    expect(fixture.nativeElement.textContent).toContain('No edit or delete actions are available.');
  });
});
