/**
 * Reviewer guide: Coordinates the manage permissions page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { finalize } from 'rxjs';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import {
  PermissionSummary,
  SecurityAdminService
} from '../../services/security-admin';

@Component({
  selector: 'app-manage-permissions',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, SearchFieldComponent],
  templateUrl: './manage-permissions.html',
  styleUrl: '../security-management.css'
})
/** Edits role-permission mappings while effective access is recomputed by the backend. */
export class ManagePermissions implements OnInit {
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  permissions: PermissionSummary[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search = '';
  module = '';
  modules: string[] = [];
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  showEditor = false;
  editing?: PermissionSummary;
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  form = this.emptyForm();

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private api: SecurityAdminService,
    private notifications: NotificationService,
    private confirmation: ConfirmationService,
    private changeDetector: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void { this.load(); }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.api.permissions(true, this.search, this.module)
      .pipe(finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      }))
      .subscribe({
        next: permissions => {
          this.permissions = permissions;
          this.modules = [...new Set(permissions.map(item => item.module))].sort();
        },
        error: error => this.errorMessage = this.readError(error)
      });
  }

  /**
   * Reviewer note: Coordinates open create so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openCreate(): void {
    this.editing = undefined;
    this.form = this.emptyForm();
    this.showEditor = true;
  }

  /**
   * Reviewer note: Coordinates open edit so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openEdit(permission: PermissionSummary): void {
    this.editing = permission;
    this.form = {
      permissionCode: permission.permissionCode,
      displayName: permission.displayName,
      module: permission.module,
      description: permission.description || '',
      rowVersion: permission.rowVersion
    };
    this.showEditor = true;
  }

  /**
   * Reviewer note: Coordinates the save interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  save(): void {
    if ((!this.editing && !/^[A-Za-z][A-Za-z0-9]+\.[A-Za-z][A-Za-z0-9]+$/.test(this.form.permissionCode)) ||
        !this.form.displayName.trim() || !this.form.module.trim()) {
      this.errorMessage = 'Enter a Module.Action code, display name and module.';
      return;
    }
    this.saving = true;
    const request = this.editing
      ? this.api.updatePermission(this.editing.permissionId, {
          displayName: this.form.displayName,
          module: this.form.module,
          description: this.form.description,
          rowVersion: this.form.rowVersion
        })
      : this.api.createPermission(this.form);
    request.pipe(finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: response => { this.notifications.success(response.message); this.showEditor = false; this.load(); },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates the change status interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async changeStatus(permission: PermissionSummary): Promise<void> {
    const activating = !permission.isActive;
    const result = await this.confirmation.ask({
      title: activating ? 'Activate permission' : 'Deactivate permission',
      message: `${activating ? 'Activate' : 'Deactivate'} ${permission.displayName}? Role access changes immediately.`,
      confirmLabel: activating ? 'Activate' : 'Deactivate',
      tone: activating ? 'default' : 'warning',
      reasonLabel: 'Reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.api.changePermissionStatus(
      permission.permissionId,
      activating,
      result.reason,
      permission.rowVersion
    ).subscribe({
      next: response => { this.notifications.success(response.message); this.load(); },
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Coordinates the delete permission interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async deletePermission(permission: PermissionSummary): Promise<void> {
    const result = await this.confirmation.ask({
      title: 'Delete custom permission',
      message: `Delete ${permission.displayName}? Assigned or system permissions cannot be deleted.`,
      confirmLabel: 'Delete permission',
      tone: 'danger'
    });
    if (!result.confirmed) return;
    this.api.deletePermission(permission.permissionId).subscribe({
      next: response => { this.notifications.success(response.message); this.load(); },
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Encapsulates the empty form view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private emptyForm() {
    return {
      permissionCode: '',
      displayName: '',
      module: '',
      description: '',
      rowVersion: ''
    };
  }

  /**
   * Reviewer note: Encapsulates the read error view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private readError(error: any): string {
    return error.error?.message || 'The permission action could not be completed.';
  }
}
