/**
 * Reviewer guide: Coordinates the driver dashboard page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { RouterLink } from '@angular/router';

// Presents delivery work for the driver without duplicating execution workflow rules.
@Component({
  selector: 'app-driver-dashboard',
  standalone: true,
  imports: [CommonModule, TopbarComponent, SidebarComponent, RouterLink],
  templateUrl: './driver-dashboard.component.html',
  styleUrls: ['./driver-dashboard.component.css']
})
export class DriverDashboardComponent {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  menuItems = [
    { name: 'Driver Dashboard', route: '/driver-dashboard', active: true },
    { name: 'My Deliveries', route: '/my-deliveries' },
    { name: 'Operations Calendar', route: '/operations-calendar' }
  ];
}
