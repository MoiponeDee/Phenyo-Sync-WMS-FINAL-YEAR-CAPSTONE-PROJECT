/**
 * Reviewer guide: Coordinates the profile page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthService, MyProfile } from '../../services/auth';
import { NotificationService } from '../../services/notification';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './profile.html',
  styleUrl: './profile.css'
})
/** Displays immutable identity fields and permits only the current user's phone-number update. */
export class Profile implements OnInit {
  profile: MyProfile | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  changingPassword = false;
  readonly editMode: boolean;
  edit = {
    phoneNumber: ''
  };
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  password = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  };

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly auth: AuthService,
    private readonly notifications: NotificationService,
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly changeDetector: ChangeDetectorRef
  ) {
    this.editMode = this.route.snapshot.data['edit'] === true;
  }

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.auth.myProfile().pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: profile => {
        this.profile = profile;
        this.edit = {
          phoneNumber: profile.phoneNumber || ''
        };
      },
      error: error => this.notifications.error(
        error?.error?.message || 'Your profile could not be loaded.')
    });
  }

  /**
   * Reviewer note: Coordinates the save interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  save(): void {
    if (!this.profile) return;

    this.saving = true;
    // Send only the editable phone and RowVersion; role/email/name cannot be changed here.
    this.auth.updateMyProfile({
      phoneNumber: this.edit.phoneNumber || null,
      rowVersion: this.profile.rowVersion
    }).pipe(finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: profile => {
        this.profile = profile;
        this.notifications.success('Profile updated.');
        void this.router.navigate(['/profile']);
      },
      error: error => this.notifications.error(
        error?.error?.message || 'Your profile could not be updated.')
    });
  }

  /**
   * Reviewer note: Coordinates the change own password interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  changeOwnPassword(): void {
    if (!this.password.currentPassword || !this.password.newPassword ||
        !this.password.confirmPassword) {
      this.notifications.warning('Complete all password fields.');
      queueMicrotask(() =>
        document.querySelector<HTMLElement>('form input:invalid')?.focus());
      return;
    }
    if (this.password.newPassword !== this.password.confirmPassword) {
      this.notifications.warning('The new passwords do not match.');
      return;
    }
    this.changingPassword = true;
    this.auth.changePassword(this.password).pipe(finalize(() => {
      this.changingPassword = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: result => {
        this.notifications.success(result.message);
        localStorage.removeItem('token');
        localStorage.removeItem('role');
        localStorage.removeItem('user');
        void this.router.navigate(['/login']);
      },
      error: error => this.notifications.error(
        error?.error?.message || 'Your password could not be changed.')
    });
  }
}
