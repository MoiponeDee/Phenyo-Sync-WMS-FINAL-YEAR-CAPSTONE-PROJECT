/**
 * Reviewer guide: Verifies the profile frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { Profile } from './profile';

// Proves self-service profile updates exclude protected identity and role fields.
describe('Profile', () => {
  let fixture: ComponentFixture<Profile>;
  let http: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Profile],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([]),
        { provide: ActivatedRoute, useValue: { snapshot: { data: { edit: true } } } }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(Profile);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  // Reviewer note: Guards the observable rule that shows protected account fields as text and exposes only phone input.
  it('shows protected account fields as text and exposes only phone input', () => {
    fixture.detectChanges();
    http.expectOne(`${environment.apiUrl}/auth/profile`).flush({
      userId: 1,
      firstName: 'Zafar',
      lastName: 'Suliman',
      username: 'zafarsuliman+admin@gmail.com',
      email: 'zafarsuliman+admin@gmail.com',
      phoneNumber: '0712345678',
      roleCode: 'Admin',
      roleName: 'Super Admin',
      rowVersion: 'AQID'
    });
    fixture.detectChanges();

    const text = fixture.nativeElement.textContent;
    expect(text).toContain('Super Admin');
    expect(text).toContain('zafarsuliman+admin@gmail.com');
    expect(text).not.toContain('Licence number');
    const inputNames = Array.from(
      fixture.nativeElement.querySelectorAll('input') as NodeListOf<HTMLInputElement>
    ).map(input => input.name);
    expect(inputNames).toEqual([
      'phoneNumber',
      'currentPassword',
      'newPassword',
      'confirmPassword'
    ]);
  });

  // Reviewer note: Guards the observable rule that submits only phone and the concurrency version.
  it('submits only phone and the concurrency version', () => {
    vi.spyOn(TestBed.inject(Router), 'navigate').mockResolvedValue(true);
    fixture.detectChanges();
    const profile = {
      userId: 1,
      firstName: 'Zafar',
      lastName: 'Suliman',
      username: 'zafarsuliman+admin@gmail.com',
      email: 'zafarsuliman+admin@gmail.com',
      phoneNumber: '0712345678',
      roleCode: 'Admin',
      roleName: 'Super Admin',
      rowVersion: 'AQID'
    };
    http.expectOne(`${environment.apiUrl}/auth/profile`).flush(profile);
    fixture.detectChanges();

    fixture.componentInstance.edit.phoneNumber = '0798765432';
    fixture.componentInstance.save();

    const request = http.expectOne(`${environment.apiUrl}/auth/profile`);
    expect(request.request.method).toBe('PUT');
    expect(request.request.body).toEqual({
      phoneNumber: '0798765432',
      rowVersion: 'AQID'
    });
    request.flush({ ...profile, phoneNumber: '0798765432' });
  });
});
