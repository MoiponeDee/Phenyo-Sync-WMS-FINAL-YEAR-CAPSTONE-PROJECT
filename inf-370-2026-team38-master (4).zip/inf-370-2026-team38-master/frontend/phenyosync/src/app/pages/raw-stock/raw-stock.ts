/**
 * Reviewer guide: Coordinates the raw stock page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { finalize, forkJoin, of } from 'rxjs';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import {
  BuyingListDetail,
  BuyingListLine,
  BuyingListService,
  BuyingListSummary
} from '../../services/buying-lists';
import {
  OperationalReason,
  OperationalSectionsService,
  RawStockReceipt,
  RawStockSummary,
  RawStockTake,
  RawStockWriteOff,
  SupplierOrder,
  SupplierSummary
} from '../../services/operational-sections';
import {
  ProductLookupService,
  WarehouseSection
} from '../../services/product-lookups';
import { HumanizeCodePipe } from '../../pipes/humanize-code.pipe';

type RawStockTab =
  'inventory' | 'receive' | 'takes' | 'writeoffs' | 'reasons';

@Component({
  selector: 'app-raw-stock',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TopbarComponent,
    SidebarComponent,
    SearchFieldComponent,
    HumanizeCodePipe
  ],
  templateUrl: './raw-stock.html'
})
/** Presents raw-stock balances, receipts and controls without computing ledger effects locally. */
export class RawStockComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  tab: RawStockTab = 'inventory';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search = '';
  includeInactive = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  inventory: RawStockSummary[] = [];
  receipts: RawStockReceipt[] = [];
  stockTakes: RawStockTake[] = [];
  writeOffs: RawStockWriteOff[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  reasons: OperationalReason[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  suppliers: SupplierSummary[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  supplierOrders: SupplierOrder[] = [];
  buyingLists: BuyingListSummary[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedBuyingListDetail: BuyingListDetail | null = null;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  sections: WarehouseSection[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  counts: Record<number, number | null> = {};
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Raw Stock', route: '/raw-stock', active: true },
    { name: 'Product Stock', route: '/search-product' },
    { name: 'Expiry Alerts', route: '/expiry-alerts' },
    { name: 'Operations Calendar', route: '/operations-calendar' },
    { name: 'Management Overview', route: '/management-dashboard' }
  ];

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly createForm = this.fb.nonNullable.group({
    itemCode: ['', [Validators.required, Validators.maxLength(40)]],
    itemName: ['', [Validators.required, Validators.maxLength(160)]],
    categoryCode: ['Produce', Validators.required],
    unitOfMeasure: ['kg', Validators.required],
    warehouseSectionId: [0, Validators.min(1)],
    initialQuantity: [0, Validators.min(0)],
    initialUnitCost: new FormControl<number | null>(
      null,
      Validators.min(.001)),
    batchReference: [''],
    bestBeforeAtUtc: [''],
    reason: ['', [Validators.required, Validators.minLength(3)]]
  });

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly receiptForm = this.fb.nonNullable.group({
    sourceType: ['BuyingList', Validators.required],
    supplierId: new FormControl<number | null>(null),
    supplierOrderId: [''],
    buyerProcurementId: [''],
    warehouseSectionId: [0, Validators.min(1)],
    docketReference: ['', Validators.required],
    notes: [''],
    lines: this.fb.array([this.createReceiptLine()])
  });

  /**
   * Reviewer note: Encapsulates the receipt lines view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get receiptLines(): FormArray {
    return this.receiptForm.controls.lines as FormArray;
  }

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly stockTakeForm = this.fb.nonNullable.group({
    warehouseSectionId: [0, Validators.min(1)],
    periodStartUtc: [this.localDateTime(new Date(Date.now() - 30 * 86400000)), Validators.required],
    periodEndUtc: [this.localDateTime(), Validators.required],
    notes: ['']
  });

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly writeOffForm = this.fb.nonNullable.group({
    rawStockBalanceId: [0, Validators.min(1)],
    operationalReasonId: [0, Validators.min(1)],
    quantity: [0, Validators.min(.001)],
    condition: [''],
    notes: ['']
  });

  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly reasonForm = this.fb.nonNullable.group({
    reasonCode: ['', Validators.required],
    reasonName: ['', Validators.required],
    categoryCode: ['WriteOff', Validators.required],
    description: [''],
    isActive: [true]
  });

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private operational: OperationalSectionsService,
    private lookups: ProductLookupService,
    private notifications: NotificationService,
    private confirmation: ConfirmationService,
    private buyingListService: BuyingListService,
    private changeDetector: ChangeDetectorRef,
    private route: ActivatedRoute,
    readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    const requestedTab = this.route.snapshot.queryParamMap.get('tab');
    if (requestedTab && this.isRawStockTab(requestedTab) &&
        this.canAccessTab(requestedTab)) {
      this.tab = requestedTab;
    } else {
      this.tab = (['inventory', 'receive', 'takes', 'writeoffs', 'reasons'] as RawStockTab[])
        .find(tab => this.canAccessTab(tab)) ?? 'takes';
    }
    this.receiptForm.controls.supplierId.disable();
    this.loadAll();
  }

  /**
   * Reviewer note: Encapsulates the set tab view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  setTab(tab: RawStockTab): void {
    if (this.canAccessTab(tab)) this.tab = tab;
  }

  /**
   * Reviewer note: Calculates is raw stock tab for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  private isRawStockTab(value: string): value is RawStockTab {
    return ['inventory', 'receive', 'takes', 'writeoffs', 'reasons']
      .includes(value);
  }

  /**
   * Reviewer note: Calculates can for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  can(permission: string): boolean {
    return this.authorization.has(permission);
  }

  canAccessTab(tab: RawStockTab): boolean {
    if (tab === 'inventory') return this.can('RawStock.View');
    if (tab === 'receive') return this.can('RawStock.Receive');
    if (tab === 'takes') return this.can('RawStockTakes.View');
    if (tab === 'writeoffs') {
      return this.can('RawStock.View') || this.can('RawStock.WriteOff') ||
        this.can('RawStock.ApproveWriteOff');
    }
    return this.can('OperationalReasons.View');
  }

  /**
   * Reviewer note: Coordinates load all so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadAll(): void {
    this.loading = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      inventory: this.can('RawStock.View')
        ? this.operational.rawStock(this.search, this.includeInactive)
        : of({ items: [], page: 1, pageSize: 100, total: 0 }),
      receipts: this.can('RawStock.View')
        ? this.operational.receipts()
        : of([]),
      takes: this.can('RawStockTakes.View')
        ? this.operational.stockTakes()
        : of([]),
      writeOffs: this.can('RawStock.View') || this.can('RawStock.ApproveWriteOff')
        ? this.operational.writeOffs()
        : of([]),
      reasons: this.can('OperationalReasons.View')
        ? this.operational.reasons()
        : of({ items: [], page: 1, pageSize: 100, total: 0 }),
      suppliers: this.can('Suppliers.View')
        ? this.operational.suppliers()
        : of([]),
      supplierOrders: this.can('SupplierOrders.View')
        ? this.operational.supplierOrders()
        : of([]),
      buyingLists: this.can('BuyingList.View')
        ? this.buyingListService.search({ page: 1, pageSize: 100 })
        : of({ items: [], page: 1, pageSize: 100, total: 0 }),
      sections: this.can('WarehouseSections.View')
        ? this.lookups.getActiveWarehouseSections()
        : of([])
    }).pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: result => {
        this.inventory = result.inventory.items;
        this.receipts = result.receipts;
        this.stockTakes = result.takes;
        this.writeOffs = result.writeOffs;
        this.reasons = result.reasons.items;
        this.suppliers = result.suppliers;
        this.supplierOrders = result.supplierOrders;
        this.buyingLists = result.buyingLists.items.filter(item =>
          item.status === 'Submitted' || item.status === 'PartiallyReceived');
        this.sections = result.sections;
        for (const take of result.takes) {
          for (const line of take.lines) {
            this.counts[line.rawStockTakeLineId] =
              line.physicalStockCount ?? null;
          }
        }
      },
      error: error => this.notifications.error(
        error?.error?.message || 'Raw-stock operations could not be loaded.')
    });
  }

  /**
   * Reviewer note: Coordinates the create raw stock interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  createRawStock(): void {
    if (this.createForm.invalid || this.loading) {
      this.createForm.markAllAsTouched();
      this.focusFirstInvalid();
      return;
    }
    const value = this.createForm.getRawValue();
    if (value.initialQuantity > 0 &&
        (value.initialUnitCost == null || value.initialUnitCost <= 0)) {
      this.notifications.warning(
        'Enter a positive opening unit cost when opening quantity is greater than zero.');
      return;
    }
    this.run(
      this.operational.createRawStock({
        ...value,
        bestBeforeAtUtc: value.bestBeforeAtUtc
          ? new Date(value.bestBeforeAtUtc).toISOString()
          : null
      }),
      'Raw-stock item created.',
      () => {
        this.createForm.reset({
          categoryCode: 'Produce',
          unitOfMeasure: 'kg',
          warehouseSectionId: 0,
          initialQuantity: 0,
          initialUnitCost: null
        });
        this.loadAll();
      });
  }

  /**
   * Reviewer note: Coordinates the receive interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  receive(): void {
    // Accepted/rejected quantities and source lines are revalidated before any ledger entry is posted.
    if (this.receiptForm.invalid || this.loading) {
      this.receiptForm.markAllAsTouched();
      this.focusFirstInvalid();
      return;
    }
    const value = this.receiptForm.getRawValue();
    this.run(this.operational.receive({
      sourceType: value.sourceType,
      supplierId: value.supplierId || null,
      supplierOrderId: this.numberOrNull(value.supplierOrderId),
      buyerProcurementId: this.numberOrNull(value.buyerProcurementId),
      warehouseSectionId: value.warehouseSectionId,
      docketReference: value.docketReference,
      adHocExplanation: null,
      notes: value.notes || null,
      receivedAtUtc: new Date().toISOString(),
      operationId: crypto.randomUUID(),
      lines: value.lines.map(line => ({
        supplierOrderLineId: this.numberOrNull(line.supplierOrderLineId),
        buyerProcurementItemId: this.numberOrNull(
          line.buyerProcurementItemId),
        rawStockItemId: Number(line.rawStockItemId),
        quantityReceived: Number(line.quantityReceived),
        acceptedQuantity: Number(line.quantityReceived),
        rejectedQuantity: 0,
        unitCost: line.unitCost,
        unitOfMeasure: line.unitOfMeasure,
        supplierBatchReference: null,
        bestBeforeAtUtc: line.bestBeforeAtUtc
          ? new Date(line.bestBeforeAtUtc).toISOString()
          : null,
        notes: line.notes || null
      }))
    }), 'Raw stock received and posted.', () => {
      this.resetReceiptLines();
      this.receiptForm.patchValue({
        docketReference: '',
        notes: '',
        supplierId: null
      });
      this.selectedBuyingListDetail = null;
      this.loadAll();
    });
  }

  /**
   * Reviewer note: Coordinates the remove raw stock interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async manageRawStock(item: RawStockSummary): Promise<void> {
    if (!item.canDelete) {
      const activating = !item.isActive;
      const decision = await this.confirmation.ask({
        title: `${activating ? 'Activate' : 'Deactivate'} ${item.itemName}?`,
        message: activating
          ? 'This item will become available for new raw-stock activity.'
          : 'The item and its stock history will be retained, but it will not be available for new activity.',
        confirmLabel: activating ? 'Activate item' : 'Deactivate item',
        tone: activating ? 'warning' : 'danger',
        reasonLabel: `${activating ? 'Activation' : 'Deactivation'} reason`,
        reasonRequired: true
      });
      if (!decision.confirmed) return;
      this.run(
        this.operational.changeRawStockStatus(
          item.rawStockItemId,
          activating,
          decision.reason),
        `Raw-stock item ${activating ? 'activated' : 'deactivated'}.`,
        () => this.loadAll());
      return;
    }

    const decision = await this.confirmation.ask({
      title: `Delete unused item ${item.itemName}?`,
      message: 'This item has no quantity or operational history and will be permanently removed.',
      confirmLabel: 'Delete unused item',
      tone: 'danger',
      reasonLabel: 'Deletion reason',
      reasonRequired: true
    });
    if (!decision.confirmed) return;
    this.loading = true;
    this.operational.deleteRawStock(
      item.rawStockItemId,
      decision.reason
    ).pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.loadAll();
      },
      error: async error => {
        if (error?.status === 409 && error?.error?.canDeactivate) {
          const fallback = await this.confirmation.ask({
            title: 'Deactivate raw stock instead?',
            message: error.error.deleteBlockedReason ||
              'Operational history must be retained.',
            confirmLabel: 'Deactivate',
            tone: 'warning'
          });
          if (!fallback.confirmed) return;
          this.operational.changeRawStockStatus(
            item.rawStockItemId,
            false,
            decision.reason
          ).subscribe({
            next: response => {
              this.notifications.success(response.message);
              this.loadAll();
            },
            error: statusError => this.notifications.error(
              statusError?.error?.message ||
              'The raw-stock item could not be deactivated.')
          });
          return;
        }
        this.notifications.error(
          error?.error?.message || 'The raw-stock item could not be deleted.');
      }
    });
  }

  itemActionLabel(item: RawStockSummary): string {
    if (item.canDelete) return 'Delete unused item';
    return item.isActive ? 'Deactivate item' : 'Activate item';
  }

  /**
   * Reviewer note: Encapsulates the receivable supplier orders view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  receivableSupplierOrders(): SupplierOrder[] {
    return this.supplierOrders.filter(order =>
      order.status === 'Ordered' || order.status === 'PartiallyReceived');
  }

  /**
   * Reviewer note: Coordinates selected supplier order so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectedSupplierOrder(): SupplierOrder | undefined {
    const id = this.numberOrNull(
      this.receiptForm.controls.supplierOrderId.value);
    return this.supplierOrders.find(order => order.supplierOrderId === id);
  }

  /**
   * Reviewer note: Encapsulates the outstanding supplier order lines view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  outstandingSupplierOrderLines() {
    return (this.selectedSupplierOrder()?.lines ?? []).filter(line =>
      line.receivedQuantity < line.orderedQuantity);
  }

  /**
   * Reviewer note: Coordinates select supplier order so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectSupplierOrder(): void {
    const order = this.selectedSupplierOrder();
    if (order) {
      this.receiptForm.controls.supplierId.disable();
      this.receiptForm.controls.warehouseSectionId.disable();
    } else {
      this.receiptForm.controls.warehouseSectionId.enable();
    }
    this.receiptForm.patchValue({
      supplierId: order?.supplierId ?? null,
      warehouseSectionId: order?.warehouseSectionId ?? 0
    });
    this.receiptLines.clear();
    this.receiptLines.push(this.createReceiptLine());
  }

  /**
   * Reviewer note: Coordinates select supplier order line so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectSupplierOrderLine(index: number): void {
    const form = this.receiptLines.at(index);
    const lineId = this.numberOrNull(form.get('supplierOrderLineId')?.value);
    const sourceLine = this.outstandingSupplierOrderLines().find(item =>
      item.supplierOrderLineId === lineId);
    if (!sourceLine) return;
    const outstanding = Math.max(
      0,
      sourceLine.orderedQuantity - sourceLine.receivedQuantity);
    form.patchValue({
      rawStockItemId: sourceLine.rawStockItemId,
      quantityReceived: outstanding,
      acceptedQuantity: outstanding,
      rejectedQuantity: 0,
      unitCost: sourceLine.expectedUnitPrice,
      expectedUnitCost: sourceLine.expectedUnitPrice,
      unitOfMeasure: sourceLine.unitOfMeasure
    });
  }

  /**
   * Reviewer note: Coordinates select buying list so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectBuyingList(): void {
    const id = this.numberOrNull(
      this.receiptForm.controls.buyerProcurementId.value);
    this.selectedBuyingListDetail = null;
    this.receiptForm.patchValue({ supplierId: null });
    this.resetReceiptLines();
    if (!id) return;
    this.loading = true;
    this.buyingListService.get(id).pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: list => {
        this.selectedBuyingListDetail = list;
        this.changeDetector.detectChanges();
      },
      error: error => this.notifications.error(
        error?.error?.message || 'The Buying List could not be loaded.')
    });
  }

  /**
   * Reviewer note: Encapsulates the outstanding buying list lines view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  outstandingBuyingListLines(): BuyingListLine[] {
    return (this.selectedBuyingListDetail?.items ?? []).filter(item =>
      (item.status === 'Purchased' || item.status === 'Substituted') &&
      item.rawStockItemId &&
      item.outstandingQuantity > 0);
  }

  /**
   * Reviewer note: Coordinates select buying list line so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectBuyingListLine(index: number): void {
    const form = this.receiptLines.at(index);
    const lineId = this.numberOrNull(
      form.get('buyerProcurementItemId')?.value);
    const sourceLine = this.outstandingBuyingListLines().find(item =>
      item.buyerProcurementItemId === lineId);
    if (!sourceLine) return;
    form.patchValue({
      rawStockItemId: sourceLine.substituteRawStockItemId ??
        sourceLine.rawStockItemId ?? 0,
      quantityReceived: sourceLine.outstandingQuantity,
      acceptedQuantity: sourceLine.outstandingQuantity,
      rejectedQuantity: 0,
      unitCost: sourceLine.actualUnitPrice ?? null,
      expectedUnitCost: sourceLine.actualUnitPrice ?? null,
      unitOfMeasure: sourceLine.unitOfMeasure
    });
    this.receiptForm.patchValue({ supplierId: sourceLine.supplierId ?? null });
  }

  /**
   * Reviewer note: Coordinates selected source supplier name so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectedSourceSupplierName(): string {
    if (this.receiptForm.controls.sourceType.value === 'SupplierOrder') {
      return this.selectedSupplierOrder()?.supplierName ?? 'Select a Supplier Order';
    }
    const lineId = this.numberOrNull(
      this.receiptLines.at(0)?.get('buyerProcurementItemId')?.value);
    const line = this.outstandingBuyingListLines().find(item =>
      item.buyerProcurementItemId === lineId);
    return line?.supplierName || 'Market purchase — select a purchased line';
  }

  /**
   * Reviewer note: Coordinates the change receipt source interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  changeReceiptSource(): void {
    this.receiptForm.controls.supplierId.disable();
    this.receiptForm.controls.warehouseSectionId.enable();
    this.receiptForm.patchValue({
      supplierOrderId: '',
      buyerProcurementId: '',
      supplierId: null,
      warehouseSectionId: 0
    });
    this.selectedBuyingListDetail = null;
    this.resetReceiptLines();
  }

  /**
   * Reviewer note: Encapsulates the cost variance view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  costVariance(index: number): number | null {
    const line = this.receiptLines.at(index).getRawValue();
    const actual = Number(line.unitCost);
    const expected = Number(line.expectedUnitCost);
    return actual > 0 && expected > 0 ? actual - expected : null;
  }

  receiptLineIsProduce(index: number): boolean {
    const rawStockItemId = Number(
      this.receiptLines.at(index).get('rawStockItemId')?.value);
    return this.inventory.some(item =>
      item.rawStockItemId === rawStockItemId && item.isProduce);
  }

  /**
   * Reviewer note: Coordinates the create stock take interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  createStockTake(): void {
    if (this.stockTakeForm.invalid) {
      this.stockTakeForm.markAllAsTouched();
      this.focusFirstInvalid();
      return;
    }
    const value = this.stockTakeForm.getRawValue();
    this.run(this.operational.createStockTake({
      warehouseSectionId: value.warehouseSectionId,
      periodStartUtc: new Date(value.periodStartUtc).toISOString(),
      periodEndUtc: new Date(value.periodEndUtc).toISOString(),
      notes: value.notes || null
    }), 'Raw-stock take opened.', () => this.loadAll());
  }

  /**
   * Reviewer note: Coordinates the save count interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveCount(take: RawStockTake, lineId: number, rowVersion: string): void {
    // RowVersion prevents a late counter response from replacing a newer count or approval decision.
    const physicalStockCount = this.counts[lineId];
    if (physicalStockCount === null || physicalStockCount === undefined ||
        physicalStockCount < 0) {
      this.notifications.warning('Enter a valid physical count.');
      return;
    }
    this.run(this.operational.saveCount(
      take.rawStockTakeSessionId,
      lineId,
      { physicalStockCount, rowVersion }
    ), 'Count saved.', () => this.loadAll());
  }

  /**
   * Reviewer note: Coordinates the submit take interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async submitTake(take: RawStockTake): Promise<void> {
    const summary = this.stockTakeSummary(take);
    if (summary.unresolved > 0) {
      this.notifications.warning(
        `Count every raw-stock line before submission. ${summary.unresolved} line${summary.unresolved === 1 ? '' : 's'} remain.`);
      return;
    }
    const result = await this.confirmation.ask({
      title: 'Submit raw-stock take',
      message: `${summary.counted} items counted · positive adjustments ${summary.positive.toFixed(3)} · negative adjustments ${summary.negative.toFixed(3)} · unresolved lines ${summary.unresolved}. Submit for authorised review?`,
      confirmLabel: 'Submit',
      tone: 'warning'
    });
    if (!result.confirmed) return;
    this.run(this.operational.submitStockTake(
      take.rawStockTakeSessionId,
      take.rowVersion
    ), 'Stock take submitted for review.', () => this.loadAll());
  }

  async reviewTake(take: RawStockTake): Promise<void> {
    const result = await this.confirmation.ask({
      title: 'Review stock take',
      message: `Confirm the discrepancy review for Take #${take.rawStockTakeSessionId}. Stock will not change until a different authorised Operations Manager approves it.`,
      confirmLabel: 'Send for approval',
      reasonLabel: 'Review notes',
      reasonRequired: true,
      tone: 'warning'
    });
    if (!result.confirmed) return;
    this.run(this.operational.reviewStockTake(
      take.rawStockTakeSessionId,
      { notes: result.reason, rowVersion: take.rowVersion }
    ), 'Stock take is awaiting Operations Manager approval.', () => this.loadAll());
  }

  async decideTake(take: RawStockTake, approved: boolean): Promise<void> {
    const result = await this.confirmation.ask({
      title: approved ? 'Approve stock take' : 'Reject stock take',
      message: approved
        ? `Approving Take #${take.rawStockTakeSessionId} will post its variances as auditable raw-stock movements.`
        : `Reject Take #${take.rawStockTakeSessionId} without changing authoritative stock?`,
      confirmLabel: approved ? 'Approve and post' : 'Reject',
      reasonLabel: 'Decision reason',
      reasonRequired: true,
      tone: approved ? 'warning' : 'danger'
    });
    if (!result.confirmed) return;
    this.run(this.operational.decideStockTake(
      take.rawStockTakeSessionId,
      { approved, reason: result.reason, rowVersion: take.rowVersion }
    ), approved ? 'Stock take approved and posted.' : 'Stock take rejected.',
    () => this.loadAll());
  }

  stockTakeVariance(take: RawStockTake, lineId: number): number | null {
    const line = take.lines.find(item => item.rawStockTakeLineId === lineId);
    const physical = this.counts[lineId];
    if (!line || physical === null || physical === undefined) return null;
    return physical - line.estimatedRawStockRemaining;
  }

  stockTakeSummary(take: RawStockTake): {
    counted: number;
    positive: number;
    negative: number;
    unresolved: number;
  } {
    const variances = take.lines.map(line =>
      this.stockTakeVariance(take, line.rawStockTakeLineId));
    return {
      counted: variances.filter(value => value !== null).length,
      positive: variances.reduce<number>(
        (total, value) => total + (value !== null && value > 0 ? value : 0), 0),
      negative: Math.abs(variances.reduce<number>(
        (total, value) => total + (value !== null && value < 0 ? value : 0), 0)),
      unresolved: variances.filter(value => value === null).length
    };
  }

  /**
   * Reviewer note: Coordinates the create write off interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  createWriteOff(): void {
    // The API calculates financial impact and decides whether independent approval is required.
    if (this.writeOffForm.invalid) {
      this.writeOffForm.markAllAsTouched();
      this.focusFirstInvalid();
      return;
    }
    this.run(
      this.operational.createWriteOff(this.writeOffForm.getRawValue()),
      'Raw-stock write-off submitted.',
      () => {
        this.writeOffForm.patchValue({ quantity: 0, condition: '', notes: '' });
        this.loadAll();
      });
  }

  /**
   * Reviewer note: Encapsulates the decide write off view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  async decideWriteOff(item: RawStockWriteOff, approved: boolean): Promise<void> {
    const result = await this.confirmation.ask({
      title: approved ? 'Approve write-off' : 'Reject write-off',
      message: `${approved ? 'Approve' : 'Reject'} ${item.quantity} units of ${item.itemName}?`,
      confirmLabel: approved ? 'Approve' : 'Reject',
      reasonLabel: 'Decision reason',
      reasonRequired: true,
      tone: approved ? 'warning' : 'danger'
    });
    if (!result.confirmed) return;
    this.run(this.operational.decideWriteOff(item.rawStockWriteOffId, {
      approved,
      reason: result.reason,
      rowVersion: item.rowVersion
    }), `Write-off ${approved ? 'approved' : 'rejected'}.`, () => this.loadAll());
  }

  /**
   * Reviewer note: Coordinates the save reason interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveReason(): void {
    if (this.reasonForm.invalid) {
      this.reasonForm.markAllAsTouched();
      this.focusFirstInvalid();
      return;
    }
    this.run(
      this.operational.saveReason(null, this.reasonForm.getRawValue()),
      'Operational reason created.',
      () => {
        this.reasonForm.reset({
          categoryCode: 'WriteOff',
          isActive: true
        });
        this.loadAll();
      });
  }

  /**
   * Reviewer note: Encapsulates the status tone view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  statusTone(status: string): string {
    if (status.includes('Pending') || status === 'Submitted') return 'warning';
    if (status === 'Rejected' || status === 'Cancelled') return 'danger';
    return '';
  }

  /**
   * Reviewer note: Encapsulates the run view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private run<T>(
    request: import('rxjs').Observable<T>,
    message: string,
    next: () => void
  ): void {
    this.loading = true;
    request.pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: () => {
        this.notifications.success(message);
        next();
      },
      error: error => this.notifications.error(
        error?.error?.message || 'The operation could not be completed.')
    });
  }

  private focusFirstInvalid(): void {
    queueMicrotask(() =>
      document.querySelector<HTMLElement>(
        '.ops-main input.ng-invalid, .ops-main select.ng-invalid, .ops-main textarea.ng-invalid')
        ?.focus());
  }

  /**
   * Reviewer note: Coordinates the create receipt line interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private createReceiptLine(initial?: {
    supplierOrderLineId?: string;
    rawStockItemId?: number;
    quantityReceived?: number;
    acceptedQuantity?: number;
    rejectedQuantity?: number;
    unitCost?: number | null;
    expectedUnitCost?: number | null;
    unitOfMeasure?: string;
  }) {
    return this.fb.nonNullable.group({
      supplierOrderLineId: [initial?.supplierOrderLineId ?? ''],
      buyerProcurementItemId: [''],
      rawStockItemId: [
        initial?.rawStockItemId ?? 0,
        Validators.min(1)
      ],
      quantityReceived: [
        initial?.quantityReceived ?? 0,
        Validators.min(.001)
      ],
      acceptedQuantity: [
        initial?.acceptedQuantity ?? 0,
        Validators.min(0)
      ],
      rejectedQuantity: [
        initial?.rejectedQuantity ?? 0,
        Validators.min(0)
      ],
      unitCost: new FormControl<number | null>(
        initial?.unitCost ?? null,
        [Validators.required, Validators.min(.001)]),
      expectedUnitCost: new FormControl<number | null>(
        initial?.expectedUnitCost ?? null),
      unitOfMeasure: [
        initial?.unitOfMeasure ?? 'kg',
        Validators.required
      ],
      bestBeforeAtUtc: [''],
      notes: ['']
    });
  }

  /**
   * Reviewer note: Coordinates the reset receipt lines interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private resetReceiptLines(): void {
    this.receiptLines.clear();
    this.receiptLines.push(this.createReceiptLine());
  }

  /**
   * Reviewer note: Encapsulates the number or null view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private numberOrNull(value: string): number | null {
    const parsed = Number(value);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  }

  /**
   * Reviewer note: Encapsulates the local date time view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private localDateTime(value = new Date()): string {
    const local = new Date(value.getTime() - value.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 16);
  }
}
