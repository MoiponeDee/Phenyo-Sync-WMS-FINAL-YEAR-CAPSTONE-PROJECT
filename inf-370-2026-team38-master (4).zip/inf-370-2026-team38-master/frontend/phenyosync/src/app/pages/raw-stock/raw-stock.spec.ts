import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { vi } from 'vitest';
import { AuthorizationService } from '../../services/authorization';
import { RawStockComponent } from './raw-stock';

describe('RawStockComponent', () => {
  let component: RawStockComponent;
  let fixture: ComponentFixture<RawStockComponent>;
  let authorization: AuthorizationService;

  beforeEach(async () => {
    vi.spyOn(RawStockComponent.prototype, 'loadAll').mockImplementation(() => undefined);
    await TestBed.configureTestingModule({
      imports: [RawStockComponent],
      providers: [provideHttpClient(), provideRouter([])]
    }).compileComponents();
    fixture = TestBed.createComponent(RawStockComponent);
    component = fixture.componentInstance;
    authorization = TestBed.inject(AuthorizationService);
    authorization.session.set({
      userId: 4,
      email: 'warehouse.manager@example.invalid',
      role: 'Warehouse Manager',
      roleCode: 'WarehouseManager',
      isActive: true,
      permissions: [
        {
          permissionId: 1,
          code: 'RawStock.Manage',
          displayName: 'Manage raw stock',
          module: 'Raw Stock'
        },
        {
          permissionId: 2,
          code: 'RawStock.View',
          displayName: 'View raw stock',
          module: 'Raw Stock'
        }
      ]
    });
  });

  it('aligns Health with its status and Actions with the accurate master-data action', () => {
    component.inventory = [{
      rawStockItemId: 7,
      rawStockBalanceId: 9,
      itemCode: 'RAW-CARROT',
      itemName: 'Loose carrots',
      categoryCode: 'Produce',
      unitOfMeasure: 'kg',
      warehouseSectionId: 2,
      warehouseSection: 'Storage Area',
      quantityOnHand: 10,
      reservedQuantity: 0,
      weightedAverageUnitCost: 8.5,
      hasCriticalAlert: false,
      isProduce: true,
      isActive: true,
      canDelete: false,
      canDeactivate: true,
      rowVersion: ''
    }];

    fixture.detectChanges();

    const headers = [...fixture.nativeElement.querySelectorAll('.ops-table thead th')]
      .map((cell: HTMLElement) => cell.textContent?.trim());
    const cells = [...fixture.nativeElement.querySelectorAll('.ops-table tbody tr:first-child td')]
      .map((cell: HTMLElement) => cell.textContent?.trim());
    expect(headers[6]).toBe('Health');
    expect(cells[6]).toBe('Healthy');
    expect(headers[7]).toBe('Actions');
    expect(cells[7]).toBe('Deactivate item');
  });

  it('summarises positive and negative stock-take variances without clamping losses', () => {
    const take = {
      rawStockTakeSessionId: 12,
      warehouseSection: 'Raw Stock',
      startedBy: 'Warehouse Manager',
      createdAtUtc: '2026-09-24T08:00:00Z',
      periodStartUtc: '2026-09-01T00:00:00Z',
      periodEndUtc: '2026-09-23T23:59:59Z',
      status: 'Draft',
      managementApprovalRequired: false,
      correlationId: 'test',
      rowVersion: 'version',
      lines: [
        {
          rawStockTakeLineId: 1,
          rawStockItemId: 1,
          itemCode: 'RAW-1',
          itemName: 'Carrots',
          isMapped: true,
          openingRawStock: 10,
          rawStockReceived: 5,
          approvedPositiveAdjustments: 0,
          existingPackedProductWeight: 4,
          recordedRawStockWriteOffs: 0,
          approvedNegativeAdjustments: 0,
          estimatedRawStockRemaining: 11,
          managementApprovalRequired: false,
          rowVersion: 'line-1'
        },
        {
          rawStockTakeLineId: 2,
          rawStockItemId: 2,
          itemCode: 'RAW-2',
          itemName: 'Potatoes',
          isMapped: false,
          openingRawStock: 8,
          rawStockReceived: 0,
          approvedPositiveAdjustments: 0,
          existingPackedProductWeight: 0,
          recordedRawStockWriteOffs: 0,
          approvedNegativeAdjustments: 0,
          estimatedRawStockRemaining: 8,
          managementApprovalRequired: false,
          rowVersion: 'line-2'
        }
      ]
    };
    component.counts = { 1: 7, 2: null };

    expect(component.stockTakeVariance(take, 1)).toBe(-4);
    expect(component.stockTakeSummary(take)).toEqual({
      counted: 1,
      positive: 0,
      negative: 4,
      unresolved: 1
    });
  });

  it('shows the Operations Manager decision queue without exposing warehouse tabs', () => {
    authorization.session.set({
      userId: 8,
      email: 'operations.manager@example.invalid',
      role: 'Operations Manager',
      roleCode: 'OperationsManager',
      isActive: true,
      permissions: [
        { permissionId: 2, code: 'RawStockTakes.View', displayName: 'View takes', module: 'Raw Stock' },
        { permissionId: 3, code: 'RawStockTakes.Approve', displayName: 'Approve takes', module: 'Raw Stock' }
      ]
    });
    component.tab = 'takes';
    component.stockTakes = [{
      rawStockTakeSessionId: 22,
      warehouseSection: 'Raw Stock',
      startedBy: 'Warehouse Manager',
      createdAtUtc: '2026-09-24T08:00:00Z',
      submittedAtUtc: '2026-09-24T09:00:00Z',
      reviewedBy: 'Warehouse Manager',
      reviewedAtUtc: '2026-09-24T10:00:00Z',
      periodStartUtc: '2026-09-01T00:00:00Z',
      periodEndUtc: '2026-09-23T23:59:59Z',
      status: 'PendingManagementApproval',
      managementApprovalRequired: true,
      correlationId: 'approval-test',
      rowVersion: 'version',
      lines: []
    }];

    fixture.detectChanges();
    const text = (fixture.nativeElement as HTMLElement).textContent ?? '';

    expect(text).toContain('Awaiting Operations Manager approval');
    expect(text).toContain('Approve and post');
    expect(text).toContain('Reject');
    expect(text).not.toContain('Receive stock');
    expect(text).not.toContain('Open a raw-stock take');
  });

  it('focuses the first invalid Stock Take control and shows a useful message', async () => {
    authorization.session.set({
      userId: 4,
      email: 'warehouse.manager@example.invalid',
      role: 'Warehouse Manager',
      roleCode: 'WarehouseManager',
      isActive: true,
      permissions: [
        { permissionId: 2, code: 'RawStockTakes.View', displayName: 'View takes', module: 'Raw Stock' },
        { permissionId: 3, code: 'RawStockTakes.Capture', displayName: 'Capture takes', module: 'Raw Stock' }
      ]
    });
    component.tab = 'takes';
    fixture.detectChanges();

    component.createStockTake();
    await Promise.resolve();
    fixture.detectChanges();

    const section = fixture.nativeElement.querySelector(
      'select[formcontrolname="warehouseSectionId"]') as HTMLSelectElement;
    expect(document.activeElement).toBe(section);
    expect((fixture.nativeElement as HTMLElement).textContent)
      .toContain('Select a warehouse section.');
  });
});
