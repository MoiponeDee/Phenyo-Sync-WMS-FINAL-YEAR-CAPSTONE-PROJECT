/**
 * Reviewer guide: Coordinates the delivery details page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize, take, timeout } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { DeliveryDetail, DeliveryService } from '../../services/delivery';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import { AuthorizationService } from '../../services/authorization';

@Component({
  selector: 'app-delivery-details',
  standalone: true,
  imports: [CommonModule, TopbarComponent],
  templateUrl: './delivery-details.html',
  styleUrl: './delivery-details.css'
})
/** Displays the authoritative delivery, assignment and status histories. */
export class DeliveryDetails implements OnInit {
  deliveryId = 0;
  delivery: DeliveryDetail | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  actionLoading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private deliveriesApi: DeliveryService,
    private changeDetector: ChangeDetectorRef,
    private confirmation: ConfirmationService,
    private notifications: NotificationService,
    private authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Calculates is driver for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get isDriver(): boolean {
    return this.authorization.session()?.roleCode === 'Driver';
  }

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.deliveryId = Number(this.route.snapshot.paramMap.get('id'));
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.deliveriesApi.get(this.deliveryId).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: delivery => this.delivery = delivery,
      error: error => this.errorMessage = error?.error?.message || 'Unable to load delivery details.'
    });
  }

  /**
   * Reviewer note: Coordinates the start interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async start(): Promise<void> {
    if (!this.delivery?.canStart) return;
    const confirmation = await this.confirmation.ask({
      title: 'Start delivery',
      message: 'Confirm that the order has been loaded and the delivery is starting now.',
      confirmLabel: 'Start delivery'
    });
    if (!confirmation.confirmed) return;
    this.actionLoading = true;
    this.deliveriesApi.start(this.deliveryId).pipe(
      take(1),
      finalize(() => {
        this.actionLoading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.delivery = result.delivery;
        this.notifications.success(result.message);
      },
      error: error => this.errorMessage = error?.error?.message || 'Unable to start delivery.'
    });
  }

  /**
   * Reviewer note: Coordinates the complete interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  complete(): void {
    this.router.navigate(['/deliveries', this.deliveryId, 'complete']);
  }

  /**
   * Reviewer note: Encapsulates the proof view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  proof(): void {
    this.router.navigate(['/deliveries', this.deliveryId, 'proof']);
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.router.navigate([
      this.authorization.session()?.roleCode === 'Driver'
        ? '/my-deliveries'
        : '/deliveries'
    ]);
  }
}
