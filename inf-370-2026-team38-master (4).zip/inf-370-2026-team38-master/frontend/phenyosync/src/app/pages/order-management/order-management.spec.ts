/**
 * Reviewer guide: Verifies the order management frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { AuthorizationService } from '../../services/authorization';
import { OrderService } from '../../services/order';
import { OrderManagement } from './order-management';

// Covers the order management behavior most likely to regress across permissions and workflow changes.
describe('OrderManagement', () => {
  // Reviewer note: Guards the observable rule that shows only actions backed by their exact permissions.
  it('shows only actions backed by their exact permissions', () => {
    const granted = new Set(['Orders.View', 'Packing.View']);
    const authorization = {
      has: (permission: string) => granted.has(permission)
    } as AuthorizationService;

    const component = new OrderManagement(
      authorization,
      {} as OrderService
    );

    expect(component.visibleActions.map(action => action.route))
      .toEqual(['/search-orders', '/view-pick-list']);
  });
});
