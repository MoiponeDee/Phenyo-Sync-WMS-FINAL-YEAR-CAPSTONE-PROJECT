/**
 * Reviewer guide: Coordinates the order management page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { finalize, take, timeout } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { AuthorizationService } from '../../services/authorization';
import {
  ExternalOrderSubmission,
  GoogleOrderSyncResult,
  OrderService
} from '../../services/order';

interface OrderAction {
  readonly title: string;
  readonly text: string;
  readonly route: string;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  readonly permission: string;
}

@Component({
  selector: 'app-order-management',
  standalone: true,
  imports: [CommonModule, RouterLink, TopbarComponent],
  templateUrl: './order-management.html',
  styleUrl: './order-management.css'
})
/** Presents commercial order review actions using backend-provided eligibility and results. */
export class OrderManagement implements OnInit {
  private readonly actions: readonly OrderAction[] = [
    {
      title: 'Share Customer Form',
      text: 'Open or share the configured Google Form for customer requests.',
      route: '/send-order-link',
      permission: 'Orders.SendLink'
    },
    {
      title: 'Create Order',
      text: 'Capture a sales order with server-controlled pricing.',
      route: '/create-order',
      permission: 'Orders.Create'
    },
    {
      title: 'Search Orders',
      text: 'Inspect orders, validation outcomes, invoices, and workflow state.',
      route: '/search-orders',
      permission: 'Orders.View'
    },
    {
      title: 'Packing Queue',
      text: 'View FEFO batch allocations and orders ready for packing.',
      route: '/view-pick-list',
      permission: 'Packing.View'
    }
  ];

  submissions: ExternalOrderSubmission[] = [];
  lastSync: GoogleOrderSyncResult | null = null;
  syncing = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loadingSubmissions = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  syncError = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly authorization: AuthorizationService,
    private readonly orders: OrderService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    if (this.canViewOrders) this.loadSubmissions();
  }

  /**
   * Reviewer note: Calculates visible actions for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get visibleActions(): readonly OrderAction[] {
    return this.actions.filter(action =>
      this.authorization.has(action.permission));
  }

  /**
   * Reviewer note: Calculates can sync for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canSync(): boolean {
    return this.authorization.has('Orders.Create');
  }

  /**
   * Reviewer note: Calculates can view orders for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canViewOrders(): boolean {
    return this.authorization.has('Orders.View');
  }

  /**
   * Reviewer note: Encapsulates the sync google orders view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  syncGoogleOrders(): void {
    // A manual sync asks the backend to read configured form rows and apply durable idempotency.
    if (!this.canSync || this.syncing) return;
    this.syncError = '';
    this.lastSync = null;
    this.syncing = true;
    this.orders.syncGoogleFormOrders().pipe(
      take(1),
      timeout(30000),
      finalize(() => this.syncing = false)
    ).subscribe({
      next: result => {
        this.lastSync = result;
        this.loadSubmissions();
      },
      error: error => {
        this.syncError = this.errorMessage(
          error,
          'Google Form responses could not be synchronised.');
      }
    });
  }

  /**
   * Reviewer note: Coordinates load submissions so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadSubmissions(): void {
    if (this.loadingSubmissions) return;
    this.loadingSubmissions = true;
    this.orders.recentExternalSubmissions().pipe(
      take(1),
      timeout(15000),
      finalize(() => this.loadingSubmissions = false)
    ).subscribe({
      next: submissions => this.submissions = submissions,
      error: error => {
        this.syncError = this.errorMessage(
          error,
          'Recent external submissions could not be loaded.');
      }
    });
  }

  /**
   * Reviewer note: Converts error message into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorMessage(error: unknown, fallback: string): string {
    if (error instanceof HttpErrorResponse) {
      return error.error?.message ||
        (error.status === 0
          ? 'The backend API is unavailable.'
          : fallback);
    }
    return fallback;
  }
}
