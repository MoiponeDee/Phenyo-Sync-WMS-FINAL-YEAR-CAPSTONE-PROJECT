/**
 * Reviewer guide: Coordinates the buyer dashboard page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';

// Presents procurement work derived from the buyer's authorized dashboard data.
@Component({
  selector: 'app-buyer-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, TopbarComponent, SidebarComponent],
  templateUrl: './buyer-dashboard.html'
})
export class BuyerDashboardComponent {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Buyer Dashboard', route: '/buyer-dashboard', active: true },
    { name: 'Raw Stock Availability', route: '/raw-stock' },
    { name: 'Supplier Directory', route: '/suppliers' },
    { name: 'Help Center', route: '/help' }
  ];
}
