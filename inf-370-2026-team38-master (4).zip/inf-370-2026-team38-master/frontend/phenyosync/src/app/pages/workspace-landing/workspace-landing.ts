/**
 * Reviewer guide: Coordinates the workspace landing page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import {
  NavigationItem,
  NavigationSection,
  WMS_NAVIGATION
} from '../../navigation/navigation.config';
import { AuthorizationService } from '../../services/authorization';

// Routes each authenticated user toward features exposed by their effective permissions.
@Component({
  selector: 'app-workspace-landing',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './workspace-landing.html',
  styleUrl: './workspace-landing.css'
})
export class WorkspaceLanding implements OnInit, OnDestroy {
  section?: NavigationSection;
  // Reviewer note: Retains a disposable browser or device resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  private readonly subscriptions = new Subscription();

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly route: ActivatedRoute,
    readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.subscriptions.add(
      this.route.paramMap.subscribe(parameters => {
        const key = parameters.get('section');
        this.section = WMS_NAVIGATION.find(item => item.key === key);
      })
    );
  }

  /**
   * Reviewer note: Releases subscriptions or device resources when the view is left to prevent duplicate background work.
   * Cleanup stops stale callbacks from mutating a page that is no longer active.
   */
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  /**
   * Reviewer note: Calculates visible items for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  visibleItems(): NavigationItem[] {
    return (this.section?.items ?? []).filter(item =>
      !item.permissions?.length ||
      this.authorization.hasAny(...item.permissions)
    );
  }
}
