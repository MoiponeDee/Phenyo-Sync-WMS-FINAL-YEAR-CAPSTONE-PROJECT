/**
 * Reviewer guide: Coordinates the account security page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, forkJoin } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import {
  AuthService,
  RecoveryCodeStatus,
  TrustedDevice
} from '../../services/auth';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';

@Component({
  selector: 'app-account-security',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  templateUrl: './account-security.html',
  styleUrl: './account-security.css'
})
/** Manages trusted devices and recovery codes without exposing stored security hashes. */
export class AccountSecurity implements OnInit {
  devices: TrustedDevice[] = [];
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  recoveryStatus: RecoveryCodeStatus | null = null;
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  currentPassword = '';
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  recoveryCodes: string[] = [];
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private auth: AuthService,
    private confirmations: ConfirmationService,
    private notifications: NotificationService,
    private changeDetector: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.errorMessage = '';
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      devices: this.auth.trustedDevices(),
      status: this.auth.recoveryCodeStatus()
    }).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.devices = result.devices;
        this.recoveryStatus = result.status;
      },
      error: error => this.errorMessage =
        error.error?.message || 'Unable to load account security details.'
    });
  }

  /**
   * Reviewer note: Coordinates the revoke interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async revoke(device: TrustedDevice): Promise<void> {
    const result = await this.confirmations.ask({
      title: 'Revoke trusted device',
      message: `Revoke "${device.deviceName}"? It will require email verification at the next login.`,
      confirmLabel: 'Revoke Device',
      tone: 'warning'
    });
    if (!result.confirmed) return;
    this.saving = true;
    this.auth.revokeTrustedDevice(device.trustedDeviceId).pipe(
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.load();
      },
      error: error => this.notifications.error(
        error.error?.message || 'The trusted device could not be revoked.')
    });
  }

  /**
   * Reviewer note: Coordinates the revoke all interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async revokeAll(): Promise<void> {
    const result = await this.confirmations.ask({
      title: 'Revoke all trusted devices',
      message: 'Every browser will require email verification after its next password login.',
      confirmLabel: 'Revoke All',
      tone: 'danger'
    });
    if (!result.confirmed) return;
    this.saving = true;
    this.auth.revokeAllTrustedDevices().pipe(
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.load();
      },
      error: error => this.notifications.error(
        error.error?.message || 'Trusted devices could not be revoked.')
    });
  }

  /**
   * Reviewer note: Encapsulates the regenerate view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  async regenerate(): Promise<void> {
    this.errorMessage = '';
    if (!this.currentPassword) {
      this.errorMessage = 'Enter your current password.';
      queueMicrotask(() => document.getElementById('currentPassword')?.focus());
      return;
    }
    const result = await this.confirmations.ask({
      title: 'Replace recovery codes',
      message: 'Every unused code from the previous set will stop working.',
      confirmLabel: 'Generate New Codes',
      tone: 'warning'
    });
    if (!result.confirmed) return;
    this.saving = true;
    this.auth.regenerateRecoveryCodes(this.currentPassword).pipe(
      finalize(() => {
        this.saving = false;
        this.currentPassword = '';
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.recoveryCodes = [...response.recoveryCodes];
        this.recoveryStatus = response.status;
        this.notifications.success(response.message);
      },
      error: error => this.errorMessage =
        error.error?.message || 'Recovery codes could not be generated.'
    });
  }

  /**
   * Reviewer note: Encapsulates the download view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  download(): void {
    if (!this.recoveryCodes.length) return;
    const url = URL.createObjectURL(new Blob([
      ['PhenyoSync one-time recovery codes', '', ...this.recoveryCodes].join('\n')
    ], { type: 'text/plain' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'PhenyoSync-Recovery-Codes.txt';
    link.click();
    URL.revokeObjectURL(url);
  }

  /**
   * Reviewer note: Encapsulates the clear codes view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearCodes(): void {
    this.recoveryCodes = [];
  }
}
