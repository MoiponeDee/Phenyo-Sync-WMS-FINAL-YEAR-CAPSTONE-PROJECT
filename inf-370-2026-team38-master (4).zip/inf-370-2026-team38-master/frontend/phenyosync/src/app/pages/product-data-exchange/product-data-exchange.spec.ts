import { ChangeDetectorRef } from '@angular/core';
import { Location } from '@angular/common';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import { ProductDataExchangeService } from '../../services/product-data-exchange';
import { ProductLookupService } from '../../services/product-lookups';
import { ProductDataExchange } from './product-data-exchange';

describe('ProductDataExchange workflow', () => {
  it('previews every validation outcome before import and exposes import errors', () => {
    const validation = {
      validationToken: 'token', expiresAtUtc: '', totalRows: 2,
      validRows: 1, warningRows: 0, invalidRows: 1,
      rows: [
        { rowNumber: 7, status: 'Valid', action: 'Update', recordKey: 'A', messages: [] },
        { rowNumber: 8, status: 'Invalid', action: 'Create', recordKey: 'B', messages: ['PriceBasis is invalid.'] }
      ]
    };
    const component = new ProductDataExchange(
      { validate: vi.fn().mockReturnValue(of(validation)) } as unknown as ProductDataExchangeService,
      {} as ProductLookupService,
      { has: () => true } as unknown as AuthorizationService,
      {} as ConfirmationService,
      { warning: vi.fn(), success: vi.fn(), error: vi.fn() } as unknown as NotificationService,
      { detectChanges: vi.fn() } as unknown as ChangeDetectorRef,
      {} as Location
    );
    component.selectedFile = new File(['workbook'], 'products.xlsx');

    component.validateWorkbook();

    expect(component.validation?.rows).toHaveLength(2);
    expect(component.validation?.invalidRows).toBe(1);
    expect(component.importing).toBe(false);
  });
});
