/**
 * Reviewer guide: Coordinates the product data exchange page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule, Location } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { finalize, forkJoin, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import {
  DataExchangeResult,
  DataExchangeValidation,
  ProductDataExchangeService
} from '../../services/product-data-exchange';
import {
  ProductCategory,
  ProductLookupService,
  ProductType
} from '../../services/product-lookups';

@Component({
  selector: 'app-product-data-exchange',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, TopbarComponent],
  templateUrl: './product-data-exchange.html',
  styleUrls: ['../phase-b.css']
})
/** Guides the operator through template/export, validation preview, import and result download. */
export class ProductDataExchange implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  categories: ProductCategory[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  types: ProductType[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  filters = {
    productCategoryId: null as number | null,
    productTypeId: null as number | null,
    productStatus: '',
    priceStatus: '',
    includeInactive: false,
    effectiveAtUtc: ''
  };
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedFile: File | null = null;
  validation: DataExchangeValidation | null = null;
  result: DataExchangeResult | null = null;
  importReason = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loadingMetadata = false;
  exporting = false;
  validating = false;
  importing = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private exchange: ProductDataExchangeService,
    private lookups: ProductLookupService,
    readonly authorization: AuthorizationService,
    private confirmations: ConfirmationService,
    private notifications: NotificationService,
    private changeDetector: ChangeDetectorRef,
    private location: Location
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.loadingMetadata = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      categories: this.lookups.getProductCategories('', ''),
      types: this.lookups.getProductTypes('', '')
    }).pipe(
      take(1),
      finalize(() => {
        this.loadingMetadata = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.categories = result.categories;
        this.types = result.types;
      },
      error: error => this.errorMessage = this.errorText(error, 'Unable to load the export filters.')
    });
  }

  /**
   * Reviewer note: Calculates can export for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canExport(): boolean {
    return this.authorization.has('ProductDataExchange.Export');
  }

  /**
   * Reviewer note: Calculates can import for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canImport(): boolean {
    return this.authorization.has('ProductDataExchange.Import');
  }

  /**
   * Reviewer note: Encapsulates the download template view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  downloadTemplate(): void {
    if (this.exporting) return;
    this.exporting = true;
    this.exchange.template().pipe(
      take(1),
      finalize(() => {
        this.exporting = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: blob => this.download(blob, 'PhenyoSync-Product-Price-Template.xlsx'),
      error: error => this.notifications.error(this.errorText(error, 'The Excel template could not be downloaded.'))
    });
  }

  /**
   * Reviewer note: Coordinates the export workbook interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  exportWorkbook(): void {
    if (this.exporting) return;
    this.exporting = true;
    this.exchange.export(this.filters).pipe(
      take(1),
      finalize(() => {
        this.exporting = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: blob => {
        this.download(blob, `PhenyoSync-Product-Price-Catalogue-${this.today()}.xlsx`);
        this.notifications.success('The product and price workbook was exported.');
      },
      error: error => this.notifications.error(this.errorText(error, 'The workbook could not be exported.'))
    });
  }

  /**
   * Reviewer note: Encapsulates the choose file view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  chooseFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.selectedFile = input.files?.[0] ?? null;
    this.validation = null;
    this.result = null;
    this.errorMessage = '';
  }

  /**
   * Reviewer note: Encapsulates the validate workbook view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  validateWorkbook(): void {
    // Validation creates a read-only server job; no product is changed at this stage.
    if (!this.selectedFile || this.validating) return;
    this.validating = true;
    this.validation = null;
    this.result = null;
    this.errorMessage = '';
    this.exchange.validate(this.selectedFile).pipe(
      take(1),
      finalize(() => {
        this.validating = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: validation => {
        this.validation = validation;
        if (validation.invalidRows) {
          this.notifications.warning('Validation completed with rows that must be corrected.');
        } else {
          this.notifications.success('The workbook passed validation and is ready for confirmation.');
        }
      },
      error: error => this.errorMessage = this.errorText(error, 'The workbook could not be validated.')
    });
  }

  /**
   * Reviewer note: Encapsulates the apply import view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  async applyImport(): Promise<void> {
    if (!this.validation || this.validation.invalidRows || this.importing) return;
    if (this.importReason.trim().length < 5) {
      this.notifications.warning('Enter a business reason of at least five characters.');
      return;
    }
    const confirmation = await this.confirmations.ask({
      title: 'Apply validated Excel import',
      message: `${this.validation.validRows} validated row(s) will create or update product and versioned price data.`,
      confirmLabel: 'Apply import',
      tone: 'warning'
    });
    if (!confirmation.confirmed) return;
    this.importing = true;
    this.exchange.import(this.validation.validationToken, this.importReason).pipe(
      take(1),
      finalize(() => {
        this.importing = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.result = result;
        this.validation = null;
        this.notifications.success(result.message);
      },
      error: error => this.notifications.error(this.errorText(error, 'The validated workbook could not be imported.'))
    });
  }

  /**
   * Reviewer note: Encapsulates the download result view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  downloadResult(): void {
    // Result tokens are opaque and short-lived, avoiding local reconstruction of import outcomes.
    if (!this.result) return;
    this.exchange.result(this.result.resultToken).pipe(take(1)).subscribe({
      next: blob => this.download(blob, `PhenyoSync-Product-Import-Result-${this.today()}.xlsx`),
      error: error => this.notifications.error(this.errorText(error, 'The result workbook could not be downloaded.'))
    });
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.location.back();
  }

  /**
   * Reviewer note: Encapsulates the download view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private download(blob: Blob, fileName: string): void {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(url);
  }

  /**
   * Reviewer note: Encapsulates the today view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private today(): string {
    return new Date().toISOString().slice(0, 10);
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    const response = error as HttpErrorResponse;
    return response.error?.message || response.error?.title || fallback;
  }
}
