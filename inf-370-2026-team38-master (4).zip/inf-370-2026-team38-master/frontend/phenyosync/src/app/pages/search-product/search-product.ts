/**
 * Reviewer guide: Coordinates the search product page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

import {
  finalize,
  take,
  timeout
} from 'rxjs';

import {
  ProductResponse,
  ProductSearchFilters,
  ProductService
} from '../../services/product';
import { ProductCategory, ProductLookupService, ProductType } from '../../services/product-lookups';
import { AuthorizationService } from '../../services/authorization';
import { SearchFieldComponent } from '../../components/search-field/search-field';

@Component({
  selector: 'app-search-product',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    SearchFieldComponent
  ],
  templateUrl: './search-product.html',
  styleUrl: './search-product.css'
})
/** Provides filterable product discovery and links into the master Product Details view. */
export class SearchProduct implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  products: ProductResponse[] = [];

  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  productTypes: ProductType[] = [];

  productCategories:
    ProductCategory[] = [];

  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  searchTerm = '';
  productTypeId: number | null = null;
  productCategoryId: number | null = null;
  status = '';

  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  initialLoadComplete = false;

  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private productService: ProductService,
    private lookupService: ProductLookupService,
    readonly authorization: AuthorizationService,
    private changeDetector: ChangeDetectorRef,
    private router: Router
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.loadLookups();
    this.loadInitialProducts();
  }

  /**
   * Reviewer note: Coordinates load lookups so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadLookups(): void {
    this.lookupService.getActiveProductTypes().pipe(take(1)).subscribe({
      next: values => this.productTypes = values,
      error: error => this.handleError(error, 'Unable to load product types.')
    });
    this.lookupService.getActiveProductCategories().pipe(take(1)).subscribe({
      next: values => this.productCategories = values,
      error: error => this.handleError(error, 'Unable to load product categories.')
    });
  }

  /**
   * Reviewer note: Coordinates load initial products so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadInitialProducts(): void {
    this.loading = true;
    this.errorMessage = '';

    this.productService
      .getProducts()
      .pipe(
        take(1),
        timeout(15000),
        finalize(() => {
          this.loading = false;
          this.initialLoadComplete = true;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe({
        next: (products: ProductResponse[]) => {
          this.products = this.sortProducts(products);

        },

        error: (error: unknown) => {
          this.handleError(
            error,
            'Unable to load products.'
          );
        }
      });
  }

  /**
   * Reviewer note: Coordinates search products so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  searchProducts(): void {
    if (this.loading) {
      return;
    }

    this.errorMessage = '';

    const filters: ProductSearchFilters = {
      searchTerm: this.searchTerm,
      productTypeId: this.productTypeId,
      productCategoryId:
        this.productCategoryId,

      status: this.status
    };

    this.loading = true;

    this.productService
      .searchProducts(filters)
      .pipe(
        take(1),
        timeout(15000),
        finalize(() => {
          this.loading = false;
          this.initialLoadComplete = true;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe({
        next: (products: ProductResponse[]) => {
          this.products =
            this.sortProducts(products);
        },

        error: (error: unknown) => {
          this.products = [];

          this.handleError(
            error,
            'Unable to search for products.'
          );
        }
      });
  }

  /**
   * Reviewer note: Encapsulates the clear filters view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearFilters(): void {
    if (this.loading) {
      return;
    }

    this.searchTerm = '';
    this.productTypeId = null;
    this.productCategoryId = null;
    this.status = '';
    this.errorMessage = '';

    this.searchProducts();
  }

  /**
   * Reviewer note: Coordinates the cancel interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  cancel(): void {
    if (this.loading) {
      return;
    }

    this.router.navigate(['/dashboard']);
  }

  /**
   * Reviewer note: Coordinates select product so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectProduct(productId: number): void {
    if (this.authorization.has('Products.Update')) {
      this.router.navigate(['/update-product'], { queryParams: { productId } });
    }
  }

  /**
   * Reviewer note: Encapsulates the view product view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  viewProduct(productId: number): void {
    this.router.navigate(['/products', productId, 'details']);
  }

  productAvailability(product: ProductResponse): string {
    const kilograms = new Intl.NumberFormat('en-ZA', {
      maximumFractionDigits: 2
    }).format(product.totalAvailableQuantityKg);

    if (product.isVariableWeight || !product.kilogramsPerUnit) {
      return `${kilograms} kg`;
    }

    const wholeUnits = Math.floor(
      product.totalAvailableQuantityKg / product.kilogramsPerUnit);
    const unit = product.sellingUnit || 'unit';
    const unitLabel = wholeUnits === 1 ? unit : `${unit}s`;
    return `${wholeUnits} ${unitLabel} · ${kilograms} kg`;
  }

  /**
   * Reviewer note: Encapsulates the sort products view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private sortProducts(
    products: ProductResponse[]
  ): ProductResponse[] {
    return [...products].sort(
      (first, second) => {
        const nameComparison =
          first.productName.localeCompare(
            second.productName
          );

        if (nameComparison !== 0) {
          return nameComparison;
        }

        return first.size.localeCompare(
          second.size
        );
      }
    );
  }

  /**
   * Reviewer note: Converts handle error into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private handleError(
    error: unknown,
    fallbackMessage: string
  ): void {
    console.error(
      'Search product error:',
      error
    );

    if (
      error instanceof Error &&
      error.name === 'TimeoutError'
    ) {
      this.errorMessage =
        'The request timed out. Check that the backend API is running.';

      return;
    }

    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) {
        this.errorMessage =
          'Cannot connect to the backend. Check the API URL, HTTPS certificate and CORS settings.';

        return;
      }

      if (error.status === 400) {
        this.errorMessage =
          error.error?.message ||
          this.getValidationMessage(error) ||
          'The search filters are invalid.';

        return;
      }

      if (error.status === 401) {
        this.errorMessage =
          'Your login session has expired. Please log in again.';

        return;
      }

      if (error.status === 403) {
        this.errorMessage =
          'You do not have permission to search products.';

        return;
      }

      if (error.status === 500) {
        this.errorMessage =
          error.error?.message ||
          'A server or database error occurred.';

        return;
      }
    }

    this.errorMessage = fallbackMessage;
  }

  /**
   * Reviewer note: Coordinates get validation message so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private getValidationMessage(
    error: HttpErrorResponse
  ): string {
    const validationErrors =
      error.error?.errors as
        Record<string, string[]> | undefined;

    if (!validationErrors) {
      return '';
    }

    return Object.values(validationErrors)
      .flat()
      .join(' ');
  }
}
