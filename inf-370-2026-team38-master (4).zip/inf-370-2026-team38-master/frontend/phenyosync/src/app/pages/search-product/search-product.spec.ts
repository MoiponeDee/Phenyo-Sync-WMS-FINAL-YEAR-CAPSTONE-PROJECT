/**
 * Reviewer guide: Verifies the search product frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import {
  ComponentFixture,
  TestBed
} from '@angular/core/testing';

import {
  provideHttpClient
} from '@angular/common/http';

import {
  provideRouter
} from '@angular/router';
import { Router } from '@angular/router';

import {
  SearchProduct
} from './search-product';
import { AuthorizationService } from '../../services/authorization';
import { vi } from 'vitest';
import { ProductResponse } from '../../services/product';

// Protects product filters, empty states and detail navigation from runtime regressions.
describe('SearchProduct', () => {
  let component: SearchProduct;
  let fixture: ComponentFixture<SearchProduct>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        SearchProduct
      ],
      providers: [
        provideHttpClient(),
        provideRouter([])
      ]
    }).compileComponents();

    fixture =
      TestBed.createComponent(SearchProduct);

    component =
      fixture.componentInstance;
  });

  // Reviewer note: Guards the observable rule that should create.
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Reviewer note: Guards the observable rule that hides product selection when update permission is absent.
  it('hides product selection when update permission is absent', () => {
    vi.spyOn(component, 'loadLookups').mockImplementation(() => undefined);
    vi.spyOn(component, 'loadInitialProducts')
      .mockImplementation(() => undefined);
    TestBed.inject(AuthorizationService).session.set({
      userId: 4,
      email: 'warehouse.manager@example.invalid',
      role: 'Warehouse Manager',
      roleCode: 'WarehouseManager',
      isActive: true,
      permissions: [{
        permissionId: 1,
        code: 'Products.View',
        displayName: 'View products',
        module: 'Products'
      }]
    });

    component.products = [{
      productId: 8,
      productName: 'Prepared Carrots',
      productTypeId: 2,
      productTypeName: 'Prepared Produce',
      productCategoryId: 1,
      productCategoryName: 'Fresh Produce',
      size: '1 unit',
      shelfLifeDays: 5,
      sellingPricePerKg: 18,
      totalAvailableQuantityKg: 10,
      qrCodeValue: 'CARROT-READY',
      status: 'Active',
      createdAt: '2026-08-25T08:00:00Z',
      alertLevel: 'Normal',
      canDelete: false,
      isCommitted: true,
      canDeactivate: true
    }];
    component.initialLoadComplete = true;
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.select-button')).toBeNull();
    expect(fixture.nativeElement.querySelector('.details-button')?.textContent)
      .toContain('View details');
    expect(fixture.nativeElement.textContent).toContain('Prepared Carrots');
  });

  // Reviewer note: Guards the observable rule that opens read-only master Product Details from a search result.
  it('opens read-only master Product Details from a search result', () => {
    const router = TestBed.inject(Router);
    const navigate = vi.spyOn(router, 'navigate').mockResolvedValue(true);

    component.viewProduct(8);

    expect(navigate).toHaveBeenCalledWith(['/products', 8, 'details']);
  });

  it('presents packaged stock as whole sellable units with weight context', () => {
    const result = component.productAvailability({
      totalAvailableQuantityKg: 23.8,
      isVariableWeight: false,
      kilogramsPerUnit: 10,
      sellingUnit: 'bag'
    } as ProductResponse);

    expect(result).toContain('2 bags');
    expect(result).toContain('23');
    expect(result).toContain('kg');
  });
});
