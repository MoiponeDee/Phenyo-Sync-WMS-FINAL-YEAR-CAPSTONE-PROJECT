/**
 * Reviewer guide: Verifies the mobile operations control frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { of } from 'rxjs';
import { vi } from 'vitest';
import { MobileOperationsService } from '../../services/mobile-operations';
import { MobileOperationsControl } from './mobile-operations-control';

// Covers the mobile operations control behavior most likely to regress across permissions and workflow changes.
describe('Track Driver page', () => {
  // Reviewer note: Guards the observable rule that loads tracking-only data and exposes no unrelated mobile actions.
  it('loads tracking-only data and exposes no unrelated mobile actions', () => {
    const operations = {
      activeTracking: vi.fn().mockReturnValue(of([])),
      trackingHistory: vi.fn().mockReturnValue(of([]))
    } as unknown as MobileOperationsService;
    const component = new MobileOperationsControl(operations);

    component.ngOnInit();

    expect(operations.activeTracking).toHaveBeenCalled();
    expect(component.tracking).toEqual([]);
    component.ngOnDestroy();
  });

  it('uses the latest point when an active session history is empty', () => {
    const latest = {
      latitude: -25.75,
      longitude: 28.23,
      capturedAtUtc: '2026-09-10T10:00:00Z',
      receivedAtUtc: '2026-09-10T10:00:01Z'
    };
    const operations = {
      activeTracking: vi.fn().mockReturnValue(of([{
        trackingSessionId: 10,
        driverName: 'Test Driver',
        deliveryId: 4,
        status: 'Active',
        latestLocation: latest
      }])),
      trackingHistory: vi.fn().mockReturnValue(of([]))
    } as unknown as MobileOperationsService;
    const component = new MobileOperationsControl(operations);

    component.ngOnInit();

    expect(component.trackingSeries[0].points).toEqual([latest]);
    component.ngOnDestroy();
  });
});
