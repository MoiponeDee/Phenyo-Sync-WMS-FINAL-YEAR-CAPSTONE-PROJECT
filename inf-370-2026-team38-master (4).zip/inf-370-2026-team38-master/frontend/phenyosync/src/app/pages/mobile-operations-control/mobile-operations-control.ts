/**
 * Reviewer guide: Coordinates the mobile operations control page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription, catchError, finalize, forkJoin, interval, map, of, switchMap } from 'rxjs';
import {
  TrackingMap,
  TrackingMapSeries
} from '../../components/tracking-map/tracking-map';
import { HumanizeCodePipe } from '../../pipes/humanize-code.pipe';
import {
  ActiveTrackingSession,
  DriverLocation,
  MobileOperationsService
} from '../../services/mobile-operations';

@Component({
  selector: 'app-mobile-operations-control',
  standalone: true,
  imports: [
    CommonModule,
    TrackingMap,
    HumanizeCodePipe
  ],
  templateUrl: './mobile-operations-control.html',
  styleUrl: './mobile-operations-control.css'
})
/** Provides tracking-only oversight; Driver delivery execution remains in the Driver workflow. */
export class MobileOperationsControl implements OnInit, OnDestroy {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  tracking: ActiveTrackingSession[] = [];
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  trackingHistory: Record<number, DriverLocation[]> = {};
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  private readonly subscriptions = new Subscription();

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(private readonly operations: MobileOperationsService) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
    this.subscriptions.add(interval(30_000).subscribe(() => {
      if (!this.loading) this.load();
    }));
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    if (this.loading) return;
    this.loading = true;
    this.errorMessage = '';
    this.operations.activeTracking().pipe(
      switchMap(tracking => {
        this.tracking = tracking;
        if (!tracking.length) return of([] as Array<{ sessionId: number; points: DriverLocation[] }>);
        return forkJoin(tracking.map(session =>
          this.operations.trackingHistory(session.trackingSessionId).pipe(
            catchError(() => of([] as DriverLocation[])),
            map(points => ({ sessionId: session.trackingSessionId, points }))
          )
        ));
      }),
      finalize(() => this.loading = false)
    ).subscribe({
      next: results => this.trackingHistory = Object.fromEntries(
        results.map(result => [result.sessionId, result.points])
      ),
      error: error => this.errorMessage =
        error.error?.message ?? 'Driver tracking could not be loaded.'
    });
  }

  /**
   * Reviewer note: Encapsulates the map link view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  mapLink(session: ActiveTrackingSession): string | null {
    const location = session.latestLocation;
    return location
      ? `https://www.google.com/maps?q=${location.latitude},${location.longitude}`
      : null;
  }

  /**
   * Reviewer note: Encapsulates the tracking series view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get trackingSeries(): TrackingMapSeries[] {
    return this.tracking.map(session => ({
      label: `${session.driverName} · Delivery ${session.deliveryId}`,
      points: this.trackingHistory[session.trackingSessionId]?.length
        ? this.trackingHistory[session.trackingSessionId]
        : session.latestLocation ? [session.latestLocation] : []
    }));
  }

  /**
   * Reviewer note: Calculates is stale for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  isStale(session: ActiveTrackingSession): boolean {
    const received = session.latestLocation?.receivedAtUtc;
    return !!received && Date.now() - new Date(received).getTime() > 120_000;
  }

  /**
   * Reviewer note: Coordinates load tracking history so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
}
