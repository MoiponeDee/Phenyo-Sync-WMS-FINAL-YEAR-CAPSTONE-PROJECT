/**
 * Reviewer guide: Coordinates the make product page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { HttpErrorResponse } from '@angular/common/http';
import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize, take, timeout } from 'rxjs';
import { DashboardRouteService } from '../../services/dashboard-route';
import {
  CreateProductRequest,
  CreateProductResponse,
  PackableProduct,
  ProductService
} from '../../services/product';
import {
  ProductLookupService,
  WarehouseSection
} from '../../services/product-lookups';

@Component({
  selector: 'app-make-product',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './make-product.html',
  styleUrl: './make-product.css'
})
/** Captures a production conversion while the API calculates and posts raw/finished stock effects. */
export class MakeProduct implements OnInit, OnDestroy {
  productId: number | null = null;
  quantityProducedKg: number | null = null;
  sectionId: number | null = null;
  packedAtLocal = this.toLocalInputValue(new Date());

  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  warehouseSections: WarehouseSection[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  packableProducts: PackableProduct[] = [];

  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loadingLookups = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loadingPackableProducts = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  qrCodeLoading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  result: CreateProductResponse | null = null;
  qrCodeImageUrl: string | null = null;

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly productService: ProductService,
    private readonly lookupService: ProductLookupService,
    private readonly changeDetector: ChangeDetectorRef,
    private readonly router: Router,
    private readonly dashboards: DashboardRouteService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.loadSections();
  }

  /**
   * Reviewer note: Coordinates selected product so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  get selectedProduct(): PackableProduct | undefined {
    return this.packableProducts.find(
      product => product.productId === this.productId);
  }

  /**
   * Reviewer note: Coordinates load sections so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadSections(): void {
    this.loadingLookups = true;
    this.errorMessage = '';
    this.lookupService.getActiveWarehouseSections().pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.loadingLookups = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: sections => {
        this.warehouseSections = sections;
      },
      error: error => this.handleError(
        error,
        'Unable to load warehouse sections.')
    });
  }

  /**
   * Reviewer note: Encapsulates the section changed view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  sectionChanged(preserveMessages = false): void {
    this.productId = null;
    this.packableProducts = [];
    if (!preserveMessages) {
      this.successMessage = '';
      this.errorMessage = '';
    }
    if (this.sectionId == null) return;

    this.loadingPackableProducts = true;
    this.productService.getPackableProducts(this.sectionId).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.loadingPackableProducts = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: products => {
        this.packableProducts = products;
      },
      error: error => this.handleError(
        error,
        'Unable to load packable Products for this section.')
    });
  }

  /**
   * Reviewer note: Coordinates the save product interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveProduct(): void {
    if (this.loading || this.loadingLookups || this.loadingPackableProducts) {
      return;
    }
    this.successMessage = '';
    this.errorMessage = '';

    if (this.productId == null ||
        this.quantityProducedKg == null ||
        this.sectionId == null ||
        !this.packedAtLocal) {
      this.errorMessage = 'Please complete all required fields.';
      return;
    }
    if (this.quantityProducedKg <= 0) {
      this.errorMessage = 'Quantity produced must be greater than zero.';
      return;
    }
    const maximum = this.selectedProduct?.maximumPackableQuantity ?? 0;
    if (this.quantityProducedKg > maximum) {
      this.errorMessage =
        `Only ${maximum.toFixed(3)} can currently be packed from available Raw Stock.`;
      return;
    }

    const packedAt = new Date(this.packedAtLocal);
    if (Number.isNaN(packedAt.getTime()) ||
        packedAt.getTime() > Date.now() + 60000) {
      this.errorMessage = 'Packed date cannot be in the future.';
      return;
    }

    const request: CreateProductRequest = {
      productId: this.productId,
      quantityProducedKg: this.quantityProducedKg,
      sectionId: this.sectionId,
      packedAtUtc: packedAt.toISOString()
    };

    this.clearQrCodeImage();
    this.result = null;
    this.loading = true;
    this.productService.createProduct(request).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.result = response;
        this.successMessage = response.message;
        this.loadQrCodeImage(response.productBatchId);
        this.productId = null;
        this.quantityProducedKg = null;
        this.packedAtLocal = this.toLocalInputValue(new Date());
        this.sectionChanged(true);
      },
      error: error => this.handleError(
        error,
        'Unable to convert Raw Stock into the finished Product.')
    });
  }

  /**
   * Reviewer note: Encapsulates the download qr code view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  downloadQrCode(): void {
    if (!this.result) return;
    this.productService.getBatchQrCode(this.result.productBatchId).pipe(
      take(1),
      timeout(15000)
    ).subscribe({
      next: blob => {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${this.result?.batchCode ?? 'product-batch'}.png`;
        link.click();
        URL.revokeObjectURL(url);
      },
      error: error => this.handleError(
        error,
        'Unable to download the QR code.')
    });
  }

  /**
   * Reviewer note: Encapsulates the print label view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  printLabel(): void {
    if (this.result && this.qrCodeImageUrl) window.print();
  }

  /**
   * Reviewer note: Coordinates the cancel interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  cancel(): void {
    if (this.loading || this.qrCodeLoading) return;
    void this.router.navigateByUrl(
      this.dashboards.forRole(localStorage.getItem('role')));
  }

  /**
   * Reviewer note: Releases subscriptions or device resources when the view is left to prevent duplicate background work.
   * Cleanup stops stale callbacks from mutating a page that is no longer active.
   */
  ngOnDestroy(): void {
    this.clearQrCodeImage();
  }

  /**
   * Reviewer note: Coordinates load qr code image so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private loadQrCodeImage(batchId: number): void {
    this.qrCodeLoading = true;
    this.productService.getBatchQrCode(batchId).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.qrCodeLoading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: blob => {
        this.clearQrCodeImage();
        this.qrCodeImageUrl = URL.createObjectURL(blob);
      },
      error: error => this.handleError(
        error,
        'The batch was recorded, but its QR image could not be loaded.')
    });
  }

  /**
   * Reviewer note: Encapsulates the clear qr code image view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private clearQrCodeImage(): void {
    if (this.qrCodeImageUrl) URL.revokeObjectURL(this.qrCodeImageUrl);
    this.qrCodeImageUrl = null;
  }

  /**
   * Reviewer note: Converts handle error into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private handleError(error: unknown, fallback: string): void {
    console.error('Make product error:', error);
    if (error instanceof HttpErrorResponse) {
      this.errorMessage = error.error?.message ||
        this.validationMessage(error) ||
        (error.status === 0
          ? 'Cannot connect to the backend API.'
          : fallback);
      return;
    }
    this.errorMessage = fallback;
  }

  /**
   * Reviewer note: Encapsulates the validation message view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private validationMessage(error: HttpErrorResponse): string {
    const errors = error.error?.errors as Record<string, string[]> | undefined;
    return errors ? Object.values(errors).flat().join(' ') : '';
  }

  /**
   * Reviewer note: Encapsulates the to local input value view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private toLocalInputValue(value: Date): string {
    const adjusted = new Date(
      value.getTime() - value.getTimezoneOffset() * 60000);
    return adjusted.toISOString().slice(0, 16);
  }
}
