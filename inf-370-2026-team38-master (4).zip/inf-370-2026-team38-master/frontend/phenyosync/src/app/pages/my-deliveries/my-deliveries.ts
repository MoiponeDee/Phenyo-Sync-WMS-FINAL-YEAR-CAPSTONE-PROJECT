/**
 * Reviewer guide: Coordinates the my deliveries page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, RouterLink } from '@angular/router';
import { finalize, take, timeout } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { DeliveryListItem, DeliveryService } from '../../services/delivery';
import { ConfirmationService } from '../../services/confirmation';

@Component({
  selector: 'app-my-deliveries',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, TopbarComponent, SidebarComponent],
  templateUrl: './my-deliveries.html',
  styleUrl: './my-deliveries.css'
})
/** Lists only deliveries accessible to the current driver and routes into execution actions. */
export class MyDeliveries implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Driver Dashboard', route: '/driver-dashboard' },
    { name: 'My Deliveries', route: '/my-deliveries', active: true }
  ];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  deliveries: DeliveryListItem[] = [];
  status = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  actionId: number | null = null;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private deliveriesApi: DeliveryService,
    private changeDetector: ChangeDetectorRef,
    private router: Router,
    private confirmation: ConfirmationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    if (this.loading) return;
    this.loading = true;
    this.errorMessage = '';
    this.deliveriesApi.my(this.status).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: deliveries => this.deliveries = deliveries,
      error: error => this.errorMessage = this.errorText(error, 'Unable to load your deliveries.')
    });
  }

  /**
   * Reviewer note: Coordinates the start interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async start(delivery: DeliveryListItem): Promise<void> {
    const confirmation = await this.confirmation.ask({
      title: 'Start delivery',
      message: `Confirm that order ${delivery.orderNumber} is loaded and ready to leave.`,
      confirmLabel: 'Start delivery'
    });
    if (!confirmation.confirmed) return;
    this.actionId = delivery.deliveryId;
    this.errorMessage = '';
    this.deliveriesApi.start(delivery.deliveryId).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.actionId = null;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.successMessage = result.message;
        this.load();
      },
      error: error => this.errorMessage = this.errorText(error, 'Unable to start delivery.')
    });
  }

  /**
   * Reviewer note: Coordinates the complete interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  complete(delivery: DeliveryListItem): void {
    this.router.navigate(['/deliveries', delivery.deliveryId, 'complete']);
  }

  /**
   * Reviewer note: Encapsulates the proof view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  proof(delivery: DeliveryListItem): void {
    this.router.navigate(['/deliveries', delivery.deliveryId, 'proof']);
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    if (error instanceof Error && error.name === 'TimeoutError') return 'The request timed out.';
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) return 'Cannot connect to the backend API.';
      if (error.status === 401) return 'Your session has expired.';
      if (error.status === 403) return error.error?.message || 'Your account is not linked to this delivery.';
      if (error.status === 409) return error.error?.message || 'The delivery status changed.';
      return error.error?.message || fallback;
    }
    return fallback;
  }
}
