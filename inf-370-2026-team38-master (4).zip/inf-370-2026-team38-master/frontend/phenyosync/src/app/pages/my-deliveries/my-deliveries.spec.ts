/**
 * Reviewer guide: Verifies the my deliveries frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { MyDeliveries } from './my-deliveries';
import { environment } from '../../../environments/environment';

// Covers the my deliveries behavior most likely to regress across permissions and workflow changes.
describe('MyDeliveries', () => {
  // Reviewer note: Guards the observable rule that loads only the authenticated driver endpoint.
  it('loads only the authenticated driver endpoint', async () => {
    await TestBed.configureTestingModule({
      imports: [MyDeliveries],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])]
    }).compileComponents();
    const fixture = TestBed.createComponent(MyDeliveries);
    const component = fixture.componentInstance;
    const http = TestBed.inject(HttpTestingController);

    component.load();
    const request = http.expectOne(`${environment.apiUrl}/deliveries/my`);
    expect(request.request.method).toBe('GET');
    request.flush([]);
    expect(component.deliveries).toEqual([]);
    http.verify();
  });
});
