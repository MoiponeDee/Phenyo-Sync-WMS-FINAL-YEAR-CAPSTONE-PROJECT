/**
 * Reviewer guide: Coordinates the order details page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { finalize, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import { OrderService, OrderStatus, SalesOrderDetail, ValidationResult } from '../../services/order';
import { AuthorizationService } from '../../services/authorization';
import {
  ConfigurationAdminService,
  LookupValueSummary
} from '../../services/configuration-admin';
import { HumanizeCodePipe } from '../../pipes/humanize-code.pipe';

@Component({
  selector: 'app-order-details', standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    TopbarComponent,
    HumanizeCodePipe
  ],
  templateUrl: './order-details.html'
})
/** Displays the current order lifecycle, validation outcome, shortages and allocations. */
export class OrderDetails implements OnInit {
  order: SalesOrderDetail | null = null;
  orderId = 0;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = true;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  processing = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  message = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  validationResult: ValidationResult | null = null;
  showCancel = false;
  showReject = false;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  cancellationReason = '';
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  cancellationReasons: LookupValueSummary[] = [];
  confirmationText = '';
  reason = '';
  decisionReason = '';
  private returnUrl: string | null = null;

  statusLabel(status: string): string {
    return status === 'Submitted' || status === 'PendingValidation'
      ? 'Pending Validation'
      : status;
  }
  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private orders: OrderService,
    private changeDetector: ChangeDetectorRef,
    private authorization: AuthorizationService,
    private configuration: ConfigurationAdminService
  ) {}
  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.orderId = Number(this.route.snapshot.paramMap.get('id'));
    this.returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') === '/search-orders'
      ? '/search-orders'
      : null;
    this.load();
    this.configuration.activeValues('ORDER_CANCELLATION_REASON').subscribe({
      next: values => this.cancellationReasons = values
    });
  }
  /**
   * Reviewer note: Calculates can update for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canUpdate(): boolean {
    return this.authorization.has('Orders.Update');
  }

  /**
   * Reviewer note: Calculates can validate for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canValidate(): boolean {
    return this.authorization.has('Orders.Validate');
  }

  /**
   * Reviewer note: Calculates can decide for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canDecide(): boolean {
    return this.authorization.has('Orders.Confirm');
  }

  /**
   * Reviewer note: Calculates can approve commercially for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canApproveCommercially(): boolean {
    return this.canValidate && this.canDecide;
  }

  /**
   * Reviewer note: Calculates can cancel for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canCancel(): boolean {
    return this.authorization.has('Orders.Cancel');
  }

  /**
   * Reviewer note: Calculates can view invoice for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canViewInvoice(): boolean {
    return this.authorization.has('Invoices.View');
  }

  /**
   * Reviewer note: Calculates can view packing for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canViewPacking(): boolean {
    return this.authorization.has('Packing.View');
  }

  /**
   * Reviewer note: Calculates can change status for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canChangeStatus(): boolean {
    return this.authorization.has('Orders.ChangeStatus');
  }

  /**
   * Reviewer note: Encapsulates the next status view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get nextStatus(): OrderStatus | null {
    if (!this.order || !this.canChangeStatus) return null;
    return null;
  }
  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true; this.errorMessage = '';
    this.orders.get(this.orderId).pipe(take(1), finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({ next: order => this.order = order, error: error => this.fail(error) });
  }
  /**
   * Reviewer note: Encapsulates the validate view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  validate(): void {
    // Commercial validation does not treat missing finished stock as an invalid customer order.
    if (!this.canValidate) return;
    this.processing = true; this.message = ''; this.errorMessage = ''; this.validationResult = null;
    this.orders.validate(this.orderId).pipe(take(1), finalize(() => {
      this.processing = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: result => { this.validationResult = result; this.message = result.message; this.load(); },
      error: error => { if (error instanceof HttpErrorResponse && error.status === 409 && error.error?.shortages) this.validationResult = error.error; this.fail(error); this.load(); }
    });
  }
  /**
   * Reviewer note: Coordinates the approve interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  approve(): void {
    // Approval activates fulfilment demand; shortages are displayed rather than blocking the decision.
    if (!this.canApproveCommercially || this.processing) return;
    this.processing = true;
    this.message = '';
    this.errorMessage = '';
    this.orders.approve(this.orderId, this.decisionReason.trim()).pipe(
      take(1),
      finalize(() => {
        this.processing = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.order = response.order;
        this.message = response.message;
        this.decisionReason = '';
        if (this.returnUrl) this.router.navigateByUrl(this.returnUrl);
      },
      error: error => this.fail(error)
    });
  }
  /**
   * Reviewer note: Coordinates the reject interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  reject(): void {
    if (!this.canApproveCommercially || this.processing) return;
    this.processing = true;
    this.message = '';
    this.errorMessage = '';
    this.orders.reject(this.orderId, this.decisionReason.trim()).pipe(
      take(1),
      finalize(() => {
        this.processing = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.order = response.order;
        this.message = response.message;
        this.decisionReason = '';
        this.showReject = false;
        if (this.returnUrl) this.router.navigateByUrl(this.returnUrl);
      },
      error: error => this.fail(error)
    });
  }
  /**
   * Reviewer note: Encapsulates the confirm warehouse ready view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  confirmWarehouseReady(): void {
    // Warehouse readiness is a separate transition after all required quantities are packed.
    if (!this.order || !this.canChangeStatus || this.order.status !== 'Packed') return;
    this.processing = true;
    this.message = '';
    this.errorMessage = '';
    this.validationResult = null;
    this.orders.confirmWarehouseReady(
      this.orderId,
      this.reason.trim() || 'Completed packing reviewed and confirmed ready for dispatch.'
    ).pipe(
      take(1),
      finalize(() => {
        this.processing = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.order = response.order;
        this.message = response.message;
        this.reason = '';
      },
      error: error => {
        this.fail(error);
        this.load();
      }
    });
  }
  /**
   * Reviewer note: Encapsulates the transition view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  transition(): void {
    if (!this.nextStatus) return;
    this.processing = true; this.message = ''; this.errorMessage = '';
    this.orders.updateStatus(this.orderId, this.nextStatus, this.reason).pipe(take(1), finalize(() => {
      this.processing = false;
      this.changeDetector.detectChanges();
    }))
      .subscribe({ next: response => { this.order = response.order; this.message = response.message; this.reason = ''; }, error: error => this.fail(error) });
  }
  /**
   * Reviewer note: Coordinates the cancel interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  cancel(): void {
    if (!this.canCancel) return;
    if (!this.order || !this.cancellationReason.trim() || this.confirmationText.trim().toUpperCase() !== this.order.orderNumber.toUpperCase()) {
      this.errorMessage = `Enter a reason and type ${this.order?.orderNumber} exactly.`; return;
    }
    this.processing = true; this.errorMessage = '';
    this.orders.cancel(this.orderId, this.cancellationReason, this.confirmationText).pipe(take(1), finalize(() => {
      this.processing = false;
      this.changeDetector.detectChanges();
    }))
      .subscribe({ next: response => { this.order = response.order; this.message = response.message; this.showCancel = false; }, error: error => this.fail(error) });
  }
  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown): void {
    this.errorMessage = error instanceof HttpErrorResponse ? error.error?.message || 'The order action failed.' : 'The order action failed.';
  }
}
