/**
 * Reviewer guide: Verifies the order details frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ChangeDetectorRef } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthorizationService } from '../../services/authorization';
import { ConfigurationAdminService } from '../../services/configuration-admin';
import { OrderService, SalesOrderDetail } from '../../services/order';
import { OrderDetails } from './order-details';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

// Proves commercial approval visibility is permission-based and independent of finished-stock shortage.
describe('OrderDetails permissions', () => {
  function componentWith(...permissions: string[]): OrderDetails {
    const granted = new Set(permissions);
    const component = new OrderDetails(
      {} as ActivatedRoute,
      {} as Router,
      {} as OrderService,
      { detectChanges: () => undefined } as ChangeDetectorRef,
      {
        has: (permission: string) => granted.has(permission)
      } as AuthorizationService,
      {} as ConfigurationAdminService
    );
    component.order = {
      status: 'Approved'
    } as SalesOrderDetail;
    return component;
  }

  // Reviewer note: Guards the observable rule that does not infer unrelated order actions from a broad manager flag.
  it('does not infer unrelated order actions from a broad manager flag', () => {
    const component = componentWith('Orders.Update');

    expect(component.canUpdate).toBe(true);
    expect(component.canValidate).toBe(false);
    expect(component.canCancel).toBe(false);
    expect(component.canViewInvoice).toBe(false);
    expect(component.canViewPacking).toBe(false);
    expect(component.nextStatus).toBeNull();
  });

  // Reviewer note: Guards the observable rule that exposes workflow actions only for their exact permissions.
  it('exposes workflow actions only for their exact permissions', () => {
    const component = componentWith(
      'Orders.Validate',
      'Orders.Confirm',
      'Orders.Cancel',
      'Orders.ChangeStatus',
      'Invoices.View',
      'Packing.View'
    );

    expect(component.canValidate).toBe(true);
    expect(component.canDecide).toBe(true);
    expect(component.canApproveCommercially).toBe(true);
    expect(component.canCancel).toBe(true);
    expect(component.canViewInvoice).toBe(true);
    expect(component.canViewPacking).toBe(true);
    expect(component.nextStatus).toBeNull();

    component.order = {
      status: 'Packed'
    } as SalesOrderDetail;

    expect(component.canChangeStatus).toBe(true);
    expect(component.nextStatus).toBeNull();
  });

  // Reviewer note: Guards the observable rule that allows an authorised Submitted order to be commercially approved without a stock gate.
  it('allows an authorised Submitted order to be commercially approved without a stock gate', () => {
    const component = componentWith('Orders.Validate', 'Orders.Confirm');
    component.order = {
      status: 'Submitted',
      validationMessage: 'Finished stock shortage: 5 units.'
    } as SalesOrderDetail;
    component.decisionReason = '';

    expect(component.canValidate).toBe(true);
    expect(component.canApproveCommercially).toBe(true);
    expect(component.decisionReason).toBe('');
    expect(component.statusLabel('Submitted')).toBe('Pending Validation');
  });

  it('accepts without a reason and waits for the server response before success', () => {
    const approve = vi.fn().mockReturnValue(of({
      message: 'Order accepted.',
      order: { status: 'Approved' }
    }));
    const component = new OrderDetails(
      {} as ActivatedRoute,
      { navigateByUrl: vi.fn() } as unknown as Router,
      { approve } as unknown as OrderService,
      { detectChanges: vi.fn() } as unknown as ChangeDetectorRef,
      { has: (permission: string) => ['Orders.Validate', 'Orders.Confirm'].includes(permission) } as AuthorizationService,
      {} as ConfigurationAdminService
    );
    component.order = { status: 'Submitted' } as SalesOrderDetail;

    component.approve();

    expect(approve).toHaveBeenCalledWith(0, '');
    expect(component.order.status).toBe('Approved');
    expect(component.processing).toBe(false);
  });

  it('releases processing and preserves the API error when acceptance fails', () => {
    const component = new OrderDetails(
      {} as ActivatedRoute,
      {} as Router,
      {
        approve: () => throwError(() => new HttpErrorResponse({
          status: 409,
          error: { message: 'This order was already decided.' }
        }))
      } as unknown as OrderService,
      { detectChanges: vi.fn() } as unknown as ChangeDetectorRef,
      { has: (permission: string) => ['Orders.Validate', 'Orders.Confirm'].includes(permission) } as AuthorizationService,
      {} as ConfigurationAdminService
    );
    component.order = { status: 'Submitted' } as SalesOrderDetail;

    component.approve();

    expect(component.processing).toBe(false);
    expect(component.errorMessage).toBe('This order was already decided.');
  });

  it('preserves an unknown derived weight instead of presenting a false kilogram value', () => {
    const line = {
      quantityUnits: 4,
      sellingUnit: 'box',
      quantityKg: null,
      unitPrice: 125,
      unitPricePerKg: null,
      priceBasis: 'PerSellableUnit'
    };

    expect(line.quantityUnits).toBe(4);
    expect(line.quantityKg).toBeNull();
    expect(line.unitPricePerKg).toBeNull();
  });
});
