/**
 * Reviewer guide: Coordinates the manage lookups page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { finalize } from 'rxjs';
import {
  ConfigurationAdminService,
  LookupHistory,
  LookupTypeDetail,
  LookupTypeSummary,
  LookupValueSummary
} from '../../services/configuration-admin';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import { AuthorizationService } from '../../services/authorization';

@Component({
  selector: 'app-manage-lookups',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, SearchFieldComponent],
  templateUrl: './manage-lookups.html',
  styleUrl: '../configuration-management.css'
})
/** Manages governed lookup types/values used by operational forms and validation. */
export class ManageLookups implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  types: LookupTypeSummary[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selected: LookupTypeDetail | null = null;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  history: LookupHistory[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search = '';
  status = '';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  valueSearch = '';
  valueStatus = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  showTypeEditor = false;
  showValueEditor = false;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  showHistory = false;
  editingValue?: LookupValueSummary;
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  typeForm = { systemCode: '', displayName: '', description: '', rowVersion: '' };
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  valueForm = {
    systemCode: '',
    displayName: '',
    description: '',
    sortOrder: 10,
    reason: '',
    rowVersion: ''
  };

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private api: ConfigurationAdminService,
    private notifications: NotificationService,
    private confirmation: ConfirmationService,
    private authorization: AuthorizationService,
    private cdr: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Calculates can view history for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get canViewHistory(): boolean {
    return this.authorization.has('Lookups.Manage');
  }

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.loadTypes();
  }

  /**
   * Reviewer note: Coordinates load types so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadTypes(): void {
    this.loading = true;
    this.errorMessage = '';
    this.api.lookupTypes({
      search: this.search,
      isActive: this.status === '' ? null : this.status === 'active',
      pageSize: 100
    }).pipe(finalize(() => {
      this.loading = false;
      this.cdr.detectChanges();
    })).subscribe({
      next: result => {
        this.types = result.items;
        if (this.selected) {
          const current = this.types.find(item =>
            item.lookupTypeId === this.selected?.lookupTypeId);
          if (current) this.selectType(current);
        } else if (this.types.length) {
          this.selectType(this.types[0]);
        }
      },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates select type so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectType(type: LookupTypeSummary): void {
    this.loading = true;
    this.api.lookupType(type.systemCode, {
      search: this.valueSearch,
      isActive: this.valueStatus === '' ? null : this.valueStatus === 'active',
      pageSize: 100
    }).pipe(finalize(() => {
      this.loading = false;
      this.cdr.detectChanges();
    })).subscribe({
      next: result => this.selected = result,
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates open create type so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openCreateType(): void {
    this.typeForm = { systemCode: '', displayName: '', description: '', rowVersion: '' };
    this.showTypeEditor = true;
  }

  /**
   * Reviewer note: Coordinates open edit type so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openEditType(): void {
    if (!this.selected) return;
    this.typeForm = {
      systemCode: this.selected.systemCode,
      displayName: this.selected.displayName,
      description: this.selected.description || '',
      rowVersion: this.selected.rowVersion
    };
    this.showTypeEditor = true;
  }

  /**
   * Reviewer note: Coordinates the save type interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveType(): void {
    const code = this.typeForm.systemCode.trim().toUpperCase();
    const name = this.typeForm.displayName.trim();
    if (!/^[A-Z][A-Z0-9_]{2,79}$/.test(code) || !name) {
      this.errorMessage = 'Enter a valid immutable code and display name.';
      return;
    }
    this.saving = true;
    this.errorMessage = '';
    const request = this.selected &&
      this.typeForm.rowVersion === this.selected.rowVersion
      ? this.api.updateLookupType(this.selected.lookupTypeId, {
          ...this.typeForm,
          systemCode: code,
          displayName: name
        })
      : this.api.createLookupType({
          ...this.typeForm,
          systemCode: code,
          displayName: name
        });
    request.pipe(finalize(() => {
      this.saving = false;
      this.cdr.detectChanges();
    })).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.showTypeEditor = false;
        this.selected = null;
        this.loadTypes();
      },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates open create value so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openCreateValue(): void {
    this.editingValue = undefined;
    this.valueForm = {
      systemCode: '',
      displayName: '',
      description: '',
      sortOrder: (this.selected?.values.length ?? 0) * 10 + 10,
      reason: '',
      rowVersion: ''
    };
    this.showValueEditor = true;
  }

  /**
   * Reviewer note: Coordinates open edit value so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openEditValue(value: LookupValueSummary): void {
    this.editingValue = value;
    this.valueForm = {
      systemCode: value.systemCode,
      displayName: value.displayName,
      description: value.description || '',
      sortOrder: value.sortOrder,
      reason: '',
      rowVersion: value.rowVersion
    };
    this.showValueEditor = true;
  }

  /**
   * Reviewer note: Coordinates the save value interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  saveValue(): void {
    if (!this.selected) return;
    const code = this.valueForm.systemCode.trim().toUpperCase();
    if (!/^[A-Z][A-Z0-9_]{1,79}$/.test(code) ||
        !this.valueForm.displayName.trim() ||
        this.valueForm.reason.trim().length < 5) {
      this.errorMessage = 'Complete the value and enter a change reason of at least 5 characters.';
      return;
    }
    this.saving = true;
    this.errorMessage = '';
    const payload = {
      ...this.valueForm,
      systemCode: code,
      displayName: this.valueForm.displayName.trim(),
      description: this.valueForm.description.trim(),
      reason: this.valueForm.reason.trim()
    };
    const request = this.editingValue
      ? this.api.updateLookupValue(this.editingValue.lookupValueId, payload)
      : this.api.createLookupValue(this.selected.systemCode, payload);
    request.pipe(finalize(() => {
      this.saving = false;
      this.cdr.detectChanges();
    })).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.showValueEditor = false;
        this.refreshSelected();
      },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Encapsulates the toggle value view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  async toggleValue(value: LookupValueSummary): Promise<void> {
    const activating = !value.isActive;
    const result = await this.confirmation.ask({
      title: activating ? 'Activate lookup value' : 'Deactivate lookup value',
      message: activating
        ? `Make ${value.displayName} available to new operational forms?`
        : `Remove ${value.displayName} from new operational forms? Historical records remain readable.`,
      confirmLabel: activating ? 'Activate' : 'Deactivate',
      tone: activating ? 'default' : 'warning',
      reasonLabel: 'Reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.api.changeLookupValueStatus(
      value.lookupValueId,
      activating,
      result.reason,
      value.rowVersion
    ).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.refreshSelected();
      },
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Coordinates the delete value interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async deleteValue(value: LookupValueSummary): Promise<void> {
    const result = await this.confirmation.ask({
      title: 'Delete custom lookup value',
      message: `Permanently delete ${value.displayName}? System or previously used values are protected.`,
      confirmLabel: 'Delete',
      tone: 'danger',
      reasonLabel: 'Reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.api.deleteLookupValue(value.lookupValueId, result.reason).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.refreshSelected();
      },
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Encapsulates the view history view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  viewHistory(value: LookupValueSummary): void {
    if (!this.canViewHistory) return;

    this.showHistory = true;
    this.loading = true;
    this.api.lookupValueHistory(value.lookupValueId).pipe(finalize(() => {
      this.loading = false;
      this.cdr.detectChanges();
    })).subscribe({
      next: history => this.history = history,
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates refresh selected so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  refreshSelected(): void {
    const summary = this.types.find(item =>
      item.lookupTypeId === this.selected?.lookupTypeId);
    if (summary) this.selectType(summary);
  }

  /**
   * Reviewer note: Encapsulates the read error view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private readError(error: any): string {
    const fields = error.error?.errors;
    if (fields) return Object.values(fields).flat().join(' ');
    return error.error?.message || 'The configuration action could not be completed.';
  }
}
