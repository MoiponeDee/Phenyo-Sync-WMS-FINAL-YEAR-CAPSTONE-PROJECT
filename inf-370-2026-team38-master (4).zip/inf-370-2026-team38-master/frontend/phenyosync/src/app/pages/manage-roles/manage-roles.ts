/**
 * Reviewer guide: Coordinates the manage roles page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { finalize, forkJoin } from 'rxjs';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import {
  PermissionSummary,
  RoleSummary,
  SecurityAdminService
} from '../../services/security-admin';

@Component({
  selector: 'app-manage-roles',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, SearchFieldComponent],
  templateUrl: './manage-roles.html',
  styleUrl: '../security-management.css'
})
/** Manages persisted roles without creating a separate SuperAdmin role code. */
export class ManageRoles implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  roles: RoleSummary[] = [];
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  permissions: PermissionSummary[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  showEditor = false;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  showPermissions = false;
  editing?: RoleSummary;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedRole?: RoleSummary;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  selectedPermissionIds = new Set<number>();
  reason = '';
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  form = this.emptyForm();

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private api: SecurityAdminService,
    private notifications: NotificationService,
    private confirmation: ConfirmationService,
    private changeDetector: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      roles: this.api.roles(true, this.search),
      permissions: this.api.permissions(false)
    }).pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: result => {
        this.roles = result.roles;
        this.permissions = result.permissions;
      },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates open create so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openCreate(copy?: RoleSummary): void {
    this.editing = undefined;
    this.form = {
      roleCode: '',
      roleName: copy ? `${copy.roleName} Copy` : '',
      description: copy?.description || '',
      copyFromRoleId: copy?.roleId || null,
      rowVersion: ''
    };
    this.showEditor = true;
  }

  /**
   * Reviewer note: Coordinates open edit so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openEdit(role: RoleSummary): void {
    this.editing = role;
    this.form = {
      roleCode: role.roleCode,
      roleName: role.roleName,
      description: role.description || '',
      copyFromRoleId: null,
      rowVersion: role.rowVersion
    };
    this.showEditor = true;
  }

  /**
   * Reviewer note: Coordinates the save interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  save(): void {
    if (!this.form.roleName.trim() || (!this.editing && !this.form.roleCode.trim())) {
      this.errorMessage = 'Enter a valid role code and display name.';
      return;
    }
    this.saving = true;
    const request = this.editing
      ? this.api.updateRole(this.editing.roleId, {
          roleName: this.form.roleName,
          description: this.form.description,
          rowVersion: this.form.rowVersion
        })
      : this.api.createRole(this.form);
    request.pipe(finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.showEditor = false;
        this.load();
      },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates open permissions so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openPermissions(role: RoleSummary): void {
    this.selectedRole = role;
    this.selectedPermissionIds.clear();
    this.reason = '';
    this.showPermissions = true;
    this.api.role(role.roleId).subscribe({
      next: detail => {
        this.selectedPermissionIds =
          new Set(detail.permissionIds || []);
        this.changeDetector.detectChanges();
      },
      error: error => {
        this.errorMessage = this.readError(error);
        this.changeDetector.detectChanges();
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the toggle permission view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  togglePermission(id: number, checked: boolean): void {
    if (checked) this.selectedPermissionIds.add(id);
    else this.selectedPermissionIds.delete(id);
  }

  /**
   * Reviewer note: Coordinates the save permissions interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  savePermissions(): void {
    if (!this.selectedRole || !this.reason.trim()) {
      this.errorMessage = 'Enter a reason for the permission change.';
      return;
    }
    this.saving = true;
    this.api.assignPermissions(
      this.selectedRole.roleId,
      [...this.selectedPermissionIds],
      this.reason,
      this.selectedRole.rowVersion
    ).pipe(finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.showPermissions = false;
        this.load();
      },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates the change status interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async changeStatus(role: RoleSummary): Promise<void> {
    const activating = !role.isActive;
    const result = await this.confirmation.ask({
      title: activating ? 'Activate role' : 'Deactivate role',
      message: activating
        ? `Activate ${role.roleName}?`
        : `Deactivate ${role.roleName}? Active users must be reassigned first.`,
      confirmLabel: activating ? 'Activate' : 'Deactivate',
      tone: activating ? 'default' : 'warning',
      reasonLabel: 'Reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.api.changeRoleStatus(
      role.roleId,
      activating,
      result.reason,
      role.rowVersion
    ).subscribe({
      next: response => { this.notifications.success(response.message); this.load(); },
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Coordinates the delete role interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async deleteRole(role: RoleSummary): Promise<void> {
    const result = await this.confirmation.ask({
      title: 'Delete custom role',
      message: `Permanently delete ${role.roleName}? Only an unused role with no permissions can be deleted.`,
      confirmLabel: 'Delete role',
      tone: 'danger'
    });
    if (!result.confirmed) return;
    this.api.deleteRole(role.roleId).subscribe({
      next: response => { this.notifications.success(response.message); this.load(); },
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Encapsulates the grouped permissions view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  groupedPermissions(): { module: string; items: PermissionSummary[] }[] {
    const groups = new Map<string, PermissionSummary[]>();
    this.permissions.forEach(permission => {
      const items = groups.get(permission.module) || [];
      items.push(permission);
      groups.set(permission.module, items);
    });
    return [...groups.entries()].map(([module, items]) => ({ module, items }));
  }

  /**
   * Reviewer note: Encapsulates the empty form view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private emptyForm() {
    return {
      roleCode: '',
      roleName: '',
      description: '',
      copyFromRoleId: null as number | null,
      rowVersion: ''
    };
  }

  /**
   * Reviewer note: Encapsulates the read error view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private readError(error: any): string {
    return error.error?.message || 'The role action could not be completed.';
  }
}
