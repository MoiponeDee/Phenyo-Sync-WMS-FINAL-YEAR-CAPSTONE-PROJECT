/**
 * Reviewer guide: Coordinates the operations calendar page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule, Location } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize, forkJoin, take } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import {
  OperationsCalendarEvent,
  OperationsCalendarService
} from '../../services/operations-calendar';
import {
  ProductCategory,
  ProductLookupService,
  WarehouseSection
} from '../../services/product-lookups';

type CalendarView = 'month' | 'week' | 'day' | 'agenda';

interface CalendarDay {
  date: Date;
  currentMonth: boolean;
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  events: OperationsCalendarEvent[];
}

@Component({
  selector: 'app-operations-calendar',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  templateUrl: './operations-calendar.html',
  styleUrls: ['../phase-b.css', './operations-calendar.css']
})
/** Displays read-only milestones derived from orders, procurement and delivery workflows. */
export class OperationsCalendar implements OnInit {
  view: CalendarView = 'month';
  anchorDate = new Date();
  days: CalendarDay[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  events: OperationsCalendarEvent[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  categories: ProductCategory[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  sections: WarehouseSection[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  filters = {
    eventType: '',
    driverId: null as number | null,
    customerId: null as number | null,
    deliveryStatus: '',
    riskLevel: '',
    warehouseSectionId: null as number | null,
    productCategoryId: null as number | null
  };
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  readonly weekdayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private calendar: OperationsCalendarService,
    private lookups: ProductLookupService,
    private router: Router,
    private changeDetector: ChangeDetectorRef,
    private location: Location
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      categories: this.lookups.getProductCategories('', ''),
      sections: this.lookups.getActiveWarehouseSections()
    }).pipe(take(1)).subscribe({
      next: result => {
        this.categories = result.categories;
        this.sections = result.sections;
      }
    });
    this.load();
  }

  /**
   * Reviewer note: Encapsulates the period label view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get periodLabel(): string {
    if (this.view === 'month') {
      return this.anchorDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
    }
    const [start, end] = this.displayRange();
    return `${start.toLocaleDateString()} – ${new Date(end.getTime() - 1).toLocaleDateString()}`;
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    if (this.loading) return;
    const [start, end] = this.queryRange();
    this.loading = true;
    this.errorMessage = '';
    this.calendar.events({
      startUtc: start.toISOString(),
      endUtc: end.toISOString(),
      ...this.filters
    }).pipe(
      take(1),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.events = response.events;
        if (!this.view && response.defaultView) this.view = response.defaultView;
        this.buildDays();
      },
      error: error => this.errorMessage = this.errorText(error, 'Unable to load operations-calendar events.')
    });
  }

  /**
   * Reviewer note: Encapsulates the set view view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  setView(view: CalendarView): void {
    this.view = view;
    this.load();
  }

  /**
   * Reviewer note: Encapsulates the move view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  move(direction: -1 | 1): void {
    const next = new Date(this.anchorDate);
    if (this.view === 'month') next.setMonth(next.getMonth() + direction);
    else if (this.view === 'week') next.setDate(next.getDate() + 7 * direction);
    else next.setDate(next.getDate() + direction);
    this.anchorDate = next;
    this.load();
  }

  /**
   * Reviewer note: Encapsulates the today view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  today(): void {
    this.anchorDate = new Date();
    this.load();
  }

  /**
   * Reviewer note: Encapsulates the clear filters view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  clearFilters(): void {
    this.filters = {
      eventType: '',
      driverId: null,
      customerId: null,
      deliveryStatus: '',
      riskLevel: '',
      warehouseSectionId: null,
      productCategoryId: null
    };
    this.load();
  }

  /**
   * Reviewer note: Coordinates open event so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openEvent(event: OperationsCalendarEvent): void {
    this.router.navigateByUrl(event.detailRoute);
  }

  /**
   * Reviewer note: Encapsulates the event class view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  eventClass(event: OperationsCalendarEvent): string {
    if (event.riskLevel === 'Urgent' || event.riskLevel === 'Expired') return 'urgent';
    return event.eventType.toLowerCase();
  }

  trackDay = (_: number, day: CalendarDay) => day.date.toISOString();
  trackEvent = (_: number, event: OperationsCalendarEvent) => event.eventId;

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.location.back();
  }

  /**
   * Reviewer note: Encapsulates the build days view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private buildDays(): void {
    const [start, end] = this.displayRange();
    const days: CalendarDay[] = [];
    for (let cursor = new Date(start); cursor < end; cursor.setDate(cursor.getDate() + 1)) {
      const date = new Date(cursor);
      const next = new Date(date);
      next.setDate(next.getDate() + 1);
      days.push({
        date,
        currentMonth: date.getMonth() === this.anchorDate.getMonth(),
        events: this.events.filter(event => {
          const eventDate = new Date(event.startUtc);
          return eventDate >= date && eventDate < next;
        })
      });
    }
    this.days = days;
  }

  /**
   * Reviewer note: Coordinates query range so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private queryRange(): [Date, Date] {
    if (this.view === 'agenda') {
      const start = this.startOfDay(this.anchorDate);
      const end = new Date(start);
      end.setDate(end.getDate() + 31);
      return [start, end];
    }
    return this.displayRange();
  }

  /**
   * Reviewer note: Encapsulates the display range view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private displayRange(): [Date, Date] {
    if (this.view === 'month') {
      const first = new Date(this.anchorDate.getFullYear(), this.anchorDate.getMonth(), 1);
      const start = new Date(first);
      start.setDate(start.getDate() - start.getDay());
      const end = new Date(start);
      end.setDate(end.getDate() + 42);
      return [start, end];
    }
    if (this.view === 'week') {
      const start = this.startOfDay(this.anchorDate);
      start.setDate(start.getDate() - start.getDay());
      const end = new Date(start);
      end.setDate(end.getDate() + 7);
      return [start, end];
    }
    const start = this.startOfDay(this.anchorDate);
    const end = new Date(start);
    end.setDate(end.getDate() + (this.view === 'agenda' ? 31 : 1));
    return [start, end];
  }

  /**
   * Reviewer note: Coordinates the start of day interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private startOfDay(date: Date): Date {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    const response = error as HttpErrorResponse;
    return response.error?.message || response.error?.title || fallback;
  }
}
