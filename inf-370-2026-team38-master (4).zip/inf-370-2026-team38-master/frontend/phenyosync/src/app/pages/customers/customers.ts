/**
 * Reviewer guide: Coordinates the customers page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import {
  CustomerSummary,
  OperationalSectionsService
} from '../../services/operational-sections';

@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    TopbarComponent,
    SidebarComponent,
    SearchFieldComponent
  ],
  templateUrl: './customers.html',
  styleUrl: './customers.css'
})
/** Provides customer discovery and permission-filtered master-data actions. */
export class CustomersComponent implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  customers: CustomerSummary[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search = '';
  includeInactive = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;

  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Customers', route: '/customers', active: true },
    { name: 'Sales Orders', route: '/order-management' },
    { name: 'Customer Payments', route: '/payments' }
  ];

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly operational: OperationalSectionsService,
    private readonly notifications: NotificationService,
    private readonly confirmations: ConfirmationService,
    private readonly changeDetector: ChangeDetectorRef,
    readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Coordinates the remove interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async remove(item: CustomerSummary): Promise<void> {
    const decision = await this.confirmations.ask({
      title: `Delete ${item.customerName}?`,
      message: 'Unused customers are permanently deleted. Customers with business history can only be deactivated.',
      confirmLabel: 'Review and delete',
      tone: 'danger',
      reasonLabel: 'Deletion reason',
      reasonRequired: true
    });
    if (!decision.confirmed) return;

    this.loading = true;
    this.operational.deleteCustomer(
      item.customerId,
      decision.reason,
      item.rowVersion
    ).pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.loading = false;
        this.load();
      },
      error: async error => {
        if (error?.status === 409 && error?.error?.canDeactivate) {
          await this.offerDeactivation(item, error.error.deleteBlockedReason);
          return;
        }
        this.notifications.error(
          error?.error?.message || 'The customer could not be deleted.');
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the offer deactivation view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private async offerDeactivation(
    item: CustomerSummary,
    blockedReason?: string
  ): Promise<void> {
    const decision = await this.confirmations.ask({
      title: 'Deactivate customer instead?',
      message: blockedReason || 'Business history must be retained.',
      confirmLabel: 'Deactivate',
      tone: 'warning'
    });
    if (!decision.confirmed) return;
    this.operational.saveCustomer(item.customerId, {
      customerName: item.customerName,
      email: item.email,
      contactPerson: item.contactPerson,
      phoneNumber: item.phoneNumber,
      billingAddress: item.billingAddress,
      deliveryAddress: item.deliveryAddress,
      status: 'Inactive',
      rowVersion: item.rowVersion
    }).subscribe({
      next: () => {
        this.notifications.success('Customer deactivated. Business history was preserved.');
        this.load();
      },
      error: error => this.notifications.error(
        error?.error?.message || 'The customer could not be deactivated.')
    });
  }

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    if (this.loading) return;

    this.loading = true;
    this.operational.customers(this.search, this.includeInactive).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => this.customers = result,
      error: error => this.notifications.error(
        error?.error?.message || 'Customers could not be loaded.')
    });
  }
}
