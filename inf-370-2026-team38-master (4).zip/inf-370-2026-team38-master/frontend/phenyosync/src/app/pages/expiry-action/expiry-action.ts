/**
 * Reviewer guide: Coordinates the expiry action page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize, take } from 'rxjs';
import { ExpiryActionReview, ExpiryAlertService } from '../../services/expiry-alerts';

@Component({
  selector: 'app-expiry-action', standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './expiry-action.html', styleUrl: './expiry-action.css'
})
/** Resolves one time-bound batch decision token without exposing internal stock controls. */
export class ExpiryAction implements OnInit {
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  token = '';
  review: ExpiryActionReview | null = null;
  reason = '';
  newExpiryAt = '';
  pendingAction: 'write-off' | 'extend' | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  completed = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: ExpiryAlertService,
    private cdr: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.token = this.route.snapshot.queryParamMap.get('token') ?? '';
    if (!this.token) { this.errorMessage = 'The expiry action link is incomplete.'; return; }
    this.loading = true;
    this.service.getActionReview(this.token).pipe(
      take(1), finalize(() => { this.loading = false; this.cdr.detectChanges(); })
    ).subscribe({
      next: review => {
        this.review = review;
        const proposed = new Date();
        proposed.setDate(proposed.getDate() + review.shelfLifeExtensionDays);
        this.newExpiryAt = this.localDateTimeValue(proposed);
      },
      error: error => this.fail(error, 'The action link is invalid or has expired.')
    });
  }

  /**
   * Reviewer note: Encapsulates the request view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  request(action: 'write-off' | 'extend'): void {
    this.errorMessage = '';
    if (this.reason.trim().length < 5) { this.errorMessage = 'Enter an inspection or decision reason of at least 5 characters.'; return; }
    if (action === 'extend' &&
        (!this.newExpiryAt || new Date(this.newExpiryAt).getTime() <= Date.now())) {
      this.errorMessage = 'Select a new expiry date and time in the future.';
      return;
    }
    this.pendingAction = action;
  }

  /**
   * Reviewer note: Encapsulates the apply decision view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  applyDecision(): void {
    if (!this.pendingAction || this.saving) return;
    const action = this.pendingAction;
    this.saving = true;
    const request = action === 'write-off'
      ? this.service.writeOff(this.token, this.reason.trim())
      : this.service.extend(
          this.token,
          this.reason.trim(),
          new Date(this.newExpiryAt).toISOString());
    request.pipe(finalize(() => { this.saving = false; this.cdr.detectChanges(); })).subscribe({
      next: response => {
        this.pendingAction = null;
        this.completed = true;
        this.successMessage = response.message;
        this.errorMessage = '';
      },
      error: error => { this.pendingAction = null; this.fail(error, 'The expiry decision could not be applied.'); }
    });
  }

  /**
   * Reviewer note: Encapsulates the go to alerts view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  goToAlerts(): void { this.router.navigate(['/expiry-alerts']); }

  /**
   * Reviewer note: Converts fail into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private fail(error: unknown, fallback: string): void {
    console.error('Expiry action error:', error);
    this.errorMessage = error instanceof HttpErrorResponse ? error.error?.message || fallback : fallback;
  }

  /**
   * Reviewer note: Encapsulates the local date time value view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private localDateTimeValue(value: Date): string {
    const offset = value.getTimezoneOffset() * 60_000;
    return new Date(value.getTime() - offset).toISOString().slice(0, 16);
  }
}
