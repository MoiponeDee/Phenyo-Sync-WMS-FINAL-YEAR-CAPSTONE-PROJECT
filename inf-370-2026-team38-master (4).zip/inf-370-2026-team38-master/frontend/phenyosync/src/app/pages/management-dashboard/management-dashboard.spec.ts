/**
 * Reviewer guide: Verifies the management dashboard frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ChangeDetectorRef } from '@angular/core';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { AuthorizationService } from '../../services/authorization';
import { OperationalSectionsService } from '../../services/operational-sections';
import { ManagementDashboardComponent } from './management-dashboard';

// Covers the management dashboard behavior most likely to regress across permissions and workflow changes.
describe('ManagementDashboardComponent navigation', () => {
  // Reviewer note: Guards the observable rule that permission-scopes Raw Stock so Operations Manager cannot see the link.
  it('permission-scopes Raw Stock so Operations Manager cannot see the link', () => {
    const authorization = {
      has: vi.fn().mockImplementation(
        (permission: string) => permission !== 'RawStock.View')
    } as unknown as AuthorizationService;
    const operational = {
      dashboard: () => of({})
    } as unknown as OperationalSectionsService;
    const changeDetector = {
      detectChanges: () => undefined
    } as unknown as ChangeDetectorRef;
    const component = new ManagementDashboardComponent(
      operational,
      changeDetector,
      authorization);

    const rawStock = component.menuItems.find(
      item => item.route === '/raw-stock');

    expect(rawStock?.permissions).toEqual(['RawStock.View']);
    expect(component.can('RawStock.View')).toBe(false);
  });
});
