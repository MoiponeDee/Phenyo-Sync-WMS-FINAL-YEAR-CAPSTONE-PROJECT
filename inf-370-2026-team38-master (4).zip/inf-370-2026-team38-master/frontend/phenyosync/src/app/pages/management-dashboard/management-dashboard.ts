/**
 * Reviewer guide: Coordinates the management dashboard page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { SidebarComponent } from '../../components/sidebar/sidebar';
import { TopbarComponent } from '../../components/topbar/topbar';
import { AuthorizationService } from '../../services/authorization';
import {
  DashboardGraphPoint,
  ManagementDashboard,
  OperationalSectionsService
} from '../../services/operational-sections';

@Component({
  selector: 'app-management-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    TopbarComponent,
    SidebarComponent
  ],
  templateUrl: './management-dashboard.html'
})
/** Presents backend-aggregated KPIs without recalculating operational totals in the browser. */
export class ManagementDashboardComponent implements OnInit {
  data: ManagementDashboard | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  fromDate = this.dateValue(new Date(Date.now() - 29 * 86400000));
  toDate = this.dateValue(new Date());
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  readonly menuItems = [
    { name: 'Management Overview', route: '/management-dashboard', active: true },
    { name: 'Raw Stock Control', route: '/raw-stock', permissions: ['RawStock.View'] },
    { name: 'Buying Lists', route: '/buying-lists', permissions: ['BuyingList.View'] },
    { name: 'Customers', route: '/customers', permissions: ['Customers.View'] },
    { name: 'Suppliers & Orders', route: '/suppliers', permissions: ['Suppliers.View'] },
    { name: 'Payments', route: '/payments', permissions: ['Payments.View'] },
    { name: 'Order Management', route: '/order-management', permissions: ['Orders.View'] },
    { name: 'Delivery Operations', route: '/deliveries', permissions: ['Deliveries.ViewAll', 'Deliveries.AssignDriver'] },
    { name: 'Track Driver', route: '/mobile-operations-control', permissions: ['Mobile.Tracking.ViewAll'] },
    { name: 'Audit Trail', route: '/audit-logs', permissions: ['AuditLogs.View'] }
  ];

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private operational: OperationalSectionsService,
    private changeDetector: ChangeDetectorRef,
    readonly authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.errorMessage = '';
    const from = new Date(`${this.fromDate}T00:00:00`).toISOString();
    const to = new Date(`${this.toDate}T23:59:59`).toISOString();
    this.operational.dashboard(from, to).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: data => this.data = data,
      error: error => this.errorMessage =
        error?.error?.message || 'The operational dashboard could not be loaded.'
    });
  }

  /**
   * Reviewer note: Encapsulates the width view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  width(point: DashboardGraphPoint, points: DashboardGraphPoint[]): number {
    const maximum = Math.max(...points.map(item => item.value), 1);
    return Math.max(2, Math.round(point.value / maximum * 100));
  }

  /**
   * Reviewer note: Calculates can for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  can(permission: string): boolean {
    return this.authorization.has(permission);
  }

  /**
   * Reviewer note: Encapsulates the date value view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private dateValue(value: Date): string {
    return value.toISOString().slice(0, 10);
  }
}
