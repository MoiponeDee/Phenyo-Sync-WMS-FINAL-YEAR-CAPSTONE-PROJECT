/**
 * Reviewer guide: Verifies the complete delivery frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute } from '@angular/router';
import { provideRouter } from '@angular/router';
import { CompleteDelivery } from './complete-delivery';
import { environment } from '../../../environments/environment';

// Covers the complete delivery behavior most likely to regress across permissions and workflow changes.
describe('CompleteDelivery', () => {
  // Reviewer note: Guards the observable rule that rejects submission until recipient and fulfillment are confirmed.
  it('rejects submission until recipient and fulfillment are confirmed', async () => {
    await TestBed.configureTestingModule({
      imports: [CompleteDelivery],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([]),
        {
          provide: ActivatedRoute,
          useValue: { snapshot: { paramMap: { get: () => '9' } } }
        }
      ]
    }).compileComponents();
    const fixture = TestBed.createComponent(CompleteDelivery);
    const component = fixture.componentInstance;
    const http = TestBed.inject(HttpTestingController);
    component.delivery = {
      deliveryId: 9, salesOrderId: 4, orderNumber: 'SO-TEST', customerName: 'Customer',
      deliveryAddress: 'Address', scheduledStartUtc: new Date().toISOString(),
      scheduledEndUtc: new Date().toISOString(), status: 'InTransit', canAssign: false,
      canStart: false, canComplete: true, rowVersion: '', customerNumber: 'CUS-TEST',
      orderStatus: 'OutForDelivery', assignmentHistory: [], statusHistory: []
    };

    component.submit();
    expect(component.errorMessage).toContain('receiving person');
    http.verify();
  });
});
