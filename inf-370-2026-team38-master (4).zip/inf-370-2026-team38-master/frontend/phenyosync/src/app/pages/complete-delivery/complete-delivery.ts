/**
 * Reviewer guide: Coordinates the complete delivery page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize, take, timeout } from 'rxjs';
import { TopbarComponent } from '../../components/topbar/topbar';
import {
  CompleteDeliveryRequest,
  DeliveryDetail,
  DeliveryProof,
  DeliveryProofImage,
  DeliveryService
} from '../../services/delivery';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';

@Component({
  selector: 'app-complete-delivery',
  standalone: true,
  imports: [CommonModule, FormsModule, TopbarComponent],
  templateUrl: './complete-delivery.html',
  styleUrl: './complete-delivery.css'
})
/** Captures proof and recipient confirmation before requesting backend delivery completion. */
export class CompleteDelivery implements OnInit, OnDestroy {
  deliveryId = 0;
  delivery: DeliveryDetail | null = null;
  proof: DeliveryProof | null = null;
  recipientName = '';
  recipientConfirmed = false;
  fulfillmentConfirmed = false;
  notes = '';
  proofReference = '';
  managementOverrideReason = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  proofImages: Array<DeliveryProofImage & { thumbnailUrl?: string }> = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedProofImage: File | null = null;
  proofCaption = '';
  proofIsPrimary = true;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  uploadingProof = false;
  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private deliveriesApi: DeliveryService,
    private changeDetector: ChangeDetectorRef,
    private authorization: AuthorizationService,
    private confirmations: ConfirmationService,
    private notifications: NotificationService
  ) {}

  /**
   * Reviewer note: Calculates is management for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  get isManagement(): boolean {
    return this.authorization.has('Deliveries.CompleteAny');
  }

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.deliveryId = Number(this.route.snapshot.paramMap.get('id'));
    if (!Number.isInteger(this.deliveryId) || this.deliveryId < 1) {
      this.errorMessage = 'The delivery reference is invalid.';
      return;
    }
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.deliveriesApi.get(this.deliveryId).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: delivery => {
        this.delivery = delivery;
        this.loadProofImages();
        if (!delivery.canComplete) {
          this.errorMessage = delivery.status === 'Completed'
            ? 'This delivery is already completed and cannot be submitted again.'
            : 'The delivery must be In Transit before completion.';
        }
      },
      error: error => this.errorMessage = this.errorText(error, 'Unable to load the delivery.')
    });
  }

  /**
   * Reviewer note: Encapsulates the choose proof image view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  chooseProofImage(event: Event): void {
    this.selectedProofImage =
      (event.target as HTMLInputElement).files?.[0] || null;
  }

  /**
   * Reviewer note: Coordinates the upload proof image interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  uploadProofImage(): void {
    // Upload proof before completion so the backend can enforce configured evidence requirements.
    this.errorMessage = '';
    if (!this.selectedProofImage) {
      this.errorMessage = 'Choose a JPEG, PNG or WebP proof image.';
      return;
    }
    this.uploadingProof = true;
    this.deliveriesApi.uploadProofImage(
      this.deliveryId,
      this.selectedProofImage,
      this.proofCaption.trim(),
      this.proofIsPrimary
    ).pipe(
      take(1),
      timeout(30000),
      finalize(() => {
        this.uploadingProof = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.selectedProofImage = null;
        this.proofCaption = '';
        this.proofIsPrimary = false;
        this.loadProofImages();
      },
      error: error => this.errorMessage =
        this.errorText(error, 'The proof image could not be uploaded.')
    });
  }

  /**
   * Reviewer note: Coordinates the remove proof image interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async removeProofImage(image: DeliveryProofImage): Promise<void> {
    const result = await this.confirmations.ask({
      title: 'Remove proof image?',
      message:
        'The image will be removed from the active gallery. Its audit history remains.',
      confirmLabel: 'Remove image',
      tone: 'danger',
      reasonLabel: 'Reason for removal',
      reasonRequired: true
    });
    if (!result.confirmed) return;
    this.deliveriesApi.removeProofImage(
      this.deliveryId,
      image.deliveryProofImageId,
      result.reason
    ).pipe(take(1)).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.loadProofImages();
      },
      error: error => this.notifications.error(
        this.errorText(error, 'The proof image could not be removed.'))
    });
  }

  /**
   * Reviewer note: Coordinates load proof images so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private loadProofImages(): void {
    this.deliveriesApi.proofImages(this.deliveryId).pipe(take(1)).subscribe({
      next: images => {
        this.clearImageUrls();
        this.proofImages = images.map(image => ({ ...image }));
        this.proofImages.forEach(image => {
          this.deliveriesApi.proofImageBlob(
            this.deliveryId,
            image.deliveryProofImageId,
            true
          ).pipe(take(1)).subscribe({
            next: blob => {
              image.thumbnailUrl = URL.createObjectURL(blob);
              this.changeDetector.detectChanges();
            }
          });
        });
      },
      error: error => this.errorMessage =
        this.errorText(error, 'Unable to load proof images.')
    });
  }

  /**
   * Reviewer note: Coordinates the submit interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  submit(): void {
    // Completion uses the latest RowVersion and server-side ownership/override validation.
    this.errorMessage = '';
    if (!this.delivery?.canComplete) {
      this.errorMessage = 'The delivery is not currently eligible for completion.';
      return;
    }
    if (this.recipientName.trim().length < 2) {
      this.errorMessage = 'Enter the receiving person’s name.';
      return;
    }
    if (!this.recipientConfirmed || !this.fulfillmentConfirmed) {
      this.errorMessage = 'Confirm both the recipient and successful fulfillment.';
      return;
    }
    if (!this.isManagement && this.proofImages.length === 0) {
      this.errorMessage =
        'Upload at least one proof-of-delivery image before completion.';
      return;
    }
    if (this.isManagement && this.managementOverrideReason.trim().length < 5) {
      this.errorMessage = 'Management completion on behalf of the driver requires a meaningful reason.';
      return;
    }
    const request: CompleteDeliveryRequest = {
      recipientName: this.recipientName.trim(),
      recipientConfirmed: this.recipientConfirmed,
      fulfillmentConfirmed: this.fulfillmentConfirmed,
      notes: this.notes.trim() || undefined,
      proofReference: this.proofReference.trim() || undefined,
      managementOverrideReason: this.isManagement
        ? this.managementOverrideReason.trim()
        : undefined,
      rowVersion: this.delivery.rowVersion || undefined
    };
    this.saving = true;
    this.deliveriesApi.complete(this.deliveryId, request).pipe(
      take(1),
      timeout(15000),
      finalize(() => {
        this.saving = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        this.successMessage = result.message;
        this.proof = result.proof;
        this.delivery = { ...this.delivery!, status: 'Completed', canComplete: false };
      },
      error: error => this.errorMessage = this.errorText(error, 'Unable to complete delivery.')
    });
  }

  /**
   * Reviewer note: Encapsulates the back view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  back(): void {
    this.router.navigate([
      this.authorization.session()?.roleCode === 'Driver'
        ? '/my-deliveries'
        : '/deliveries'
    ]);
  }

  /**
   * Reviewer note: Encapsulates the view proof view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  viewProof(): void {
    this.router.navigate(['/deliveries', this.deliveryId, 'proof']);
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    if (error instanceof Error && error.name === 'TimeoutError') return 'The request timed out.';
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) return 'Cannot connect to the backend API.';
      if (error.status === 401) return 'Your session has expired.';
      if (error.status === 403) return error.error?.message || 'You cannot complete this delivery.';
      if (error.status === 404) return error.error?.message || 'Delivery not found.';
      if (error.status === 409) return error.error?.message || 'The delivery is no longer eligible for completion.';
      return error.error?.message || fallback;
    }
    return fallback;
  }

  /**
   * Reviewer note: Encapsulates the clear image urls view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private clearImageUrls(): void {
    this.proofImages.forEach(image => {
      if (image.thumbnailUrl) URL.revokeObjectURL(image.thumbnailUrl);
    });
  }

  /**
   * Reviewer note: Releases subscriptions or device resources when the view is left to prevent duplicate background work.
   * Cleanup stops stale callbacks from mutating a page that is no longer active.
   */
  ngOnDestroy(): void {
    this.clearImageUrls();
  }
}
