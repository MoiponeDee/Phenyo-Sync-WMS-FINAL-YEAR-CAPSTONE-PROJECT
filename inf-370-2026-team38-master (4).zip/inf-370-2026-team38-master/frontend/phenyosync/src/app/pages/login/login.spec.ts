/**
 * Reviewer guide: Verifies the login frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { LoginComponent } from './login';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [LoginComponent], providers: [provideHttpClient(), provideRouter([])] }).compileComponents();
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
  });
  // Reviewer note: Guards the observable rule that should create.
  it('should create', () => expect(component).toBeTruthy());

  it('renders the exact company logo, required markers, password eye and visible sign in action', () => {
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;

    expect(element.querySelector<HTMLImageElement>('.company-logo')?.src)
      .toContain('/assets/phenyo-botlhe-logo.jpeg');
    expect(element.textContent).toContain('Email *');
    expect(element.textContent).toContain('Password *');
    expect(element.querySelector('.eye-btn')?.getAttribute('aria-label')).toBe('Show password');
    expect(element.textContent).toContain('Sign In');
    expect(element.querySelector('.topbar')).toBeNull();
    expect(element.querySelector<HTMLImageElement>('.welcome-poster')?.src)
      .toContain('/assets/phenyo-welcome-poster.svg');
    expect(element.textContent).toContain('Fresh stock.');
  });

  it('loads the optional Higgsfield welcome motion only after it is enabled', () => {
    component.welcomeMotionEnabled = true;
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    const video = element.querySelector<HTMLVideoElement>('.welcome-motion');
    const source = video?.querySelector<HTMLSourceElement>('source');
    expect(video?.getAttribute('aria-hidden')).toBe('true');
    expect(source?.src).toContain('fa9d12b1-172c-49ac-ac8f-985ab08017b8.mp4');
  });

  it('marks the forgot-password email as required', () => {
    component.showForgotPasswordModal = true;
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;

    expect(element.textContent).toContain('Email Address *');
    expect(element.querySelector<HTMLInputElement>('#resetEmail')?.required).toBe(true);
  });
});
