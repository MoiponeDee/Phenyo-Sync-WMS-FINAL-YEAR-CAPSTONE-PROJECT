/**
 * Reviewer guide: Coordinates the login page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component, HostListener,
  OnDestroy
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import {
  AuthenticationResult,
  AuthService,
  TwoFactorChallenge
} from '../../services/auth';
import { DashboardRouteService } from '../../services/dashboard-route';

type LoginStep = 'password' | 'otp' | 'recovery' | 'codes';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
/** Coordinates password, OTP/recovery and recovery-code acknowledgement login stages. */
export class LoginComponent implements AfterViewInit, OnDestroy {
  readonly welcomeMotionUrl = 'https://d8j0ntlcm91z4.cloudfront.net/user_3JIVZdfnIsRbMzNXIvsZ78pptT9/hf_20260921_140205_fa9d12b1-172c-49ac-ac8f-985ab08017b8.mp4';
  welcomeMotionEnabled = false;
  welcomeMotionLoaded = false;
  user = { email: '', password: '' };
  step: LoginStep = 'password';
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  showPassword = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  challenge: TwoFactorChallenge | null = null;
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  otp = '';
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  recoveryCode = '';
  trustDevice = false;
  deviceName = '';
  resendSeconds = 0;
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  recoveryCodes: string[] = [];
  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  recoveryCodesAcknowledged = false;
  private pendingSession: AuthenticationResult | null = null;
  private countdownHandle?: ReturnType<typeof setInterval>;
  private welcomeMotionHandle?: ReturnType<typeof setTimeout>;

  // Reviewer note: Keeps sensitive authentication input transient and sends it only through the authentication service.
  // The UI never treats possession of this value as permission to bypass backend verification.
  showForgotPasswordModal = false;
  resetEmail = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  resetLoading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  resetMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  resetError = '';
  resetAttempted = false;

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private changeDetector: ChangeDetectorRef,
    private dashboards: DashboardRouteService
  ) {}

  /** Keeps the sign-in form first to paint and only then requests optional welcome motion. */
  ngAfterViewInit(): void {
    if (typeof window === 'undefined' || typeof navigator === 'undefined') return;

    const prefersReducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    const savesData = (navigator as Navigator & { connection?: { saveData?: boolean } })
      .connection?.saveData ?? false;
    if (prefersReducedMotion || savesData || window.innerWidth < 900) return;

    this.welcomeMotionHandle = setTimeout(() => {
      this.welcomeMotionEnabled = true;
      this.changeDetector.detectChanges();
    }, 300);
  }

  onWelcomeMotionReady(event: Event): void {
    this.welcomeMotionLoaded = true;
    void (event.currentTarget as HTMLVideoElement).play().catch(() => {
      // Autoplay policy failures leave the already-rendered local poster in place.
    });
  }

  onWelcomeMotionError(): void {
    this.welcomeMotionLoaded = false;
    this.welcomeMotionEnabled = false;
  }

  /**
   * Reviewer note: Encapsulates the toggle password visibility view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  /**
   * Reviewer note: Encapsulates the login view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  login(): void {
    // Credentials are sent only to the authentication endpoint; role/permission state comes later.
    this.errorMessage = '';
    if (!this.user.email.trim() || !this.user.password) {
      this.errorMessage = 'Enter your email and password.';
      return;
    }
    this.loading = true;
    this.authService.login({
      email: this.user.email.trim(),
      password: this.user.password
    }).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => {
        if (this.isChallenge(result)) {
          this.challenge = result;
          this.step = 'otp';
          this.user.password = '';
          if (result.emailDeliveryFailed) {
            this.errorMessage = result.message ||
              'Email delivery failed. Use a saved recovery code or sign in again.';
          }
          this.beginCountdown(result.resendAfterSeconds);
          queueMicrotask(() =>
            document.getElementById('otp')?.focus());
          return;
        }
        this.finishAuthentication(result);
      },
      error: error => this.errorMessage = this.errorText(
        error,
        'Unable to sign in.')
    });
  }

  /**
   * Reviewer note: Encapsulates the verify otp view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  verifyOtp(): void {
    this.errorMessage = '';
    if (!this.challenge || !/^\d{6}$/.test(this.otp)) {
      this.errorMessage = 'Enter the six-digit verification code.';
      return;
    }
    this.loading = true;
    this.authService.verifyOtp({
      challengeToken: this.challenge.challengeToken,
      otp: this.otp,
      trustDevice: this.trustDevice,
      deviceName: this.deviceName.trim() || undefined
    }).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => this.handleVerified(result),
      error: error => this.errorMessage = this.errorText(
        error,
        'The verification code could not be accepted.')
    });
  }

  /**
   * Reviewer note: Encapsulates the verify recovery code view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  verifyRecoveryCode(): void {
    this.errorMessage = '';
    if (!this.challenge || this.recoveryCode.trim().length < 8) {
      this.errorMessage = 'Enter one of your saved recovery codes.';
      return;
    }
    this.loading = true;
    this.authService.verifyRecoveryCode({
      challengeToken: this.challenge.challengeToken,
      recoveryCode: this.recoveryCode.trim(),
      trustDevice: this.trustDevice,
      deviceName: this.deviceName.trim() || undefined
    }).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => this.handleVerified(result),
      error: error => this.errorMessage = this.errorText(
        error,
        'The recovery code could not be accepted.')
    });
  }

  /**
   * Reviewer note: Encapsulates the resend otp view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  resendOtp(): void {
    if (!this.challenge || this.resendSeconds > 0 || this.loading) {
      return;
    }
    this.errorMessage = '';
    this.loading = true;
    this.authService.resendOtp(
      this.challenge.challengeToken
    ).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: challenge => {
        this.challenge = challenge;
        this.otp = '';
        this.beginCountdown(challenge.resendAfterSeconds);
      },
      error: error => this.errorMessage = this.errorText(
        error,
        'A new code could not be sent.')
    });
  }

  /**
   * Reviewer note: Encapsulates the use recovery code view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  useRecoveryCode(): void {
    this.errorMessage = '';
    this.step = 'recovery';
    /**
     * Reviewer note: Encapsulates the queue microtask view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    queueMicrotask(() =>
      document.getElementById('recoveryCode')?.focus());
  }

  /**
   * Reviewer note: Encapsulates the use otp view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  useOtp(): void {
    this.errorMessage = '';
    this.step = 'otp';
  }

  /**
   * Reviewer note: Encapsulates the restart login view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  restartLogin(): void {
    this.stopCountdown();
    this.challenge = null;
    this.otp = '';
    this.recoveryCode = '';
    this.errorMessage = '';
    this.step = 'password';
  }

  /**
   * Reviewer note: Encapsulates the acknowledge recovery codes view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  acknowledgeRecoveryCodes(): void {
    if (!this.recoveryCodesAcknowledged || !this.pendingSession) {
      this.errorMessage =
        'Confirm that you saved the recovery codes before continuing.';
      return;
    }
    const result = this.pendingSession;
    this.pendingSession = null;
    this.recoveryCodes = [];
    this.finishAuthentication(result);
  }

  /**
   * Reviewer note: Encapsulates the download recovery codes view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  downloadRecoveryCodes(): void {
    // Recovery codes are available only in this one-time response and are never reloaded from storage.
    if (this.recoveryCodes.length === 0) return;
    const contents = [
      'PhenyoSync one-time recovery codes',
      'Store these securely. Each code works once.',
      '',
      ...this.recoveryCodes
    ].join('\n');
    const url = URL.createObjectURL(
      new Blob([contents], { type: 'text/plain' })
    );
    const link = document.createElement('a');
    link.href = url;
    link.download = 'PhenyoSync-Recovery-Codes.txt';
    link.click();
    URL.revokeObjectURL(url);
  }

  /**
   * Reviewer note: Encapsulates the print recovery codes view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  printRecoveryCodes(): void {
    window.print();
  }

  /**
   * Reviewer note: Coordinates the send reset link interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  sendResetLink(): void {
    const email = this.resetEmail.trim();
    this.resetAttempted = true;
    if (!this.validResetEmail(email)) {
      this.resetError = email
        ? 'Enter a valid email address.'
        : 'Email address is required.';
      this.resetMessage = '';
      queueMicrotask(() => document.getElementById('resetEmail')?.focus());
      return;
    }
    this.resetLoading = true;
    this.resetError = '';
    this.resetMessage = '';
    this.authService.forgotPassword(email).pipe(
      finalize(() => {
        this.resetLoading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: (response: any) => {
        this.resetMessage = response.message ||
          'If an account exists for that email, a reset link has been sent.';
        this.resetEmail = '';
        this.resetAttempted = false;
      },
      error: error => this.resetError = this.errorText(
        error,
        'The password reset email could not be sent.')
    });
  }

  validResetEmail(value = this.resetEmail.trim()): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  openForgotPassword(): void {
    this.resetError = '';
    this.resetMessage = '';
    this.resetAttempted = false;
    this.showForgotPasswordModal = true;
    queueMicrotask(() => document.getElementById('resetEmail')?.focus());
  }

  closeForgotPassword(): void {
    this.showForgotPasswordModal = false;
    queueMicrotask(() => document.getElementById('forgotPasswordTrigger')?.focus());
  }

  @HostListener('document:keydown.escape')
  closeForgotPasswordOnEscape(): void {
    if (this.showForgotPasswordModal) this.closeForgotPassword();
  }

  /**
   * Reviewer note: Releases subscriptions or device resources when the view is left to prevent duplicate background work.
   * Cleanup stops stale callbacks from mutating a page that is no longer active.
   */
  ngOnDestroy(): void {
    this.stopCountdown();
    if (this.welcomeMotionHandle) clearTimeout(this.welcomeMotionHandle);
    this.recoveryCodes = [];
    this.pendingSession = null;
  }

  /**
   * Reviewer note: Converts handle verified into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private handleVerified(result: AuthenticationResult): void {
    this.stopCountdown();
    if (result.recoveryCodes?.length) {
      this.pendingSession = result;
      this.recoveryCodes = [...result.recoveryCodes];
      this.step = 'codes';
      return;
    }
    this.finishAuthentication(result);
  }

  /**
   * Reviewer note: Encapsulates the finish authentication view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private finishAuthentication(result: AuthenticationResult): void {
    localStorage.setItem('token', result.token);
    localStorage.setItem('role', result.role);
    localStorage.setItem('user', JSON.stringify(result));
    const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
    const route = returnUrl?.startsWith('/')
      ? returnUrl
      : this.dashboards.forRole(result.role);
    void this.router.navigateByUrl(route || '/help');
  }

  /**
   * Reviewer note: Encapsulates the begin countdown view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private beginCountdown(seconds: number): void {
    this.stopCountdown();
    this.resendSeconds = Math.max(0, seconds);
    this.countdownHandle = setInterval(() => {
      this.resendSeconds = Math.max(0, this.resendSeconds - 1);
      if (this.resendSeconds === 0) this.stopCountdown();
      this.changeDetector.detectChanges();
    }, 1000);
  }

  /**
   * Reviewer note: Coordinates the stop countdown interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private stopCountdown(): void {
    if (this.countdownHandle) {
      clearInterval(this.countdownHandle);
      this.countdownHandle = undefined;
    }
  }

  /**
   * Reviewer note: Calculates is challenge for presentation and navigation only.
   * Hiding or disabling a control is not security; the API still authorises the request.
   */
  private isChallenge(
    result: TwoFactorChallenge | AuthenticationResult
  ): result is TwoFactorChallenge {
    return 'requiresTwoFactor' in result &&
      result.requiresTwoFactor === true;
  }

  /**
   * Reviewer note: Converts error text into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private errorText(error: unknown, fallback: string): string {
    if (error instanceof HttpErrorResponse) {
      return error.error?.message || fallback;
    }
    return fallback;
  }
}
