/**
 * Reviewer guide: Coordinates the help center page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { finalize, Subscription } from 'rxjs';
import {
  HelpCategory,
  HelpMedia,
  HelpService,
  HelpTopic,
  HelpTopicSummary
} from '../../services/help';
import { TopbarComponent } from '../../components/topbar/topbar';
import { SearchFieldComponent } from '../../components/search-field/search-field';

@Component({
  selector: 'app-help-center',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, TopbarComponent, SearchFieldComponent],
  templateUrl: './help-center.html',
  styleUrl: './help-center.css'
})
/** Resolves route-aware help and safely releases protected media object URLs. */
export class HelpCenter implements OnInit, OnDestroy {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  categories: HelpCategory[] = [];
  topics: HelpTopicSummary[] = [];
  topic: HelpTopic | null = null;
  featuredMedia: HelpMedia | null = null;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  query = '';
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedCategory: number | null = null;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  videoUrl: string | null = null;
  captionUrl: string | null = null;
  // Reviewer note: Retains a disposable browser or device resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  private routeSubscription?: Subscription;

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private help: HelpService,
    private route: ActivatedRoute,
    private router: Router,
    private changeDetector: ChangeDetectorRef
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.routeSubscription = this.route.paramMap.subscribe(params => {
      const slug = params.get('slug');
      if (slug) this.loadTopic(slug);
      else {
        this.query = this.route.snapshot.queryParamMap.get('query') || '';
        this.loadHome();
      }
    });
  }

  /**
   * Reviewer note: Coordinates load home so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadHome(): void {
    this.topic = null;
    this.loading = true;
    this.help.home().pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: home => {
        this.categories = home.categories;
        this.topics = home.recommended;
        this.featuredMedia = home.featuredMedia || null;
        if (this.featuredMedia) this.loadMedia(this.featuredMedia);
        if (this.query.trim()) this.search();
      },
      error: error => this.errorMessage =
        error.error?.message || 'Unable to load Help.'
    });
  }

  /**
   * Reviewer note: Coordinates search so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  search(): void {
    this.loading = true;
    this.errorMessage = '';
    this.topic = null;
    this.help.search(
      this.query.trim(),
      this.selectedCategory || undefined
    ).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: result => this.topics = result.items,
      error: error => this.errorMessage =
        error.error?.message || 'Help search could not be completed.'
    });
  }

  /**
   * Reviewer note: Coordinates select category so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  selectCategory(id: number | null): void {
    this.selectedCategory = id;
    this.search();
  }

  /**
   * Reviewer note: Coordinates open so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  open(slug: string): void {
    void this.router.navigate(['/help', slug]);
  }

  /**
   * Reviewer note: Encapsulates the download pdf view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  downloadPdf(): void {
    this.help.downloadPdf().subscribe(blob => {
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'PhenyoSync-User-Guide.pdf';
      link.click();
      URL.revokeObjectURL(url);
    });
  }

  /**
   * Reviewer note: Encapsulates the print view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  print(): void {
    window.print();
  }

  /**
   * Reviewer note: Releases subscriptions or device resources when the view is left to prevent duplicate background work.
   * Cleanup stops stale callbacks from mutating a page that is no longer active.
   */
  ngOnDestroy(): void {
    this.routeSubscription?.unsubscribe();
    this.revokeMediaUrls();
  }

  /**
   * Reviewer note: Coordinates load topic so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private loadTopic(slug: string): void {
    this.loading = true;
    this.errorMessage = '';
    this.revokeMediaUrls();
    this.help.topic(slug).pipe(
      finalize(() => {
        this.loading = false;
        this.changeDetector.detectChanges();
      })
    ).subscribe({
      next: topic => this.topic = topic,
      error: error => this.errorMessage =
        error.error?.message || 'The Help topic could not be loaded.'
    });
  }

  /**
   * Reviewer note: Coordinates load media so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private loadMedia(media: HelpMedia): void {
    this.revokeMediaUrls();
    this.help.mediaBlob(media.helpMediaId).subscribe(blob => {
      this.videoUrl = URL.createObjectURL(blob);
      this.changeDetector.detectChanges();
      if (media.hasCaptions) {
        this.help.captionsBlob(media.helpMediaId).subscribe(captions => {
          this.captionUrl = URL.createObjectURL(captions);
          this.changeDetector.detectChanges();
        });
      }
    });
  }

  /**
   * Reviewer note: Coordinates the revoke media urls interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private revokeMediaUrls(): void {
    if (this.videoUrl) URL.revokeObjectURL(this.videoUrl);
    if (this.captionUrl) URL.revokeObjectURL(this.captionUrl);
    this.videoUrl = null;
    this.captionUrl = null;
  }
}
