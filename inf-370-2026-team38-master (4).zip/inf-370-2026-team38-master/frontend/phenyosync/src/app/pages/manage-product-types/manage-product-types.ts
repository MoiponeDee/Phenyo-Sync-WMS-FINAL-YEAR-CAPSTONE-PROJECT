/**
 * Reviewer guide: Coordinates the manage product types page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { Component } from '@angular/core';
import { LookupManagement } from '../lookup-management/lookup-management';

@Component({
  selector: 'app-manage-product-types',
  standalone: true,
  imports: [LookupManagement],
  template: '<app-lookup-management kind="type" />'
})
export class ManageProductTypes {}
