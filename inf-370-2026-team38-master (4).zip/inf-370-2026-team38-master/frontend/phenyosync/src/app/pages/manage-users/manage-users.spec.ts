/**
 * Reviewer guide: Verifies the manage users frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting
} from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ManageUsers } from './manage-users';
import { AuthorizationService } from '../../services/authorization';

// Locks friendly role choices to their intended persisted backend role codes.
describe('ManageUsers', () => {
  let fixture: ComponentFixture<ManageUsers>;
  let component: ManageUsers;
  let http: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManageUsers],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([])
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ManageUsers);
    component = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    fixture.detectChanges();

    http.expectOne(`${environment.apiUrl}/roles/active`).flush([
      role(1, 'Admin', 'Super Admin'),
      role(2, 'AdminClerk', 'Admin'),
      role(3, 'OperationsManager', 'Operations Manager'),
      role(4, 'WarehouseManager', 'Warehouse Manager'),
      role(5, 'MarketBuyer', 'Market Buyer'),
      role(6, 'Packer', 'Packer'),
      role(7, 'Driver', 'Driver')
    ]);
    http.expectOne(request => request.url === `${environment.apiUrl}/users`)
      .flush({ items: [], page: 1, pageSize: 20, total: 0, totalPages: 0 });
    await fixture.whenStable();
  });

  afterEach(() => http.verify());

  it.each([
    [1, 'Super Admin'],
    [2, 'Admin'],
    [3, 'Operations Manager'],
    [4, 'Warehouse Manager'],
    [5, 'Market Buyer'],
    [6, 'Packer']
  ])('does not require a driver licence for %s (%s)', (roleId) => {
    component.openCreate();
    component.userForm.patchValue({ roleId: Number(roleId) });

    expect(component.creatingDriver).toBe(false);
    expect(component.userForm.controls.licenseNumber.hasError('required'))
      .toBe(false);
  });

  // Reviewer note: Guards the observable rule that requires a licence only when creating a Driver.
  it('requires licence number and expiry only when Driver is selected', () => {
    component.openCreate();
    component.userForm.patchValue({ roleId: 7 });

    expect(component.creatingDriver).toBe(true);
    expect(component.userForm.controls.licenseNumber.hasError('required'))
      .toBe(true);
    expect(component.userForm.controls.licenseExpiryDate.hasError('required'))
      .toBe(true);
  });

  // Reviewer note: Guards the observable rule that clears stale driver-only values after changing to a non-driver role.
  it('clears stale driver-only values after changing to a non-driver role', () => {
    component.openCreate();
    component.userForm.patchValue({
      roleId: 7,
      licenseNumber: 'DRV-100',
      licenseExpiryDate: '2027-10-01',
      vehicleAssigned: 'Truck 4'
    });

    component.userForm.patchValue({ roleId: 2 });

    expect(component.userForm.controls.licenseNumber.value).toBe('');
    expect(component.userForm.controls.licenseExpiryDate.value).toBe('');
    expect(component.userForm.controls.vehicleAssigned.value).toBe('');
  });

  // Reviewer note: Guards the observable rule that shows Super Admin as Admin and Admin as AdminClerk without a SuperAdmin role.
  it('shows Super Admin as Admin and Admin as AdminClerk without a SuperAdmin role', () => {
    expect(component.roles.find(item => item.roleName === 'Super Admin')?.roleCode)
      .toBe('Admin');
    expect(component.roles.find(item => item.roleName === 'Admin')?.roleCode)
      .toBe('AdminClerk');
    expect(component.roles.some(item => item.roleCode === 'SuperAdmin')).toBe(false);
  });

  it('shows one friendly Admin creation option and reveals the Super Admin toggle for a Super Admin', async () => {
    setSession('Admin', 'Super Admin');
    await openCreateFromUi();

    const roleSelect = fixture.nativeElement.querySelector('#roleId') as HTMLSelectElement;
    const optionLabels = Array.from(roleSelect.options).map(option => option.text.trim());
    expect(optionLabels.filter(label => label === 'Admin')).toHaveLength(1);
    expect(optionLabels).not.toContain('Super Admin');

    component.userForm.patchValue({ roleId: 2 });
    fixture.changeDetectorRef.markForCheck();
    await fixture.whenStable();

    expect(fixture.nativeElement.textContent).toContain('Grant Super Admin access');
  });

  it('renders the approved account, access and permission-guide structure', async () => {
    setSession('Admin', 'Super Admin');
    await openCreateFromUi();
    component.userForm.patchValue({ roleId: 2 });
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    expect(element.textContent).toContain('Account details');
    expect(element.textContent).toContain('Access, made clear');
    expect(element.textContent).toContain('Selected access');
    expect(component.selectedAccessLabel).toBe('Admin');

    const accessSwitch = element.querySelector<HTMLInputElement>('[role="switch"]');
    accessSwitch?.click();
    await fixture.whenStable();

    expect(component.selectedAccessLabel).toBe('Super Admin');
    expect(accessSwitch?.checked).toBe(true);
    expect(element.textContent).toContain('Full system administration, settings and role management.');
  });

  it('does not show the Super Admin toggle to a normal Admin', async () => {
    setSession('AdminClerk', 'Admin');
    await openCreateFromUi();
    component.userForm.patchValue({ roleId: 2 });
    fixture.changeDetectorRef.markForCheck();
    await fixture.whenStable();

    expect(fixture.nativeElement.querySelector('#roleId')).not.toBeNull();
    expect(fixture.nativeElement.textContent).not.toContain('Grant Super Admin access');
  });

  it('creates friendly Admin with the persisted AdminClerk role when elevation is off', () => {
    setSession('Admin', 'Super Admin');
    component.openCreate();
    component.userForm.patchValue({
      firstName: 'Standard',
      lastName: 'Administrator',
      email: 'standard.admin@example.test',
      roleId: 2,
      grantSuperAdmin: false
    });

    component.save();

    const request = http.expectOne(`${environment.apiUrl}/users`);
    expect(request.request.body.roleId).toBe(2);
    request.flush({ message: 'Created' });
    http.expectOne(req => req.url === `${environment.apiUrl}/users`)
      .flush({ items: [], page: 1, pageSize: 20, total: 0, totalPages: 0 });
  });

  it('maps the explicit Super Admin control to the persisted Admin role id', () => {
    TestBed.inject(AuthorizationService).session.set({
      userId: 99,
      email: 'owner@example.test',
      role: 'Super Admin',
      roleCode: 'Admin',
      isActive: true,
      permissions: []
    });
    component.openCreate();
    component.userForm.patchValue({
      firstName: 'New',
      lastName: 'Owner',
      email: 'new.owner@example.test',
      roleId: 2,
      grantSuperAdmin: true
    });

    component.save();

    const request = http.expectOne(`${environment.apiUrl}/users`);
    expect(request.request.body.roleId).toBe(1);
    request.flush({ message: 'Created' });
    http.expectOne(req => req.url === `${environment.apiUrl}/users`)
      .flush({ items: [], page: 1, pageSize: 20, total: 0, totalPages: 0 });
  });

  it('shows and preserves the current administration level while editing', () => {
    component.openEdit(user(42, 1, 'Admin', 'Super Admin'));

    expect(component.userForm.controls.roleId.value).toBe(1);
    expect(component.editing?.role).toBe('Super Admin');
    expect(component.roles.find(item => item.roleId === 1)?.roleName)
      .toBe('Super Admin');
    component.save();

    const update = http.expectOne(`${environment.apiUrl}/users/42`);
    expect(update.request.method).toBe('PUT');
    update.flush({ message: 'Updated', rowVersion: 'fresh-version' });
    http.expectNone(`${environment.apiUrl}/users/42/assign-role`);
    http.expectOne(req => req.url === `${environment.apiUrl}/users`)
      .flush({ items: [], page: 1, pageSize: 20, total: 0, totalPages: 0 });
  });

  it('loads persisted AdminClerk as friendly Admin while editing', () => {
    component.openEdit(user(42, 2, 'AdminClerk', 'Admin'));

    expect(component.userForm.controls.roleId.value).toBe(2);
    expect(component.editing?.role).toBe('Admin');
    expect(component.roles.find(item => item.roleId === 2)?.roleName)
      .toBe('Admin');
  });

  it('changes administration level in the same atomic user update', () => {
    component.openEdit(user(42, 2, 'AdminClerk', 'Admin'));
    component.userForm.patchValue({
      roleId: 1,
      roleChangeReason: 'Approved elevation'
    });

    component.save();

    const update = http.expectOne(`${environment.apiUrl}/users/42`);
    expect(update.request.body.roleId).toBe(1);
    expect(update.request.body.roleChangeReason).toBe('Approved elevation');
    expect(update.request.body.rowVersion).toBe('original-version');
    update.flush({ message: 'Updated', rowVersion: 'fresh-version' });
    http.expectNone(`${environment.apiUrl}/users/42/assign-role`);
    http.expectOne(req => req.url === `${environment.apiUrl}/users`)
      .flush({ items: [], page: 1, pageSize: 20, total: 0, totalPages: 0 });
  });

  it('loads and preserves Driver details while editing and reports date-only licence status', () => {
    const driver = {
      ...user(42, 7, 'Driver', 'Driver'),
      licenseNumber: 'DRV-100',
      licenseExpiryDate: '2099-10-01T00:00:00',
      vehicleAssigned: 'Fleet 4'
    };

    component.openEdit(driver);

    expect(component.userForm.controls.licenseNumber.value).toBe('DRV-100');
    expect(component.userForm.controls.licenseExpiryDate.value).toBe('2099-10-01');
    expect(component.userForm.controls.vehicleAssigned.value).toBe('Fleet 4');
    expect(component.driverLicenseStatus).toBe('Valid');

    component.save();
    const update = http.expectOne(`${environment.apiUrl}/users/42`);
    expect(update.request.body).toEqual(expect.objectContaining({
      roleId: 7,
      licenseNumber: 'DRV-100',
      licenseExpiryDate: '2099-10-01',
      vehicleAssigned: 'Fleet 4'
    }));
    update.flush({ message: 'Updated', rowVersion: 'fresh-version' });
    http.expectOne(req => req.url === `${environment.apiUrl}/users`)
      .flush({ items: [], page: 1, pageSize: 20, total: 0, totalPages: 0 });
  });

  it('uses inclusive date-only licence warning boundaries without negative wording', () => {
    const dateValue = (offsetDays: number) => {
      const value = new Date();
      value.setHours(12, 0, 0, 0);
      value.setDate(value.getDate() + offsetDays);
      return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, '0')}-${String(value.getDate()).padStart(2, '0')}`;
    };

    expect(component.licenseStatusFor(dateValue(31))).toBe('Valid');
    expect(component.licenseStatusFor(dateValue(30))).toBe('Expiring Soon');
    expect(component.licenceTimelineText(dateValue(30))).toBe('expires in 30 days');
    expect(component.licenseStatusFor(dateValue(0))).toBe('Expiring Soon');
    expect(component.licenceTimelineText(dateValue(0))).toBe('expires today');
    expect(component.licenseStatusFor(dateValue(-4))).toBe('Expired');
    expect(component.licenceTimelineText(dateValue(-4))).toBe('expired 4 days ago');
    expect(component.licenceTimelineText(dateValue(-4))).not.toContain('-4');
  });

  function setSession(roleCode: string, roleName: string): void {
    TestBed.inject(AuthorizationService).session.set({
      userId: 99,
      email: 'role.owner@example.test',
      role: roleName,
      roleCode,
      isActive: true,
      permissions: []
    });
  }

  async function openCreateFromUi(): Promise<void> {
    const createButton = Array.from(
      fixture.nativeElement.querySelectorAll('button') as NodeListOf<HTMLButtonElement>
    ).find(button => button.textContent?.trim() === 'Create user');
    expect(createButton).toBeDefined();
    createButton!.click();
    await fixture.whenStable();
  }
});

function role(roleId: number, roleCode: string, roleName: string) {
  return {
    roleId,
    roleCode,
    roleName,
    isSystemRole: true,
    isActive: true,
    assignedUsers: 0,
    effectivePermissionCount: 1,
    rowVersion: ''
  };
}

function user(userId: number, roleId: number, roleCode: string, roleName: string) {
  return {
    userId,
    email: 'reviewer@example.test',
    firstName: 'Review',
    lastName: 'User',
    phoneNumber: '',
    status: 'Active' as const,
    roleId,
    role: roleName,
    roleCode,
    rowVersion: 'original-version'
  };
}
