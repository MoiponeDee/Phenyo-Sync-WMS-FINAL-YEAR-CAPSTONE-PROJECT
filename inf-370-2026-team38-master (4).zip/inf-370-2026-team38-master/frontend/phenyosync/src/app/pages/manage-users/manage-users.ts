/**
 * Reviewer guide: Coordinates the manage users page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { SearchFieldComponent } from '../../components/search-field/search-field';
import { ConfirmationService } from '../../services/confirmation';
import { NotificationService } from '../../services/notification';
import { AuthorizationService } from '../../services/authorization';
import { httpErrorMessage } from '../../services/http-error-message';
import {
  RoleSummary,
  SecurityAdminService,
  UserSummary
} from '../../services/security-admin';

@Component({
  selector: 'app-manage-users',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterLink, SearchFieldComponent],
  templateUrl: './manage-users.html',
  styleUrl: '../security-management.css'
})
/** Manages accounts and role assignment while backend policies enforce administrative authority. */
export class ManageUsers implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  users: UserSummary[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  roles: RoleSummary[] = [];
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  search = '';
  role = '';
  status = '';
  page = 1;
  totalPages = 1;
  total = 0;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;
  private driverWarningShown = false;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';
  showEditor = false;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  showPermissions = false;
  editing?: UserSummary;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  permissionUser?: UserSummary;
  // Reviewer note: Controls presentation visibility or disabled state for the current session.
  // This is not a security boundary; the backend permission check remains authoritative.
  permissionModules: { module: string; permissions: { displayName: string; code: string }[] }[] = [];
  // Reviewer note: Defines the client-side input boundary before a narrow DTO is sent through the frontend service.
  // Browser validation improves feedback; the API validates the same business constraints independently.
  readonly userForm = new FormGroup({
    firstName: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(2), Validators.maxLength(50)]
    }),
    lastName: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(2), Validators.maxLength(50)]
    }),
    email: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.email, Validators.maxLength(100)]
    }),
    phoneNumber: new FormControl('', {
      nonNullable: true,
      validators: [Validators.maxLength(20)]
    }),
    roleId: new FormControl(0, {
      nonNullable: true,
      validators: [Validators.required, Validators.min(1)]
    }),
    grantSuperAdmin: new FormControl(false, { nonNullable: true }),
    roleChangeReason: new FormControl('', {
      nonNullable: true,
      validators: [Validators.maxLength(500)]
    }),
    licenseNumber: new FormControl('', {
      nonNullable: true,
      validators: [Validators.maxLength(100)]
    }),
    licenseExpiryDate: new FormControl('', { nonNullable: true }),
    vehicleAssigned: new FormControl('', {
      nonNullable: true,
      validators: [Validators.maxLength(100)]
    }),
    rowVersion: new FormControl('', { nonNullable: true })
  });

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private api: SecurityAdminService,
    private notifications: NotificationService,
    private confirmation: ConfirmationService,
    private changeDetector: ChangeDetectorRef,
    private authorization: AuthorizationService
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.userForm.controls.roleId.valueChanges.subscribe(() => {
      this.synchronizeDriverFields();
      this.synchronizeRoleReason();
    });
    this.loadRoles();
    this.load();
  }

  /**
   * Reviewer note: Coordinates load so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  load(): void {
    this.loading = true;
    this.errorMessage = '';
    this.api.searchUsers({
      search: this.search,
      role: this.role,
      status: this.status,
      page: this.page,
      pageSize: 20
    }).pipe(finalize(() => {
      this.loading = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: result => {
        this.users = result.items;
        this.total = result.total;
        this.totalPages = Math.max(1, result.totalPages);
        const warning = this.users.find(user =>
          user.roleCode === 'Driver' &&
          ['Expiring Soon', 'Expired'].includes(this.licenseStatusFor(user.licenseExpiryDate)));
        if (warning && !this.driverWarningShown) {
          this.driverWarningShown = true;
          this.notifications.warning(
            `${warning.firstName} ${warning.lastName}'s driver's licence ${this.licenceTimelineText(warning.licenseExpiryDate)}.`
          );
        }
      },
      error: error => this.errorMessage = error.error?.message || 'Users could not be loaded.'
    });
  }

  /**
   * Reviewer note: Coordinates the reset filters interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  resetFilters(): void {
    this.search = '';
    this.role = '';
    this.status = '';
    this.page = 1;
    this.load();
  }

  /**
   * Reviewer note: Coordinates open create so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openCreate(): void {
    this.editing = undefined;
    this.userForm.reset(this.emptyForm());
    this.synchronizeDriverFields();
    this.synchronizeRoleReason();
    this.showEditor = true;
  }

  /**
   * Reviewer note: Coordinates open edit so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  openEdit(user: UserSummary): void {
    this.editing = user;
    this.userForm.reset({
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      phoneNumber: user.phoneNumber || '',
      roleId: user.roleId,
      grantSuperAdmin: false,
      roleChangeReason: '',
      licenseNumber: user.licenseNumber || '',
      licenseExpiryDate: this.toDateInput(user.licenseExpiryDate),
      vehicleAssigned: user.vehicleAssigned || '',
      rowVersion: user.rowVersion
    });
    this.synchronizeDriverFields();
    this.synchronizeRoleReason();
    this.showEditor = true;
  }

  /**
   * Reviewer note: Coordinates the save interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  save(): void {
    this.userForm.markAllAsTouched();
    if (this.userForm.invalid) {
      this.errorMessage = this.userForm.controls.roleChangeReason.invalid
        ? 'Enter a role change reason of at least five characters.'
        : this.creatingDriver && (
          this.userForm.controls.licenseNumber.hasError('required') ||
          this.userForm.controls.licenseExpiryDate.hasError('required'))
        ? 'Enter the driver licence number and expiry date.'
        : 'Complete the required user fields with a valid email and role.';
      this.focusFirstInvalidControl();
      return;
    }

    const form = this.userForm.getRawValue();
    const selectedRole = this.roles.find(item => item.roleId === form.roleId);
    const roleId = !this.editing && selectedRole?.roleCode === 'AdminClerk' && form.grantSuperAdmin
      ? this.roles.find(item => item.roleCode === 'Admin')?.roleId ?? form.roleId
      : form.roleId;
    this.saving = true;
    this.errorMessage = '';
    // Persisted role codes come from server options; friendly labels are presentation only.
    const roleChanged = !!this.editing && roleId !== this.editing.roleId;
    if (roleChanged && form.roleChangeReason.trim().length < 5) {
      this.saving = false;
      this.errorMessage = 'Enter a reason of at least five characters for the administration or role change.';
      this.focusFirstInvalidControl();
      return;
    }
    const payload = {
          firstName: form.firstName.trim(),
          lastName: form.lastName.trim(),
          email: form.email.trim(),
          phoneNumber: form.phoneNumber.trim() || null,
          roleId,
          roleChangeReason: roleChanged ? form.roleChangeReason.trim() : null,
          licenseNumber: this.creatingDriver
            ? form.licenseNumber.trim()
            : null,
          licenseExpiryDate: this.creatingDriver
            ? form.licenseExpiryDate
            : null,
          vehicleAssigned: this.creatingDriver
            ? form.vehicleAssigned.trim() || null
            : null,
          ...(this.editing ? { rowVersion: form.rowVersion } : {})
        };
    const request = this.editing
      ? this.api.updateUser(this.editing.userId, payload)
      : this.api.createUser(payload);
    request.pipe(finalize(() => {
      this.saving = false;
      this.changeDetector.detectChanges();
    })).subscribe({
      next: response => {
        this.notifications.success(response.message);
        this.showEditor = false;
        this.load();
      },
      error: error => this.errorMessage = this.readError(error)
    });
  }

  /**
   * Reviewer note: Coordinates the change status interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async changeStatus(user: UserSummary): Promise<void> {
    const activating = user.status !== 'Active';
    const result = await this.confirmation.ask({
      title: activating ? 'Reactivate user' : 'Deactivate user',
      message: activating
        ? `Restore access for ${user.firstName} ${user.lastName}?`
        : `End all current access for ${user.firstName} ${user.lastName}? Historical records will be retained.`,
      confirmLabel: activating ? 'Reactivate' : 'Deactivate',
      tone: activating ? 'default' : 'danger',
      reasonLabel: 'Reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;

    this.api.changeUserStatus(
      user.userId,
      activating,
      result.reason,
      user.rowVersion
    ).subscribe({
      next: response => { this.notifications.success(response.message); this.load(); },
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Coordinates the assign role interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async assignRole(user: UserSummary, roleId: number): Promise<void> {
    if (roleId === user.roleId) return;
    const selected = this.roles.find(item => item.roleId === roleId);
    const result = await this.confirmation.ask({
      title: 'Assign role',
      message: `Change ${user.firstName} ${user.lastName} from ${user.role} to ${selected?.roleName || 'the selected role'}? Their current session will end.`,
      confirmLabel: 'Assign role',
      reasonLabel: 'Reason',
      reasonRequired: true
    });
    if (!result.confirmed) return;

    this.api.assignRole(
      user.userId,
      roleId,
      result.reason,
      user.rowVersion
    ).subscribe({
      next: response => { this.notifications.success(response.message); this.load(); },
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Coordinates the reset password interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  async resetPassword(user: UserSummary): Promise<void> {
    const result = await this.confirmation.ask({
      title: 'Send password reset',
      message: `Send a one-time secure reset link to ${user.email}?`,
      confirmLabel: 'Send link'
    });
    if (!result.confirmed) return;
    this.api.triggerPasswordReset(user.userId).subscribe({
      next: response => this.notifications.success(response.message),
      error: error => this.notifications.error(this.readError(error))
    });
  }

  /**
   * Reviewer note: Encapsulates the view permissions view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  viewPermissions(user: UserSummary): void {
    this.permissionUser = user;
    this.permissionModules = [];
    this.showPermissions = true;
    this.api.userPermissions(user.userId).subscribe({
      next: session => {
        const groups = new Map<string, { displayName: string; code: string }[]>();
        session.permissions.forEach(permission => {
          const items = groups.get(permission.module) || [];
          items.push(permission);
          groups.set(permission.module, items);
        });
        this.permissionModules = [...groups.entries()].map(([module, permissions]) => ({
          module, permissions
        }));
        this.changeDetector.detectChanges();
      },
      error: error => {
        this.errorMessage = this.readError(error);
        this.changeDetector.detectChanges();
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the previous view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  previous(): void {
    if (this.page > 1) { this.page--; this.load(); }
  }

  /**
   * Reviewer note: Encapsulates the next view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  next(): void {
    if (this.page < this.totalPages) { this.page++; this.load(); }
  }

  /**
   * Reviewer note: Encapsulates the creating driver view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  get creatingDriver(): boolean {
    return this.roles.find(
      item => item.roleId === this.userForm.controls.roleId.value
    )?.roleCode === 'Driver';
  }

  get driverLicenseStatus(): 'Valid' | 'Expiring Soon' | 'Expired' | '' {
    if (!this.creatingDriver) return '';
    return this.licenseStatusFor(this.userForm.controls.licenseExpiryDate.value);
  }

  licenseStatusFor(value?: string | null): 'Valid' | 'Expiring Soon' | 'Expired' | '' {
    if (!value) return '';
    const [year, month, day] = value.slice(0, 10).split('-').map(Number);
    const expiry = new Date(year, month - 1, day);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const days = Math.round((expiry.getTime() - today.getTime()) / 86_400_000);
    if (days < 0) return 'Expired';
    if (days <= 30) return 'Expiring Soon';
    return 'Valid';
  }

  licenceDate(value?: string | null): string {
    if (!value) return 'Not recorded';
    const [year, month, day] = value.slice(0, 10).split('-').map(Number);
    return new Intl.DateTimeFormat('en-ZA', {
      day: 'numeric', month: 'short', year: 'numeric'
    }).format(new Date(year, month - 1, day));
  }

  licenceTimelineText(value?: string | null): string {
    if (!value) return 'has no expiry date recorded';
    const [year, month, day] = value.slice(0, 10).split('-').map(Number);
    const expiry = new Date(year, month - 1, day);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const days = Math.round((expiry.getTime() - today.getTime()) / 86_400_000);
    if (days < 0) return `expired ${Math.abs(days)} day${days === -1 ? '' : 's'} ago`;
    if (days === 0) return 'expires today';
    if (days <= 30) return `expires in ${days} day${days === 1 ? '' : 's'}`;
    return `expires on ${this.licenceDate(value)}`;
  }

  get driverLicenseStatusText(): string {
    const value = this.userForm.controls.licenseExpiryDate.value;
    if (!value || !this.driverLicenseStatus) return '';
    return `${this.driverLicenseStatus} · ${this.licenceTimelineText(value)}`;
  }

  get mayGrantSuperAdmin(): boolean {
    return this.authorization.session()?.roleCode === 'Admin';
  }

  get creationRoles(): RoleSummary[] {
    return this.roles.filter(item => item.roleCode !== 'Admin');
  }

  get assignableRoles(): RoleSummary[] {
    return this.mayGrantSuperAdmin
      ? this.roles
      : this.roles.filter(item => item.roleCode !== 'Admin');
  }

  get creatingAdministrator(): boolean {
    return this.roles.find(item => item.roleId === this.userForm.controls.roleId.value)
      ?.roleCode === 'AdminClerk';
  }

  /** Presents the friendly access level without leaking persisted role codes into the UI. */
  get selectedAccessLabel(): string {
    const selectedRole = this.roles.find(
      item => item.roleId === this.userForm.controls.roleId.value
    );

    if (!selectedRole) return 'Choose an access level';
    if (!this.editing && selectedRole.roleCode === 'AdminClerk' &&
        this.userForm.controls.grantSuperAdmin.value && this.mayGrantSuperAdmin) {
      return 'Super Admin';
    }

    return selectedRole.roleName;
  }

  /** Explains the currently selected access level while the API remains authoritative. */
  get selectedAccessDescription(): string {
    if (this.selectedAccessLabel === 'Super Admin') {
      return 'Full system administration, settings and role management.';
    }
    if (this.selectedAccessLabel === 'Admin') {
      return 'Standard administrative access for day-to-day user and system support.';
    }
    if (this.userForm.controls.roleId.value > 0) {
      return 'Access is limited to the permissions assigned to this role.';
    }
    return 'Select a role to preview the access that will be granted.';
  }

  /**
   * Reviewer note: Coordinates load roles so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private loadRoles(): void {
    this.api.activeRoles().subscribe({
      next: roles => {
        this.roles = roles;
        this.changeDetector.detectChanges();
      },
      error: error => {
        this.errorMessage = this.readError(error);
        this.changeDetector.detectChanges();
      }
    });
  }

  /**
   * Reviewer note: Encapsulates the empty form view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private emptyForm() {
    return {
      firstName: '',
      lastName: '',
      email: '',
      phoneNumber: '',
      roleId: 0,
      grantSuperAdmin: false,
      roleChangeReason: '',
      licenseNumber: '',
      licenseExpiryDate: '',
      vehicleAssigned: '',
      rowVersion: ''
    };
  }

  /**
   * Reviewer note: Encapsulates the synchronize driver fields view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private synchronizeDriverFields(): void {
    const license = this.userForm.controls.licenseNumber;
    const expiry = this.userForm.controls.licenseExpiryDate;
    const vehicle = this.userForm.controls.vehicleAssigned;

    if (this.creatingDriver) {
      license.setValidators([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(100)
      ]);
      expiry.setValidators([Validators.required]);
    } else {
      license.clearValidators();
      license.setValidators([Validators.maxLength(100)]);
      license.setValue('', { emitEvent: false });
      expiry.clearValidators();
      expiry.setValue('', { emitEvent: false });
      vehicle.setValue('', { emitEvent: false });
    }

    license.updateValueAndValidity({ emitEvent: false });
    expiry.updateValueAndValidity({ emitEvent: false });
    vehicle.updateValueAndValidity({ emitEvent: false });
  }

  private synchronizeRoleReason(): void {
    const reason = this.userForm.controls.roleChangeReason;
    if (this.editing && this.userForm.controls.roleId.value !== this.editing.roleId) {
      reason.setValidators([
        Validators.required,
        Validators.minLength(5),
        Validators.maxLength(500)
      ]);
    } else {
      reason.setValidators([Validators.maxLength(500)]);
    }
    reason.updateValueAndValidity({ emitEvent: false });
  }

  private toDateInput(value?: string | null): string {
    return value ? value.slice(0, 10) : '';
  }

  private focusFirstInvalidControl(): void {
    setTimeout(() => {
      document.querySelector<HTMLElement>(
        '.user-editor-form input.ng-invalid, .user-editor-form select.ng-invalid, .user-editor-form textarea.ng-invalid'
      )?.focus();
    });
  }

  /**
   * Reviewer note: Encapsulates the read error view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private readError(error: any): string {
    return httpErrorMessage(error, 'The user action could not be completed.');
  }
}
