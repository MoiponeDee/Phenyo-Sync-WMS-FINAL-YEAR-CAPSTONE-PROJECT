/**
 * Reviewer guide: Coordinates the update product page between view state, frontend services and API DTOs.
 * It presents validation and failures while the backend owns authorization and workflow invariants.
 */
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

import {
  finalize,
  forkJoin,
  take,
  timeout
} from 'rxjs';

import {
  ProductResponse,
  ProductService,
  UpdateProductRequest
} from '../../services/product';
import { ProductCategory, ProductLookupService, ProductType } from '../../services/product-lookups';

@Component({
  selector: 'app-update-product',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './update-product.html',
  styleUrl: './update-product.css'
})
/** Updates product master data with RowVersion protection against stale browser edits. */
export class UpdateProduct implements OnInit {
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  products: ProductResponse[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  productTypes: ProductType[] = [];
  // Reviewer note: Stores the latest DTO projection used for rendering; it is not authoritative business state.
  // Successful mutations refresh this view from the API rather than assuming submitted values were accepted.
  productCategories: ProductCategory[] = [];

  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedProductId: number | null = null;
  // Reviewer note: Stores the current view selection or filter sent to the service when authoritative data is refreshed.
  // The server validates identifiers, ranges, and permissions before returning results.
  selectedProduct: ProductResponse | null = null;

  productName = '';
  productTypeId: number | null = null;
  productCategoryId: number | null = null;
  size = '';
  shelfLifeDays: number | null = null;
  status = 'Active';
  qrCodeValue = '';

  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loadingProducts = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loadingProduct = false;
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  saving = false;

  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  successMessage = '';
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // The page clears or replaces it for each attempt so stale outcomes are not presented as current.
  errorMessage = '';

  /**
   * Reviewer note: Injects the page's framework and service collaborators explicitly so dependencies remain testable.
   * The page coordinates UI state while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private productService: ProductService,
    private lookupService: ProductLookupService,
    private changeDetector: ChangeDetectorRef,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  /**
   * Reviewer note: Initialises the view from route and session context, then requests authoritative state from the API.
   * Loading and failure state stay explicit so the template never assumes that data is available.
   */
  ngOnInit(): void {
    this.loadProducts();
  }

  /**
   * Reviewer note: Coordinates load products so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadProducts(): void {
    this.loadingProducts = true;
    this.errorMessage = '';

    /**
     * Reviewer note: Encapsulates the fork join view concern so the template remains declarative and state changes stay testable.
     * This helper prepares or presents data without replacing server-side workflow validation.
     */
    forkJoin({
      products: this.productService.getProducts(),
      types: this.lookupService.getActiveProductTypes(),
      categories: this.lookupService.getActiveProductCategories()
    })
      .pipe(
        take(1),
        timeout(15000),
        finalize(() => {
          this.loadingProducts = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe({
        next: data => {
          this.products = data.products.sort((first, second) =>
            first.productName.localeCompare(second.productName)
          );
          this.productTypes = data.types;
          this.productCategories = data.categories;

          const requestedId = Number(this.route.snapshot.queryParamMap.get('productId'));
          if (Number.isInteger(requestedId) && requestedId > 0) {
            this.selectedProductId = requestedId;
            this.loadSelectedProduct();
          }
        },

        error: (error: unknown) => {
          this.handleError(
            error,
            'Unable to load products.'
          );
        }
      });
  }

  /**
   * Reviewer note: Encapsulates the on product selected view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  onProductSelected(): void {
    this.successMessage = '';
    this.errorMessage = '';

    if (this.selectedProductId === null) {
      this.selectedProduct = null;
      this.clearProductFields();
      return;
    }

    this.loadSelectedProduct();
  }

  /**
   * Reviewer note: Coordinates load selected product so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  loadSelectedProduct(): void {
    // Reload the current detail and RowVersion before allowing an edit to be submitted.
    if (this.selectedProductId === null) {
      this.errorMessage =
        'Please select a product to update.';

      return;
    }

    this.loadingProduct = true;
    this.errorMessage = '';

    this.productService
      .getProductById(this.selectedProductId)
      .pipe(
        take(1),
        timeout(15000),
        finalize(() => {
          this.loadingProduct = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe({
        next: (product: ProductResponse) => {
          this.selectedProduct = product;

          this.productName = product.productName;
          this.productTypeId = product.productTypeId;
          this.productCategoryId =
            product.productCategoryId;

          this.size = product.size;
          this.shelfLifeDays = product.shelfLifeDays;
          this.status = product.status;
          this.qrCodeValue =
            product.qrCodeValue ?? '';
        },

        error: (error: unknown) => {
          this.selectedProduct = null;
          this.clearProductFields();

          this.handleError(
            error,
            'Unable to load the selected product.'
          );
        }
      });
  }

  /**
   * Reviewer note: Coordinates the update product interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  updateProduct(): void {
    // Association and uniqueness rules remain authoritative in the Product API.
    if (this.saving) {
      return;
    }

    this.successMessage = '';
    this.errorMessage = '';

    if (
      this.selectedProductId === null ||
      this.selectedProduct === null
    ) {
      this.errorMessage =
        'Please select a product to update.';

      return;
    }

    if (
      !this.productName.trim() ||
      this.productTypeId === null ||
      this.productCategoryId === null ||
      !this.size.trim() ||
      this.shelfLifeDays === null ||
      !this.status
    ) {
      this.errorMessage =
        'Please complete all required fields.';

      return;
    }

    if (
      this.productTypeId < 1 ||
      this.productCategoryId < 1
    ) {
      this.errorMessage =
        'Please select a valid product type and category.';

      return;
    }

    if (
      this.shelfLifeDays < 1 ||
      this.shelfLifeDays > 3650
    ) {
      this.errorMessage =
        'Shelf life must be between 1 and 3650 days.';

      return;
    }

    if (
      this.status !== 'Active' &&
      this.status !== 'Inactive'
    ) {
      this.errorMessage =
        'Status must be Active or Inactive.';

      return;
    }

    const request: UpdateProductRequest = {
      productName: this.productName.trim(),
      productTypeId: this.productTypeId,
      productCategoryId:
        this.productCategoryId,

      size: this.size.trim(),
      shelfLifeDays: this.shelfLifeDays,
      status: this.status
    };

    const productId = this.selectedProductId;

    this.saving = true;

    this.productService
      .updateProduct(productId, request)
      .pipe(
        take(1),
        timeout(15000),
        finalize(() => {
          this.saving = false;
          this.changeDetector.detectChanges();
        })
      )
      .subscribe({
        next: (response: { message: string }) => {
          this.successMessage =
            response.message ||
            'Product updated successfully.';

          this.updateProductInLocalList(
            productId,
            request
          );
        },

        error: (error: unknown) => {
          this.handleError(
            error,
            'Unable to update the product.'
          );
        }
      });
  }

  /**
   * Reviewer note: Coordinates the reset changes interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  resetChanges(): void {
    if (this.selectedProduct === null) {
      return;
    }

    this.productName =
      this.selectedProduct.productName;

    this.productTypeId =
      this.selectedProduct.productTypeId;

    this.productCategoryId =
      this.selectedProduct.productCategoryId;

    this.size =
      this.selectedProduct.size;

    this.shelfLifeDays =
      this.selectedProduct.shelfLifeDays;

    this.status =
      this.selectedProduct.status;

    this.qrCodeValue =
      this.selectedProduct.qrCodeValue ?? '';

    this.successMessage = '';
    this.errorMessage = '';
  }

  /**
   * Reviewer note: Coordinates the cancel interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  cancel(): void {
    if (
      this.loadingProducts ||
      this.loadingProduct ||
      this.saving
    ) {
      return;
    }

    this.router.navigate([
      '/packer-dashboard'
    ]);
  }

  /**
   * Reviewer note: Coordinates the update product in local list interaction in one place and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private updateProductInLocalList(
    productId: number,
    request: UpdateProductRequest
  ): void {
    const productType =
      this.productTypes.find(type =>
        type.productTypeId ===
        request.productTypeId
      );

    const productCategory =
      this.productCategories.find(category =>
        category.productCategoryId ===
        request.productCategoryId
      );

    const productIndex =
      this.products.findIndex(product =>
        product.productId === productId
      );

    if (productIndex === -1) {
      return;
    }

    const updatedProduct: ProductResponse = {
      ...this.products[productIndex],
      productName: request.productName,
      productTypeId: request.productTypeId,

      productTypeName:
        productType?.productTypeName ?? '',

      productCategoryId:
        request.productCategoryId,

      productCategoryName:
        productCategory?.productCategoryName ?? '',

      size: request.size,
      shelfLifeDays: request.shelfLifeDays,
      status: request.status,
      updatedAt: new Date().toISOString()
    };

    this.products[productIndex] =
      updatedProduct;

    this.selectedProduct =
      updatedProduct;

    this.products = [
      ...this.products
    ].sort((first, second) =>
      first.productName.localeCompare(
        second.productName
      )
    );
  }

  /**
   * Reviewer note: Encapsulates the clear product fields view concern so the template remains declarative and state changes stay testable.
   * This helper prepares or presents data without replacing server-side workflow validation.
   */
  private clearProductFields(): void {
    this.productName = '';
    this.productTypeId = null;
    this.productCategoryId = null;
    this.size = '';
    this.shelfLifeDays = null;
    this.status = 'Active';
    this.qrCodeValue = '';
  }

  /**
   * Reviewer note: Converts handle error into clear user-facing state while preserving a safe retry path.
   * Technical details and sensitive values are not exposed through the presentation layer.
   */
  private handleError(
    error: unknown,
    fallbackMessage: string
  ): void {
    console.error(
      'Update product error:',
      error
    );

    if (
      error instanceof Error &&
      error.name === 'TimeoutError'
    ) {
      this.errorMessage =
        'The request timed out. Check that the backend API is running.';

      return;
    }

    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) {
        this.errorMessage =
          'Cannot connect to the backend. Check the API URL, HTTPS certificate and CORS settings.';

        return;
      }

      if (error.status === 400) {
        this.errorMessage =
          error.error?.message ||
          this.getValidationMessage(error) ||
          'The product details are invalid.';

        return;
      }

      if (error.status === 401) {
        this.errorMessage =
          'Your login session has expired. Please log in again.';

        return;
      }

      if (error.status === 403) {
        this.errorMessage =
          'You do not have permission to update products.';

        return;
      }

      if (error.status === 404) {
        this.errorMessage =
          error.error?.message ||
          'The selected product could not be found.';

        return;
      }

      if (error.status === 500) {
        this.errorMessage =
          error.error?.message ||
          'A server or database error occurred.';

        return;
      }
    }

    this.errorMessage = fallbackMessage;
  }

  /**
   * Reviewer note: Coordinates get validation message so displayed state is refreshed or selected consistently.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private getValidationMessage(
    error: HttpErrorResponse
  ): string {
    const validationErrors =
      error.error?.errors as
        Record<string, string[]> | undefined;

    if (!validationErrors) {
      return '';
    }

    return Object.values(validationErrors)
      .flat()
      .join(' ');
  }
}
