import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchFieldComponent } from './search-field';

describe('SearchFieldComponent', () => {
  let fixture: ComponentFixture<SearchFieldComponent>;
  let component: SearchFieldComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SearchFieldComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(SearchFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('emits the trimmed query from the icon button and Enter key', () => {
    const values: string[] = [];
    component.search.subscribe(value => values.push(value));
    component.updateQuery('  invoice  ');
    fixture.detectChanges();

    const input = fixture.nativeElement.querySelector('input') as HTMLInputElement;
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    fixture.nativeElement.querySelector('.phenyo-search-submit').click();

    expect(values).toEqual(['invoice', 'invoice']);
  });

  it('clears the query and exposes icon-only accessible actions', () => {
    const changes: string[] = [];
    let cleared = false;
    component.queryChange.subscribe(value => changes.push(value));
    component.clear.subscribe(() => cleared = true);
    component.query = 'customer';
    fixture.detectChanges();

    const buttons = fixture.nativeElement.querySelectorAll('button');
    expect(buttons[0].getAttribute('aria-label')).toBe('Clear search');
    expect(buttons[1].getAttribute('aria-label')).toBe('Search');
    buttons[0].click();

    expect(changes).toEqual(['']);
    expect(cleared).toBe(true);
  });
});
