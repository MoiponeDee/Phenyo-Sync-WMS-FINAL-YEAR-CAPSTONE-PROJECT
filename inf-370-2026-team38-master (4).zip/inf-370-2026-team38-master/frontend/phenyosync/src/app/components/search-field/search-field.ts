import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  ViewChild
} from '@angular/core';
import { FormsModule } from '@angular/forms';

/** Shared search input with keyboard, clear and loading behaviour. */
@Component({
  selector: 'app-search-field',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search-field.html',
  styleUrl: './search-field.css'
})
export class SearchFieldComponent {
  private static nextId = 0;

  @Input() query: string | undefined = '';
  @Input() placeholder = 'Search';
  @Input() ariaLabel = 'Search';
  @Input() loading = false;
  @Input() disabled = false;
  @Input() maxLength: number | null = null;

  @Output() readonly queryChange = new EventEmitter<string>();
  @Output() readonly search = new EventEmitter<string>();
  @Output() readonly clear = new EventEmitter<void>();

  @ViewChild('searchInput') private input?: ElementRef<HTMLInputElement>;

  readonly inputId = `phenyo-search-${SearchFieldComponent.nextId++}`;

  updateQuery(value: string): void {
    this.query = value;
    this.queryChange.emit(value);
  }

  requestSearch(event?: Event): void {
    event?.preventDefault();
    event?.stopPropagation();
    if (this.disabled || this.loading) return;
    this.search.emit((this.query ?? '').trim());
  }

  clearQuery(): void {
    if (this.disabled || this.loading) return;
    this.updateQuery('');
    this.clear.emit();
    queueMicrotask(() => this.input?.nativeElement.focus());
  }
}
