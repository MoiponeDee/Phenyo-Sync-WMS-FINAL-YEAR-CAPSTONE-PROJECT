/**
 * Reviewer guide: Provides reusable confirmation dialog presentation while keeping domain work in services and APIs.
 * Any visibility or disabled state here is a UX aid, never a replacement for backend authorization.
 */
import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  HostListener,
  ViewChild,
  effect
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ConfirmationService } from '../../services/confirmation';

// Centralizes destructive-action wording so callers require an explicit user choice.
@Component({
  selector: 'app-confirmation-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './confirmation-dialog.html',
  styleUrl: './confirmation-dialog.css'
})
export class ConfirmationDialog {
  @ViewChild('dialog') private dialog?: ElementRef<HTMLElement>;

  reason = '';
  private previouslyFocused?: HTMLElement;

  /**
   * Reviewer note: Injects the component's framework and service collaborators explicitly so dependencies remain testable.
   * The component coordinates presentation while reusable HTTP contracts stay in frontend services.
   */
  constructor(readonly confirmation: ConfirmationService) {
    effect(() => {
      const current = this.confirmation.current();
      if (current) {
        this.previouslyFocused = document.activeElement as HTMLElement | undefined;
        setTimeout(() => this.focusableElements()[0]?.focus());
        return;
      }

      const returnTarget = this.previouslyFocused;
      this.previouslyFocused = undefined;
      setTimeout(() => returnTarget?.focus());
    });
  }

  /**
   * Reviewer note: Calculates can confirm for presentation or navigation only.
   * Hiding a control is not security; the API must still reject unauthorised callers.
   */
  get canConfirm(): boolean {
    const current = this.confirmation.current();
    return !current?.reasonRequired || this.reason.trim().length > 0;
  }

  /**
   * Reviewer note: Coordinates submit decision in one component boundary and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  submitDecision(): void {
    if (!this.canConfirm) return;
    this.confirmation.complete(true, this.reason);
    this.reason = '';
  }

  /**
   * Reviewer note: Coordinates cancel in one component boundary and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  cancel(): void {
    this.confirmation.cancel();
    this.reason = '';
  }

  @HostListener('document:keydown', ['$event'])
  /**
   * Reviewer note: Encapsulates on escape so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  onKeydown(event: KeyboardEvent): void {
    if (!this.confirmation.current()) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      this.cancel();
      return;
    }
    if (event.key !== 'Tab') return;

    const focusable = this.focusableElements();
    if (!focusable.length) {
      event.preventDefault();
      return;
    }
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  private focusableElements(): HTMLElement[] {
    return Array.from(this.dialog?.nativeElement.querySelectorAll<HTMLElement>(
      'button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])'
    ) ?? []).filter(element => !element.hasAttribute('hidden'));
  }
}
