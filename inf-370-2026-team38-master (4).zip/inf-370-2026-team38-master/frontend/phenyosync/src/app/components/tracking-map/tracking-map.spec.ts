/**
 * Reviewer guide: Verifies the tracking map frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { TrackingMap } from './tracking-map';

// Proves location content remains available when external map tiles cannot render.
describe('TrackingMap', () => {
  // Reviewer note: Guards the observable rule that provides the latest point in each route as a coordinate fallback.
  it('provides the latest point in each route as a coordinate fallback', () => {
    const component = new TrackingMap();
    component.series = [{
      label: 'Driver One',
      points: [
        {
          latitude: -25.75,
          longitude: 28.22,
          capturedAtUtc: '2026-08-24T10:00:00Z'
        },
        {
          latitude: -25.74,
          longitude: 28.24,
          capturedAtUtc: '2026-08-24T10:01:00Z'
        }
      ]
    }];

    expect(component.latestPoints).toEqual([{
      label: 'Driver One',
      point: component.series[0].points[1]
    }]);
  });

  // Reviewer note: Guards the observable rule that omits empty routes from the fallback list.
  it('omits empty routes from the fallback list', () => {
    const component = new TrackingMap();
    component.series = [{ label: 'Waiting Driver', points: [] }];
    expect(component.latestPoints).toEqual([]);
  });
});
