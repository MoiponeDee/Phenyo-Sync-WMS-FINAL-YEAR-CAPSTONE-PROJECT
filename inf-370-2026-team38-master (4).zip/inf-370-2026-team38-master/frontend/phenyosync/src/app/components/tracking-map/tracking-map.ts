/**
 * Reviewer guide: Provides reusable tracking map presentation while keeping domain work in services and APIs.
 * Any visibility or disabled state here is a UX aid, never a replacement for backend authorization.
 */
import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnDestroy,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import * as L from 'leaflet';

export interface TrackingMapPoint {
  latitude: number;
  longitude: number;
  capturedAtUtc: string;
  accuracyMetres?: number;
}

export interface TrackingMapSeries {
  label: string;
  points: TrackingMapPoint[];
}

@Component({
  selector: 'app-tracking-map',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div #mapHost class="map-host" [attr.aria-label]="ariaLabel"></div>
    <div class="map-fallback" *ngIf="mapError">
      <strong>Map tiles are unavailable</strong>
      <p>{{ mapError }}</p>
      <ul>
        <li *ngFor="let item of latestPoints">
          {{ item.label }}: {{ item.point.latitude | number:'1.5-5' }},
          {{ item.point.longitude | number:'1.5-5' }}
        </li>
      </ul>
    </div>
  `,
  styleUrl: './tracking-map.css'
})
/** Renders one or more tracking histories while retaining a coordinate fallback on tile failure. */
export class TrackingMap implements AfterViewInit, OnChanges, OnDestroy {
  @Input() series: TrackingMapSeries[] = [];
  @Input() ariaLabel = 'Live delivery tracking map';
  @ViewChild('mapHost') mapHost?: ElementRef<HTMLDivElement>;

  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  mapError = '';
  // Reviewer note: Retains a disposable browser resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  private map?: L.Map;
  private layerGroup?: L.LayerGroup;
  private hasPositionedView = false;
  private userMovedMap = false;

  /**
   * Reviewer note: Encapsulates latest points so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  get latestPoints(): Array<{ label: string; point: TrackingMapPoint }> {
    return this.series
      .filter(item => item.points.length > 0)
      .map(item => ({
        label: item.label,
        point: item.points[item.points.length - 1]
      }));
  }

  /**
   * Reviewer note: Initialises component state and requests any authoritative data needed by the rendered view.
   * Loading and error state remain explicit so asynchronous work cannot silently fail.
   */
  ngAfterViewInit(): void {
    this.renderMap();
  }

  /**
   * Reviewer note: Encapsulates ng on changes so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  ngOnChanges(_changes: SimpleChanges): void {
    if (this.map) {
      this.renderSeries();
    }
  }

  /**
   * Reviewer note: Releases subscriptions, timers or map/device resources when the component is destroyed.
   * Cleanup prevents duplicate callbacks and memory leaks after navigation.
   */
  ngOnDestroy(): void {
    this.map?.remove();
  }

  /**
   * Reviewer note: Encapsulates render map so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  private renderMap(): void {
    if (!this.mapHost || this.map) {
      return;
    }

    try {
      this.map = L.map(this.mapHost.nativeElement, {
        zoomControl: true,
        attributionControl: true
      }).setView([-25.7479, 28.2293], 11);
      this.map.on('dragstart', () => this.userMovedMap = true);

      const tiles = L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
      });
      tiles.on('tileerror', () => {
        this.mapError =
          'The latest coordinates remain available below for operational continuity.';
      });
      tiles.addTo(this.map);

      this.layerGroup = L.layerGroup().addTo(this.map);
      this.renderSeries();
      setTimeout(() => this.map?.invalidateSize(), 0);
    } catch {
      this.mapError =
        'The latest coordinates remain available below for operational continuity.';
    }
  }

  /**
   * Reviewer note: Encapsulates render series so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  private renderSeries(): void {
    if (!this.map || !this.layerGroup) {
      return;
    }

    // Rebuild transient Leaflet layers from immutable API points; no location is edited client-side.
    this.layerGroup.clearLayers();
    const bounds: L.LatLngExpression[] = [];
    const colours = ['#168044', '#1f6fb2', '#d07b14', '#8b4bb3'];

    this.series.forEach((item, index) => {
      const colour = colours[index % colours.length];
      const coordinates = item.points.map(point =>
        [point.latitude, point.longitude] as L.LatLngTuple);
      bounds.push(...coordinates);

      if (coordinates.length > 1) {
        L.polyline(coordinates, {
          color: colour,
          weight: 4,
          opacity: 0.75
        }).addTo(this.layerGroup!);
      }

      const latest = item.points[item.points.length - 1];
      if (latest) {
        L.circleMarker([latest.latitude, latest.longitude], {
          radius: 9,
          color: '#ffffff',
          weight: 3,
          fillColor: colour,
          fillOpacity: 1
        })
          .bindPopup(
            `<strong>${this.escape(item.label)}</strong><br>` +
            `${latest.latitude.toFixed(5)}, ${latest.longitude.toFixed(5)}<br>` +
            `${new Date(latest.capturedAtUtc).toLocaleString()}`
          )
          .addTo(this.layerGroup!);
      }
    });

    if (!this.hasPositionedView && !this.userMovedMap && bounds.length === 1) {
      this.map.setView(bounds[0], 15);
      this.hasPositionedView = true;
    } else if (!this.hasPositionedView && !this.userMovedMap && bounds.length > 1) {
      this.map.fitBounds(L.latLngBounds(bounds), { padding: [30, 30] });
      this.hasPositionedView = true;
    }
  }

  /**
   * Reviewer note: Encapsulates escape so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  private escape(value: string): string {
    // Popup HTML is generated by Leaflet, so labels must be escaped explicitly.
    return value.replace(/[&<>'"]/g, character => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    })[character] ?? character);
  }
}
