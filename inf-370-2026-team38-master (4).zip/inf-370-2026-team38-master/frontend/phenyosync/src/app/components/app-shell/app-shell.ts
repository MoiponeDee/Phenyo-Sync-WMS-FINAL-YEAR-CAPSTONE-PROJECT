/**
 * Reviewer guide: Provides reusable app shell presentation while keeping domain work in services and APIs.
 * Any visibility or disabled state here is a UX aid, never a replacement for backend authorization.
 */
import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild,
  signal
} from '@angular/core';
import {
  NavigationEnd,
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet
} from '@angular/router';
import { Subscription, filter } from 'rxjs';
import { WMS_NAVIGATION, NavigationItem, NavigationSection } from '../../navigation/navigation.config';
import { AuthorizationService } from '../../services/authorization';
import { ConfirmationService } from '../../services/confirmation';
import { ContextHelpButton } from '../context-help-button/context-help-button';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    RouterLinkActive,
    RouterOutlet,
    ContextHelpButton
  ],
  templateUrl: './app-shell.html',
  styleUrl: './app-shell.css'
})
/** Hosts permission-filtered navigation, current-page context and accessible menu focus handling. */
export class AppShell implements OnInit, OnDestroy {
  @ViewChild('menuButton') private menuButton?: ElementRef<HTMLButtonElement>;
  @ViewChild('drawer') private drawer?: ElementRef<HTMLElement>;

  readonly menuOpen = signal(false);
  readonly profileMenuOpen = signal(false);
  readonly currentLabel = signal('Dashboard');
  readonly currentRoute = signal('/dashboard');
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  readonly loadingSession = signal(true);
  readonly navigation = WMS_NAVIGATION;

  // Reviewer note: Retains a disposable browser resource so lifecycle cleanup can stop background work.
  // This prevents duplicate callbacks and stale updates after navigation.
  private readonly subscriptions = new Subscription();

  /**
   * Reviewer note: Injects the component's framework and service collaborators explicitly so dependencies remain testable.
   * The component coordinates presentation while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    readonly authorization: AuthorizationService,
    private readonly confirmation: ConfirmationService,
    private readonly router: Router
  ) {}

  /**
   * Reviewer note: Initialises component state and requests any authoritative data needed by the rendered view.
   * Loading and error state remain explicit so asynchronous work cannot silently fail.
   */
  ngOnInit(): void {
    this.updateCurrentPage(this.router.url);
    this.subscriptions.add(
      this.router.events.pipe(
        filter(event => event instanceof NavigationEnd)
      ).subscribe(event => {
        this.updateCurrentPage((event as NavigationEnd).urlAfterRedirects);
        this.closeMenu(false);
      })
    );
    this.subscriptions.add(
      this.authorization.ensureLoaded().subscribe({
        next: () => this.loadingSession.set(false),
        error: () => this.loadingSession.set(false)
      })
    );
  }

  /**
   * Reviewer note: Releases subscriptions, timers or map/device resources when the component is destroyed.
   * Cleanup prevents duplicate callbacks and memory leaks after navigation.
   */
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  /**
   * Reviewer note: Calculates visible items for presentation or navigation only.
   * Hiding a control is not security; the API must still reject unauthorised callers.
   */
  visibleItems(section: NavigationSection): NavigationItem[] {
    return section.items.filter(item =>
      !item.permissions?.length ||
      this.authorization.hasAny(...item.permissions)
    );
  }

  /**
   * Reviewer note: Encapsulates toggle menu so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  toggleMenu(): void {
    const open = !this.menuOpen();
    this.menuOpen.set(open);
    if (open) {
      setTimeout(() => {
        this.drawer?.nativeElement
          .querySelector<HTMLElement>('a, button')
          ?.focus();
      });
    }
  }

  /**
   * Reviewer note: Encapsulates toggle profile menu so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  toggleProfileMenu(): void {
    this.profileMenuOpen.update(open => !open);
  }

  /**
   * Reviewer note: Encapsulates close profile menu so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  closeProfileMenu(): void {
    this.profileMenuOpen.set(false);
  }

  /**
   * Reviewer note: Encapsulates close menu so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  closeMenu(returnFocus = true): void {
    if (!this.menuOpen()) return;
    this.menuOpen.set(false);
    if (returnFocus) {
      setTimeout(() => this.menuButton?.nativeElement.focus());
    }
  }

  /**
   * Reviewer note: Encapsulates logout so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  async logout(): Promise<void> {
    this.closeProfileMenu();
    const result = await this.confirmation.ask({
      title: 'Log out?',
      message: 'Are you sure you want to log out of PhenyoSync?',
      confirmLabel: 'Log out',
      cancelLabel: 'Stay signed in',
      tone: 'danger'
    });
    if (!result.confirmed) return;

    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('user');
    this.authorization.clear();
    void this.router.navigate(['/login']);
  }

  /**
   * Reviewer note: Encapsulates display name so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  displayName(): string {
    const stored = JSON.parse(localStorage.getItem('user') || '{}');
    const name = `${stored.firstName || ''} ${stored.lastName || ''}`.trim();
    return name || this.authorization.session()?.email || 'Signed-in user';
  }

  @HostListener('document:keydown.escape')
  /**
   * Reviewer note: Encapsulates on escape so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  onEscape(): void {
    this.closeMenu();
    this.closeProfileMenu();
  }

  /**
   * Reviewer note: Encapsulates display role so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  displayRole(): string {
    const role = this.authorization.session()?.role || '';
    if (role === 'Admin') return 'Super Admin';
    if (role === 'AdminClerk' || role === 'Admin Clerk') return 'Admin';
    return role;
  }

  /**
   * Reviewer note: Coordinates update current page in one component boundary and keeps any pending or error feedback visible.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  private updateCurrentPage(url: string): void {
    // Normalize query/fragment variations before matching route metadata for breadcrumbs/help.
    const route = url.split('?')[0].split('#')[0] || '/dashboard';
    const items = this.navigation.flatMap(section => section.items);
    const exact = items.find(item => item.route === route);
    const parent = items
      .filter(item => route.startsWith(`${item.route}/`))
      .sort((left, right) => right.route.length - left.route.length)[0];

    this.currentRoute.set(route);
    this.currentLabel.set(exact?.label || parent?.label || this.humanize(route));
  }

  /**
   * Reviewer note: Encapsulates humanize so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  private humanize(route: string): string {
    const segment = route.split('/').filter(Boolean).find(value => !/^\d+$/.test(value));
    if (!segment) return 'Dashboard';
    return segment
      .split('-')
      .map(value => value.charAt(0).toUpperCase() + value.slice(1))
      .join(' ');
  }
}

