/**
 * Reviewer guide: Verifies the topbar frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { Router } from '@angular/router';
import { ConfirmationService } from '../../services/confirmation';
import { TopbarComponent } from './topbar';

describe('TopbarComponent', () => {
  let component: TopbarComponent;
  let fixture: ComponentFixture<TopbarComponent>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [TopbarComponent], providers: [provideRouter([])] }).compileComponents();
    fixture = TestBed.createComponent(TopbarComponent);
    component = fixture.componentInstance;
  });
  // Reviewer note: Guards the observable rule that should create.
  it('should create', () => expect(component).toBeTruthy());

  it('keeps the session intact when logout is cancelled', async () => {
    localStorage.setItem('token', 'local-test-token');
    localStorage.setItem('role', 'Packer');
    localStorage.setItem('user', JSON.stringify({ role: 'Packer' }));
    const confirmation = TestBed.inject(ConfirmationService);

    const pending = component.logout();
    expect(confirmation.current()?.title).toBe('Log out?');
    expect(confirmation.current()?.cancelLabel).toBe('Stay signed in');
    expect(localStorage.getItem('token')).toBe('local-test-token');
    confirmation.complete(false);
    await pending;

    expect(localStorage.getItem('token')).toBe('local-test-token');
    expect(localStorage.getItem('role')).toBe('Packer');
    expect(localStorage.getItem('user')).toContain('Packer');
  });

  it('clears the session only after logout is confirmed', async () => {
    localStorage.setItem('token', 'local-test-token');
    localStorage.setItem('role', 'Packer');
    localStorage.setItem('user', JSON.stringify({ role: 'Packer' }));
    const confirmation = TestBed.inject(ConfirmationService);
    const router = TestBed.inject(Router);
    const navigate = vi.spyOn(router, 'navigate');

    const pending = component.logout();
    confirmation.complete(true);
    await pending;

    expect(localStorage.getItem('token')).toBeNull();
    expect(localStorage.getItem('role')).toBeNull();
    expect(localStorage.getItem('user')).toBeNull();
    expect(navigate).toHaveBeenCalledWith(['/login']);
  });
});
