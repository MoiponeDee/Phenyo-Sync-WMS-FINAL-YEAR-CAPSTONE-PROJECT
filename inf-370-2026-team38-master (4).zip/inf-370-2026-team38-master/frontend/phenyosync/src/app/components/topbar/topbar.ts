/**
 * Reviewer guide: Provides reusable topbar presentation while keeping domain work in services and APIs.
 * Any visibility or disabled state here is a UX aid, never a replacement for backend authorization.
 */
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthorizationService } from '../../services/authorization';
import { ContextHelpButton } from '../context-help-button/context-help-button';
import { DashboardRouteService } from '../../services/dashboard-route';
import { ConfirmationService } from '../../services/confirmation';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [CommonModule, RouterLink, ContextHelpButton],
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.css']
})
/** Presents current-user actions and notifications without treating displayed role data as security. */
export class TopbarComponent implements OnInit {
  user: any = JSON.parse(localStorage.getItem('user') || '{}');
  showProfileMenu = false;
  currentUser: any = null;

  /**
   * Reviewer note: Injects the component's framework and service collaborators explicitly so dependencies remain testable.
   * The component coordinates presentation while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private router: Router,
    private authorization: AuthorizationService,
    private confirmation: ConfirmationService,
    private dashboards: DashboardRouteService
  ) {}

  /**
   * Reviewer note: Encapsulates home route so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  get homeRoute(): string {
    return this.dashboards.forRole(
      this.currentUser?.role || this.user?.role);
  }

  /**
   * Reviewer note: Encapsulates display role so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  get displayRole(): string {
    const role = this.currentUser?.role || this.user?.role || '';
    if (role === 'Admin') return 'Super Admin';
    if (role === 'AdminClerk' || role === 'Admin Clerk') return 'Admin';
    return role;
  }

  /**
   * Reviewer note: Encapsulates logout so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  async logout(): Promise<void> {
    this.showProfileMenu = false;
    const result = await this.confirmation.ask({
      title: 'Log out?',
      message: 'Are you sure you want to log out of PhenyoSync?',
      confirmLabel: 'Log out',
      cancelLabel: 'Stay signed in',
      tone: 'danger'
    });
    if (!result.confirmed) return;

    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('user');
    this.authorization.clear();
    this.router.navigate(['/login']);
  }

  /**
   * Reviewer note: Initialises component state and requests any authoritative data needed by the rendered view.
   * Loading and error state remain explicit so asynchronous work cannot silently fail.
   */
  ngOnInit(): void {
    const storedUser = localStorage.getItem('user');
    this.currentUser = storedUser
      ? JSON.parse(storedUser)
      : null;
  }
}
