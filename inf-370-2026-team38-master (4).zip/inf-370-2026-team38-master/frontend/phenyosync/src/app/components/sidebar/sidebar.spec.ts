/**
 * Reviewer guide: Verifies the sidebar frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { SidebarComponent } from './sidebar';
import { AuthorizationService } from '../../services/authorization';

// Covers the sidebar behavior most likely to regress across permissions and workflow changes.
describe('SidebarComponent', () => {
  let component: SidebarComponent;
  let fixture: ComponentFixture<SidebarComponent>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [SidebarComponent], providers: [provideRouter([])] }).compileComponents();
    fixture = TestBed.createComponent(SidebarComponent);
    component = fixture.componentInstance;
  });
  // Reviewer note: Guards the observable rule that should create.
  it('should create', () => expect(component).toBeTruthy());

  // Reviewer note: Guards the observable rule that hides permission-scoped destinations when the session lacks access.
  it('hides permission-scoped destinations when the session lacks access', () => {
    component.menuItems = [
      { name: 'Suppliers', route: '/suppliers' },
      { name: 'Raw Stock', route: '/raw-stock', permissions: ['RawStock.View'] }
    ];
    TestBed.inject(AuthorizationService).session.set({
      userId: 4,
      email: 'operations@example.test',
      role: 'Operations Manager',
      roleCode: 'OperationsManager',
      isActive: true,
      permissions: []
    });

    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain('Suppliers');
    expect(fixture.nativeElement.textContent).not.toContain('Raw Stock');
  });

  // Reviewer note: Guards the observable rule that shows permission-scoped destinations to an authorised session.
  it('shows permission-scoped destinations to an authorised session', () => {
    component.menuItems = [
      { name: 'Raw Stock', route: '/raw-stock', permissions: ['RawStock.View'] }
    ];
    TestBed.inject(AuthorizationService).session.set({
      userId: 1,
      email: 'superadmin@example.test',
      role: 'Super Admin',
      roleCode: 'Admin',
      isActive: true,
      permissions: [{
        permissionId: 1,
        code: 'RawStock.View',
        displayName: 'View Raw Stock',
        module: 'RawStock'
      }]
    });

    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain('Raw Stock');
  });
});
