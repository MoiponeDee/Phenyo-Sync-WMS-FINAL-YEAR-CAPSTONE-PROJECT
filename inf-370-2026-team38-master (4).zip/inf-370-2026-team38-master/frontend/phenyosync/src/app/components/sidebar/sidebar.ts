/**
 * Reviewer guide: Provides reusable sidebar presentation while keeping domain work in services and APIs.
 * Any visibility or disabled state here is a UX aid, never a replacement for backend authorization.
 */
import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthorizationService } from '../../services/authorization';

// Renders the already-filtered navigation model; route guards remain the security boundary.
export interface SidebarMenuItem {
  name: string;
  route?: string;
  active?: boolean;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  permissions?: readonly string[];
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent {
  @Input() title = '';
  @Input() menuItems: SidebarMenuItem[] = [];

  /**
   * Reviewer note: Injects the component's framework and service collaborators explicitly so dependencies remain testable.
   * The component coordinates presentation while reusable HTTP contracts stay in frontend services.
   */
  constructor(private readonly authorization: AuthorizationService) {}

  /**
   * Reviewer note: Calculates visible menu items for presentation or navigation only.
   * Hiding a control is not security; the API must still reject unauthorised callers.
   */
  get visibleMenuItems(): SidebarMenuItem[] {
    return this.menuItems.filter(item =>
      !item.permissions?.length ||
      this.authorization.hasAny(...item.permissions));
  }
}
