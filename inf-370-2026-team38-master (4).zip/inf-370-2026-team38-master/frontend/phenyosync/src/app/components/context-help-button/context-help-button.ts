/**
 * Reviewer guide: Provides reusable context help button presentation while keeping domain work in services and APIs.
 * Any visibility or disabled state here is a UX aid, never a replacement for backend authorization.
 */
import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { finalize, take } from 'rxjs';
import { HelpService } from '../../services/help';
import { registeredHelpRoute, registeredHelpSlug } from '../../services/context-help-registry';

// Loads contextual help without coupling feature pages to help-content storage.
@Component({
  selector: 'app-context-help-button',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './context-help-button.html',
  styleUrl: './context-help-button.css'
})
export class ContextHelpButton {
  @Input() componentKey = '';
  // Reviewer note: Tracks pending UI or device work so progress is visible and duplicate gestures can be disabled.
  // The backend still needs idempotency and concurrency protection for repeated requests.
  loading = false;

  /**
   * Reviewer note: Injects the component's framework and service collaborators explicitly so dependencies remain testable.
   * The component coordinates presentation while reusable HTTP contracts stay in frontend services.
   */
  constructor(
    private readonly help: HelpService,
    private readonly router: Router
  ) {}

  /**
   * Reviewer note: Coordinates open so the component presents a consistent current view.
   * Persistent changes still flow through typed services and backend validation when required.
   */
  open(): void {
    if (this.loading) return;
    this.loading = true;
    const route = this.router.url.split('?')[0].split('#')[0] || '/';
    const registeredSlug = registeredHelpSlug(route);
    if (registeredSlug) {
      this.loading = false;
      void this.router.navigate(['/help', registeredSlug]);
      return;
    }
    this.help.context(registeredHelpRoute(route), this.componentKey || undefined).pipe(
      take(1),
      finalize(() => this.loading = false)
    ).subscribe({
      next: result => this.router.navigate(['/help', result.slug]),
      error: () => this.router.navigate(['/help'], {
        queryParams: { query: this.fallbackQuery(route) }
      })
    });
  }

  /**
   * Reviewer note: Encapsulates fallback query so templates and configuration remain declarative and testable.
   * The helper prepares presentation data without replacing backend validation.
   */
  private fallbackQuery(route: string): string {
    return route
      .split('/')
      .filter(Boolean)
      .filter(value => !/^\d+$/.test(value))
      .join(' ')
      .replaceAll('-', ' ');
  }
}
