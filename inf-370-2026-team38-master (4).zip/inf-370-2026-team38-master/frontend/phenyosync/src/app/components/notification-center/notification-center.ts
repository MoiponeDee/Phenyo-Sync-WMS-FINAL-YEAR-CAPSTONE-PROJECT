/**
 * Reviewer guide: Provides reusable notification center presentation while keeping domain work in services and APIs.
 * Any visibility or disabled state here is a UX aid, never a replacement for backend authorization.
 */
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { NotificationService } from '../../services/notification';

@Component({
  selector: 'app-notification-center',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notification-center.html',
  styleUrl: './notification-center.css'
})
export class NotificationCenter {
  /**
   * Reviewer note: Injects the component's framework and service collaborators explicitly so dependencies remain testable.
   * The component coordinates presentation while reusable HTTP contracts stay in frontend services.
   */
  constructor(readonly notifications: NotificationService) {}
}
