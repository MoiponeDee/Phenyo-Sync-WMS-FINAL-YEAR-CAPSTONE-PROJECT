/**
 * Reviewer guide: Applies the auth interceptor client-side access policy before protected UI work begins.
 * This is defence-in-depth for navigation; backend authorization remains the actual security boundary.
 */
import {
  HttpErrorResponse,
  HttpInterceptorFn,
  HttpResponse
} from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, map, throwError } from 'rxjs';
import { AuthorizationService } from '../services/authorization';
import { NotificationService } from '../services/notification';
import { httpErrorMessage } from '../services/http-error-message';

interface ApiEnvelope<T> {
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  success: boolean;
  // Reviewer note: Holds user-facing workflow feedback returned by validation, API, or device operations.
  // It is replaced for each attempt so stale outcomes are not presented as current.
  message: string;
  code: string;
  data: T;
  traceId: string;
}

// Attach the current bearer token and unwrap the standard API envelope for every service call.
// A 401/403 clears stale client state or redirects, but authentication and authorization occur on the API.
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);
  const authorization = inject(AuthorizationService);
  const notifications = inject(NotificationService);

  // Attach the access token centrally so individual services never duplicate auth plumbing.
  const token = localStorage.getItem('token');

  if (token) {
    req = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  return next(req).pipe(
    /**
     * Reviewer note: Handles map consistently for API requests instead of duplicating authentication plumbing in pages.
     * It attaches session context but never grants access; the backend authenticates and authorises the request.
     */
    map(event => {
      // Unwrap the common API envelope while preserving status codes and response headers.
      if (
        event instanceof HttpResponse &&
        isEnvelope(event.body)
      ) {
        return event.clone({ body: event.body.data });
      }
      return event;
    }),
    /**
     * Reviewer note: Handles catch error consistently for API requests instead of duplicating authentication plumbing in pages.
     * It attaches session context but never grants access; the backend authenticates and authorises the request.
     */
    catchError((error: HttpErrorResponse) => {
      const message = httpErrorMessage(error);
      // A 401 invalidates local hints immediately; the API has already made the security decision.
      if (error.status === 401 && !req.url.includes('/auth/login')) {
        localStorage.removeItem('token');
        localStorage.removeItem('role');
        localStorage.removeItem('user');
        authorization.clear();
        notifications.warning('Your session ended. Sign in again.');
        void router.navigate(['/login'], {
          queryParams: { returnUrl: router.url }
        });
      } else if (error.status === 403) {
        notifications.warning(message);
      } else if (error.status === 0 || error.status >= 500) {
        notifications.error(message);
      }
      return throwError(() => error);
    })
  );
};

function isEnvelope(value: unknown): value is ApiEnvelope<unknown> {
  return !!value &&
    typeof value === 'object' &&
    'success' in value &&
    'data' in value &&
    'code' in value;
}
