/**
 * Reviewer guide: Wires the app frontend concern into the Angular application.
 * Business state remains server-authoritative and is exchanged through typed service contracts.
 */
import { AfterViewInit, Component, OnDestroy, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ConfirmationDialog } from './components/confirmation-dialog/confirmation-dialog';
import { NotificationCenter } from './components/notification-center/notification-center';
import { FieldHelpService } from './services/field-help';

// Owns the root web application shell; feature behavior remains in routed pages.
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NotificationCenter, ConfirmationDialog],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements AfterViewInit, OnDestroy {
  protected readonly title = signal('phenyosync');

  /**
   * Reviewer note: Injects the component's framework and service collaborators explicitly so dependencies remain testable.
   * The component coordinates presentation while reusable HTTP contracts stay in frontend services.
   */
  constructor(private readonly fieldHelp: FieldHelpService) {}

  /**
   * Reviewer note: Initialises component state and requests any authoritative data needed by the rendered view.
   * Loading and error state remain explicit so asynchronous work cannot silently fail.
   */
  ngAfterViewInit(): void {
    this.fieldHelp.start();
  }

  /**
   * Reviewer note: Releases subscriptions, timers or map/device resources when the component is destroyed.
   * Cleanup prevents duplicate callbacks and memory leaks after navigation.
   */
  ngOnDestroy(): void {
    this.fieldHelp.stop();
  }
}
