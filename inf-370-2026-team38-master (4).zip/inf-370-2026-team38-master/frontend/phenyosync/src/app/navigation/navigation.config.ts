/**
 * Reviewer guide: Defines navigation config routing and visibility from authenticated role/permission state.
 * Hidden links and route guards improve UX, but the API independently rejects unauthorised calls.
 */
export interface NavigationItem {
  readonly label: string;
  readonly route: string;
  readonly icon: string;
  // Reviewer note: Controls presentation visibility or navigation for the current session.
  // This is not security; the backend permission check remains authoritative.
  readonly permissions?: readonly string[];
  readonly exact?: boolean;
}

export interface NavigationSection {
  readonly key?: string;
  readonly label: string;
  readonly route?: string;
  readonly summary?: string;
  // Reviewer note: Stores a DTO or configuration projection used by consumers; it is not persisted business state.
  // Authoritative values still come from authenticated API responses.
  readonly items: readonly NavigationItem[];
}

// Navigation is filtered for usability from backend-derived permission codes. Hiding an
// item is not authorization; direct route and endpoint access are independently guarded.
export const WMS_NAVIGATION: readonly NavigationSection[] = [
  {
    label: 'Overview',
    items: [
      {
        label: 'Dashboard',
        route: '/dashboard',
        icon: '▦',
        permissions: ['Dashboards.View'],
        exact: true
      }
    ]
  },
  {
    key: 'warehouse-operations',
    label: 'Warehouse Operations',
    route: '/workspace/warehouse-operations',
    summary: 'Control stock, expiry, hierarchy and warehouse data exchange.',
    items: [
  { label: 'Product Overview', route: '/search-product', icon: '▣', permissions: ['Products.View', 'Stock.View'] },

  { label: 'Raw Stock', route: '/raw-stock', icon: '◇', permissions: ['RawStock.View'] },

  { label: 'Make Product', route: '/make-product', icon: '+', permissions: ['Products.Make'] },

  { label: 'Expiry Alerts', route: '/expiry-alerts', icon: '!', permissions: ['Expiry.View'] },

  { label: 'Product Hierarchy', route: '/product-hierarchy', icon: '⌘', permissions: ['ProductHierarchy.View'] },

  { label: 'Add Product', route: '/add-product', icon: '+', permissions: ['ProductHierarchy.Manage'] },

  { label: 'Product Data Exchange', route: '/product-data-exchange', icon: '⇄', permissions: ['ProductDataExchange.Export', 'ProductDataExchange.Import'] },

  { label: 'Stock Count Exchange', route: '/stock-count-data-exchange', icon: '≋', permissions: ['StockCountExchange.Export', 'StockCountExchange.Import'] },

  { label: 'Scan Product Batch', route: '/scan-product-batch', icon: '⌗', permissions: ['ProductBatchScanner.View'] }
]
  },
  {
    key: 'orders-procurement',
    label: 'Orders & Procurement',
    route: '/workspace/orders-procurement',
    summary: 'Coordinate customer demand, procurement, packing and delivery.',
    items: [
      { label: 'Customer Orders', route: '/order-management', icon: '▤', permissions: ['Orders.View'] },
      { label: 'Buying Lists', route: '/buying-lists', icon: '✓', permissions: ['BuyingList.View'] },
      { label: 'Suppliers & Orders', route: '/suppliers', icon: '⌂', permissions: ['Suppliers.View'] },
      { label: 'Packing Queue', route: '/view-pick-list', icon: '□', permissions: ['Packing.View'] },
      { label: 'Deliveries', route: '/deliveries', icon: '➜', permissions: ['Deliveries.View', 'Deliveries.AssignDriver'] },
      { label: 'My Deliveries', route: '/my-deliveries', icon: '⌖', permissions: ['Deliveries.ViewOwn'] }
    ]
  },
  {
    key: 'customers-pricing',
    label: 'Customers & Pricing',
    route: '/workspace/customers-pricing',
    summary: 'Maintain customer records and controlled selling prices.',
    items: [
      { label: 'Customers', route: '/customers', icon: '◎', permissions: ['Customers.View'] },
      { label: 'Pricing', route: '/pricing', icon: 'R', permissions: ['Pricing.View'] }
    ]
  },
  {
    key: 'payments-oversight',
    label: 'Payments & Oversight',
    route: '/workspace/payments-oversight',
    summary: 'Review payments, live operations, calendar events and audit evidence.',
    items: [
      { label: 'Payments', route: '/payments', icon: '$', permissions: ['CustomerPayments.View', 'SupplierPayments.View', 'Payments.View'] },
      { label: 'Operations Calendar', route: '/operations-calendar', icon: '▦', permissions: ['OperationsCalendar.View'] },
      { label: 'Track Driver', route: '/mobile-operations-control', icon: '◉', permissions: ['Mobile.Tracking.ViewAll'] },
      { label: 'Audit Logs', route: '/audit-logs', icon: '≡', permissions: ['AuditLogs.View'] }
    ]
  },
  {
    key: 'reports-analytics',
    label: 'Reports & Analytics',
    route: '/reports',
    summary: 'Generate formal operational, transactional, financial and management reports.',
    items: [
      { label: 'Reports Overview', route: '/reports', icon: 'R', permissions: ['Reports.View'], exact: true },
      { label: 'Inventory Position', route: '/reports/inventory', icon: 'I', permissions: ['Reports.Inventory.View'] },
      { label: 'Sales Analysis', route: '/reports/sales', icon: 'S', permissions: ['Reports.Sales.View'] },
      { label: 'Financial Activity', route: '/reports/financial', icon: 'F', permissions: ['Reports.Financial.View'] },
      { label: 'Stock Movement', route: '/reports/stock-movement', icon: 'M', permissions: ['Reports.StockMovement.View'] },
      { label: 'Expiry & Waste', route: '/reports/expiry-waste', icon: 'E', permissions: ['Reports.ExpiryWaste.View'] },
      { label: 'Pricing Analysis', route: '/reports/pricing', icon: 'P', permissions: ['Reports.Pricing.View'] },
      { label: 'Markup & Margin', route: '/reports/markup', icon: '%', permissions: ['Reports.Markup.View'] }
    ]
  },
  {
    key: 'administration',
    label: 'Administration',
    route: '/workspace/administration',
    summary: 'Manage controlled configuration, access and support content.',
    items: [
      { label: 'Users', route: '/manage-users', icon: '♙', permissions: ['Users.View'] },
      { label: 'Roles', route: '/manage-roles', icon: '♜', permissions: ['Roles.View'] },
      { label: 'Permissions', route: '/manage-permissions', icon: '⌁', permissions: ['Permissions.View'] },
      { label: 'Product Types', route: '/manage-product-types', icon: '◫', permissions: ['ProductTypes.Manage'] },
      { label: 'Product Categories', route: '/manage-product-categories', icon: '▱', permissions: ['ProductCategories.Manage'] },
      { label: 'Operational Lookups', route: '/manage-lookups', icon: '⋮', permissions: ['Lookups.View'] },
      { label: 'Warehouse Sections', route: '/manage-warehouse-sections', icon: '▥', permissions: ['WarehouseSections.Manage'] },
      { label: 'System Settings', route: '/manage-system-settings', icon: '⚙', permissions: ['SystemSettings.View'] },
      { label: 'Help Content', route: '/manage-help', icon: '?', permissions: ['Help.Manage'] },
      { label: 'Training Media', route: '/manage-help-media', icon: '▶', permissions: ['HelpMedia.Manage'] }
    ]
  },
  {
    key: 'support',
    label: 'Support',
    route: '/workspace/support',
    summary: 'Find contextual guidance, training and account security tools.',
    items: [
      { label: 'Help Centre', route: '/help', icon: '?', permissions: ['Help.View'] },
      { label: 'Account Security', route: '/account-security', icon: '●' }
    ]
  }
];
