/**
 * Reviewer guide: Verifies the navigation config frontend contract and its regression-sensitive behaviour.
 * Each test documents an observable rule rather than coupling reviewers to implementation details.
 */
import { WMS_NAVIGATION } from './navigation.config';

// Locks the final role/navigation matrix, including Buying Lists, Raw Stock and Track Driver labels.
describe('WMS navigation configuration', () => {
  const items = WMS_NAVIGATION.flatMap(section => section.items);

  // Reviewer note: Guards the observable rule that contains one canonical dashboard link.
  it('contains one canonical dashboard link', () => {
    expect(items.filter(item => item.route === '/dashboard').length).toBe(1);
  });

  // Reviewer note: Guards the observable rule that uses the revised business names in visible navigation.
  it('uses the revised business names in visible navigation', () => {
    const labels = WMS_NAVIGATION
      .flatMap(section => [section.label, ...section.items.map(item => item.label)])
      .join(' ');

    expect(labels).not.toContain('Stock Taker');
    expect(labels).not.toContain('CEO');
    expect(labels).not.toContain('COO');
    expect(labels).toContain('Product Overview');
    expect(labels).not.toContain('Stock Overview');
  });

  // Reviewer note: Guards the observable rule that does not expose management destinations through read-only permissions.
  it('does not expose management destinations through read-only permissions', () => {
    const productTypes = items.find(item => item.route === '/manage-product-types');
    const productCategories = items.find(item => item.route === '/manage-product-categories');
    const warehouseSections = items.find(item => item.route === '/manage-warehouse-sections');
    const buyingLists = items.find(item => item.route === '/buying-lists');
    const addProduct = items.find(item => item.route === '/add-product');

    expect(productTypes?.permissions).toEqual(['ProductTypes.Manage']);
    expect(productCategories?.permissions).toEqual(['ProductCategories.Manage']);
    expect(warehouseSections?.permissions).toEqual(['WarehouseSections.Manage']);
    expect(buyingLists?.permissions).toEqual(['BuyingList.View']);
    expect(addProduct?.permissions).toEqual(['ProductHierarchy.Manage']);
  });

  // Reviewer note: Guards the observable rule that protects every operational navigation item with a permission.
  it('protects every operational navigation item with a permission', () => {
    const operational = WMS_NAVIGATION
      .filter(section => section.label !== 'Support')
      .flatMap(section => section.items);

    expect(operational.every(item => !!item.permissions?.length)).toBe(true);
  });

  // Reviewer note: Guards the observable rule that gives each business section a unique landing route.
  it('gives each business section a unique landing route', () => {
    const landingRoutes = WMS_NAVIGATION
      .map(section => section.route)
      .filter((route): route is string => !!route);

    expect(new Set(landingRoutes).size).toBe(landingRoutes.length);
    expect(landingRoutes.length).toBeGreaterThanOrEqual(5);
  });
});
