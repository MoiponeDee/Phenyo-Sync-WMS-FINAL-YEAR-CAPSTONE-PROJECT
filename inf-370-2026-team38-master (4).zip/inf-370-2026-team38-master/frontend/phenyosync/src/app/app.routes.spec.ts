import { routes } from './app.routes';

describe('raw-stock route authorization', () => {
  const applicationRoutes = routes.find(route => route.path === '' && route.children)
    ?.children ?? [];

  it('keeps the broad Raw Stock route behind RawStock.View', () => {
    const route = applicationRoutes.find(candidate => candidate.path === 'raw-stock');

    expect(route?.data).toEqual({ permission: 'RawStock.View' });
  });

  it('exposes approvals through a separate narrow route', () => {
    const route = applicationRoutes.find(
      candidate => candidate.path === 'raw-stock/approvals');

    expect(route?.data).toEqual({
      permissions: ['RawStockTakes.View', 'RawStock.ApproveWriteOff']
    });
  });
});
