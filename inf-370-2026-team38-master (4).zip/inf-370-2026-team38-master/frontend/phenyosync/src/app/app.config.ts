/**
 * Reviewer guide: Wires the app config frontend concern into the Angular application.
 * Business state remains server-authoritative and is exchanged through typed service contracts.
 */
import { ApplicationConfig, LOCALE_ID } from '@angular/core';

import { provideRouter, withInMemoryScrolling } from '@angular/router';

import {
  provideHttpClient,
  withInterceptors
} from '@angular/common/http';

import { routes } from './app.routes';

import { authInterceptor } from './interceptors/auth.interceptor';

// Composes application-wide providers, including routing and authenticated HTTP.
export const appConfig: ApplicationConfig = {

  providers: [

    /**
     * Reviewer note: Encapsulates provide router so templates and configuration remain declarative and testable.
     * The helper prepares presentation data without replacing backend validation.
     */
    provideRouter(
      routes,
      withInMemoryScrolling({
        scrollPositionRestoration: 'top',
        anchorScrolling: 'enabled'
      })
    ),

    /**
     * Reviewer note: Encapsulates provide http client so templates and configuration remain declarative and testable.
     * The helper prepares presentation data without replacing backend validation.
     */
    provideHttpClient(
      withInterceptors([authInterceptor])
    ),

    { provide: LOCALE_ID, useValue: 'en-ZA' }

  ]
};
