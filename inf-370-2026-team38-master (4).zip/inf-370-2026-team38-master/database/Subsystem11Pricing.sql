/*
    INF370 Subsystem 11 - Pricing Management
    Idempotent, additive deployment script for the existing WMS_DB database.
    It preserves Product.SellingPricePerKg as a compatibility projection and
    migrates valid legacy values into append-only ProductPrices records.
*/

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

IF OBJECT_ID(N'dbo.ProductPrices', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ProductPrices
    (
        ProductPriceId INT IDENTITY(1, 1) NOT NULL
            CONSTRAINT PK_ProductPrices PRIMARY KEY,
        ProductId INT NOT NULL,
        SellingPrice DECIMAL(18, 2) NOT NULL,
        EffectiveFromUtc DATETIME2 NOT NULL,
        EffectiveToUtc DATETIME2 NULL,
        IsCurrent BIT NOT NULL
            CONSTRAINT DF_ProductPrices_IsCurrent DEFAULT (0),
        IsDeleted BIT NOT NULL
            CONSTRAINT DF_ProductPrices_IsDeleted DEFAULT (0),
        CreatedAtUtc DATETIME2 NOT NULL
            CONSTRAINT DF_ProductPrices_CreatedAtUtc DEFAULT (SYSUTCDATETIME()),
        CreatedByUserId INT NULL,
        ChangeReason NVARCHAR(500) NULL,
        DeletedAtUtc DATETIME2 NULL,
        DeletedByUserId INT NULL,
        DeleteReason NVARCHAR(500) NULL,
        RowVersion ROWVERSION NOT NULL,
        CONSTRAINT CK_ProductPrices_Positive
            CHECK (SellingPrice > 0),
        CONSTRAINT FK_ProductPrices_Product_ProductId
            FOREIGN KEY (ProductId) REFERENCES dbo.Product(ProductId),
        CONSTRAINT FK_ProductPrices_Users_CreatedByUserId
            FOREIGN KEY (CreatedByUserId) REFERENCES dbo.Users(UserId),
        CONSTRAINT FK_ProductPrices_Users_DeletedByUserId
            FOREIGN KEY (DeletedByUserId) REFERENCES dbo.Users(UserId)
    );
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE parent_object_id = OBJECT_ID(N'dbo.ProductPrices')
      AND name = N'CK_ProductPrices_Positive'
)
BEGIN
    ALTER TABLE dbo.ProductPrices WITH CHECK
        ADD CONSTRAINT CK_ProductPrices_Positive
        CHECK (SellingPrice > 0);
END;

IF COL_LENGTH(N'dbo.SalesOrderItems', N'ProductPriceId') IS NULL
BEGIN
    ALTER TABLE dbo.SalesOrderItems
        ADD ProductPriceId INT NULL;
END;

INSERT INTO dbo.ProductPrices
(
    ProductId,
    SellingPrice,
    EffectiveFromUtc,
    IsCurrent,
    IsDeleted,
    CreatedAtUtc,
    ChangeReason
)
SELECT
    product.ProductId,
    product.SellingPricePerKg,
    COALESCE(product.UpdatedAt, product.CreatedAt, SYSUTCDATETIME()),
    1,
    0,
    SYSUTCDATETIME(),
    N'Migrated from the legacy Product selling price.'
FROM dbo.Product AS product
WHERE product.SellingPricePerKg > 0
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.ProductPrices AS price
      WHERE price.ProductId = product.ProductId
        AND price.IsCurrent = 1
        AND price.IsDeleted = 0
  );

UPDATE orderItem
SET ProductPriceId = price.ProductPriceId
FROM dbo.SalesOrderItems AS orderItem
INNER JOIN dbo.ProductPrices AS price
    ON price.ProductId = orderItem.ProductId
   AND price.IsCurrent = 1
   AND price.IsDeleted = 0
WHERE orderItem.ProductPriceId IS NULL;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.ProductPrices')
      AND name = N'UX_ProductPrices_Current'
)
BEGIN
    CREATE UNIQUE INDEX UX_ProductPrices_Current
        ON dbo.ProductPrices(ProductId, IsCurrent, IsDeleted)
        WHERE IsCurrent = 1 AND IsDeleted = 0;
END;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.ProductPrices')
      AND name = N'IX_ProductPrices_ProductId'
)
    CREATE INDEX IX_ProductPrices_ProductId
        ON dbo.ProductPrices(ProductId);

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.ProductPrices')
      AND name = N'IX_ProductPrices_EffectiveFromUtc'
)
    CREATE INDEX IX_ProductPrices_EffectiveFromUtc
        ON dbo.ProductPrices(EffectiveFromUtc);

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.ProductPrices')
      AND name = N'IX_ProductPrices_EffectiveToUtc'
)
    CREATE INDEX IX_ProductPrices_EffectiveToUtc
        ON dbo.ProductPrices(EffectiveToUtc);

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.ProductPrices')
      AND name = N'IX_ProductPrices_SellingPrice'
)
    CREATE INDEX IX_ProductPrices_SellingPrice
        ON dbo.ProductPrices(SellingPrice);

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.SalesOrderItems')
      AND name = N'IX_SalesOrderItems_ProductPriceId'
)
    CREATE INDEX IX_SalesOrderItems_ProductPriceId
        ON dbo.SalesOrderItems(ProductPriceId);

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_SalesOrderItems_ProductPrices_ProductPriceId'
)
BEGIN
    ALTER TABLE dbo.SalesOrderItems WITH CHECK
        ADD CONSTRAINT FK_SalesOrderItems_ProductPrices_ProductPriceId
        FOREIGN KEY (ProductPriceId)
        REFERENCES dbo.ProductPrices(ProductPriceId);
END;

COMMIT TRANSACTION;

SELECT
    ProductId,
    ProductName,
    SellingPricePerKg
FROM dbo.Product
WHERE SellingPricePerKg <= 0
ORDER BY ProductName, ProductId;
