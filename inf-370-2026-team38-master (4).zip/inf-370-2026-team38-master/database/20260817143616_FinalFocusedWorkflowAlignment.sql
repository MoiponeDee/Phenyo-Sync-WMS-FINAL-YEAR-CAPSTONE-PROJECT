﻿BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260817143616_FinalFocusedWorkflowAlignment'
)
BEGIN
    DECLARE @var0 sysname;
    SELECT @var0 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[RawStockReceipts]') AND [c].[name] = N'SupplierId');
    IF @var0 IS NOT NULL EXEC(N'ALTER TABLE [RawStockReceipts] DROP CONSTRAINT [' + @var0 + '];');
    ALTER TABLE [RawStockReceipts] ALTER COLUMN [SupplierId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260817143616_FinalFocusedWorkflowAlignment'
)
BEGIN
    DELETE mapping
    FROM dbo.RolePermissions mapping
    JOIN dbo.Roles role ON role.RoleId = mapping.RoleId
    JOIN dbo.Permissions permission
      ON permission.PermissionId = mapping.PermissionId
    WHERE
        (role.RoleCode = 'Admin' AND permission.PermissionCode IN
            ('RawStock.View', 'Products.Make',
             'WarehouseSections.Manage'))
        OR
        (role.RoleCode = 'OperationsManager' AND
         permission.PermissionCode IN
            ('RawStock.View', 'Products.Make',
             'ProductTypes.Manage', 'ProductCategories.Manage',
             'WarehouseSections.Manage',
             'Orders.Validate', 'Orders.Confirm',
             'Users.View', 'Roles.View',
             'PermissionDefinitions.View'))
        OR
        (role.RoleCode = 'WarehouseManager' AND
         permission.PermissionCode IN
            ('Users.View', 'Roles.View',
             'PermissionDefinitions.View',
             'ProductTypes.Manage',
             'ProductCategories.Manage',
             'Orders.Validate', 'Orders.Confirm'));
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON
        (role.RoleCode = 'Admin' AND
         permission.PermissionCode IN
            ('Orders.Validate', 'Orders.Confirm'))
        OR
        (role.RoleCode = 'WarehouseManager' AND
         permission.PermissionCode IN
            ('Products.Make', 'BuyingList.View',
             'BuyingList.ViewAll', 'Orders.ChangeStatus'))
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.RolePermissions existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId = permission.PermissionId
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260817143616_FinalFocusedWorkflowAlignment'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''WarehouseManager'', [BodyContent] = CONCAT(CAST(N''# Make products'' AS nvarchar(max)), nchar(10), N''Select a warehouse section, then select an existing active Product whose Raw Stock requirements are configured and currently available. The readiness card shows adjusted input quantities and maximum packable output.'', nchar(10), nchar(10), N''Enter only the warehouse section, Product and quantity to make. PhenyoSync automatically consumes eligible Raw Stock in earliest-expiry-first order, records the conversion and increases finished Product stock. The transaction rolls back when any input is insufficient or changes concurrently. Product master creation and order barcode packing remain separate workflows.''), [Keywords] = N''make product raw stock conversion recipe availability''
    WHERE [HelpTopicId] = 8;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260817143616_FinalFocusedWorkflowAlignment'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Customer order form'' AS nvarchar(max)), nchar(10), N''Open the configured Google Form from Order Management and share it with the customer. When responses are ready, an authorised user selects Synchronise responses. PhenyoSync reads the configured Google Sheet through the backend and never exposes the provider key to the browser.'', nchar(10), nchar(10), N''The live form uses customer identity, account reference, phone, fulfilment choice, address, requested date, purchase-order reference, six Product/quantity pairs, additional items and customer notes. Products match an exact Product code first and then one unambiguous description. Customers match email first, account reference second and a unique phone number only as a safe fallback. Collection requests do not require a delivery address. Additional free-text products and any ambiguity remain in Needs Attention instead of silently creating records or changing master data.'', nchar(10), nchar(10), N''Synchronisation is a Super Admin commercial-intake task. Each response has a stable external key, so repeated syncs cannot create duplicate orders. Authoritative prices come from PhenyoSync and accepted requests enter Submitted for commercial approval.'')
    WHERE [HelpTopicId] = 18;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260817143616_FinalFocusedWorkflowAlignment'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Create and validate orders'' AS nvarchar(max)), nchar(10), N''Select a customer and add products with positive quantities. Prices are read from the current server-side price record and snapshotted onto order lines.'', nchar(10), nchar(10), N''A Super Admin reviews the request and selects Validate and Approve Order or Reject Order with a reason. Approval activates demand without rejecting a valid request merely because stock is short. After approved demand is fulfilled, a Packer scans finished Product Batches and completes packing. The Warehouse Manager then reviews the completed packing and confirms Ready for Dispatch.'')
    WHERE [HelpTopicId] = 19;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260817143616_FinalFocusedWorkflowAlignment'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Order status and cancellation'' AS nvarchar(max)), nchar(10), N''Orders move from Submitted to commercially Approved, Packing, Packing Complete, Ready for Dispatch, Out for Delivery and Delivered. Commercial approval belongs to Super Admin. Packing belongs to the Packer, and the Warehouse Manager confirms dispatch readiness only after packing is complete.'', nchar(10), nchar(10), N''Cancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.'')
    WHERE [HelpTopicId] = 20;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260817143616_FinalFocusedWorkflowAlignment'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Product and price Excel exchange'' AS nvarchar(max)), nchar(10), N''Use the filters to create a presentation-ready Excel workbook showing Product master data and the price effective at the selected business date. Excel includes instructions, metadata, filters and typed columns.'', nchar(10), nchar(10), N''Import is a controlled Excel workflow: upload the current template, review valid, warning and invalid rows, enter a business reason, confirm, and apply the exact staged content. Existing prices are versioned instead of overwritten. JSON is reserved for Stock Taker inventory snapshots and never contains prices or costs.''), [Keywords] = N''excel product price catalogue template validate import export stock count json'', [Summary] = N''Export professional pricing workbooks and apply only validated Excel imports.'', [Title] = N''Product and price Excel exchange''
    WHERE [HelpTopicId] = 36;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260817143616_FinalFocusedWorkflowAlignment'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Procurement shortages'' AS nvarchar(max)), nchar(10), N''Shortage planning starts with commercially approved and active fulfilment demand. Submitted customer or Google Form requests are excluded until Super Admin approval. Active finished-stock reservations are subtracted before the Product shortage is calculated.'', nchar(10), nchar(10), N''The Warehouse Manager maintains Product-to-Raw-Stock mappings using friendly dropdowns, quantity, unit, waste and yield. Unmapped approved demand is shown separately and cannot generate misleading purchase quantities. Mapped shortages include available Raw Stock, outstanding supplier orders and open Buying List quantities.'', nchar(10), nchar(10), N''Receive Raw Stock only from a controlled Supplier Order line or a submitted Buying List line. Supplier and unit are derived from the selected source. A Buying List may use Market Purchase / Not applicable when no supplier applies. Record the received quantity, actual cost, docket and any variance notes; the source document remains the traceability record.'')
    WHERE [HelpTopicId] = 37;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260817143616_FinalFocusedWorkflowAlignment'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260817143616_FinalFocusedWorkflowAlignment', N'8.0.0');
END;
GO

COMMIT;
GO

