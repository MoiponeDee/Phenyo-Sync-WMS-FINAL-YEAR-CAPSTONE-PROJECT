BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [StockTakeSessions] ADD [CorrelationId] nvarchar(64) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [StockMovements] ADD [StockTakeSessionId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [ProductType] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [ProductCategory] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [Product] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    UPDATE dbo.StockTakeSessions
    SET CorrelationId = CONCAT('legacy-stocktake-', SessionId)
    WHERE CorrelationId IS NULL
       OR LTRIM(RTRIM(CorrelationId)) = '';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE TABLE [DataExchangeJobs] (
        [DataExchangeJobId] bigint NOT NULL IDENTITY,
        [ValidationTokenHash] nvarchar(64) NOT NULL,
        [ExchangeType] nvarchar(40) NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [OriginalFileName] nvarchar(255) NOT NULL,
        [ContentSha256] nvarchar(64) NOT NULL,
        [StagedPayloadJson] nvarchar(max) NOT NULL,
        [ResultPayloadJson] nvarchar(max) NULL,
        [TotalRows] int NOT NULL,
        [ValidRows] int NOT NULL,
        [WarningRows] int NOT NULL,
        [InvalidRows] int NOT NULL,
        [CreatedByUserId] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        [AppliedAtUtc] datetime2 NULL,
        [ApplyReason] nvarchar(500) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_DataExchangeJobs] PRIMARY KEY ([DataExchangeJobId]),
        CONSTRAINT [FK_DataExchangeJobs_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE TABLE [ProductCategoryTypes] (
        [ProductCategoryTypeId] int NOT NULL IDENTITY,
        [ProductCategoryId] int NOT NULL,
        [ProductTypeId] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [CreatedByUserId] int NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_ProductCategoryTypes] PRIMARY KEY ([ProductCategoryTypeId]),
        CONSTRAINT [FK_ProductCategoryTypes_ProductCategory_ProductCategoryId] FOREIGN KEY ([ProductCategoryId]) REFERENCES [ProductCategory] ([ProductCategoryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductCategoryTypes_ProductType_ProductTypeId] FOREIGN KEY ([ProductTypeId]) REFERENCES [ProductType] ([ProductTypeId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductCategoryTypes_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    INSERT INTO dbo.ProductCategoryTypes
        (ProductCategoryId, ProductTypeId, CreatedAtUtc, CreatedByUserId)
    SELECT
        product.ProductCategoryId,
        product.ProductTypeId,
        MIN(product.CreatedAt),
        NULL
    FROM dbo.Product product
    WHERE product.ProductCategoryId IS NOT NULL
      AND product.ProductTypeId IS NOT NULL
    GROUP BY
        product.ProductCategoryId,
        product.ProductTypeId;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (19, NULL, N''Files'', N''10'', N''Maximum accepted Product and Price Excel workbook size.'', N''Excel import maximum size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Files.ExcelImportMaximumMb'', N''50'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (20, NULL, N''Files'', N''5'', N''Maximum accepted Stock Count JSON package size.'', N''JSON import maximum size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Files.JsonImportMaximumMb'', N''25'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''Integer''),
    (21, NULL, N''Data exchange'', N''2000'', N''Maximum number of rows accepted in one validated import.'', N''Maximum import rows'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''DataExchange.MaximumRows'', N''10000'', N''1'', CAST(0 AS bit), N''rows'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''2000'', N''Integer''),
    (22, NULL, N''Data exchange'', N''30'', N''Minutes a validated import remains available for confirmation.'', N''Validation lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''DataExchange.ValidationLifetimeMinutes'', N''120'', N''5'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''30'', N''TimeSpanMinutes''),
    (23, NULL, N''QR scanning'', N''3'', N''Seconds during which a repeated camera scan is ignored.'', N''Duplicate scan delay'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Qr.DuplicateDelaySeconds'', N''30'', N''1'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''3'', N''Integer''),
    (24, N''["month","week","day","agenda"]'', N''Calendar'', N''month'', N''Initial view used by the Operations Calendar.'', N''Default calendar view'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Calendar.DefaultView'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''month'', N''String''),
    (25, NULL, N''Calendar'', N''93'', N''Maximum number of days returned by one Operations Calendar query.'', N''Maximum date range'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Calendar.MaximumDateRangeDays'', N''366'', N''7'', CAST(0 AS bit), N''days'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''93'', N''Integer'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    DECLARE @PhaseBPermissionSeed TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(120) NOT NULL,
        Module nvarchar(80) NOT NULL
    );
    INSERT INTO @PhaseBPermissionSeed VALUES
        ('ProductHierarchy.View', 'View the product hierarchy', 'Product'),
        ('ProductHierarchy.Manage', 'Manage the product hierarchy', 'Product'),
        ('ProductDataExchange.Export', 'Export Product and Price workbooks', 'DataExchange'),
        ('ProductDataExchange.Import', 'Validate and import Product and Price workbooks', 'DataExchange'),
        ('StockCountExchange.Export', 'Export Stock Count JSON packages', 'DataExchange'),
        ('StockCountExchange.Import', 'Validate and import Stock Count JSON packages', 'DataExchange'),
        ('OperationsCalendar.View', 'View the Operations Calendar', 'Operations'),
        ('ProductBatchScanner.View', 'Resolve Product Batch QR codes', 'Product');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT
        seed.PermissionCode,
        seed.PermissionCode,
        seed.DisplayName,
        seed.Module,
        1,
        1,
        SYSUTCDATETIME()
    FROM @PhaseBPermissionSeed seed
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode
    );
    UPDATE permission
    SET
        permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @PhaseBPermissionSeed seed
      ON seed.PermissionCode = permission.PermissionCode;
    DECLARE @PhaseBRoleAssignments TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL
    );
    INSERT INTO @PhaseBRoleAssignments VALUES
        ('Admin', 'ProductHierarchy.View'),
        ('Admin', 'ProductHierarchy.Manage'),
        ('Admin', 'ProductDataExchange.Export'),
        ('Admin', 'ProductDataExchange.Import'),
        ('Admin', 'OperationsCalendar.View'),
        ('Admin', 'ProductBatchScanner.View'),
        ('Packer', 'ProductHierarchy.View'),
        ('Packer', 'OperationsCalendar.View'),
        ('Packer', 'ProductBatchScanner.View'),
        ('WarehouseManager', 'ProductHierarchy.View'),
        ('WarehouseManager', 'StockCountExchange.Export'),
        ('WarehouseManager', 'StockCountExchange.Import'),
        ('WarehouseManager', 'OperationsCalendar.View'),
        ('WarehouseManager', 'ProductBatchScanner.View'),
        ('Driver', 'OperationsCalendar.View');
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT
        role.RoleId,
        permission.PermissionId,
        SYSUTCDATETIME()
    FROM dbo.Roles role
    CROSS JOIN dbo.Permissions permission
    WHERE role.RoleCode IN ('CEO', 'COO', 'BusinessManager')
      AND permission.PermissionCode IN
      (
          'ProductHierarchy.View',
          'ProductHierarchy.Manage',
          'ProductDataExchange.Export',
          'ProductDataExchange.Import',
          'StockCountExchange.Export',
          'StockCountExchange.Import',
          'OperationsCalendar.View',
          'ProductBatchScanner.View'
      )
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.RolePermissions existing
          WHERE existing.RoleId = role.RoleId
            AND existing.PermissionId = permission.PermissionId
      );
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT
        role.RoleId,
        permission.PermissionId,
        SYSUTCDATETIME()
    FROM @PhaseBRoleAssignments assignment
    JOIN dbo.Roles role
      ON role.RoleCode = assignment.RoleCode
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = assignment.PermissionCode
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.RolePermissions existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId = permission.PermissionId
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE UNIQUE INDEX [UX_StockTakeSessions_CorrelationId] ON [StockTakeSessions] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE INDEX [IX_StockMovements_StockTakeSessionId] ON [StockMovements] ([StockTakeSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE INDEX [IX_DataExchangeJobs_CreatedByUserId_ExchangeType_Status_ExpiresAtUtc] ON [DataExchangeJobs] ([CreatedByUserId], [ExchangeType], [Status], [ExpiresAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE UNIQUE INDEX [UX_DataExchangeJobs_ValidationTokenHash] ON [DataExchangeJobs] ([ValidationTokenHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE INDEX [IX_ProductCategoryTypes_CreatedByUserId] ON [ProductCategoryTypes] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE INDEX [IX_ProductCategoryTypes_ProductTypeId] ON [ProductCategoryTypes] ([ProductTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE UNIQUE INDEX [UX_ProductCategoryTypes_Category_Type] ON [ProductCategoryTypes] ([ProductCategoryId], [ProductTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [StockMovements] ADD CONSTRAINT [FK_StockMovements_StockTakeSessions_StockTakeSessionId] FOREIGN KEY ([StockTakeSessionId]) REFERENCES [StockTakeSessions] ([SessionId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr', N'8.0.0');
END;
GO

COMMIT;
GO

