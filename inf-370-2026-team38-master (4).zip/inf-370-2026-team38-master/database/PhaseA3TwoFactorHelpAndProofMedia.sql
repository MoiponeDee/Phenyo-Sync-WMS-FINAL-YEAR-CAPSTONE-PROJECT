BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (
        SELECT NormalizedEmail
        FROM dbo.Users
        GROUP BY NormalizedEmail
        HAVING COUNT(*) > 1)
        THROW 51003,
            'Duplicate user email addresses must be resolved before Phase A3 can be applied.',
            1;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [HelpCategories] (
        [HelpCategoryId] int NOT NULL IDENTITY,
        [SystemCode] nvarchar(80) NOT NULL,
        [DisplayName] nvarchar(120) NOT NULL,
        [Description] nvarchar(500) NULL,
        [SortOrder] int NOT NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_HelpCategories] PRIMARY KEY ([HelpCategoryId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [StoredFiles] (
        [StoredFileId] bigint NOT NULL IDENTITY,
        [StorageProvider] nvarchar(40) NOT NULL,
        [StorageKey] nvarchar(300) NOT NULL,
        [OriginalFileName] nvarchar(255) NOT NULL,
        [SafeDownloadName] nvarchar(255) NOT NULL,
        [ContentType] nvarchar(120) NOT NULL,
        [Extension] nvarchar(16) NOT NULL,
        [SizeBytes] bigint NOT NULL,
        [Sha256Hash] nvarchar(64) NOT NULL,
        [UploadedAtUtc] datetime2 NOT NULL,
        [UploadedByUserId] int NOT NULL,
        [IsDeleted] bit NOT NULL,
        [DeletedAtUtc] datetime2 NULL,
        [DeletedByUserId] int NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_StoredFiles] PRIMARY KEY ([StoredFileId]),
        CONSTRAINT [FK_StoredFiles_Users_DeletedByUserId] FOREIGN KEY ([DeletedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StoredFiles_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [TrustedDevices] (
        [TrustedDeviceId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [TokenHash] nvarchar(64) NOT NULL,
        [DeviceName] nvarchar(120) NOT NULL,
        [UserAgentSummary] nvarchar(256) NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [LastUsedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        [RevokedAtUtc] datetime2 NULL,
        [RevokedByUserId] int NULL,
        [RevocationReason] nvarchar(300) NULL,
        [SecurityVersionSnapshot] int NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_TrustedDevices] PRIMARY KEY ([TrustedDeviceId]),
        CONSTRAINT [FK_TrustedDevices_Users_RevokedByUserId] FOREIGN KEY ([RevokedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_TrustedDevices_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [UserOtpChallenges] (
        [UserOtpChallengeId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [ChallengeTokenHash] nvarchar(64) NOT NULL,
        [OtpHash] nvarchar(256) NOT NULL,
        [Purpose] nvarchar(40) NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        [LastSentAtUtc] datetime2 NOT NULL,
        [AttemptCount] int NOT NULL,
        [MaximumAttempts] int NOT NULL,
        [ResendCount] int NOT NULL,
        [ConsumedAtUtc] datetime2 NULL,
        [RevokedAtUtc] datetime2 NULL,
        [FailureReason] nvarchar(160) NULL,
        [IpAddressSummary] nvarchar(64) NULL,
        [UserAgentSummary] nvarchar(256) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [SecurityVersionSnapshot] int NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_UserOtpChallenges] PRIMARY KEY ([UserOtpChallengeId]),
        CONSTRAINT [FK_UserOtpChallenges_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [UserRecoveryCodes] (
        [UserRecoveryCodeId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [CodeHash] nvarchar(256) NOT NULL,
        [CodeOrder] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UsedAtUtc] datetime2 NULL,
        [RevokedAtUtc] datetime2 NULL,
        [SecurityVersionSnapshot] int NOT NULL,
        CONSTRAINT [PK_UserRecoveryCodes] PRIMARY KEY ([UserRecoveryCodeId]),
        CONSTRAINT [FK_UserRecoveryCodes_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [HelpTopics] (
        [HelpTopicId] int NOT NULL IDENTITY,
        [HelpCategoryId] int NOT NULL,
        [Slug] nvarchar(160) NOT NULL,
        [Title] nvarchar(180) NOT NULL,
        [Summary] nvarchar(600) NOT NULL,
        [BodyContent] nvarchar(max) NOT NULL,
        [Keywords] nvarchar(800) NULL,
        [AudienceRolesCsv] nvarchar(500) NULL,
        [IsPublic] bit NOT NULL,
        [IsPublished] bit NOT NULL,
        [SortOrder] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [UpdatedByUserId] int NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_HelpTopics] PRIMARY KEY ([HelpTopicId]),
        CONSTRAINT [FK_HelpTopics_HelpCategories_HelpCategoryId] FOREIGN KEY ([HelpCategoryId]) REFERENCES [HelpCategories] ([HelpCategoryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpTopics_Users_UpdatedByUserId] FOREIGN KEY ([UpdatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [DeliveryProofImages] (
        [DeliveryProofImageId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [StoredFileId] bigint NOT NULL,
        [ThumbnailStoredFileId] bigint NULL,
        [UploadedAtUtc] datetime2 NOT NULL,
        [UploadedByUserId] int NOT NULL,
        [UploadedByDriverId] int NULL,
        [Caption] nvarchar(300) NULL,
        [IsPrimary] bit NOT NULL,
        [RemovedAtUtc] datetime2 NULL,
        [RemovedByUserId] int NULL,
        [RemovalReason] nvarchar(500) NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_DeliveryProofImages] PRIMARY KEY ([DeliveryProofImageId]),
        CONSTRAINT [FK_DeliveryProofImages_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_Drivers_UploadedByDriverId] FOREIGN KEY ([UploadedByDriverId]) REFERENCES [Drivers] ([DriverId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_StoredFiles_StoredFileId] FOREIGN KEY ([StoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_StoredFiles_ThumbnailStoredFileId] FOREIGN KEY ([ThumbnailStoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_Users_RemovedByUserId] FOREIGN KEY ([RemovedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [HelpContextMappings] (
        [HelpContextMappingId] int NOT NULL IDENTITY,
        [HelpTopicId] int NOT NULL,
        [RoutePattern] nvarchar(240) NOT NULL,
        [ComponentKey] nvarchar(120) NULL,
        [Priority] int NOT NULL,
        [IsActive] bit NOT NULL,
        CONSTRAINT [PK_HelpContextMappings] PRIMARY KEY ([HelpContextMappingId]),
        CONSTRAINT [FK_HelpContextMappings_HelpTopics_HelpTopicId] FOREIGN KEY ([HelpTopicId]) REFERENCES [HelpTopics] ([HelpTopicId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [HelpMedia] (
        [HelpMediaId] bigint NOT NULL IDENTITY,
        [HelpTopicId] int NULL,
        [StoredFileId] bigint NOT NULL,
        [CaptionStoredFileId] bigint NULL,
        [MediaType] nvarchar(40) NOT NULL,
        [Title] nvarchar(180) NOT NULL,
        [Description] nvarchar(1000) NULL,
        [Transcript] nvarchar(max) NULL,
        [IsFeatured] bit NOT NULL,
        [IsPublished] bit NOT NULL,
        [SortOrder] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [UploadedByUserId] int NOT NULL,
        [RemovedAtUtc] datetime2 NULL,
        [RemovedByUserId] int NULL,
        [RemovalReason] nvarchar(500) NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_HelpMedia] PRIMARY KEY ([HelpMediaId]),
        CONSTRAINT [FK_HelpMedia_HelpTopics_HelpTopicId] FOREIGN KEY ([HelpTopicId]) REFERENCES [HelpTopics] ([HelpTopicId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpMedia_StoredFiles_CaptionStoredFileId] FOREIGN KEY ([CaptionStoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpMedia_StoredFiles_StoredFileId] FOREIGN KEY ([StoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpMedia_Users_RemovedByUserId] FOREIGN KEY ([RemovedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpMedia_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpCategoryId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[HelpCategories]'))
        SET IDENTITY_INSERT [HelpCategories] ON;
    EXEC(N'INSERT INTO [HelpCategories] ([HelpCategoryId], [CreatedAtUtc], [Description], [DisplayName], [IsActive], [SortOrder], [SystemCode], [UpdatedAtUtc])
    VALUES (1, ''2026-07-24T00:00:00.0000000Z'', N''Sign-in, security, navigation and account recovery.'', N''Getting started'', CAST(1 AS bit), 10, N''GETTING_STARTED'', NULL),
    (2, ''2026-07-24T00:00:00.0000000Z'', N''User, role, permission and security administration.'', N''Users and security'', CAST(1 AS bit), 20, N''SECURITY_ADMIN'', NULL),
    (3, ''2026-07-24T00:00:00.0000000Z'', N''Product, batch, stock, expiry and label workflows.'', N''Products and stock'', CAST(1 AS bit), 30, N''PRODUCT_STOCK'', NULL),
    (4, ''2026-07-24T00:00:00.0000000Z'', N''Lookups, warehouse sections and runtime business settings.'', N''Configuration'', CAST(1 AS bit), 40, N''CONFIGURATION'', NULL),
    (5, ''2026-07-24T00:00:00.0000000Z'', N''Customers, orders, reservations, packing and invoices.'', N''Customers and orders'', CAST(1 AS bit), 50, N''ORDERS'', NULL),
    (6, ''2026-07-24T00:00:00.0000000Z'', N''Price history and audit-log workflows.'', N''Pricing and accountability'', CAST(1 AS bit), 60, N''PRICING_AUDIT'', NULL),
    (7, ''2026-07-24T00:00:00.0000000Z'', N''Driver assignment, delivery completion and proof images.'', N''Logistics and delivery'', CAST(1 AS bit), 70, N''DELIVERY'', NULL),
    (8, ''2026-07-24T00:00:00.0000000Z'', N''Common validation, access, email and file problems.'', N''Troubleshooting'', CAST(1 AS bit), 80, N''TROUBLESHOOTING'', NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpCategoryId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[HelpCategories]'))
        SET IDENTITY_INSERT [HelpCategories] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (10, NULL, N''Security'', N''5'', N''Minutes before a login verification code expires.'', N''OTP lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.OtpLifetimeMinutes'', N''15'', N''2'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''TimeSpanMinutes''),
    (11, NULL, N''Security'', N''5'', N''Failed verification attempts allowed before a challenge is locked.'', N''OTP maximum attempts'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.OtpMaximumAttempts'', N''10'', N''3'', CAST(0 AS bit), N''attempts'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''Integer''),
    (12, NULL, N''Security'', N''60'', N''Seconds before another verification code may be sent.'', N''OTP resend delay'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.OtpResendDelaySeconds'', N''300'', N''30'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''60'', N''Integer''),
    (13, NULL, N''Security'', N''5'', N''Verification emails allowed for one account in a rolling hour.'', N''OTP hourly resend limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.OtpMaximumResendsPerHour'', N''10'', N''1'', CAST(0 AS bit), N''resends'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''Integer''),
    (14, NULL, N''Security'', N''30'', N''Days before a trusted-device token expires.'', N''Trusted-device lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.TrustedDeviceDays'', N''90'', N''1'', CAST(0 AS bit), N''days'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''30'', N''Integer''),
    (15, NULL, N''Security'', N''10'', N''One-time recovery codes generated for a user.'', N''Recovery-code count'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.RecoveryCodeCount'', N''10'', N''10'', CAST(0 AS bit), N''codes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (16, NULL, N''Files'', N''10'', N''Maximum upload size for a delivery proof image.'', N''Proof-image maximum size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Files.ProofImageMaximumMb'', N''25'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (17, NULL, N''Files'', N''250'', N''Maximum upload size for a training video.'', N''Training-video maximum size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Files.TrainingVideoMaximumMb'', N''500'', N''10'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''250'', N''Integer''),
    (18, NULL, N''Delivery'', N''true'', N''Require an active delivery proof image before final completion.'', N''Require proof image'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Delivery.RequireProofImageForCompletion'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''true'', N''Boolean'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpTopicId', N'AudienceRolesCsv', N'BodyContent', N'CreatedAtUtc', N'HelpCategoryId', N'IsPublic', N'IsPublished', N'Keywords', N'Slug', N'SortOrder', N'Summary', N'Title', N'UpdatedAtUtc', N'UpdatedByUserId') AND [object_id] = OBJECT_ID(N'[HelpTopics]'))
        SET IDENTITY_INSERT [HelpTopics] ON;
    EXEC(N'INSERT INTO [HelpTopics] ([HelpTopicId], [AudienceRolesCsv], [BodyContent], [CreatedAtUtc], [HelpCategoryId], [IsPublic], [IsPublished], [Keywords], [Slug], [SortOrder], [Summary], [Title], [UpdatedAtUtc], [UpdatedByUserId])
    VALUES (1, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Getting started'' AS nvarchar(max)), nchar(10), N''Sign in with the email address assigned to your user account. PhenyoSync opens the dashboard and actions permitted by your role and permissions.'', nchar(10), nchar(10), N''Use the persistent Help action for guidance on the page you are viewing. Navigation cards and side menus only show authorized workflows. Always sign out when leaving a shared device.'', nchar(10), nchar(10), N''Management users administer users and configuration. Admin handles operational administration. Packers prepare products and orders, Warehouse Managers control stock and expiry, and Drivers access only their assigned deliveries.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(0 AS bit), CAST(1 AS bit), N''start navigation dashboard sign out role'', N''getting-started'', 10, N''Learn the main navigation, role dashboards and safe sign-out workflow.'', N''Getting started with PhenyoSync'', NULL, NULL),
    (2, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Login and email verification'' AS nvarchar(max)), nchar(10), N''Enter your email and password. A new or untrusted session receives a six-digit code by email before business access is granted.'', nchar(10), nchar(10), N''The code expires after five minutes, allows five attempts and can be resent after the displayed countdown. A new resend invalidates the previous code. Never share a password or verification code.'', nchar(10), nchar(10), N''If email is delayed, check junk mail, confirm the masked destination, wait for the resend timer and request a fresh code.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(1 AS bit), CAST(1 AS bit), N''login otp code two factor email resend'', N''login-and-otp'', 20, N''Sign in with a password, verify a new session by email, and understand OTP limits.'', N''Login and email verification'', NULL, NULL),
    (3, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Trusted devices'' AS nvarchar(max)), nchar(10), N''Selecting Trust this device after OTP stores a protected HttpOnly device token. It bypasses OTP for up to 30 days but never bypasses the password.'', nchar(10), nchar(10), N''Open Account Security to review device names, last use and expiry. Revoke an unfamiliar device immediately. Password reset, account deactivation, role changes and security-session revocation invalidate trusted devices.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(0 AS bit), CAST(1 AS bit), N''trusted device revoke thirty days security'', N''trusted-devices'', 30, N''Understand the 30-day trusted-device option and revoke devices safely.'', N''Trusted devices'', NULL, NULL),
    (4, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Recovery codes'' AS nvarchar(max)), nchar(10), N''After the first successful OTP, PhenyoSync displays ten one-time recovery codes. Save or print them immediately; they cannot be shown again.'', nchar(10), nchar(10), N''Use one code from the login verification screen only when email verification is unavailable. Each code works once. Regenerating codes revokes every unused code from the previous set and requires your current password.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(0 AS bit), CAST(1 AS bit), N''recovery code regenerate download print'', N''recovery-codes'', 40, N''Save, use and regenerate one-time recovery codes.'', N''Recovery codes'', NULL, NULL),
    (5, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Password reset'' AS nvarchar(max)), nchar(10), N''Select Forgot Password on the login page and enter your account email. For privacy, the same confirmation appears whether or not an account exists.'', nchar(10), nchar(10), N''Open the email link within 30 minutes, enter matching passwords of at least eight characters and submit once. A successful reset invalidates previous sessions and trusted devices.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(1 AS bit), CAST(1 AS bit), N''forgot password reset email expired link'', N''password-reset'', 50, N''Request and use the secure, expiring password-reset email.'', N''Reset a forgotten password'', NULL, NULL),
    (6, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Manage users'' AS nvarchar(max)), nchar(10), N''Authorized management can search users, create accounts with unique real email addresses, update identity details, assign roles and deactivate or reactivate accounts.'', nchar(10), nchar(10), N''Deactivation blocks new and current sessions without deleting history. Historical users must remain linked to their audit and operational records. Trigger password-reset email instead of setting a password manually.''), ''2026-07-24T00:00:00.0000000Z'', 2, CAST(0 AS bit), CAST(1 AS bit), N''users create update deactivate role password reset'', N''manage-users'', 10, N''Create, search, update, deactivate and reactivate users safely.'', N''Manage users'', NULL, NULL),
    (7, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Roles and permissions'' AS nvarchar(max)), nchar(10), N''Roles group permissions by business responsibility. Create or update custom roles, assign permission checkboxes and inspect a user''''s effective permissions before changing access.'', nchar(10), nchar(10), N''System role codes and system permission codes are protected because APIs depend on them. Unused custom roles may be deactivated or deleted; roles with users or historical references must remain.''), ''2026-07-24T00:00:00.0000000Z'', 2, CAST(0 AS bit), CAST(1 AS bit), N''role permission create assign effective access'', N''roles-and-permissions'', 20, N''Maintain roles, permission assignments and effective access.'', N''Roles and permissions'', NULL, NULL),
    (8, N''CEO,COO,BusinessManager,Admin,Packer'', CONCAT(CAST(N''# Make products'' AS nvarchar(max)), nchar(10), N''Select an existing product identity or enter name, type, category and size. Enter the produced quantity, warehouse section and packed date.'', nchar(10), nchar(10), N''PhenyoSync reuses an exact matching product identity and always creates a separate physical batch. The batch increases available stock, records a stock movement and calculates expiry from the product shelf life.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''make product batch quantity stock increase'', N''make-products'', 10, N''Create or reuse a product and record a new physical batch as stock increase.'', N''Make products and batches'', NULL, NULL),
    (9, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager'', CONCAT(CAST(N''# Search and update products'' AS nvarchar(max)), nchar(10), N''Search by product name, type, category, status or QR value. Select a result to view or update it.'', nchar(10), nchar(10), N''Product changes affect future production, not historical batch snapshots. Use Inactive when a product must stay in history but should not be available for new operations.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''search product update qr inactive'', N''search-update-products'', 20, N''Find products by details or QR value and edit valid master data.'', N''Search and update products'', NULL, NULL),
    (10, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Product types and categories'' AS nvarchar(max)), nchar(10), N''Management pages maintain the database values shown in product forms. Names are unique and active entries are available for new products.'', nchar(10), nchar(10), N''A type or category linked to products cannot be permanently removed. Deactivate it instead so history remains valid.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''product type category crud deactivate'', N''product-types-categories'', 30, N''Create, edit, activate and dependency-check product classifications.'', N''Product types and categories'', NULL, NULL),
    (11, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager'', CONCAT(CAST(N''# QR codes and labels'' AS nvarchar(max)), nchar(10), N''Each physical batch receives a scannable QR value. The printable label identifies the product, batch code, packed date and expiry date.'', nchar(10), nchar(10), N''Attach the label to the matching physical stock. Scanning should open or identify that exact batch, not just the product master record.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''qr code label print batch'', N''qr-labels'', 40, N''Generate, download and use batch-specific QR labels.'', N''QR codes and labels'', NULL, NULL),
    (12, N''CEO,COO,BusinessManager,WarehouseManager'', CONCAT(CAST(N''# Stock takes'' AS nvarchar(max)), nchar(10), N''Start a stock-take session, capture observed quantities and review discrepancies before posting.'', nchar(10), nchar(10), N''Adjustments require an approved reason and create immutable stock movements. Never edit aggregate stock directly; batch and movement records are the accountability source.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''stock take adjustment movement discrepancy'', N''stock-take'', 50, N''Count physical stock and record controlled adjustments.'', N''Stock takes and adjustments'', NULL, NULL),
    (13, N''CEO,COO,BusinessManager,WarehouseManager'', CONCAT(CAST(N''# Expiry management'' AS nvarchar(max)), nchar(10), N''Yellow warnings identify batches approaching expiry. Red urgent warnings appear when 24 hours or less remain.'', nchar(10), nchar(10), N''Authorized users may write off remaining stock or approve the one-time two-day extension after inspection and with a reason. Expired, consumed and written-off batches are excluded from available stock.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''expiry yellow red urgent write off extension'', N''expiry-actions'', 60, N''Respond to yellow and urgent expiry alerts safely.'', N''Expiry warnings, write-off and extension'', NULL, NULL),
    (14, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Operational lookups'' AS nvarchar(max)), nchar(10), N''Lookup values supply controlled options for stock movements, write-offs, order cancellation, delivery failures, payment methods, customer and supplier types, and units of measure.'', nchar(10), nchar(10), N''Display names and active status are editable. Protected system codes remain immutable because workflow logic and reporting use them.''), ''2026-07-24T00:00:00.0000000Z'', 4, CAST(0 AS bit), CAST(1 AS bit), N''lookup reason payment method customer supplier unit'', N''operational-lookups'', 10, N''Maintain approved reasons, payment methods, customer types and units.'', N''Operational lookups'', NULL, NULL),
    (15, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Warehouse sections'' AS nvarchar(max)), nchar(10), N''Create a unique section code, display name and description. Active sections appear in product and stock workflows.'', nchar(10), nchar(10), N''Deactivate a location that should no longer receive stock. Do not delete a section referenced by stock, batches or movements.''), ''2026-07-24T00:00:00.0000000Z'', 4, CAST(0 AS bit), CAST(1 AS bit), N''warehouse section location create deactivate'', N''warehouse-sections'', 20, N''Maintain warehouse locations without breaking historical stock.'', N''Warehouse sections'', NULL, NULL),
    (16, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# System settings'' AS nvarchar(max)), nchar(10), N''Authorized management can edit expiry thresholds, scanning intervals, order-link lifetime, delivery duration, OTP limits and file limits.'', nchar(10), nchar(10), N''Values are type-checked and range-checked. Changes apply immediately through cache invalidation and retain a history with actor, time and reason.''), ''2026-07-24T00:00:00.0000000Z'', 4, CAST(0 AS bit), CAST(1 AS bit), N''settings timers threshold history configuration'', N''system-settings'', 30, N''Change validated business timers and thresholds immediately.'', N''System settings and history'', NULL, NULL),
    (17, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Customers, suppliers and payments'' AS nvarchar(max)), nchar(10), N''Use unique contact details and active classifications when maintaining customers and suppliers. Orders must link to valid customers.'', nchar(10), nchar(10), N''Admin and authorized management capture and confirm payments. Amounts must be positive and cannot exceed the outstanding invoice. Reversal requires a reason and audit record.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''customer supplier payment invoice confirm reverse'', N''customers-suppliers-payments'', 10, N''Maintain parties and capture authorized payments.'', N''Customers, suppliers and payments'', NULL, NULL),
    (18, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Customer order links'' AS nvarchar(max)), nchar(10), N''Select a valid customer, confirm the email address and send the secure order link. The link expires according to the configured lifetime and can be used once.'', nchar(10), nchar(10), N''The public form exposes only active products with current valid prices. A submitted link cannot be reused.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''order link customer email one time expiry'', N''order-links'', 20, N''Generate and email a unique, expiring, one-time order form.'', N''Send customer order links'', NULL, NULL),
    (19, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Create and validate orders'' AS nvarchar(max)), nchar(10), N''Select a customer and add products with positive quantities. Prices are read from the current server-side price record and snapshotted onto order lines.'', nchar(10), nchar(10), N''Validation checks details and uses FEFO to reserve eligible batches atomically. An order cannot be confirmed when stock is insufficient.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''create order validate stock reserve fefo price'', N''create-validate-orders'', 30, N''Capture order lines and reserve sufficient eligible stock.'', N''Create and validate orders'', NULL, NULL),
    (20, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Order status and cancellation'' AS nvarchar(max)), nchar(10), N''Orders move through the controlled sequence from pending validation to confirmed, packed, out for delivery and delivered.'', nchar(10), nchar(10), N''Cancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''order status cancel reservation release'', N''order-status-cancel'', 40, N''Follow the valid status sequence and release reservations on cancellation.'', N''Order status and cancellation'', NULL, NULL),
    (21, N''CEO,COO,BusinessManager,Admin,Packer'', CONCAT(CAST(N''# Packing and invoices'' AS nvarchar(max)), nchar(10), N''Packers open the packing queue, verify each allocated batch and quantity, then confirm packing once.'', nchar(10), nchar(10), N''Packing decreases stock with movements and creates the order''''s invoice snapshot. The invoice remains linked to the order and later price changes do not alter it.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''packing list batch invoice stock decrease'', N''packing-invoices'', 50, N''Pack allocated batches and view the immutable invoice snapshot.'', N''Packing lists and invoices'', NULL, NULL),
    (22, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Pricing'' AS nvarchar(max)), nchar(10), N''A price must be greater than zero and belong to a valid product. Updating a price closes the previous record and creates a new current version.'', nchar(10), nchar(10), N''Soft deletion removes a price from future ordering but preserves its history. Existing order items and invoices retain their snapshotted unit prices.''), ''2026-07-24T00:00:00.0000000Z'', 6, CAST(0 AS bit), CAST(1 AS bit), N''price create update history soft delete current'', N''pricing'', 10, N''Create current product prices while preserving historical versions.'', N''Pricing and price history'', NULL, NULL),
    (23, N''CEO,COO,BusinessManager'', CONCAT(CAST(N''# Audit logs'' AS nvarchar(max)), nchar(10), N''Search by user, date, action, module, entity, success state, correlation ID or text. Open a result to inspect sanitized before-and-after details.'', nchar(10), nchar(10), N''Audit logs are read-only and retained for accountability. A correlation ID groups changes and security events from the same request or workflow.''), ''2026-07-24T00:00:00.0000000Z'', 6, CAST(0 AS bit), CAST(1 AS bit), N''audit log search correlation activity readonly'', N''audit-logs'', 20, N''Find read-only accountability records and use correlation IDs.'', N''Search audit logs'', NULL, NULL),
    (24, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Assign drivers'' AS nvarchar(max)), nchar(10), N''A packed order may be scheduled for a delivery window. Select an active available driver whose licence covers the full window.'', nchar(10), nchar(10), N''PhenyoSync prevents overlapping assignments and records assignment, reassignment and unassignment history.''), ''2026-07-24T00:00:00.0000000Z'', 7, CAST(0 AS bit), CAST(1 AS bit), N''delivery schedule assign driver availability overlap'', N''assign-drivers'', 10, N''Schedule deliveries and prevent overlapping driver assignments.'', N''Assign drivers'', NULL, NULL),
    (25, N''Driver'', CONCAT(CAST(N''# My Deliveries'' AS nvarchar(max)), nchar(10), N''Drivers see only currently assigned deliveries. Open a record for the schedule, customer, address and order details.'', nchar(10), nchar(10), N''Start the delivery only when it is Assigned. This moves the delivery and order into their in-transit states.''), ''2026-07-24T00:00:00.0000000Z'', 7, CAST(0 AS bit), CAST(1 AS bit), N''driver my deliveries assigned start'', N''my-deliveries'', 20, N''Review and start only deliveries assigned to your driver account.'', N''Driver: My Deliveries'', NULL, NULL),
    (26, N''CEO,COO,BusinessManager,Admin,Driver'', CONCAT(CAST(N''# Complete a delivery'' AS nvarchar(max)), nchar(10), N''Upload one or more JPEG, PNG or WebP proof images, add a useful caption and select the primary image. Confirm the recipient and successful fulfillment.'', nchar(10), nchar(10), N''Proof is required by default. The assigned Driver may complete their own in-transit delivery. Authorized management can complete on behalf of a driver or override missing proof only with an explicit reason.'', nchar(10), nchar(10), N''Completion is final: proof becomes read-only, the delivery records a UTC completion time and the order becomes Delivered.''), ''2026-07-24T00:00:00.0000000Z'', 7, CAST(0 AS bit), CAST(1 AS bit), N''delivery proof image upload complete recipient override'', N''complete-delivery-proof'', 30, N''Upload protected proof images before final delivery completion.'', N''Complete delivery with proof images'', NULL, NULL),
    (27, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Validation and server errors'' AS nvarchar(max)), nchar(10), N''Read the friendly message and correct every highlighted field. Refresh when a row-version conflict says the record changed.'', nchar(10), nchar(10), N''If an unexpected server error persists, note the displayed trace ID and the time of the action. Do not send passwords, OTPs or recovery codes to support.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(1 AS bit), CAST(1 AS bit), N''validation error trace id conflict support'', N''validation-errors'', 10, N''Resolve highlighted fields and provide a trace ID when support is needed.'', N''Validation messages and trace IDs'', NULL, NULL),
    (28, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Permission denied'' AS nvarchar(max)), nchar(10), N''Menus and APIs are controlled by database permissions. A denied action means the signed-in role does not currently have that permission.'', nchar(10), nchar(10), N''Ask authorized management to review your effective permissions. Sign out and in again after a role change so the session uses the new security version.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(0 AS bit), CAST(1 AS bit), N''permission denied role access 403'', N''permission-denied'', 20, N''Understand why a page or action is unavailable.'', N''Permission denied'', NULL, NULL),
    (29, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Expired links'' AS nvarchar(max)), nchar(10), N''Security links are time-limited and often one-time. Request a new password-reset link, customer order link or expiry review link from the appropriate workflow.'', nchar(10), nchar(10), N''Do not edit tokens in the address bar or share links. A used link cannot be reactivated.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(1 AS bit), CAST(1 AS bit), N''expired link used token password order expiry'', N''expired-links'', 30, N''Recover from password, order or expiry-action links that no longer work.'', N''Expired or used links'', NULL, NULL),
    (30, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Unavailable drivers'' AS nvarchar(max)), nchar(10), N''A driver is unavailable when inactive, not marked Available, missing a valid driver-user link, holding an expired licence or already assigned to an overlapping window.'', nchar(10), nchar(10), N''Adjust the schedule, update legitimate driver details or select a different available driver. Do not bypass overlap protection.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(0 AS bit), CAST(1 AS bit), N''driver unavailable overlap licence schedule'', N''unavailable-drivers'', 40, N''Resolve licence, status and schedule conflicts during assignment.'', N''Unavailable drivers'', NULL, NULL),
    (31, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# OTP email not received'' AS nvarchar(max)), nchar(10), N''Confirm the masked email destination, check spam, wait for the resend countdown and request one fresh code. Only the newest code is valid.'', nchar(10), nchar(10), N''If email remains unavailable, use a saved recovery code. Contact management to correct the account email; never create duplicate shared addresses.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(1 AS bit), CAST(1 AS bit), N''otp email not received resend recovery'', N''otp-not-received'', 50, N''Use safe recovery steps when the verification email is delayed.'', N''OTP email not received'', NULL, NULL),
    (32, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# File rejected'' AS nvarchar(max)), nchar(10), N''Proof images must be genuine JPEG, PNG or WebP files within the configured limit. Training media must be a genuine MP4 or WebM; captions must be WEBVTT.'', nchar(10), nchar(10), N''Renaming an extension does not convert a file. Export the file in an allowed format and retry. Executable, SVG, HTML, polyglot and mismatched files are blocked.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(0 AS bit), CAST(1 AS bit), N''file rejected image video size mime extension'', N''file-rejected'', 60, N''Resolve protected-file validation failures without weakening security.'', N''A proof image or training video was rejected'', NULL, NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpTopicId', N'AudienceRolesCsv', N'BodyContent', N'CreatedAtUtc', N'HelpCategoryId', N'IsPublic', N'IsPublished', N'Keywords', N'Slug', N'SortOrder', N'Summary', N'Title', N'UpdatedAtUtc', N'UpdatedByUserId') AND [object_id] = OBJECT_ID(N'[HelpTopics]'))
        SET IDENTITY_INSERT [HelpTopics] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpContextMappingId', N'ComponentKey', N'HelpTopicId', N'IsActive', N'Priority', N'RoutePattern') AND [object_id] = OBJECT_ID(N'[HelpContextMappings]'))
        SET IDENTITY_INSERT [HelpContextMappings] ON;
    EXEC(N'INSERT INTO [HelpContextMappings] ([HelpContextMappingId], [ComponentKey], [HelpTopicId], [IsActive], [Priority], [RoutePattern])
    VALUES (1, N''AdminDashboard'', 1, CAST(1 AS bit), 100, N''/admin-dashboard''),
    (2, N''PackerDashboard'', 1, CAST(1 AS bit), 100, N''/packer-dashboard''),
    (3, N''WarehouseManagerDashboard'', 1, CAST(1 AS bit), 100, N''/dashboard''),
    (4, N''DriverDashboard'', 25, CAST(1 AS bit), 100, N''/driver-dashboard''),
    (5, N''Login'', 2, CAST(1 AS bit), 100, N''/login''),
    (6, N''ResetPassword'', 5, CAST(1 AS bit), 100, N''/reset-password''),
    (7, N''ManageUsers'', 6, CAST(1 AS bit), 100, N''/manage-users''),
    (8, N''ManageRoles'', 7, CAST(1 AS bit), 100, N''/manage-roles''),
    (9, N''ManagePermissions'', 7, CAST(1 AS bit), 100, N''/manage-permissions''),
    (10, N''MakeProduct'', 8, CAST(1 AS bit), 100, N''/make-product''),
    (11, N''SearchProduct'', 9, CAST(1 AS bit), 100, N''/search-product''),
    (12, N''UpdateProduct'', 9, CAST(1 AS bit), 100, N''/update-product''),
    (13, N''ManageProductTypes'', 10, CAST(1 AS bit), 100, N''/manage-product-types''),
    (14, N''ManageProductCategories'', 10, CAST(1 AS bit), 100, N''/manage-product-categories''),
    (15, N''StockTake'', 12, CAST(1 AS bit), 100, N''/stock-take''),
    (16, N''ExpiryAlerts'', 13, CAST(1 AS bit), 100, N''/expiry-alerts''),
    (17, N''ManageLookups'', 14, CAST(1 AS bit), 100, N''/manage-lookups''),
    (18, N''WarehouseSections'', 15, CAST(1 AS bit), 100, N''/manage-warehouse-sections''),
    (19, N''SystemSettings'', 16, CAST(1 AS bit), 100, N''/manage-system-settings''),
    (20, N''SendOrderLink'', 18, CAST(1 AS bit), 100, N''/send-order-link''),
    (21, N''OrderEditor'', 19, CAST(1 AS bit), 100, N''/create-order''),
    (22, N''OrderDetails'', 20, CAST(1 AS bit), 100, N''/order-details/:id''),
    (23, N''PackingOrders'', 21, CAST(1 AS bit), 100, N''/view-pick-list''),
    (24, N''OrderInvoice'', 21, CAST(1 AS bit), 100, N''/order-invoice/:id''),
    (25, N''PricingManagement'', 22, CAST(1 AS bit), 100, N''/pricing-management''),
    (26, N''AuditLogs'', 23, CAST(1 AS bit), 100, N''/audit-logs''),
    (27, N''DeliveryManagement'', 24, CAST(1 AS bit), 100, N''/deliveries''),
    (28, N''MyDeliveries'', 25, CAST(1 AS bit), 100, N''/my-deliveries''),
    (29, N''CompleteDelivery'', 26, CAST(1 AS bit), 100, N''/deliveries/:id/complete''),
    (30, N''DeliveryProof'', 26, CAST(1 AS bit), 100, N''/deliveries/:id/proof''),
    (31, N''AccountSecurity'', 3, CAST(1 AS bit), 100, N''/account-security''),
    (32, N''HelpCenter'', 1, CAST(1 AS bit), 50, N''/help'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpContextMappingId', N'ComponentKey', N'HelpTopicId', N'IsActive', N'Priority', N'RoutePattern') AND [object_id] = OBJECT_ID(N'[HelpContextMappings]'))
        SET IDENTITY_INSERT [HelpContextMappings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_DeliveryId_RemovedAtUtc_UploadedAtUtc] ON [DeliveryProofImages] ([DeliveryId], [RemovedAtUtc], [UploadedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_RemovedByUserId] ON [DeliveryProofImages] ([RemovedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [IX_DeliveryProofImages_StoredFileId] ON [DeliveryProofImages] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_ThumbnailStoredFileId] ON [DeliveryProofImages] ([ThumbnailStoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_UploadedByDriverId] ON [DeliveryProofImages] ([UploadedByDriverId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_UploadedByUserId] ON [DeliveryProofImages] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [UX_DeliveryProofImages_Primary] ON [DeliveryProofImages] ([DeliveryId], [IsPrimary]) WHERE [IsPrimary] = 1 AND [RemovedAtUtc] IS NULL');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpCategories_IsActive_SortOrder_DisplayName] ON [HelpCategories] ([IsActive], [SortOrder], [DisplayName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [IX_HelpCategories_SystemCode] ON [HelpCategories] ([SystemCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpContextMappings_HelpTopicId] ON [HelpContextMappings] ([HelpTopicId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpContextMappings_RoutePattern_ComponentKey_IsActive_Priority] ON [HelpContextMappings] ([RoutePattern], [ComponentKey], [IsActive], [Priority]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_CaptionStoredFileId] ON [HelpMedia] ([CaptionStoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_HelpTopicId] ON [HelpMedia] ([HelpTopicId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_IsPublished_IsFeatured_SortOrder] ON [HelpMedia] ([IsPublished], [IsFeatured], [SortOrder]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_RemovedByUserId] ON [HelpMedia] ([RemovedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_StoredFileId] ON [HelpMedia] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_UploadedByUserId] ON [HelpMedia] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpTopics_HelpCategoryId_IsPublished_SortOrder] ON [HelpTopics] ([HelpCategoryId], [IsPublished], [SortOrder]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [IX_HelpTopics_Slug] ON [HelpTopics] ([Slug]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpTopics_UpdatedByUserId] ON [HelpTopics] ([UpdatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_StoredFiles_DeletedByUserId] ON [StoredFiles] ([DeletedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_StoredFiles_IsDeleted_UploadedAtUtc] ON [StoredFiles] ([IsDeleted], [UploadedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_StoredFiles_UploadedByUserId] ON [StoredFiles] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [UX_StoredFiles_StorageKey] ON [StoredFiles] ([StorageKey]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_TrustedDevices_RevokedByUserId] ON [TrustedDevices] ([RevokedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_TrustedDevices_UserId_RevokedAtUtc_ExpiresAtUtc] ON [TrustedDevices] ([UserId], [RevokedAtUtc], [ExpiresAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [UX_TrustedDevices_TokenHash] ON [TrustedDevices] ([TokenHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_UserOtpChallenges_UserId_Purpose_ExpiresAtUtc] ON [UserOtpChallenges] ([UserId], [Purpose], [ExpiresAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [UX_UserOtpChallenges_ChallengeHash] ON [UserOtpChallenges] ([ChallengeTokenHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_UserRecoveryCodes_UserId_CodeOrder_CreatedAtUtc] ON [UserRecoveryCodes] ([UserId], [CodeOrder], [CreatedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    DECLARE @PhaseA3PermissionSeed TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(120) NOT NULL,
        Module nvarchar(80) NOT NULL
    );
    INSERT INTO @PhaseA3PermissionSeed VALUES
        ('Help.View', 'View Help content', 'Help'),
        ('Help.Manage', 'Manage Help content', 'Help'),
        ('HelpMedia.Manage', 'Manage training media', 'Help');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT seed.PermissionCode, seed.PermissionCode,
           seed.DisplayName, seed.Module, 1, 1, SYSUTCDATETIME()
    FROM @PhaseA3PermissionSeed seed
    WHERE NOT EXISTS (
        SELECT 1
        FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode);
    UPDATE permission
    SET permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @PhaseA3PermissionSeed seed
      ON seed.PermissionCode = permission.PermissionCode;
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode IN
         ('Help.View', 'Help.Manage', 'HelpMedia.Manage')
    WHERE role.RoleCode IN ('CEO', 'COO', 'BusinessManager')
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions existing
          WHERE existing.RoleId = role.RoleId
            AND existing.PermissionId = permission.PermissionId);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode IN
         ('Help.View', 'Help.Manage', 'HelpMedia.Manage')
    WHERE role.RoleCode = 'Admin'
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions existing
          WHERE existing.RoleId = role.RoleId
            AND existing.PermissionId = permission.PermissionId);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = 'Help.View'
    WHERE role.RoleCode IN ('Packer', 'WarehouseManager', 'Driver')
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions existing
          WHERE existing.RoleId = role.RoleId
            AND existing.PermissionId = permission.PermissionId);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia', N'8.0.0');
END;
GO

COMMIT;
GO

