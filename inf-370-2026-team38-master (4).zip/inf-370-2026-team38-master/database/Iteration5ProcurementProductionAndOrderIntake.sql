﻿BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    ALTER TABLE [Users] ADD [RequireTwoFactorOnNextWebLogin] bit NOT NULL DEFAULT CAST(0 AS bit);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE TABLE [ExternalOrderSubmissions] (
        [ExternalOrderSubmissionId] bigint NOT NULL IDENTITY,
        [Source] nvarchar(40) NOT NULL,
        [ExternalSourceKey] nvarchar(180) NOT NULL,
        [PayloadHash] nvarchar(64) NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [SafeIssueSummary] nvarchar(1000) NULL,
        [SubmittedAtUtc] datetime2 NULL,
        [ImportedAtUtc] datetime2 NOT NULL,
        [SalesOrderId] int NULL,
        [ImportedByUserId] int NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_ExternalOrderSubmissions] PRIMARY KEY ([ExternalOrderSubmissionId]),
        CONSTRAINT [FK_ExternalOrderSubmissions_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ExternalOrderSubmissions_Users_ImportedByUserId] FOREIGN KEY ([ImportedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE TABLE [PackingConversions] (
        [PackingConversionId] bigint NOT NULL IDENTITY,
        [ProductId] int NOT NULL,
        [ProductBatchId] int NOT NULL,
        [WarehouseSectionId] int NOT NULL,
        [QuantityProduced] decimal(18,3) NOT NULL,
        [PackedByUserId] int NOT NULL,
        [PackedAtUtc] datetime2 NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_PackingConversions] PRIMARY KEY ([PackingConversionId]),
        CONSTRAINT [FK_PackingConversions_ProductBatches_ProductBatchId] FOREIGN KEY ([ProductBatchId]) REFERENCES [ProductBatches] ([ProductBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingConversions_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingConversions_Users_PackedByUserId] FOREIGN KEY ([PackedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingConversions_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE TABLE [PackingConversionRawStock] (
        [PackingConversionRawStockId] bigint NOT NULL IDENTITY,
        [PackingConversionId] bigint NOT NULL,
        [RawStockItemId] int NOT NULL,
        [RawStockBalanceId] int NOT NULL,
        [RawStockBatchId] bigint NOT NULL,
        [QuantityConsumed] decimal(18,3) NOT NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [BalanceBefore] decimal(18,3) NOT NULL,
        [BalanceAfter] decimal(18,3) NOT NULL,
        [BatchBefore] decimal(18,3) NOT NULL,
        [BatchAfter] decimal(18,3) NOT NULL,
        [UnitCost] decimal(18,4) NULL,
        CONSTRAINT [PK_PackingConversionRawStock] PRIMARY KEY ([PackingConversionRawStockId]),
        CONSTRAINT [FK_PackingConversionRawStock_PackingConversions_PackingConversionId] FOREIGN KEY ([PackingConversionId]) REFERENCES [PackingConversions] ([PackingConversionId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingConversionRawStock_RawStockBalances_RawStockBalanceId] FOREIGN KEY ([RawStockBalanceId]) REFERENCES [RawStockBalances] ([RawStockBalanceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingConversionRawStock_RawStockBatches_RawStockBatchId] FOREIGN KEY ([RawStockBatchId]) REFERENCES [RawStockBatches] ([RawStockBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingConversionRawStock_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Login and email verification'' AS nvarchar(max)), nchar(10), N''Enter your email and password. Normal web and mobile sign-in opens the permitted dashboard without an email code.'', nchar(10), nchar(10), N''After a successful password reset or account-owner password change, the next web login requires one email verification challenge. Mobile login remains available and does not clear this requirement. The requirement is cleared only after the web code or recovery code is verified successfully.'', nchar(10), nchar(10), N''The code expires after five minutes and is attempt limited. Never share a password or verification code. If email is delayed, check junk mail, confirm the masked destination, wait for the resend timer and request one fresh code.''), [Summary] = N''Sign in normally and understand the one-time web verification required after a password reset.''
    WHERE [HelpTopicId] = 2;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Trusted devices'' AS nvarchar(max)), nchar(10), N''Normal sign-in no longer uses a trusted-device token to decide whether verification is required. Existing device records remain visible for accountability and can be revoked.'', nchar(10), nchar(10), N''Open Account Security to review device names, last use and expiry. Revoke an unfamiliar device immediately. Password reset, account deactivation, role changes and security-session revocation invalidate trusted devices.''), [Summary] = N''Review and revoke legacy trusted-device records safely.''
    WHERE [HelpTopicId] = 3;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Make products'' AS nvarchar(max)), nchar(10), N''Select a warehouse section, then select an existing active Product whose Raw Stock requirements are configured and currently available. The readiness card shows adjusted input quantities and maximum packable output.'', nchar(10), nchar(10), N''Confirming production consumes eligible Raw Stock batches in expiry and FIFO order, writes negative Raw Stock movements, creates one finished Product batch and stock increase, and links the records through one conversion and correlation ID. The transaction rolls back when any input is insufficient or changes concurrently. Product master creation and order barcode packing remain separate workflows.''), [Keywords] = N''make product raw stock conversion recipe trace batch'', [Summary] = N''Convert mapped Raw Stock into an existing Product and trace both sides of production.''
    WHERE [HelpTopicId] = 8;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Customer order form'' AS nvarchar(max)), nchar(10), N''Open the configured Google Form from Order Management and share it with the customer. When responses are ready, an authorised user selects Synchronise responses. PhenyoSync reads the configured Google Sheet through the backend and never exposes the provider key to the browser.'', nchar(10), nchar(10), N''Each response has a stable external key, so repeated syncs cannot create duplicate orders. Valid responses use the existing Product codes and active Customer, apply authoritative server-side prices, and enter the system as Submitted with Pending Validation. Unknown customers, Products, malformed quantities and incomplete addresses remain in Needs Attention instead of silently creating records.''), [Keywords] = N''customer google sheet order sync duplicate pending validation'', [Summary] = N''Share the configured Google Form and manually synchronise controlled order requests.''
    WHERE [HelpTopicId] = 18;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Formal reports'' AS nvarchar(max)), nchar(10), N''Choose a report, set its criteria and select Preview. The preview is the authoritative dataset for the PDF. If any criterion changes, preview the report again before downloading.'', nchar(10), nchar(10), N''Inventory Availability, Expiry and Waste, and Markup Analysis are simple flat reports. Sales and Stock Movement reports use visible control breaks, subtotals and grand totals. Currency is displayed in South African rand and timestamps are shown consistently with the selected criteria.'', nchar(10), nchar(10), N''Access to costs, reversals and exports is controlled independently. Future dates and future pricing periods are rejected in both the page and API. An empty report means no records matched the selected criteria; it is not a failure. Every preview and PDF export is audited.'')
    WHERE [HelpTopicId] = 33;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpTopicId', N'AudienceRolesCsv', N'BodyContent', N'CreatedAtUtc', N'HelpCategoryId', N'IsPublic', N'IsPublished', N'Keywords', N'Slug', N'SortOrder', N'Summary', N'Title', N'UpdatedAtUtc', N'UpdatedByUserId') AND [object_id] = OBJECT_ID(N'[HelpTopics]'))
        SET IDENTITY_INSERT [HelpTopics] ON;
    EXEC(N'INSERT INTO [HelpTopics] ([HelpTopicId], [AudienceRolesCsv], [BodyContent], [CreatedAtUtc], [HelpCategoryId], [IsPublic], [IsPublished], [Keywords], [Slug], [SortOrder], [Summary], [Title], [UpdatedAtUtc], [UpdatedByUserId])
    VALUES (36, N''OperationsManager,BusinessManager,Admin,WarehouseManager'', CONCAT(CAST(N''# Product and price data exchange'' AS nvarchar(max)), nchar(10), N''Use the same filters for the presentation-ready Excel workbook and stable, indented JSON catalogue. Both formats show the Product master and price effective at the selected business date. Excel includes instructions, metadata, filters and typed columns; JSON includes a schema version and deterministic Product ordering.'', nchar(10), nchar(10), N''Import remains an Excel-only controlled workflow: upload the current template, review valid, warning and invalid rows, enter a business reason, confirm, and apply the exact staged content. Existing prices are versioned instead of overwritten. JSON catalogue export never imports or mutates records.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''excel json product price catalogue template validate import export'', N''product-data-exchange'', 40, N''Export professional Excel or readable JSON and apply only validated Excel imports.'', N''Product and price data exchange'', NULL, NULL),
    (37, N''OperationsManager,BusinessManager,Admin,WarehouseManager'', CONCAT(CAST(N''# Procurement shortages'' AS nvarchar(max)), nchar(10), N''Shortage planning starts with approved, confirmed and active fulfilment demand. Submitted customer or Google Form requests are excluded until validation succeeds. Active finished-stock reservations are subtracted before the Product shortage is calculated.'', nchar(10), nchar(10), N''Product shortages are translated through active Product-to-Raw-Stock requirements, including configured yield and waste. Available Raw Stock, outstanding supplier orders and open buying-list quantities are then subtracted. Negative values are clamped per line before aggregation so one over-supplied line cannot hide another shortage.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''procurement demand shortage reservation raw stock buying list'', N''procurement-shortages'', 50, N''Understand how validated demand becomes Product and Raw Stock buying requirements.'', N''Demand-driven procurement shortages'', NULL, NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpTopicId', N'AudienceRolesCsv', N'BodyContent', N'CreatedAtUtc', N'HelpCategoryId', N'IsPublic', N'IsPublished', N'Keywords', N'Slug', N'SortOrder', N'Summary', N'Title', N'UpdatedAtUtc', N'UpdatedByUserId') AND [object_id] = OBJECT_ID(N'[HelpTopics]'))
        SET IDENTITY_INSERT [HelpTopics] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpContextMappingId', N'ComponentKey', N'HelpTopicId', N'IsActive', N'Priority', N'RoutePattern') AND [object_id] = OBJECT_ID(N'[HelpContextMappings]'))
        SET IDENTITY_INSERT [HelpContextMappings] ON;
    EXEC(N'INSERT INTO [HelpContextMappings] ([HelpContextMappingId], [ComponentKey], [HelpTopicId], [IsActive], [Priority], [RoutePattern])
    VALUES (41, N''ProductDataExchange'', 36, CAST(1 AS bit), 100, N''/product-data-exchange''),
    (42, N''BuyingLists'', 37, CAST(1 AS bit), 100, N''/buying-lists''),
    (43, N''RawStock'', 37, CAST(1 AS bit), 90, N''/raw-stock'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpContextMappingId', N'ComponentKey', N'HelpTopicId', N'IsActive', N'Priority', N'RoutePattern') AND [object_id] = OBJECT_ID(N'[HelpContextMappings]'))
        SET IDENTITY_INSERT [HelpContextMappings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_ExternalOrderSubmissions_CorrelationId] ON [ExternalOrderSubmissions] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_ExternalOrderSubmissions_ImportedByUserId] ON [ExternalOrderSubmissions] ([ImportedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_ExternalOrderSubmissions_SalesOrderId] ON [ExternalOrderSubmissions] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_ExternalOrderSubmissions_Status_ImportedAtUtc] ON [ExternalOrderSubmissions] ([Status], [ImportedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE UNIQUE INDEX [UX_ExternalOrderSubmissions_Source_Key] ON [ExternalOrderSubmissions] ([Source], [ExternalSourceKey]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_PackingConversionRawStock_PackingConversionId_RawStockItemId] ON [PackingConversionRawStock] ([PackingConversionId], [RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_PackingConversionRawStock_RawStockBalanceId] ON [PackingConversionRawStock] ([RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_PackingConversionRawStock_RawStockBatchId] ON [PackingConversionRawStock] ([RawStockBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_PackingConversionRawStock_RawStockItemId] ON [PackingConversionRawStock] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_PackingConversions_CorrelationId] ON [PackingConversions] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_PackingConversions_PackedByUserId] ON [PackingConversions] ([PackedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_PackingConversions_ProductId_PackedAtUtc] ON [PackingConversions] ([ProductId], [PackedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE INDEX [IX_PackingConversions_WarehouseSectionId] ON [PackingConversions] ([WarehouseSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    CREATE UNIQUE INDEX [UX_PackingConversions_ProductBatch] ON [PackingConversions] ([ProductBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260816171840_Iteration5ProcurementProductionAndOrderIntake'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260816171840_Iteration5ProcurementProductionAndOrderIntake', N'8.0.0');
END;
GO

COMMIT;
GO

