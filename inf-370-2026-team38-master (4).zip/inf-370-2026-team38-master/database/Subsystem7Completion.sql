/*
  PhenyoSync WMS - INF370 Subsystem 7
  Safe, idempotent SQL Server deployment for existing WMS_DB installations.
  This script never drops Product, ProductType, ProductCategory, or their data.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.ProductType', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.ProductType (
            ProductTypeId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ProductType PRIMARY KEY,
            ProductTypeName NVARCHAR(100) NOT NULL,
            Description NVARCHAR(255) NULL,
            Status NVARCHAR(20) NOT NULL CONSTRAINT DF_ProductType_Status DEFAULT N'Active',
            CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_ProductType_CreatedAt DEFAULT SYSUTCDATETIME(),
            UpdatedAt DATETIME2 NULL
        );
    END;

    IF OBJECT_ID(N'dbo.ProductCategory', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.ProductCategory (
            ProductCategoryId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ProductCategory PRIMARY KEY,
            ProductCategoryName NVARCHAR(100) NOT NULL,
            Description NVARCHAR(255) NULL,
            Status NVARCHAR(20) NOT NULL CONSTRAINT DF_ProductCategory_Status DEFAULT N'Active',
            CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_ProductCategory_CreatedAt DEFAULT SYSUTCDATETIME(),
            UpdatedAt DATETIME2 NULL
        );
    END;

    IF OBJECT_ID(N'dbo.Product', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.Product (
            ProductId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Product PRIMARY KEY,
            ProductName NVARCHAR(150) NOT NULL,
            ProductTypeId INT NOT NULL,
            ProductCategoryId INT NOT NULL,
            Size NVARCHAR(50) NOT NULL,
            ShelfLifeDays INT NOT NULL,
            QRCodeValue NVARCHAR(500) NULL,
            Status NVARCHAR(20) NOT NULL CONSTRAINT DF_Product_Status DEFAULT N'Active',
            CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_Product_CreatedAt DEFAULT SYSUTCDATETIME(),
            UpdatedAt DATETIME2 NULL,
            CONSTRAINT FK_Product_ProductType_ProductTypeId FOREIGN KEY (ProductTypeId)
                REFERENCES dbo.ProductType(ProductTypeId),
            CONSTRAINT FK_Product_ProductCategory_ProductCategoryId FOREIGN KEY (ProductCategoryId)
                REFERENCES dbo.ProductCategory(ProductCategoryId)
        );
    END;

    IF OBJECT_ID(N'dbo.WarehouseSections', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.WarehouseSections (
            SectionId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WarehouseSections PRIMARY KEY,
            SectionName NVARCHAR(150) NOT NULL,
            Description NVARCHAR(500) NULL,
            Status NVARCHAR(20) NOT NULL CONSTRAINT DF_WarehouseSections_Status DEFAULT N'Active'
        );
    END;

    IF NOT EXISTS (SELECT 1 FROM dbo.WarehouseSections)
    BEGIN
        INSERT dbo.WarehouseSections (SectionName, Description, Status)
        VALUES (N'Default Production', N'Default section for production batches and aggregate stock.', N'Active');
    END;

    IF COL_LENGTH(N'dbo.Users', N'PasswordResetTokenHash') IS NULL
        ALTER TABLE dbo.Users ADD PasswordResetTokenHash NVARCHAR(256) NULL;
    IF COL_LENGTH(N'dbo.Users', N'PasswordResetTokenExpiry') IS NULL
        ALTER TABLE dbo.Users ADD PasswordResetTokenExpiry DATETIME2 NULL;

    IF OBJECT_ID(N'dbo.Stocks', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.Stocks (
            StockId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Stocks PRIMARY KEY,
            ProductId INT NOT NULL,
            SectionId INT NOT NULL,
            QuantityAvailableKg DECIMAL(18,2) NOT NULL CONSTRAINT DF_Stocks_Quantity DEFAULT 0,
            ReorderLevelKg DECIMAL(18,2) NOT NULL CONSTRAINT DF_Stocks_Reorder DEFAULT 0,
            InventoryStatus NVARCHAR(40) NOT NULL CONSTRAINT DF_Stocks_Status DEFAULT N'Available'
        );
    END;

    /* Remove the earlier EF shadow column only after its foreign key and indexes are removed. */
    IF COL_LENGTH(N'dbo.Stocks', N'WarehouseSectionSectionId') IS NOT NULL
    BEGIN
        DECLARE @shadowFk SYSNAME;
        SELECT TOP (1) @shadowFk = fk.name
        FROM sys.foreign_keys fk
        JOIN sys.foreign_key_columns fkc ON fkc.constraint_object_id = fk.object_id
        JOIN sys.columns c ON c.object_id = fkc.parent_object_id AND c.column_id = fkc.parent_column_id
        WHERE fk.parent_object_id = OBJECT_ID(N'dbo.Stocks') AND c.name = N'WarehouseSectionSectionId';
        IF @shadowFk IS NOT NULL
        BEGIN
            DECLARE @dropShadowFkSql NVARCHAR(MAX) =
                N'ALTER TABLE dbo.Stocks DROP CONSTRAINT ' + QUOTENAME(@shadowFk) + N';';
            EXEC sys.sp_executesql @dropShadowFkSql;
        END;

        DECLARE @shadowIndex SYSNAME;
        WHILE EXISTS (
            SELECT 1 FROM sys.indexes i
            JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
            JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
            WHERE i.object_id = OBJECT_ID(N'dbo.Stocks') AND c.name = N'WarehouseSectionSectionId'
        )
        BEGIN
            SELECT TOP (1) @shadowIndex = i.name
            FROM sys.indexes i
            JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
            JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
            WHERE i.object_id = OBJECT_ID(N'dbo.Stocks') AND c.name = N'WarehouseSectionSectionId';
            DECLARE @dropShadowIndexSql NVARCHAR(MAX) =
                N'DROP INDEX ' + QUOTENAME(@shadowIndex) + N' ON dbo.Stocks;';
            EXEC sys.sp_executesql @dropShadowIndexSql;
        END;
        ALTER TABLE dbo.Stocks DROP COLUMN WarehouseSectionSectionId;
    END;

    IF OBJECT_ID(N'dbo.ProductBatches', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.ProductBatches (
            ProductBatchId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ProductBatches PRIMARY KEY,
            ProductId INT NOT NULL,
            SectionId INT NOT NULL,
            BatchCode NVARCHAR(64) NOT NULL,
            QRCodeValue NVARCHAR(500) NOT NULL,
            QuantityProducedKg DECIMAL(18,2) NOT NULL,
            QuantityRemainingKg DECIMAL(18,2) NOT NULL,
            PackedAtUtc DATETIME2 NOT NULL,
            OriginalExpiryAtUtc DATETIME2 NOT NULL,
            EffectiveExpiryAtUtc DATETIME2 NOT NULL,
            Status NVARCHAR(40) NOT NULL,
            ShelfLifeExtended BIT NOT NULL CONSTRAINT DF_ProductBatches_Extended DEFAULT 0,
            ShelfLifeExtendedAtUtc DATETIME2 NULL,
            ShelfLifeExtendedByUserId INT NULL,
            ShelfLifeExtensionReason NVARCHAR(500) NULL,
            YellowAlertSentAtUtc DATETIME2 NULL,
            RedAlertSentAtUtc DATETIME2 NULL,
            AvailableQuantityRemovedAtUtc DATETIME2 NULL,
            CreatedAtUtc DATETIME2 NOT NULL CONSTRAINT DF_ProductBatches_Created DEFAULT SYSUTCDATETIME(),
            UpdatedAtUtc DATETIME2 NULL,
            CONSTRAINT FK_ProductBatches_Product_ProductId FOREIGN KEY (ProductId) REFERENCES dbo.Product(ProductId),
            CONSTRAINT FK_ProductBatches_WarehouseSections_SectionId FOREIGN KEY (SectionId) REFERENCES dbo.WarehouseSections(SectionId),
            CONSTRAINT FK_ProductBatches_Users_ShelfLifeExtendedByUserId FOREIGN KEY (ShelfLifeExtendedByUserId) REFERENCES dbo.Users(UserId),
            CONSTRAINT CK_ProductBatches_Quantities CHECK (QuantityProducedKg > 0 AND QuantityRemainingKg >= 0 AND QuantityRemainingKg <= QuantityProducedKg),
            CONSTRAINT CK_ProductBatches_Expiry CHECK (OriginalExpiryAtUtc > PackedAtUtc AND EffectiveExpiryAtUtc > PackedAtUtc)
        );
    END;

    IF OBJECT_ID(N'dbo.StockMovements', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.StockMovements (
            StockMovementId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_StockMovements PRIMARY KEY,
            ProductId INT NOT NULL,
            ProductBatchId INT NOT NULL,
            SectionId INT NOT NULL,
            MovementType NVARCHAR(30) NOT NULL,
            QuantityKg DECIMAL(18,2) NOT NULL,
            OccurredAtUtc DATETIME2 NOT NULL,
            CreatedByUserId INT NULL,
            Reason NVARCHAR(500) NULL,
            CONSTRAINT FK_StockMovements_Product_ProductId FOREIGN KEY (ProductId) REFERENCES dbo.Product(ProductId),
            CONSTRAINT FK_StockMovements_ProductBatches_ProductBatchId FOREIGN KEY (ProductBatchId) REFERENCES dbo.ProductBatches(ProductBatchId),
            CONSTRAINT FK_StockMovements_WarehouseSections_SectionId FOREIGN KEY (SectionId) REFERENCES dbo.WarehouseSections(SectionId),
            CONSTRAINT FK_StockMovements_Users_CreatedByUserId FOREIGN KEY (CreatedByUserId) REFERENCES dbo.Users(UserId),
            CONSTRAINT CK_StockMovements_Quantity CHECK (QuantityKg > 0)
        );
    END;

    IF OBJECT_ID(N'dbo.ExpiryActionTokens', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.ExpiryActionTokens (
            ExpiryActionTokenId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ExpiryActionTokens PRIMARY KEY,
            ProductBatchId INT NOT NULL,
            TokenHash NVARCHAR(64) NOT NULL,
            AlertLevel NVARCHAR(30) NOT NULL,
            CreatedAtUtc DATETIME2 NOT NULL,
            ExpiresAtUtc DATETIME2 NOT NULL,
            UsedAtUtc DATETIME2 NULL,
            InvalidatedAtUtc DATETIME2 NULL,
            CONSTRAINT FK_ExpiryActionTokens_ProductBatches_ProductBatchId FOREIGN KEY (ProductBatchId) REFERENCES dbo.ProductBatches(ProductBatchId)
        );
    END;

    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Stocks_Product_ProductId')
        ALTER TABLE dbo.Stocks WITH CHECK ADD CONSTRAINT FK_Stocks_Product_ProductId FOREIGN KEY (ProductId) REFERENCES dbo.Product(ProductId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Stocks_WarehouseSections_SectionId')
        ALTER TABLE dbo.Stocks WITH CHECK ADD CONSTRAINT FK_Stocks_WarehouseSections_SectionId FOREIGN KEY (SectionId) REFERENCES dbo.WarehouseSections(SectionId);

    IF EXISTS (SELECT ProductName, ProductTypeId, ProductCategoryId, Size FROM dbo.Product GROUP BY ProductName, ProductTypeId, ProductCategoryId, Size HAVING COUNT(*) > 1)
        THROW 51001, 'Duplicate composite product SKUs must be resolved before creating UX_Product_CompositeSku.', 1;
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Product') AND name = N'UX_Product_CompositeSku')
        CREATE UNIQUE INDEX UX_Product_CompositeSku ON dbo.Product(ProductName, ProductTypeId, ProductCategoryId, Size);

    IF EXISTS (SELECT ProductTypeName FROM dbo.ProductType GROUP BY ProductTypeName HAVING COUNT(*) > 1)
        THROW 51002, 'Duplicate product type names must be resolved before creating UX_ProductType_Name.', 1;
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductType') AND name = N'UX_ProductType_Name')
        CREATE UNIQUE INDEX UX_ProductType_Name ON dbo.ProductType(ProductTypeName);

    IF EXISTS (SELECT ProductCategoryName FROM dbo.ProductCategory GROUP BY ProductCategoryName HAVING COUNT(*) > 1)
        THROW 51003, 'Duplicate product category names must be resolved before creating UX_ProductCategory_Name.', 1;
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductCategory') AND name = N'UX_ProductCategory_Name')
        CREATE UNIQUE INDEX UX_ProductCategory_Name ON dbo.ProductCategory(ProductCategoryName);

    IF EXISTS (SELECT ProductId, SectionId FROM dbo.Stocks GROUP BY ProductId, SectionId HAVING COUNT(*) > 1)
        THROW 51004, 'Duplicate aggregate stock rows must be resolved before creating UX_Stocks_Product_Section.', 1;
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Stocks') AND name = N'UX_Stocks_Product_Section')
        CREATE UNIQUE INDEX UX_Stocks_Product_Section ON dbo.Stocks(ProductId, SectionId);

    IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Stocks_Quantity_NonNegative')
        ALTER TABLE dbo.Stocks ADD CONSTRAINT CK_Stocks_Quantity_NonNegative CHECK (QuantityAvailableKg >= 0 AND ReorderLevelKg >= 0);

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductBatches') AND name = N'UX_ProductBatches_BatchCode')
        CREATE UNIQUE INDEX UX_ProductBatches_BatchCode ON dbo.ProductBatches(BatchCode);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductBatches') AND name = N'UX_ProductBatches_QRCodeValue')
        CREATE UNIQUE INDEX UX_ProductBatches_QRCodeValue ON dbo.ProductBatches(QRCodeValue);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductBatches') AND name = N'IX_ProductBatches_Status_Expiry_Quantity')
        CREATE INDEX IX_ProductBatches_Status_Expiry_Quantity ON dbo.ProductBatches(Status, EffectiveExpiryAtUtc, QuantityRemainingKg);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductBatches') AND name = N'IX_ProductBatches_Product_Section')
        CREATE INDEX IX_ProductBatches_Product_Section ON dbo.ProductBatches(ProductId, SectionId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.StockMovements') AND name = N'IX_StockMovements_Product_Section_Occurred')
        CREATE INDEX IX_StockMovements_Product_Section_Occurred ON dbo.StockMovements(ProductId, SectionId, OccurredAtUtc);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.StockMovements') AND name = N'IX_StockMovements_Batch')
        CREATE INDEX IX_StockMovements_Batch ON dbo.StockMovements(ProductBatchId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ExpiryActionTokens') AND name = N'UX_ExpiryActionTokens_TokenHash')
        CREATE UNIQUE INDEX UX_ExpiryActionTokens_TokenHash ON dbo.ExpiryActionTokens(TokenHash);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ExpiryActionTokens') AND name = N'IX_ExpiryActionTokens_Batch_State')
        CREATE INDEX IX_ExpiryActionTokens_Batch_State ON dbo.ExpiryActionTokens(ProductBatchId, ExpiresAtUtc, UsedAtUtc, InvalidatedAtUtc);

    COMMIT TRANSACTION;
    PRINT 'Subsystem 7 database deployment completed successfully.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
