SET XACT_ABORT ON;
BEGIN TRANSACTION;

IF COL_LENGTH('dbo.Roles', 'RoleCode') IS NULL
    ALTER TABLE dbo.Roles ADD RoleCode nvarchar(50) NULL;
IF COL_LENGTH('dbo.Roles', 'Description') IS NULL
    ALTER TABLE dbo.Roles ADD Description nvarchar(500) NULL;
IF COL_LENGTH('dbo.Roles', 'IsSystemRole') IS NULL
    ALTER TABLE dbo.Roles ADD IsSystemRole bit NOT NULL
        CONSTRAINT DF_Roles_IsSystemRole DEFAULT (0);
IF COL_LENGTH('dbo.Roles', 'IsActive') IS NULL
    ALTER TABLE dbo.Roles ADD IsActive bit NOT NULL
        CONSTRAINT DF_Roles_IsActive DEFAULT (1);
IF COL_LENGTH('dbo.Roles', 'CreatedAtUtc') IS NULL
    ALTER TABLE dbo.Roles ADD CreatedAtUtc datetime2 NOT NULL
        CONSTRAINT DF_Roles_CreatedAtUtc DEFAULT (SYSUTCDATETIME());
IF COL_LENGTH('dbo.Roles', 'UpdatedAtUtc') IS NULL
    ALTER TABLE dbo.Roles ADD UpdatedAtUtc datetime2 NULL;
IF COL_LENGTH('dbo.Roles', 'RowVersion') IS NULL
    ALTER TABLE dbo.Roles ADD RowVersion rowversion NOT NULL;
GO

UPDATE dbo.Roles
SET RoleCode = CASE
    WHEN RoleName = 'AdminClerk' THEN 'Admin'
    ELSE RoleName
END
WHERE RoleCode IS NULL OR LTRIM(RTRIM(RoleCode)) = '';

DECLARE @AdminRoleId int =
    (SELECT TOP (1) RoleId FROM dbo.Roles
     WHERE RoleName = 'Admin' OR RoleCode = 'Admin'
     ORDER BY CASE WHEN RoleName = 'Admin' THEN 0 ELSE 1 END, RoleId);
DECLARE @LegacyAdminRoleId int =
    (SELECT TOP (1) RoleId FROM dbo.Roles
     WHERE RoleName = 'AdminClerk' AND RoleId <> ISNULL(@AdminRoleId, -1)
     ORDER BY RoleId);

IF @AdminRoleId IS NULL
BEGIN
    SELECT TOP (1) @AdminRoleId = RoleId
    FROM dbo.Roles
    WHERE RoleName = 'AdminClerk'
    ORDER BY RoleId;

    UPDATE dbo.Roles
    SET RoleName = 'Admin',
        RoleCode = 'Admin',
        UpdatedAtUtc = SYSUTCDATETIME()
    WHERE RoleId = @AdminRoleId;
END
ELSE
BEGIN
    UPDATE dbo.Roles
    SET RoleName = 'Admin',
        RoleCode = 'Admin',
        UpdatedAtUtc = SYSUTCDATETIME()
    WHERE RoleId = @AdminRoleId;

    IF @LegacyAdminRoleId IS NOT NULL
    BEGIN
        UPDATE dbo.Users SET RoleId = @AdminRoleId
        WHERE RoleId = @LegacyAdminRoleId;

        INSERT INTO dbo.RolePermissions
            (RoleId, PermissionId)
        SELECT @AdminRoleId, legacy.PermissionId
        FROM dbo.RolePermissions legacy
        WHERE legacy.RoleId = @LegacyAdminRoleId
          AND NOT EXISTS (
              SELECT 1 FROM dbo.RolePermissions existing
              WHERE existing.RoleId = @AdminRoleId
                AND existing.PermissionId = legacy.PermissionId);

        DELETE FROM dbo.RolePermissions
        WHERE RoleId = @LegacyAdminRoleId;
        DELETE FROM dbo.Roles
        WHERE RoleId = @LegacyAdminRoleId;
    END
END

UPDATE dbo.Roles
SET RoleCode = RoleName
WHERE RoleCode IS NULL OR LTRIM(RTRIM(RoleCode)) = '';

ALTER TABLE dbo.Roles ALTER COLUMN RoleCode nvarchar(50) NOT NULL;
ALTER TABLE dbo.Roles ALTER COLUMN RoleName nvarchar(80) NOT NULL;

UPDATE dbo.Roles
SET IsSystemRole = CASE
    WHEN RoleCode IN
        ('Admin','Packer','Driver','WarehouseManager','CEO','COO','BusinessManager')
        THEN 1 ELSE IsSystemRole END,
    IsActive = 1;

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID('dbo.Roles')
      AND name = 'UX_Roles_RoleCode')
    CREATE UNIQUE INDEX UX_Roles_RoleCode ON dbo.Roles(RoleCode);
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID('dbo.Roles')
      AND name = 'UX_Roles_RoleName')
    CREATE UNIQUE INDEX UX_Roles_RoleName ON dbo.Roles(RoleName);

IF COL_LENGTH('dbo.Permissions', 'PermissionCode') IS NULL
    ALTER TABLE dbo.Permissions ADD PermissionCode nvarchar(100) NULL;
IF COL_LENGTH('dbo.Permissions', 'DisplayName') IS NULL
    ALTER TABLE dbo.Permissions ADD DisplayName nvarchar(120) NULL;
IF COL_LENGTH('dbo.Permissions', 'Module') IS NULL
    ALTER TABLE dbo.Permissions ADD Module nvarchar(80) NULL;
IF COL_LENGTH('dbo.Permissions', 'Description') IS NULL
    ALTER TABLE dbo.Permissions ADD Description nvarchar(500) NULL;
IF COL_LENGTH('dbo.Permissions', 'IsSystemPermission') IS NULL
    ALTER TABLE dbo.Permissions ADD IsSystemPermission bit NOT NULL
        CONSTRAINT DF_Permissions_IsSystemPermission DEFAULT (0);
IF COL_LENGTH('dbo.Permissions', 'IsActive') IS NULL
    ALTER TABLE dbo.Permissions ADD IsActive bit NOT NULL
        CONSTRAINT DF_Permissions_IsActive DEFAULT (1);
IF COL_LENGTH('dbo.Permissions', 'CreatedAtUtc') IS NULL
    ALTER TABLE dbo.Permissions ADD CreatedAtUtc datetime2 NOT NULL
        CONSTRAINT DF_Permissions_CreatedAtUtc DEFAULT (SYSUTCDATETIME());
IF COL_LENGTH('dbo.Permissions', 'UpdatedAtUtc') IS NULL
    ALTER TABLE dbo.Permissions ADD UpdatedAtUtc datetime2 NULL;
IF COL_LENGTH('dbo.Permissions', 'RowVersion') IS NULL
    ALTER TABLE dbo.Permissions ADD RowVersion rowversion NOT NULL;
GO

UPDATE dbo.Permissions
SET PermissionCode = ISNULL(NULLIF(PermissionCode, ''), PermissionName),
    DisplayName = ISNULL(NULLIF(DisplayName, ''), PermissionName),
    Module = ISNULL(NULLIF(Module, ''),
        CASE WHEN CHARINDEX('.', PermissionName) > 0
             THEN LEFT(PermissionName, CHARINDEX('.', PermissionName) - 1)
             ELSE 'General' END);

DECLARE @PermissionSeed TABLE
(
    PermissionCode nvarchar(100) NOT NULL,
    DisplayName nvarchar(120) NOT NULL,
    Module nvarchar(80) NOT NULL
);
INSERT INTO @PermissionSeed VALUES
('Users.View','View users','Security'),
('Users.Create','Create users','Security'),
('Users.Update','Update users','Security'),
('Users.Deactivate','Deactivate users','Security'),
('Users.Reactivate','Reactivate users','Security'),
('Users.AssignRole','Assign user roles','Security'),
('Users.TriggerPasswordReset','Trigger secure password reset','Security'),
('Users.ViewEffectivePermissions','View effective permissions','Security'),
('Roles.View','View roles','Security'),
('Roles.Create','Create roles','Security'),
('Roles.Update','Update roles','Security'),
('Roles.Deactivate','Deactivate roles','Security'),
('Roles.Delete','Delete unused custom roles','Security'),
('Roles.AssignPermissions','Assign role permissions','Security'),
('Permissions.View','View permission definitions','Security'),
('Permissions.Create','Create permission definitions','Security'),
('Permissions.Update','Update permission definitions','Security'),
('Permissions.Deactivate','Deactivate permission definitions','Security'),
('Permissions.Delete','Delete unused custom permissions','Security'),
('Products.View','View products','Product'),
('Products.Make','Make products','Product'),
('Products.Update','Update products','Product'),
('Products.Delete','Delete or deactivate products','Product'),
('Products.ChangeStatus','Change product status','Product'),
('ProductTypes.View','View product types','Product'),
('ProductTypes.Manage','Manage product types','Product'),
('ProductCategories.View','View product categories','Product'),
('ProductCategories.Manage','Manage product categories','Product'),
('Stock.View','View stock','Stock'),
('Stock.Take','Perform stock takes','Stock'),
('Stock.Adjust','Adjust stock','Stock'),
('Stock.WriteOff','Write off stock','Stock'),
('Expiry.View','View expiry information','Stock'),
('Expiry.Resolve','Resolve expiry alerts','Stock'),
('Labels.Print','Print product and batch labels','Product'),
('Customers.View','View customers','Orders'),
('Customers.Manage','Manage customers','Orders'),
('Suppliers.View','View suppliers','Suppliers'),
('Suppliers.Manage','Manage suppliers','Suppliers'),
('Orders.View','View orders','Orders'),
('Orders.Create','Create orders','Orders'),
('Orders.Update','Update orders','Orders'),
('Orders.Validate','Validate orders','Orders'),
('Orders.Confirm','Confirm orders','Orders'),
('Orders.Cancel','Cancel orders','Orders'),
('Orders.ChangeStatus','Change order status','Orders'),
('Orders.SendLink','Send customer order links','Orders'),
('Packing.View','View packing lists','Packing'),
('Packing.Confirm','Confirm packing','Packing'),
('Invoices.View','View invoices','Orders'),
('Payments.View','View payments','Payments'),
('Payments.Capture','Capture payments','Payments'),
('Payments.Confirm','Confirm payments','Payments'),
('Payments.Reverse','Reverse payments','Payments'),
('Pricing.View','View pricing','Pricing'),
('Pricing.Manage','Manage pricing','Pricing'),
('Deliveries.View','View deliveries','Delivery'),
('Deliveries.ViewOwn','View own deliveries','Delivery'),
('Deliveries.AssignDriver','Assign drivers','Delivery'),
('Deliveries.ReassignDriver','Reassign drivers','Delivery'),
('Deliveries.CompleteOwn','Complete own delivery','Delivery'),
('Deliveries.CompleteAny','Complete delivery on behalf','Delivery'),
('Deliveries.ViewProof','View proof of delivery','Delivery'),
('AuditLogs.View','View audit logs','Audit');

INSERT INTO dbo.Permissions
    (PermissionName, PermissionCode, DisplayName, Module,
     IsSystemPermission, IsActive, CreatedAtUtc)
SELECT seed.PermissionCode, seed.PermissionCode, seed.DisplayName, seed.Module,
       1, 1, SYSUTCDATETIME()
FROM @PermissionSeed seed
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.Permissions existing
    WHERE existing.PermissionCode = seed.PermissionCode
       OR existing.PermissionName = seed.PermissionCode);

UPDATE permission
SET permission.PermissionName = seed.PermissionCode,
    permission.PermissionCode = seed.PermissionCode,
    permission.DisplayName = seed.DisplayName,
    permission.Module = seed.Module,
    permission.IsSystemPermission = 1,
    permission.IsActive = 1
FROM dbo.Permissions permission
JOIN @PermissionSeed seed
  ON permission.PermissionCode = seed.PermissionCode
  OR permission.PermissionName = seed.PermissionCode;

ALTER TABLE dbo.Permissions
    ALTER COLUMN PermissionCode nvarchar(100) NOT NULL;
ALTER TABLE dbo.Permissions
    ALTER COLUMN PermissionName nvarchar(120) NOT NULL;
ALTER TABLE dbo.Permissions
    ALTER COLUMN DisplayName nvarchar(120) NOT NULL;
ALTER TABLE dbo.Permissions
    ALTER COLUMN Module nvarchar(80) NOT NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID('dbo.Permissions')
      AND name = 'UX_Permissions_PermissionCode')
    CREATE UNIQUE INDEX UX_Permissions_PermissionCode
        ON dbo.Permissions(PermissionCode);
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID('dbo.Permissions')
      AND name = 'IX_Permissions_Module_IsActive')
    CREATE INDEX IX_Permissions_Module_IsActive
        ON dbo.Permissions(Module, IsActive);

IF COL_LENGTH('dbo.Users', 'NormalizedEmail') IS NULL
    ALTER TABLE dbo.Users ADD NormalizedEmail nvarchar(100) NULL;
IF COL_LENGTH('dbo.Users', 'UpdatedAtUtc') IS NULL
    ALTER TABLE dbo.Users ADD UpdatedAtUtc datetime2 NULL;
IF COL_LENGTH('dbo.Users', 'SecurityVersion') IS NULL
    ALTER TABLE dbo.Users ADD SecurityVersion int NOT NULL
        CONSTRAINT DF_Users_SecurityVersion DEFAULT (1);
IF COL_LENGTH('dbo.Users', 'RowVersion') IS NULL
    ALTER TABLE dbo.Users ADD RowVersion rowversion NOT NULL;
GO

UPDATE dbo.Users
SET NormalizedEmail = UPPER(LTRIM(RTRIM(Email)))
WHERE NormalizedEmail IS NULL OR LTRIM(RTRIM(NormalizedEmail)) = '';

IF EXISTS (
    SELECT NormalizedEmail
    FROM dbo.Users
    GROUP BY NormalizedEmail
    HAVING COUNT(*) > 1)
    THROW 51001,
        'Duplicate user email addresses must be resolved before Phase A1 can create the unique email index.',
        1;

ALTER TABLE dbo.Users
    ALTER COLUMN NormalizedEmail nvarchar(100) NOT NULL;
ALTER TABLE dbo.Users
    ALTER COLUMN Status nvarchar(20) NOT NULL;
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID('dbo.Users')
      AND name = 'UX_Users_NormalizedEmail')
    CREATE UNIQUE INDEX UX_Users_NormalizedEmail
        ON dbo.Users(NormalizedEmail);
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID('dbo.Users')
      AND name = 'IX_Users_Status_RoleId')
    CREATE INDEX IX_Users_Status_RoleId
        ON dbo.Users(Status, RoleId);

IF COL_LENGTH('dbo.RolePermissions', 'AssignedAtUtc') IS NULL
    ALTER TABLE dbo.RolePermissions ADD AssignedAtUtc datetime2 NOT NULL
        CONSTRAINT DF_RolePermissions_AssignedAtUtc DEFAULT (SYSUTCDATETIME());
IF COL_LENGTH('dbo.RolePermissions', 'AssignedByUserId') IS NULL
    ALTER TABLE dbo.RolePermissions ADD AssignedByUserId int NULL;
GO
IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys
    WHERE parent_object_id = OBJECT_ID('dbo.RolePermissions')
      AND name = 'FK_RolePermissions_Users_AssignedByUserId')
    ALTER TABLE dbo.RolePermissions
        ADD CONSTRAINT FK_RolePermissions_Users_AssignedByUserId
        FOREIGN KEY (AssignedByUserId) REFERENCES dbo.Users(UserId);
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE object_id = OBJECT_ID('dbo.RolePermissions')
      AND name = 'IX_RolePermissions_AssignedByUserId')
    CREATE INDEX IX_RolePermissions_AssignedByUserId
        ON dbo.RolePermissions(AssignedByUserId);

INSERT INTO dbo.RolePermissions
    (RoleId, PermissionId, AssignedAtUtc)
SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
FROM dbo.Roles role
CROSS JOIN dbo.Permissions permission
WHERE role.RoleCode IN ('CEO','COO','BusinessManager')
  AND permission.IsActive = 1
  AND NOT EXISTS (
      SELECT 1 FROM dbo.RolePermissions mapping
      WHERE mapping.RoleId = role.RoleId
        AND mapping.PermissionId = permission.PermissionId);

DECLARE @OperationalAssignments TABLE
(
    RoleCode nvarchar(50) NOT NULL,
    PermissionCode nvarchar(100) NOT NULL
);
INSERT INTO @OperationalAssignments VALUES
('Admin','Products.View'),('Admin','Products.Make'),
('Admin','Products.Update'),('Admin','Products.Delete'),
('Admin','Products.ChangeStatus'),('Admin','ProductTypes.View'),
('Admin','ProductTypes.Manage'),('Admin','ProductCategories.View'),
('Admin','ProductCategories.Manage'),('Admin','Stock.View'),
('Admin','Expiry.View'),('Admin','Labels.Print'),
('Admin','Customers.View'),('Admin','Customers.Manage'),
('Admin','Suppliers.View'),('Admin','Suppliers.Manage'),
('Admin','Orders.View'),('Admin','Orders.Create'),
('Admin','Orders.Update'),('Admin','Orders.Validate'),
('Admin','Orders.Confirm'),('Admin','Orders.Cancel'),
('Admin','Orders.ChangeStatus'),('Admin','Orders.SendLink'),
('Admin','Packing.View'),('Admin','Invoices.View'),
('Admin','Payments.View'),('Admin','Payments.Capture'),
('Admin','Payments.Confirm'),('Admin','Pricing.View'),
('Admin','Pricing.Manage'),('Admin','Deliveries.View'),
('Admin','Deliveries.AssignDriver'),('Admin','Deliveries.ReassignDriver'),
('Admin','Deliveries.CompleteOwn'),('Admin','Deliveries.CompleteAny'),
('Admin','Deliveries.ViewProof'),
('Packer','Products.View'),('Packer','Products.Make'),
('Packer','Stock.View'),('Packer','Expiry.View'),
('Packer','Labels.Print'),('Packer','Orders.View'),
('Packer','Orders.ChangeStatus'),('Packer','Packing.View'),
('Packer','Packing.Confirm'),
('WarehouseManager','Products.View'),('WarehouseManager','Stock.View'),
('WarehouseManager','Stock.Take'),('WarehouseManager','Stock.Adjust'),
('WarehouseManager','Stock.WriteOff'),('WarehouseManager','Expiry.View'),
('WarehouseManager','Expiry.Resolve'),
('Driver','Deliveries.View'),('Driver','Deliveries.ViewOwn'),
('Driver','Deliveries.CompleteOwn'),('Driver','Deliveries.ViewProof');

INSERT INTO dbo.RolePermissions
    (RoleId, PermissionId, AssignedAtUtc)
SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
FROM @OperationalAssignments assignment
JOIN dbo.Roles role ON role.RoleCode = assignment.RoleCode
JOIN dbo.Permissions permission
  ON permission.PermissionCode = assignment.PermissionCode
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.RolePermissions mapping
    WHERE mapping.RoleId = role.RoleId
      AND mapping.PermissionId = permission.PermissionId);

COMMIT TRANSACTION;
