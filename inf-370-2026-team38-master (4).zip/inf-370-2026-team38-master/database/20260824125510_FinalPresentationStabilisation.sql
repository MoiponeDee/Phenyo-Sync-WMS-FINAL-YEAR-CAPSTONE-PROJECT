/*
    PhenyoSync final presentation Help content.

    This script is the idempotent deployment equivalent of:
    20260824125510_FinalPresentationStabilisation

    It does not alter application data outside the named Help records.
    Run it only after the preceding Iteration 5 and backup-permission migrations.
*/

SET XACT_ABORT ON;
GO

BEGIN TRY
    BEGIN TRANSACTION;

    IF EXISTS
    (
        SELECT 1
        FROM sys.identity_columns
        WHERE object_id = OBJECT_ID(N'dbo.HelpTopics')
          AND name = N'HelpTopicId'
    )
    BEGIN
        SET IDENTITY_INSERT dbo.HelpTopics ON;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.HelpTopics
        WHERE HelpTopicId = 38
    )
    BEGIN
        INSERT dbo.HelpTopics
        (
            HelpTopicId,
            HelpCategoryId,
            Slug,
            Title,
            Summary,
            BodyContent,
            Keywords,
            AudienceRolesCsv,
            IsPublic,
            IsPublished,
            SortOrder,
            CreatedAtUtc,
            UpdatedAtUtc,
            UpdatedByUserId
        )
        VALUES
        (
            38,
            3,
            N'product-production-lifecycle',
            N'Add, configure and make Products',
            N'Create a sellable Product, configure its Raw Stock recipe and produce traceable batches.',
            N'# Product creation and production
Open Product Hierarchy and select Add Product. Choose a compatible Category and Product Type, enter the pack Size, shelf life, initial selling price and status, then save. PhenyoSync prevents duplicate Product names within the same hierarchy and creates the first versioned price.

Select Configure Raw Stock Recipe after creation. A recipe describes the Raw Stock needed for one sellable Product unit. For example, one Granny Smith Apples 3 KG Product unit consumes 3 kg of Loose Granny Smith Apples. Make Product multiplies that recipe by the number of units and records Raw Stock movements and a traceable Product Batch.

Permanently delete only unused master data. If a Product, Customer, Supplier, Raw Stock item, Category or Type has operational history, PhenyoSync blocks deletion and offers deactivation so history remains intact.',
            N'add product hierarchy recipe make product unit price safe delete deactivate',
            N'OperationsManager,BusinessManager,Admin,WarehouseManager',
            0,
            1,
            60,
            '2026-07-24T00:00:00Z',
            NULL,
            NULL
        );
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.HelpTopics
        WHERE HelpTopicId = 39
    )
    BEGIN
        INSERT dbo.HelpTopics
        (
            HelpTopicId,
            HelpCategoryId,
            Slug,
            Title,
            Summary,
            BodyContent,
            Keywords,
            AudienceRolesCsv,
            IsPublic,
            IsPublished,
            SortOrder,
            CreatedAtUtc,
            UpdatedAtUtc,
            UpdatedByUserId
        )
        VALUES
        (
            39,
            7,
            N'mobile-scanning-and-tracking',
            N'Scan, track and complete deliveries',
            N'Use browser or mobile scanning, live foreground tracking and protected proof capture.',
            N'# Mobile scanning and delivery tracking
Packers can scan a Product Batch QR with the Android camera or a laptop webcam. If live scanning is unavailable, enter the printed code manually. The server always verifies the Product, batch, order, expiry, available quantity and duplicate-scan rules before progress changes.

Drivers start a dispatched delivery before sharing location. While the delivery page remains open, PhenyoSync sends a first browser or device location immediately and retries foreground updates at a controlled interval. The driver and authorised management maps show the latest timestamp, accuracy, stale state and route trail. For a presentation, browser developer tools may simulate movement; this is test evidence, not physical GPS evidence.

Take or select a delivery proof photo, wait for the successful upload message, name the recipient and confirm the handover before completing the delivery. Google Maps remains available for turn-by-turn navigation.',
            N'packing qr webcam manual scan driver location leaflet map simulated proof',
            N'OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer',
            0,
            1,
            70,
            '2026-07-24T00:00:00Z',
            NULL,
            NULL
        );
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.HelpTopics
        WHERE HelpTopicId = 40
    )
    BEGIN
        INSERT dbo.HelpTopics
        (
            HelpTopicId,
            HelpCategoryId,
            Slug,
            Title,
            Summary,
            BodyContent,
            Keywords,
            AudienceRolesCsv,
            IsPublic,
            IsPublished,
            SortOrder,
            CreatedAtUtc,
            UpdatedAtUtc,
            UpdatedByUserId
        )
        VALUES
        (
            40,
            4,
            N'offline-data-exchange',
            N'Controlled offline data exchange',
            N'Use the correct controlled offline file workflow for Products, Prices and stock counts.',
            N'# Controlled offline data exchange
Product and Price offline work uses Excel only. Download the current workbook, preserve its template version, validate it, review the staged rows and confirm the exact validated import. Stocktake offline work uses the dedicated JSON package; it contains operational count fields and excludes prices, costs and normal user-facing internal identifiers.',
            N'excel product price stocktake json offline validate import export',
            N'OperationsManager,BusinessManager,Admin,WarehouseManager',
            0,
            1,
            80,
            '2026-07-24T00:00:00Z',
            NULL,
            NULL
        );
    END;

    IF EXISTS
    (
        SELECT 1
        FROM sys.identity_columns
        WHERE object_id = OBJECT_ID(N'dbo.HelpTopics')
          AND name = N'HelpTopicId'
    )
    BEGIN
        SET IDENTITY_INSERT dbo.HelpTopics OFF;
    END;

    DECLARE @ContextMappings TABLE
    (
        HelpContextMappingId int NOT NULL,
        HelpTopicId int NOT NULL,
        RoutePattern nvarchar(256) NOT NULL,
        ComponentKey nvarchar(128) NOT NULL
    );

    INSERT @ContextMappings
    (
        HelpContextMappingId,
        HelpTopicId,
        RoutePattern,
        ComponentKey
    )
    VALUES
        (44, 38, N'/product-hierarchy', N'ProductHierarchy'),
        (46, 39, N'/scan-product-batch', N'ProductBatchScanner'),
        (47, 39, N'/mobile-operations-control', N'MobileOperationsControl'),
        (49, 40, N'/stock-count-data-exchange', N'StockCountDataExchange');

    IF EXISTS
    (
        SELECT 1
        FROM sys.identity_columns
        WHERE object_id = OBJECT_ID(N'dbo.HelpContextMappings')
          AND name = N'HelpContextMappingId'
    )
    BEGIN
        SET IDENTITY_INSERT dbo.HelpContextMappings ON;
    END;

    INSERT dbo.HelpContextMappings
    (
        HelpContextMappingId,
        HelpTopicId,
        RoutePattern,
        ComponentKey,
        Priority,
        IsActive
    )
    SELECT
        source.HelpContextMappingId,
        source.HelpTopicId,
        source.RoutePattern,
        source.ComponentKey,
        100,
        1
    FROM @ContextMappings AS source
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.HelpContextMappings AS existing
        WHERE existing.HelpContextMappingId = source.HelpContextMappingId
           OR
           (
               existing.RoutePattern = source.RoutePattern
               AND existing.ComponentKey = source.ComponentKey
           )
    );

    IF EXISTS
    (
        SELECT 1
        FROM sys.identity_columns
        WHERE object_id = OBJECT_ID(N'dbo.HelpContextMappings')
          AND name = N'HelpContextMappingId'
    )
    BEGIN
        SET IDENTITY_INSERT dbo.HelpContextMappings OFF;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.__EFMigrationsHistory
        WHERE MigrationId = N'20260824125510_FinalPresentationStabilisation'
    )
    BEGIN
        INSERT dbo.__EFMigrationsHistory
        (
            MigrationId,
            ProductVersion
        )
        VALUES
        (
            N'20260824125510_FinalPresentationStabilisation',
            N'8.0.0'
        );
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;
END CATCH;
GO
