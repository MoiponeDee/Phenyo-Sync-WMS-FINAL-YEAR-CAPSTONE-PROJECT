/*
  PhenyoSync WMS - INF370 Subsystem 15 Logistics and Delivery
  Safe, additive, idempotent deployment for existing WMS_DB installations.
  Existing users, drivers, orders, stock, invoices, audit logs, and history
  are preserved. Run this script only after Subsystems 7, 10, 11, and 14.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.Deliveries', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.Deliveries (
            DeliveryId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Deliveries PRIMARY KEY,
            SalesOrderId INT NOT NULL,
            DeliveryAddressSnapshot NVARCHAR(500) NOT NULL,
            ScheduledStartUtc DATETIME2 NOT NULL,
            ScheduledEndUtc DATETIME2 NOT NULL,
            DriverId INT NULL,
            Status NVARCHAR(30) NOT NULL,
            AssignedAtUtc DATETIME2 NULL,
            AssignedByUserId INT NULL,
            StartedAtUtc DATETIME2 NULL,
            StartedByUserId INT NULL,
            CompletedAtUtc DATETIME2 NULL,
            CompletedByUserId INT NULL,
            CreatedAtUtc DATETIME2 NOT NULL,
            UpdatedAtUtc DATETIME2 NULL,
            RowVersion ROWVERSION NULL,
            CONSTRAINT CK_Deliveries_ScheduleWindow CHECK (ScheduledEndUtc > ScheduledStartUtc),
            CONSTRAINT CK_Deliveries_Status CHECK
                (Status IN ('Scheduled','Assigned','InTransit','Completed','Cancelled')),
            CONSTRAINT FK_Deliveries_SalesOrders_SalesOrderId
                FOREIGN KEY (SalesOrderId) REFERENCES dbo.SalesOrders(SalesOrderId),
            CONSTRAINT FK_Deliveries_Drivers_DriverId
                FOREIGN KEY (DriverId) REFERENCES dbo.Drivers(DriverId),
            CONSTRAINT FK_Deliveries_Users_AssignedByUserId
                FOREIGN KEY (AssignedByUserId) REFERENCES dbo.Users(UserId),
            CONSTRAINT FK_Deliveries_Users_StartedByUserId
                FOREIGN KEY (StartedByUserId) REFERENCES dbo.Users(UserId),
            CONSTRAINT FK_Deliveries_Users_CompletedByUserId
                FOREIGN KEY (CompletedByUserId) REFERENCES dbo.Users(UserId)
        );
    END;

    IF OBJECT_ID(N'dbo.DeliveryDriverAssignments', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.DeliveryDriverAssignments (
            DeliveryDriverAssignmentId BIGINT IDENTITY(1,1) NOT NULL
                CONSTRAINT PK_DeliveryDriverAssignments PRIMARY KEY,
            DeliveryId INT NOT NULL,
            DriverId INT NOT NULL,
            AssignedAtUtc DATETIME2 NOT NULL,
            AssignedByUserId INT NULL,
            UnassignedAtUtc DATETIME2 NULL,
            UnassignedByUserId INT NULL,
            AssignmentNotes NVARCHAR(500) NULL,
            ReassignmentReason NVARCHAR(500) NULL,
            IsCurrent BIT NOT NULL,
            CreatedAtUtc DATETIME2 NOT NULL,
            CONSTRAINT FK_DeliveryDriverAssignments_Deliveries_DeliveryId
                FOREIGN KEY (DeliveryId) REFERENCES dbo.Deliveries(DeliveryId),
            CONSTRAINT FK_DeliveryDriverAssignments_Drivers_DriverId
                FOREIGN KEY (DriverId) REFERENCES dbo.Drivers(DriverId),
            CONSTRAINT FK_DeliveryDriverAssignments_Users_AssignedByUserId
                FOREIGN KEY (AssignedByUserId) REFERENCES dbo.Users(UserId),
            CONSTRAINT FK_DeliveryDriverAssignments_Users_UnassignedByUserId
                FOREIGN KEY (UnassignedByUserId) REFERENCES dbo.Users(UserId)
        );
    END;

    IF OBJECT_ID(N'dbo.DeliveryStatusHistory', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.DeliveryStatusHistory (
            DeliveryStatusHistoryId BIGINT IDENTITY(1,1) NOT NULL
                CONSTRAINT PK_DeliveryStatusHistory PRIMARY KEY,
            DeliveryId INT NOT NULL,
            PreviousStatus NVARCHAR(30) NULL,
            NewStatus NVARCHAR(30) NOT NULL,
            ChangedAtUtc DATETIME2 NOT NULL,
            ChangedByUserId INT NULL,
            Reason NVARCHAR(500) NULL,
            Source NVARCHAR(80) NOT NULL,
            CONSTRAINT FK_DeliveryStatusHistory_Deliveries_DeliveryId
                FOREIGN KEY (DeliveryId) REFERENCES dbo.Deliveries(DeliveryId),
            CONSTRAINT FK_DeliveryStatusHistory_Users_ChangedByUserId
                FOREIGN KEY (ChangedByUserId) REFERENCES dbo.Users(UserId)
        );
    END;

    IF OBJECT_ID(N'dbo.DeliveryCompletionRecords', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.DeliveryCompletionRecords (
            DeliveryCompletionRecordId BIGINT IDENTITY(1,1) NOT NULL
                CONSTRAINT PK_DeliveryCompletionRecords PRIMARY KEY,
            DeliveryId INT NOT NULL,
            CompletedAtUtc DATETIME2 NOT NULL,
            CompletedByUserId INT NULL,
            CompletedByDriverId INT NULL,
            CompletedOnBehalfOfDriver BIT NOT NULL,
            ManagementOverrideReason NVARCHAR(500) NULL,
            RecipientName NVARCHAR(200) NOT NULL,
            RecipientConfirmed BIT NOT NULL,
            FulfillmentConfirmed BIT NOT NULL,
            Notes NVARCHAR(1000) NULL,
            ProofReference NVARCHAR(500) NULL,
            CreatedAtUtc DATETIME2 NOT NULL,
            CONSTRAINT FK_DeliveryCompletionRecords_Deliveries_DeliveryId
                FOREIGN KEY (DeliveryId) REFERENCES dbo.Deliveries(DeliveryId),
            CONSTRAINT FK_DeliveryCompletionRecords_Users_CompletedByUserId
                FOREIGN KEY (CompletedByUserId) REFERENCES dbo.Users(UserId),
            CONSTRAINT FK_DeliveryCompletionRecords_Drivers_CompletedByDriverId
                FOREIGN KEY (CompletedByDriverId) REFERENCES dbo.Drivers(DriverId)
        );
    END;

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Deliveries') AND name = N'UX_Deliveries_SalesOrderId')
        CREATE UNIQUE INDEX UX_Deliveries_SalesOrderId ON dbo.Deliveries(SalesOrderId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Deliveries') AND name = N'IX_Deliveries_Status')
        CREATE INDEX IX_Deliveries_Status ON dbo.Deliveries(Status);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Deliveries') AND name = N'IX_Deliveries_ScheduledStartUtc')
        CREATE INDEX IX_Deliveries_ScheduledStartUtc ON dbo.Deliveries(ScheduledStartUtc);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Deliveries') AND name = N'IX_Deliveries_ScheduledEndUtc')
        CREATE INDEX IX_Deliveries_ScheduledEndUtc ON dbo.Deliveries(ScheduledEndUtc);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Deliveries') AND name = N'IX_Deliveries_Driver_Window')
        CREATE INDEX IX_Deliveries_Driver_Window
            ON dbo.Deliveries(DriverId, Status, ScheduledStartUtc, ScheduledEndUtc);

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.DeliveryDriverAssignments') AND name = N'UX_DeliveryDriverAssignments_Current')
        CREATE UNIQUE INDEX UX_DeliveryDriverAssignments_Current
            ON dbo.DeliveryDriverAssignments(DeliveryId, IsCurrent)
            WHERE IsCurrent = 1;
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.DeliveryDriverAssignments') AND name = N'IX_DeliveryDriverAssignments_DriverId_IsCurrent_AssignedAtUtc')
        CREATE INDEX IX_DeliveryDriverAssignments_DriverId_IsCurrent_AssignedAtUtc
            ON dbo.DeliveryDriverAssignments(DriverId, IsCurrent, AssignedAtUtc);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.DeliveryStatusHistory') AND name = N'IX_DeliveryStatusHistory_DeliveryId_ChangedAtUtc')
        CREATE INDEX IX_DeliveryStatusHistory_DeliveryId_ChangedAtUtc
            ON dbo.DeliveryStatusHistory(DeliveryId, ChangedAtUtc);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.DeliveryCompletionRecords') AND name = N'UX_DeliveryCompletionRecords_DeliveryId')
        CREATE UNIQUE INDEX UX_DeliveryCompletionRecords_DeliveryId
            ON dbo.DeliveryCompletionRecords(DeliveryId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.DeliveryCompletionRecords') AND name = N'IX_DeliveryCompletionRecords_CompletedAtUtc')
        CREATE INDEX IX_DeliveryCompletionRecords_CompletedAtUtc
            ON dbo.DeliveryCompletionRecords(CompletedAtUtc);

    IF EXISTS (
        SELECT 1 FROM sys.columns
        WHERE object_id = OBJECT_ID(N'dbo.Drivers')
          AND name = N'AvailabilityStatus'
          AND max_length = -1
    )
    BEGIN
        IF EXISTS (SELECT 1 FROM dbo.Drivers WHERE LEN(AvailabilityStatus) > 100)
            THROW 51015, 'Driver AvailabilityStatus values exceed the safe 100-character migration limit.', 1;
        ALTER TABLE dbo.Drivers ALTER COLUMN AvailabilityStatus NVARCHAR(100) NOT NULL;
    END;
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Drivers') AND name = N'IX_Drivers_AvailabilityStatus')
        CREATE INDEX IX_Drivers_AvailabilityStatus ON dbo.Drivers(AvailabilityStatus);

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
