/*
  PhenyoSync WMS - INF370 Subsystem 10 Order Management
  Safe, additive, idempotent deployment for existing WMS_DB installations.
  The script never drops or recreates existing Product, Stock, User,
  SupplierOrder, Subsystem 7 batch, or operational history tables.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    IF COL_LENGTH(N'dbo.Product', N'SellingPricePerKg') IS NULL
        ALTER TABLE dbo.Product ADD SellingPricePerKg DECIMAL(18,2) NOT NULL
            CONSTRAINT DF_Product_SellingPricePerKg DEFAULT (0);

    IF COL_LENGTH(N'dbo.Stocks', N'RowVersion') IS NULL
        ALTER TABLE dbo.Stocks ADD RowVersion ROWVERSION NULL;

    IF COL_LENGTH(N'dbo.StockMovements', N'SalesOrderId') IS NULL
        ALTER TABLE dbo.StockMovements ADD SalesOrderId INT NULL;

    IF OBJECT_ID(N'dbo.Customers', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.Customers (
            CustomerId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Customers PRIMARY KEY,
            CustomerNumber NVARCHAR(30) NOT NULL,
            CustomerName NVARCHAR(150) NOT NULL,
            Email NVARCHAR(254) NOT NULL,
            PhoneNumber NVARCHAR(30) NULL,
            BillingAddress NVARCHAR(500) NULL,
            DeliveryAddress NVARCHAR(500) NULL,
            Status NVARCHAR(20) NOT NULL,
            CreatedAtUtc DATETIME2 NOT NULL,
            UpdatedAtUtc DATETIME2 NULL
        );
    END;

    IF OBJECT_ID(N'dbo.CustomerOrderLinks', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.CustomerOrderLinks (
            CustomerOrderLinkId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CustomerOrderLinks PRIMARY KEY,
            CustomerId INT NOT NULL,
            TokenHash NVARCHAR(64) NOT NULL,
            CreatedByUserId INT NOT NULL,
            CreatedAtUtc DATETIME2 NOT NULL,
            ExpiresAtUtc DATETIME2 NOT NULL,
            UsedAtUtc DATETIME2 NULL,
            RevokedAtUtc DATETIME2 NULL,
            SalesOrderId INT NULL,
            EmailSentAtUtc DATETIME2 NULL
        );
    END;

    IF OBJECT_ID(N'dbo.SalesOrders', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.SalesOrders (
            SalesOrderId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SalesOrders PRIMARY KEY,
            OrderNumber NVARCHAR(30) NOT NULL,
            CustomerId INT NOT NULL,
            OrderDateUtc DATETIME2 NOT NULL,
            RequestedDeliveryDateUtc DATETIME2 NULL,
            DeliveryAddressSnapshot NVARCHAR(500) NOT NULL,
            BillingAddressSnapshot NVARCHAR(500) NOT NULL,
            Status NVARCHAR(30) NOT NULL,
            ValidationStatus NVARCHAR(20) NOT NULL,
            ValidationMessage NVARCHAR(1000) NULL,
            Subtotal DECIMAL(18,2) NOT NULL,
            TaxAmount DECIMAL(18,2) NOT NULL,
            TotalAmount DECIMAL(18,2) NOT NULL,
            Notes NVARCHAR(1000) NULL,
            CreatedByUserId INT NULL,
            CreatedViaOrderLinkId BIGINT NULL,
            ValidatedByUserId INT NULL,
            ValidatedAtUtc DATETIME2 NULL,
            PackedByUserId INT NULL,
            PackedAtUtc DATETIME2 NULL,
            CancelledByUserId INT NULL,
            CancelledAtUtc DATETIME2 NULL,
            CancellationReason NVARCHAR(500) NULL,
            CreatedAtUtc DATETIME2 NOT NULL,
            UpdatedAtUtc DATETIME2 NULL,
            RowVersion ROWVERSION NULL
        );
    END;

    IF OBJECT_ID(N'dbo.Invoices', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.Invoices (
            InvoiceId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Invoices PRIMARY KEY,
            InvoiceNumber NVARCHAR(30) NOT NULL,
            SalesOrderId INT NOT NULL,
            IssuedAtUtc DATETIME2 NOT NULL,
            CustomerNameSnapshot NVARCHAR(150) NOT NULL,
            CustomerEmailSnapshot NVARCHAR(254) NOT NULL,
            BillingAddressSnapshot NVARCHAR(500) NOT NULL,
            Subtotal DECIMAL(18,2) NOT NULL,
            TaxAmount DECIMAL(18,2) NOT NULL,
            TotalAmount DECIMAL(18,2) NOT NULL,
            Status NVARCHAR(20) NOT NULL
        );
    END;

    IF OBJECT_ID(N'dbo.OrderStatusHistory', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.OrderStatusHistory (
            OrderStatusHistoryId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderStatusHistory PRIMARY KEY,
            SalesOrderId INT NOT NULL,
            PreviousStatus NVARCHAR(30) NULL,
            NewStatus NVARCHAR(30) NOT NULL,
            ChangedByUserId INT NULL,
            ChangedAtUtc DATETIME2 NOT NULL,
            Reason NVARCHAR(500) NULL
        );
    END;

    IF OBJECT_ID(N'dbo.SalesOrderItems', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.SalesOrderItems (
            SalesOrderItemId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SalesOrderItems PRIMARY KEY,
            SalesOrderId INT NOT NULL,
            ProductId INT NOT NULL,
            ProductNameSnapshot NVARCHAR(150) NOT NULL,
            ProductSizeSnapshot NVARCHAR(50) NOT NULL,
            QuantityKg DECIMAL(18,2) NOT NULL,
            UnitPricePerKg DECIMAL(18,2) NOT NULL,
            LineTotal DECIMAL(18,2) NOT NULL,
            IsActive BIT NOT NULL,
            Notes NVARCHAR(500) NULL
        );
    END;

    IF OBJECT_ID(N'dbo.OrderStockReservations', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.OrderStockReservations (
            OrderStockReservationId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderStockReservations PRIMARY KEY,
            SalesOrderId INT NOT NULL,
            SalesOrderItemId INT NOT NULL,
            ProductId INT NOT NULL,
            StockId INT NOT NULL,
            SectionId INT NOT NULL,
            ProductBatchId INT NOT NULL,
            QuantityReservedKg DECIMAL(18,2) NOT NULL,
            Status NVARCHAR(20) NOT NULL,
            ReservedAtUtc DATETIME2 NOT NULL,
            ReleasedAtUtc DATETIME2 NULL,
            ConsumedAtUtc DATETIME2 NULL
        );
    END;

    /* Relationships are added separately so the circular link/order pair is safe. */
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_CustomerOrderLinks_Customers_CustomerId')
        ALTER TABLE dbo.CustomerOrderLinks WITH CHECK ADD CONSTRAINT FK_CustomerOrderLinks_Customers_CustomerId
            FOREIGN KEY (CustomerId) REFERENCES dbo.Customers(CustomerId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_CustomerOrderLinks_Users_CreatedByUserId')
        ALTER TABLE dbo.CustomerOrderLinks WITH CHECK ADD CONSTRAINT FK_CustomerOrderLinks_Users_CreatedByUserId
            FOREIGN KEY (CreatedByUserId) REFERENCES dbo.Users(UserId);

    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SalesOrders_Customers_CustomerId')
        ALTER TABLE dbo.SalesOrders WITH CHECK ADD CONSTRAINT FK_SalesOrders_Customers_CustomerId
            FOREIGN KEY (CustomerId) REFERENCES dbo.Customers(CustomerId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SalesOrders_CustomerOrderLinks_CreatedViaOrderLinkId')
        ALTER TABLE dbo.SalesOrders WITH CHECK ADD CONSTRAINT FK_SalesOrders_CustomerOrderLinks_CreatedViaOrderLinkId
            FOREIGN KEY (CreatedViaOrderLinkId) REFERENCES dbo.CustomerOrderLinks(CustomerOrderLinkId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SalesOrders_Users_CreatedByUserId')
        ALTER TABLE dbo.SalesOrders WITH CHECK ADD CONSTRAINT FK_SalesOrders_Users_CreatedByUserId
            FOREIGN KEY (CreatedByUserId) REFERENCES dbo.Users(UserId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SalesOrders_Users_ValidatedByUserId')
        ALTER TABLE dbo.SalesOrders WITH CHECK ADD CONSTRAINT FK_SalesOrders_Users_ValidatedByUserId
            FOREIGN KEY (ValidatedByUserId) REFERENCES dbo.Users(UserId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SalesOrders_Users_PackedByUserId')
        ALTER TABLE dbo.SalesOrders WITH CHECK ADD CONSTRAINT FK_SalesOrders_Users_PackedByUserId
            FOREIGN KEY (PackedByUserId) REFERENCES dbo.Users(UserId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SalesOrders_Users_CancelledByUserId')
        ALTER TABLE dbo.SalesOrders WITH CHECK ADD CONSTRAINT FK_SalesOrders_Users_CancelledByUserId
            FOREIGN KEY (CancelledByUserId) REFERENCES dbo.Users(UserId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_CustomerOrderLinks_SalesOrders_SalesOrderId')
        ALTER TABLE dbo.CustomerOrderLinks WITH CHECK ADD CONSTRAINT FK_CustomerOrderLinks_SalesOrders_SalesOrderId
            FOREIGN KEY (SalesOrderId) REFERENCES dbo.SalesOrders(SalesOrderId);

    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Invoices_SalesOrders_SalesOrderId')
        ALTER TABLE dbo.Invoices WITH CHECK ADD CONSTRAINT FK_Invoices_SalesOrders_SalesOrderId
            FOREIGN KEY (SalesOrderId) REFERENCES dbo.SalesOrders(SalesOrderId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_OrderStatusHistory_SalesOrders_SalesOrderId')
        ALTER TABLE dbo.OrderStatusHistory WITH CHECK ADD CONSTRAINT FK_OrderStatusHistory_SalesOrders_SalesOrderId
            FOREIGN KEY (SalesOrderId) REFERENCES dbo.SalesOrders(SalesOrderId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_OrderStatusHistory_Users_ChangedByUserId')
        ALTER TABLE dbo.OrderStatusHistory WITH CHECK ADD CONSTRAINT FK_OrderStatusHistory_Users_ChangedByUserId
            FOREIGN KEY (ChangedByUserId) REFERENCES dbo.Users(UserId);

    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SalesOrderItems_SalesOrders_SalesOrderId')
        ALTER TABLE dbo.SalesOrderItems WITH CHECK ADD CONSTRAINT FK_SalesOrderItems_SalesOrders_SalesOrderId
            FOREIGN KEY (SalesOrderId) REFERENCES dbo.SalesOrders(SalesOrderId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_SalesOrderItems_Product_ProductId')
        ALTER TABLE dbo.SalesOrderItems WITH CHECK ADD CONSTRAINT FK_SalesOrderItems_Product_ProductId
            FOREIGN KEY (ProductId) REFERENCES dbo.Product(ProductId);

    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_OrderStockReservations_SalesOrders_SalesOrderId')
        ALTER TABLE dbo.OrderStockReservations WITH CHECK ADD CONSTRAINT FK_OrderStockReservations_SalesOrders_SalesOrderId
            FOREIGN KEY (SalesOrderId) REFERENCES dbo.SalesOrders(SalesOrderId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_OrderStockReservations_SalesOrderItems_SalesOrderItemId')
        ALTER TABLE dbo.OrderStockReservations WITH CHECK ADD CONSTRAINT FK_OrderStockReservations_SalesOrderItems_SalesOrderItemId
            FOREIGN KEY (SalesOrderItemId) REFERENCES dbo.SalesOrderItems(SalesOrderItemId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_OrderStockReservations_Product_ProductId')
        ALTER TABLE dbo.OrderStockReservations WITH CHECK ADD CONSTRAINT FK_OrderStockReservations_Product_ProductId
            FOREIGN KEY (ProductId) REFERENCES dbo.Product(ProductId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_OrderStockReservations_Stocks_StockId')
        ALTER TABLE dbo.OrderStockReservations WITH CHECK ADD CONSTRAINT FK_OrderStockReservations_Stocks_StockId
            FOREIGN KEY (StockId) REFERENCES dbo.Stocks(StockId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_OrderStockReservations_WarehouseSections_SectionId')
        ALTER TABLE dbo.OrderStockReservations WITH CHECK ADD CONSTRAINT FK_OrderStockReservations_WarehouseSections_SectionId
            FOREIGN KEY (SectionId) REFERENCES dbo.WarehouseSections(SectionId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_OrderStockReservations_ProductBatches_ProductBatchId')
        ALTER TABLE dbo.OrderStockReservations WITH CHECK ADD CONSTRAINT FK_OrderStockReservations_ProductBatches_ProductBatchId
            FOREIGN KEY (ProductBatchId) REFERENCES dbo.ProductBatches(ProductBatchId);
    IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_StockMovements_SalesOrders_SalesOrderId')
        ALTER TABLE dbo.StockMovements WITH CHECK ADD CONSTRAINT FK_StockMovements_SalesOrders_SalesOrderId
            FOREIGN KEY (SalesOrderId) REFERENCES dbo.SalesOrders(SalesOrderId);

    /* Required uniqueness and operational query indexes. */
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Customers') AND name = N'IX_Customers_CustomerNumber')
        CREATE UNIQUE INDEX IX_Customers_CustomerNumber ON dbo.Customers(CustomerNumber);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Customers') AND name = N'IX_Customers_Email')
        CREATE INDEX IX_Customers_Email ON dbo.Customers(Email);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Customers') AND name = N'IX_Customers_Status_CustomerName')
        CREATE INDEX IX_Customers_Status_CustomerName ON dbo.Customers(Status, CustomerName);

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.CustomerOrderLinks') AND name = N'IX_CustomerOrderLinks_TokenHash')
        CREATE UNIQUE INDEX IX_CustomerOrderLinks_TokenHash ON dbo.CustomerOrderLinks(TokenHash);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.CustomerOrderLinks') AND name = N'IX_CustomerOrderLinks_ExpiresAtUtc')
        CREATE INDEX IX_CustomerOrderLinks_ExpiresAtUtc ON dbo.CustomerOrderLinks(ExpiresAtUtc);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.CustomerOrderLinks') AND name = N'IX_CustomerOrderLinks_CustomerId_CreatedAtUtc')
        CREATE INDEX IX_CustomerOrderLinks_CustomerId_CreatedAtUtc ON dbo.CustomerOrderLinks(CustomerId, CreatedAtUtc);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.CustomerOrderLinks') AND name = N'IX_CustomerOrderLinks_CreatedByUserId')
        CREATE INDEX IX_CustomerOrderLinks_CreatedByUserId ON dbo.CustomerOrderLinks(CreatedByUserId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.CustomerOrderLinks') AND name = N'IX_CustomerOrderLinks_SalesOrderId')
        CREATE UNIQUE INDEX IX_CustomerOrderLinks_SalesOrderId ON dbo.CustomerOrderLinks(SalesOrderId) WHERE SalesOrderId IS NOT NULL;

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_OrderNumber')
        CREATE UNIQUE INDEX IX_SalesOrders_OrderNumber ON dbo.SalesOrders(OrderNumber);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_CustomerId')
        CREATE INDEX IX_SalesOrders_CustomerId ON dbo.SalesOrders(CustomerId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_Status')
        CREATE INDEX IX_SalesOrders_Status ON dbo.SalesOrders(Status);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_ValidationStatus')
        CREATE INDEX IX_SalesOrders_ValidationStatus ON dbo.SalesOrders(ValidationStatus);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_OrderDateUtc')
        CREATE INDEX IX_SalesOrders_OrderDateUtc ON dbo.SalesOrders(OrderDateUtc);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_CreatedViaOrderLinkId')
        CREATE INDEX IX_SalesOrders_CreatedViaOrderLinkId ON dbo.SalesOrders(CreatedViaOrderLinkId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_CreatedByUserId')
        CREATE INDEX IX_SalesOrders_CreatedByUserId ON dbo.SalesOrders(CreatedByUserId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_ValidatedByUserId')
        CREATE INDEX IX_SalesOrders_ValidatedByUserId ON dbo.SalesOrders(ValidatedByUserId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_PackedByUserId')
        CREATE INDEX IX_SalesOrders_PackedByUserId ON dbo.SalesOrders(PackedByUserId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrders') AND name = N'IX_SalesOrders_CancelledByUserId')
        CREATE INDEX IX_SalesOrders_CancelledByUserId ON dbo.SalesOrders(CancelledByUserId);

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrderItems') AND name = N'IX_SalesOrderItems_ProductId')
        CREATE INDEX IX_SalesOrderItems_ProductId ON dbo.SalesOrderItems(ProductId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.SalesOrderItems') AND name = N'IX_SalesOrderItems_SalesOrderId_ProductId')
        CREATE UNIQUE INDEX IX_SalesOrderItems_SalesOrderId_ProductId
            ON dbo.SalesOrderItems(SalesOrderId, ProductId) WHERE IsActive = 1;

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Invoices') AND name = N'IX_Invoices_InvoiceNumber')
        CREATE UNIQUE INDEX IX_Invoices_InvoiceNumber ON dbo.Invoices(InvoiceNumber);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Invoices') AND name = N'IX_Invoices_SalesOrderId')
        CREATE UNIQUE INDEX IX_Invoices_SalesOrderId ON dbo.Invoices(SalesOrderId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.OrderStatusHistory') AND name = N'IX_OrderStatusHistory_SalesOrderId_ChangedAtUtc')
        CREATE INDEX IX_OrderStatusHistory_SalesOrderId_ChangedAtUtc ON dbo.OrderStatusHistory(SalesOrderId, ChangedAtUtc);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.OrderStatusHistory') AND name = N'IX_OrderStatusHistory_ChangedByUserId')
        CREATE INDEX IX_OrderStatusHistory_ChangedByUserId ON dbo.OrderStatusHistory(ChangedByUserId);

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.OrderStockReservations') AND name = N'IX_OrderStockReservations_SalesOrderId_Status')
        CREATE INDEX IX_OrderStockReservations_SalesOrderId_Status ON dbo.OrderStockReservations(SalesOrderId, Status);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.OrderStockReservations') AND name = N'IX_OrderStockReservations_ProductBatchId_Status')
        CREATE INDEX IX_OrderStockReservations_ProductBatchId_Status ON dbo.OrderStockReservations(ProductBatchId, Status);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.OrderStockReservations') AND name = N'IX_OrderStockReservations_SalesOrderItemId')
        CREATE INDEX IX_OrderStockReservations_SalesOrderItemId ON dbo.OrderStockReservations(SalesOrderItemId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.OrderStockReservations') AND name = N'IX_OrderStockReservations_ProductId')
        CREATE INDEX IX_OrderStockReservations_ProductId ON dbo.OrderStockReservations(ProductId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.OrderStockReservations') AND name = N'IX_OrderStockReservations_StockId')
        CREATE INDEX IX_OrderStockReservations_StockId ON dbo.OrderStockReservations(StockId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.OrderStockReservations') AND name = N'IX_OrderStockReservations_SectionId')
        CREATE INDEX IX_OrderStockReservations_SectionId ON dbo.OrderStockReservations(SectionId);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.StockMovements') AND name = N'IX_StockMovements_SalesOrderId')
        CREATE INDEX IX_StockMovements_SalesOrderId ON dbo.StockMovements(SalesOrderId);

    IF OBJECT_ID(N'dbo.__EFMigrationsHistory', N'U') IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM dbo.__EFMigrationsHistory WHERE MigrationId = N'20260722223550_Subsystem10OrderManagement')
        INSERT dbo.__EFMigrationsHistory(MigrationId, ProductVersion)
        VALUES (N'20260722223550_Subsystem10OrderManagement', N'8.0.0');

    COMMIT TRANSACTION;
    PRINT 'Subsystem 10 Order Management deployment completed successfully.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
