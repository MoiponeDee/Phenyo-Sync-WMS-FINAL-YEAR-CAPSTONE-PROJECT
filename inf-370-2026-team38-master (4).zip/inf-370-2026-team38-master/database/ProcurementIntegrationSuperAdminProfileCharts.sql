﻿BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    ALTER TABLE [RawStockReceiptLines] ADD [SupplierOrderLineId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    CREATE TABLE [ProductRawStockRequirements] (
        [ProductRawStockRequirementId] int NOT NULL IDENTITY,
        [ProductId] int NOT NULL,
        [RawStockItemId] int NOT NULL,
        [RawQuantityPerProductUnit] decimal(18,4) NOT NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [WastePercentage] decimal(8,4) NOT NULL,
        [YieldPercentage] decimal(8,4) NOT NULL,
        [IsActive] bit NOT NULL,
        [CreatedByUserId] int NOT NULL,
        [UpdatedByUserId] int NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_ProductRawStockRequirements] PRIMARY KEY ([ProductRawStockRequirementId]),
        CONSTRAINT [FK_ProductRawStockRequirements_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductRawStockRequirements_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductRawStockRequirements_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductRawStockRequirements_Users_UpdatedByUserId] FOREIGN KEY ([UpdatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    CREATE INDEX [IX_RawStockReceiptLines_SupplierOrderLineId] ON [RawStockReceiptLines] ([SupplierOrderLineId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    CREATE INDEX [IX_ProductRawStockRequirements_CreatedByUserId] ON [ProductRawStockRequirements] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    CREATE INDEX [IX_ProductRawStockRequirements_RawStockItemId_IsActive] ON [ProductRawStockRequirements] ([RawStockItemId], [IsActive]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    CREATE INDEX [IX_ProductRawStockRequirements_UpdatedByUserId] ON [ProductRawStockRequirements] ([UpdatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    CREATE UNIQUE INDEX [UX_ProductRawStockRequirements_Product_RawStock] ON [ProductRawStockRequirements] ([ProductId], [RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    ALTER TABLE [RawStockReceiptLines] ADD CONSTRAINT [FK_RawStockReceiptLines_SupplierOrderLines_SupplierOrderLineId] FOREIGN KEY ([SupplierOrderLineId]) REFERENCES [SupplierOrderLines] ([SupplierOrderLineId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    UPDATE dbo.SupplierOrders
    SET Status = CASE
        WHEN Status IN ('Approved', 'PendingApproval') THEN 'Ordered'
        ELSE Status
    END
    WHERE Status IN ('Approved', 'PendingApproval');
    DECLARE @AdminRoleId int =
        (SELECT TOP (1) RoleId FROM dbo.Roles WHERE RoleCode = 'Admin');
    DECLARE @BusinessManagerRoleId int =
        (SELECT TOP (1) RoleId FROM dbo.Roles WHERE RoleCode = 'BusinessManager');
    DECLARE @ConflictingSuperAdminRoleId int =
        (SELECT TOP (1) RoleId
         FROM dbo.Roles
         WHERE RoleName = 'Super Admin'
           AND RoleCode <> 'Admin');
    IF @AdminRoleId IS NOT NULL
    BEGIN
        IF @ConflictingSuperAdminRoleId IS NOT NULL
        BEGIN
            INSERT INTO dbo.RolePermissions
                (RoleId, PermissionId, AssignedAtUtc, AssignedByUserId)
            SELECT @AdminRoleId, conflicting.PermissionId,
                   SYSUTCDATETIME(), conflicting.AssignedByUserId
            FROM dbo.RolePermissions conflicting
            WHERE conflicting.RoleId = @ConflictingSuperAdminRoleId
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.RolePermissions existing
                  WHERE existing.RoleId = @AdminRoleId
                    AND existing.PermissionId = conflicting.PermissionId
              );
            UPDATE dbo.Users
            SET RoleId = @AdminRoleId,
                UpdatedAtUtc = SYSUTCDATETIME()
            WHERE RoleId = @ConflictingSuperAdminRoleId;
            UPDATE dbo.Roles
            SET RoleName = CONCAT('Legacy Super Admin ', RoleId),
                Description = 'Retired role retained for migration history. Use Super Admin.',
                IsActive = 0,
                IsSystemRole = 0,
                UpdatedAtUtc = SYSUTCDATETIME()
            WHERE RoleId = @ConflictingSuperAdminRoleId;
        END;
        IF @BusinessManagerRoleId IS NOT NULL AND
           @BusinessManagerRoleId <> @AdminRoleId
        BEGIN
            INSERT INTO dbo.RolePermissions
                (RoleId, PermissionId, AssignedAtUtc, AssignedByUserId)
            SELECT @AdminRoleId, legacy.PermissionId,
                   SYSUTCDATETIME(), legacy.AssignedByUserId
            FROM dbo.RolePermissions legacy
            WHERE legacy.RoleId = @BusinessManagerRoleId
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.RolePermissions existing
                  WHERE existing.RoleId = @AdminRoleId
                    AND existing.PermissionId = legacy.PermissionId
              );
            UPDATE dbo.Users
            SET RoleId = @AdminRoleId,
                UpdatedAtUtc = SYSUTCDATETIME()
            WHERE RoleId = @BusinessManagerRoleId;
            UPDATE dbo.Roles
            SET RoleName = 'Legacy Business Manager',
                Description = 'Retired role retained for migration history. Use Super Admin.',
                IsActive = 0,
                IsSystemRole = 0,
                UpdatedAtUtc = SYSUTCDATETIME()
            WHERE RoleId = @BusinessManagerRoleId;
        END;
        UPDATE dbo.Roles
        SET RoleName = 'Super Admin',
            Description = 'Master-data and controlled business-administration role.',
            IsActive = 1,
            IsSystemRole = 1,
            UpdatedAtUtc = SYSUTCDATETIME()
        WHERE RoleId = @AdminRoleId;
        INSERT INTO dbo.RolePermissions
            (RoleId, PermissionId, AssignedAtUtc, AssignedByUserId)
        SELECT @AdminRoleId, permission.PermissionId,
               SYSUTCDATETIME(), NULL
        FROM dbo.Permissions permission
        WHERE permission.PermissionCode IN
        (
            'Customers.View', 'Customers.Manage',
            'Suppliers.View', 'Suppliers.Manage',
            'SupplierOrders.View', 'SupplierOrders.Manage',
            'BuyingList.View', 'BuyingList.ViewAll',
            'BuyingList.Create', 'BuyingList.UpdateDraft',
            'BuyingList.DeleteDraft', 'BuyingList.Assign',
            'BuyingList.Publish', 'BuyingList.Cancel',
            'Products.View', 'Products.Make', 'Products.Update',
            'Products.Delete', 'Products.ChangeStatus',
            'ProductTypes.View', 'ProductTypes.Manage',
            'ProductCategories.View', 'ProductCategories.Manage',
            'ProductHierarchy.View', 'ProductHierarchy.Manage',
            'ProductDataExchange.Export', 'ProductDataExchange.Import',
            'Orders.View', 'Orders.Create', 'Orders.Update',
            'Orders.Cancel',
            'Orders.SendLink', 'Pricing.View', 'Pricing.Create',
            'Pricing.Cancel', 'Pricing.ViewHistory', 'Pricing.Manage',
            'Lookups.View', 'Lookups.Manage',
            'SystemSettings.View', 'SystemSettings.Manage'
        )
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.RolePermissions existing
              WHERE existing.RoleId = @AdminRoleId
                AND existing.PermissionId = permission.PermissionId
          );
    END;
    DELETE rolePermission
    FROM dbo.RolePermissions rolePermission
    JOIN dbo.Roles role ON role.RoleId = rolePermission.RoleId
    JOIN dbo.Permissions permission
      ON permission.PermissionId = rolePermission.PermissionId
    WHERE role.RoleCode = 'WarehouseManager'
      AND permission.PermissionCode IN
      (
          'Products.Make', 'Products.Update', 'Products.Delete',
          'Products.ChangeStatus', 'ProductTypes.Manage',
          'ProductCategories.Manage', 'ProductHierarchy.Manage',
          'ProductDataExchange.Export', 'ProductDataExchange.Import'
      );
    DECLARE @OperationsManagerRoleId int =
        (SELECT TOP (1) RoleId
         FROM dbo.Roles
         WHERE RoleCode = 'OperationsManager');
    IF @OperationsManagerRoleId IS NOT NULL
    BEGIN
        INSERT INTO dbo.RolePermissions
            (RoleId, PermissionId, AssignedAtUtc, AssignedByUserId)
        SELECT @OperationsManagerRoleId, permission.PermissionId,
               SYSUTCDATETIME(), NULL
        FROM dbo.Permissions permission
        WHERE permission.PermissionCode IN
            ('Orders.Validate', 'Orders.Confirm')
          AND NOT EXISTS
          (
              SELECT 1
              FROM dbo.RolePermissions existing
              WHERE existing.RoleId = @OperationsManagerRoleId
                AND existing.PermissionId = permission.PermissionId
          );
    END;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260813221417_ProcurementIntegrationSuperAdminProfileCharts', N'8.0.0');
END;
GO

COMMIT;
GO

