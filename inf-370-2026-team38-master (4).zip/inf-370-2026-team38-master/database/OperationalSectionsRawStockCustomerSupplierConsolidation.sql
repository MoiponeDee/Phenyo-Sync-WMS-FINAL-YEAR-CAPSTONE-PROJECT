SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var0 sysname;
    SELECT @var0 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'Status');
    IF @var0 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var0 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [Status] nvarchar(450) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var1 sysname;
    SELECT @var1 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'Phone');
    IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var1 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [Phone] nvarchar(30) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var2 sysname;
    SELECT @var2 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'Email');
    IF @var2 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var2 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [Email] nvarchar(254) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var3 sysname;
    SELECT @var3 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'ContactPerson');
    IF @var3 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var3 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [ContactPerson] nvarchar(150) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var4 sysname;
    SELECT @var4 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'Address');
    IF @var4 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var4 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [Address] nvarchar(500) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [CreatedAtUtc] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [NormalizedEmail] nvarchar(254) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [SupplierCode] nvarchar(40) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [SupplierTypeCode] nvarchar(40) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [UpdatedAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [ApprovedAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [ApprovedByUserId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [CancelledAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [CreatedAtUtc] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [CreatedByUserId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [ExpectedDeliveryAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [Notes] nvarchar(1000) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [OrderNumber] nvarchar(40) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [Status] nvarchar(40) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [WarehouseSectionId] int NOT NULL DEFAULT 0;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Customers] ADD [ContactPerson] nvarchar(150) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Customers] ADD [NormalizedEmail] nvarchar(254) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Customers] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var5 sysname;
    SELECT @var5 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[BuyerProcurementItems]') AND [c].[name] = N'ProductId');
    IF @var5 IS NOT NULL EXEC(N'ALTER TABLE [BuyerProcurementItems] DROP CONSTRAINT [' + @var5 + '];');
    ALTER TABLE [BuyerProcurementItems] ALTER COLUMN [ProductId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD [RawStockItemId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    UPDATE dbo.Suppliers
    SET SupplierCode =
            CONCAT('SUP-', RIGHT(CONCAT('000000', SupplierId), 6)),
        SupplierTypeCode =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(SupplierTypeCode)), '') IS NULL
                    THEN 'GENERAL_SUPPLIER'
                ELSE UPPER(LTRIM(RTRIM(SupplierTypeCode)))
            END,
        NormalizedEmail =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(Email)), '') IS NULL THEN NULL
                ELSE UPPER(LTRIM(RTRIM(Email)))
            END,
        CreatedAtUtc =
            CASE
                WHEN CreatedAtUtc = '0001-01-01T00:00:00'
                    THEN SYSUTCDATETIME()
                ELSE CreatedAtUtc
            END;
    UPDATE dbo.Customers
    SET NormalizedEmail = UPPER(LTRIM(RTRIM(Email)));
    IF EXISTS (
        SELECT NormalizedEmail
        FROM dbo.Customers
        GROUP BY NormalizedEmail
        HAVING COUNT(*) > 1)
    BEGIN
        THROW 51001,
            'Duplicate customer emails must be resolved before the operational-sections migration can continue.',
            1;
    END;
    IF EXISTS (SELECT 1 FROM dbo.SupplierOrders)
       AND NOT EXISTS (SELECT 1 FROM dbo.WarehouseSections)
    BEGIN
        THROW 51002,
            'At least one Warehouse Section is required to backfill existing Supplier Orders.',
            1;
    END;
    UPDATE supplierOrder
    SET OrderNumber =
            CONCAT('SUPORD-', RIGHT(CONCAT('00000000', SupplierOrderId), 8)),
        Status =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(Status)), '') IS NULL
                    THEN 'Draft'
                ELSE Status
            END,
        CreatedAtUtc =
            CASE
                WHEN CreatedAtUtc = '0001-01-01T00:00:00'
                    THEN COALESCE(OrderDate, SYSUTCDATETIME())
                ELSE CreatedAtUtc
            END,
        WarehouseSectionId =
            (SELECT TOP (1) SectionId
             FROM dbo.WarehouseSections
             ORDER BY
                 CASE WHEN Status = 'Active' THEN 0 ELSE 1 END,
                 SectionId)
    FROM dbo.SupplierOrders supplierOrder;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [FinancialPayments] (
        [FinancialPaymentId] bigint NOT NULL IDENTITY,
        [PaymentNumber] nvarchar(40) NOT NULL,
        [CounterpartyType] nvarchar(20) NOT NULL,
        [CustomerId] int NULL,
        [SupplierId] int NULL,
        [InvoiceId] int NULL,
        [SupplierOrderId] int NULL,
        [OriginalPaymentId] bigint NULL,
        [Amount] decimal(18,2) NOT NULL,
        [PaymentDateUtc] datetime2 NOT NULL,
        [PaymentMethodCode] nvarchar(40) NOT NULL,
        [Reference] nvarchar(120) NULL,
        [Notes] nvarchar(1000) NULL,
        [Status] nvarchar(40) NOT NULL,
        [ReversalReason] nvarchar(1000) NULL,
        [CreatedByUserId] int NOT NULL,
        [PostedByUserId] int NULL,
        [DecidedByUserId] int NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [PostedAtUtc] datetime2 NULL,
        [DecidedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_FinancialPayments] PRIMARY KEY ([FinancialPaymentId]),
        CONSTRAINT [FK_FinancialPayments_Customers_CustomerId] FOREIGN KEY ([CustomerId]) REFERENCES [Customers] ([CustomerId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_FinancialPayments_OriginalPaymentId] FOREIGN KEY ([OriginalPaymentId]) REFERENCES [FinancialPayments] ([FinancialPaymentId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Invoices_InvoiceId] FOREIGN KEY ([InvoiceId]) REFERENCES [Invoices] ([InvoiceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_SupplierOrders_SupplierOrderId] FOREIGN KEY ([SupplierOrderId]) REFERENCES [SupplierOrders] ([SupplierOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Users_DecidedByUserId] FOREIGN KEY ([DecidedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Users_PostedByUserId] FOREIGN KEY ([PostedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [OperationalReasons] (
        [OperationalReasonId] int NOT NULL IDENTITY,
        [ReasonCode] nvarchar(40) NOT NULL,
        [ReasonName] nvarchar(120) NOT NULL,
        [CategoryCode] nvarchar(40) NOT NULL,
        [Description] nvarchar(1000) NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_OperationalReasons] PRIMARY KEY ([OperationalReasonId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockItems] (
        [RawStockItemId] int NOT NULL IDENTITY,
        [ItemCode] nvarchar(40) NOT NULL,
        [ItemName] nvarchar(160) NOT NULL,
        [CategoryCode] nvarchar(30) NOT NULL,
        [DefaultUnitOfMeasure] nvarchar(20) NOT NULL,
        [Description] nvarchar(1000) NULL,
        [IsProduce] bit NOT NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockItems] PRIMARY KEY ([RawStockItemId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockReceipts] (
        [RawStockReceiptId] bigint NOT NULL IDENTITY,
        [ReceiptNumber] nvarchar(40) NOT NULL,
        [SourceType] nvarchar(30) NOT NULL,
        [SupplierId] int NOT NULL,
        [SupplierOrderId] int NULL,
        [BuyerProcurementId] int NULL,
        [WarehouseSectionId] int NOT NULL,
        [ReceivedByUserId] int NOT NULL,
        [DocketReference] nvarchar(120) NOT NULL,
        [AdHocExplanation] nvarchar(1000) NULL,
        [Notes] nvarchar(1000) NULL,
        [ReceivedAtUtc] datetime2 NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [PostedAtUtc] datetime2 NULL,
        [Status] nvarchar(30) NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [OperationKeyHash] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockReceipts] PRIMARY KEY ([RawStockReceiptId]),
        CONSTRAINT [FK_RawStockReceipts_BuyerProcurements_BuyerProcurementId] FOREIGN KEY ([BuyerProcurementId]) REFERENCES [BuyerProcurements] ([BuyerProcurementId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceipts_SupplierOrders_SupplierOrderId] FOREIGN KEY ([SupplierOrderId]) REFERENCES [SupplierOrders] ([SupplierOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceipts_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceipts_Users_ReceivedByUserId] FOREIGN KEY ([ReceivedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceipts_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockReconciliationGroups] (
        [RawStockReconciliationGroupId] int NOT NULL IDENTITY,
        [GroupCode] nvarchar(40) NOT NULL,
        [GroupName] nvarchar(120) NOT NULL,
        [Description] nvarchar(1000) NULL,
        [IsActive] bit NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockReconciliationGroups] PRIMARY KEY ([RawStockReconciliationGroupId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockTakeSessions] (
        [RawStockTakeSessionId] bigint NOT NULL IDENTITY,
        [WarehouseSectionId] int NOT NULL,
        [CreatedByUserId] int NOT NULL,
        [ReviewedByUserId] int NULL,
        [DecidedByUserId] int NULL,
        [PeriodStartUtc] datetime2 NOT NULL,
        [PeriodEndUtc] datetime2 NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [SubmittedAtUtc] datetime2 NULL,
        [ReviewedAtUtc] datetime2 NULL,
        [DecidedAtUtc] datetime2 NULL,
        [ClosedAtUtc] datetime2 NULL,
        [Status] nvarchar(40) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [AdministratorReviewNotes] nvarchar(1000) NULL,
        [ManagementDecisionReason] nvarchar(1000) NULL,
        [ManagementApprovalRequired] bit NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockTakeSessions] PRIMARY KEY ([RawStockTakeSessionId]),
        CONSTRAINT [FK_RawStockTakeSessions_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeSessions_Users_DecidedByUserId] FOREIGN KEY ([DecidedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeSessions_Users_ReviewedByUserId] FOREIGN KEY ([ReviewedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeSessions_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockBalances] (
        [RawStockBalanceId] int NOT NULL IDENTITY,
        [RawStockItemId] int NOT NULL,
        [WarehouseSectionId] int NOT NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [QuantityOnHand] decimal(18,3) NOT NULL,
        [ReservedQuantity] decimal(18,3) NOT NULL,
        [WeightedAverageUnitCost] decimal(18,4) NOT NULL,
        [LastReceiptAtUtc] datetime2 NULL,
        [LastStockTakeAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockBalances] PRIMARY KEY ([RawStockBalanceId]),
        CONSTRAINT [FK_RawStockBalances_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockBalances_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [SupplierOrderLines] (
        [SupplierOrderLineId] int NOT NULL IDENTITY,
        [SupplierOrderId] int NOT NULL,
        [RawStockItemId] int NOT NULL,
        [OrderedQuantity] decimal(18,3) NOT NULL,
        [ReceivedQuantity] decimal(18,3) NOT NULL,
        [ExpectedUnitPrice] decimal(18,4) NOT NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [Notes] nvarchar(500) NULL,
        CONSTRAINT [PK_SupplierOrderLines] PRIMARY KEY ([SupplierOrderLineId]),
        CONSTRAINT [FK_SupplierOrderLines_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SupplierOrderLines_SupplierOrders_SupplierOrderId] FOREIGN KEY ([SupplierOrderId]) REFERENCES [SupplierOrders] ([SupplierOrderId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockReceiptLines] (
        [RawStockReceiptLineId] bigint NOT NULL IDENTITY,
        [RawStockReceiptId] bigint NOT NULL,
        [RawStockItemId] int NOT NULL,
        [QuantityReceived] decimal(18,3) NOT NULL,
        [AcceptedQuantity] decimal(18,3) NOT NULL,
        [RejectedQuantity] decimal(18,3) NOT NULL,
        [UnitCost] decimal(18,4) NOT NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [SupplierBatchReference] nvarchar(80) NULL,
        [BestBeforeAtUtc] datetime2 NULL,
        [Notes] nvarchar(500) NULL,
        CONSTRAINT [PK_RawStockReceiptLines] PRIMARY KEY ([RawStockReceiptLineId]),
        CONSTRAINT [FK_RawStockReceiptLines_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceiptLines_RawStockReceipts_RawStockReceiptId] FOREIGN KEY ([RawStockReceiptId]) REFERENCES [RawStockReceipts] ([RawStockReceiptId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [ProductReconciliationMappings] (
        [ProductReconciliationMappingId] int NOT NULL IDENTITY,
        [RawStockReconciliationGroupId] int NOT NULL,
        [ProductId] int NOT NULL,
        CONSTRAINT [PK_ProductReconciliationMappings] PRIMARY KEY ([ProductReconciliationMappingId]),
        CONSTRAINT [FK_ProductReconciliationMappings_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductReconciliationMappings_RawStockReconciliationGroups_RawStockReconciliationGroupId] FOREIGN KEY ([RawStockReconciliationGroupId]) REFERENCES [RawStockReconciliationGroups] ([RawStockReconciliationGroupId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockReconciliationGroupItems] (
        [RawStockReconciliationGroupItemId] int NOT NULL IDENTITY,
        [RawStockReconciliationGroupId] int NOT NULL,
        [RawStockItemId] int NOT NULL,
        CONSTRAINT [PK_RawStockReconciliationGroupItems] PRIMARY KEY ([RawStockReconciliationGroupItemId]),
        CONSTRAINT [FK_RawStockReconciliationGroupItems_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReconciliationGroupItems_RawStockReconciliationGroups_RawStockReconciliationGroupId] FOREIGN KEY ([RawStockReconciliationGroupId]) REFERENCES [RawStockReconciliationGroups] ([RawStockReconciliationGroupId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockTakeLines] (
        [RawStockTakeLineId] bigint NOT NULL IDENTITY,
        [RawStockTakeSessionId] bigint NOT NULL,
        [RawStockItemId] int NOT NULL,
        [RawStockBalanceId] int NOT NULL,
        [RawStockReconciliationGroupId] int NULL,
        [OpeningRawStock] decimal(18,3) NOT NULL,
        [RawStockReceived] decimal(18,3) NOT NULL,
        [ApprovedPositiveAdjustments] decimal(18,3) NOT NULL,
        [ExistingPackedProductWeight] decimal(18,3) NOT NULL,
        [RecordedRawStockWriteOffs] decimal(18,3) NOT NULL,
        [ApprovedNegativeAdjustments] decimal(18,3) NOT NULL,
        [EstimatedRawStockRemaining] decimal(18,3) NOT NULL,
        [PhysicalStockCount] decimal(18,3) NULL,
        [UnexplainedStockDifference] decimal(18,3) NULL,
        [EstimatedFinancialImpact] decimal(18,3) NOT NULL,
        [IsMapped] bit NOT NULL,
        [RequiresManagementApproval] bit NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockTakeLines] PRIMARY KEY ([RawStockTakeLineId]),
        CONSTRAINT [FK_RawStockTakeLines_RawStockBalances_RawStockBalanceId] FOREIGN KEY ([RawStockBalanceId]) REFERENCES [RawStockBalances] ([RawStockBalanceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeLines_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeLines_RawStockReconciliationGroups_RawStockReconciliationGroupId] FOREIGN KEY ([RawStockReconciliationGroupId]) REFERENCES [RawStockReconciliationGroups] ([RawStockReconciliationGroupId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeLines_RawStockTakeSessions_RawStockTakeSessionId] FOREIGN KEY ([RawStockTakeSessionId]) REFERENCES [RawStockTakeSessions] ([RawStockTakeSessionId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockBatches] (
        [RawStockBatchId] bigint NOT NULL IDENTITY,
        [RawStockItemId] int NOT NULL,
        [RawStockBalanceId] int NOT NULL,
        [SupplierId] int NULL,
        [RawStockReceiptLineId] bigint NULL,
        [BatchCode] nvarchar(70) NOT NULL,
        [QrCodeValue] nvarchar(220) NOT NULL,
        [QuantityReceived] decimal(18,3) NOT NULL,
        [QuantityRemaining] decimal(18,3) NOT NULL,
        [UnitCost] decimal(18,4) NOT NULL,
        [ReceivedAtUtc] datetime2 NOT NULL,
        [BestBeforeAtUtc] datetime2 NULL,
        [Status] nvarchar(30) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockBatches] PRIMARY KEY ([RawStockBatchId]),
        CONSTRAINT [FK_RawStockBatches_RawStockBalances_RawStockBalanceId] FOREIGN KEY ([RawStockBalanceId]) REFERENCES [RawStockBalances] ([RawStockBalanceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockBatches_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockBatches_RawStockReceiptLines_RawStockReceiptLineId] FOREIGN KEY ([RawStockReceiptLineId]) REFERENCES [RawStockReceiptLines] ([RawStockReceiptLineId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockBatches_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockMovements] (
        [RawStockMovementId] bigint NOT NULL IDENTITY,
        [RawStockItemId] int NOT NULL,
        [RawStockBalanceId] int NOT NULL,
        [RawStockBatchId] bigint NULL,
        [OperationalReasonId] int NULL,
        [CreatedByUserId] int NOT NULL,
        [MovementType] nvarchar(40) NOT NULL,
        [QuantityChange] decimal(18,3) NOT NULL,
        [UnitCost] decimal(18,4) NOT NULL,
        [OccurredAtUtc] datetime2 NOT NULL,
        [SourceType] nvarchar(80) NULL,
        [SourceId] nvarchar(80) NULL,
        [ReasonText] nvarchar(1000) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_RawStockMovements] PRIMARY KEY ([RawStockMovementId]),
        CONSTRAINT [FK_RawStockMovements_OperationalReasons_OperationalReasonId] FOREIGN KEY ([OperationalReasonId]) REFERENCES [OperationalReasons] ([OperationalReasonId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockMovements_RawStockBalances_RawStockBalanceId] FOREIGN KEY ([RawStockBalanceId]) REFERENCES [RawStockBalances] ([RawStockBalanceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockMovements_RawStockBatches_RawStockBatchId] FOREIGN KEY ([RawStockBatchId]) REFERENCES [RawStockBatches] ([RawStockBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockMovements_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockMovements_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockWriteOffs] (
        [RawStockWriteOffId] bigint NOT NULL IDENTITY,
        [RawStockItemId] int NOT NULL,
        [RawStockBalanceId] int NOT NULL,
        [RawStockBatchId] bigint NULL,
        [OperationalReasonId] int NOT NULL,
        [SubmittedByUserId] int NOT NULL,
        [DecidedByUserId] int NULL,
        [Quantity] decimal(18,3) NOT NULL,
        [EstimatedUnitCost] decimal(18,4) NOT NULL,
        [EstimatedTotalLoss] decimal(18,2) NOT NULL,
        [Condition] nvarchar(120) NULL,
        [Notes] nvarchar(1000) NULL,
        [Status] nvarchar(30) NOT NULL,
        [DecisionReason] nvarchar(1000) NULL,
        [SubmittedAtUtc] datetime2 NOT NULL,
        [DecidedAtUtc] datetime2 NULL,
        [CompletedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockWriteOffs] PRIMARY KEY ([RawStockWriteOffId]),
        CONSTRAINT [FK_RawStockWriteOffs_OperationalReasons_OperationalReasonId] FOREIGN KEY ([OperationalReasonId]) REFERENCES [OperationalReasons] ([OperationalReasonId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_RawStockBalances_RawStockBalanceId] FOREIGN KEY ([RawStockBalanceId]) REFERENCES [RawStockBalances] ([RawStockBalanceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_RawStockBatches_RawStockBatchId] FOREIGN KEY ([RawStockBatchId]) REFERENCES [RawStockBatches] ([RawStockBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_Users_DecidedByUserId] FOREIGN KEY ([DecidedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_Users_SubmittedByUserId] FOREIGN KEY ([SubmittedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockWriteOffEvidence] (
        [RawStockWriteOffEvidenceId] bigint NOT NULL IDENTITY,
        [RawStockWriteOffId] bigint NOT NULL,
        [StoredFileId] bigint NOT NULL,
        [UploadedByUserId] int NOT NULL,
        [UploadedAtUtc] datetime2 NOT NULL,
        [Caption] nvarchar(300) NULL,
        CONSTRAINT [PK_RawStockWriteOffEvidence] PRIMARY KEY ([RawStockWriteOffEvidenceId]),
        CONSTRAINT [FK_RawStockWriteOffEvidence_RawStockWriteOffs_RawStockWriteOffId] FOREIGN KEY ([RawStockWriteOffId]) REFERENCES [RawStockWriteOffs] ([RawStockWriteOffId]) ON DELETE CASCADE,
        CONSTRAINT [FK_RawStockWriteOffEvidence_StoredFiles_StoredFileId] FOREIGN KEY ([StoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffEvidence_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (45, NULL, N''Raw stock take'', N''25'', N''Absolute raw-stock variance above which management approval is required.'', N''Quantity approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStockTake.RequireApprovalAboveKg'', N''100000'', N''0'', CAST(0 AS bit), N''kg'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''25'', N''Decimal''),
    (46, NULL, N''Raw stock take'', N''5'', N''Percentage raw-stock variance above which management approval is required.'', N''Percentage approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStockTake.RequireApprovalAbovePercentage'', N''100'', N''0'', CAST(0 AS bit), N''percent'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''Decimal''),
    (47, NULL, N''Raw stock take'', N''1000'', N''Estimated financial impact above which management approval is required.'', N''Value approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStockTake.RequireApprovalAboveValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''1000'', N''Decimal''),
    (48, NULL, N''Payments'', N''5000'', N''Maximum payment value an Administrator may reverse on the capture day.'', N''Administrator same-day reversal limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Payments.AdminVoidSameDayMaximumValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5000'', N''Decimal''),
    (49, NULL, N''Payments'', N''24'', N''Hours after posting when a payment reversal requires management approval.'', N''Reversal approval hours'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Payments.RequireManagementApprovalAfterHours'', N''720'', N''0'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''24'', N''Integer''),
    (50, NULL, N''Payments'', N''5000'', N''Payment value above which reversal requires management approval.'', N''Reversal approval value'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Payments.RequireManagementApprovalAboveValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5000'', N''Decimal''),
    (51, NULL, N''Raw stock'', N''100'', N''Raw-stock write-off quantity above which management approval is required.'', N''Write-off quantity approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStock.WriteOffRequireApprovalAboveQuantity'', N''1000000'', N''0'', CAST(0 AS bit), N''units'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''100'', N''Decimal''),
    (52, NULL, N''Raw stock'', N''1000'', N''Raw-stock write-off value above which management approval is required.'', N''Write-off value approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStock.WriteOffRequireApprovalAboveValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''1000'', N''Decimal''),
    (53, NULL, N''Raw stock'', N''500'', N''Raw-stock loss above which photographic evidence is required.'', N''Write-off evidence threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStock.WriteOffEvidenceAboveValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''500'', N''Decimal'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @OperationalPermissions TABLE
    (
        PermissionCode nvarchar(100) NOT NULL PRIMARY KEY,
        DisplayName nvarchar(120) NOT NULL,
        Module nvarchar(80) NOT NULL
    );
    INSERT INTO @OperationalPermissions VALUES
        ('RawStock.View', 'View raw stock', 'RawStock'),
        ('RawStock.Manage', 'Create and maintain raw-stock items', 'RawStock'),
        ('RawStock.Receive', 'Receive raw stock into warehouse balances', 'RawStock'),
        ('RawStock.WriteOff', 'Submit raw-stock write-offs', 'RawStock'),
        ('RawStock.ApproveWriteOff', 'Approve raw-stock write-offs', 'RawStock'),
        ('RawStockTakes.View', 'View raw-stock takes', 'RawStock'),
        ('RawStockTakes.Capture', 'Capture and submit raw-stock takes', 'RawStock'),
        ('RawStockTakes.Review', 'Review raw-stock takes', 'RawStock'),
        ('RawStockTakes.Approve', 'Approve raw-stock-take adjustments', 'RawStock'),
        ('OperationalReasons.View', 'View operational reasons', 'Configuration'),
        ('OperationalReasons.Manage', 'Manage operational reasons', 'Configuration'),
        ('SupplierOrders.View', 'View supplier orders', 'Suppliers'),
        ('SupplierOrders.Manage', 'Create and maintain supplier orders', 'Suppliers'),
        ('CustomerPayments.View', 'View customer payments', 'Payments'),
        ('CustomerPayments.Capture', 'Capture customer payments', 'Payments'),
        ('CustomerPayments.Reverse', 'Request customer-payment reversal', 'Payments'),
        ('CustomerPayments.ApproveReversal', 'Approve customer-payment reversal', 'Payments'),
        ('SupplierPayments.View', 'View supplier payments', 'Payments'),
        ('SupplierPayments.Capture', 'Capture supplier payments', 'Payments'),
        ('SupplierPayments.Reverse', 'Request supplier-payment reversal', 'Payments'),
        ('SupplierPayments.ApproveReversal', 'Approve supplier-payment reversal', 'Payments'),
        ('Reconciliation.View', 'View raw-stock reconciliation mappings', 'RawStock'),
        ('Reconciliation.Manage', 'Manage raw-stock reconciliation mappings', 'RawStock'),
        ('ManagementDashboard.View', 'View management operational dashboard', 'Dashboard');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT seed.PermissionCode, seed.PermissionCode,
           seed.DisplayName, seed.Module, 1, 1, SYSUTCDATETIME()
    FROM @OperationalPermissions seed
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode);
    UPDATE permission
    SET permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @OperationalPermissions seed
      ON seed.PermissionCode = permission.PermissionCode;
    DECLARE @OperationalRolePermissions TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL,
        PRIMARY KEY (RoleCode, PermissionCode)
    );
    INSERT INTO @OperationalRolePermissions
    SELECT roleCode.RoleCode, permission.PermissionCode
    FROM (VALUES ('CEO'), ('COO'), ('BusinessManager'))
         roleCode(RoleCode)
    CROSS JOIN @OperationalPermissions permission;
    INSERT INTO @OperationalRolePermissions VALUES
        ('Admin', 'CustomerPayments.View'),
        ('Admin', 'CustomerPayments.Capture'),
        ('Admin', 'CustomerPayments.Reverse'),
        ('Admin', 'SupplierPayments.View'),
        ('Admin', 'SupplierPayments.Capture'),
        ('Admin', 'SupplierPayments.Reverse'),
        ('Admin', 'RawStock.View'),
        ('Admin', 'RawStock.Manage'),
        ('Admin', 'RawStock.Receive'),
        ('Admin', 'RawStockTakes.View'),
        ('Admin', 'RawStockTakes.Review'),
        ('Admin', 'OperationalReasons.View'),
        ('Admin', 'OperationalReasons.Manage'),
        ('Admin', 'SupplierOrders.View'),
        ('Admin', 'SupplierOrders.Manage'),
        ('Admin', 'Reconciliation.View'),
        ('WarehouseManager', 'RawStock.View'),
        ('WarehouseManager', 'RawStock.Receive'),
        ('WarehouseManager', 'RawStock.WriteOff'),
        ('WarehouseManager', 'RawStockTakes.View'),
        ('WarehouseManager', 'RawStockTakes.Capture'),
        ('WarehouseManager', 'OperationalReasons.View'),
        ('WarehouseManager', 'Reconciliation.View'),
        ('MarketBuyer', 'RawStock.View');
    INSERT INTO @OperationalRolePermissions
        (RoleCode, PermissionCode)
    SELECT 'AdminClerk', PermissionCode
    FROM @OperationalRolePermissions
    WHERE RoleCode = 'Admin';
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM @OperationalRolePermissions seed
    JOIN dbo.Roles role
      ON role.RoleCode = seed.RoleCode
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = seed.PermissionCode
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.RolePermissions existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId = permission.PermissionId);
    INSERT INTO dbo.OperationalReasons
        (ReasonCode, ReasonName, CategoryCode, Description,
         IsActive, CreatedAtUtc)
    SELECT seed.ReasonCode, seed.ReasonName, seed.CategoryCode,
           seed.Description, 1, SYSUTCDATETIME()
    FROM (VALUES
        ('EXPIRED', 'Expired stock', 'WriteOff',
         'Stock passed its approved best-before date.'),
        ('SPOILED', 'Spoiled stock', 'WriteOff',
         'Stock is no longer fit for processing or sale.'),
        ('DAMAGED', 'Damaged stock', 'WriteOff',
         'Stock was damaged during handling or storage.'),
        ('QUALITY_REJECTED', 'Quality rejected', 'WriteOff',
         'Inspection found that the stock failed quality requirements.'),
        ('STOCK_COUNT', 'Stock-count adjustment', 'StockTake',
         'Controlled adjustment arising from an approved physical stock take.'),
        ('RECEIPT_REJECTION', 'Receipt rejection', 'Receipt',
         'Quantity was rejected during receiving inspection.')
    ) seed(ReasonCode, ReasonName, CategoryCode, Description)
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.OperationalReasons existing
        WHERE existing.ReasonCode = seed.ReasonCode);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_Suppliers_NormalizedEmail] ON [Suppliers] ([NormalizedEmail]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_Suppliers_SupplierTypeCode_Status] ON [Suppliers] ([SupplierTypeCode], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_Suppliers_Code] ON [Suppliers] ([SupplierCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrders_ApprovedByUserId] ON [SupplierOrders] ([ApprovedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrders_CreatedByUserId] ON [SupplierOrders] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrders_Status_OrderDate] ON [SupplierOrders] ([Status], [OrderDate]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrders_WarehouseSectionId] ON [SupplierOrders] ([WarehouseSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_SupplierOrders_Number] ON [SupplierOrders] ([OrderNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_Customers_NormalizedEmail] ON [Customers] ([NormalizedEmail]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_RawStockItemId] ON [BuyerProcurementItems] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_CorrelationId] ON [FinancialPayments] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_CounterpartyType_Status_PaymentDateUtc] ON [FinancialPayments] ([CounterpartyType], [Status], [PaymentDateUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_CreatedByUserId] ON [FinancialPayments] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_CustomerId] ON [FinancialPayments] ([CustomerId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_DecidedByUserId] ON [FinancialPayments] ([DecidedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_InvoiceId] ON [FinancialPayments] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_OriginalPaymentId] ON [FinancialPayments] ([OriginalPaymentId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_PostedByUserId] ON [FinancialPayments] ([PostedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_SupplierId] ON [FinancialPayments] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_SupplierOrderId] ON [FinancialPayments] ([SupplierOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_FinancialPayments_Number] ON [FinancialPayments] ([PaymentNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_OperationalReasons_CategoryCode_IsActive_ReasonName] ON [OperationalReasons] ([CategoryCode], [IsActive], [ReasonName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_OperationalReasons_Code] ON [OperationalReasons] ([ReasonCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_ProductReconciliationMappings_RawStockReconciliationGroupId] ON [ProductReconciliationMappings] ([RawStockReconciliationGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_ProductReconciliationMappings_Product] ON [ProductReconciliationMappings] ([ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockBalances_WarehouseSectionId] ON [RawStockBalances] ([WarehouseSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockBalances_Item_Section_Unit] ON [RawStockBalances] ([RawStockItemId], [WarehouseSectionId], [UnitOfMeasure]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockBatches_RawStockBalanceId] ON [RawStockBatches] ([RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockBatches_RawStockItemId_Status_BestBeforeAtUtc] ON [RawStockBatches] ([RawStockItemId], [Status], [BestBeforeAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [IX_RawStockBatches_RawStockReceiptLineId] ON [RawStockBatches] ([RawStockReceiptLineId]) WHERE [RawStockReceiptLineId] IS NOT NULL');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockBatches_SupplierId] ON [RawStockBatches] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockBatches_BatchCode] ON [RawStockBatches] ([BatchCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockBatches_Qr] ON [RawStockBatches] ([QrCodeValue]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockItems_CategoryCode_IsActive] ON [RawStockItems] ([CategoryCode], [IsActive]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockItems_Code] ON [RawStockItems] ([ItemCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockItems_Name] ON [RawStockItems] ([ItemName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_CorrelationId] ON [RawStockMovements] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_CreatedByUserId] ON [RawStockMovements] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_OperationalReasonId] ON [RawStockMovements] ([OperationalReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_RawStockBalanceId] ON [RawStockMovements] ([RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_RawStockBatchId] ON [RawStockMovements] ([RawStockBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_RawStockItemId_OccurredAtUtc] ON [RawStockMovements] ([RawStockItemId], [OccurredAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_SourceType_SourceId] ON [RawStockMovements] ([SourceType], [SourceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceiptLines_RawStockItemId] ON [RawStockReceiptLines] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceiptLines_RawStockReceiptId_RawStockItemId] ON [RawStockReceiptLines] ([RawStockReceiptId], [RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_BuyerProcurementId] ON [RawStockReceipts] ([BuyerProcurementId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_CorrelationId] ON [RawStockReceipts] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_ReceivedByUserId] ON [RawStockReceipts] ([ReceivedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_Status_ReceivedAtUtc] ON [RawStockReceipts] ([Status], [ReceivedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_SupplierId] ON [RawStockReceipts] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_SupplierOrderId] ON [RawStockReceipts] ([SupplierOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_WarehouseSectionId] ON [RawStockReceipts] ([WarehouseSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockReceipts_Number] ON [RawStockReceipts] ([ReceiptNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockReceipts_Operation] ON [RawStockReceipts] ([OperationKeyHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReconciliationGroupItems_RawStockReconciliationGroupId] ON [RawStockReconciliationGroupItems] ([RawStockReconciliationGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_ReconciliationGroupItems_RawStock] ON [RawStockReconciliationGroupItems] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockReconciliationGroups_Code] ON [RawStockReconciliationGroups] ([GroupCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeLines_RawStockBalanceId] ON [RawStockTakeLines] ([RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeLines_RawStockItemId] ON [RawStockTakeLines] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeLines_RawStockReconciliationGroupId] ON [RawStockTakeLines] ([RawStockReconciliationGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockTakeLines_Session_Balance] ON [RawStockTakeLines] ([RawStockTakeSessionId], [RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeSessions_CreatedByUserId] ON [RawStockTakeSessions] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeSessions_DecidedByUserId] ON [RawStockTakeSessions] ([DecidedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeSessions_ReviewedByUserId] ON [RawStockTakeSessions] ([ReviewedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeSessions_WarehouseSectionId_Status_CreatedAtUtc] ON [RawStockTakeSessions] ([WarehouseSectionId], [Status], [CreatedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockTakeSessions_Correlation] ON [RawStockTakeSessions] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffEvidence_RawStockWriteOffId] ON [RawStockWriteOffEvidence] ([RawStockWriteOffId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffEvidence_StoredFileId] ON [RawStockWriteOffEvidence] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffEvidence_UploadedByUserId] ON [RawStockWriteOffEvidence] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_CorrelationId] ON [RawStockWriteOffs] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_DecidedByUserId] ON [RawStockWriteOffs] ([DecidedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_OperationalReasonId] ON [RawStockWriteOffs] ([OperationalReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_RawStockBalanceId] ON [RawStockWriteOffs] ([RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_RawStockBatchId] ON [RawStockWriteOffs] ([RawStockBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_RawStockItemId] ON [RawStockWriteOffs] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_Status_SubmittedAtUtc] ON [RawStockWriteOffs] ([Status], [SubmittedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_SubmittedByUserId] ON [RawStockWriteOffs] ([SubmittedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrderLines_RawStockItemId] ON [SupplierOrderLines] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_SupplierOrderLines_Order_Item] ON [SupplierOrderLines] ([SupplierOrderId], [RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD CONSTRAINT [FK_BuyerProcurementItems_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD CONSTRAINT [FK_SupplierOrders_Users_ApprovedByUserId] FOREIGN KEY ([ApprovedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD CONSTRAINT [FK_SupplierOrders_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD CONSTRAINT [FK_SupplierOrders_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation', N'8.0.0');
END;
GO

COMMIT;
GO

