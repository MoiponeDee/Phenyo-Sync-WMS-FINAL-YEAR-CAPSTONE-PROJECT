﻿BEGIN TRANSACTION;
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
SET ANSI_PADDING ON;
GO
SET ANSI_WARNINGS ON;
GO
SET ARITHABORT ON;
GO
SET CONCAT_NULL_YIELDS_NULL ON;
GO
SET NUMERIC_ROUNDABORT OFF;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    ALTER TABLE [SalesOrders] ADD [PackingCompletionOperationKeyHash] nvarchar(64) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    DECLARE @OperationsManagerRoleId int =
    (
        SELECT TOP (1) RoleId
        FROM dbo.Roles
        WHERE RoleCode IN (N'OperationsManager', N'CEO', N'COO')
           OR RoleName IN (N'Operations Manager', N'Chief Executive Officer', N'Chief Operating Officer')
        ORDER BY
            CASE
                WHEN RoleCode = N'OperationsManager'
                  OR RoleName = N'Operations Manager'
                THEN 0
                ELSE 1
            END,
            RoleId
    );
    DECLARE @OperationsRoleWasLegacy bit =
    (
        SELECT
            CASE
                WHEN RoleCode IN (N'CEO', N'COO')
                  OR RoleName IN
                  (
                      N'CEO',
                      N'COO',
                      N'Chief Executive Officer',
                      N'Chief Operating Officer'
                  )
                THEN 1
                ELSE 0
            END
        FROM dbo.Roles
        WHERE RoleId = @OperationsManagerRoleId
    );
    IF @OperationsManagerRoleId IS NULL
    BEGIN
        INSERT INTO dbo.Roles
        (
            RoleCode,
            RoleName,
            Description,
            IsSystemRole,
            IsActive,
            CreatedAtUtc
        )
        VALUES
        (
            N'OperationsManager',
            N'Operations Manager',
            N'Executive operational oversight with scoped read and approval access.',
            1,
            1,
            SYSUTCDATETIME()
        );
        SET @OperationsManagerRoleId = CONVERT(int, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE dbo.Roles
        SET
            RoleCode = N'OperationsManager',
            RoleName = N'Operations Manager',
            Description = N'Executive operational oversight with scoped read and approval access.',
            IsSystemRole = 1,
            IsActive = 1,
            UpdatedAtUtc = SYSUTCDATETIME()
        WHERE RoleId = @OperationsManagerRoleId;
    END;
    DECLARE @WarehouseManagerRoleId int =
    (
        SELECT TOP (1) RoleId
        FROM dbo.Roles
        WHERE RoleCode IN (N'WarehouseManager', N'StockTaker')
           OR RoleName IN (N'Warehouse Manager', N'Stock Taker', N'StockTaker')
        ORDER BY
            CASE
                WHEN RoleCode = N'WarehouseManager'
                  OR RoleName = N'Warehouse Manager'
                THEN 0
                ELSE 1
            END,
            RoleId
    );
    DECLARE @WarehouseRoleWasLegacy bit =
    (
        SELECT
            CASE
                WHEN RoleCode = N'StockTaker'
                  OR RoleName IN (N'Stock Taker', N'StockTaker')
                THEN 1
                ELSE 0
            END
        FROM dbo.Roles
        WHERE RoleId = @WarehouseManagerRoleId
    );
    IF @WarehouseManagerRoleId IS NULL
    BEGIN
        INSERT INTO dbo.Roles
        (
            RoleCode,
            RoleName,
            Description,
            IsSystemRole,
            IsActive,
            CreatedAtUtc
        )
        VALUES
        (
            N'WarehouseManager',
            N'Warehouse Manager',
            N'Warehouse, inventory, packing, dispatch, expiry and write-off operations.',
            1,
            1,
            SYSUTCDATETIME()
        );
        SET @WarehouseManagerRoleId = CONVERT(int, SCOPE_IDENTITY());
    END
    ELSE
    BEGIN
        UPDATE dbo.Roles
        SET
            RoleCode = N'WarehouseManager',
            RoleName = N'Warehouse Manager',
            Description = N'Warehouse, inventory, packing, dispatch, expiry and write-off operations.',
            IsSystemRole = 1,
            IsActive = 1,
            UpdatedAtUtc = SYSUTCDATETIME()
        WHERE RoleId = @WarehouseManagerRoleId;
    END;
    DECLARE @CoreRoleSeed TABLE
    (
        RoleCode nvarchar(50) NOT NULL PRIMARY KEY,
        RoleName nvarchar(80) NOT NULL,
        Description nvarchar(500) NOT NULL
    );
    INSERT INTO @CoreRoleSeed
    (
        RoleCode,
        RoleName,
        Description
    )
    VALUES
        (
            N'Admin',
            N'Administrator',
            N'Customer, pricing, user, permission and configuration administration.'
        ),
        (
            N'BusinessManager',
            N'Business Manager',
            N'Customer Orders, Supplier Orders, procurement and Buying List coordination.'
        ),
        (
            N'Packer',
            N'Packer',
            N'Mobile-first Order packing and Product Batch scanning.'
        ),
        (
            N'Driver',
            N'Driver',
            N'Mobile-first assigned delivery, tracking and proof capture.'
        ),
        (
            N'MarketBuyer',
            N'Market Buyer',
            N'Mobile-first Buying List purchasing, notes and docket capture.'
        );
    UPDATE role
    SET
        role.RoleCode = seed.RoleCode,
        role.Description = seed.Description,
        role.IsSystemRole = 1,
        role.IsActive = 1,
        role.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Roles AS role
    INNER JOIN @CoreRoleSeed AS seed
        ON seed.RoleName = role.RoleName
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.Roles AS canonical
        WHERE canonical.RoleCode = seed.RoleCode
    );
    INSERT INTO dbo.Roles
    (
        RoleCode,
        RoleName,
        Description,
        IsSystemRole,
        IsActive,
        CreatedAtUtc
    )
    SELECT
        seed.RoleCode,
        seed.RoleName,
        seed.Description,
        1,
        1,
        SYSUTCDATETIME()
    FROM @CoreRoleSeed AS seed
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.Roles AS role
        WHERE role.RoleCode = seed.RoleCode
    );
    UPDATE role
    SET
        role.Description = seed.Description,
        role.IsSystemRole = 1,
        role.IsActive = 1,
        role.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Roles AS role
    INNER JOIN @CoreRoleSeed AS seed
        ON seed.RoleCode = role.RoleCode;
    UPDATE appUser
    SET
        appUser.RoleId = @WarehouseManagerRoleId,
        appUser.SecurityVersion = appUser.SecurityVersion + 1,
        appUser.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Users AS appUser
    INNER JOIN dbo.Roles AS legacyRole
        ON legacyRole.RoleId = appUser.RoleId
    WHERE legacyRole.RoleId <> @WarehouseManagerRoleId
      AND
      (
          legacyRole.RoleCode = N'StockTaker'
          OR legacyRole.RoleName IN (N'Stock Taker', N'StockTaker')
      );
    IF @WarehouseRoleWasLegacy = 1
    BEGIN
        UPDATE dbo.Users
        SET
            SecurityVersion = SecurityVersion + 1,
            UpdatedAtUtc = SYSUTCDATETIME()
        WHERE RoleId = @WarehouseManagerRoleId;
    END;
    UPDATE appUser
    SET
        appUser.RoleId = @OperationsManagerRoleId,
        appUser.SecurityVersion = appUser.SecurityVersion + 1,
        appUser.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Users AS appUser
    INNER JOIN dbo.Roles AS legacyRole
        ON legacyRole.RoleId = appUser.RoleId
    WHERE legacyRole.RoleId <> @OperationsManagerRoleId
      AND
      (
          legacyRole.RoleCode IN (N'CEO', N'COO')
          OR legacyRole.RoleName IN
          (
              N'CEO',
              N'COO',
              N'Chief Executive Officer',
              N'Chief Operating Officer'
          )
      );
    IF @OperationsRoleWasLegacy = 1
    BEGIN
        UPDATE dbo.Users
        SET
            SecurityVersion = SecurityVersion + 1,
            UpdatedAtUtc = SYSUTCDATETIME()
        WHERE RoleId = @OperationsManagerRoleId;
    END;
    UPDATE appUser
    SET
        appUser.RoleId = canonicalRole.RoleId,
        appUser.SecurityVersion = appUser.SecurityVersion + 1,
        appUser.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Users AS appUser
    INNER JOIN dbo.Roles AS legacyRole
        ON legacyRole.RoleId = appUser.RoleId
    INNER JOIN dbo.Roles AS canonicalRole
        ON canonicalRole.RoleCode = N'Admin'
    WHERE legacyRole.RoleCode = N'AdminClerk'
       OR legacyRole.RoleName = N'Admin Clerk';
    UPDATE appUser
    SET
        appUser.RoleId = canonicalRole.RoleId,
        appUser.SecurityVersion = appUser.SecurityVersion + 1,
        appUser.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Users AS appUser
    INNER JOIN dbo.Roles AS legacyRole
        ON legacyRole.RoleId = appUser.RoleId
    INNER JOIN dbo.Roles AS canonicalRole
        ON canonicalRole.RoleCode = N'MarketBuyer'
    WHERE legacyRole.RoleCode = N'Buyer'
       OR legacyRole.RoleName = N'Buyer';
    UPDATE dbo.Roles
    SET
        IsActive = 0,
        UpdatedAtUtc = SYSUTCDATETIME()
    WHERE RoleId NOT IN
    (
        @OperationsManagerRoleId,
        @WarehouseManagerRoleId
    )
      AND
      (
          RoleCode IN
          (
              N'CEO',
              N'COO',
              N'StockTaker',
              N'AdminClerk',
              N'Buyer'
          )
          OR RoleName IN
          (
              N'CEO',
              N'COO',
              N'Chief Executive Officer',
              N'Chief Operating Officer',
              N'Stock Taker',
              N'StockTaker',
              N'Admin Clerk',
              N'Buyer'
          )
      );
    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.Permissions
        WHERE PermissionCode = N'Dashboards.View'
    )
    BEGIN
        INSERT INTO dbo.Permissions
        (
            PermissionName,
            PermissionCode,
            DisplayName,
            Module,
            Description,
            IsSystemPermission,
            IsActive,
            CreatedAtUtc
        )
        VALUES
        (
            N'Dashboards.View',
            N'Dashboards.View',
            N'View role dashboard',
            N'Dashboards',
            N'View the live role-scoped operational dashboard.',
            1,
            1,
            SYSUTCDATETIME()
        );
    END
    ELSE
    BEGIN
        UPDATE dbo.Permissions
        SET
            PermissionName = N'Dashboards.View',
            DisplayName = N'View role dashboard',
            Module = N'Dashboards',
            Description = N'View the live role-scoped operational dashboard.',
            IsSystemPermission = 1,
            IsActive = 1,
            UpdatedAtUtc = SYSUTCDATETIME()
        WHERE PermissionCode = N'Dashboards.View';
    END;
    DECLARE @DesiredRolePermissions TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL,
        PRIMARY KEY (RoleCode, PermissionCode)
    );
    INSERT INTO @DesiredRolePermissions
    (
        RoleCode,
        PermissionCode
    )
    VALUES
        (N'OperationsManager', N'AuditLogs.View'),
        (N'OperationsManager', N'BuyingList.View'),
        (N'OperationsManager', N'BuyingList.ViewAll'),
        (N'OperationsManager', N'CustomerPayments.ApproveReversal'),
        (N'OperationsManager', N'CustomerPayments.Capture'),
        (N'OperationsManager', N'CustomerPayments.Reverse'),
        (N'OperationsManager', N'CustomerPayments.View'),
        (N'OperationsManager', N'Customers.View'),
        (N'OperationsManager', N'Dashboards.View'),
        (N'OperationsManager', N'Deliveries.View'),
        (N'OperationsManager', N'Deliveries.ViewProof'),
        (N'OperationsManager', N'Expiry.View'),
        (N'OperationsManager', N'Help.View'),
        (N'OperationsManager', N'Invoices.View'),
        (N'OperationsManager', N'Lookups.View'),
        (N'OperationsManager', N'ManagementDashboard.View'),
        (N'OperationsManager', N'Mobile.Access'),
        (N'OperationsManager', N'Mobile.BuyingList.ViewAll'),
        (N'OperationsManager', N'Mobile.Delivery.ViewAll'),
        (N'OperationsManager', N'Mobile.DeviceManagement.View'),
        (N'OperationsManager', N'Mobile.Dispatch.View'),
        (N'OperationsManager', N'Mobile.Help.View'),
        (N'OperationsManager', N'Mobile.Notification.View'),
        (N'OperationsManager', N'Mobile.Packing.View'),
        (N'OperationsManager', N'Mobile.Profile.View'),
        (N'OperationsManager', N'Mobile.StockReceipt.View'),
        (N'OperationsManager', N'Mobile.Tracking.ViewAll'),
        (N'OperationsManager', N'Mobile.WriteOff.Approve'),
        (N'OperationsManager', N'Mobile.WriteOff.Override'),
        (N'OperationsManager', N'Mobile.WriteOff.Reject'),
        (N'OperationsManager', N'Mobile.WriteOff.View'),
        (N'OperationsManager', N'Mobile.WriteOff.ViewFinancialImpact'),
        (N'OperationsManager', N'Notifications.ManagePreferences'),
        (N'OperationsManager', N'Notifications.ManageRules'),
        (N'OperationsManager', N'Notifications.SendTest'),
        (N'OperationsManager', N'Notifications.View'),
        (N'OperationsManager', N'Notifications.ViewDeliveryHistory'),
        (N'OperationsManager', N'OperationalReasons.View'),
        (N'OperationsManager', N'OperationsCalendar.View'),
        (N'OperationsManager', N'Orders.View'),
        (N'OperationsManager', N'Payments.Capture'),
        (N'OperationsManager', N'Payments.Confirm'),
        (N'OperationsManager', N'Payments.Reverse'),
        (N'OperationsManager', N'Payments.View'),
        (N'OperationsManager', N'Permissions.View'),
        (N'OperationsManager', N'Pricing.View'),
        (N'OperationsManager', N'ProductCategories.View'),
        (N'OperationsManager', N'ProductHierarchy.View'),
        (N'OperationsManager', N'Products.View'),
        (N'OperationsManager', N'ProductTypes.View'),
        (N'OperationsManager', N'RawStock.ApproveWriteOff'),
        (N'OperationsManager', N'RawStock.View'),
        (N'OperationsManager', N'RawStockTakes.Approve'),
        (N'OperationsManager', N'RawStockTakes.View'),
        (N'OperationsManager', N'Reconciliation.View'),
        (N'OperationsManager', N'Roles.View'),
        (N'OperationsManager', N'Stock.View'),
        (N'OperationsManager', N'SupplierOrders.View'),
        (N'OperationsManager', N'SupplierPayments.ApproveReversal'),
        (N'OperationsManager', N'SupplierPayments.Capture'),
        (N'OperationsManager', N'SupplierPayments.Reverse'),
        (N'OperationsManager', N'SupplierPayments.View'),
        (N'OperationsManager', N'Suppliers.View'),
        (N'OperationsManager', N'SystemSettings.View'),
        (N'OperationsManager', N'Users.View'),
        (N'OperationsManager', N'WarehouseSections.View'),
        (N'BusinessManager', N'BuyingList.Assign'),
        (N'BusinessManager', N'BuyingList.Cancel'),
        (N'BusinessManager', N'BuyingList.Create'),
        (N'BusinessManager', N'BuyingList.DeleteDraft'),
        (N'BusinessManager', N'BuyingList.Publish'),
        (N'BusinessManager', N'BuyingList.UpdateDraft'),
        (N'BusinessManager', N'BuyingList.View'),
        (N'BusinessManager', N'BuyingList.ViewAll'),
        (N'BusinessManager', N'Customers.View'),
        (N'BusinessManager', N'Dashboards.View'),
        (N'BusinessManager', N'Help.View'),
        (N'BusinessManager', N'Invoices.View'),
        (N'BusinessManager', N'Mobile.Access'),
        (N'BusinessManager', N'Mobile.BuyingList.Assign'),
        (N'BusinessManager', N'Mobile.BuyingList.Create'),
        (N'BusinessManager', N'Mobile.BuyingList.Update'),
        (N'BusinessManager', N'Mobile.BuyingList.View'),
        (N'BusinessManager', N'Mobile.BuyingList.ViewAll'),
        (N'BusinessManager', N'Mobile.Dispatch.View'),
        (N'BusinessManager', N'Mobile.Help.View'),
        (N'BusinessManager', N'Mobile.Notification.View'),
        (N'BusinessManager', N'Mobile.Profile.View'),
        (N'BusinessManager', N'Mobile.Tracking.ViewAll'),
        (N'BusinessManager', N'Notifications.ManagePreferences'),
        (N'BusinessManager', N'Notifications.View'),
        (N'BusinessManager', N'OperationsCalendar.View'),
        (N'BusinessManager', N'Orders.Cancel'),
        (N'BusinessManager', N'Orders.Confirm'),
        (N'BusinessManager', N'Orders.Create'),
        (N'BusinessManager', N'Orders.SendLink'),
        (N'BusinessManager', N'Orders.Update'),
        (N'BusinessManager', N'Orders.Validate'),
        (N'BusinessManager', N'Orders.View'),
        (N'BusinessManager', N'Pricing.View'),
        (N'BusinessManager', N'RawStock.View'),
        (N'BusinessManager', N'SupplierOrders.Manage'),
        (N'BusinessManager', N'SupplierOrders.View'),
        (N'BusinessManager', N'Suppliers.Manage'),
        (N'BusinessManager', N'Suppliers.View'),
        (N'Admin', N'AuditLogs.View'),
        (N'Admin', N'Customers.Manage'),
        (N'Admin', N'Customers.View'),
        (N'Admin', N'Dashboards.View'),
        (N'Admin', N'Help.Manage'),
        (N'Admin', N'Help.View'),
        (N'Admin', N'HelpMedia.Manage'),
        (N'Admin', N'Invoices.View'),
        (N'Admin', N'Lookups.Manage'),
        (N'Admin', N'Lookups.View'),
        (N'Admin', N'Notifications.ManagePreferences'),
        (N'Admin', N'Notifications.View'),
        (N'Admin', N'Orders.View'),
        (N'Admin', N'Permissions.Create'),
        (N'Admin', N'Permissions.Deactivate'),
        (N'Admin', N'Permissions.Delete'),
        (N'Admin', N'Permissions.Update'),
        (N'Admin', N'Permissions.View'),
        (N'Admin', N'Pricing.Manage'),
        (N'Admin', N'Pricing.View'),
        (N'Admin', N'Products.View'),
        (N'Admin', N'Roles.AssignPermissions'),
        (N'Admin', N'Roles.Create'),
        (N'Admin', N'Roles.Deactivate'),
        (N'Admin', N'Roles.Delete'),
        (N'Admin', N'Roles.Update'),
        (N'Admin', N'Roles.View'),
        (N'Admin', N'SystemSettings.Manage'),
        (N'Admin', N'SystemSettings.View'),
        (N'Admin', N'Users.AssignRole'),
        (N'Admin', N'Users.Create'),
        (N'Admin', N'Users.Deactivate'),
        (N'Admin', N'Users.Reactivate'),
        (N'Admin', N'Users.TriggerPasswordReset'),
        (N'Admin', N'Users.Update'),
        (N'Admin', N'Users.View'),
        (N'Admin', N'Users.ViewEffectivePermissions'),
        (N'Admin', N'WarehouseSections.Manage'),
        (N'Admin', N'WarehouseSections.View'),
        (N'WarehouseManager', N'Dashboards.View'),
        (N'WarehouseManager', N'Deliveries.AssignDriver'),
        (N'WarehouseManager', N'Deliveries.CompleteAny'),
        (N'WarehouseManager', N'Deliveries.ReassignDriver'),
        (N'WarehouseManager', N'Deliveries.View'),
        (N'WarehouseManager', N'Deliveries.ViewProof'),
        (N'WarehouseManager', N'Expiry.Resolve'),
        (N'WarehouseManager', N'Expiry.View'),
        (N'WarehouseManager', N'Help.View'),
        (N'WarehouseManager', N'Labels.Print'),
        (N'WarehouseManager', N'Lookups.View'),
        (N'WarehouseManager', N'Mobile.Access'),
        (N'WarehouseManager', N'Mobile.Dispatch.Confirm'),
        (N'WarehouseManager', N'Mobile.Dispatch.Reject'),
        (N'WarehouseManager', N'Mobile.Dispatch.View'),
        (N'WarehouseManager', N'Mobile.Help.View'),
        (N'WarehouseManager', N'Mobile.Notification.View'),
        (N'WarehouseManager', N'Mobile.Packing.View'),
        (N'WarehouseManager', N'Mobile.Profile.View'),
        (N'WarehouseManager', N'Mobile.StockReceipt.Create'),
        (N'WarehouseManager', N'Mobile.StockReceipt.Submit'),
        (N'WarehouseManager', N'Mobile.StockReceipt.UploadDocket'),
        (N'WarehouseManager', N'Mobile.StockReceipt.View'),
        (N'WarehouseManager', N'Mobile.WriteOff.Complete'),
        (N'WarehouseManager', N'Mobile.WriteOff.Create'),
        (N'WarehouseManager', N'Mobile.WriteOff.UploadEvidence'),
        (N'WarehouseManager', N'Mobile.WriteOff.View'),
        (N'WarehouseManager', N'Mobile.WriteOff.ViewFinancialImpact'),
        (N'WarehouseManager', N'Notifications.ManagePreferences'),
        (N'WarehouseManager', N'Notifications.View'),
        (N'WarehouseManager', N'OperationalReasons.View'),
        (N'WarehouseManager', N'OperationsCalendar.View'),
        (N'WarehouseManager', N'Orders.ChangeStatus'),
        (N'WarehouseManager', N'Orders.View'),
        (N'WarehouseManager', N'Packing.Confirm'),
        (N'WarehouseManager', N'Packing.View'),
        (N'WarehouseManager', N'ProductBatchScanner.View'),
        (N'WarehouseManager', N'ProductCategories.Manage'),
        (N'WarehouseManager', N'ProductCategories.View'),
        (N'WarehouseManager', N'ProductDataExchange.Export'),
        (N'WarehouseManager', N'ProductDataExchange.Import'),
        (N'WarehouseManager', N'ProductHierarchy.Manage'),
        (N'WarehouseManager', N'ProductHierarchy.View'),
        (N'WarehouseManager', N'Products.ChangeStatus'),
        (N'WarehouseManager', N'Products.Delete'),
        (N'WarehouseManager', N'Products.Make'),
        (N'WarehouseManager', N'Products.Update'),
        (N'WarehouseManager', N'Products.View'),
        (N'WarehouseManager', N'ProductTypes.Manage'),
        (N'WarehouseManager', N'ProductTypes.View'),
        (N'WarehouseManager', N'RawStock.Manage'),
        (N'WarehouseManager', N'RawStock.Receive'),
        (N'WarehouseManager', N'RawStock.View'),
        (N'WarehouseManager', N'RawStock.WriteOff'),
        (N'WarehouseManager', N'RawStockTakes.Capture'),
        (N'WarehouseManager', N'RawStockTakes.Review'),
        (N'WarehouseManager', N'RawStockTakes.View'),
        (N'WarehouseManager', N'Reconciliation.Manage'),
        (N'WarehouseManager', N'Reconciliation.View'),
        (N'WarehouseManager', N'Stock.Adjust'),
        (N'WarehouseManager', N'Stock.Take'),
        (N'WarehouseManager', N'Stock.View'),
        (N'WarehouseManager', N'Stock.WriteOff'),
        (N'WarehouseManager', N'StockCountExchange.Export'),
        (N'WarehouseManager', N'StockCountExchange.Import'),
        (N'WarehouseManager', N'SupplierOrders.View'),
        (N'WarehouseManager', N'Suppliers.View'),
        (N'WarehouseManager', N'WarehouseSections.Manage'),
        (N'WarehouseManager', N'WarehouseSections.View'),
        (N'Packer', N'Dashboards.View'),
        (N'Packer', N'Expiry.View'),
        (N'Packer', N'Help.View'),
        (N'Packer', N'Labels.Print'),
        (N'Packer', N'Mobile.Access'),
        (N'Packer', N'Mobile.Help.View'),
        (N'Packer', N'Mobile.Notification.View'),
        (N'Packer', N'Mobile.Packing.Complete'),
        (N'Packer', N'Mobile.Packing.RemoveScan'),
        (N'Packer', N'Mobile.Packing.Scan'),
        (N'Packer', N'Mobile.Packing.View'),
        (N'Packer', N'Mobile.Profile.View'),
        (N'Packer', N'Notifications.ManagePreferences'),
        (N'Packer', N'Notifications.View'),
        (N'Packer', N'Orders.View'),
        (N'Packer', N'Packing.View'),
        (N'Packer', N'ProductBatchScanner.View'),
        (N'Packer', N'Products.View'),
        (N'Packer', N'Stock.View'),
        (N'Driver', N'Dashboards.View'),
        (N'Driver', N'Deliveries.CompleteOwn'),
        (N'Driver', N'Deliveries.ViewOwn'),
        (N'Driver', N'Deliveries.ViewProof'),
        (N'Driver', N'Help.View'),
        (N'Driver', N'Mobile.Access'),
        (N'Driver', N'Mobile.Delivery.CompleteOwn'),
        (N'Driver', N'Mobile.Delivery.UpdateOwn'),
        (N'Driver', N'Mobile.Delivery.UploadProof'),
        (N'Driver', N'Mobile.Delivery.ViewOwn'),
        (N'Driver', N'Mobile.Help.View'),
        (N'Driver', N'Mobile.Notification.View'),
        (N'Driver', N'Mobile.Profile.View'),
        (N'Driver', N'Mobile.Tracking.ShareOwn'),
        (N'Driver', N'Mobile.Tracking.ViewOwn'),
        (N'Driver', N'Notifications.ManagePreferences'),
        (N'Driver', N'Notifications.View'),
        (N'MarketBuyer', N'Dashboards.View'),
        (N'MarketBuyer', N'Help.View'),
        (N'MarketBuyer', N'Mobile.Access'),
        (N'MarketBuyer', N'Mobile.BuyingList.AddPromotionalItem'),
        (N'MarketBuyer', N'Mobile.BuyingList.Submit'),
        (N'MarketBuyer', N'Mobile.BuyingList.Update'),
        (N'MarketBuyer', N'Mobile.BuyingList.UploadDocket'),
        (N'MarketBuyer', N'Mobile.BuyingList.View'),
        (N'MarketBuyer', N'Mobile.Help.View'),
        (N'MarketBuyer', N'Mobile.Notification.View'),
        (N'MarketBuyer', N'Mobile.Profile.View'),
        (N'MarketBuyer', N'Notifications.ManagePreferences'),
        (N'MarketBuyer', N'Notifications.View'),
        (N'MarketBuyer', N'Products.View'),
        (N'MarketBuyer', N'RawStock.View'),
        (N'MarketBuyer', N'Suppliers.View');
    IF EXISTS
    (
        SELECT 1
        FROM @DesiredRolePermissions AS desired
        LEFT JOIN dbo.Permissions AS permission
            ON permission.PermissionCode = desired.PermissionCode
        WHERE permission.PermissionId IS NULL
    )
    BEGIN
        THROW 51000, 'The role refactor requires a permission that is missing from the catalogue.', 1;
    END;
    IF EXISTS
    (
        SELECT 1
        FROM @DesiredRolePermissions AS desired
        LEFT JOIN dbo.Roles AS role
            ON role.RoleCode = desired.RoleCode
        WHERE role.RoleId IS NULL
    )
    BEGIN
        THROW 51001, 'The role refactor requires a role that is missing from the catalogue.', 1;
    END;
    DELETE rolePermission
    FROM dbo.RolePermissions AS rolePermission
    INNER JOIN dbo.Roles AS role
        ON role.RoleId = rolePermission.RoleId
    WHERE role.RoleCode IN
    (
        N'OperationsManager',
        N'BusinessManager',
        N'Admin',
        N'WarehouseManager',
        N'Packer',
        N'Driver',
        N'MarketBuyer'
    );
    INSERT INTO dbo.RolePermissions
    (
        RoleId,
        PermissionId,
        AssignedAtUtc,
        AssignedByUserId
    )
    SELECT
        role.RoleId,
        permission.PermissionId,
        SYSUTCDATETIME(),
        NULL
    FROM @DesiredRolePermissions AS desired
    INNER JOIN dbo.Roles AS role
        ON role.RoleCode = desired.RoleCode
    INNER JOIN dbo.Permissions AS permission
        ON permission.PermissionCode = desired.PermissionCode;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpContextMappings] SET [ComponentKey] = N''RoleDashboard'', [RoutePattern] = N''/dashboard''
    WHERE [HelpContextMappingId] = 3;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 1;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 2;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 3;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 4;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 5;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 6;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 7;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''WarehouseManager,Admin,Packer''
    WHERE [HelpTopicId] = 8;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer''
    WHERE [HelpTopicId] = 9;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 10;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''WarehouseManager,Packer''
    WHERE [HelpTopicId] = 11;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,WarehouseManager''
    WHERE [HelpTopicId] = 12;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,WarehouseManager''
    WHERE [HelpTopicId] = 13;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 14;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 15;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 16;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 17;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 18;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 19;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 20;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,WarehouseManager,Packer''
    WHERE [HelpTopicId] = 21;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 22;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,Admin''
    WHERE [HelpTopicId] = 23;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 24;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,WarehouseManager,Driver''
    WHERE [HelpTopicId] = 26;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 27;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 28;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 29;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager''
    WHERE [HelpTopicId] = 30;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 31;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [AudienceRolesCsv] = N''OperationsManager,BusinessManager,Admin,WarehouseManager,Packer,Driver,MarketBuyer''
    WHERE [HelpTopicId] = 32;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [SystemSettings] SET [DefaultValue] = N''["OperationsManager","WarehouseManager"]'', [Value] = N''["OperationsManager","WarehouseManager"]''
    WHERE [SystemSettingId] = 6;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [SystemSettings] SET [Description] = N''Maximum estimated loss a Warehouse Manager may complete without Operations Manager approval.'', [DisplayName] = N''Warehouse Manager value limit'', [Key] = N''WriteOff.WarehouseManagerMaximumValue''
    WHERE [SystemSettingId] = 40;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'UPDATE [SystemSettings] SET [Description] = N''Maximum quantity a Warehouse Manager may complete without Operations Manager approval.'', [DisplayName] = N''Warehouse Manager quantity limit'', [Key] = N''WriteOff.WarehouseManagerMaximumQuantity''
    WHERE [SystemSettingId] = 41;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    EXEC(N'CREATE INDEX [IX_SalesOrders_PackingCompletionOperationKeyHash] ON [SalesOrders] ([PackingCompletionOperationKeyHash]) WHERE [PackingCompletionOperationKeyHash] IS NOT NULL');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802005731_RoleNavigationWorkflowRefactor'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260802005731_RoleNavigationWorkflowRefactor', N'8.0.0');
END;
GO

COMMIT;
GO

