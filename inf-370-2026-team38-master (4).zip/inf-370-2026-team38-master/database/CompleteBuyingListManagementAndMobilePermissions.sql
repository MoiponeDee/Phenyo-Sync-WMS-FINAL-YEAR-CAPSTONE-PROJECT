USE WMS_DB
go
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET ARITHABORT ON;
SET NUMERIC_ROUNDABORT OFF;
GO

IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [Permissions] (
        [PermissionId] int NOT NULL IDENTITY,
        [PermissionName] nvarchar(100) NOT NULL,
        CONSTRAINT [PK_Permissions] PRIMARY KEY ([PermissionId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [Roles] (
        [RoleId] int NOT NULL IDENTITY,
        [RoleName] nvarchar(50) NOT NULL,
        CONSTRAINT [PK_Roles] PRIMARY KEY ([RoleId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [Suppliers] (
        [SupplierId] int NOT NULL IDENTITY,
        [SupplierName] nvarchar(max) NOT NULL,
        [ContactPerson] nvarchar(max) NULL,
        [Email] nvarchar(max) NULL,
        [Phone] nvarchar(max) NULL,
        [Address] nvarchar(max) NULL,
        [Status] nvarchar(max) NOT NULL,
        CONSTRAINT [PK_Suppliers] PRIMARY KEY ([SupplierId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [WarehouseSections] (
        [SectionId] int NOT NULL IDENTITY,
        [SectionName] nvarchar(max) NOT NULL,
        [Description] nvarchar(max) NULL,
        [Status] nvarchar(max) NOT NULL,
        CONSTRAINT [PK_WarehouseSections] PRIMARY KEY ([SectionId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [RolePermissions] (
        [RoleId] int NOT NULL,
        [PermissionId] int NOT NULL,
        CONSTRAINT [PK_RolePermissions] PRIMARY KEY ([RoleId], [PermissionId]),
        CONSTRAINT [FK_RolePermissions_Permissions_PermissionId] FOREIGN KEY ([PermissionId]) REFERENCES [Permissions] ([PermissionId]) ON DELETE CASCADE,
        CONSTRAINT [FK_RolePermissions_Roles_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [Roles] ([RoleId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [Users] (
        [UserId] int NOT NULL IDENTITY,
        [Email] nvarchar(100) NOT NULL,
        [PasswordHash] nvarchar(max) NOT NULL,
        [FirstName] nvarchar(50) NOT NULL,
        [LastName] nvarchar(50) NOT NULL,
        [PhoneNumber] nvarchar(20) NULL,
        [RoleId] int NOT NULL,
        [Status] nvarchar(max) NOT NULL,
        [CreatedDate] datetime2 NOT NULL,
        CONSTRAINT [PK_Users] PRIMARY KEY ([UserId]),
        CONSTRAINT [FK_Users_Roles_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [Roles] ([RoleId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [SupplierOrders] (
        [SupplierOrderId] int NOT NULL IDENTITY,
        [SupplierId] int NOT NULL,
        [OrderDate] datetime2 NOT NULL,
        [TotalAmount] decimal(18,2) NOT NULL,
        CONSTRAINT [PK_SupplierOrders] PRIMARY KEY ([SupplierOrderId]),
        CONSTRAINT [FK_SupplierOrders_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [Stocks] (
        [StockId] int NOT NULL IDENTITY,
        [ProductId] int NOT NULL,
        [SectionId] int NOT NULL,
        [QuantityAvailableKg] decimal(18,2) NOT NULL,
        [ReorderLevelKg] decimal(18,2) NOT NULL,
        [InventoryStatus] nvarchar(max) NOT NULL,
        [WarehouseSectionSectionId] int NOT NULL,
        CONSTRAINT [PK_Stocks] PRIMARY KEY ([StockId]),
        CONSTRAINT [FK_Stocks_WarehouseSections_WarehouseSectionSectionId] FOREIGN KEY ([WarehouseSectionSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [BusinessManagers] (
        [BusinessManagerId] int NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [Department] nvarchar(max) NOT NULL,
        [OfficeNumber] nvarchar(max) NULL,
        [ManagedSection] nvarchar(max) NULL,
        [EmploymentDate] datetime2 NULL,
        CONSTRAINT [PK_BusinessManagers] PRIMARY KEY ([BusinessManagerId]),
        CONSTRAINT [FK_BusinessManagers_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [CEOs] (
        [CEOId] int NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [OfficeNumber] nvarchar(max) NULL,
        [AppointmentDate] datetime2 NULL,
        CONSTRAINT [PK_CEOs] PRIMARY KEY ([CEOId]),
        CONSTRAINT [FK_CEOs_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [COOs] (
        [COOId] int NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [OfficeNumber] nvarchar(max) NULL,
        [AppointmentDate] datetime2 NULL,
        CONSTRAINT [PK_COOs] PRIMARY KEY ([COOId]),
        CONSTRAINT [FK_COOs_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [Drivers] (
        [DriverId] int NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [LicenseNumber] nvarchar(max) NOT NULL,
        [LicenseExpiryDate] datetime2 NULL,
        [VehicleAssigned] nvarchar(max) NULL,
        [AvailabilityStatus] nvarchar(max) NOT NULL,
        CONSTRAINT [PK_Drivers] PRIMARY KEY ([DriverId]),
        CONSTRAINT [FK_Drivers_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [Packers] (
        [PackerId] int NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [PackingStation] nvarchar(max) NOT NULL,
        [Shift] nvarchar(max) NOT NULL,
        [PackingArea] nvarchar(max) NULL,
        [EmploymentDate] datetime2 NULL,
        CONSTRAINT [PK_Packers] PRIMARY KEY ([PackerId]),
        CONSTRAINT [FK_Packers_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [StockTakers] (
        [StockTakerId] int NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [AssignedSection] nvarchar(max) NOT NULL,
        [Shift] nvarchar(max) NOT NULL,
        [LastStockTakeDate] datetime2 NULL,
        CONSTRAINT [PK_StockTakers] PRIMARY KEY ([StockTakerId]),
        CONSTRAINT [FK_StockTakers_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE TABLE [StockTakeSessions] (
        [SessionId] int NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [SectionId] int NOT NULL,
        [SessionDate] datetime2 NOT NULL,
        [Status] nvarchar(max) NOT NULL,
        [Notes] nvarchar(max) NULL,
        [WarehouseSectionSectionId] int NOT NULL,
        CONSTRAINT [PK_StockTakeSessions] PRIMARY KEY ([SessionId]),
        CONSTRAINT [FK_StockTakeSessions_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE,
        CONSTRAINT [FK_StockTakeSessions_WarehouseSections_WarehouseSectionSectionId] FOREIGN KEY ([WarehouseSectionSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_BusinessManagers_UserId] ON [BusinessManagers] ([UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_CEOs_UserId] ON [CEOs] ([UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_COOs_UserId] ON [COOs] ([UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Drivers_UserId] ON [Drivers] ([UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Packers_UserId] ON [Packers] ([UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_RolePermissions_PermissionId] ON [RolePermissions] ([PermissionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Stocks_WarehouseSectionSectionId] ON [Stocks] ([WarehouseSectionSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_StockTakers_UserId] ON [StockTakers] ([UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_StockTakeSessions_UserId] ON [StockTakeSessions] ([UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_StockTakeSessions_WarehouseSectionSectionId] ON [StockTakeSessions] ([WarehouseSectionSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_SupplierOrders_SupplierId] ON [SupplierOrders] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Users_RoleId] ON [Users] ([RoleId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011509_InitialCreate'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260511011509_InitialCreate', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260511011916_FreshDatabaseSetup'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260511011916_FreshDatabaseSetup', N'8.0.0');
END;
GO

COMMIT;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722202808_Subsystem7Completion'
)
BEGIN
    /*
      PhenyoSync WMS - INF370 Subsystem 7
      Safe, idempotent SQL Server deployment for existing WMS_DB installations.
      This script never drops Product, ProductType, ProductCategory, or their data.
    */
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        IF OBJECT_ID(N'dbo.ProductType', N'U') IS NULL
        BEGIN
            CREATE TABLE dbo.ProductType (
                ProductTypeId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ProductType PRIMARY KEY,
                ProductTypeName NVARCHAR(100) NOT NULL,
                Description NVARCHAR(255) NULL,
                Status NVARCHAR(20) NOT NULL CONSTRAINT DF_ProductType_Status DEFAULT N'Active',
                CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_ProductType_CreatedAt DEFAULT SYSUTCDATETIME(),
                UpdatedAt DATETIME2 NULL
            );
        END;
        IF OBJECT_ID(N'dbo.ProductCategory', N'U') IS NULL
        BEGIN
            CREATE TABLE dbo.ProductCategory (
                ProductCategoryId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ProductCategory PRIMARY KEY,
                ProductCategoryName NVARCHAR(100) NOT NULL,
                Description NVARCHAR(255) NULL,
                Status NVARCHAR(20) NOT NULL CONSTRAINT DF_ProductCategory_Status DEFAULT N'Active',
                CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_ProductCategory_CreatedAt DEFAULT SYSUTCDATETIME(),
                UpdatedAt DATETIME2 NULL
            );
        END;
        IF OBJECT_ID(N'dbo.Product', N'U') IS NULL
        BEGIN
            CREATE TABLE dbo.Product (
                ProductId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Product PRIMARY KEY,
                ProductName NVARCHAR(150) NOT NULL,
                ProductTypeId INT NOT NULL,
                ProductCategoryId INT NOT NULL,
                Size NVARCHAR(50) NOT NULL,
                ShelfLifeDays INT NOT NULL,
                QRCodeValue NVARCHAR(500) NULL,
                Status NVARCHAR(20) NOT NULL CONSTRAINT DF_Product_Status DEFAULT N'Active',
                CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_Product_CreatedAt DEFAULT SYSUTCDATETIME(),
                UpdatedAt DATETIME2 NULL,
                CONSTRAINT FK_Product_ProductType_ProductTypeId FOREIGN KEY (ProductTypeId)
                    REFERENCES dbo.ProductType(ProductTypeId),
                CONSTRAINT FK_Product_ProductCategory_ProductCategoryId FOREIGN KEY (ProductCategoryId)
                    REFERENCES dbo.ProductCategory(ProductCategoryId)
            );
        END;
        IF OBJECT_ID(N'dbo.WarehouseSections', N'U') IS NULL
        BEGIN
            CREATE TABLE dbo.WarehouseSections (
                SectionId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WarehouseSections PRIMARY KEY,
                SectionName NVARCHAR(150) NOT NULL,
                Description NVARCHAR(500) NULL,
                Status NVARCHAR(20) NOT NULL CONSTRAINT DF_WarehouseSections_Status DEFAULT N'Active'
            );
        END;
        IF NOT EXISTS (SELECT 1 FROM dbo.WarehouseSections)
        BEGIN
            INSERT dbo.WarehouseSections (SectionName, Description, Status)
            VALUES (N'Default Production', N'Default section for production batches and aggregate stock.', N'Active');
        END;
        IF COL_LENGTH(N'dbo.Users', N'PasswordResetTokenHash') IS NULL
            ALTER TABLE dbo.Users ADD PasswordResetTokenHash NVARCHAR(256) NULL;
        IF COL_LENGTH(N'dbo.Users', N'PasswordResetTokenExpiry') IS NULL
            ALTER TABLE dbo.Users ADD PasswordResetTokenExpiry DATETIME2 NULL;
        IF OBJECT_ID(N'dbo.Stocks', N'U') IS NULL
        BEGIN
            CREATE TABLE dbo.Stocks (
                StockId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Stocks PRIMARY KEY,
                ProductId INT NOT NULL,
                SectionId INT NOT NULL,
                QuantityAvailableKg DECIMAL(18,2) NOT NULL CONSTRAINT DF_Stocks_Quantity DEFAULT 0,
                ReorderLevelKg DECIMAL(18,2) NOT NULL CONSTRAINT DF_Stocks_Reorder DEFAULT 0,
                InventoryStatus NVARCHAR(40) NOT NULL CONSTRAINT DF_Stocks_Status DEFAULT N'Available'
            );
        END;
        /* Remove the earlier EF shadow column only after its foreign key and indexes are removed. */
        IF COL_LENGTH(N'dbo.Stocks', N'WarehouseSectionSectionId') IS NOT NULL
        BEGIN
            DECLARE @shadowFk SYSNAME;
            SELECT TOP (1) @shadowFk = fk.name
            FROM sys.foreign_keys fk
            JOIN sys.foreign_key_columns fkc ON fkc.constraint_object_id = fk.object_id
            JOIN sys.columns c ON c.object_id = fkc.parent_object_id AND c.column_id = fkc.parent_column_id
            WHERE fk.parent_object_id = OBJECT_ID(N'dbo.Stocks') AND c.name = N'WarehouseSectionSectionId';
            IF @shadowFk IS NOT NULL
            BEGIN
                DECLARE @dropShadowFkSql NVARCHAR(MAX) =
                    N'ALTER TABLE dbo.Stocks DROP CONSTRAINT ' + QUOTENAME(@shadowFk) + N';';
                EXEC sys.sp_executesql @dropShadowFkSql;
            END;
            DECLARE @shadowIndex SYSNAME;
            WHILE EXISTS (
                SELECT 1 FROM sys.indexes i
                JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
                JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                WHERE i.object_id = OBJECT_ID(N'dbo.Stocks') AND c.name = N'WarehouseSectionSectionId'
            )
            BEGIN
                SELECT TOP (1) @shadowIndex = i.name
                FROM sys.indexes i
                JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
                JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                WHERE i.object_id = OBJECT_ID(N'dbo.Stocks') AND c.name = N'WarehouseSectionSectionId';
                DECLARE @dropShadowIndexSql NVARCHAR(MAX) =
                    N'DROP INDEX ' + QUOTENAME(@shadowIndex) + N' ON dbo.Stocks;';
                EXEC sys.sp_executesql @dropShadowIndexSql;
            END;
            ALTER TABLE dbo.Stocks DROP COLUMN WarehouseSectionSectionId;
        END;
        IF OBJECT_ID(N'dbo.ProductBatches', N'U') IS NULL
        BEGIN
            CREATE TABLE dbo.ProductBatches (
                ProductBatchId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ProductBatches PRIMARY KEY,
                ProductId INT NOT NULL,
                SectionId INT NOT NULL,
                BatchCode NVARCHAR(64) NOT NULL,
                QRCodeValue NVARCHAR(500) NOT NULL,
                QuantityProducedKg DECIMAL(18,2) NOT NULL,
                QuantityRemainingKg DECIMAL(18,2) NOT NULL,
                PackedAtUtc DATETIME2 NOT NULL,
                OriginalExpiryAtUtc DATETIME2 NOT NULL,
                EffectiveExpiryAtUtc DATETIME2 NOT NULL,
                Status NVARCHAR(40) NOT NULL,
                ShelfLifeExtended BIT NOT NULL CONSTRAINT DF_ProductBatches_Extended DEFAULT 0,
                ShelfLifeExtendedAtUtc DATETIME2 NULL,
                ShelfLifeExtendedByUserId INT NULL,
                ShelfLifeExtensionReason NVARCHAR(500) NULL,
                YellowAlertSentAtUtc DATETIME2 NULL,
                RedAlertSentAtUtc DATETIME2 NULL,
                AvailableQuantityRemovedAtUtc DATETIME2 NULL,
                CreatedAtUtc DATETIME2 NOT NULL CONSTRAINT DF_ProductBatches_Created DEFAULT SYSUTCDATETIME(),
                UpdatedAtUtc DATETIME2 NULL,
                CONSTRAINT FK_ProductBatches_Product_ProductId FOREIGN KEY (ProductId) REFERENCES dbo.Product(ProductId),
                CONSTRAINT FK_ProductBatches_WarehouseSections_SectionId FOREIGN KEY (SectionId) REFERENCES dbo.WarehouseSections(SectionId),
                CONSTRAINT FK_ProductBatches_Users_ShelfLifeExtendedByUserId FOREIGN KEY (ShelfLifeExtendedByUserId) REFERENCES dbo.Users(UserId),
                CONSTRAINT CK_ProductBatches_Quantities CHECK (QuantityProducedKg > 0 AND QuantityRemainingKg >= 0 AND QuantityRemainingKg <= QuantityProducedKg),
                CONSTRAINT CK_ProductBatches_Expiry CHECK (OriginalExpiryAtUtc > PackedAtUtc AND EffectiveExpiryAtUtc > PackedAtUtc)
            );
        END;
        IF OBJECT_ID(N'dbo.StockMovements', N'U') IS NULL
        BEGIN
            CREATE TABLE dbo.StockMovements (
                StockMovementId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_StockMovements PRIMARY KEY,
                ProductId INT NOT NULL,
                ProductBatchId INT NOT NULL,
                SectionId INT NOT NULL,
                MovementType NVARCHAR(30) NOT NULL,
                QuantityKg DECIMAL(18,2) NOT NULL,
                OccurredAtUtc DATETIME2 NOT NULL,
                CreatedByUserId INT NULL,
                Reason NVARCHAR(500) NULL,
                CONSTRAINT FK_StockMovements_Product_ProductId FOREIGN KEY (ProductId) REFERENCES dbo.Product(ProductId),
                CONSTRAINT FK_StockMovements_ProductBatches_ProductBatchId FOREIGN KEY (ProductBatchId) REFERENCES dbo.ProductBatches(ProductBatchId),
                CONSTRAINT FK_StockMovements_WarehouseSections_SectionId FOREIGN KEY (SectionId) REFERENCES dbo.WarehouseSections(SectionId),
                CONSTRAINT FK_StockMovements_Users_CreatedByUserId FOREIGN KEY (CreatedByUserId) REFERENCES dbo.Users(UserId),
                CONSTRAINT CK_StockMovements_Quantity CHECK (QuantityKg > 0)
            );
        END;
        IF OBJECT_ID(N'dbo.ExpiryActionTokens', N'U') IS NULL
        BEGIN
            CREATE TABLE dbo.ExpiryActionTokens (
                ExpiryActionTokenId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ExpiryActionTokens PRIMARY KEY,
                ProductBatchId INT NOT NULL,
                TokenHash NVARCHAR(64) NOT NULL,
                AlertLevel NVARCHAR(30) NOT NULL,
                CreatedAtUtc DATETIME2 NOT NULL,
                ExpiresAtUtc DATETIME2 NOT NULL,
                UsedAtUtc DATETIME2 NULL,
                InvalidatedAtUtc DATETIME2 NULL,
                CONSTRAINT FK_ExpiryActionTokens_ProductBatches_ProductBatchId FOREIGN KEY (ProductBatchId) REFERENCES dbo.ProductBatches(ProductBatchId)
            );
        END;
        IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Stocks_Product_ProductId')
            ALTER TABLE dbo.Stocks WITH CHECK ADD CONSTRAINT FK_Stocks_Product_ProductId FOREIGN KEY (ProductId) REFERENCES dbo.Product(ProductId);
        IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Stocks_WarehouseSections_SectionId')
            ALTER TABLE dbo.Stocks WITH CHECK ADD CONSTRAINT FK_Stocks_WarehouseSections_SectionId FOREIGN KEY (SectionId) REFERENCES dbo.WarehouseSections(SectionId);
        IF EXISTS (SELECT ProductName, ProductTypeId, ProductCategoryId, Size FROM dbo.Product GROUP BY ProductName, ProductTypeId, ProductCategoryId, Size HAVING COUNT(*) > 1)
            THROW 51001, 'Duplicate composite product SKUs must be resolved before creating UX_Product_CompositeSku.', 1;
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Product') AND name = N'UX_Product_CompositeSku')
            CREATE UNIQUE INDEX UX_Product_CompositeSku ON dbo.Product(ProductName, ProductTypeId, ProductCategoryId, Size);
        IF EXISTS (SELECT ProductTypeName FROM dbo.ProductType GROUP BY ProductTypeName HAVING COUNT(*) > 1)
            THROW 51002, 'Duplicate product type names must be resolved before creating UX_ProductType_Name.', 1;
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductType') AND name = N'UX_ProductType_Name')
            CREATE UNIQUE INDEX UX_ProductType_Name ON dbo.ProductType(ProductTypeName);
        IF EXISTS (SELECT ProductCategoryName FROM dbo.ProductCategory GROUP BY ProductCategoryName HAVING COUNT(*) > 1)
            THROW 51003, 'Duplicate product category names must be resolved before creating UX_ProductCategory_Name.', 1;
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductCategory') AND name = N'UX_ProductCategory_Name')
            CREATE UNIQUE INDEX UX_ProductCategory_Name ON dbo.ProductCategory(ProductCategoryName);
        IF EXISTS (SELECT ProductId, SectionId FROM dbo.Stocks GROUP BY ProductId, SectionId HAVING COUNT(*) > 1)
            THROW 51004, 'Duplicate aggregate stock rows must be resolved before creating UX_Stocks_Product_Section.', 1;
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Stocks') AND name = N'UX_Stocks_Product_Section')
            CREATE UNIQUE INDEX UX_Stocks_Product_Section ON dbo.Stocks(ProductId, SectionId);
        IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Stocks_Quantity_NonNegative')
            ALTER TABLE dbo.Stocks ADD CONSTRAINT CK_Stocks_Quantity_NonNegative CHECK (QuantityAvailableKg >= 0 AND ReorderLevelKg >= 0);
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductBatches') AND name = N'UX_ProductBatches_BatchCode')
            CREATE UNIQUE INDEX UX_ProductBatches_BatchCode ON dbo.ProductBatches(BatchCode);
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductBatches') AND name = N'UX_ProductBatches_QRCodeValue')
            CREATE UNIQUE INDEX UX_ProductBatches_QRCodeValue ON dbo.ProductBatches(QRCodeValue);
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductBatches') AND name = N'IX_ProductBatches_Status_Expiry_Quantity')
            CREATE INDEX IX_ProductBatches_Status_Expiry_Quantity ON dbo.ProductBatches(Status, EffectiveExpiryAtUtc, QuantityRemainingKg);
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ProductBatches') AND name = N'IX_ProductBatches_Product_Section')
            CREATE INDEX IX_ProductBatches_Product_Section ON dbo.ProductBatches(ProductId, SectionId);
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.StockMovements') AND name = N'IX_StockMovements_Product_Section_Occurred')
            CREATE INDEX IX_StockMovements_Product_Section_Occurred ON dbo.StockMovements(ProductId, SectionId, OccurredAtUtc);
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.StockMovements') AND name = N'IX_StockMovements_Batch')
            CREATE INDEX IX_StockMovements_Batch ON dbo.StockMovements(ProductBatchId);
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ExpiryActionTokens') AND name = N'UX_ExpiryActionTokens_TokenHash')
            CREATE UNIQUE INDEX UX_ExpiryActionTokens_TokenHash ON dbo.ExpiryActionTokens(TokenHash);
        IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.ExpiryActionTokens') AND name = N'IX_ExpiryActionTokens_Batch_State')
            CREATE INDEX IX_ExpiryActionTokens_Batch_State ON dbo.ExpiryActionTokens(ProductBatchId, ExpiresAtUtc, UsedAtUtc, InvalidatedAtUtc);
        COMMIT TRANSACTION;
        PRINT 'Subsystem 7 database deployment completed successfully.';
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722202808_Subsystem7Completion'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260722202808_Subsystem7Completion', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    ALTER TABLE [Stocks] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    ALTER TABLE [StockMovements] ADD [SalesOrderId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    ALTER TABLE [Product] ADD [SellingPricePerKg] decimal(18,2) NOT NULL DEFAULT 0.0;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE TABLE [Customers] (
        [CustomerId] int NOT NULL IDENTITY,
        [CustomerNumber] nvarchar(30) NOT NULL,
        [CustomerName] nvarchar(150) NOT NULL,
        [Email] nvarchar(254) NOT NULL,
        [PhoneNumber] nvarchar(30) NULL,
        [BillingAddress] nvarchar(500) NULL,
        [DeliveryAddress] nvarchar(500) NULL,
        [Status] nvarchar(20) NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        CONSTRAINT [PK_Customers] PRIMARY KEY ([CustomerId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE TABLE [CustomerOrderLinks] (
        [CustomerOrderLinkId] bigint NOT NULL IDENTITY,
        [CustomerId] int NOT NULL,
        [TokenHash] nvarchar(64) NOT NULL,
        [CreatedByUserId] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        [UsedAtUtc] datetime2 NULL,
        [RevokedAtUtc] datetime2 NULL,
        [SalesOrderId] int NULL,
        [EmailSentAtUtc] datetime2 NULL,
        CONSTRAINT [PK_CustomerOrderLinks] PRIMARY KEY ([CustomerOrderLinkId]),
        CONSTRAINT [FK_CustomerOrderLinks_Customers_CustomerId] FOREIGN KEY ([CustomerId]) REFERENCES [Customers] ([CustomerId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_CustomerOrderLinks_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE TABLE [SalesOrders] (
        [SalesOrderId] int NOT NULL IDENTITY,
        [OrderNumber] nvarchar(30) NOT NULL,
        [CustomerId] int NOT NULL,
        [OrderDateUtc] datetime2 NOT NULL,
        [RequestedDeliveryDateUtc] datetime2 NULL,
        [DeliveryAddressSnapshot] nvarchar(500) NOT NULL,
        [BillingAddressSnapshot] nvarchar(500) NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [ValidationStatus] nvarchar(20) NOT NULL,
        [ValidationMessage] nvarchar(1000) NULL,
        [Subtotal] decimal(18,2) NOT NULL,
        [TaxAmount] decimal(18,2) NOT NULL,
        [TotalAmount] decimal(18,2) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [CreatedByUserId] int NULL,
        [CreatedViaOrderLinkId] bigint NULL,
        [ValidatedByUserId] int NULL,
        [ValidatedAtUtc] datetime2 NULL,
        [PackedByUserId] int NULL,
        [PackedAtUtc] datetime2 NULL,
        [CancelledByUserId] int NULL,
        [CancelledAtUtc] datetime2 NULL,
        [CancellationReason] nvarchar(500) NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_SalesOrders] PRIMARY KEY ([SalesOrderId]),
        CONSTRAINT [FK_SalesOrders_CustomerOrderLinks_CreatedViaOrderLinkId] FOREIGN KEY ([CreatedViaOrderLinkId]) REFERENCES [CustomerOrderLinks] ([CustomerOrderLinkId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SalesOrders_Customers_CustomerId] FOREIGN KEY ([CustomerId]) REFERENCES [Customers] ([CustomerId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SalesOrders_Users_CancelledByUserId] FOREIGN KEY ([CancelledByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SalesOrders_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SalesOrders_Users_PackedByUserId] FOREIGN KEY ([PackedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SalesOrders_Users_ValidatedByUserId] FOREIGN KEY ([ValidatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE TABLE [Invoices] (
        [InvoiceId] int NOT NULL IDENTITY,
        [InvoiceNumber] nvarchar(30) NOT NULL,
        [SalesOrderId] int NOT NULL,
        [IssuedAtUtc] datetime2 NOT NULL,
        [CustomerNameSnapshot] nvarchar(150) NOT NULL,
        [CustomerEmailSnapshot] nvarchar(254) NOT NULL,
        [BillingAddressSnapshot] nvarchar(500) NOT NULL,
        [Subtotal] decimal(18,2) NOT NULL,
        [TaxAmount] decimal(18,2) NOT NULL,
        [TotalAmount] decimal(18,2) NOT NULL,
        [Status] nvarchar(20) NOT NULL,
        CONSTRAINT [PK_Invoices] PRIMARY KEY ([InvoiceId]),
        CONSTRAINT [FK_Invoices_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE TABLE [OrderStatusHistory] (
        [OrderStatusHistoryId] bigint NOT NULL IDENTITY,
        [SalesOrderId] int NOT NULL,
        [PreviousStatus] nvarchar(30) NULL,
        [NewStatus] nvarchar(30) NOT NULL,
        [ChangedByUserId] int NULL,
        [ChangedAtUtc] datetime2 NOT NULL,
        [Reason] nvarchar(500) NULL,
        CONSTRAINT [PK_OrderStatusHistory] PRIMARY KEY ([OrderStatusHistoryId]),
        CONSTRAINT [FK_OrderStatusHistory_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_OrderStatusHistory_Users_ChangedByUserId] FOREIGN KEY ([ChangedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE TABLE [SalesOrderItems] (
        [SalesOrderItemId] int NOT NULL IDENTITY,
        [SalesOrderId] int NOT NULL,
        [ProductId] int NOT NULL,
        [ProductNameSnapshot] nvarchar(150) NOT NULL,
        [ProductSizeSnapshot] nvarchar(50) NOT NULL,
        [QuantityKg] decimal(18,2) NOT NULL,
        [UnitPricePerKg] decimal(18,2) NOT NULL,
        [LineTotal] decimal(18,2) NOT NULL,
        [IsActive] bit NOT NULL,
        [Notes] nvarchar(500) NULL,
        CONSTRAINT [PK_SalesOrderItems] PRIMARY KEY ([SalesOrderItemId]),
        CONSTRAINT [FK_SalesOrderItems_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SalesOrderItems_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE TABLE [OrderStockReservations] (
        [OrderStockReservationId] bigint NOT NULL IDENTITY,
        [SalesOrderId] int NOT NULL,
        [SalesOrderItemId] int NOT NULL,
        [ProductId] int NOT NULL,
        [StockId] int NOT NULL,
        [SectionId] int NOT NULL,
        [ProductBatchId] int NOT NULL,
        [QuantityReservedKg] decimal(18,2) NOT NULL,
        [Status] nvarchar(20) NOT NULL,
        [ReservedAtUtc] datetime2 NOT NULL,
        [ReleasedAtUtc] datetime2 NULL,
        [ConsumedAtUtc] datetime2 NULL,
        CONSTRAINT [PK_OrderStockReservations] PRIMARY KEY ([OrderStockReservationId]),
        CONSTRAINT [FK_OrderStockReservations_ProductBatches_ProductBatchId] FOREIGN KEY ([ProductBatchId]) REFERENCES [ProductBatches] ([ProductBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_OrderStockReservations_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_OrderStockReservations_SalesOrderItems_SalesOrderItemId] FOREIGN KEY ([SalesOrderItemId]) REFERENCES [SalesOrderItems] ([SalesOrderItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_OrderStockReservations_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_OrderStockReservations_Stocks_StockId] FOREIGN KEY ([StockId]) REFERENCES [Stocks] ([StockId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_OrderStockReservations_WarehouseSections_SectionId] FOREIGN KEY ([SectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_StockMovements_SalesOrderId] ON [StockMovements] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_CustomerOrderLinks_CreatedByUserId] ON [CustomerOrderLinks] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_CustomerOrderLinks_CustomerId_CreatedAtUtc] ON [CustomerOrderLinks] ([CustomerId], [CreatedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_CustomerOrderLinks_ExpiresAtUtc] ON [CustomerOrderLinks] ([ExpiresAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [IX_CustomerOrderLinks_SalesOrderId] ON [CustomerOrderLinks] ([SalesOrderId]) WHERE [SalesOrderId] IS NOT NULL');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE UNIQUE INDEX [IX_CustomerOrderLinks_TokenHash] ON [CustomerOrderLinks] ([TokenHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Customers_CustomerNumber] ON [Customers] ([CustomerNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_Customers_Email] ON [Customers] ([Email]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_Customers_Status_CustomerName] ON [Customers] ([Status], [CustomerName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Invoices_InvoiceNumber] ON [Invoices] ([InvoiceNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Invoices_SalesOrderId] ON [Invoices] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_OrderStatusHistory_ChangedByUserId] ON [OrderStatusHistory] ([ChangedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_OrderStatusHistory_SalesOrderId_ChangedAtUtc] ON [OrderStatusHistory] ([SalesOrderId], [ChangedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_OrderStockReservations_ProductBatchId_Status] ON [OrderStockReservations] ([ProductBatchId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_OrderStockReservations_ProductId] ON [OrderStockReservations] ([ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_OrderStockReservations_SalesOrderId_Status] ON [OrderStockReservations] ([SalesOrderId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_OrderStockReservations_SalesOrderItemId] ON [OrderStockReservations] ([SalesOrderItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_OrderStockReservations_SectionId] ON [OrderStockReservations] ([SectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_OrderStockReservations_StockId] ON [OrderStockReservations] ([StockId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrderItems_ProductId] ON [SalesOrderItems] ([ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [IX_SalesOrderItems_SalesOrderId_ProductId] ON [SalesOrderItems] ([SalesOrderId], [ProductId]) WHERE [IsActive] = 1');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_CancelledByUserId] ON [SalesOrders] ([CancelledByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_CreatedByUserId] ON [SalesOrders] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_CreatedViaOrderLinkId] ON [SalesOrders] ([CreatedViaOrderLinkId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_CustomerId] ON [SalesOrders] ([CustomerId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_OrderDateUtc] ON [SalesOrders] ([OrderDateUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE UNIQUE INDEX [IX_SalesOrders_OrderNumber] ON [SalesOrders] ([OrderNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_PackedByUserId] ON [SalesOrders] ([PackedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_Status] ON [SalesOrders] ([Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_ValidatedByUserId] ON [SalesOrders] ([ValidatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_ValidationStatus] ON [SalesOrders] ([ValidationStatus]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    ALTER TABLE [StockMovements] ADD CONSTRAINT [FK_StockMovements_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    ALTER TABLE [CustomerOrderLinks] ADD CONSTRAINT [FK_CustomerOrderLinks_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260722223550_Subsystem10OrderManagement'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260722223550_Subsystem10OrderManagement', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    ALTER TABLE [SalesOrderItems] ADD [ProductPriceId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    CREATE TABLE [ProductPrices] (
        [ProductPriceId] int NOT NULL IDENTITY,
        [ProductId] int NOT NULL,
        [SellingPrice] decimal(18,2) NOT NULL,
        [EffectiveFromUtc] datetime2 NOT NULL,
        [EffectiveToUtc] datetime2 NULL,
        [IsCurrent] bit NOT NULL,
        [IsDeleted] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [CreatedByUserId] int NULL,
        [ChangeReason] nvarchar(500) NULL,
        [DeletedAtUtc] datetime2 NULL,
        [DeletedByUserId] int NULL,
        [DeleteReason] nvarchar(500) NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_ProductPrices] PRIMARY KEY ([ProductPriceId]),
        CONSTRAINT [FK_ProductPrices_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductPrices_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductPrices_Users_DeletedByUserId] FOREIGN KEY ([DeletedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    INSERT INTO [ProductPrices]
        ([ProductId], [SellingPrice], [EffectiveFromUtc], [EffectiveToUtc],
         [IsCurrent], [IsDeleted], [CreatedAtUtc], [CreatedByUserId],
         [ChangeReason], [DeletedAtUtc], [DeletedByUserId], [DeleteReason])
    SELECT
        [ProductId],
        [SellingPricePerKg],
        COALESCE([UpdatedAt], [CreatedAt], SYSUTCDATETIME()),
        NULL,
        1,
        0,
        SYSUTCDATETIME(),
        NULL,
        N'Migrated from the legacy Product selling price.',
        NULL,
        NULL,
        NULL
    FROM [Product]
    WHERE [SellingPricePerKg] > 0;
    UPDATE orderItem
    SET [ProductPriceId] = price.[ProductPriceId]
    FROM [SalesOrderItems] AS orderItem
    INNER JOIN [ProductPrices] AS price
        ON price.[ProductId] = orderItem.[ProductId]
       AND price.[IsCurrent] = 1
       AND price.[IsDeleted] = 0;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    CREATE INDEX [IX_SalesOrderItems_ProductPriceId] ON [SalesOrderItems] ([ProductPriceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    CREATE INDEX [IX_ProductPrices_CreatedByUserId] ON [ProductPrices] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    CREATE INDEX [IX_ProductPrices_DeletedByUserId] ON [ProductPrices] ([DeletedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    CREATE INDEX [IX_ProductPrices_EffectiveFromUtc] ON [ProductPrices] ([EffectiveFromUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    CREATE INDEX [IX_ProductPrices_EffectiveToUtc] ON [ProductPrices] ([EffectiveToUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    CREATE INDEX [IX_ProductPrices_ProductId] ON [ProductPrices] ([ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    CREATE INDEX [IX_ProductPrices_SellingPrice] ON [ProductPrices] ([SellingPrice]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [UX_ProductPrices_Current] ON [ProductPrices] ([ProductId], [IsCurrent], [IsDeleted]) WHERE [IsCurrent] = 1 AND [IsDeleted] = 0');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    ALTER TABLE [SalesOrderItems] ADD CONSTRAINT [FK_SalesOrderItems_ProductPrices_ProductPriceId] FOREIGN KEY ([ProductPriceId]) REFERENCES [ProductPrices] ([ProductPriceId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723194113_Subsystem11Pricing'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260723194113_Subsystem11Pricing', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723195451_Subsystem11PricingConstraint'
)
BEGIN
    EXEC(N'ALTER TABLE [ProductPrices] ADD CONSTRAINT [CK_ProductPrices_Positive] CHECK ([SellingPrice] > 0)');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723195451_Subsystem11PricingConstraint'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260723195451_Subsystem11PricingConstraint', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    CREATE TABLE [AuditLogs] (
        [AuditLogId] bigint NOT NULL IDENTITY,
        [OccurredAtUtc] datetime2(7) NOT NULL,
        [UserId] int NULL,
        [UserEmailSnapshot] nvarchar(320) NULL,
        [UserDisplayNameSnapshot] nvarchar(200) NULL,
        [UserRoleSnapshot] nvarchar(100) NULL,
        [ActorType] nvarchar(32) NOT NULL,
        [ActionType] nvarchar(64) NOT NULL,
        [SystemModule] nvarchar(80) NOT NULL,
        [OperationName] nvarchar(160) NOT NULL,
        [EntityType] nvarchar(128) NULL,
        [EntityId] nvarchar(256) NULL,
        [EntityDisplay] nvarchar(500) NULL,
        [Description] nvarchar(1000) NOT NULL,
        [BeforeValuesJson] nvarchar(max) NULL,
        [AfterValuesJson] nvarchar(max) NULL,
        [ChangedFieldsJson] nvarchar(max) NULL,
        [Success] bit NOT NULL,
        [FailureReason] nvarchar(1000) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RequestPath] nvarchar(512) NULL,
        [HttpMethod] nvarchar(10) NULL,
        [IpAddress] nvarchar(64) NULL,
        [UserAgent] nvarchar(512) NULL,
        [EventSource] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_AuditLogs] PRIMARY KEY ([AuditLogId]),
        CONSTRAINT [CK_AuditLogs_BeforeValuesJson] CHECK ([BeforeValuesJson] IS NULL OR ISJSON([BeforeValuesJson]) = 1),
        CONSTRAINT [CK_AuditLogs_AfterValuesJson] CHECK ([AfterValuesJson] IS NULL OR ISJSON([AfterValuesJson]) = 1),
        CONSTRAINT [CK_AuditLogs_ChangedFieldsJson] CHECK ([ChangedFieldsJson] IS NULL OR ISJSON([ChangedFieldsJson]) = 1)
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_Action_OccurredAtUtc] ON [AuditLogs] ([ActionType], [OccurredAtUtc] DESC);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_CorrelationId] ON [AuditLogs] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_Entity] ON [AuditLogs] ([EntityType], [EntityId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_Module_OccurredAtUtc] ON [AuditLogs] ([SystemModule], [OccurredAtUtc] DESC);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_OccurredAtUtc] ON [AuditLogs] ([OccurredAtUtc] DESC);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_Success_OccurredAtUtc] ON [AuditLogs] ([Success], [OccurredAtUtc] DESC);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    CREATE INDEX [IX_AuditLogs_User_OccurredAtUtc] ON [AuditLogs] ([UserId], [OccurredAtUtc] DESC);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    EXEC(N'
        CREATE OR ALTER TRIGGER [dbo].[TR_AuditLogs_Immutable]
        ON [dbo].[AuditLogs]
        INSTEAD OF UPDATE, DELETE
        AS
        BEGIN
            SET NOCOUNT ON;
            THROW 51000,
                ''Audit logs are immutable and cannot be updated or deleted.'',
                1;
        END;
    ');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723204135_Subsystem14AuditLog'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260723204135_Subsystem14AuditLog', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    ALTER TABLE [Drivers] DROP CONSTRAINT [FK_Drivers_Users_UserId];
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    EXEC sp_rename N'[Drivers].[IX_Drivers_UserId]', N'UX_Drivers_UserId', N'INDEX';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    DECLARE @var0 sysname;
    SELECT @var0 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Drivers]') AND [c].[name] = N'AvailabilityStatus');
    IF @var0 IS NOT NULL EXEC(N'ALTER TABLE [Drivers] DROP CONSTRAINT [' + @var0 + '];');
    ALTER TABLE [Drivers] ALTER COLUMN [AvailabilityStatus] nvarchar(100) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE TABLE [Deliveries] (
        [DeliveryId] int NOT NULL IDENTITY,
        [SalesOrderId] int NOT NULL,
        [DeliveryAddressSnapshot] nvarchar(500) NOT NULL,
        [ScheduledStartUtc] datetime2 NOT NULL,
        [ScheduledEndUtc] datetime2 NOT NULL,
        [DriverId] int NULL,
        [Status] nvarchar(30) NOT NULL,
        [AssignedAtUtc] datetime2 NULL,
        [AssignedByUserId] int NULL,
        [StartedAtUtc] datetime2 NULL,
        [StartedByUserId] int NULL,
        [CompletedAtUtc] datetime2 NULL,
        [CompletedByUserId] int NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_Deliveries] PRIMARY KEY ([DeliveryId]),
        CONSTRAINT [CK_Deliveries_ScheduleWindow] CHECK ([ScheduledEndUtc] > [ScheduledStartUtc]),
        CONSTRAINT [CK_Deliveries_Status] CHECK ([Status] IN ('Scheduled','Assigned','InTransit','Completed','Cancelled')),
        CONSTRAINT [FK_Deliveries_Drivers_DriverId] FOREIGN KEY ([DriverId]) REFERENCES [Drivers] ([DriverId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Deliveries_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Deliveries_Users_AssignedByUserId] FOREIGN KEY ([AssignedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Deliveries_Users_CompletedByUserId] FOREIGN KEY ([CompletedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_Deliveries_Users_StartedByUserId] FOREIGN KEY ([StartedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE TABLE [DeliveryCompletionRecords] (
        [DeliveryCompletionRecordId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [CompletedAtUtc] datetime2 NOT NULL,
        [CompletedByUserId] int NULL,
        [CompletedByDriverId] int NULL,
        [CompletedOnBehalfOfDriver] bit NOT NULL,
        [ManagementOverrideReason] nvarchar(500) NULL,
        [RecipientName] nvarchar(200) NOT NULL,
        [RecipientConfirmed] bit NOT NULL,
        [FulfillmentConfirmed] bit NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [ProofReference] nvarchar(500) NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        CONSTRAINT [PK_DeliveryCompletionRecords] PRIMARY KEY ([DeliveryCompletionRecordId]),
        CONSTRAINT [FK_DeliveryCompletionRecords_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryCompletionRecords_Drivers_CompletedByDriverId] FOREIGN KEY ([CompletedByDriverId]) REFERENCES [Drivers] ([DriverId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryCompletionRecords_Users_CompletedByUserId] FOREIGN KEY ([CompletedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE TABLE [DeliveryDriverAssignments] (
        [DeliveryDriverAssignmentId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [DriverId] int NOT NULL,
        [AssignedAtUtc] datetime2 NOT NULL,
        [AssignedByUserId] int NULL,
        [UnassignedAtUtc] datetime2 NULL,
        [UnassignedByUserId] int NULL,
        [AssignmentNotes] nvarchar(500) NULL,
        [ReassignmentReason] nvarchar(500) NULL,
        [IsCurrent] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        CONSTRAINT [PK_DeliveryDriverAssignments] PRIMARY KEY ([DeliveryDriverAssignmentId]),
        CONSTRAINT [FK_DeliveryDriverAssignments_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryDriverAssignments_Drivers_DriverId] FOREIGN KEY ([DriverId]) REFERENCES [Drivers] ([DriverId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryDriverAssignments_Users_AssignedByUserId] FOREIGN KEY ([AssignedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryDriverAssignments_Users_UnassignedByUserId] FOREIGN KEY ([UnassignedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE TABLE [DeliveryStatusHistory] (
        [DeliveryStatusHistoryId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [PreviousStatus] nvarchar(30) NULL,
        [NewStatus] nvarchar(30) NOT NULL,
        [ChangedAtUtc] datetime2 NOT NULL,
        [ChangedByUserId] int NULL,
        [Reason] nvarchar(500) NULL,
        [Source] nvarchar(80) NOT NULL,
        CONSTRAINT [PK_DeliveryStatusHistory] PRIMARY KEY ([DeliveryStatusHistoryId]),
        CONSTRAINT [FK_DeliveryStatusHistory_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryStatusHistory_Users_ChangedByUserId] FOREIGN KEY ([ChangedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_Drivers_AvailabilityStatus] ON [Drivers] ([AvailabilityStatus]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_Deliveries_AssignedByUserId] ON [Deliveries] ([AssignedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_Deliveries_CompletedByUserId] ON [Deliveries] ([CompletedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_Deliveries_Driver_Window] ON [Deliveries] ([DriverId], [Status], [ScheduledStartUtc], [ScheduledEndUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_Deliveries_ScheduledEndUtc] ON [Deliveries] ([ScheduledEndUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_Deliveries_ScheduledStartUtc] ON [Deliveries] ([ScheduledStartUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_Deliveries_StartedByUserId] ON [Deliveries] ([StartedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_Deliveries_Status] ON [Deliveries] ([Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE UNIQUE INDEX [UX_Deliveries_SalesOrderId] ON [Deliveries] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_DeliveryCompletionRecords_CompletedAtUtc] ON [DeliveryCompletionRecords] ([CompletedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_DeliveryCompletionRecords_CompletedByDriverId] ON [DeliveryCompletionRecords] ([CompletedByDriverId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_DeliveryCompletionRecords_CompletedByUserId] ON [DeliveryCompletionRecords] ([CompletedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE UNIQUE INDEX [UX_DeliveryCompletionRecords_DeliveryId] ON [DeliveryCompletionRecords] ([DeliveryId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_DeliveryDriverAssignments_AssignedByUserId] ON [DeliveryDriverAssignments] ([AssignedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_DeliveryDriverAssignments_DeliveryId] ON [DeliveryDriverAssignments] ([DeliveryId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_DeliveryDriverAssignments_DriverId_IsCurrent_AssignedAtUtc] ON [DeliveryDriverAssignments] ([DriverId], [IsCurrent], [AssignedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_DeliveryDriverAssignments_UnassignedByUserId] ON [DeliveryDriverAssignments] ([UnassignedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [UX_DeliveryDriverAssignments_Current] ON [DeliveryDriverAssignments] ([DeliveryId], [IsCurrent]) WHERE [IsCurrent] = 1');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_DeliveryStatusHistory_ChangedByUserId] ON [DeliveryStatusHistory] ([ChangedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    CREATE INDEX [IX_DeliveryStatusHistory_DeliveryId_ChangedAtUtc] ON [DeliveryStatusHistory] ([DeliveryId], [ChangedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    ALTER TABLE [Drivers] ADD CONSTRAINT [FK_Drivers_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260723215734_Subsystem15LogisticsDelivery'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260723215734_Subsystem15LogisticsDelivery', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724120000_PhaseA1SecurityValidationRoles'
)
BEGIN
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;
    IF COL_LENGTH('dbo.Roles', 'RoleCode') IS NULL
        ALTER TABLE dbo.Roles ADD RoleCode nvarchar(50) NULL;
    IF COL_LENGTH('dbo.Roles', 'Description') IS NULL
        ALTER TABLE dbo.Roles ADD Description nvarchar(500) NULL;
    IF COL_LENGTH('dbo.Roles', 'IsSystemRole') IS NULL
        ALTER TABLE dbo.Roles ADD IsSystemRole bit NOT NULL
            CONSTRAINT DF_Roles_IsSystemRole DEFAULT (0);
    IF COL_LENGTH('dbo.Roles', 'IsActive') IS NULL
        ALTER TABLE dbo.Roles ADD IsActive bit NOT NULL
            CONSTRAINT DF_Roles_IsActive DEFAULT (1);
    IF COL_LENGTH('dbo.Roles', 'CreatedAtUtc') IS NULL
        ALTER TABLE dbo.Roles ADD CreatedAtUtc datetime2 NOT NULL
            CONSTRAINT DF_Roles_CreatedAtUtc DEFAULT (SYSUTCDATETIME());
    IF COL_LENGTH('dbo.Roles', 'UpdatedAtUtc') IS NULL
        ALTER TABLE dbo.Roles ADD UpdatedAtUtc datetime2 NULL;
    IF COL_LENGTH('dbo.Roles', 'RowVersion') IS NULL
        ALTER TABLE dbo.Roles ADD RowVersion rowversion NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724120000_PhaseA1SecurityValidationRoles'
)
BEGIN
    UPDATE dbo.Roles
    SET RoleCode = CASE
        WHEN RoleName = 'AdminClerk' THEN 'Admin'
        ELSE RoleName
    END
    WHERE RoleCode IS NULL OR LTRIM(RTRIM(RoleCode)) = '';
    DECLARE @AdminRoleId int =
        (SELECT TOP (1) RoleId FROM dbo.Roles
         WHERE RoleName = 'Admin' OR RoleCode = 'Admin'
         ORDER BY CASE WHEN RoleName = 'Admin' THEN 0 ELSE 1 END, RoleId);
    DECLARE @LegacyAdminRoleId int =
        (SELECT TOP (1) RoleId FROM dbo.Roles
         WHERE RoleName = 'AdminClerk' AND RoleId <> ISNULL(@AdminRoleId, -1)
         ORDER BY RoleId);
    IF @AdminRoleId IS NULL
    BEGIN
        SELECT TOP (1) @AdminRoleId = RoleId
        FROM dbo.Roles
        WHERE RoleName = 'AdminClerk'
        ORDER BY RoleId;
        UPDATE dbo.Roles
        SET RoleName = 'Admin',
            RoleCode = 'Admin',
            UpdatedAtUtc = SYSUTCDATETIME()
        WHERE RoleId = @AdminRoleId;
    END
    ELSE
    BEGIN
        UPDATE dbo.Roles
        SET RoleName = 'Admin',
            RoleCode = 'Admin',
            UpdatedAtUtc = SYSUTCDATETIME()
        WHERE RoleId = @AdminRoleId;
        IF @LegacyAdminRoleId IS NOT NULL
        BEGIN
            UPDATE dbo.Users SET RoleId = @AdminRoleId
            WHERE RoleId = @LegacyAdminRoleId;
            INSERT INTO dbo.RolePermissions
                (RoleId, PermissionId)
            SELECT @AdminRoleId, legacy.PermissionId
            FROM dbo.RolePermissions legacy
            WHERE legacy.RoleId = @LegacyAdminRoleId
              AND NOT EXISTS (
                  SELECT 1 FROM dbo.RolePermissions existing
                  WHERE existing.RoleId = @AdminRoleId
                    AND existing.PermissionId = legacy.PermissionId);
            DELETE FROM dbo.RolePermissions
            WHERE RoleId = @LegacyAdminRoleId;
            DELETE FROM dbo.Roles
            WHERE RoleId = @LegacyAdminRoleId;
        END
    END
    UPDATE dbo.Roles
    SET RoleCode = RoleName
    WHERE RoleCode IS NULL OR LTRIM(RTRIM(RoleCode)) = '';
    ALTER TABLE dbo.Roles ALTER COLUMN RoleCode nvarchar(50) NOT NULL;
    ALTER TABLE dbo.Roles ALTER COLUMN RoleName nvarchar(80) NOT NULL;
    UPDATE dbo.Roles
    SET IsSystemRole = CASE
        WHEN RoleCode IN
            ('Admin','Packer','Driver','WarehouseManager','CEO','COO','BusinessManager')
            THEN 1 ELSE IsSystemRole END,
        IsActive = 1;
    IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE object_id = OBJECT_ID('dbo.Roles')
          AND name = 'UX_Roles_RoleCode')
        CREATE UNIQUE INDEX UX_Roles_RoleCode ON dbo.Roles(RoleCode);
    IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE object_id = OBJECT_ID('dbo.Roles')
          AND name = 'UX_Roles_RoleName')
        CREATE UNIQUE INDEX UX_Roles_RoleName ON dbo.Roles(RoleName);
    IF COL_LENGTH('dbo.Permissions', 'PermissionCode') IS NULL
        ALTER TABLE dbo.Permissions ADD PermissionCode nvarchar(100) NULL;
    IF COL_LENGTH('dbo.Permissions', 'DisplayName') IS NULL
        ALTER TABLE dbo.Permissions ADD DisplayName nvarchar(120) NULL;
    IF COL_LENGTH('dbo.Permissions', 'Module') IS NULL
        ALTER TABLE dbo.Permissions ADD Module nvarchar(80) NULL;
    IF COL_LENGTH('dbo.Permissions', 'Description') IS NULL
        ALTER TABLE dbo.Permissions ADD Description nvarchar(500) NULL;
    IF COL_LENGTH('dbo.Permissions', 'IsSystemPermission') IS NULL
        ALTER TABLE dbo.Permissions ADD IsSystemPermission bit NOT NULL
            CONSTRAINT DF_Permissions_IsSystemPermission DEFAULT (0);
    IF COL_LENGTH('dbo.Permissions', 'IsActive') IS NULL
        ALTER TABLE dbo.Permissions ADD IsActive bit NOT NULL
            CONSTRAINT DF_Permissions_IsActive DEFAULT (1);
    IF COL_LENGTH('dbo.Permissions', 'CreatedAtUtc') IS NULL
        ALTER TABLE dbo.Permissions ADD CreatedAtUtc datetime2 NOT NULL
            CONSTRAINT DF_Permissions_CreatedAtUtc DEFAULT (SYSUTCDATETIME());
    IF COL_LENGTH('dbo.Permissions', 'UpdatedAtUtc') IS NULL
        ALTER TABLE dbo.Permissions ADD UpdatedAtUtc datetime2 NULL;
    IF COL_LENGTH('dbo.Permissions', 'RowVersion') IS NULL
        ALTER TABLE dbo.Permissions ADD RowVersion rowversion NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724120000_PhaseA1SecurityValidationRoles'
)
BEGIN
    UPDATE dbo.Permissions
    SET PermissionCode = ISNULL(NULLIF(PermissionCode, ''), PermissionName),
        DisplayName = ISNULL(NULLIF(DisplayName, ''), PermissionName),
        Module = ISNULL(NULLIF(Module, ''),
            CASE WHEN CHARINDEX('.', PermissionName) > 0
                 THEN LEFT(PermissionName, CHARINDEX('.', PermissionName) - 1)
                 ELSE 'General' END);
    DECLARE @PermissionSeed TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(120) NOT NULL,
        Module nvarchar(80) NOT NULL
    );
    INSERT INTO @PermissionSeed VALUES
    ('Users.View','View users','Security'),
    ('Users.Create','Create users','Security'),
    ('Users.Update','Update users','Security'),
    ('Users.Deactivate','Deactivate users','Security'),
    ('Users.Reactivate','Reactivate users','Security'),
    ('Users.AssignRole','Assign user roles','Security'),
    ('Users.TriggerPasswordReset','Trigger secure password reset','Security'),
    ('Users.ViewEffectivePermissions','View effective permissions','Security'),
    ('Roles.View','View roles','Security'),
    ('Roles.Create','Create roles','Security'),
    ('Roles.Update','Update roles','Security'),
    ('Roles.Deactivate','Deactivate roles','Security'),
    ('Roles.Delete','Delete unused custom roles','Security'),
    ('Roles.AssignPermissions','Assign role permissions','Security'),
    ('Permissions.View','View permission definitions','Security'),
    ('Permissions.Create','Create permission definitions','Security'),
    ('Permissions.Update','Update permission definitions','Security'),
    ('Permissions.Deactivate','Deactivate permission definitions','Security'),
    ('Permissions.Delete','Delete unused custom permissions','Security'),
    ('Products.View','View products','Product'),
    ('Products.Make','Make products','Product'),
    ('Products.Update','Update products','Product'),
    ('Products.Delete','Delete or deactivate products','Product'),
    ('Products.ChangeStatus','Change product status','Product'),
    ('ProductTypes.View','View product types','Product'),
    ('ProductTypes.Manage','Manage product types','Product'),
    ('ProductCategories.View','View product categories','Product'),
    ('ProductCategories.Manage','Manage product categories','Product'),
    ('Stock.View','View stock','Stock'),
    ('Stock.Take','Perform stock takes','Stock'),
    ('Stock.Adjust','Adjust stock','Stock'),
    ('Stock.WriteOff','Write off stock','Stock'),
    ('Expiry.View','View expiry information','Stock'),
    ('Expiry.Resolve','Resolve expiry alerts','Stock'),
    ('Labels.Print','Print product and batch labels','Product'),
    ('Customers.View','View customers','Orders'),
    ('Customers.Manage','Manage customers','Orders'),
    ('Suppliers.View','View suppliers','Suppliers'),
    ('Suppliers.Manage','Manage suppliers','Suppliers'),
    ('Orders.View','View orders','Orders'),
    ('Orders.Create','Create orders','Orders'),
    ('Orders.Update','Update orders','Orders'),
    ('Orders.Validate','Validate orders','Orders'),
    ('Orders.Confirm','Confirm orders','Orders'),
    ('Orders.Cancel','Cancel orders','Orders'),
    ('Orders.ChangeStatus','Change order status','Orders'),
    ('Orders.SendLink','Send customer order links','Orders'),
    ('Packing.View','View packing lists','Packing'),
    ('Packing.Confirm','Confirm packing','Packing'),
    ('Invoices.View','View invoices','Orders'),
    ('Payments.View','View payments','Payments'),
    ('Payments.Capture','Capture payments','Payments'),
    ('Payments.Confirm','Confirm payments','Payments'),
    ('Payments.Reverse','Reverse payments','Payments'),
    ('Pricing.View','View pricing','Pricing'),
    ('Pricing.Manage','Manage pricing','Pricing'),
    ('Deliveries.View','View deliveries','Delivery'),
    ('Deliveries.ViewOwn','View own deliveries','Delivery'),
    ('Deliveries.AssignDriver','Assign drivers','Delivery'),
    ('Deliveries.ReassignDriver','Reassign drivers','Delivery'),
    ('Deliveries.CompleteOwn','Complete own delivery','Delivery'),
    ('Deliveries.CompleteAny','Complete delivery on behalf','Delivery'),
    ('Deliveries.ViewProof','View proof of delivery','Delivery'),
    ('AuditLogs.View','View audit logs','Audit');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT seed.PermissionCode, seed.PermissionCode, seed.DisplayName, seed.Module,
           1, 1, SYSUTCDATETIME()
    FROM @PermissionSeed seed
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode
           OR existing.PermissionName = seed.PermissionCode);
    UPDATE permission
    SET permission.PermissionName = seed.PermissionCode,
        permission.PermissionCode = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1
    FROM dbo.Permissions permission
    JOIN @PermissionSeed seed
      ON permission.PermissionCode = seed.PermissionCode
      OR permission.PermissionName = seed.PermissionCode;
    ALTER TABLE dbo.Permissions
        ALTER COLUMN PermissionCode nvarchar(100) NOT NULL;
    ALTER TABLE dbo.Permissions
        ALTER COLUMN PermissionName nvarchar(120) NOT NULL;
    ALTER TABLE dbo.Permissions
        ALTER COLUMN DisplayName nvarchar(120) NOT NULL;
    ALTER TABLE dbo.Permissions
        ALTER COLUMN Module nvarchar(80) NOT NULL;
    IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE object_id = OBJECT_ID('dbo.Permissions')
          AND name = 'UX_Permissions_PermissionCode')
        CREATE UNIQUE INDEX UX_Permissions_PermissionCode
            ON dbo.Permissions(PermissionCode);
    IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE object_id = OBJECT_ID('dbo.Permissions')
          AND name = 'IX_Permissions_Module_IsActive')
        CREATE INDEX IX_Permissions_Module_IsActive
            ON dbo.Permissions(Module, IsActive);
    IF COL_LENGTH('dbo.Users', 'NormalizedEmail') IS NULL
        ALTER TABLE dbo.Users ADD NormalizedEmail nvarchar(100) NULL;
    IF COL_LENGTH('dbo.Users', 'UpdatedAtUtc') IS NULL
        ALTER TABLE dbo.Users ADD UpdatedAtUtc datetime2 NULL;
    IF COL_LENGTH('dbo.Users', 'SecurityVersion') IS NULL
        ALTER TABLE dbo.Users ADD SecurityVersion int NOT NULL
            CONSTRAINT DF_Users_SecurityVersion DEFAULT (1);
    IF COL_LENGTH('dbo.Users', 'RowVersion') IS NULL
        ALTER TABLE dbo.Users ADD RowVersion rowversion NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724120000_PhaseA1SecurityValidationRoles'
)
BEGIN
    UPDATE dbo.Users
    SET NormalizedEmail = UPPER(LTRIM(RTRIM(Email)))
    WHERE NormalizedEmail IS NULL OR LTRIM(RTRIM(NormalizedEmail)) = '';
    IF EXISTS (
        SELECT NormalizedEmail
        FROM dbo.Users
        GROUP BY NormalizedEmail
        HAVING COUNT(*) > 1)
        THROW 51001,
            'Duplicate user email addresses must be resolved before Phase A1 can create the unique email index.',
            1;
    ALTER TABLE dbo.Users
        ALTER COLUMN NormalizedEmail nvarchar(100) NOT NULL;
    ALTER TABLE dbo.Users
        ALTER COLUMN Status nvarchar(20) NOT NULL;
    IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE object_id = OBJECT_ID('dbo.Users')
          AND name = 'UX_Users_NormalizedEmail')
        CREATE UNIQUE INDEX UX_Users_NormalizedEmail
            ON dbo.Users(NormalizedEmail);
    IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE object_id = OBJECT_ID('dbo.Users')
          AND name = 'IX_Users_Status_RoleId')
        CREATE INDEX IX_Users_Status_RoleId
            ON dbo.Users(Status, RoleId);
    IF COL_LENGTH('dbo.RolePermissions', 'AssignedAtUtc') IS NULL
        ALTER TABLE dbo.RolePermissions ADD AssignedAtUtc datetime2 NOT NULL
            CONSTRAINT DF_RolePermissions_AssignedAtUtc DEFAULT (SYSUTCDATETIME());
    IF COL_LENGTH('dbo.RolePermissions', 'AssignedByUserId') IS NULL
        ALTER TABLE dbo.RolePermissions ADD AssignedByUserId int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724120000_PhaseA1SecurityValidationRoles'
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM sys.foreign_keys
        WHERE parent_object_id = OBJECT_ID('dbo.RolePermissions')
          AND name = 'FK_RolePermissions_Users_AssignedByUserId')
        ALTER TABLE dbo.RolePermissions
            ADD CONSTRAINT FK_RolePermissions_Users_AssignedByUserId
            FOREIGN KEY (AssignedByUserId) REFERENCES dbo.Users(UserId);
    IF NOT EXISTS (
        SELECT 1 FROM sys.indexes
        WHERE object_id = OBJECT_ID('dbo.RolePermissions')
          AND name = 'IX_RolePermissions_AssignedByUserId')
        CREATE INDEX IX_RolePermissions_AssignedByUserId
            ON dbo.RolePermissions(AssignedByUserId);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    CROSS JOIN dbo.Permissions permission
    WHERE role.RoleCode IN ('CEO','COO','BusinessManager')
      AND permission.IsActive = 1
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions mapping
          WHERE mapping.RoleId = role.RoleId
            AND mapping.PermissionId = permission.PermissionId);
    DECLARE @OperationalAssignments TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL
    );
    INSERT INTO @OperationalAssignments VALUES
    ('Admin','Products.View'),('Admin','Products.Make'),
    ('Admin','Products.Update'),('Admin','Products.Delete'),
    ('Admin','Products.ChangeStatus'),('Admin','ProductTypes.View'),
    ('Admin','ProductTypes.Manage'),('Admin','ProductCategories.View'),
    ('Admin','ProductCategories.Manage'),('Admin','Stock.View'),
    ('Admin','Expiry.View'),('Admin','Labels.Print'),
    ('Admin','Customers.View'),('Admin','Customers.Manage'),
    ('Admin','Suppliers.View'),('Admin','Suppliers.Manage'),
    ('Admin','Orders.View'),('Admin','Orders.Create'),
    ('Admin','Orders.Update'),('Admin','Orders.Validate'),
    ('Admin','Orders.Confirm'),('Admin','Orders.Cancel'),
    ('Admin','Orders.ChangeStatus'),('Admin','Orders.SendLink'),
    ('Admin','Packing.View'),('Admin','Invoices.View'),
    ('Admin','Payments.View'),('Admin','Payments.Capture'),
    ('Admin','Payments.Confirm'),('Admin','Pricing.View'),
    ('Admin','Pricing.Manage'),('Admin','Deliveries.View'),
    ('Admin','Deliveries.AssignDriver'),('Admin','Deliveries.ReassignDriver'),
    ('Admin','Deliveries.CompleteOwn'),('Admin','Deliveries.CompleteAny'),
    ('Admin','Deliveries.ViewProof'),
    ('Packer','Products.View'),('Packer','Products.Make'),
    ('Packer','Stock.View'),('Packer','Expiry.View'),
    ('Packer','Labels.Print'),('Packer','Orders.View'),
    ('Packer','Orders.ChangeStatus'),('Packer','Packing.View'),
    ('Packer','Packing.Confirm'),
    ('WarehouseManager','Products.View'),('WarehouseManager','Stock.View'),
    ('WarehouseManager','Stock.Take'),('WarehouseManager','Stock.Adjust'),
    ('WarehouseManager','Stock.WriteOff'),('WarehouseManager','Expiry.View'),
    ('WarehouseManager','Expiry.Resolve'),
    ('Driver','Deliveries.View'),('Driver','Deliveries.ViewOwn'),
    ('Driver','Deliveries.CompleteOwn'),('Driver','Deliveries.ViewProof');
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM @OperationalAssignments assignment
    JOIN dbo.Roles role ON role.RoleCode = assignment.RoleCode
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = assignment.PermissionCode
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.RolePermissions mapping
        WHERE mapping.RoleId = role.RoleId
          AND mapping.PermissionId = permission.PermissionId);
    COMMIT TRANSACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724120000_PhaseA1SecurityValidationRoles'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260724120000_PhaseA1SecurityValidationRoles', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @var1 sysname;
    SELECT @var1 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[WarehouseSections]') AND [c].[name] = N'Status');
    IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [WarehouseSections] DROP CONSTRAINT [' + @var1 + '];');
    ALTER TABLE [WarehouseSections] ALTER COLUMN [Status] nvarchar(20) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @var2 sysname;
    SELECT @var2 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[WarehouseSections]') AND [c].[name] = N'SectionName');
    IF @var2 IS NOT NULL EXEC(N'ALTER TABLE [WarehouseSections] DROP CONSTRAINT [' + @var2 + '];');
    ALTER TABLE [WarehouseSections] ALTER COLUMN [SectionName] nvarchar(100) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @var3 sysname;
    SELECT @var3 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[WarehouseSections]') AND [c].[name] = N'Description');
    IF @var3 IS NOT NULL EXEC(N'ALTER TABLE [WarehouseSections] DROP CONSTRAINT [' + @var3 + '];');
    ALTER TABLE [WarehouseSections] ALTER COLUMN [Description] nvarchar(500) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    ALTER TABLE [WarehouseSections] ADD [CreatedAtUtc] datetime2 NOT NULL DEFAULT (SYSUTCDATETIME());
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    ALTER TABLE [WarehouseSections] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    ALTER TABLE [WarehouseSections] ADD [SectionCode] nvarchar(40) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    ALTER TABLE [WarehouseSections] ADD [UpdatedAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    UPDATE dbo.WarehouseSections
    SET SectionCode = CONCAT('SECTION-', RIGHT(CONCAT('000000', SectionId), 6))
    WHERE SectionCode IS NULL OR LTRIM(RTRIM(SectionCode)) = '';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @var4 sysname;
    SELECT @var4 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[WarehouseSections]') AND [c].[name] = N'SectionCode');
    IF @var4 IS NOT NULL EXEC(N'ALTER TABLE [WarehouseSections] DROP CONSTRAINT [' + @var4 + '];');
    ALTER TABLE [WarehouseSections] ALTER COLUMN [SectionCode] nvarchar(40) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [LookupTypes] (
        [LookupTypeId] int NOT NULL IDENTITY,
        [SystemCode] nvarchar(80) NOT NULL,
        [DisplayName] nvarchar(120) NOT NULL,
        [Description] nvarchar(500) NULL,
        [IsSystemType] bit NOT NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_LookupTypes] PRIMARY KEY ([LookupTypeId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [SystemSettings] (
        [SystemSettingId] int NOT NULL IDENTITY,
        [Key] nvarchar(150) NOT NULL,
        [Category] nvarchar(80) NOT NULL,
        [DisplayName] nvarchar(120) NOT NULL,
        [Description] nvarchar(500) NOT NULL,
        [ValueType] nvarchar(40) NOT NULL,
        [Value] nvarchar(2000) NOT NULL,
        [DefaultValue] nvarchar(2000) NOT NULL,
        [Unit] nvarchar(40) NULL,
        [MinimumValue] nvarchar(100) NULL,
        [MaximumValue] nvarchar(100) NULL,
        [AllowedValuesJson] nvarchar(max) NULL,
        [IsSensitive] bit NOT NULL,
        [IsSystemSetting] bit NOT NULL,
        [IsActive] bit NOT NULL,
        [RequiresRestart] bit NOT NULL,
        [UpdatedAtUtc] datetime2 NOT NULL,
        [UpdatedByUserId] int NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_SystemSettings] PRIMARY KEY ([SystemSettingId]),
        CONSTRAINT [FK_SystemSettings_Users_UpdatedByUserId] FOREIGN KEY ([UpdatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [LookupValues] (
        [LookupValueId] int NOT NULL IDENTITY,
        [LookupTypeId] int NOT NULL,
        [SystemCode] nvarchar(80) NOT NULL,
        [DisplayName] nvarchar(120) NOT NULL,
        [Description] nvarchar(500) NULL,
        [SortOrder] int NOT NULL,
        [IsSystemValue] bit NOT NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_LookupValues] PRIMARY KEY ([LookupValueId]),
        CONSTRAINT [FK_LookupValues_LookupTypes_LookupTypeId] FOREIGN KEY ([LookupTypeId]) REFERENCES [LookupTypes] ([LookupTypeId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [SystemSettingHistory] (
        [SystemSettingHistoryId] bigint NOT NULL IDENTITY,
        [SystemSettingId] int NOT NULL,
        [PreviousValue] nvarchar(2000) NOT NULL,
        [NewValue] nvarchar(2000) NOT NULL,
        [ChangedAtUtc] datetime2 NOT NULL,
        [ChangedByUserId] int NULL,
        [Reason] nvarchar(500) NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [AppliedSuccessfully] bit NOT NULL,
        [FailureReason] nvarchar(500) NULL,
        CONSTRAINT [PK_SystemSettingHistory] PRIMARY KEY ([SystemSettingHistoryId]),
        CONSTRAINT [FK_SystemSettingHistory_SystemSettings_SystemSettingId] FOREIGN KEY ([SystemSettingId]) REFERENCES [SystemSettings] ([SystemSettingId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SystemSettingHistory_Users_ChangedByUserId] FOREIGN KEY ([ChangedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [LookupValueHistory] (
        [LookupValueHistoryId] bigint NOT NULL IDENTITY,
        [LookupValueId] int NOT NULL,
        [ChangeType] nvarchar(40) NOT NULL,
        [BeforeValuesJson] nvarchar(max) NULL,
        [AfterValuesJson] nvarchar(max) NULL,
        [ChangedByUserId] int NULL,
        [ChangedAtUtc] datetime2 NOT NULL,
        [Reason] nvarchar(500) NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_LookupValueHistory] PRIMARY KEY ([LookupValueHistoryId]),
        CONSTRAINT [FK_LookupValueHistory_LookupValues_LookupValueId] FOREIGN KEY ([LookupValueId]) REFERENCES [LookupValues] ([LookupValueId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_LookupValueHistory_Users_ChangedByUserId] FOREIGN KEY ([ChangedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'LookupTypeId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'IsSystemType', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[LookupTypes]'))
        SET IDENTITY_INSERT [LookupTypes] ON;
    EXEC(N'INSERT INTO [LookupTypes] ([LookupTypeId], [CreatedAtUtc], [Description], [DisplayName], [IsActive], [IsSystemType], [SystemCode], [UpdatedAtUtc])
    VALUES (1, ''2026-07-24T00:00:00.0000000Z'', N''Reasons recorded when stock is adjusted or moved.'', N''Stock movement reasons'', CAST(1 AS bit), CAST(1 AS bit), N''STOCK_MOVEMENT_REASON'', NULL),
    (2, ''2026-07-24T00:00:00.0000000Z'', N''Approved reasons for final stock write-off.'', N''Write-off reasons'', CAST(1 AS bit), CAST(1 AS bit), N''WRITE_OFF_REASON'', NULL),
    (3, ''2026-07-24T00:00:00.0000000Z'', N''Reasons used when a sales order is cancelled.'', N''Order cancellation reasons'', CAST(1 AS bit), CAST(1 AS bit), N''ORDER_CANCELLATION_REASON'', NULL),
    (4, ''2026-07-24T00:00:00.0000000Z'', N''Reasons used when an order is rejected during validation.'', N''Order rejection reasons'', CAST(1 AS bit), CAST(1 AS bit), N''ORDER_REJECTION_REASON'', NULL),
    (5, ''2026-07-24T00:00:00.0000000Z'', N''Reasons recorded when a delivery cannot be fulfilled.'', N''Delivery failure reasons'', CAST(1 AS bit), CAST(1 AS bit), N''DELIVERY_FAILURE_REASON'', NULL),
    (6, ''2026-07-24T00:00:00.0000000Z'', N''Approved customer and supplier payment methods.'', N''Payment methods'', CAST(1 AS bit), CAST(1 AS bit), N''PAYMENT_METHOD'', NULL),
    (7, ''2026-07-24T00:00:00.0000000Z'', N''Customer classifications used by operational forms.'', N''Customer types'', CAST(1 AS bit), CAST(1 AS bit), N''CUSTOMER_TYPE'', NULL),
    (8, ''2026-07-24T00:00:00.0000000Z'', N''Supplier classifications used by operational forms.'', N''Supplier types'', CAST(1 AS bit), CAST(1 AS bit), N''SUPPLIER_TYPE'', NULL),
    (9, ''2026-07-24T00:00:00.0000000Z'', N''Units available for quantities and packaging.'', N''Units of measure'', CAST(1 AS bit), CAST(1 AS bit), N''UNIT_OF_MEASURE'', NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'LookupTypeId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'IsSystemType', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[LookupTypes]'))
        SET IDENTITY_INSERT [LookupTypes] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (1, NULL, N''Expiry'', N''72'', N''Hours before expiry when a batch becomes a yellow warning.'', N''Yellow warning threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.YellowThresholdHours'', N''720'', N''2'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''72'', N''TimeSpanHours''),
    (2, NULL, N''Expiry'', N''24'', N''Hours before expiry when a batch becomes urgent.'', N''Red urgent threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.RedThresholdHours'', N''168'', N''1'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''24'', N''TimeSpanHours''),
    (3, NULL, N''Expiry'', N''60'', N''Minutes between automatic expiry scans.'', N''Expiry scan interval'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.ScanIntervalMinutes'', N''1440'', N''1'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''60'', N''TimeSpanMinutes''),
    (4, NULL, N''Expiry'', N''2'', N''Days added by a permitted one-time shelf-life extension.'', N''Shelf-life extension'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.ShelfLifeExtensionDays'', N''14'', N''1'', CAST(0 AS bit), N''days'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''2'', N''Integer''),
    (5, NULL, N''Expiry'', N''48'', N''Hours before a newly generated expiry decision link expires.'', N''Expiry action-link lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.ActionTokenLifetimeHours'', N''168'', N''1'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''48'', N''TimeSpanHours''),
    (6, NULL, N''Expiry'', N''["BusinessManager","CEO","COO","WarehouseManager"]'', N''Active role codes that receive new expiry-alert emails.'', N''Expiry recipient roles'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.RecipientRoleCodes'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''["BusinessManager","CEO","COO","WarehouseManager"]'', N''StringArray''),
    (7, NULL, N''Orders'', N''72'', N''Hours before a newly created customer order link expires.'', N''Customer order-link lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Orders.OrderLinkLifetimeHours'', N''168'', N''1'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''72'', N''TimeSpanHours''),
    (8, NULL, N''Orders'', N''0'', N''Extra hours beyond requested delivery time that reserved batches must remain valid.'', N''Delivery stock-safety window'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Orders.DeliverySafetyHours'', N''168'', N''0'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''0'', N''TimeSpanHours''),
    (9, NULL, N''Delivery'', N''120'', N''Duration used for a new schedule when no end time is supplied.'', N''Default delivery duration'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Delivery.DefaultDurationMinutes'', N''1440'', N''15'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''120'', N''TimeSpanMinutes'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'LookupValueId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'IsSystemValue', N'LookupTypeId', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[LookupValues]'))
        SET IDENTITY_INSERT [LookupValues] ON;
    EXEC(N'INSERT INTO [LookupValues] ([LookupValueId], [CreatedAtUtc], [Description], [DisplayName], [IsActive], [IsSystemValue], [LookupTypeId], [SortOrder], [SystemCode], [UpdatedAtUtc])
    VALUES (1, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Production increase'', CAST(1 AS bit), CAST(1 AS bit), 1, 10, N''PRODUCTION_INCREASE'', NULL),
    (2, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Packing decrease'', CAST(1 AS bit), CAST(1 AS bit), 1, 20, N''PACKING_DECREASE'', NULL),
    (3, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Stock adjustment'', CAST(1 AS bit), CAST(1 AS bit), 1, 30, N''STOCK_ADJUSTMENT'', NULL),
    (4, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Expired stock'', CAST(1 AS bit), CAST(1 AS bit), 2, 10, N''EXPIRED'', NULL),
    (5, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Damaged stock'', CAST(1 AS bit), CAST(1 AS bit), 2, 20, N''DAMAGED'', NULL),
    (6, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Quality inspection failure'', CAST(1 AS bit), CAST(1 AS bit), 2, 30, N''QUALITY_FAILURE'', NULL),
    (7, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Customer request'', CAST(1 AS bit), CAST(1 AS bit), 3, 10, N''CUSTOMER_REQUEST'', NULL),
    (8, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Duplicate order'', CAST(1 AS bit), CAST(1 AS bit), 3, 20, N''DUPLICATE_ORDER'', NULL),
    (9, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Stock unavailable'', CAST(1 AS bit), CAST(1 AS bit), 3, 30, N''STOCK_UNAVAILABLE'', NULL),
    (10, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Insufficient stock'', CAST(1 AS bit), CAST(1 AS bit), 4, 10, N''INSUFFICIENT_STOCK'', NULL),
    (11, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Invalid order details'', CAST(1 AS bit), CAST(1 AS bit), 4, 20, N''INVALID_DETAILS'', NULL),
    (12, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Customer unavailable'', CAST(1 AS bit), CAST(1 AS bit), 5, 10, N''CUSTOMER_UNAVAILABLE'', NULL),
    (13, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Address not found'', CAST(1 AS bit), CAST(1 AS bit), 5, 20, N''ADDRESS_NOT_FOUND'', NULL),
    (14, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Vehicle issue'', CAST(1 AS bit), CAST(1 AS bit), 5, 30, N''VEHICLE_ISSUE'', NULL),
    (15, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Electronic funds transfer'', CAST(1 AS bit), CAST(1 AS bit), 6, 10, N''EFT'', NULL),
    (16, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Card'', CAST(1 AS bit), CAST(1 AS bit), 6, 20, N''CARD'', NULL),
    (17, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Cash'', CAST(1 AS bit), CAST(1 AS bit), 6, 30, N''CASH'', NULL),
    (18, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Retail'', CAST(1 AS bit), CAST(1 AS bit), 7, 10, N''RETAIL'', NULL),
    (19, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Wholesale'', CAST(1 AS bit), CAST(1 AS bit), 7, 20, N''WHOLESALE'', NULL),
    (20, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Distributor'', CAST(1 AS bit), CAST(1 AS bit), 7, 30, N''DISTRIBUTOR'', NULL),
    (21, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Producer'', CAST(1 AS bit), CAST(1 AS bit), 8, 10, N''PRODUCER'', NULL),
    (22, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Distributor'', CAST(1 AS bit), CAST(1 AS bit), 8, 20, N''DISTRIBUTOR'', NULL),
    (23, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Service provider'', CAST(1 AS bit), CAST(1 AS bit), 8, 30, N''SERVICE_PROVIDER'', NULL),
    (24, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Kilogram (kg)'', CAST(1 AS bit), CAST(1 AS bit), 9, 10, N''KG'', NULL),
    (25, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Gram (g)'', CAST(1 AS bit), CAST(1 AS bit), 9, 20, N''G'', NULL),
    (26, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Litre (L)'', CAST(1 AS bit), CAST(1 AS bit), 9, 30, N''L'', NULL),
    (27, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Unit'', CAST(1 AS bit), CAST(1 AS bit), 9, 40, N''UNIT'', NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'LookupValueId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'IsSystemValue', N'LookupTypeId', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[LookupValues]'))
        SET IDENTITY_INSERT [LookupValues] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_WarehouseSections_Status_SectionName] ON [WarehouseSections] ([Status], [SectionName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE UNIQUE INDEX [UX_WarehouseSections_SectionCode] ON [WarehouseSections] ([SectionCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_LookupTypes_IsActive_DisplayName] ON [LookupTypes] ([IsActive], [DisplayName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE UNIQUE INDEX [UX_LookupTypes_SystemCode] ON [LookupTypes] ([SystemCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_LookupValueHistory_ChangedByUserId] ON [LookupValueHistory] ([ChangedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_LookupValueHistory_LookupValueId_ChangedAtUtc] ON [LookupValueHistory] ([LookupValueId], [ChangedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_LookupValues_LookupTypeId_IsActive_SortOrder_DisplayName] ON [LookupValues] ([LookupTypeId], [IsActive], [SortOrder], [DisplayName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE UNIQUE INDEX [UX_LookupValues_Type_SystemCode] ON [LookupValues] ([LookupTypeId], [SystemCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_SystemSettingHistory_ChangedByUserId] ON [SystemSettingHistory] ([ChangedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_SystemSettingHistory_SystemSettingId_ChangedAtUtc] ON [SystemSettingHistory] ([SystemSettingId], [ChangedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_SystemSettings_Category_IsActive] ON [SystemSettings] ([Category], [IsActive]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_SystemSettings_UpdatedByUserId] ON [SystemSettings] ([UpdatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE UNIQUE INDEX [UX_SystemSettings_Key] ON [SystemSettings] ([Key]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @A2PermissionSeed TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(120) NOT NULL
    );
    INSERT INTO @A2PermissionSeed VALUES
        ('Lookups.View','View operational lookup values'),
        ('Lookups.Manage','Manage operational lookup values'),
        ('WarehouseSections.View','View warehouse sections'),
        ('WarehouseSections.Manage','Manage warehouse sections'),
        ('SystemSettings.View','View configurable business rules'),
        ('SystemSettings.Manage','Manage configurable business rules');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT seed.PermissionCode, seed.PermissionCode,
           seed.DisplayName, 'Configuration', 1, 1, SYSUTCDATETIME()
    FROM @A2PermissionSeed seed
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode IN
         ('Lookups.View','Lookups.Manage',
          'WarehouseSections.View','WarehouseSections.Manage',
          'SystemSettings.View','SystemSettings.Manage')
    WHERE role.RoleCode IN ('CEO','COO','BusinessManager')
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions mapping
          WHERE mapping.RoleId = role.RoleId
            AND mapping.PermissionId = permission.PermissionId);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode IN
         ('Lookups.View','WarehouseSections.View')
    WHERE role.RoleCode IN ('Admin','Packer','WarehouseManager')
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions mapping
          WHERE mapping.RoleId = role.RoleId
            AND mapping.PermissionId = permission.PermissionId);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = 'Lookups.View'
    WHERE role.RoleCode = 'Driver'
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions mapping
          WHERE mapping.RoleId = role.RoleId
            AND mapping.PermissionId = permission.PermissionId);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260724130000_PhaseA2ConfigurableRulesAndLookups', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (
        SELECT NormalizedEmail
        FROM dbo.Users
        GROUP BY NormalizedEmail
        HAVING COUNT(*) > 1)
        THROW 51003,
            'Duplicate user email addresses must be resolved before Phase A3 can be applied.',
            1;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [HelpCategories] (
        [HelpCategoryId] int NOT NULL IDENTITY,
        [SystemCode] nvarchar(80) NOT NULL,
        [DisplayName] nvarchar(120) NOT NULL,
        [Description] nvarchar(500) NULL,
        [SortOrder] int NOT NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_HelpCategories] PRIMARY KEY ([HelpCategoryId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [StoredFiles] (
        [StoredFileId] bigint NOT NULL IDENTITY,
        [StorageProvider] nvarchar(40) NOT NULL,
        [StorageKey] nvarchar(300) NOT NULL,
        [OriginalFileName] nvarchar(255) NOT NULL,
        [SafeDownloadName] nvarchar(255) NOT NULL,
        [ContentType] nvarchar(120) NOT NULL,
        [Extension] nvarchar(16) NOT NULL,
        [SizeBytes] bigint NOT NULL,
        [Sha256Hash] nvarchar(64) NOT NULL,
        [UploadedAtUtc] datetime2 NOT NULL,
        [UploadedByUserId] int NOT NULL,
        [IsDeleted] bit NOT NULL,
        [DeletedAtUtc] datetime2 NULL,
        [DeletedByUserId] int NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_StoredFiles] PRIMARY KEY ([StoredFileId]),
        CONSTRAINT [FK_StoredFiles_Users_DeletedByUserId] FOREIGN KEY ([DeletedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StoredFiles_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [TrustedDevices] (
        [TrustedDeviceId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [TokenHash] nvarchar(64) NOT NULL,
        [DeviceName] nvarchar(120) NOT NULL,
        [UserAgentSummary] nvarchar(256) NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [LastUsedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        [RevokedAtUtc] datetime2 NULL,
        [RevokedByUserId] int NULL,
        [RevocationReason] nvarchar(300) NULL,
        [SecurityVersionSnapshot] int NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_TrustedDevices] PRIMARY KEY ([TrustedDeviceId]),
        CONSTRAINT [FK_TrustedDevices_Users_RevokedByUserId] FOREIGN KEY ([RevokedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_TrustedDevices_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [UserOtpChallenges] (
        [UserOtpChallengeId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [ChallengeTokenHash] nvarchar(64) NOT NULL,
        [OtpHash] nvarchar(256) NOT NULL,
        [Purpose] nvarchar(40) NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        [LastSentAtUtc] datetime2 NOT NULL,
        [AttemptCount] int NOT NULL,
        [MaximumAttempts] int NOT NULL,
        [ResendCount] int NOT NULL,
        [ConsumedAtUtc] datetime2 NULL,
        [RevokedAtUtc] datetime2 NULL,
        [FailureReason] nvarchar(160) NULL,
        [IpAddressSummary] nvarchar(64) NULL,
        [UserAgentSummary] nvarchar(256) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [SecurityVersionSnapshot] int NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_UserOtpChallenges] PRIMARY KEY ([UserOtpChallengeId]),
        CONSTRAINT [FK_UserOtpChallenges_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [UserRecoveryCodes] (
        [UserRecoveryCodeId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [CodeHash] nvarchar(256) NOT NULL,
        [CodeOrder] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UsedAtUtc] datetime2 NULL,
        [RevokedAtUtc] datetime2 NULL,
        [SecurityVersionSnapshot] int NOT NULL,
        CONSTRAINT [PK_UserRecoveryCodes] PRIMARY KEY ([UserRecoveryCodeId]),
        CONSTRAINT [FK_UserRecoveryCodes_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [HelpTopics] (
        [HelpTopicId] int NOT NULL IDENTITY,
        [HelpCategoryId] int NOT NULL,
        [Slug] nvarchar(160) NOT NULL,
        [Title] nvarchar(180) NOT NULL,
        [Summary] nvarchar(600) NOT NULL,
        [BodyContent] nvarchar(max) NOT NULL,
        [Keywords] nvarchar(800) NULL,
        [AudienceRolesCsv] nvarchar(500) NULL,
        [IsPublic] bit NOT NULL,
        [IsPublished] bit NOT NULL,
        [SortOrder] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [UpdatedByUserId] int NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_HelpTopics] PRIMARY KEY ([HelpTopicId]),
        CONSTRAINT [FK_HelpTopics_HelpCategories_HelpCategoryId] FOREIGN KEY ([HelpCategoryId]) REFERENCES [HelpCategories] ([HelpCategoryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpTopics_Users_UpdatedByUserId] FOREIGN KEY ([UpdatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [DeliveryProofImages] (
        [DeliveryProofImageId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [StoredFileId] bigint NOT NULL,
        [ThumbnailStoredFileId] bigint NULL,
        [UploadedAtUtc] datetime2 NOT NULL,
        [UploadedByUserId] int NOT NULL,
        [UploadedByDriverId] int NULL,
        [Caption] nvarchar(300) NULL,
        [IsPrimary] bit NOT NULL,
        [RemovedAtUtc] datetime2 NULL,
        [RemovedByUserId] int NULL,
        [RemovalReason] nvarchar(500) NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_DeliveryProofImages] PRIMARY KEY ([DeliveryProofImageId]),
        CONSTRAINT [FK_DeliveryProofImages_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_Drivers_UploadedByDriverId] FOREIGN KEY ([UploadedByDriverId]) REFERENCES [Drivers] ([DriverId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_StoredFiles_StoredFileId] FOREIGN KEY ([StoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_StoredFiles_ThumbnailStoredFileId] FOREIGN KEY ([ThumbnailStoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_Users_RemovedByUserId] FOREIGN KEY ([RemovedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DeliveryProofImages_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [HelpContextMappings] (
        [HelpContextMappingId] int NOT NULL IDENTITY,
        [HelpTopicId] int NOT NULL,
        [RoutePattern] nvarchar(240) NOT NULL,
        [ComponentKey] nvarchar(120) NULL,
        [Priority] int NOT NULL,
        [IsActive] bit NOT NULL,
        CONSTRAINT [PK_HelpContextMappings] PRIMARY KEY ([HelpContextMappingId]),
        CONSTRAINT [FK_HelpContextMappings_HelpTopics_HelpTopicId] FOREIGN KEY ([HelpTopicId]) REFERENCES [HelpTopics] ([HelpTopicId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE TABLE [HelpMedia] (
        [HelpMediaId] bigint NOT NULL IDENTITY,
        [HelpTopicId] int NULL,
        [StoredFileId] bigint NOT NULL,
        [CaptionStoredFileId] bigint NULL,
        [MediaType] nvarchar(40) NOT NULL,
        [Title] nvarchar(180) NOT NULL,
        [Description] nvarchar(1000) NULL,
        [Transcript] nvarchar(max) NULL,
        [IsFeatured] bit NOT NULL,
        [IsPublished] bit NOT NULL,
        [SortOrder] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [UploadedByUserId] int NOT NULL,
        [RemovedAtUtc] datetime2 NULL,
        [RemovedByUserId] int NULL,
        [RemovalReason] nvarchar(500) NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_HelpMedia] PRIMARY KEY ([HelpMediaId]),
        CONSTRAINT [FK_HelpMedia_HelpTopics_HelpTopicId] FOREIGN KEY ([HelpTopicId]) REFERENCES [HelpTopics] ([HelpTopicId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpMedia_StoredFiles_CaptionStoredFileId] FOREIGN KEY ([CaptionStoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpMedia_StoredFiles_StoredFileId] FOREIGN KEY ([StoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpMedia_Users_RemovedByUserId] FOREIGN KEY ([RemovedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_HelpMedia_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpCategoryId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[HelpCategories]'))
        SET IDENTITY_INSERT [HelpCategories] ON;
    EXEC(N'INSERT INTO [HelpCategories] ([HelpCategoryId], [CreatedAtUtc], [Description], [DisplayName], [IsActive], [SortOrder], [SystemCode], [UpdatedAtUtc])
    VALUES (1, ''2026-07-24T00:00:00.0000000Z'', N''Sign-in, security, navigation and account recovery.'', N''Getting started'', CAST(1 AS bit), 10, N''GETTING_STARTED'', NULL),
    (2, ''2026-07-24T00:00:00.0000000Z'', N''User, role, permission and security administration.'', N''Users and security'', CAST(1 AS bit), 20, N''SECURITY_ADMIN'', NULL),
    (3, ''2026-07-24T00:00:00.0000000Z'', N''Product, batch, stock, expiry and label workflows.'', N''Products and stock'', CAST(1 AS bit), 30, N''PRODUCT_STOCK'', NULL),
    (4, ''2026-07-24T00:00:00.0000000Z'', N''Lookups, warehouse sections and runtime business settings.'', N''Configuration'', CAST(1 AS bit), 40, N''CONFIGURATION'', NULL),
    (5, ''2026-07-24T00:00:00.0000000Z'', N''Customers, orders, reservations, packing and invoices.'', N''Customers and orders'', CAST(1 AS bit), 50, N''ORDERS'', NULL),
    (6, ''2026-07-24T00:00:00.0000000Z'', N''Price history and audit-log workflows.'', N''Pricing and accountability'', CAST(1 AS bit), 60, N''PRICING_AUDIT'', NULL),
    (7, ''2026-07-24T00:00:00.0000000Z'', N''Driver assignment, delivery completion and proof images.'', N''Logistics and delivery'', CAST(1 AS bit), 70, N''DELIVERY'', NULL),
    (8, ''2026-07-24T00:00:00.0000000Z'', N''Common validation, access, email and file problems.'', N''Troubleshooting'', CAST(1 AS bit), 80, N''TROUBLESHOOTING'', NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpCategoryId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[HelpCategories]'))
        SET IDENTITY_INSERT [HelpCategories] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (10, NULL, N''Security'', N''5'', N''Minutes before a login verification code expires.'', N''OTP lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.OtpLifetimeMinutes'', N''15'', N''2'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''TimeSpanMinutes''),
    (11, NULL, N''Security'', N''5'', N''Failed verification attempts allowed before a challenge is locked.'', N''OTP maximum attempts'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.OtpMaximumAttempts'', N''10'', N''3'', CAST(0 AS bit), N''attempts'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''Integer''),
    (12, NULL, N''Security'', N''60'', N''Seconds before another verification code may be sent.'', N''OTP resend delay'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.OtpResendDelaySeconds'', N''300'', N''30'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''60'', N''Integer''),
    (13, NULL, N''Security'', N''5'', N''Verification emails allowed for one account in a rolling hour.'', N''OTP hourly resend limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.OtpMaximumResendsPerHour'', N''10'', N''1'', CAST(0 AS bit), N''resends'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''Integer''),
    (14, NULL, N''Security'', N''30'', N''Days before a trusted-device token expires.'', N''Trusted-device lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.TrustedDeviceDays'', N''90'', N''1'', CAST(0 AS bit), N''days'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''30'', N''Integer''),
    (15, NULL, N''Security'', N''10'', N''One-time recovery codes generated for a user.'', N''Recovery-code count'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Security.RecoveryCodeCount'', N''10'', N''10'', CAST(0 AS bit), N''codes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (16, NULL, N''Files'', N''10'', N''Maximum upload size for a delivery proof image.'', N''Proof-image maximum size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Files.ProofImageMaximumMb'', N''25'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (17, NULL, N''Files'', N''250'', N''Maximum upload size for a training video.'', N''Training-video maximum size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Files.TrainingVideoMaximumMb'', N''500'', N''10'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''250'', N''Integer''),
    (18, NULL, N''Delivery'', N''true'', N''Require an active delivery proof image before final completion.'', N''Require proof image'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Delivery.RequireProofImageForCompletion'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''true'', N''Boolean'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpTopicId', N'AudienceRolesCsv', N'BodyContent', N'CreatedAtUtc', N'HelpCategoryId', N'IsPublic', N'IsPublished', N'Keywords', N'Slug', N'SortOrder', N'Summary', N'Title', N'UpdatedAtUtc', N'UpdatedByUserId') AND [object_id] = OBJECT_ID(N'[HelpTopics]'))
        SET IDENTITY_INSERT [HelpTopics] ON;
    EXEC(N'INSERT INTO [HelpTopics] ([HelpTopicId], [AudienceRolesCsv], [BodyContent], [CreatedAtUtc], [HelpCategoryId], [IsPublic], [IsPublished], [Keywords], [Slug], [SortOrder], [Summary], [Title], [UpdatedAtUtc], [UpdatedByUserId])
    VALUES (1, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Getting started'' AS nvarchar(max)), nchar(10), N''Sign in with the email address assigned to your user account. PhenyoSync opens the dashboard and actions permitted by your role and permissions.'', nchar(10), nchar(10), N''Use the persistent Help action for guidance on the page you are viewing. Navigation cards and side menus only show authorized workflows. Always sign out when leaving a shared device.'', nchar(10), nchar(10), N''Management users administer users and configuration. Admin handles operational administration. Packers prepare products and orders, Warehouse Managers control stock and expiry, and Drivers access only their assigned deliveries.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(0 AS bit), CAST(1 AS bit), N''start navigation dashboard sign out role'', N''getting-started'', 10, N''Learn the main navigation, role dashboards and safe sign-out workflow.'', N''Getting started with PhenyoSync'', NULL, NULL),
    (2, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Login and email verification'' AS nvarchar(max)), nchar(10), N''Enter your email and password. A new or untrusted session receives a six-digit code by email before business access is granted.'', nchar(10), nchar(10), N''The code expires after five minutes, allows five attempts and can be resent after the displayed countdown. A new resend invalidates the previous code. Never share a password or verification code.'', nchar(10), nchar(10), N''If email is delayed, check junk mail, confirm the masked destination, wait for the resend timer and request a fresh code.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(1 AS bit), CAST(1 AS bit), N''login otp code two factor email resend'', N''login-and-otp'', 20, N''Sign in with a password, verify a new session by email, and understand OTP limits.'', N''Login and email verification'', NULL, NULL),
    (3, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Trusted devices'' AS nvarchar(max)), nchar(10), N''Selecting Trust this device after OTP stores a protected HttpOnly device token. It bypasses OTP for up to 30 days but never bypasses the password.'', nchar(10), nchar(10), N''Open Account Security to review device names, last use and expiry. Revoke an unfamiliar device immediately. Password reset, account deactivation, role changes and security-session revocation invalidate trusted devices.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(0 AS bit), CAST(1 AS bit), N''trusted device revoke thirty days security'', N''trusted-devices'', 30, N''Understand the 30-day trusted-device option and revoke devices safely.'', N''Trusted devices'', NULL, NULL),
    (4, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Recovery codes'' AS nvarchar(max)), nchar(10), N''After the first successful OTP, PhenyoSync displays ten one-time recovery codes. Save or print them immediately; they cannot be shown again.'', nchar(10), nchar(10), N''Use one code from the login verification screen only when email verification is unavailable. Each code works once. Regenerating codes revokes every unused code from the previous set and requires your current password.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(0 AS bit), CAST(1 AS bit), N''recovery code regenerate download print'', N''recovery-codes'', 40, N''Save, use and regenerate one-time recovery codes.'', N''Recovery codes'', NULL, NULL),
    (5, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Password reset'' AS nvarchar(max)), nchar(10), N''Select Forgot Password on the login page and enter your account email. For privacy, the same confirmation appears whether or not an account exists.'', nchar(10), nchar(10), N''Open the email link within 30 minutes, enter matching passwords of at least eight characters and submit once. A successful reset invalidates previous sessions and trusted devices.''), ''2026-07-24T00:00:00.0000000Z'', 1, CAST(1 AS bit), CAST(1 AS bit), N''forgot password reset email expired link'', N''password-reset'', 50, N''Request and use the secure, expiring password-reset email.'', N''Reset a forgotten password'', NULL, NULL),
    (6, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Manage users'' AS nvarchar(max)), nchar(10), N''Authorized management can search users, create accounts with unique real email addresses, update identity details, assign roles and deactivate or reactivate accounts.'', nchar(10), nchar(10), N''Deactivation blocks new and current sessions without deleting history. Historical users must remain linked to their audit and operational records. Trigger password-reset email instead of setting a password manually.''), ''2026-07-24T00:00:00.0000000Z'', 2, CAST(0 AS bit), CAST(1 AS bit), N''users create update deactivate role password reset'', N''manage-users'', 10, N''Create, search, update, deactivate and reactivate users safely.'', N''Manage users'', NULL, NULL),
    (7, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Roles and permissions'' AS nvarchar(max)), nchar(10), N''Roles group permissions by business responsibility. Create or update custom roles, assign permission checkboxes and inspect a user''''s effective permissions before changing access.'', nchar(10), nchar(10), N''System role codes and system permission codes are protected because APIs depend on them. Unused custom roles may be deactivated or deleted; roles with users or historical references must remain.''), ''2026-07-24T00:00:00.0000000Z'', 2, CAST(0 AS bit), CAST(1 AS bit), N''role permission create assign effective access'', N''roles-and-permissions'', 20, N''Maintain roles, permission assignments and effective access.'', N''Roles and permissions'', NULL, NULL),
    (8, N''CEO,COO,BusinessManager,Admin,Packer'', CONCAT(CAST(N''# Make products'' AS nvarchar(max)), nchar(10), N''Select an existing product identity or enter name, type, category and size. Enter the produced quantity, warehouse section and packed date.'', nchar(10), nchar(10), N''PhenyoSync reuses an exact matching product identity and always creates a separate physical batch. The batch increases available stock, records a stock movement and calculates expiry from the product shelf life.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''make product batch quantity stock increase'', N''make-products'', 10, N''Create or reuse a product and record a new physical batch as stock increase.'', N''Make products and batches'', NULL, NULL),
    (9, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager'', CONCAT(CAST(N''# Search and update products'' AS nvarchar(max)), nchar(10), N''Search by product name, type, category, status or QR value. Select a result to view or update it.'', nchar(10), nchar(10), N''Product changes affect future production, not historical batch snapshots. Use Inactive when a product must stay in history but should not be available for new operations.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''search product update qr inactive'', N''search-update-products'', 20, N''Find products by details or QR value and edit valid master data.'', N''Search and update products'', NULL, NULL),
    (10, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Product types and categories'' AS nvarchar(max)), nchar(10), N''Management pages maintain the database values shown in product forms. Names are unique and active entries are available for new products.'', nchar(10), nchar(10), N''A type or category linked to products cannot be permanently removed. Deactivate it instead so history remains valid.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''product type category crud deactivate'', N''product-types-categories'', 30, N''Create, edit, activate and dependency-check product classifications.'', N''Product types and categories'', NULL, NULL),
    (11, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager'', CONCAT(CAST(N''# QR codes and labels'' AS nvarchar(max)), nchar(10), N''Each physical batch receives a scannable QR value. The printable label identifies the product, batch code, packed date and expiry date.'', nchar(10), nchar(10), N''Attach the label to the matching physical stock. Scanning should open or identify that exact batch, not just the product master record.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''qr code label print batch'', N''qr-labels'', 40, N''Generate, download and use batch-specific QR labels.'', N''QR codes and labels'', NULL, NULL),
    (12, N''CEO,COO,BusinessManager,WarehouseManager'', CONCAT(CAST(N''# Stock takes'' AS nvarchar(max)), nchar(10), N''Start a stock-take session, capture observed quantities and review discrepancies before posting.'', nchar(10), nchar(10), N''Adjustments require an approved reason and create immutable stock movements. Never edit aggregate stock directly; batch and movement records are the accountability source.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''stock take adjustment movement discrepancy'', N''stock-take'', 50, N''Count physical stock and record controlled adjustments.'', N''Stock takes and adjustments'', NULL, NULL),
    (13, N''CEO,COO,BusinessManager,WarehouseManager'', CONCAT(CAST(N''# Expiry management'' AS nvarchar(max)), nchar(10), N''Yellow warnings identify batches approaching expiry. Red urgent warnings appear when 24 hours or less remain.'', nchar(10), nchar(10), N''Authorized users may write off remaining stock or approve the one-time two-day extension after inspection and with a reason. Expired, consumed and written-off batches are excluded from available stock.''), ''2026-07-24T00:00:00.0000000Z'', 3, CAST(0 AS bit), CAST(1 AS bit), N''expiry yellow red urgent write off extension'', N''expiry-actions'', 60, N''Respond to yellow and urgent expiry alerts safely.'', N''Expiry warnings, write-off and extension'', NULL, NULL),
    (14, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Operational lookups'' AS nvarchar(max)), nchar(10), N''Lookup values supply controlled options for stock movements, write-offs, order cancellation, delivery failures, payment methods, customer and supplier types, and units of measure.'', nchar(10), nchar(10), N''Display names and active status are editable. Protected system codes remain immutable because workflow logic and reporting use them.''), ''2026-07-24T00:00:00.0000000Z'', 4, CAST(0 AS bit), CAST(1 AS bit), N''lookup reason payment method customer supplier unit'', N''operational-lookups'', 10, N''Maintain approved reasons, payment methods, customer types and units.'', N''Operational lookups'', NULL, NULL),
    (15, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Warehouse sections'' AS nvarchar(max)), nchar(10), N''Create a unique section code, display name and description. Active sections appear in product and stock workflows.'', nchar(10), nchar(10), N''Deactivate a location that should no longer receive stock. Do not delete a section referenced by stock, batches or movements.''), ''2026-07-24T00:00:00.0000000Z'', 4, CAST(0 AS bit), CAST(1 AS bit), N''warehouse section location create deactivate'', N''warehouse-sections'', 20, N''Maintain warehouse locations without breaking historical stock.'', N''Warehouse sections'', NULL, NULL),
    (16, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# System settings'' AS nvarchar(max)), nchar(10), N''Authorized management can edit expiry thresholds, scanning intervals, order-link lifetime, delivery duration, OTP limits and file limits.'', nchar(10), nchar(10), N''Values are type-checked and range-checked. Changes apply immediately through cache invalidation and retain a history with actor, time and reason.''), ''2026-07-24T00:00:00.0000000Z'', 4, CAST(0 AS bit), CAST(1 AS bit), N''settings timers threshold history configuration'', N''system-settings'', 30, N''Change validated business timers and thresholds immediately.'', N''System settings and history'', NULL, NULL),
    (17, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Customers, suppliers and payments'' AS nvarchar(max)), nchar(10), N''Use unique contact details and active classifications when maintaining customers and suppliers. Orders must link to valid customers.'', nchar(10), nchar(10), N''Admin and authorized management capture and confirm payments. Amounts must be positive and cannot exceed the outstanding invoice. Reversal requires a reason and audit record.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''customer supplier payment invoice confirm reverse'', N''customers-suppliers-payments'', 10, N''Maintain parties and capture authorized payments.'', N''Customers, suppliers and payments'', NULL, NULL),
    (18, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Customer order links'' AS nvarchar(max)), nchar(10), N''Select a valid customer, confirm the email address and send the secure order link. The link expires according to the configured lifetime and can be used once.'', nchar(10), nchar(10), N''The public form exposes only active products with current valid prices. A submitted link cannot be reused.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''order link customer email one time expiry'', N''order-links'', 20, N''Generate and email a unique, expiring, one-time order form.'', N''Send customer order links'', NULL, NULL),
    (19, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Create and validate orders'' AS nvarchar(max)), nchar(10), N''Select a customer and add products with positive quantities. Prices are read from the current server-side price record and snapshotted onto order lines.'', nchar(10), nchar(10), N''Validation checks details and uses FEFO to reserve eligible batches atomically. An order cannot be confirmed when stock is insufficient.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''create order validate stock reserve fefo price'', N''create-validate-orders'', 30, N''Capture order lines and reserve sufficient eligible stock.'', N''Create and validate orders'', NULL, NULL),
    (20, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Order status and cancellation'' AS nvarchar(max)), nchar(10), N''Orders move through the controlled sequence from pending validation to confirmed, packed, out for delivery and delivered.'', nchar(10), nchar(10), N''Cancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''order status cancel reservation release'', N''order-status-cancel'', 40, N''Follow the valid status sequence and release reservations on cancellation.'', N''Order status and cancellation'', NULL, NULL),
    (21, N''CEO,COO,BusinessManager,Admin,Packer'', CONCAT(CAST(N''# Packing and invoices'' AS nvarchar(max)), nchar(10), N''Packers open the packing queue, verify each allocated batch and quantity, then confirm packing once.'', nchar(10), nchar(10), N''Packing decreases stock with movements and creates the order''''s invoice snapshot. The invoice remains linked to the order and later price changes do not alter it.''), ''2026-07-24T00:00:00.0000000Z'', 5, CAST(0 AS bit), CAST(1 AS bit), N''packing list batch invoice stock decrease'', N''packing-invoices'', 50, N''Pack allocated batches and view the immutable invoice snapshot.'', N''Packing lists and invoices'', NULL, NULL),
    (22, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Pricing'' AS nvarchar(max)), nchar(10), N''A price must be greater than zero and belong to a valid product. Updating a price closes the previous record and creates a new current version.'', nchar(10), nchar(10), N''Soft deletion removes a price from future ordering but preserves its history. Existing order items and invoices retain their snapshotted unit prices.''), ''2026-07-24T00:00:00.0000000Z'', 6, CAST(0 AS bit), CAST(1 AS bit), N''price create update history soft delete current'', N''pricing'', 10, N''Create current product prices while preserving historical versions.'', N''Pricing and price history'', NULL, NULL),
    (23, N''CEO,COO,BusinessManager'', CONCAT(CAST(N''# Audit logs'' AS nvarchar(max)), nchar(10), N''Search by user, date, action, module, entity, success state, correlation ID or text. Open a result to inspect sanitized before-and-after details.'', nchar(10), nchar(10), N''Audit logs are read-only and retained for accountability. A correlation ID groups changes and security events from the same request or workflow.''), ''2026-07-24T00:00:00.0000000Z'', 6, CAST(0 AS bit), CAST(1 AS bit), N''audit log search correlation activity readonly'', N''audit-logs'', 20, N''Find read-only accountability records and use correlation IDs.'', N''Search audit logs'', NULL, NULL),
    (24, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Assign drivers'' AS nvarchar(max)), nchar(10), N''A packed order may be scheduled for a delivery window. Select an active available driver whose licence covers the full window.'', nchar(10), nchar(10), N''PhenyoSync prevents overlapping assignments and records assignment, reassignment and unassignment history.''), ''2026-07-24T00:00:00.0000000Z'', 7, CAST(0 AS bit), CAST(1 AS bit), N''delivery schedule assign driver availability overlap'', N''assign-drivers'', 10, N''Schedule deliveries and prevent overlapping driver assignments.'', N''Assign drivers'', NULL, NULL),
    (25, N''Driver'', CONCAT(CAST(N''# My Deliveries'' AS nvarchar(max)), nchar(10), N''Drivers see only currently assigned deliveries. Open a record for the schedule, customer, address and order details.'', nchar(10), nchar(10), N''Start the delivery only when it is Assigned. This moves the delivery and order into their in-transit states.''), ''2026-07-24T00:00:00.0000000Z'', 7, CAST(0 AS bit), CAST(1 AS bit), N''driver my deliveries assigned start'', N''my-deliveries'', 20, N''Review and start only deliveries assigned to your driver account.'', N''Driver: My Deliveries'', NULL, NULL),
    (26, N''CEO,COO,BusinessManager,Admin,Driver'', CONCAT(CAST(N''# Complete a delivery'' AS nvarchar(max)), nchar(10), N''Upload one or more JPEG, PNG or WebP proof images, add a useful caption and select the primary image. Confirm the recipient and successful fulfillment.'', nchar(10), nchar(10), N''Proof is required by default. The assigned Driver may complete their own in-transit delivery. Authorized management can complete on behalf of a driver or override missing proof only with an explicit reason.'', nchar(10), nchar(10), N''Completion is final: proof becomes read-only, the delivery records a UTC completion time and the order becomes Delivered.''), ''2026-07-24T00:00:00.0000000Z'', 7, CAST(0 AS bit), CAST(1 AS bit), N''delivery proof image upload complete recipient override'', N''complete-delivery-proof'', 30, N''Upload protected proof images before final delivery completion.'', N''Complete delivery with proof images'', NULL, NULL),
    (27, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Validation and server errors'' AS nvarchar(max)), nchar(10), N''Read the friendly message and correct every highlighted field. Refresh when a row-version conflict says the record changed.'', nchar(10), nchar(10), N''If an unexpected server error persists, note the displayed trace ID and the time of the action. Do not send passwords, OTPs or recovery codes to support.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(1 AS bit), CAST(1 AS bit), N''validation error trace id conflict support'', N''validation-errors'', 10, N''Resolve highlighted fields and provide a trace ID when support is needed.'', N''Validation messages and trace IDs'', NULL, NULL),
    (28, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Permission denied'' AS nvarchar(max)), nchar(10), N''Menus and APIs are controlled by database permissions. A denied action means the signed-in role does not currently have that permission.'', nchar(10), nchar(10), N''Ask authorized management to review your effective permissions. Sign out and in again after a role change so the session uses the new security version.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(0 AS bit), CAST(1 AS bit), N''permission denied role access 403'', N''permission-denied'', 20, N''Understand why a page or action is unavailable.'', N''Permission denied'', NULL, NULL),
    (29, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# Expired links'' AS nvarchar(max)), nchar(10), N''Security links are time-limited and often one-time. Request a new password-reset link, customer order link or expiry review link from the appropriate workflow.'', nchar(10), nchar(10), N''Do not edit tokens in the address bar or share links. A used link cannot be reactivated.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(1 AS bit), CAST(1 AS bit), N''expired link used token password order expiry'', N''expired-links'', 30, N''Recover from password, order or expiry-action links that no longer work.'', N''Expired or used links'', NULL, NULL),
    (30, N''CEO,COO,BusinessManager,Admin'', CONCAT(CAST(N''# Unavailable drivers'' AS nvarchar(max)), nchar(10), N''A driver is unavailable when inactive, not marked Available, missing a valid driver-user link, holding an expired licence or already assigned to an overlapping window.'', nchar(10), nchar(10), N''Adjust the schedule, update legitimate driver details or select a different available driver. Do not bypass overlap protection.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(0 AS bit), CAST(1 AS bit), N''driver unavailable overlap licence schedule'', N''unavailable-drivers'', 40, N''Resolve licence, status and schedule conflicts during assignment.'', N''Unavailable drivers'', NULL, NULL),
    (31, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# OTP email not received'' AS nvarchar(max)), nchar(10), N''Confirm the masked email destination, check spam, wait for the resend countdown and request one fresh code. Only the newest code is valid.'', nchar(10), nchar(10), N''If email remains unavailable, use a saved recovery code. Contact management to correct the account email; never create duplicate shared addresses.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(1 AS bit), CAST(1 AS bit), N''otp email not received resend recovery'', N''otp-not-received'', 50, N''Use safe recovery steps when the verification email is delayed.'', N''OTP email not received'', NULL, NULL),
    (32, N''CEO,COO,BusinessManager,Admin,Packer,WarehouseManager,Driver'', CONCAT(CAST(N''# File rejected'' AS nvarchar(max)), nchar(10), N''Proof images must be genuine JPEG, PNG or WebP files within the configured limit. Training media must be a genuine MP4 or WebM; captions must be WEBVTT.'', nchar(10), nchar(10), N''Renaming an extension does not convert a file. Export the file in an allowed format and retry. Executable, SVG, HTML, polyglot and mismatched files are blocked.''), ''2026-07-24T00:00:00.0000000Z'', 8, CAST(0 AS bit), CAST(1 AS bit), N''file rejected image video size mime extension'', N''file-rejected'', 60, N''Resolve protected-file validation failures without weakening security.'', N''A proof image or training video was rejected'', NULL, NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpTopicId', N'AudienceRolesCsv', N'BodyContent', N'CreatedAtUtc', N'HelpCategoryId', N'IsPublic', N'IsPublished', N'Keywords', N'Slug', N'SortOrder', N'Summary', N'Title', N'UpdatedAtUtc', N'UpdatedByUserId') AND [object_id] = OBJECT_ID(N'[HelpTopics]'))
        SET IDENTITY_INSERT [HelpTopics] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpContextMappingId', N'ComponentKey', N'HelpTopicId', N'IsActive', N'Priority', N'RoutePattern') AND [object_id] = OBJECT_ID(N'[HelpContextMappings]'))
        SET IDENTITY_INSERT [HelpContextMappings] ON;
    EXEC(N'INSERT INTO [HelpContextMappings] ([HelpContextMappingId], [ComponentKey], [HelpTopicId], [IsActive], [Priority], [RoutePattern])
    VALUES (1, N''AdminDashboard'', 1, CAST(1 AS bit), 100, N''/admin-dashboard''),
    (2, N''PackerDashboard'', 1, CAST(1 AS bit), 100, N''/packer-dashboard''),
    (3, N''WarehouseManagerDashboard'', 1, CAST(1 AS bit), 100, N''/dashboard''),
    (4, N''DriverDashboard'', 25, CAST(1 AS bit), 100, N''/driver-dashboard''),
    (5, N''Login'', 2, CAST(1 AS bit), 100, N''/login''),
    (6, N''ResetPassword'', 5, CAST(1 AS bit), 100, N''/reset-password''),
    (7, N''ManageUsers'', 6, CAST(1 AS bit), 100, N''/manage-users''),
    (8, N''ManageRoles'', 7, CAST(1 AS bit), 100, N''/manage-roles''),
    (9, N''ManagePermissions'', 7, CAST(1 AS bit), 100, N''/manage-permissions''),
    (10, N''MakeProduct'', 8, CAST(1 AS bit), 100, N''/make-product''),
    (11, N''SearchProduct'', 9, CAST(1 AS bit), 100, N''/search-product''),
    (12, N''UpdateProduct'', 9, CAST(1 AS bit), 100, N''/update-product''),
    (13, N''ManageProductTypes'', 10, CAST(1 AS bit), 100, N''/manage-product-types''),
    (14, N''ManageProductCategories'', 10, CAST(1 AS bit), 100, N''/manage-product-categories''),
    (15, N''StockTake'', 12, CAST(1 AS bit), 100, N''/stock-take''),
    (16, N''ExpiryAlerts'', 13, CAST(1 AS bit), 100, N''/expiry-alerts''),
    (17, N''ManageLookups'', 14, CAST(1 AS bit), 100, N''/manage-lookups''),
    (18, N''WarehouseSections'', 15, CAST(1 AS bit), 100, N''/manage-warehouse-sections''),
    (19, N''SystemSettings'', 16, CAST(1 AS bit), 100, N''/manage-system-settings''),
    (20, N''SendOrderLink'', 18, CAST(1 AS bit), 100, N''/send-order-link''),
    (21, N''OrderEditor'', 19, CAST(1 AS bit), 100, N''/create-order''),
    (22, N''OrderDetails'', 20, CAST(1 AS bit), 100, N''/order-details/:id''),
    (23, N''PackingOrders'', 21, CAST(1 AS bit), 100, N''/view-pick-list''),
    (24, N''OrderInvoice'', 21, CAST(1 AS bit), 100, N''/order-invoice/:id''),
    (25, N''PricingManagement'', 22, CAST(1 AS bit), 100, N''/pricing-management''),
    (26, N''AuditLogs'', 23, CAST(1 AS bit), 100, N''/audit-logs''),
    (27, N''DeliveryManagement'', 24, CAST(1 AS bit), 100, N''/deliveries''),
    (28, N''MyDeliveries'', 25, CAST(1 AS bit), 100, N''/my-deliveries''),
    (29, N''CompleteDelivery'', 26, CAST(1 AS bit), 100, N''/deliveries/:id/complete''),
    (30, N''DeliveryProof'', 26, CAST(1 AS bit), 100, N''/deliveries/:id/proof''),
    (31, N''AccountSecurity'', 3, CAST(1 AS bit), 100, N''/account-security''),
    (32, N''HelpCenter'', 1, CAST(1 AS bit), 50, N''/help'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpContextMappingId', N'ComponentKey', N'HelpTopicId', N'IsActive', N'Priority', N'RoutePattern') AND [object_id] = OBJECT_ID(N'[HelpContextMappings]'))
        SET IDENTITY_INSERT [HelpContextMappings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_DeliveryId_RemovedAtUtc_UploadedAtUtc] ON [DeliveryProofImages] ([DeliveryId], [RemovedAtUtc], [UploadedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_RemovedByUserId] ON [DeliveryProofImages] ([RemovedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [IX_DeliveryProofImages_StoredFileId] ON [DeliveryProofImages] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_ThumbnailStoredFileId] ON [DeliveryProofImages] ([ThumbnailStoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_UploadedByDriverId] ON [DeliveryProofImages] ([UploadedByDriverId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_DeliveryProofImages_UploadedByUserId] ON [DeliveryProofImages] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [UX_DeliveryProofImages_Primary] ON [DeliveryProofImages] ([DeliveryId], [IsPrimary]) WHERE [IsPrimary] = 1 AND [RemovedAtUtc] IS NULL');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpCategories_IsActive_SortOrder_DisplayName] ON [HelpCategories] ([IsActive], [SortOrder], [DisplayName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [IX_HelpCategories_SystemCode] ON [HelpCategories] ([SystemCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpContextMappings_HelpTopicId] ON [HelpContextMappings] ([HelpTopicId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpContextMappings_RoutePattern_ComponentKey_IsActive_Priority] ON [HelpContextMappings] ([RoutePattern], [ComponentKey], [IsActive], [Priority]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_CaptionStoredFileId] ON [HelpMedia] ([CaptionStoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_HelpTopicId] ON [HelpMedia] ([HelpTopicId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_IsPublished_IsFeatured_SortOrder] ON [HelpMedia] ([IsPublished], [IsFeatured], [SortOrder]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_RemovedByUserId] ON [HelpMedia] ([RemovedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_StoredFileId] ON [HelpMedia] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpMedia_UploadedByUserId] ON [HelpMedia] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpTopics_HelpCategoryId_IsPublished_SortOrder] ON [HelpTopics] ([HelpCategoryId], [IsPublished], [SortOrder]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [IX_HelpTopics_Slug] ON [HelpTopics] ([Slug]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_HelpTopics_UpdatedByUserId] ON [HelpTopics] ([UpdatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_StoredFiles_DeletedByUserId] ON [StoredFiles] ([DeletedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_StoredFiles_IsDeleted_UploadedAtUtc] ON [StoredFiles] ([IsDeleted], [UploadedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_StoredFiles_UploadedByUserId] ON [StoredFiles] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [UX_StoredFiles_StorageKey] ON [StoredFiles] ([StorageKey]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_TrustedDevices_RevokedByUserId] ON [TrustedDevices] ([RevokedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_TrustedDevices_UserId_RevokedAtUtc_ExpiresAtUtc] ON [TrustedDevices] ([UserId], [RevokedAtUtc], [ExpiresAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [UX_TrustedDevices_TokenHash] ON [TrustedDevices] ([TokenHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_UserOtpChallenges_UserId_Purpose_ExpiresAtUtc] ON [UserOtpChallenges] ([UserId], [Purpose], [ExpiresAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE UNIQUE INDEX [UX_UserOtpChallenges_ChallengeHash] ON [UserOtpChallenges] ([ChallengeTokenHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    CREATE INDEX [IX_UserRecoveryCodes_UserId_CodeOrder_CreatedAtUtc] ON [UserRecoveryCodes] ([UserId], [CodeOrder], [CreatedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    DECLARE @PhaseA3PermissionSeed TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(120) NOT NULL,
        Module nvarchar(80) NOT NULL
    );
    INSERT INTO @PhaseA3PermissionSeed VALUES
        ('Help.View', 'View Help content', 'Help'),
        ('Help.Manage', 'Manage Help content', 'Help'),
        ('HelpMedia.Manage', 'Manage training media', 'Help');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT seed.PermissionCode, seed.PermissionCode,
           seed.DisplayName, seed.Module, 1, 1, SYSUTCDATETIME()
    FROM @PhaseA3PermissionSeed seed
    WHERE NOT EXISTS (
        SELECT 1
        FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode);
    UPDATE permission
    SET permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @PhaseA3PermissionSeed seed
      ON seed.PermissionCode = permission.PermissionCode;
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode IN
         ('Help.View', 'Help.Manage', 'HelpMedia.Manage')
    WHERE role.RoleCode IN ('CEO', 'COO', 'BusinessManager')
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions existing
          WHERE existing.RoleId = role.RoleId
            AND existing.PermissionId = permission.PermissionId);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode IN
         ('Help.View', 'Help.Manage', 'HelpMedia.Manage')
    WHERE role.RoleCode = 'Admin'
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions existing
          WHERE existing.RoleId = role.RoleId
            AND existing.PermissionId = permission.PermissionId);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = 'Help.View'
    WHERE role.RoleCode IN ('Packer', 'WarehouseManager', 'Driver')
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions existing
          WHERE existing.RoleId = role.RoleId
            AND existing.PermissionId = permission.PermissionId);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260724140000_PhaseA3TwoFactorHelpAndProofMedia', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [StockTakeSessions] ADD [CorrelationId] nvarchar(64) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [StockMovements] ADD [StockTakeSessionId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [ProductType] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [ProductCategory] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [Product] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    UPDATE dbo.StockTakeSessions
    SET CorrelationId = CONCAT('legacy-stocktake-', SessionId)
    WHERE CorrelationId IS NULL
       OR LTRIM(RTRIM(CorrelationId)) = '';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE TABLE [DataExchangeJobs] (
        [DataExchangeJobId] bigint NOT NULL IDENTITY,
        [ValidationTokenHash] nvarchar(64) NOT NULL,
        [ExchangeType] nvarchar(40) NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [OriginalFileName] nvarchar(255) NOT NULL,
        [ContentSha256] nvarchar(64) NOT NULL,
        [StagedPayloadJson] nvarchar(max) NOT NULL,
        [ResultPayloadJson] nvarchar(max) NULL,
        [TotalRows] int NOT NULL,
        [ValidRows] int NOT NULL,
        [WarningRows] int NOT NULL,
        [InvalidRows] int NOT NULL,
        [CreatedByUserId] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        [AppliedAtUtc] datetime2 NULL,
        [ApplyReason] nvarchar(500) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_DataExchangeJobs] PRIMARY KEY ([DataExchangeJobId]),
        CONSTRAINT [FK_DataExchangeJobs_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE TABLE [ProductCategoryTypes] (
        [ProductCategoryTypeId] int NOT NULL IDENTITY,
        [ProductCategoryId] int NOT NULL,
        [ProductTypeId] int NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [CreatedByUserId] int NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_ProductCategoryTypes] PRIMARY KEY ([ProductCategoryTypeId]),
        CONSTRAINT [FK_ProductCategoryTypes_ProductCategory_ProductCategoryId] FOREIGN KEY ([ProductCategoryId]) REFERENCES [ProductCategory] ([ProductCategoryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductCategoryTypes_ProductType_ProductTypeId] FOREIGN KEY ([ProductTypeId]) REFERENCES [ProductType] ([ProductTypeId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductCategoryTypes_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    INSERT INTO dbo.ProductCategoryTypes
        (ProductCategoryId, ProductTypeId, CreatedAtUtc, CreatedByUserId)
    SELECT
        product.ProductCategoryId,
        product.ProductTypeId,
        MIN(product.CreatedAt),
        NULL
    FROM dbo.Product product
    WHERE product.ProductCategoryId IS NOT NULL
      AND product.ProductTypeId IS NOT NULL
    GROUP BY
        product.ProductCategoryId,
        product.ProductTypeId;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (19, NULL, N''Files'', N''10'', N''Maximum accepted Product and Price Excel workbook size.'', N''Excel import maximum size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Files.ExcelImportMaximumMb'', N''50'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (20, NULL, N''Files'', N''5'', N''Maximum accepted Stock Count JSON package size.'', N''JSON import maximum size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Files.JsonImportMaximumMb'', N''25'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''Integer''),
    (21, NULL, N''Data exchange'', N''2000'', N''Maximum number of rows accepted in one validated import.'', N''Maximum import rows'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''DataExchange.MaximumRows'', N''10000'', N''1'', CAST(0 AS bit), N''rows'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''2000'', N''Integer''),
    (22, NULL, N''Data exchange'', N''30'', N''Minutes a validated import remains available for confirmation.'', N''Validation lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''DataExchange.ValidationLifetimeMinutes'', N''120'', N''5'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''30'', N''TimeSpanMinutes''),
    (23, NULL, N''QR scanning'', N''3'', N''Seconds during which a repeated camera scan is ignored.'', N''Duplicate scan delay'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Qr.DuplicateDelaySeconds'', N''30'', N''1'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''3'', N''Integer''),
    (24, N''["month","week","day","agenda"]'', N''Calendar'', N''month'', N''Initial view used by the Operations Calendar.'', N''Default calendar view'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Calendar.DefaultView'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''month'', N''String''),
    (25, NULL, N''Calendar'', N''93'', N''Maximum number of days returned by one Operations Calendar query.'', N''Maximum date range'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Calendar.MaximumDateRangeDays'', N''366'', N''7'', CAST(0 AS bit), N''days'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''93'', N''Integer'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    DECLARE @PhaseBPermissionSeed TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(120) NOT NULL,
        Module nvarchar(80) NOT NULL
    );
    INSERT INTO @PhaseBPermissionSeed VALUES
        ('ProductHierarchy.View', 'View the product hierarchy', 'Product'),
        ('ProductHierarchy.Manage', 'Manage the product hierarchy', 'Product'),
        ('ProductDataExchange.Export', 'Export Product and Price workbooks', 'DataExchange'),
        ('ProductDataExchange.Import', 'Validate and import Product and Price workbooks', 'DataExchange'),
        ('StockCountExchange.Export', 'Export Stock Count JSON packages', 'DataExchange'),
        ('StockCountExchange.Import', 'Validate and import Stock Count JSON packages', 'DataExchange'),
        ('OperationsCalendar.View', 'View the Operations Calendar', 'Operations'),
        ('ProductBatchScanner.View', 'Resolve Product Batch QR codes', 'Product');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT
        seed.PermissionCode,
        seed.PermissionCode,
        seed.DisplayName,
        seed.Module,
        1,
        1,
        SYSUTCDATETIME()
    FROM @PhaseBPermissionSeed seed
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode
    );
    UPDATE permission
    SET
        permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @PhaseBPermissionSeed seed
      ON seed.PermissionCode = permission.PermissionCode;
    DECLARE @PhaseBRoleAssignments TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL
    );
    INSERT INTO @PhaseBRoleAssignments VALUES
        ('Admin', 'ProductHierarchy.View'),
        ('Admin', 'ProductHierarchy.Manage'),
        ('Admin', 'ProductDataExchange.Export'),
        ('Admin', 'ProductDataExchange.Import'),
        ('Admin', 'OperationsCalendar.View'),
        ('Admin', 'ProductBatchScanner.View'),
        ('Packer', 'ProductHierarchy.View'),
        ('Packer', 'OperationsCalendar.View'),
        ('Packer', 'ProductBatchScanner.View'),
        ('WarehouseManager', 'ProductHierarchy.View'),
        ('WarehouseManager', 'StockCountExchange.Export'),
        ('WarehouseManager', 'StockCountExchange.Import'),
        ('WarehouseManager', 'OperationsCalendar.View'),
        ('WarehouseManager', 'ProductBatchScanner.View'),
        ('Driver', 'OperationsCalendar.View');
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT
        role.RoleId,
        permission.PermissionId,
        SYSUTCDATETIME()
    FROM dbo.Roles role
    CROSS JOIN dbo.Permissions permission
    WHERE role.RoleCode IN ('CEO', 'COO', 'BusinessManager')
      AND permission.PermissionCode IN
      (
          'ProductHierarchy.View',
          'ProductHierarchy.Manage',
          'ProductDataExchange.Export',
          'ProductDataExchange.Import',
          'StockCountExchange.Export',
          'StockCountExchange.Import',
          'OperationsCalendar.View',
          'ProductBatchScanner.View'
      )
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.RolePermissions existing
          WHERE existing.RoleId = role.RoleId
            AND existing.PermissionId = permission.PermissionId
      );
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT
        role.RoleId,
        permission.PermissionId,
        SYSUTCDATETIME()
    FROM @PhaseBRoleAssignments assignment
    JOIN dbo.Roles role
      ON role.RoleCode = assignment.RoleCode
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = assignment.PermissionCode
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.RolePermissions existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId = permission.PermissionId
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE UNIQUE INDEX [UX_StockTakeSessions_CorrelationId] ON [StockTakeSessions] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE INDEX [IX_StockMovements_StockTakeSessionId] ON [StockMovements] ([StockTakeSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE INDEX [IX_DataExchangeJobs_CreatedByUserId_ExchangeType_Status_ExpiresAtUtc] ON [DataExchangeJobs] ([CreatedByUserId], [ExchangeType], [Status], [ExpiresAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE UNIQUE INDEX [UX_DataExchangeJobs_ValidationTokenHash] ON [DataExchangeJobs] ([ValidationTokenHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE INDEX [IX_ProductCategoryTypes_CreatedByUserId] ON [ProductCategoryTypes] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE INDEX [IX_ProductCategoryTypes_ProductTypeId] ON [ProductCategoryTypes] ([ProductTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    CREATE UNIQUE INDEX [UX_ProductCategoryTypes_Category_Type] ON [ProductCategoryTypes] ([ProductCategoryId], [ProductTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    ALTER TABLE [StockMovements] ADD CONSTRAINT [FK_StockMovements_StockTakeSessions_StockTakeSessionId] FOREIGN KEY ([StockTakeSessionId]) REFERENCES [StockTakeSessions] ([SessionId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260725174044_PhaseBDataExchangeHierarchyCalendarQr', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [BuyerProcurements] (
        [BuyerProcurementId] int NOT NULL IDENTITY,
        [BuyingDateUtc] datetime2 NOT NULL,
        [AssignedBuyerUserId] int NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [DocketStoredFileId] bigint NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [SubmittedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_BuyerProcurements] PRIMARY KEY ([BuyerProcurementId]),
        CONSTRAINT [FK_BuyerProcurements_StoredFiles_DocketStoredFileId] FOREIGN KEY ([DocketStoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_BuyerProcurements_Users_AssignedBuyerUserId] FOREIGN KEY ([AssignedBuyerUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [DeliveryRouteCalculations] (
        [DeliveryRouteCalculationId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [OriginLatitude] decimal(9,6) NOT NULL,
        [OriginLongitude] decimal(9,6) NOT NULL,
        [DestinationLatitude] decimal(9,6) NOT NULL,
        [DestinationLongitude] decimal(9,6) NOT NULL,
        [DistanceMetres] bigint NOT NULL,
        [DurationSeconds] int NOT NULL,
        [TrafficDurationSeconds] int NULL,
        [EncodedPolyline] nvarchar(max) NULL,
        [Provider] nvarchar(40) NOT NULL,
        [RequestFingerprint] nvarchar(64) NOT NULL,
        [CalculatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        CONSTRAINT [PK_DeliveryRouteCalculations] PRIMARY KEY ([DeliveryRouteCalculationId]),
        CONSTRAINT [FK_DeliveryRouteCalculations_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [DriverTrackingSessions] (
        [DriverTrackingSessionId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [DriverId] int NOT NULL,
        [StartedByUserId] int NOT NULL,
        [StartedAtUtc] datetime2 NOT NULL,
        [ConsentConfirmedAtUtc] datetime2 NOT NULL,
        [EndedAtUtc] datetime2 NULL,
        [Status] nvarchar(20) NOT NULL,
        [EndedReason] nvarchar(300) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_DriverTrackingSessions] PRIMARY KEY ([DriverTrackingSessionId]),
        CONSTRAINT [FK_DriverTrackingSessions_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DriverTrackingSessions_Drivers_DriverId] FOREIGN KEY ([DriverId]) REFERENCES [Drivers] ([DriverId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DriverTrackingSessions_Users_StartedByUserId] FOREIGN KEY ([StartedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [MobileDeliveryEvents] (
        [MobileDeliveryEventId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [RecordedByUserId] int NOT NULL,
        [EventType] nvarchar(40) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [RecordedAtUtc] datetime2 NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_MobileDeliveryEvents] PRIMARY KEY ([MobileDeliveryEventId]),
        CONSTRAINT [FK_MobileDeliveryEvents_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_MobileDeliveryEvents_Users_RecordedByUserId] FOREIGN KEY ([RecordedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [MobileDeviceRegistrations] (
        [MobileDeviceRegistrationId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [DeviceIdentifierHash] nvarchar(64) NOT NULL,
        [Platform] nvarchar(30) NOT NULL,
        [DeviceName] nvarchar(120) NULL,
        [AppVersion] nvarchar(40) NULL,
        [PushToken] nvarchar(2048) NULL,
        [RegisteredAtUtc] datetime2 NOT NULL,
        [LastSeenAtUtc] datetime2 NOT NULL,
        [IsActive] bit NOT NULL,
        [RevokedAtUtc] datetime2 NULL,
        [RevokedByUserId] int NULL,
        [RevocationReason] nvarchar(300) NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_MobileDeviceRegistrations] PRIMARY KEY ([MobileDeviceRegistrationId]),
        CONSTRAINT [FK_MobileDeviceRegistrations_Users_RevokedByUserId] FOREIGN KEY ([RevokedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_MobileDeviceRegistrations_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [MobileIdempotencyRecords] (
        [MobileIdempotencyRecordId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [OperationType] nvarchar(80) NOT NULL,
        [OperationKeyHash] nvarchar(64) NOT NULL,
        [RequestHash] nvarchar(64) NOT NULL,
        [ResponseJson] nvarchar(max) NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        CONSTRAINT [PK_MobileIdempotencyRecords] PRIMARY KEY ([MobileIdempotencyRecordId]),
        CONSTRAINT [FK_MobileIdempotencyRecords_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [NotificationPreferences] (
        [NotificationPreferenceId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [PushEnabled] bit NOT NULL,
        [EmailFallbackEnabled] bit NOT NULL,
        [CriticalAlertsEnabled] bit NOT NULL,
        [QuietHoursStart] nvarchar(5) NULL,
        [QuietHoursEnd] nvarchar(5) NULL,
        [UpdatedAtUtc] datetime2 NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_NotificationPreferences] PRIMARY KEY ([NotificationPreferenceId]),
        CONSTRAINT [FK_NotificationPreferences_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [OperationalNotifications] (
        [OperationalNotificationId] bigint NOT NULL IDENTITY,
        [NotificationType] nvarchar(80) NOT NULL,
        [Severity] nvarchar(20) NOT NULL,
        [Title] nvarchar(180) NOT NULL,
        [Message] nvarchar(1000) NOT NULL,
        [EntityType] nvarchar(100) NULL,
        [EntityId] nvarchar(100) NULL,
        [ActionRoute] nvarchar(300) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [CreatedByUserId] int NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NULL,
        CONSTRAINT [PK_OperationalNotifications] PRIMARY KEY ([OperationalNotificationId]),
        CONSTRAINT [FK_OperationalNotifications_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [PackingScans] (
        [PackingScanId] bigint NOT NULL IDENTITY,
        [SalesOrderId] int NOT NULL,
        [SalesOrderItemId] int NOT NULL,
        [OrderStockReservationId] bigint NOT NULL,
        [ProductBatchId] int NOT NULL,
        [ScannedByUserId] int NOT NULL,
        [QuantityPackedKg] decimal(18,2) NOT NULL,
        [ScannedAtUtc] datetime2 NOT NULL,
        [RemovedAtUtc] datetime2 NULL,
        [RemovedByUserId] int NULL,
        [RemovalReason] nvarchar(500) NULL,
        [OperationKeyHash] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_PackingScans] PRIMARY KEY ([PackingScanId]),
        CONSTRAINT [FK_PackingScans_OrderStockReservations_OrderStockReservationId] FOREIGN KEY ([OrderStockReservationId]) REFERENCES [OrderStockReservations] ([OrderStockReservationId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_ProductBatches_ProductBatchId] FOREIGN KEY ([ProductBatchId]) REFERENCES [ProductBatches] ([ProductBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_SalesOrderItems_SalesOrderItemId] FOREIGN KEY ([SalesOrderItemId]) REFERENCES [SalesOrderItems] ([SalesOrderItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_Users_RemovedByUserId] FOREIGN KEY ([RemovedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_Users_ScannedByUserId] FOREIGN KEY ([ScannedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [StockReceipts] (
        [StockReceiptId] int NOT NULL IDENTITY,
        [SupplierId] int NOT NULL,
        [SupplierOrderId] int NULL,
        [WarehouseSectionId] int NOT NULL,
        [ReceivedByUserId] int NOT NULL,
        [ReceiptNumber] nvarchar(80) NOT NULL,
        [SupplierDocketNumber] nvarchar(100) NULL,
        [PurchaseDateUtc] datetime2 NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [DocketStoredFileId] bigint NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [SubmittedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_StockReceipts] PRIMARY KEY ([StockReceiptId]),
        CONSTRAINT [FK_StockReceipts_StoredFiles_DocketStoredFileId] FOREIGN KEY ([DocketStoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceipts_SupplierOrders_SupplierOrderId] FOREIGN KEY ([SupplierOrderId]) REFERENCES [SupplierOrders] ([SupplierOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceipts_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceipts_Users_ReceivedByUserId] FOREIGN KEY ([ReceivedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceipts_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [StockWriteOffs] (
        [StockWriteOffId] bigint NOT NULL IDENTITY,
        [ProductBatchId] int NOT NULL,
        [SectionId] int NOT NULL,
        [SubmittedByUserId] int NOT NULL,
        [DecidedByUserId] int NULL,
        [QuantityKg] decimal(18,2) NOT NULL,
        [EstimatedUnitCost] decimal(18,2) NOT NULL,
        [EstimatedTotalLoss] decimal(18,2) NOT NULL,
        [ReasonCode] nvarchar(80) NOT NULL,
        [Condition] nvarchar(120) NULL,
        [Notes] nvarchar(1000) NULL,
        [Status] nvarchar(30) NOT NULL,
        [DecisionReason] nvarchar(1000) NULL,
        [SubmittedAtUtc] datetime2 NOT NULL,
        [DecidedAtUtc] datetime2 NULL,
        [CompletedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_StockWriteOffs] PRIMARY KEY ([StockWriteOffId]),
        CONSTRAINT [FK_StockWriteOffs_ProductBatches_ProductBatchId] FOREIGN KEY ([ProductBatchId]) REFERENCES [ProductBatches] ([ProductBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockWriteOffs_Users_DecidedByUserId] FOREIGN KEY ([DecidedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockWriteOffs_Users_SubmittedByUserId] FOREIGN KEY ([SubmittedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockWriteOffs_WarehouseSections_SectionId] FOREIGN KEY ([SectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [BuyerProcurementItems] (
        [BuyerProcurementItemId] int NOT NULL IDENTITY,
        [BuyerProcurementId] int NOT NULL,
        [ProductId] int NOT NULL,
        [SupplierId] int NULL,
        [RecommendedQuantity] decimal(18,2) NOT NULL,
        [RequiredQuantity] decimal(18,2) NOT NULL,
        [ActualQuantity] decimal(18,2) NULL,
        [ActualUnitPrice] decimal(18,2) NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [IsPromotionalItem] bit NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [UnavailableReason] nvarchar(500) NULL,
        [UpdatedAtUtc] datetime2 NOT NULL,
        CONSTRAINT [PK_BuyerProcurementItems] PRIMARY KEY ([BuyerProcurementItemId]),
        CONSTRAINT [FK_BuyerProcurementItems_BuyerProcurements_BuyerProcurementId] FOREIGN KEY ([BuyerProcurementId]) REFERENCES [BuyerProcurements] ([BuyerProcurementId]) ON DELETE CASCADE,
        CONSTRAINT [FK_BuyerProcurementItems_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_BuyerProcurementItems_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [DriverLocationUpdates] (
        [DriverLocationUpdateId] bigint NOT NULL IDENTITY,
        [DriverTrackingSessionId] bigint NOT NULL,
        [Latitude] decimal(9,6) NOT NULL,
        [Longitude] decimal(9,6) NOT NULL,
        [AccuracyMetres] decimal(10,2) NOT NULL,
        [SpeedMetresPerSecond] decimal(10,2) NULL,
        [HeadingDegrees] decimal(6,2) NULL,
        [CapturedAtUtc] datetime2 NOT NULL,
        [ReceivedAtUtc] datetime2 NOT NULL,
        [Source] nvarchar(20) NOT NULL,
        [OperationKeyHash] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_DriverLocationUpdates] PRIMARY KEY ([DriverLocationUpdateId]),
        CONSTRAINT [FK_DriverLocationUpdates_DriverTrackingSessions_DriverTrackingSessionId] FOREIGN KEY ([DriverTrackingSessionId]) REFERENCES [DriverTrackingSessions] ([DriverTrackingSessionId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [OperationalNotificationRecipients] (
        [OperationalNotificationRecipientId] bigint NOT NULL IDENTITY,
        [OperationalNotificationId] bigint NOT NULL,
        [UserId] int NOT NULL,
        [ReadAtUtc] datetime2 NULL,
        [DismissedAtUtc] datetime2 NULL,
        [PushSentAtUtc] datetime2 NULL,
        [EmailSentAtUtc] datetime2 NULL,
        [PushStatus] nvarchar(20) NOT NULL,
        [PushAttemptCount] int NOT NULL,
        [NextPushAttemptAtUtc] datetime2 NULL,
        [SafePushErrorCode] nvarchar(80) NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_OperationalNotificationRecipients] PRIMARY KEY ([OperationalNotificationRecipientId]),
        CONSTRAINT [FK_OperationalNotificationRecipients_OperationalNotifications_OperationalNotificationId] FOREIGN KEY ([OperationalNotificationId]) REFERENCES [OperationalNotifications] ([OperationalNotificationId]) ON DELETE CASCADE,
        CONSTRAINT [FK_OperationalNotificationRecipients_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [StockReceiptItems] (
        [StockReceiptItemId] int NOT NULL IDENTITY,
        [StockReceiptId] int NOT NULL,
        [ProductId] int NOT NULL,
        [ProductBatchId] int NULL,
        [QuantityReceivedKg] decimal(18,2) NOT NULL,
        [AcceptedQuantityKg] decimal(18,2) NOT NULL,
        [RejectedQuantityKg] decimal(18,2) NOT NULL,
        [UnitCost] decimal(18,2) NULL,
        [ContainerCount] int NULL,
        [ContainerType] nvarchar(30) NULL,
        [BatchReference] nvarchar(80) NULL,
        [ReceivedAtUtc] datetime2 NOT NULL,
        [BestBeforeAtUtc] datetime2 NOT NULL,
        [QualityStatus] nvarchar(30) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        CONSTRAINT [PK_StockReceiptItems] PRIMARY KEY ([StockReceiptItemId]),
        CONSTRAINT [FK_StockReceiptItems_ProductBatches_ProductBatchId] FOREIGN KEY ([ProductBatchId]) REFERENCES [ProductBatches] ([ProductBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceiptItems_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceiptItems_StockReceipts_StockReceiptId] FOREIGN KEY ([StockReceiptId]) REFERENCES [StockReceipts] ([StockReceiptId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [StockWriteOffEvidence] (
        [StockWriteOffEvidenceId] bigint NOT NULL IDENTITY,
        [StockWriteOffId] bigint NOT NULL,
        [StoredFileId] bigint NOT NULL,
        [UploadedByUserId] int NOT NULL,
        [UploadedAtUtc] datetime2 NOT NULL,
        [Caption] nvarchar(300) NULL,
        CONSTRAINT [PK_StockWriteOffEvidence] PRIMARY KEY ([StockWriteOffEvidenceId]),
        CONSTRAINT [FK_StockWriteOffEvidence_StockWriteOffs_StockWriteOffId] FOREIGN KEY ([StockWriteOffId]) REFERENCES [StockWriteOffs] ([StockWriteOffId]) ON DELETE CASCADE,
        CONSTRAINT [FK_StockWriteOffEvidence_StoredFiles_StoredFileId] FOREIGN KEY ([StoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockWriteOffEvidence_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [NotificationDeliveryAttempts] (
        [NotificationDeliveryAttemptId] bigint NOT NULL IDENTITY,
        [OperationalNotificationRecipientId] bigint NOT NULL,
        [Channel] nvarchar(20) NOT NULL,
        [Provider] nvarchar(40) NOT NULL,
        [Status] nvarchar(20) NOT NULL,
        [AttemptNumber] int NOT NULL,
        [AttemptedAtUtc] datetime2 NOT NULL,
        [CompletedAtUtc] datetime2 NULL,
        [SafeErrorCode] nvarchar(80) NULL,
        CONSTRAINT [PK_NotificationDeliveryAttempts] PRIMARY KEY ([NotificationDeliveryAttemptId]),
        CONSTRAINT [FK_NotificationDeliveryAttempts_OperationalNotificationRecipients_OperationalNotificationRecipientId] FOREIGN KEY ([OperationalNotificationRecipientId]) REFERENCES [OperationalNotificationRecipients] ([OperationalNotificationRecipientId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (26, NULL, N''Mobile'', N''45'', N''Seconds between foreground driver-location updates.'', N''Location interval'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.LocationIntervalSeconds'', N''300'', N''15'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''45'', N''Integer''),
    (27, NULL, N''Mobile'', N''20'', N''Movement required before another driver-location point is accepted.'', N''Minimum movement'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.LocationMinimumMovementMetres'', N''1000'', N''0'', CAST(0 AS bit), N''metres'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''20'', N''Integer''),
    (28, NULL, N''Mobile'', N''180'', N''Seconds after which an active driver location is shown as stale.'', N''Location stale threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.LocationStaleAfterSeconds'', N''3600'', N''30'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''180'', N''Integer''),
    (29, NULL, N''Mobile'', N''30'', N''Days that detailed delivery-location history is retained.'', N''Location retention'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.LocationRetentionDays'', N''365'', N''1'', CAST(0 AS bit), N''days'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''30'', N''Integer''),
    (30, NULL, N''Mobile'', N''250'', N''Maximum safe draft operations retained by the mobile client.'', N''Offline queue maximum'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.OfflineQueueMaximumItems'', N''2000'', N''10'', CAST(0 AS bit), N''items'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''250'', N''Integer''),
    (31, NULL, N''Mobile'', N''10'', N''Maximum delivery proof photograph size accepted from mobile.'', N''Proof image maximum'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.ProofMaximumMb'', N''25'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (32, NULL, N''Mobile'', N''10'', N''Maximum buying-list or receipt docket image size.'', N''Docket image maximum'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.DocketMaximumMb'', N''25'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (33, NULL, N''Maps'', N''10'', N''Minutes a matching route calculation may be reused.'', N''Route cache'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Maps.RouteCacheMinutes'', N''120'', N''1'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (34, NULL, N''Maps'', N''20'', N''Maximum explicit route refreshes per delivery.'', N''Route refresh limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Maps.MaximumRefreshesPerDelivery'', N''100'', N''1'', CAST(0 AS bit), N''refreshes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''20'', N''Integer''),
    (35, NULL, N''Maps'', N''true'', N''Request traffic-aware travel durations from the configured provider.'', N''Traffic-aware routing'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Maps.TrafficAwareEnabled'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''true'', N''Boolean''),
    (36, NULL, N''Notifications'', N''true'', N''Enable Firebase push processing when protected provider configuration is present.'', N''Push enabled'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Notifications.PushEnabled'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''true'', N''Boolean''),
    (37, NULL, N''Notifications'', N''false'', N''Allow email fallback for supported critical operational notifications.'', N''Email fallback'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Notifications.EmailFallbackEnabled'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''false'', N''Boolean''),
    (38, NULL, N''Notifications'', N''4'', N''Maximum attempts for a transient notification delivery failure.'', N''Maximum retries'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Notifications.MaximumRetryCount'', N''10'', N''0'', CAST(0 AS bit), N''attempts'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''4'', N''Integer''),
    (39, NULL, N''Notifications'', N''60'', N''Base seconds before retrying a transient notification delivery failure.'', N''Retry delay'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Notifications.RetryDelaySeconds'', N''3600'', N''10'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''60'', N''Integer''),
    (40, NULL, N''Write-off'', N''1000'', N''Maximum estimated loss a Warehouse Manager may complete without management approval.'', N''Warehouse Manager value limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.StockTakerMaximumValue'', N''1000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''1000'', N''Decimal''),
    (41, NULL, N''Write-off'', N''100'', N''Maximum quantity a Warehouse Manager may complete without management approval.'', N''Warehouse Manager quantity limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.StockTakerMaximumQuantity'', N''100000'', N''0'', CAST(0 AS bit), N''kg'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''100'', N''Decimal''),
    (42, NULL, N''Write-off'', N''500'', N''Estimated loss above which write-off evidence is required.'', N''Photo threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.RequirePhotoAboveValue'', N''1000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''500'', N''Decimal''),
    (43, NULL, N''Write-off'', N''1000'', N''Estimated loss above which management approval is required.'', N''Approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.RequireApprovalAboveValue'', N''1000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''1000'', N''Decimal''),
    (44, NULL, N''Write-off'', N''true'', N''Block expired batches from normal stock use until a write-off decision is recorded.'', N''Block expired batches'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.AllowExpiredBatchAutomaticBlock'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''true'', N''Boolean'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_BuyerProcurementId_ProductId] ON [BuyerProcurementItems] ([BuyerProcurementId], [ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_ProductId] ON [BuyerProcurementItems] ([ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_SupplierId] ON [BuyerProcurementItems] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurements_AssignedBuyerUserId_BuyingDateUtc_Status] ON [BuyerProcurements] ([AssignedBuyerUserId], [BuyingDateUtc], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurements_CorrelationId] ON [BuyerProcurements] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurements_DocketStoredFileId] ON [BuyerProcurements] ([DocketStoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DeliveryRouteCalculations_DeliveryId_CalculatedAtUtc] ON [DeliveryRouteCalculations] ([DeliveryId], [CalculatedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DeliveryRouteCalculations_DeliveryId_RequestFingerprint] ON [DeliveryRouteCalculations] ([DeliveryId], [RequestFingerprint]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverLocationUpdates_DriverTrackingSessionId_CapturedAtUtc] ON [DriverLocationUpdates] ([DriverTrackingSessionId], [CapturedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_DriverLocationUpdates_Session_Operation] ON [DriverLocationUpdates] ([DriverTrackingSessionId], [OperationKeyHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverTrackingSessions_CorrelationId] ON [DriverTrackingSessions] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverTrackingSessions_DeliveryId_Status] ON [DriverTrackingSessions] ([DeliveryId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverTrackingSessions_DriverId_Status] ON [DriverTrackingSessions] ([DriverId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverTrackingSessions_StartedByUserId] ON [DriverTrackingSessions] ([StartedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [UX_DriverTrackingSessions_ActiveDelivery] ON [DriverTrackingSessions] ([DeliveryId]) WHERE [Status] = ''Active''');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeliveryEvents_CorrelationId] ON [MobileDeliveryEvents] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeliveryEvents_DeliveryId_RecordedAtUtc] ON [MobileDeliveryEvents] ([DeliveryId], [RecordedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeliveryEvents_RecordedByUserId] ON [MobileDeliveryEvents] ([RecordedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeviceRegistrations_IsActive_LastSeenAtUtc] ON [MobileDeviceRegistrations] ([IsActive], [LastSeenAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeviceRegistrations_RevokedByUserId] ON [MobileDeviceRegistrations] ([RevokedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_MobileDeviceRegistrations_User_Device] ON [MobileDeviceRegistrations] ([UserId], [DeviceIdentifierHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileIdempotencyRecords_ExpiresAtUtc] ON [MobileIdempotencyRecords] ([ExpiresAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_MobileIdempotency_User_Operation_Key] ON [MobileIdempotencyRecords] ([UserId], [OperationType], [OperationKeyHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_NotificationDeliveryAttempts_OperationalNotificationRecipientId_AttemptNumber] ON [NotificationDeliveryAttempts] ([OperationalNotificationRecipientId], [AttemptNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [IX_NotificationPreferences_UserId] ON [NotificationPreferences] ([UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotificationRecipients_PushStatus_NextPushAttemptAtUtc] ON [OperationalNotificationRecipients] ([PushStatus], [NextPushAttemptAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotificationRecipients_UserId_ReadAtUtc_DismissedAtUtc] ON [OperationalNotificationRecipients] ([UserId], [ReadAtUtc], [DismissedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_NotificationRecipients_Notification_User] ON [OperationalNotificationRecipients] ([OperationalNotificationId], [UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotifications_CorrelationId] ON [OperationalNotifications] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotifications_CreatedAtUtc_NotificationType] ON [OperationalNotifications] ([CreatedAtUtc], [NotificationType]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotifications_CreatedByUserId] ON [OperationalNotifications] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_OrderStockReservationId] ON [PackingScans] ([OrderStockReservationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_ProductBatchId] ON [PackingScans] ([ProductBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_RemovedByUserId] ON [PackingScans] ([RemovedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_SalesOrderId_ScannedAtUtc] ON [PackingScans] ([SalesOrderId], [ScannedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_SalesOrderItemId] ON [PackingScans] ([SalesOrderItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_PackingScans_User_Operation] ON [PackingScans] ([ScannedByUserId], [OperationKeyHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceiptItems_ProductBatchId] ON [StockReceiptItems] ([ProductBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceiptItems_ProductId] ON [StockReceiptItems] ([ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceiptItems_StockReceiptId_ProductId] ON [StockReceiptItems] ([StockReceiptId], [ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_CorrelationId] ON [StockReceipts] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_DocketStoredFileId] ON [StockReceipts] ([DocketStoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [IX_StockReceipts_ReceiptNumber] ON [StockReceipts] ([ReceiptNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_ReceivedByUserId] ON [StockReceipts] ([ReceivedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_Status_PurchaseDateUtc] ON [StockReceipts] ([Status], [PurchaseDateUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_SupplierId] ON [StockReceipts] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_SupplierOrderId] ON [StockReceipts] ([SupplierOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_WarehouseSectionId] ON [StockReceipts] ([WarehouseSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffEvidence_StockWriteOffId_UploadedAtUtc] ON [StockWriteOffEvidence] ([StockWriteOffId], [UploadedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffEvidence_StoredFileId] ON [StockWriteOffEvidence] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffEvidence_UploadedByUserId] ON [StockWriteOffEvidence] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_CorrelationId] ON [StockWriteOffs] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_DecidedByUserId] ON [StockWriteOffs] ([DecidedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_ProductBatchId_Status] ON [StockWriteOffs] ([ProductBatchId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_SectionId] ON [StockWriteOffs] ([SectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_Status_SubmittedAtUtc] ON [StockWriteOffs] ([Status], [SubmittedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_SubmittedByUserId] ON [StockWriteOffs] ([SubmittedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM dbo.Roles WHERE RoleCode = 'MarketBuyer')
    BEGIN
        INSERT INTO dbo.Roles
            (RoleCode, RoleName, Description, IsSystemRole, IsActive, CreatedAtUtc)
        VALUES
            ('MarketBuyer', 'Market Buyer',
             'Mobile purchasing user for approved buying lists.',
             1, 1, SYSUTCDATETIME());
    END;
    DECLARE @PhaseCPermissions TABLE
    (
        PermissionCode nvarchar(100) NOT NULL PRIMARY KEY,
        DisplayName nvarchar(120) NOT NULL,
        Module nvarchar(80) NOT NULL
    );
    INSERT INTO @PhaseCPermissions VALUES
        ('Mobile.Access', 'Access PhenyoSync Mobile', 'Mobile'),
        ('Mobile.Delivery.ViewOwn', 'View own mobile deliveries', 'Mobile'),
        ('Mobile.Delivery.ViewAll', 'View all mobile deliveries', 'Mobile'),
        ('Mobile.Delivery.UpdateOwn', 'Update own mobile delivery', 'Mobile'),
        ('Mobile.Delivery.CompleteOwn', 'Complete own mobile delivery', 'Mobile'),
        ('Mobile.Delivery.UploadProof', 'Upload mobile delivery proof', 'Mobile'),
        ('Mobile.BuyingList.View', 'View mobile buying lists', 'Mobile'),
        ('Mobile.BuyingList.Update', 'Update mobile buying lists', 'Mobile'),
        ('Mobile.BuyingList.Submit', 'Submit mobile buying lists', 'Mobile'),
        ('Mobile.BuyingList.AddPromotionalItem', 'Add promotional buying items', 'Mobile'),
        ('Mobile.BuyingList.UploadDocket', 'Upload buying-list dockets', 'Mobile'),
        ('Mobile.StockReceipt.View', 'View mobile stock receipts', 'Mobile'),
        ('Mobile.StockReceipt.Create', 'Create mobile stock receipts', 'Mobile'),
        ('Mobile.StockReceipt.Submit', 'Submit mobile stock receipts', 'Mobile'),
        ('Mobile.StockReceipt.UploadDocket', 'Upload stock-receipt dockets', 'Mobile'),
        ('Mobile.Packing.View', 'View mobile packing work', 'Mobile'),
        ('Mobile.Packing.Scan', 'Scan packed Product Batches', 'Mobile'),
        ('Mobile.Packing.RemoveScan', 'Correct packing scans', 'Mobile'),
        ('Mobile.Packing.Complete', 'Complete mobile packing', 'Mobile'),
        ('Mobile.Dispatch.View', 'View dispatch queue', 'Mobile'),
        ('Mobile.Dispatch.Confirm', 'Confirm order dispatch', 'Mobile'),
        ('Mobile.Dispatch.Reject', 'Reject or return packed orders', 'Mobile'),
        ('Mobile.Tracking.ShareOwn', 'Share own delivery location', 'Mobile'),
        ('Mobile.Tracking.ViewOwn', 'View own delivery tracking', 'Mobile'),
        ('Mobile.Tracking.ViewAll', 'View all delivery tracking', 'Mobile'),
        ('Mobile.Tracking.Manage', 'Manage delivery tracking', 'Mobile'),
        ('Mobile.WriteOff.View', 'View mobile stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Create', 'Create mobile stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Complete', 'Complete ordinary stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Approve', 'Approve stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Reject', 'Reject stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Override', 'Override stock write-off rules', 'Mobile'),
        ('Mobile.WriteOff.UploadEvidence', 'Upload stock write-off evidence', 'Mobile'),
        ('Mobile.WriteOff.ViewFinancialImpact', 'View write-off financial impact', 'Mobile'),
        ('Mobile.DeviceManagement.View', 'View registered mobile devices', 'Mobile'),
        ('Mobile.DeviceManagement.Manage', 'Manage registered mobile devices', 'Mobile'),
        ('Notifications.View', 'View operational notifications', 'Notifications'),
        ('Notifications.ManagePreferences', 'Manage notification preferences', 'Notifications'),
        ('Notifications.ManageRules', 'Manage notification rules', 'Notifications'),
        ('Notifications.ViewDeliveryHistory', 'View notification delivery history', 'Notifications'),
        ('Notifications.SendTest', 'Send test notifications', 'Notifications');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT seed.PermissionCode, seed.PermissionCode,
           seed.DisplayName, seed.Module, 1, 1, SYSUTCDATETIME()
    FROM @PhaseCPermissions seed
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode);
    UPDATE permission
    SET permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @PhaseCPermissions seed
      ON seed.PermissionCode = permission.PermissionCode;
    DECLARE @PhaseCRolePermissions TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL,
        PRIMARY KEY (RoleCode, PermissionCode)
    );
    INSERT INTO @PhaseCRolePermissions
    SELECT roleCode.RoleCode, permission.PermissionCode
    FROM (VALUES ('CEO'), ('COO'), ('BusinessManager'))
         roleCode(RoleCode)
    CROSS JOIN @PhaseCPermissions permission;
    INSERT INTO @PhaseCRolePermissions VALUES
        ('Driver', 'Mobile.Access'),
        ('Driver', 'Mobile.Delivery.ViewOwn'),
        ('Driver', 'Mobile.Delivery.UpdateOwn'),
        ('Driver', 'Mobile.Delivery.CompleteOwn'),
        ('Driver', 'Mobile.Delivery.UploadProof'),
        ('Driver', 'Mobile.Tracking.ShareOwn'),
        ('Driver', 'Mobile.Tracking.ViewOwn'),
        ('Driver', 'Notifications.View'),
        ('Driver', 'Notifications.ManagePreferences'),
        ('Packer', 'Mobile.Access'),
        ('Packer', 'Mobile.Packing.View'),
        ('Packer', 'Mobile.Packing.Scan'),
        ('Packer', 'Mobile.Packing.RemoveScan'),
        ('Packer', 'Mobile.Packing.Complete'),
        ('Packer', 'Notifications.View'),
        ('Packer', 'Notifications.ManagePreferences'),
        ('WarehouseManager', 'Mobile.Access'),
        ('WarehouseManager', 'Suppliers.View'),
        ('WarehouseManager', 'Mobile.BuyingList.View'),
        ('WarehouseManager', 'Mobile.StockReceipt.View'),
        ('WarehouseManager', 'Mobile.StockReceipt.Create'),
        ('WarehouseManager', 'Mobile.StockReceipt.Submit'),
        ('WarehouseManager', 'Mobile.StockReceipt.UploadDocket'),
        ('WarehouseManager', 'Mobile.WriteOff.View'),
        ('WarehouseManager', 'Mobile.WriteOff.Create'),
        ('WarehouseManager', 'Mobile.WriteOff.Complete'),
        ('WarehouseManager', 'Mobile.WriteOff.UploadEvidence'),
        ('WarehouseManager', 'Mobile.WriteOff.ViewFinancialImpact'),
        ('WarehouseManager', 'Notifications.View'),
        ('WarehouseManager', 'Notifications.ManagePreferences'),
        ('MarketBuyer', 'Mobile.Access'),
        ('MarketBuyer', 'Mobile.BuyingList.View'),
        ('MarketBuyer', 'Mobile.BuyingList.Update'),
        ('MarketBuyer', 'Mobile.BuyingList.Submit'),
        ('MarketBuyer', 'Mobile.BuyingList.AddPromotionalItem'),
        ('MarketBuyer', 'Mobile.BuyingList.UploadDocket'),
        ('MarketBuyer', 'Notifications.View'),
        ('MarketBuyer', 'Notifications.ManagePreferences');
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM @PhaseCRolePermissions seed
    JOIN dbo.Roles role
      ON role.RoleCode = seed.RoleCode
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = seed.PermissionCode
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.RolePermissions existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId = permission.PermissionId);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260725200523_PhaseCMobileOperationsTrackingNotifications', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var5 sysname;
    SELECT @var5 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'Status');
    IF @var5 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var5 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [Status] nvarchar(450) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var6 sysname;
    SELECT @var6 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'Phone');
    IF @var6 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var6 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [Phone] nvarchar(30) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var7 sysname;
    SELECT @var7 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'Email');
    IF @var7 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var7 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [Email] nvarchar(254) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var8 sysname;
    SELECT @var8 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'ContactPerson');
    IF @var8 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var8 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [ContactPerson] nvarchar(150) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var9 sysname;
    SELECT @var9 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[Suppliers]') AND [c].[name] = N'Address');
    IF @var9 IS NOT NULL EXEC(N'ALTER TABLE [Suppliers] DROP CONSTRAINT [' + @var9 + '];');
    ALTER TABLE [Suppliers] ALTER COLUMN [Address] nvarchar(500) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [CreatedAtUtc] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [NormalizedEmail] nvarchar(254) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [SupplierCode] nvarchar(40) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [SupplierTypeCode] nvarchar(40) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Suppliers] ADD [UpdatedAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [ApprovedAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [ApprovedByUserId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [CancelledAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [CreatedAtUtc] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [CreatedByUserId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [ExpectedDeliveryAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [Notes] nvarchar(1000) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [OrderNumber] nvarchar(40) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [Status] nvarchar(40) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD [WarehouseSectionId] int NOT NULL DEFAULT 0;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Customers] ADD [ContactPerson] nvarchar(150) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Customers] ADD [NormalizedEmail] nvarchar(254) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [Customers] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @var10 sysname;
    SELECT @var10 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[BuyerProcurementItems]') AND [c].[name] = N'ProductId');
    IF @var10 IS NOT NULL EXEC(N'ALTER TABLE [BuyerProcurementItems] DROP CONSTRAINT [' + @var10 + '];');
    ALTER TABLE [BuyerProcurementItems] ALTER COLUMN [ProductId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD [RawStockItemId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    UPDATE dbo.Suppliers
    SET SupplierCode =
            CONCAT('SUP-', RIGHT(CONCAT('000000', SupplierId), 6)),
        SupplierTypeCode =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(SupplierTypeCode)), '') IS NULL
                    THEN 'GENERAL_SUPPLIER'
                ELSE UPPER(LTRIM(RTRIM(SupplierTypeCode)))
            END,
        NormalizedEmail =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(Email)), '') IS NULL THEN NULL
                ELSE UPPER(LTRIM(RTRIM(Email)))
            END,
        CreatedAtUtc =
            CASE
                WHEN CreatedAtUtc = '0001-01-01T00:00:00'
                    THEN SYSUTCDATETIME()
                ELSE CreatedAtUtc
            END;
    UPDATE dbo.Customers
    SET NormalizedEmail = UPPER(LTRIM(RTRIM(Email)));
    IF EXISTS (
        SELECT NormalizedEmail
        FROM dbo.Customers
        GROUP BY NormalizedEmail
        HAVING COUNT(*) > 1)
    BEGIN
        THROW 51001,
            'Duplicate customer emails must be resolved before the operational-sections migration can continue.',
            1;
    END;
    IF EXISTS (SELECT 1 FROM dbo.SupplierOrders)
       AND NOT EXISTS (SELECT 1 FROM dbo.WarehouseSections)
    BEGIN
        THROW 51002,
            'At least one Warehouse Section is required to backfill existing Supplier Orders.',
            1;
    END;
    UPDATE supplierOrder
    SET OrderNumber =
            CONCAT('SUPORD-', RIGHT(CONCAT('00000000', SupplierOrderId), 8)),
        Status =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(Status)), '') IS NULL
                    THEN 'Draft'
                ELSE Status
            END,
        CreatedAtUtc =
            CASE
                WHEN CreatedAtUtc = '0001-01-01T00:00:00'
                    THEN COALESCE(OrderDate, SYSUTCDATETIME())
                ELSE CreatedAtUtc
            END,
        WarehouseSectionId =
            (SELECT TOP (1) SectionId
             FROM dbo.WarehouseSections
             ORDER BY
                 CASE WHEN Status = 'Active' THEN 0 ELSE 1 END,
                 SectionId)
    FROM dbo.SupplierOrders supplierOrder;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [FinancialPayments] (
        [FinancialPaymentId] bigint NOT NULL IDENTITY,
        [PaymentNumber] nvarchar(40) NOT NULL,
        [CounterpartyType] nvarchar(20) NOT NULL,
        [CustomerId] int NULL,
        [SupplierId] int NULL,
        [InvoiceId] int NULL,
        [SupplierOrderId] int NULL,
        [OriginalPaymentId] bigint NULL,
        [Amount] decimal(18,2) NOT NULL,
        [PaymentDateUtc] datetime2 NOT NULL,
        [PaymentMethodCode] nvarchar(40) NOT NULL,
        [Reference] nvarchar(120) NULL,
        [Notes] nvarchar(1000) NULL,
        [Status] nvarchar(40) NOT NULL,
        [ReversalReason] nvarchar(1000) NULL,
        [CreatedByUserId] int NOT NULL,
        [PostedByUserId] int NULL,
        [DecidedByUserId] int NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [PostedAtUtc] datetime2 NULL,
        [DecidedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_FinancialPayments] PRIMARY KEY ([FinancialPaymentId]),
        CONSTRAINT [FK_FinancialPayments_Customers_CustomerId] FOREIGN KEY ([CustomerId]) REFERENCES [Customers] ([CustomerId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_FinancialPayments_OriginalPaymentId] FOREIGN KEY ([OriginalPaymentId]) REFERENCES [FinancialPayments] ([FinancialPaymentId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Invoices_InvoiceId] FOREIGN KEY ([InvoiceId]) REFERENCES [Invoices] ([InvoiceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_SupplierOrders_SupplierOrderId] FOREIGN KEY ([SupplierOrderId]) REFERENCES [SupplierOrders] ([SupplierOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Users_DecidedByUserId] FOREIGN KEY ([DecidedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_FinancialPayments_Users_PostedByUserId] FOREIGN KEY ([PostedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [OperationalReasons] (
        [OperationalReasonId] int NOT NULL IDENTITY,
        [ReasonCode] nvarchar(40) NOT NULL,
        [ReasonName] nvarchar(120) NOT NULL,
        [CategoryCode] nvarchar(40) NOT NULL,
        [Description] nvarchar(1000) NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_OperationalReasons] PRIMARY KEY ([OperationalReasonId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockItems] (
        [RawStockItemId] int NOT NULL IDENTITY,
        [ItemCode] nvarchar(40) NOT NULL,
        [ItemName] nvarchar(160) NOT NULL,
        [CategoryCode] nvarchar(30) NOT NULL,
        [DefaultUnitOfMeasure] nvarchar(20) NOT NULL,
        [Description] nvarchar(1000) NULL,
        [IsProduce] bit NOT NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockItems] PRIMARY KEY ([RawStockItemId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockReceipts] (
        [RawStockReceiptId] bigint NOT NULL IDENTITY,
        [ReceiptNumber] nvarchar(40) NOT NULL,
        [SourceType] nvarchar(30) NOT NULL,
        [SupplierId] int NOT NULL,
        [SupplierOrderId] int NULL,
        [BuyerProcurementId] int NULL,
        [WarehouseSectionId] int NOT NULL,
        [ReceivedByUserId] int NOT NULL,
        [DocketReference] nvarchar(120) NOT NULL,
        [AdHocExplanation] nvarchar(1000) NULL,
        [Notes] nvarchar(1000) NULL,
        [ReceivedAtUtc] datetime2 NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [PostedAtUtc] datetime2 NULL,
        [Status] nvarchar(30) NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [OperationKeyHash] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockReceipts] PRIMARY KEY ([RawStockReceiptId]),
        CONSTRAINT [FK_RawStockReceipts_BuyerProcurements_BuyerProcurementId] FOREIGN KEY ([BuyerProcurementId]) REFERENCES [BuyerProcurements] ([BuyerProcurementId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceipts_SupplierOrders_SupplierOrderId] FOREIGN KEY ([SupplierOrderId]) REFERENCES [SupplierOrders] ([SupplierOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceipts_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceipts_Users_ReceivedByUserId] FOREIGN KEY ([ReceivedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceipts_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockReconciliationGroups] (
        [RawStockReconciliationGroupId] int NOT NULL IDENTITY,
        [GroupCode] nvarchar(40) NOT NULL,
        [GroupName] nvarchar(120) NOT NULL,
        [Description] nvarchar(1000) NULL,
        [IsActive] bit NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockReconciliationGroups] PRIMARY KEY ([RawStockReconciliationGroupId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockTakeSessions] (
        [RawStockTakeSessionId] bigint NOT NULL IDENTITY,
        [WarehouseSectionId] int NOT NULL,
        [CreatedByUserId] int NOT NULL,
        [ReviewedByUserId] int NULL,
        [DecidedByUserId] int NULL,
        [PeriodStartUtc] datetime2 NOT NULL,
        [PeriodEndUtc] datetime2 NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [SubmittedAtUtc] datetime2 NULL,
        [ReviewedAtUtc] datetime2 NULL,
        [DecidedAtUtc] datetime2 NULL,
        [ClosedAtUtc] datetime2 NULL,
        [Status] nvarchar(40) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [AdministratorReviewNotes] nvarchar(1000) NULL,
        [ManagementDecisionReason] nvarchar(1000) NULL,
        [ManagementApprovalRequired] bit NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockTakeSessions] PRIMARY KEY ([RawStockTakeSessionId]),
        CONSTRAINT [FK_RawStockTakeSessions_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeSessions_Users_DecidedByUserId] FOREIGN KEY ([DecidedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeSessions_Users_ReviewedByUserId] FOREIGN KEY ([ReviewedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeSessions_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockBalances] (
        [RawStockBalanceId] int NOT NULL IDENTITY,
        [RawStockItemId] int NOT NULL,
        [WarehouseSectionId] int NOT NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [QuantityOnHand] decimal(18,3) NOT NULL,
        [ReservedQuantity] decimal(18,3) NOT NULL,
        [WeightedAverageUnitCost] decimal(18,4) NOT NULL,
        [LastReceiptAtUtc] datetime2 NULL,
        [LastStockTakeAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockBalances] PRIMARY KEY ([RawStockBalanceId]),
        CONSTRAINT [FK_RawStockBalances_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockBalances_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [SupplierOrderLines] (
        [SupplierOrderLineId] int NOT NULL IDENTITY,
        [SupplierOrderId] int NOT NULL,
        [RawStockItemId] int NOT NULL,
        [OrderedQuantity] decimal(18,3) NOT NULL,
        [ReceivedQuantity] decimal(18,3) NOT NULL,
        [ExpectedUnitPrice] decimal(18,4) NOT NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [Notes] nvarchar(500) NULL,
        CONSTRAINT [PK_SupplierOrderLines] PRIMARY KEY ([SupplierOrderLineId]),
        CONSTRAINT [FK_SupplierOrderLines_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SupplierOrderLines_SupplierOrders_SupplierOrderId] FOREIGN KEY ([SupplierOrderId]) REFERENCES [SupplierOrders] ([SupplierOrderId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockReceiptLines] (
        [RawStockReceiptLineId] bigint NOT NULL IDENTITY,
        [RawStockReceiptId] bigint NOT NULL,
        [RawStockItemId] int NOT NULL,
        [QuantityReceived] decimal(18,3) NOT NULL,
        [AcceptedQuantity] decimal(18,3) NOT NULL,
        [RejectedQuantity] decimal(18,3) NOT NULL,
        [UnitCost] decimal(18,4) NOT NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [SupplierBatchReference] nvarchar(80) NULL,
        [BestBeforeAtUtc] datetime2 NULL,
        [Notes] nvarchar(500) NULL,
        CONSTRAINT [PK_RawStockReceiptLines] PRIMARY KEY ([RawStockReceiptLineId]),
        CONSTRAINT [FK_RawStockReceiptLines_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReceiptLines_RawStockReceipts_RawStockReceiptId] FOREIGN KEY ([RawStockReceiptId]) REFERENCES [RawStockReceipts] ([RawStockReceiptId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [ProductReconciliationMappings] (
        [ProductReconciliationMappingId] int NOT NULL IDENTITY,
        [RawStockReconciliationGroupId] int NOT NULL,
        [ProductId] int NOT NULL,
        CONSTRAINT [PK_ProductReconciliationMappings] PRIMARY KEY ([ProductReconciliationMappingId]),
        CONSTRAINT [FK_ProductReconciliationMappings_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_ProductReconciliationMappings_RawStockReconciliationGroups_RawStockReconciliationGroupId] FOREIGN KEY ([RawStockReconciliationGroupId]) REFERENCES [RawStockReconciliationGroups] ([RawStockReconciliationGroupId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockReconciliationGroupItems] (
        [RawStockReconciliationGroupItemId] int NOT NULL IDENTITY,
        [RawStockReconciliationGroupId] int NOT NULL,
        [RawStockItemId] int NOT NULL,
        CONSTRAINT [PK_RawStockReconciliationGroupItems] PRIMARY KEY ([RawStockReconciliationGroupItemId]),
        CONSTRAINT [FK_RawStockReconciliationGroupItems_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockReconciliationGroupItems_RawStockReconciliationGroups_RawStockReconciliationGroupId] FOREIGN KEY ([RawStockReconciliationGroupId]) REFERENCES [RawStockReconciliationGroups] ([RawStockReconciliationGroupId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockTakeLines] (
        [RawStockTakeLineId] bigint NOT NULL IDENTITY,
        [RawStockTakeSessionId] bigint NOT NULL,
        [RawStockItemId] int NOT NULL,
        [RawStockBalanceId] int NOT NULL,
        [RawStockReconciliationGroupId] int NULL,
        [OpeningRawStock] decimal(18,3) NOT NULL,
        [RawStockReceived] decimal(18,3) NOT NULL,
        [ApprovedPositiveAdjustments] decimal(18,3) NOT NULL,
        [ExistingPackedProductWeight] decimal(18,3) NOT NULL,
        [RecordedRawStockWriteOffs] decimal(18,3) NOT NULL,
        [ApprovedNegativeAdjustments] decimal(18,3) NOT NULL,
        [EstimatedRawStockRemaining] decimal(18,3) NOT NULL,
        [PhysicalStockCount] decimal(18,3) NULL,
        [UnexplainedStockDifference] decimal(18,3) NULL,
        [EstimatedFinancialImpact] decimal(18,3) NOT NULL,
        [IsMapped] bit NOT NULL,
        [RequiresManagementApproval] bit NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockTakeLines] PRIMARY KEY ([RawStockTakeLineId]),
        CONSTRAINT [FK_RawStockTakeLines_RawStockBalances_RawStockBalanceId] FOREIGN KEY ([RawStockBalanceId]) REFERENCES [RawStockBalances] ([RawStockBalanceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeLines_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeLines_RawStockReconciliationGroups_RawStockReconciliationGroupId] FOREIGN KEY ([RawStockReconciliationGroupId]) REFERENCES [RawStockReconciliationGroups] ([RawStockReconciliationGroupId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockTakeLines_RawStockTakeSessions_RawStockTakeSessionId] FOREIGN KEY ([RawStockTakeSessionId]) REFERENCES [RawStockTakeSessions] ([RawStockTakeSessionId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockBatches] (
        [RawStockBatchId] bigint NOT NULL IDENTITY,
        [RawStockItemId] int NOT NULL,
        [RawStockBalanceId] int NOT NULL,
        [SupplierId] int NULL,
        [RawStockReceiptLineId] bigint NULL,
        [BatchCode] nvarchar(70) NOT NULL,
        [QrCodeValue] nvarchar(220) NOT NULL,
        [QuantityReceived] decimal(18,3) NOT NULL,
        [QuantityRemaining] decimal(18,3) NOT NULL,
        [UnitCost] decimal(18,4) NOT NULL,
        [ReceivedAtUtc] datetime2 NOT NULL,
        [BestBeforeAtUtc] datetime2 NULL,
        [Status] nvarchar(30) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockBatches] PRIMARY KEY ([RawStockBatchId]),
        CONSTRAINT [FK_RawStockBatches_RawStockBalances_RawStockBalanceId] FOREIGN KEY ([RawStockBalanceId]) REFERENCES [RawStockBalances] ([RawStockBalanceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockBatches_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockBatches_RawStockReceiptLines_RawStockReceiptLineId] FOREIGN KEY ([RawStockReceiptLineId]) REFERENCES [RawStockReceiptLines] ([RawStockReceiptLineId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockBatches_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockMovements] (
        [RawStockMovementId] bigint NOT NULL IDENTITY,
        [RawStockItemId] int NOT NULL,
        [RawStockBalanceId] int NOT NULL,
        [RawStockBatchId] bigint NULL,
        [OperationalReasonId] int NULL,
        [CreatedByUserId] int NOT NULL,
        [MovementType] nvarchar(40) NOT NULL,
        [QuantityChange] decimal(18,3) NOT NULL,
        [UnitCost] decimal(18,4) NOT NULL,
        [OccurredAtUtc] datetime2 NOT NULL,
        [SourceType] nvarchar(80) NULL,
        [SourceId] nvarchar(80) NULL,
        [ReasonText] nvarchar(1000) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_RawStockMovements] PRIMARY KEY ([RawStockMovementId]),
        CONSTRAINT [FK_RawStockMovements_OperationalReasons_OperationalReasonId] FOREIGN KEY ([OperationalReasonId]) REFERENCES [OperationalReasons] ([OperationalReasonId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockMovements_RawStockBalances_RawStockBalanceId] FOREIGN KEY ([RawStockBalanceId]) REFERENCES [RawStockBalances] ([RawStockBalanceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockMovements_RawStockBatches_RawStockBatchId] FOREIGN KEY ([RawStockBatchId]) REFERENCES [RawStockBatches] ([RawStockBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockMovements_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockMovements_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockWriteOffs] (
        [RawStockWriteOffId] bigint NOT NULL IDENTITY,
        [RawStockItemId] int NOT NULL,
        [RawStockBalanceId] int NOT NULL,
        [RawStockBatchId] bigint NULL,
        [OperationalReasonId] int NOT NULL,
        [SubmittedByUserId] int NOT NULL,
        [DecidedByUserId] int NULL,
        [Quantity] decimal(18,3) NOT NULL,
        [EstimatedUnitCost] decimal(18,4) NOT NULL,
        [EstimatedTotalLoss] decimal(18,2) NOT NULL,
        [Condition] nvarchar(120) NULL,
        [Notes] nvarchar(1000) NULL,
        [Status] nvarchar(30) NOT NULL,
        [DecisionReason] nvarchar(1000) NULL,
        [SubmittedAtUtc] datetime2 NOT NULL,
        [DecidedAtUtc] datetime2 NULL,
        [CompletedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_RawStockWriteOffs] PRIMARY KEY ([RawStockWriteOffId]),
        CONSTRAINT [FK_RawStockWriteOffs_OperationalReasons_OperationalReasonId] FOREIGN KEY ([OperationalReasonId]) REFERENCES [OperationalReasons] ([OperationalReasonId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_RawStockBalances_RawStockBalanceId] FOREIGN KEY ([RawStockBalanceId]) REFERENCES [RawStockBalances] ([RawStockBalanceId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_RawStockBatches_RawStockBatchId] FOREIGN KEY ([RawStockBatchId]) REFERENCES [RawStockBatches] ([RawStockBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_Users_DecidedByUserId] FOREIGN KEY ([DecidedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffs_Users_SubmittedByUserId] FOREIGN KEY ([SubmittedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE TABLE [RawStockWriteOffEvidence] (
        [RawStockWriteOffEvidenceId] bigint NOT NULL IDENTITY,
        [RawStockWriteOffId] bigint NOT NULL,
        [StoredFileId] bigint NOT NULL,
        [UploadedByUserId] int NOT NULL,
        [UploadedAtUtc] datetime2 NOT NULL,
        [Caption] nvarchar(300) NULL,
        CONSTRAINT [PK_RawStockWriteOffEvidence] PRIMARY KEY ([RawStockWriteOffEvidenceId]),
        CONSTRAINT [FK_RawStockWriteOffEvidence_RawStockWriteOffs_RawStockWriteOffId] FOREIGN KEY ([RawStockWriteOffId]) REFERENCES [RawStockWriteOffs] ([RawStockWriteOffId]) ON DELETE CASCADE,
        CONSTRAINT [FK_RawStockWriteOffEvidence_StoredFiles_StoredFileId] FOREIGN KEY ([StoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_RawStockWriteOffEvidence_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (45, NULL, N''Raw stock take'', N''25'', N''Absolute raw-stock variance above which management approval is required.'', N''Quantity approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStockTake.RequireApprovalAboveKg'', N''100000'', N''0'', CAST(0 AS bit), N''kg'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''25'', N''Decimal''),
    (46, NULL, N''Raw stock take'', N''5'', N''Percentage raw-stock variance above which management approval is required.'', N''Percentage approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStockTake.RequireApprovalAbovePercentage'', N''100'', N''0'', CAST(0 AS bit), N''percent'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''Decimal''),
    (47, NULL, N''Raw stock take'', N''1000'', N''Estimated financial impact above which management approval is required.'', N''Value approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStockTake.RequireApprovalAboveValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''1000'', N''Decimal''),
    (48, NULL, N''Payments'', N''5000'', N''Maximum payment value an Administrator may reverse on the capture day.'', N''Administrator same-day reversal limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Payments.AdminVoidSameDayMaximumValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5000'', N''Decimal''),
    (49, NULL, N''Payments'', N''24'', N''Hours after posting when a payment reversal requires management approval.'', N''Reversal approval hours'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Payments.RequireManagementApprovalAfterHours'', N''720'', N''0'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''24'', N''Integer''),
    (50, NULL, N''Payments'', N''5000'', N''Payment value above which reversal requires management approval.'', N''Reversal approval value'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Payments.RequireManagementApprovalAboveValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5000'', N''Decimal''),
    (51, NULL, N''Raw stock'', N''100'', N''Raw-stock write-off quantity above which management approval is required.'', N''Write-off quantity approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStock.WriteOffRequireApprovalAboveQuantity'', N''1000000'', N''0'', CAST(0 AS bit), N''units'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''100'', N''Decimal''),
    (52, NULL, N''Raw stock'', N''1000'', N''Raw-stock write-off value above which management approval is required.'', N''Write-off value approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStock.WriteOffRequireApprovalAboveValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''1000'', N''Decimal''),
    (53, NULL, N''Raw stock'', N''500'', N''Raw-stock loss above which photographic evidence is required.'', N''Write-off evidence threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''RawStock.WriteOffEvidenceAboveValue'', N''10000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''500'', N''Decimal'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    DECLARE @OperationalPermissions TABLE
    (
        PermissionCode nvarchar(100) NOT NULL PRIMARY KEY,
        DisplayName nvarchar(120) NOT NULL,
        Module nvarchar(80) NOT NULL
    );
    INSERT INTO @OperationalPermissions VALUES
        ('RawStock.View', 'View raw stock', 'RawStock'),
        ('RawStock.Manage', 'Create and maintain raw-stock items', 'RawStock'),
        ('RawStock.Receive', 'Receive raw stock into warehouse balances', 'RawStock'),
        ('RawStock.WriteOff', 'Submit raw-stock write-offs', 'RawStock'),
        ('RawStock.ApproveWriteOff', 'Approve raw-stock write-offs', 'RawStock'),
        ('RawStockTakes.View', 'View raw-stock takes', 'RawStock'),
        ('RawStockTakes.Capture', 'Capture and submit raw-stock takes', 'RawStock'),
        ('RawStockTakes.Review', 'Review raw-stock takes', 'RawStock'),
        ('RawStockTakes.Approve', 'Approve raw-stock-take adjustments', 'RawStock'),
        ('OperationalReasons.View', 'View operational reasons', 'Configuration'),
        ('OperationalReasons.Manage', 'Manage operational reasons', 'Configuration'),
        ('SupplierOrders.View', 'View supplier orders', 'Suppliers'),
        ('SupplierOrders.Manage', 'Create and maintain supplier orders', 'Suppliers'),
        ('CustomerPayments.View', 'View customer payments', 'Payments'),
        ('CustomerPayments.Capture', 'Capture customer payments', 'Payments'),
        ('CustomerPayments.Reverse', 'Request customer-payment reversal', 'Payments'),
        ('CustomerPayments.ApproveReversal', 'Approve customer-payment reversal', 'Payments'),
        ('SupplierPayments.View', 'View supplier payments', 'Payments'),
        ('SupplierPayments.Capture', 'Capture supplier payments', 'Payments'),
        ('SupplierPayments.Reverse', 'Request supplier-payment reversal', 'Payments'),
        ('SupplierPayments.ApproveReversal', 'Approve supplier-payment reversal', 'Payments'),
        ('Reconciliation.View', 'View raw-stock reconciliation mappings', 'RawStock'),
        ('Reconciliation.Manage', 'Manage raw-stock reconciliation mappings', 'RawStock'),
        ('ManagementDashboard.View', 'View management operational dashboard', 'Dashboard');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT seed.PermissionCode, seed.PermissionCode,
           seed.DisplayName, seed.Module, 1, 1, SYSUTCDATETIME()
    FROM @OperationalPermissions seed
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode);
    UPDATE permission
    SET permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @OperationalPermissions seed
      ON seed.PermissionCode = permission.PermissionCode;
    DECLARE @OperationalRolePermissions TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL,
        PRIMARY KEY (RoleCode, PermissionCode)
    );
    INSERT INTO @OperationalRolePermissions
    SELECT roleCode.RoleCode, permission.PermissionCode
    FROM (VALUES ('CEO'), ('COO'), ('BusinessManager'))
         roleCode(RoleCode)
    CROSS JOIN @OperationalPermissions permission;
    INSERT INTO @OperationalRolePermissions VALUES
        ('Admin', 'CustomerPayments.View'),
        ('Admin', 'CustomerPayments.Capture'),
        ('Admin', 'CustomerPayments.Reverse'),
        ('Admin', 'SupplierPayments.View'),
        ('Admin', 'SupplierPayments.Capture'),
        ('Admin', 'SupplierPayments.Reverse'),
        ('Admin', 'RawStock.View'),
        ('Admin', 'RawStock.Manage'),
        ('Admin', 'RawStock.Receive'),
        ('Admin', 'RawStockTakes.View'),
        ('Admin', 'RawStockTakes.Review'),
        ('Admin', 'OperationalReasons.View'),
        ('Admin', 'OperationalReasons.Manage'),
        ('Admin', 'SupplierOrders.View'),
        ('Admin', 'SupplierOrders.Manage'),
        ('Admin', 'Reconciliation.View'),
        ('WarehouseManager', 'RawStock.View'),
        ('WarehouseManager', 'RawStock.Receive'),
        ('WarehouseManager', 'RawStock.WriteOff'),
        ('WarehouseManager', 'RawStockTakes.View'),
        ('WarehouseManager', 'RawStockTakes.Capture'),
        ('WarehouseManager', 'OperationalReasons.View'),
        ('WarehouseManager', 'Reconciliation.View'),
        ('MarketBuyer', 'RawStock.View');
    INSERT INTO @OperationalRolePermissions
        (RoleCode, PermissionCode)
    SELECT 'AdminClerk', PermissionCode
    FROM @OperationalRolePermissions
    WHERE RoleCode = 'Admin';
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM @OperationalRolePermissions seed
    JOIN dbo.Roles role
      ON role.RoleCode = seed.RoleCode
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = seed.PermissionCode
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.RolePermissions existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId = permission.PermissionId);
    INSERT INTO dbo.OperationalReasons
        (ReasonCode, ReasonName, CategoryCode, Description,
         IsActive, CreatedAtUtc)
    SELECT seed.ReasonCode, seed.ReasonName, seed.CategoryCode,
           seed.Description, 1, SYSUTCDATETIME()
    FROM (VALUES
        ('EXPIRED', 'Expired stock', 'WriteOff',
         'Stock passed its approved best-before date.'),
        ('SPOILED', 'Spoiled stock', 'WriteOff',
         'Stock is no longer fit for processing or sale.'),
        ('DAMAGED', 'Damaged stock', 'WriteOff',
         'Stock was damaged during handling or storage.'),
        ('QUALITY_REJECTED', 'Quality rejected', 'WriteOff',
         'Inspection found that the stock failed quality requirements.'),
        ('STOCK_COUNT', 'Stock-count adjustment', 'StockTake',
         'Controlled adjustment arising from an approved physical stock take.'),
        ('RECEIPT_REJECTION', 'Receipt rejection', 'Receipt',
         'Quantity was rejected during receiving inspection.')
    ) seed(ReasonCode, ReasonName, CategoryCode, Description)
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.OperationalReasons existing
        WHERE existing.ReasonCode = seed.ReasonCode);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_Suppliers_NormalizedEmail] ON [Suppliers] ([NormalizedEmail]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_Suppliers_SupplierTypeCode_Status] ON [Suppliers] ([SupplierTypeCode], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_Suppliers_Code] ON [Suppliers] ([SupplierCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrders_ApprovedByUserId] ON [SupplierOrders] ([ApprovedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrders_CreatedByUserId] ON [SupplierOrders] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrders_Status_OrderDate] ON [SupplierOrders] ([Status], [OrderDate]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrders_WarehouseSectionId] ON [SupplierOrders] ([WarehouseSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_SupplierOrders_Number] ON [SupplierOrders] ([OrderNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_Customers_NormalizedEmail] ON [Customers] ([NormalizedEmail]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_RawStockItemId] ON [BuyerProcurementItems] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_CorrelationId] ON [FinancialPayments] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_CounterpartyType_Status_PaymentDateUtc] ON [FinancialPayments] ([CounterpartyType], [Status], [PaymentDateUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_CreatedByUserId] ON [FinancialPayments] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_CustomerId] ON [FinancialPayments] ([CustomerId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_DecidedByUserId] ON [FinancialPayments] ([DecidedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_InvoiceId] ON [FinancialPayments] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_OriginalPaymentId] ON [FinancialPayments] ([OriginalPaymentId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_PostedByUserId] ON [FinancialPayments] ([PostedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_SupplierId] ON [FinancialPayments] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_SupplierOrderId] ON [FinancialPayments] ([SupplierOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_FinancialPayments_Number] ON [FinancialPayments] ([PaymentNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_OperationalReasons_CategoryCode_IsActive_ReasonName] ON [OperationalReasons] ([CategoryCode], [IsActive], [ReasonName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_OperationalReasons_Code] ON [OperationalReasons] ([ReasonCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_ProductReconciliationMappings_RawStockReconciliationGroupId] ON [ProductReconciliationMappings] ([RawStockReconciliationGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_ProductReconciliationMappings_Product] ON [ProductReconciliationMappings] ([ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockBalances_WarehouseSectionId] ON [RawStockBalances] ([WarehouseSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockBalances_Item_Section_Unit] ON [RawStockBalances] ([RawStockItemId], [WarehouseSectionId], [UnitOfMeasure]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockBatches_RawStockBalanceId] ON [RawStockBatches] ([RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockBatches_RawStockItemId_Status_BestBeforeAtUtc] ON [RawStockBatches] ([RawStockItemId], [Status], [BestBeforeAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [IX_RawStockBatches_RawStockReceiptLineId] ON [RawStockBatches] ([RawStockReceiptLineId]) WHERE [RawStockReceiptLineId] IS NOT NULL');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockBatches_SupplierId] ON [RawStockBatches] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockBatches_BatchCode] ON [RawStockBatches] ([BatchCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockBatches_Qr] ON [RawStockBatches] ([QrCodeValue]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockItems_CategoryCode_IsActive] ON [RawStockItems] ([CategoryCode], [IsActive]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockItems_Code] ON [RawStockItems] ([ItemCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockItems_Name] ON [RawStockItems] ([ItemName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_CorrelationId] ON [RawStockMovements] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_CreatedByUserId] ON [RawStockMovements] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_OperationalReasonId] ON [RawStockMovements] ([OperationalReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_RawStockBalanceId] ON [RawStockMovements] ([RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_RawStockBatchId] ON [RawStockMovements] ([RawStockBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_RawStockItemId_OccurredAtUtc] ON [RawStockMovements] ([RawStockItemId], [OccurredAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_SourceType_SourceId] ON [RawStockMovements] ([SourceType], [SourceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceiptLines_RawStockItemId] ON [RawStockReceiptLines] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceiptLines_RawStockReceiptId_RawStockItemId] ON [RawStockReceiptLines] ([RawStockReceiptId], [RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_BuyerProcurementId] ON [RawStockReceipts] ([BuyerProcurementId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_CorrelationId] ON [RawStockReceipts] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_ReceivedByUserId] ON [RawStockReceipts] ([ReceivedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_Status_ReceivedAtUtc] ON [RawStockReceipts] ([Status], [ReceivedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_SupplierId] ON [RawStockReceipts] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_SupplierOrderId] ON [RawStockReceipts] ([SupplierOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReceipts_WarehouseSectionId] ON [RawStockReceipts] ([WarehouseSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockReceipts_Number] ON [RawStockReceipts] ([ReceiptNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockReceipts_Operation] ON [RawStockReceipts] ([OperationKeyHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockReconciliationGroupItems_RawStockReconciliationGroupId] ON [RawStockReconciliationGroupItems] ([RawStockReconciliationGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_ReconciliationGroupItems_RawStock] ON [RawStockReconciliationGroupItems] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockReconciliationGroups_Code] ON [RawStockReconciliationGroups] ([GroupCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeLines_RawStockBalanceId] ON [RawStockTakeLines] ([RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeLines_RawStockItemId] ON [RawStockTakeLines] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeLines_RawStockReconciliationGroupId] ON [RawStockTakeLines] ([RawStockReconciliationGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockTakeLines_Session_Balance] ON [RawStockTakeLines] ([RawStockTakeSessionId], [RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeSessions_CreatedByUserId] ON [RawStockTakeSessions] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeSessions_DecidedByUserId] ON [RawStockTakeSessions] ([DecidedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeSessions_ReviewedByUserId] ON [RawStockTakeSessions] ([ReviewedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockTakeSessions_WarehouseSectionId_Status_CreatedAtUtc] ON [RawStockTakeSessions] ([WarehouseSectionId], [Status], [CreatedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_RawStockTakeSessions_Correlation] ON [RawStockTakeSessions] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffEvidence_RawStockWriteOffId] ON [RawStockWriteOffEvidence] ([RawStockWriteOffId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffEvidence_StoredFileId] ON [RawStockWriteOffEvidence] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffEvidence_UploadedByUserId] ON [RawStockWriteOffEvidence] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_CorrelationId] ON [RawStockWriteOffs] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_DecidedByUserId] ON [RawStockWriteOffs] ([DecidedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_OperationalReasonId] ON [RawStockWriteOffs] ([OperationalReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_RawStockBalanceId] ON [RawStockWriteOffs] ([RawStockBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_RawStockBatchId] ON [RawStockWriteOffs] ([RawStockBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_RawStockItemId] ON [RawStockWriteOffs] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_Status_SubmittedAtUtc] ON [RawStockWriteOffs] ([Status], [SubmittedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_RawStockWriteOffs_SubmittedByUserId] ON [RawStockWriteOffs] ([SubmittedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE INDEX [IX_SupplierOrderLines_RawStockItemId] ON [SupplierOrderLines] ([RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    CREATE UNIQUE INDEX [UX_SupplierOrderLines_Order_Item] ON [SupplierOrderLines] ([SupplierOrderId], [RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD CONSTRAINT [FK_BuyerProcurementItems_RawStockItems_RawStockItemId] FOREIGN KEY ([RawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD CONSTRAINT [FK_SupplierOrders_Users_ApprovedByUserId] FOREIGN KEY ([ApprovedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD CONSTRAINT [FK_SupplierOrders_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    ALTER TABLE [SupplierOrders] ADD CONSTRAINT [FK_SupplierOrders_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260726180251_OperationalSectionsRawStockCustomerSupplierConsolidation', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    EXEC sp_rename N'[BuyerProcurementItems].[Notes]', N'ManagementNotes', N'COLUMN';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [RawStockReceiptLines] ADD [BuyerProcurementItemId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    DECLARE @var11 sysname;
    SELECT @var11 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[BuyerProcurements]') AND [c].[name] = N'AssignedBuyerUserId');
    IF @var11 IS NOT NULL EXEC(N'ALTER TABLE [BuyerProcurements] DROP CONSTRAINT [' + @var11 + '];');
    ALTER TABLE [BuyerProcurements] ALTER COLUMN [AssignedBuyerUserId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD [CancellationReason] nvarchar(500) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD [CancelledAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD [CancelledByUserId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD [CreatedByUserId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD [Priority] nvarchar(20) NOT NULL DEFAULT N'Standard';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD [PublishedAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD [ReferenceNumber] nvarchar(40) NOT NULL DEFAULT N'';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD [Title] nvarchar(160) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD [UpdatedAtUtc] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD [BuyerNotes] nvarchar(1000) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD [PreferredSupplierId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD [Priority] nvarchar(20) NOT NULL DEFAULT N'Standard';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD [ReceivedQuantity] decimal(18,2) NOT NULL DEFAULT 0.0;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD [SubstituteNotes] nvarchar(500) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD [SubstituteRawStockItemId] int NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    UPDATE list
    SET
        list.ReferenceNumber =
            CONCAT(
                'BL-LEGACY-',
                RIGHT(
                    '0000000000' +
                    CONVERT(varchar(10), list.BuyerProcurementId),
                    10
                )
            ),
        list.Priority = 'Standard',
        list.UpdatedAtUtc =
            COALESCE(
                list.SubmittedAtUtc,
                list.CreatedAtUtc,
                SYSUTCDATETIME()
            ),
        list.PublishedAtUtc =
            CASE
                WHEN list.Status <> 'Draft'
                THEN COALESCE(
                    list.SubmittedAtUtc,
                    list.CreatedAtUtc,
                    SYSUTCDATETIME()
                )
                ELSE NULL
            END,
        list.Status =
            CASE
                WHEN list.Status = 'Completed'
                     AND EXISTS
                     (
                         SELECT 1
                         FROM dbo.RawStockReceipts receipt
                         WHERE receipt.BuyerProcurementId =
                               list.BuyerProcurementId
                     )
                THEN 'Completed'
                WHEN list.Status = 'Completed'
                THEN 'Submitted'
                ELSE list.Status
            END
    FROM dbo.BuyerProcurements list
    WHERE list.ReferenceNumber = '';
    UPDATE item
    SET item.Priority = 'Standard'
    FROM dbo.BuyerProcurementItems item
    WHERE item.Priority = '';
    UPDATE line
    SET line.BuyerProcurementItemId = matched.BuyerProcurementItemId
    FROM dbo.RawStockReceiptLines line
    JOIN dbo.RawStockReceipts receipt
      ON receipt.RawStockReceiptId = line.RawStockReceiptId
    CROSS APPLY
    (
        SELECT MIN(item.BuyerProcurementItemId)
               AS BuyerProcurementItemId,
               COUNT_BIG(*) AS MatchCount
        FROM dbo.BuyerProcurementItems item
        WHERE item.BuyerProcurementId =
              receipt.BuyerProcurementId
          AND item.RawStockItemId = line.RawStockItemId
    ) matched
    WHERE receipt.BuyerProcurementId IS NOT NULL
      AND matched.MatchCount = 1;
    UPDATE item
    SET item.ReceivedQuantity = received.AcceptedQuantity
    FROM dbo.BuyerProcurementItems item
    JOIN
    (
        SELECT
            line.BuyerProcurementItemId,
            SUM(line.AcceptedQuantity) AS AcceptedQuantity
        FROM dbo.RawStockReceiptLines line
        WHERE line.BuyerProcurementItemId IS NOT NULL
        GROUP BY line.BuyerProcurementItemId
    ) received
      ON received.BuyerProcurementItemId =
         item.BuyerProcurementItemId;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    DECLARE @BuyingListPermissionSeed TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(150) NOT NULL,
        Module nvarchar(100) NOT NULL
    );
    INSERT INTO @BuyingListPermissionSeed VALUES
        ('BuyingList.View', 'View Buying Lists', 'BuyingList'),
        ('BuyingList.ViewAll', 'View all Buying Lists', 'BuyingList'),
        ('BuyingList.Create', 'Create Buying List drafts', 'BuyingList'),
        ('BuyingList.UpdateDraft', 'Update Buying List drafts', 'BuyingList'),
        ('BuyingList.DeleteDraft', 'Remove Buying List draft lines', 'BuyingList'),
        ('BuyingList.Assign', 'Assign Buying Lists', 'BuyingList'),
        ('BuyingList.Publish', 'Publish Buying Lists', 'BuyingList'),
        ('BuyingList.Cancel', 'Cancel Buying Lists', 'BuyingList'),
        ('Mobile.BuyingList.ViewAll', 'View all mobile Buying Lists', 'Mobile'),
        ('Mobile.BuyingList.Create', 'Create mobile Buying Lists', 'Mobile'),
        ('Mobile.BuyingList.Assign', 'Assign mobile Buying Lists', 'Mobile'),
        ('Mobile.Notification.View', 'View mobile notifications', 'Mobile'),
        ('Mobile.Profile.View', 'View the mobile profile', 'Mobile'),
        ('Mobile.Help.View', 'View mobile help and safety', 'Mobile');
    INSERT INTO dbo.Permissions
        (
            PermissionName,
            PermissionCode,
            DisplayName,
            Module,
            IsSystemPermission,
            IsActive,
            CreatedAtUtc
        )
    SELECT
        seed.PermissionCode,
        seed.PermissionCode,
        seed.DisplayName,
        seed.Module,
        1,
        1,
        SYSUTCDATETIME()
    FROM @BuyingListPermissionSeed seed
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode
    );
    UPDATE permission
    SET
        permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @BuyingListPermissionSeed seed
      ON seed.PermissionCode = permission.PermissionCode;
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT
        role.RoleId,
        permission.PermissionId,
        SYSUTCDATETIME()
    FROM dbo.Roles role
    CROSS JOIN dbo.Permissions permission
    WHERE role.RoleCode IN
        ('CEO', 'COO', 'BusinessManager')
      AND permission.PermissionCode IN
        (
            SELECT PermissionCode
            FROM @BuyingListPermissionSeed
        )
      AND NOT EXISTS
        (
            SELECT 1
            FROM dbo.RolePermissions existing
            WHERE existing.RoleId = role.RoleId
              AND existing.PermissionId =
                  permission.PermissionId
        );
    DECLARE @BuyingListRoleAssignments TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL
    );
    INSERT INTO @BuyingListRoleAssignments VALUES
        ('Admin', 'BuyingList.View'),
        ('Admin', 'BuyingList.ViewAll'),
        ('Admin', 'BuyingList.Create'),
        ('Admin', 'BuyingList.UpdateDraft'),
        ('Admin', 'BuyingList.DeleteDraft'),
        ('Admin', 'BuyingList.Assign'),
        ('Admin', 'BuyingList.Publish'),
        ('Admin', 'BuyingList.Cancel'),
        ('WarehouseManager', 'Mobile.BuyingList.ViewAll'),
        ('WarehouseManager', 'Mobile.Notification.View'),
        ('WarehouseManager', 'Mobile.Profile.View'),
        ('WarehouseManager', 'Mobile.Help.View'),
        ('Packer', 'Mobile.Notification.View'),
        ('Packer', 'Mobile.Profile.View'),
        ('Packer', 'Mobile.Help.View'),
        ('Driver', 'Mobile.Notification.View'),
        ('Driver', 'Mobile.Profile.View'),
        ('Driver', 'Mobile.Help.View'),
        ('MarketBuyer', 'Mobile.Notification.View'),
        ('MarketBuyer', 'Mobile.Profile.View'),
        ('MarketBuyer', 'Mobile.Help.View');
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT
        role.RoleId,
        permission.PermissionId,
        SYSUTCDATETIME()
    FROM @BuyingListRoleAssignments assignment
    JOIN dbo.Roles role
      ON role.RoleCode = assignment.RoleCode
    JOIN dbo.Permissions permission
      ON permission.PermissionCode =
         assignment.PermissionCode
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.RolePermissions existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId =
              permission.PermissionId
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    CREATE INDEX [IX_RawStockReceiptLines_BuyerProcurementItemId] ON [RawStockReceiptLines] ([BuyerProcurementItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurements_CancelledByUserId] ON [BuyerProcurements] ([CancelledByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurements_CreatedByUserId] ON [BuyerProcurements] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    CREATE UNIQUE INDEX [UX_BuyerProcurements_Reference] ON [BuyerProcurements] ([ReferenceNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_BuyerProcurementId_RawStockItemId] ON [BuyerProcurementItems] ([BuyerProcurementId], [RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_PreferredSupplierId] ON [BuyerProcurementItems] ([PreferredSupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_SubstituteRawStockItemId] ON [BuyerProcurementItems] ([SubstituteRawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD CONSTRAINT [FK_BuyerProcurementItems_RawStockItems_SubstituteRawStockItemId] FOREIGN KEY ([SubstituteRawStockItemId]) REFERENCES [RawStockItems] ([RawStockItemId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurementItems] ADD CONSTRAINT [FK_BuyerProcurementItems_Suppliers_PreferredSupplierId] FOREIGN KEY ([PreferredSupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD CONSTRAINT [FK_BuyerProcurements_Users_CancelledByUserId] FOREIGN KEY ([CancelledByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [BuyerProcurements] ADD CONSTRAINT [FK_BuyerProcurements_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    ALTER TABLE [RawStockReceiptLines] ADD CONSTRAINT [FK_RawStockReceiptLines_BuyerProcurementItems_BuyerProcurementItemId] FOREIGN KEY ([BuyerProcurementItemId]) REFERENCES [BuyerProcurementItems] ([BuyerProcurementItemId]) ON DELETE NO ACTION;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260730233558_CompleteBuyingListManagementAndMobilePermissions'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260730233558_CompleteBuyingListManagementAndMobilePermissions', N'8.0.0');
END;
GO

COMMIT;
GO

