﻿BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802164650_FormalReportingSubsystem'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (54, NULL, N''Reports'', N''50'', N''Rows shown when a paged report does not specify a page size.'', N''Default page size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Reports.DefaultPageSize'', N''500'', N''10'', CAST(0 AS bit), N''rows'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''50'', N''Integer''),
    (55, NULL, N''Reports'', N''500'', N''Largest row count accepted for one paged report preview.'', N''Maximum page size'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Reports.MaximumPageSize'', N''2000'', N''50'', CAST(0 AS bit), N''rows'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''500'', N''Integer''),
    (56, NULL, N''Reports'', N''30'', N''Minutes an authenticated preview remains available for matching PDF export.'', N''Preview lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Reports.PreviewLifetimeMinutes'', N''120'', N''5'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''30'', N''TimeSpanMinutes''),
    (57, NULL, N''Reports'', N''365'', N''Maximum date range accepted by transactional and adjustable reports.'', N''Maximum date range'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Reports.MaximumDateRangeDays'', N''1095'', N''31'', CAST(0 AS bit), N''days'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''365'', N''Integer''),
    (58, NULL, N''Reports'', N''false'', N''Allow markup analysis to use a prior receipt cost when no direct or current receipt cost is available.'', N''Allow prior receipt cost fallback'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Reports.Markup.AllowPriorReceiptCostFallback'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''false'', N''Boolean''),
    (59, NULL, N''Reports'', N''5'', N''Minimum historical price observations required before a box plot is reliable.'', N''Minimum box-plot observations'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Reports.Pricing.MinimumBoxPlotObservations'', N''30'', N''5'', CAST(0 AS bit), N''observations'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''5'', N''Integer'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802164650_FormalReportingSubsystem'
)
BEGIN
    DECLARE @ReportPermissions TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(120) NOT NULL
    );
    INSERT INTO @ReportPermissions VALUES
        (N'Reports.View', N'Open Reports and Analytics'),
        (N'Reports.Inventory.View', N'View the Inventory Position Report'),
        (N'Reports.Inventory.ExportPdf', N'Export the Inventory Position Report PDF'),
        (N'Reports.Sales.View', N'View the Sales by Customer and Product Report'),
        (N'Reports.Sales.ExportPdf', N'Export the Sales Report PDF'),
        (N'Reports.Financial.View', N'View the Financial Activity Report'),
        (N'Reports.Financial.ViewCost', N'View financial report cost values'),
        (N'Reports.Financial.ExportPdf', N'Export the Financial Activity Report PDF'),
        (N'Reports.Financial.ViewReversalHistory', N'View reversed and voided financial activity'),
        (N'Reports.StockMovement.View', N'View the Stock Movement Report'),
        (N'Reports.StockMovement.ViewCost', N'View stock movement cost values'),
        (N'Reports.StockMovement.ExportPdf', N'Export the Stock Movement Report PDF'),
        (N'Reports.ExpiryWaste.View', N'View the Expiry and Waste Risk Report'),
        (N'Reports.ExpiryWaste.ViewCost', N'View expiry and waste cost values'),
        (N'Reports.ExpiryWaste.ExportPdf', N'Export the Expiry and Waste Report PDF'),
        (N'Reports.Pricing.View', N'View the Product Pricing Analysis Report'),
        (N'Reports.Pricing.ExportPdf', N'Export the Product Pricing Analysis Report PDF'),
        (N'Reports.Markup.View', N'View the Product Markup and Gross Margin Report'),
        (N'Reports.Markup.ViewCost', N'View markup report cost values'),
        (N'Reports.Markup.ExportPdf', N'Export the Product Markup and Gross Margin Report PDF');
    INSERT INTO dbo.Permissions
    (
        PermissionName,
        PermissionCode,
        DisplayName,
        Module,
        IsSystemPermission,
        IsActive,
        CreatedAtUtc
    )
    SELECT
        seed.PermissionCode,
        seed.PermissionCode,
        seed.DisplayName,
        N'Reports',
        1,
        1,
        SYSUTCDATETIME()
    FROM @ReportPermissions seed
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode
    );
    UPDATE permission
    SET permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = N'Reports',
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @ReportPermissions seed
      ON seed.PermissionCode = permission.PermissionCode;
    DECLARE @ReportRolePermissions TABLE
    (
        RoleCode nvarchar(100) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL
    );
    INSERT INTO @ReportRolePermissions
    SELECT N'OperationsManager', PermissionCode
    FROM @ReportPermissions;
    INSERT INTO @ReportRolePermissions VALUES
        (N'Admin', N'Reports.View'),
        (N'Admin', N'Reports.Inventory.View'),
        (N'Admin', N'Reports.Inventory.ExportPdf'),
        (N'Admin', N'Reports.Pricing.View'),
        (N'Admin', N'Reports.Pricing.ExportPdf'),
        (N'Admin', N'Reports.Markup.View'),
        (N'Admin', N'Reports.Markup.ViewCost'),
        (N'Admin', N'Reports.Markup.ExportPdf'),
        (N'BusinessManager', N'Reports.View'),
        (N'BusinessManager', N'Reports.Inventory.View'),
        (N'BusinessManager', N'Reports.Inventory.ExportPdf'),
        (N'BusinessManager', N'Reports.Sales.View'),
        (N'BusinessManager', N'Reports.Sales.ExportPdf'),
        (N'BusinessManager', N'Reports.Pricing.View'),
        (N'BusinessManager', N'Reports.Pricing.ExportPdf'),
        (N'WarehouseManager', N'Reports.View'),
        (N'WarehouseManager', N'Reports.Inventory.View'),
        (N'WarehouseManager', N'Reports.Inventory.ExportPdf'),
        (N'WarehouseManager', N'Reports.StockMovement.View'),
        (N'WarehouseManager', N'Reports.StockMovement.ViewCost'),
        (N'WarehouseManager', N'Reports.StockMovement.ExportPdf'),
        (N'WarehouseManager', N'Reports.ExpiryWaste.View'),
        (N'WarehouseManager', N'Reports.ExpiryWaste.ViewCost'),
        (N'WarehouseManager', N'Reports.ExpiryWaste.ExportPdf');
    INSERT INTO dbo.RolePermissions
    (
        RoleId,
        PermissionId,
        AssignedAtUtc
    )
    SELECT
        role.RoleId,
        permission.PermissionId,
        SYSUTCDATETIME()
    FROM @ReportRolePermissions seed
    JOIN dbo.Roles role
      ON role.RoleCode = seed.RoleCode
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = seed.PermissionCode
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.RolePermissions existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId = permission.PermissionId
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802164650_FormalReportingSubsystem'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_ReportCompletedStatus] ON [StockWriteOffs] ([CompletedAtUtc], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802164650_FormalReportingSubsystem'
)
BEGIN
    CREATE INDEX [IX_StockMovements_ReportDateTypeProduct] ON [StockMovements] ([OccurredAtUtc], [MovementType], [ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802164650_FormalReportingSubsystem'
)
BEGIN
    CREATE INDEX [IX_SalesOrders_ReportDateCustomerStatus] ON [SalesOrders] ([OrderDateUtc], [CustomerId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802164650_FormalReportingSubsystem'
)
BEGIN
    CREATE INDEX [IX_RawStockMovements_ReportDateTypeItem] ON [RawStockMovements] ([OccurredAtUtc], [MovementType], [RawStockItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802164650_FormalReportingSubsystem'
)
BEGIN
    CREATE INDEX [IX_FinancialPayments_ReportDateCounterpartyStatus] ON [FinancialPayments] ([PaymentDateUtc], [CounterpartyType], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802164650_FormalReportingSubsystem'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260802164650_FormalReportingSubsystem', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802165915_FormalReportingHelpContent'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpCategoryId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[HelpCategories]'))
        SET IDENTITY_INSERT [HelpCategories] ON;
    EXEC(N'INSERT INTO [HelpCategories] ([HelpCategoryId], [CreatedAtUtc], [Description], [DisplayName], [IsActive], [SortOrder], [SystemCode], [UpdatedAtUtc])
    VALUES (9, ''2026-07-24T00:00:00.0000000Z'', N''Formal operational, transactional, financial and pricing reports.'', N''Reports and analytics'', CAST(1 AS bit), 90, N''REPORTING'', NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpCategoryId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[HelpCategories]'))
        SET IDENTITY_INSERT [HelpCategories] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802165915_FormalReportingHelpContent'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpTopicId', N'AudienceRolesCsv', N'BodyContent', N'CreatedAtUtc', N'HelpCategoryId', N'IsPublic', N'IsPublished', N'Keywords', N'Slug', N'SortOrder', N'Summary', N'Title', N'UpdatedAtUtc', N'UpdatedByUserId') AND [object_id] = OBJECT_ID(N'[HelpTopics]'))
        SET IDENTITY_INSERT [HelpTopics] ON;
    EXEC(N'INSERT INTO [HelpTopics] ([HelpTopicId], [AudienceRolesCsv], [BodyContent], [CreatedAtUtc], [HelpCategoryId], [IsPublic], [IsPublished], [Keywords], [Slug], [SortOrder], [Summary], [Title], [UpdatedAtUtc], [UpdatedByUserId])
    VALUES (33, N''OperationsManager,BusinessManager,Admin,WarehouseManager'', CONCAT(CAST(N''# Formal reports'' AS nvarchar(max)), nchar(10), N''Choose a report, set its criteria and select Preview. The preview is the authoritative dataset for the PDF. If any criterion changes, preview the report again before downloading.'', nchar(10), nchar(10), N''Inventory Availability, Expiry and Waste, and Markup Analysis are simple flat reports. Sales and Stock Movement reports use visible control breaks, subtotals and grand totals. Currency is displayed in South African rand and timestamps are shown consistently with the selected criteria.'', nchar(10), nchar(10), N''Access to costs, reversals and exports is controlled independently. An empty report means no records matched the selected criteria; it is not a failure. Every preview and PDF export is audited.''), ''2026-07-24T00:00:00.0000000Z'', 9, CAST(0 AS bit), CAST(1 AS bit), N''report preview criteria pdf export totals empty audit'', N''formal-reports'', 10, N''Preview report criteria, understand report structure and export the exact preview as PDF.'', N''Run and export formal reports'', NULL, NULL),
    (34, N''OperationsManager,BusinessManager,Admin,WarehouseManager'', CONCAT(CAST(N''# Financial report'' AS nvarchar(max)), nchar(10), N''Filter by date, customer, invoice status, payment status, payment method and amount range. The report summarizes invoiced value, confirmed payments, outstanding value, reversals and write-off losses from stored operational records.'', nchar(10), nchar(10), N''This is an operational financial summary, not a profit-and-loss statement. It does not infer general-ledger balances, tax liability, payroll, overheads or accounting profit where those ledgers do not exist. Reversal detail is shown only to users with the dedicated permission.''), ''2026-07-24T00:00:00.0000000Z'', 9, CAST(0 AS bit), CAST(1 AS bit), N''financial criteria invoice payment outstanding reversal write off non profit loss'', N''financial-report'', 20, N''Use adjustable criteria and interpret the operational financial summary correctly.'', N''Interpret the financial report'', NULL, NULL),
    (35, N''OperationsManager,BusinessManager,Admin,WarehouseManager'', CONCAT(CAST(N''# Pricing management report'' AS nvarchar(max)), nchar(10), N''Monthly average selling price is quantity weighted from stored SalesOrderItem price snapshots: the sum of quantity multiplied by unit price, divided by total quantity. The annual value is the arithmetic mean of available monthly averages. Months without observations are shown as N/A and are never treated as zero.'', nchar(10), nchar(10), N''The box plot uses linear-interpolated quartiles and 1.5 times the interquartile range for whiskers and outliers. A box is shown only when at least five observations are available. The support tables contain the exact values used by the line, bar and box-plot charts.''), ''2026-07-24T00:00:00.0000000Z'', 9, CAST(0 AS bit), CAST(1 AS bit), N''pricing weighted monthly annual average box plot quartile iqr observation snapshot'', N''pricing-management-report'', 30, N''Understand weighted monthly averages, annual means and reliable box plots.'', N''Interpret pricing charts and formulas'', NULL, NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpTopicId', N'AudienceRolesCsv', N'BodyContent', N'CreatedAtUtc', N'HelpCategoryId', N'IsPublic', N'IsPublished', N'Keywords', N'Slug', N'SortOrder', N'Summary', N'Title', N'UpdatedAtUtc', N'UpdatedByUserId') AND [object_id] = OBJECT_ID(N'[HelpTopics]'))
        SET IDENTITY_INSERT [HelpTopics] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802165915_FormalReportingHelpContent'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpContextMappingId', N'ComponentKey', N'HelpTopicId', N'IsActive', N'Priority', N'RoutePattern') AND [object_id] = OBJECT_ID(N'[HelpContextMappings]'))
        SET IDENTITY_INSERT [HelpContextMappings] ON;
    EXEC(N'INSERT INTO [HelpContextMappings] ([HelpContextMappingId], [ComponentKey], [HelpTopicId], [IsActive], [Priority], [RoutePattern])
    VALUES (33, N''ReportsLanding'', 33, CAST(1 AS bit), 100, N''/reports''),
    (34, N''FormalReportInventory'', 33, CAST(1 AS bit), 100, N''/reports/inventory-availability''),
    (35, N''FormalReportExpiryWaste'', 33, CAST(1 AS bit), 100, N''/reports/expiry-waste''),
    (36, N''FormalReportMarkup'', 33, CAST(1 AS bit), 100, N''/reports/markup-analysis''),
    (37, N''FormalReportSales'', 33, CAST(1 AS bit), 100, N''/reports/sales-transactions''),
    (38, N''FormalReportStockMovements'', 33, CAST(1 AS bit), 100, N''/reports/stock-movements''),
    (39, N''FormalReportFinancial'', 34, CAST(1 AS bit), 100, N''/reports/financial-summary''),
    (40, N''FormalReportPricing'', 35, CAST(1 AS bit), 100, N''/reports/pricing-management'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'HelpContextMappingId', N'ComponentKey', N'HelpTopicId', N'IsActive', N'Priority', N'RoutePattern') AND [object_id] = OBJECT_ID(N'[HelpContextMappings]'))
        SET IDENTITY_INSERT [HelpContextMappings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260802165915_FormalReportingHelpContent'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260802165915_FormalReportingHelpContent', N'8.0.0');
END;
GO

COMMIT;
GO

