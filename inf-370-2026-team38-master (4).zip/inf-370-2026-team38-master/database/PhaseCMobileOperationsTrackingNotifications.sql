BEGIN TRANSACTION;
GO

SET ANSI_NULLS ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET QUOTED_IDENTIFIER ON;
SET NUMERIC_ROUNDABORT OFF;
SET XACT_ABORT ON;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [BuyerProcurements] (
        [BuyerProcurementId] int NOT NULL IDENTITY,
        [BuyingDateUtc] datetime2 NOT NULL,
        [AssignedBuyerUserId] int NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [DocketStoredFileId] bigint NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [SubmittedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_BuyerProcurements] PRIMARY KEY ([BuyerProcurementId]),
        CONSTRAINT [FK_BuyerProcurements_StoredFiles_DocketStoredFileId] FOREIGN KEY ([DocketStoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_BuyerProcurements_Users_AssignedBuyerUserId] FOREIGN KEY ([AssignedBuyerUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [DeliveryRouteCalculations] (
        [DeliveryRouteCalculationId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [OriginLatitude] decimal(9,6) NOT NULL,
        [OriginLongitude] decimal(9,6) NOT NULL,
        [DestinationLatitude] decimal(9,6) NOT NULL,
        [DestinationLongitude] decimal(9,6) NOT NULL,
        [DistanceMetres] bigint NOT NULL,
        [DurationSeconds] int NOT NULL,
        [TrafficDurationSeconds] int NULL,
        [EncodedPolyline] nvarchar(max) NULL,
        [Provider] nvarchar(40) NOT NULL,
        [RequestFingerprint] nvarchar(64) NOT NULL,
        [CalculatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        CONSTRAINT [PK_DeliveryRouteCalculations] PRIMARY KEY ([DeliveryRouteCalculationId]),
        CONSTRAINT [FK_DeliveryRouteCalculations_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [DriverTrackingSessions] (
        [DriverTrackingSessionId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [DriverId] int NOT NULL,
        [StartedByUserId] int NOT NULL,
        [StartedAtUtc] datetime2 NOT NULL,
        [ConsentConfirmedAtUtc] datetime2 NOT NULL,
        [EndedAtUtc] datetime2 NULL,
        [Status] nvarchar(20) NOT NULL,
        [EndedReason] nvarchar(300) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_DriverTrackingSessions] PRIMARY KEY ([DriverTrackingSessionId]),
        CONSTRAINT [FK_DriverTrackingSessions_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DriverTrackingSessions_Drivers_DriverId] FOREIGN KEY ([DriverId]) REFERENCES [Drivers] ([DriverId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_DriverTrackingSessions_Users_StartedByUserId] FOREIGN KEY ([StartedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [MobileDeliveryEvents] (
        [MobileDeliveryEventId] bigint NOT NULL IDENTITY,
        [DeliveryId] int NOT NULL,
        [RecordedByUserId] int NOT NULL,
        [EventType] nvarchar(40) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [RecordedAtUtc] datetime2 NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_MobileDeliveryEvents] PRIMARY KEY ([MobileDeliveryEventId]),
        CONSTRAINT [FK_MobileDeliveryEvents_Deliveries_DeliveryId] FOREIGN KEY ([DeliveryId]) REFERENCES [Deliveries] ([DeliveryId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_MobileDeliveryEvents_Users_RecordedByUserId] FOREIGN KEY ([RecordedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [MobileDeviceRegistrations] (
        [MobileDeviceRegistrationId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [DeviceIdentifierHash] nvarchar(64) NOT NULL,
        [Platform] nvarchar(30) NOT NULL,
        [DeviceName] nvarchar(120) NULL,
        [AppVersion] nvarchar(40) NULL,
        [PushToken] nvarchar(2048) NULL,
        [RegisteredAtUtc] datetime2 NOT NULL,
        [LastSeenAtUtc] datetime2 NOT NULL,
        [IsActive] bit NOT NULL,
        [RevokedAtUtc] datetime2 NULL,
        [RevokedByUserId] int NULL,
        [RevocationReason] nvarchar(300) NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_MobileDeviceRegistrations] PRIMARY KEY ([MobileDeviceRegistrationId]),
        CONSTRAINT [FK_MobileDeviceRegistrations_Users_RevokedByUserId] FOREIGN KEY ([RevokedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_MobileDeviceRegistrations_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [MobileIdempotencyRecords] (
        [MobileIdempotencyRecordId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [OperationType] nvarchar(80) NOT NULL,
        [OperationKeyHash] nvarchar(64) NOT NULL,
        [RequestHash] nvarchar(64) NOT NULL,
        [ResponseJson] nvarchar(max) NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NOT NULL,
        CONSTRAINT [PK_MobileIdempotencyRecords] PRIMARY KEY ([MobileIdempotencyRecordId]),
        CONSTRAINT [FK_MobileIdempotencyRecords_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [NotificationPreferences] (
        [NotificationPreferenceId] bigint NOT NULL IDENTITY,
        [UserId] int NOT NULL,
        [PushEnabled] bit NOT NULL,
        [EmailFallbackEnabled] bit NOT NULL,
        [CriticalAlertsEnabled] bit NOT NULL,
        [QuietHoursStart] nvarchar(5) NULL,
        [QuietHoursEnd] nvarchar(5) NULL,
        [UpdatedAtUtc] datetime2 NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_NotificationPreferences] PRIMARY KEY ([NotificationPreferenceId]),
        CONSTRAINT [FK_NotificationPreferences_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [OperationalNotifications] (
        [OperationalNotificationId] bigint NOT NULL IDENTITY,
        [NotificationType] nvarchar(80) NOT NULL,
        [Severity] nvarchar(20) NOT NULL,
        [Title] nvarchar(180) NOT NULL,
        [Message] nvarchar(1000) NOT NULL,
        [EntityType] nvarchar(100) NULL,
        [EntityId] nvarchar(100) NULL,
        [ActionRoute] nvarchar(300) NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [CreatedByUserId] int NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [ExpiresAtUtc] datetime2 NULL,
        CONSTRAINT [PK_OperationalNotifications] PRIMARY KEY ([OperationalNotificationId]),
        CONSTRAINT [FK_OperationalNotifications_Users_CreatedByUserId] FOREIGN KEY ([CreatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [PackingScans] (
        [PackingScanId] bigint NOT NULL IDENTITY,
        [SalesOrderId] int NOT NULL,
        [SalesOrderItemId] int NOT NULL,
        [OrderStockReservationId] bigint NOT NULL,
        [ProductBatchId] int NOT NULL,
        [ScannedByUserId] int NOT NULL,
        [QuantityPackedKg] decimal(18,2) NOT NULL,
        [ScannedAtUtc] datetime2 NOT NULL,
        [RemovedAtUtc] datetime2 NULL,
        [RemovedByUserId] int NULL,
        [RemovalReason] nvarchar(500) NULL,
        [OperationKeyHash] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_PackingScans] PRIMARY KEY ([PackingScanId]),
        CONSTRAINT [FK_PackingScans_OrderStockReservations_OrderStockReservationId] FOREIGN KEY ([OrderStockReservationId]) REFERENCES [OrderStockReservations] ([OrderStockReservationId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_ProductBatches_ProductBatchId] FOREIGN KEY ([ProductBatchId]) REFERENCES [ProductBatches] ([ProductBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_SalesOrderItems_SalesOrderItemId] FOREIGN KEY ([SalesOrderItemId]) REFERENCES [SalesOrderItems] ([SalesOrderItemId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_SalesOrders_SalesOrderId] FOREIGN KEY ([SalesOrderId]) REFERENCES [SalesOrders] ([SalesOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_Users_RemovedByUserId] FOREIGN KEY ([RemovedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PackingScans_Users_ScannedByUserId] FOREIGN KEY ([ScannedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [StockReceipts] (
        [StockReceiptId] int NOT NULL IDENTITY,
        [SupplierId] int NOT NULL,
        [SupplierOrderId] int NULL,
        [WarehouseSectionId] int NOT NULL,
        [ReceivedByUserId] int NOT NULL,
        [ReceiptNumber] nvarchar(80) NOT NULL,
        [SupplierDocketNumber] nvarchar(100) NULL,
        [PurchaseDateUtc] datetime2 NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [DocketStoredFileId] bigint NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [SubmittedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_StockReceipts] PRIMARY KEY ([StockReceiptId]),
        CONSTRAINT [FK_StockReceipts_StoredFiles_DocketStoredFileId] FOREIGN KEY ([DocketStoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceipts_SupplierOrders_SupplierOrderId] FOREIGN KEY ([SupplierOrderId]) REFERENCES [SupplierOrders] ([SupplierOrderId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceipts_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceipts_Users_ReceivedByUserId] FOREIGN KEY ([ReceivedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceipts_WarehouseSections_WarehouseSectionId] FOREIGN KEY ([WarehouseSectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [StockWriteOffs] (
        [StockWriteOffId] bigint NOT NULL IDENTITY,
        [ProductBatchId] int NOT NULL,
        [SectionId] int NOT NULL,
        [SubmittedByUserId] int NOT NULL,
        [DecidedByUserId] int NULL,
        [QuantityKg] decimal(18,2) NOT NULL,
        [EstimatedUnitCost] decimal(18,2) NOT NULL,
        [EstimatedTotalLoss] decimal(18,2) NOT NULL,
        [ReasonCode] nvarchar(80) NOT NULL,
        [Condition] nvarchar(120) NULL,
        [Notes] nvarchar(1000) NULL,
        [Status] nvarchar(30) NOT NULL,
        [DecisionReason] nvarchar(1000) NULL,
        [SubmittedAtUtc] datetime2 NOT NULL,
        [DecidedAtUtc] datetime2 NULL,
        [CompletedAtUtc] datetime2 NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_StockWriteOffs] PRIMARY KEY ([StockWriteOffId]),
        CONSTRAINT [FK_StockWriteOffs_ProductBatches_ProductBatchId] FOREIGN KEY ([ProductBatchId]) REFERENCES [ProductBatches] ([ProductBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockWriteOffs_Users_DecidedByUserId] FOREIGN KEY ([DecidedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockWriteOffs_Users_SubmittedByUserId] FOREIGN KEY ([SubmittedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockWriteOffs_WarehouseSections_SectionId] FOREIGN KEY ([SectionId]) REFERENCES [WarehouseSections] ([SectionId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [BuyerProcurementItems] (
        [BuyerProcurementItemId] int NOT NULL IDENTITY,
        [BuyerProcurementId] int NOT NULL,
        [ProductId] int NOT NULL,
        [SupplierId] int NULL,
        [RecommendedQuantity] decimal(18,2) NOT NULL,
        [RequiredQuantity] decimal(18,2) NOT NULL,
        [ActualQuantity] decimal(18,2) NULL,
        [ActualUnitPrice] decimal(18,2) NULL,
        [UnitOfMeasure] nvarchar(20) NOT NULL,
        [Status] nvarchar(30) NOT NULL,
        [IsPromotionalItem] bit NOT NULL,
        [Notes] nvarchar(1000) NULL,
        [UnavailableReason] nvarchar(500) NULL,
        [UpdatedAtUtc] datetime2 NOT NULL,
        CONSTRAINT [PK_BuyerProcurementItems] PRIMARY KEY ([BuyerProcurementItemId]),
        CONSTRAINT [FK_BuyerProcurementItems_BuyerProcurements_BuyerProcurementId] FOREIGN KEY ([BuyerProcurementId]) REFERENCES [BuyerProcurements] ([BuyerProcurementId]) ON DELETE CASCADE,
        CONSTRAINT [FK_BuyerProcurementItems_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_BuyerProcurementItems_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers] ([SupplierId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [DriverLocationUpdates] (
        [DriverLocationUpdateId] bigint NOT NULL IDENTITY,
        [DriverTrackingSessionId] bigint NOT NULL,
        [Latitude] decimal(9,6) NOT NULL,
        [Longitude] decimal(9,6) NOT NULL,
        [AccuracyMetres] decimal(10,2) NOT NULL,
        [SpeedMetresPerSecond] decimal(10,2) NULL,
        [HeadingDegrees] decimal(6,2) NULL,
        [CapturedAtUtc] datetime2 NOT NULL,
        [ReceivedAtUtc] datetime2 NOT NULL,
        [Source] nvarchar(20) NOT NULL,
        [OperationKeyHash] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_DriverLocationUpdates] PRIMARY KEY ([DriverLocationUpdateId]),
        CONSTRAINT [FK_DriverLocationUpdates_DriverTrackingSessions_DriverTrackingSessionId] FOREIGN KEY ([DriverTrackingSessionId]) REFERENCES [DriverTrackingSessions] ([DriverTrackingSessionId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [OperationalNotificationRecipients] (
        [OperationalNotificationRecipientId] bigint NOT NULL IDENTITY,
        [OperationalNotificationId] bigint NOT NULL,
        [UserId] int NOT NULL,
        [ReadAtUtc] datetime2 NULL,
        [DismissedAtUtc] datetime2 NULL,
        [PushSentAtUtc] datetime2 NULL,
        [EmailSentAtUtc] datetime2 NULL,
        [PushStatus] nvarchar(20) NOT NULL,
        [PushAttemptCount] int NOT NULL,
        [NextPushAttemptAtUtc] datetime2 NULL,
        [SafePushErrorCode] nvarchar(80) NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_OperationalNotificationRecipients] PRIMARY KEY ([OperationalNotificationRecipientId]),
        CONSTRAINT [FK_OperationalNotificationRecipients_OperationalNotifications_OperationalNotificationId] FOREIGN KEY ([OperationalNotificationId]) REFERENCES [OperationalNotifications] ([OperationalNotificationId]) ON DELETE CASCADE,
        CONSTRAINT [FK_OperationalNotificationRecipients_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [StockReceiptItems] (
        [StockReceiptItemId] int NOT NULL IDENTITY,
        [StockReceiptId] int NOT NULL,
        [ProductId] int NOT NULL,
        [ProductBatchId] int NULL,
        [QuantityReceivedKg] decimal(18,2) NOT NULL,
        [AcceptedQuantityKg] decimal(18,2) NOT NULL,
        [RejectedQuantityKg] decimal(18,2) NOT NULL,
        [UnitCost] decimal(18,2) NULL,
        [ContainerCount] int NULL,
        [ContainerType] nvarchar(30) NULL,
        [BatchReference] nvarchar(80) NULL,
        [ReceivedAtUtc] datetime2 NOT NULL,
        [BestBeforeAtUtc] datetime2 NOT NULL,
        [QualityStatus] nvarchar(30) NOT NULL,
        [Notes] nvarchar(1000) NULL,
        CONSTRAINT [PK_StockReceiptItems] PRIMARY KEY ([StockReceiptItemId]),
        CONSTRAINT [FK_StockReceiptItems_ProductBatches_ProductBatchId] FOREIGN KEY ([ProductBatchId]) REFERENCES [ProductBatches] ([ProductBatchId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceiptItems_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [Product] ([ProductId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockReceiptItems_StockReceipts_StockReceiptId] FOREIGN KEY ([StockReceiptId]) REFERENCES [StockReceipts] ([StockReceiptId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [StockWriteOffEvidence] (
        [StockWriteOffEvidenceId] bigint NOT NULL IDENTITY,
        [StockWriteOffId] bigint NOT NULL,
        [StoredFileId] bigint NOT NULL,
        [UploadedByUserId] int NOT NULL,
        [UploadedAtUtc] datetime2 NOT NULL,
        [Caption] nvarchar(300) NULL,
        CONSTRAINT [PK_StockWriteOffEvidence] PRIMARY KEY ([StockWriteOffEvidenceId]),
        CONSTRAINT [FK_StockWriteOffEvidence_StockWriteOffs_StockWriteOffId] FOREIGN KEY ([StockWriteOffId]) REFERENCES [StockWriteOffs] ([StockWriteOffId]) ON DELETE CASCADE,
        CONSTRAINT [FK_StockWriteOffEvidence_StoredFiles_StoredFileId] FOREIGN KEY ([StoredFileId]) REFERENCES [StoredFiles] ([StoredFileId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_StockWriteOffEvidence_Users_UploadedByUserId] FOREIGN KEY ([UploadedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE TABLE [NotificationDeliveryAttempts] (
        [NotificationDeliveryAttemptId] bigint NOT NULL IDENTITY,
        [OperationalNotificationRecipientId] bigint NOT NULL,
        [Channel] nvarchar(20) NOT NULL,
        [Provider] nvarchar(40) NOT NULL,
        [Status] nvarchar(20) NOT NULL,
        [AttemptNumber] int NOT NULL,
        [AttemptedAtUtc] datetime2 NOT NULL,
        [CompletedAtUtc] datetime2 NULL,
        [SafeErrorCode] nvarchar(80) NULL,
        CONSTRAINT [PK_NotificationDeliveryAttempts] PRIMARY KEY ([NotificationDeliveryAttemptId]),
        CONSTRAINT [FK_NotificationDeliveryAttempts_OperationalNotificationRecipients_OperationalNotificationRecipientId] FOREIGN KEY ([OperationalNotificationRecipientId]) REFERENCES [OperationalNotificationRecipients] ([OperationalNotificationRecipientId]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (26, NULL, N''Mobile'', N''45'', N''Seconds between foreground driver-location updates.'', N''Location interval'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.LocationIntervalSeconds'', N''300'', N''15'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''45'', N''Integer''),
    (27, NULL, N''Mobile'', N''20'', N''Movement required before another driver-location point is accepted.'', N''Minimum movement'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.LocationMinimumMovementMetres'', N''1000'', N''0'', CAST(0 AS bit), N''metres'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''20'', N''Integer''),
    (28, NULL, N''Mobile'', N''180'', N''Seconds after which an active driver location is shown as stale.'', N''Location stale threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.LocationStaleAfterSeconds'', N''3600'', N''30'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''180'', N''Integer''),
    (29, NULL, N''Mobile'', N''30'', N''Days that detailed delivery-location history is retained.'', N''Location retention'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.LocationRetentionDays'', N''365'', N''1'', CAST(0 AS bit), N''days'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''30'', N''Integer''),
    (30, NULL, N''Mobile'', N''250'', N''Maximum safe draft operations retained by the mobile client.'', N''Offline queue maximum'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.OfflineQueueMaximumItems'', N''2000'', N''10'', CAST(0 AS bit), N''items'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''250'', N''Integer''),
    (31, NULL, N''Mobile'', N''10'', N''Maximum delivery proof photograph size accepted from mobile.'', N''Proof image maximum'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.ProofMaximumMb'', N''25'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (32, NULL, N''Mobile'', N''10'', N''Maximum buying-list or receipt docket image size.'', N''Docket image maximum'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Mobile.DocketMaximumMb'', N''25'', N''1'', CAST(0 AS bit), N''MB'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (33, NULL, N''Maps'', N''10'', N''Minutes a matching route calculation may be reused.'', N''Route cache'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Maps.RouteCacheMinutes'', N''120'', N''1'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''10'', N''Integer''),
    (34, NULL, N''Maps'', N''20'', N''Maximum explicit route refreshes per delivery.'', N''Route refresh limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Maps.MaximumRefreshesPerDelivery'', N''100'', N''1'', CAST(0 AS bit), N''refreshes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''20'', N''Integer''),
    (35, NULL, N''Maps'', N''true'', N''Request traffic-aware travel durations from the configured provider.'', N''Traffic-aware routing'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Maps.TrafficAwareEnabled'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''true'', N''Boolean''),
    (36, NULL, N''Notifications'', N''true'', N''Enable Firebase push processing when protected provider configuration is present.'', N''Push enabled'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Notifications.PushEnabled'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''true'', N''Boolean''),
    (37, NULL, N''Notifications'', N''false'', N''Allow email fallback for supported critical operational notifications.'', N''Email fallback'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Notifications.EmailFallbackEnabled'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''false'', N''Boolean''),
    (38, NULL, N''Notifications'', N''4'', N''Maximum attempts for a transient notification delivery failure.'', N''Maximum retries'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Notifications.MaximumRetryCount'', N''10'', N''0'', CAST(0 AS bit), N''attempts'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''4'', N''Integer''),
    (39, NULL, N''Notifications'', N''60'', N''Base seconds before retrying a transient notification delivery failure.'', N''Retry delay'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Notifications.RetryDelaySeconds'', N''3600'', N''10'', CAST(0 AS bit), N''seconds'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''60'', N''Integer''),
    (40, NULL, N''Write-off'', N''1000'', N''Maximum estimated loss a Warehouse Manager may complete without management approval.'', N''Warehouse Manager value limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.StockTakerMaximumValue'', N''1000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''1000'', N''Decimal''),
    (41, NULL, N''Write-off'', N''100'', N''Maximum quantity a Warehouse Manager may complete without management approval.'', N''Warehouse Manager quantity limit'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.StockTakerMaximumQuantity'', N''100000'', N''0'', CAST(0 AS bit), N''kg'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''100'', N''Decimal''),
    (42, NULL, N''Write-off'', N''500'', N''Estimated loss above which write-off evidence is required.'', N''Photo threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.RequirePhotoAboveValue'', N''1000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''500'', N''Decimal''),
    (43, NULL, N''Write-off'', N''1000'', N''Estimated loss above which management approval is required.'', N''Approval threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.RequireApprovalAboveValue'', N''1000000'', N''0'', CAST(0 AS bit), N''currency'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''1000'', N''Decimal''),
    (44, NULL, N''Write-off'', N''true'', N''Block expired batches from normal stock use until a write-off decision is recorded.'', N''Block expired batches'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''WriteOff.AllowExpiredBatchAutomaticBlock'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''true'', N''Boolean'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_BuyerProcurementId_ProductId] ON [BuyerProcurementItems] ([BuyerProcurementId], [ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_ProductId] ON [BuyerProcurementItems] ([ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurementItems_SupplierId] ON [BuyerProcurementItems] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurements_AssignedBuyerUserId_BuyingDateUtc_Status] ON [BuyerProcurements] ([AssignedBuyerUserId], [BuyingDateUtc], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurements_CorrelationId] ON [BuyerProcurements] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_BuyerProcurements_DocketStoredFileId] ON [BuyerProcurements] ([DocketStoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DeliveryRouteCalculations_DeliveryId_CalculatedAtUtc] ON [DeliveryRouteCalculations] ([DeliveryId], [CalculatedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DeliveryRouteCalculations_DeliveryId_RequestFingerprint] ON [DeliveryRouteCalculations] ([DeliveryId], [RequestFingerprint]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverLocationUpdates_DriverTrackingSessionId_CapturedAtUtc] ON [DriverLocationUpdates] ([DriverTrackingSessionId], [CapturedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_DriverLocationUpdates_Session_Operation] ON [DriverLocationUpdates] ([DriverTrackingSessionId], [OperationKeyHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverTrackingSessions_CorrelationId] ON [DriverTrackingSessions] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverTrackingSessions_DeliveryId_Status] ON [DriverTrackingSessions] ([DeliveryId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverTrackingSessions_DriverId_Status] ON [DriverTrackingSessions] ([DriverId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_DriverTrackingSessions_StartedByUserId] ON [DriverTrackingSessions] ([StartedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [UX_DriverTrackingSessions_ActiveDelivery] ON [DriverTrackingSessions] ([DeliveryId]) WHERE [Status] = ''Active''');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeliveryEvents_CorrelationId] ON [MobileDeliveryEvents] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeliveryEvents_DeliveryId_RecordedAtUtc] ON [MobileDeliveryEvents] ([DeliveryId], [RecordedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeliveryEvents_RecordedByUserId] ON [MobileDeliveryEvents] ([RecordedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeviceRegistrations_IsActive_LastSeenAtUtc] ON [MobileDeviceRegistrations] ([IsActive], [LastSeenAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileDeviceRegistrations_RevokedByUserId] ON [MobileDeviceRegistrations] ([RevokedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_MobileDeviceRegistrations_User_Device] ON [MobileDeviceRegistrations] ([UserId], [DeviceIdentifierHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_MobileIdempotencyRecords_ExpiresAtUtc] ON [MobileIdempotencyRecords] ([ExpiresAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_MobileIdempotency_User_Operation_Key] ON [MobileIdempotencyRecords] ([UserId], [OperationType], [OperationKeyHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_NotificationDeliveryAttempts_OperationalNotificationRecipientId_AttemptNumber] ON [NotificationDeliveryAttempts] ([OperationalNotificationRecipientId], [AttemptNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [IX_NotificationPreferences_UserId] ON [NotificationPreferences] ([UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotificationRecipients_PushStatus_NextPushAttemptAtUtc] ON [OperationalNotificationRecipients] ([PushStatus], [NextPushAttemptAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotificationRecipients_UserId_ReadAtUtc_DismissedAtUtc] ON [OperationalNotificationRecipients] ([UserId], [ReadAtUtc], [DismissedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_NotificationRecipients_Notification_User] ON [OperationalNotificationRecipients] ([OperationalNotificationId], [UserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotifications_CorrelationId] ON [OperationalNotifications] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotifications_CreatedAtUtc_NotificationType] ON [OperationalNotifications] ([CreatedAtUtc], [NotificationType]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_OperationalNotifications_CreatedByUserId] ON [OperationalNotifications] ([CreatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_OrderStockReservationId] ON [PackingScans] ([OrderStockReservationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_ProductBatchId] ON [PackingScans] ([ProductBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_RemovedByUserId] ON [PackingScans] ([RemovedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_SalesOrderId_ScannedAtUtc] ON [PackingScans] ([SalesOrderId], [ScannedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_PackingScans_SalesOrderItemId] ON [PackingScans] ([SalesOrderItemId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [UX_PackingScans_User_Operation] ON [PackingScans] ([ScannedByUserId], [OperationKeyHash]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceiptItems_ProductBatchId] ON [StockReceiptItems] ([ProductBatchId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceiptItems_ProductId] ON [StockReceiptItems] ([ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceiptItems_StockReceiptId_ProductId] ON [StockReceiptItems] ([StockReceiptId], [ProductId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_CorrelationId] ON [StockReceipts] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_DocketStoredFileId] ON [StockReceipts] ([DocketStoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE UNIQUE INDEX [IX_StockReceipts_ReceiptNumber] ON [StockReceipts] ([ReceiptNumber]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_ReceivedByUserId] ON [StockReceipts] ([ReceivedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_Status_PurchaseDateUtc] ON [StockReceipts] ([Status], [PurchaseDateUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_SupplierId] ON [StockReceipts] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_SupplierOrderId] ON [StockReceipts] ([SupplierOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockReceipts_WarehouseSectionId] ON [StockReceipts] ([WarehouseSectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffEvidence_StockWriteOffId_UploadedAtUtc] ON [StockWriteOffEvidence] ([StockWriteOffId], [UploadedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffEvidence_StoredFileId] ON [StockWriteOffEvidence] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffEvidence_UploadedByUserId] ON [StockWriteOffEvidence] ([UploadedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_CorrelationId] ON [StockWriteOffs] ([CorrelationId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_DecidedByUserId] ON [StockWriteOffs] ([DecidedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_ProductBatchId_Status] ON [StockWriteOffs] ([ProductBatchId], [Status]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_SectionId] ON [StockWriteOffs] ([SectionId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_Status_SubmittedAtUtc] ON [StockWriteOffs] ([Status], [SubmittedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    CREATE INDEX [IX_StockWriteOffs_SubmittedByUserId] ON [StockWriteOffs] ([SubmittedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM dbo.Roles WHERE RoleCode = 'MarketBuyer')
    BEGIN
        INSERT INTO dbo.Roles
            (RoleCode, RoleName, Description, IsSystemRole, IsActive, CreatedAtUtc)
        VALUES
            ('MarketBuyer', 'Market Buyer',
             'Mobile purchasing user for approved buying lists.',
             1, 1, SYSUTCDATETIME());
    END;
    DECLARE @PhaseCPermissions TABLE
    (
        PermissionCode nvarchar(100) NOT NULL PRIMARY KEY,
        DisplayName nvarchar(120) NOT NULL,
        Module nvarchar(80) NOT NULL
    );
    INSERT INTO @PhaseCPermissions VALUES
        ('Mobile.Access', 'Access PhenyoSync Mobile', 'Mobile'),
        ('Mobile.Delivery.ViewOwn', 'View own mobile deliveries', 'Mobile'),
        ('Mobile.Delivery.ViewAll', 'View all mobile deliveries', 'Mobile'),
        ('Mobile.Delivery.UpdateOwn', 'Update own mobile delivery', 'Mobile'),
        ('Mobile.Delivery.CompleteOwn', 'Complete own mobile delivery', 'Mobile'),
        ('Mobile.Delivery.UploadProof', 'Upload mobile delivery proof', 'Mobile'),
        ('Mobile.BuyingList.View', 'View mobile buying lists', 'Mobile'),
        ('Mobile.BuyingList.Update', 'Update mobile buying lists', 'Mobile'),
        ('Mobile.BuyingList.Submit', 'Submit mobile buying lists', 'Mobile'),
        ('Mobile.BuyingList.AddPromotionalItem', 'Add promotional buying items', 'Mobile'),
        ('Mobile.BuyingList.UploadDocket', 'Upload buying-list dockets', 'Mobile'),
        ('Mobile.StockReceipt.View', 'View mobile stock receipts', 'Mobile'),
        ('Mobile.StockReceipt.Create', 'Create mobile stock receipts', 'Mobile'),
        ('Mobile.StockReceipt.Submit', 'Submit mobile stock receipts', 'Mobile'),
        ('Mobile.StockReceipt.UploadDocket', 'Upload stock-receipt dockets', 'Mobile'),
        ('Mobile.Packing.View', 'View mobile packing work', 'Mobile'),
        ('Mobile.Packing.Scan', 'Scan packed Product Batches', 'Mobile'),
        ('Mobile.Packing.RemoveScan', 'Correct packing scans', 'Mobile'),
        ('Mobile.Packing.Complete', 'Complete mobile packing', 'Mobile'),
        ('Mobile.Dispatch.View', 'View dispatch queue', 'Mobile'),
        ('Mobile.Dispatch.Confirm', 'Confirm order dispatch', 'Mobile'),
        ('Mobile.Dispatch.Reject', 'Reject or return packed orders', 'Mobile'),
        ('Mobile.Tracking.ShareOwn', 'Share own delivery location', 'Mobile'),
        ('Mobile.Tracking.ViewOwn', 'View own delivery tracking', 'Mobile'),
        ('Mobile.Tracking.ViewAll', 'View all delivery tracking', 'Mobile'),
        ('Mobile.Tracking.Manage', 'Manage delivery tracking', 'Mobile'),
        ('Mobile.WriteOff.View', 'View mobile stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Create', 'Create mobile stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Complete', 'Complete ordinary stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Approve', 'Approve stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Reject', 'Reject stock write-offs', 'Mobile'),
        ('Mobile.WriteOff.Override', 'Override stock write-off rules', 'Mobile'),
        ('Mobile.WriteOff.UploadEvidence', 'Upload stock write-off evidence', 'Mobile'),
        ('Mobile.WriteOff.ViewFinancialImpact', 'View write-off financial impact', 'Mobile'),
        ('Mobile.DeviceManagement.View', 'View registered mobile devices', 'Mobile'),
        ('Mobile.DeviceManagement.Manage', 'Manage registered mobile devices', 'Mobile'),
        ('Notifications.View', 'View operational notifications', 'Notifications'),
        ('Notifications.ManagePreferences', 'Manage notification preferences', 'Notifications'),
        ('Notifications.ManageRules', 'Manage notification rules', 'Notifications'),
        ('Notifications.ViewDeliveryHistory', 'View notification delivery history', 'Notifications'),
        ('Notifications.SendTest', 'Send test notifications', 'Notifications');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT seed.PermissionCode, seed.PermissionCode,
           seed.DisplayName, seed.Module, 1, 1, SYSUTCDATETIME()
    FROM @PhaseCPermissions seed
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode);
    UPDATE permission
    SET permission.PermissionName = seed.PermissionCode,
        permission.DisplayName = seed.DisplayName,
        permission.Module = seed.Module,
        permission.IsSystemPermission = 1,
        permission.IsActive = 1,
        permission.UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions permission
    JOIN @PhaseCPermissions seed
      ON seed.PermissionCode = permission.PermissionCode;
    DECLARE @PhaseCRolePermissions TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL,
        PRIMARY KEY (RoleCode, PermissionCode)
    );
    INSERT INTO @PhaseCRolePermissions
    SELECT roleCode.RoleCode, permission.PermissionCode
    FROM (VALUES ('CEO'), ('COO'), ('BusinessManager'))
         roleCode(RoleCode)
    CROSS JOIN @PhaseCPermissions permission;
    INSERT INTO @PhaseCRolePermissions VALUES
        ('Driver', 'Mobile.Access'),
        ('Driver', 'Mobile.Delivery.ViewOwn'),
        ('Driver', 'Mobile.Delivery.UpdateOwn'),
        ('Driver', 'Mobile.Delivery.CompleteOwn'),
        ('Driver', 'Mobile.Delivery.UploadProof'),
        ('Driver', 'Mobile.Tracking.ShareOwn'),
        ('Driver', 'Mobile.Tracking.ViewOwn'),
        ('Driver', 'Notifications.View'),
        ('Driver', 'Notifications.ManagePreferences'),
        ('Packer', 'Mobile.Access'),
        ('Packer', 'Mobile.Packing.View'),
        ('Packer', 'Mobile.Packing.Scan'),
        ('Packer', 'Mobile.Packing.RemoveScan'),
        ('Packer', 'Mobile.Packing.Complete'),
        ('Packer', 'Notifications.View'),
        ('Packer', 'Notifications.ManagePreferences'),
        ('WarehouseManager', 'Mobile.Access'),
        ('WarehouseManager', 'Suppliers.View'),
        ('WarehouseManager', 'Mobile.BuyingList.View'),
        ('WarehouseManager', 'Mobile.StockReceipt.View'),
        ('WarehouseManager', 'Mobile.StockReceipt.Create'),
        ('WarehouseManager', 'Mobile.StockReceipt.Submit'),
        ('WarehouseManager', 'Mobile.StockReceipt.UploadDocket'),
        ('WarehouseManager', 'Mobile.WriteOff.View'),
        ('WarehouseManager', 'Mobile.WriteOff.Create'),
        ('WarehouseManager', 'Mobile.WriteOff.Complete'),
        ('WarehouseManager', 'Mobile.WriteOff.UploadEvidence'),
        ('WarehouseManager', 'Mobile.WriteOff.ViewFinancialImpact'),
        ('WarehouseManager', 'Notifications.View'),
        ('WarehouseManager', 'Notifications.ManagePreferences'),
        ('MarketBuyer', 'Mobile.Access'),
        ('MarketBuyer', 'Mobile.BuyingList.View'),
        ('MarketBuyer', 'Mobile.BuyingList.Update'),
        ('MarketBuyer', 'Mobile.BuyingList.Submit'),
        ('MarketBuyer', 'Mobile.BuyingList.AddPromotionalItem'),
        ('MarketBuyer', 'Mobile.BuyingList.UploadDocket'),
        ('MarketBuyer', 'Notifications.View'),
        ('MarketBuyer', 'Notifications.ManagePreferences');
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM @PhaseCRolePermissions seed
    JOIN dbo.Roles role
      ON role.RoleCode = seed.RoleCode
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = seed.PermissionCode
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.RolePermissions existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId = permission.PermissionId);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260725200523_PhaseCMobileOperationsTrackingNotifications'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260725200523_PhaseCMobileOperationsTrackingNotifications', N'8.0.0');
END;
GO

COMMIT;
GO

