﻿BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811194030_FinalWorkflowStabilisation'
)
BEGIN
    UPDATE dbo.SalesOrders
    SET Status = N'Submitted'
    WHERE Status = N'PendingValidation';
    UPDATE dbo.OrderStatusHistory
    SET PreviousStatus = N'Submitted'
    WHERE PreviousStatus = N'PendingValidation';
    UPDATE dbo.OrderStatusHistory
    SET NewStatus = N'Submitted'
    WHERE NewStatus = N'PendingValidation';
    DECLARE @PricingPermissions TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(120) NOT NULL
    );
    INSERT INTO @PricingPermissions (PermissionCode, DisplayName)
    VALUES
        (N'Pricing.Create', N'Create price versions'),
        (N'Pricing.Cancel', N'Cancel eligible price versions'),
        (N'Pricing.ViewHistory', N'View price history');
    INSERT INTO dbo.Permissions
    (
        PermissionName,
        PermissionCode,
        DisplayName,
        Module,
        IsSystemPermission,
        IsActive,
        CreatedAtUtc
    )
    SELECT
        seed.PermissionCode,
        seed.PermissionCode,
        seed.DisplayName,
        N'Pricing',
        1,
        1,
        SYSUTCDATETIME()
    FROM @PricingPermissions AS seed
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.Permissions AS existing
        WHERE existing.PermissionCode = seed.PermissionCode
    );
    UPDATE permission
    SET PermissionName = seed.PermissionCode,
        DisplayName = seed.DisplayName,
        Module = N'Pricing',
        IsSystemPermission = 1,
        IsActive = 1,
        UpdatedAtUtc = SYSUTCDATETIME()
    FROM dbo.Permissions AS permission
    INNER JOIN @PricingPermissions AS seed
        ON seed.PermissionCode = permission.PermissionCode;
    UPDATE dbo.Permissions
    SET DisplayName = N'Share customer order form',
        UpdatedAtUtc = SYSUTCDATETIME()
    WHERE PermissionCode = N'Orders.SendLink';
    DECLARE @RolePermissionAssignments TABLE
    (
        RoleCode nvarchar(50) NOT NULL,
        PermissionCode nvarchar(100) NOT NULL
    );
    INSERT INTO @RolePermissionAssignments (RoleCode, PermissionCode)
    VALUES
        (N'OperationsManager', N'Pricing.ViewHistory'),
        (N'Admin', N'Suppliers.View'),
        (N'Admin', N'Suppliers.Manage'),
        (N'Admin', N'Pricing.Create'),
        (N'Admin', N'Pricing.Cancel'),
        (N'Admin', N'Pricing.ViewHistory'),
        (N'BusinessManager', N'Customers.Manage'),
        (N'BusinessManager', N'Pricing.Create'),
        (N'BusinessManager', N'Pricing.Cancel'),
        (N'BusinessManager', N'Pricing.ViewHistory'),
        (N'BusinessManager', N'CustomerPayments.View'),
        (N'BusinessManager', N'CustomerPayments.Capture'),
        (N'BusinessManager', N'CustomerPayments.Reverse'),
        (N'BusinessManager', N'SupplierPayments.View'),
        (N'BusinessManager', N'SupplierPayments.Capture'),
        (N'BusinessManager', N'SupplierPayments.Reverse'),
        (N'BusinessManager', N'ManagementDashboard.View'),
        (N'Packer', N'Packing.Confirm');
    INSERT INTO dbo.RolePermissions
    (
        RoleId,
        PermissionId,
        AssignedAtUtc,
        AssignedByUserId
    )
    SELECT
        role.RoleId,
        permission.PermissionId,
        SYSUTCDATETIME(),
        NULL
    FROM @RolePermissionAssignments AS assignment
    INNER JOIN dbo.Roles AS role
        ON role.RoleCode = assignment.RoleCode
    INNER JOIN dbo.Permissions AS permission
        ON permission.PermissionCode = assignment.PermissionCode
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.RolePermissions AS existing
        WHERE existing.RoleId = role.RoleId
          AND existing.PermissionId = permission.PermissionId
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811194030_FinalWorkflowStabilisation'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Customer order form'' AS nvarchar(max)), nchar(10), N''Open the configured Google Form from Order Management and share it with the customer. The response is an intake aid only. An authorised staff member must review it and capture the official multi-line order in PhenyoSync, where server-side prices and stock rules are applied.'', nchar(10), nchar(10), N''Customer Form responses never create or price an order automatically.''), [Keywords] = N''customer google form intake capture official order'', [Summary] = N''Open or share the configured Google Form, then capture the official order.'', [Title] = N''Share the customer order form''
    WHERE [HelpTopicId] = 18;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811194030_FinalWorkflowStabilisation'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Order status and cancellation'' AS nvarchar(max)), nchar(10), N''Orders move through the controlled sequence from Submitted to validated, confirmed, packed, out for delivery and delivered.'', nchar(10), nchar(10), N''Cancellation requires confirmation and a reason. Reserved stock is released atomically. Completed or delivered records remain read-only except through explicitly authorized correction workflows.'')
    WHERE [HelpTopicId] = 20;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811194030_FinalWorkflowStabilisation'
)
BEGIN
    EXEC(N'UPDATE [HelpTopics] SET [BodyContent] = CONCAT(CAST(N''# Expired links'' AS nvarchar(max)), nchar(10), N''Security links are time-limited and often one-time. Request a new password-reset or expiry-review link from the appropriate workflow. Customer ordering uses the configured Google Form and staff capture process.'', nchar(10), nchar(10), N''Do not edit tokens in the address bar or share links. A used link cannot be reactivated.'')
    WHERE [HelpTopicId] = 29;
    SELECT @@ROWCOUNT');
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811194030_FinalWorkflowStabilisation'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (60, NULL, N''Orders'', N'''', N''Google Form used to collect external customer requests before staff capture an official order.'', N''Customer request Google Form URL'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Orders.CustomerGoogleFormUrl'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N'''', N''String'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811194030_FinalWorkflowStabilisation'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260811194030_FinalWorkflowStabilisation', N'8.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811200929_PreserveUnknownStockCosts'
)
BEGIN
    DECLARE @var0 sysname;
    SELECT @var0 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[StockWriteOffs]') AND [c].[name] = N'EstimatedUnitCost');
    IF @var0 IS NOT NULL EXEC(N'ALTER TABLE [StockWriteOffs] DROP CONSTRAINT [' + @var0 + '];');
    ALTER TABLE [StockWriteOffs] ALTER COLUMN [EstimatedUnitCost] decimal(18,2) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811200929_PreserveUnknownStockCosts'
)
BEGIN
    DECLARE @var1 sysname;
    SELECT @var1 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[StockWriteOffs]') AND [c].[name] = N'EstimatedTotalLoss');
    IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [StockWriteOffs] DROP CONSTRAINT [' + @var1 + '];');
    ALTER TABLE [StockWriteOffs] ALTER COLUMN [EstimatedTotalLoss] decimal(18,2) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811200929_PreserveUnknownStockCosts'
)
BEGIN
    DECLARE @var2 sysname;
    SELECT @var2 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[RawStockWriteOffs]') AND [c].[name] = N'EstimatedUnitCost');
    IF @var2 IS NOT NULL EXEC(N'ALTER TABLE [RawStockWriteOffs] DROP CONSTRAINT [' + @var2 + '];');
    ALTER TABLE [RawStockWriteOffs] ALTER COLUMN [EstimatedUnitCost] decimal(18,4) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811200929_PreserveUnknownStockCosts'
)
BEGIN
    DECLARE @var3 sysname;
    SELECT @var3 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[RawStockWriteOffs]') AND [c].[name] = N'EstimatedTotalLoss');
    IF @var3 IS NOT NULL EXEC(N'ALTER TABLE [RawStockWriteOffs] DROP CONSTRAINT [' + @var3 + '];');
    ALTER TABLE [RawStockWriteOffs] ALTER COLUMN [EstimatedTotalLoss] decimal(18,2) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811200929_PreserveUnknownStockCosts'
)
BEGIN
    DECLARE @var4 sysname;
    SELECT @var4 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[RawStockTakeLines]') AND [c].[name] = N'EstimatedFinancialImpact');
    IF @var4 IS NOT NULL EXEC(N'ALTER TABLE [RawStockTakeLines] DROP CONSTRAINT [' + @var4 + '];');
    ALTER TABLE [RawStockTakeLines] ALTER COLUMN [EstimatedFinancialImpact] decimal(18,3) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811200929_PreserveUnknownStockCosts'
)
BEGIN
    DECLARE @var5 sysname;
    SELECT @var5 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[RawStockMovements]') AND [c].[name] = N'UnitCost');
    IF @var5 IS NOT NULL EXEC(N'ALTER TABLE [RawStockMovements] DROP CONSTRAINT [' + @var5 + '];');
    ALTER TABLE [RawStockMovements] ALTER COLUMN [UnitCost] decimal(18,4) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811200929_PreserveUnknownStockCosts'
)
BEGIN
    DECLARE @var6 sysname;
    SELECT @var6 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[RawStockBatches]') AND [c].[name] = N'UnitCost');
    IF @var6 IS NOT NULL EXEC(N'ALTER TABLE [RawStockBatches] DROP CONSTRAINT [' + @var6 + '];');
    ALTER TABLE [RawStockBatches] ALTER COLUMN [UnitCost] decimal(18,4) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811200929_PreserveUnknownStockCosts'
)
BEGIN
    DECLARE @var7 sysname;
    SELECT @var7 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[RawStockBalances]') AND [c].[name] = N'WeightedAverageUnitCost');
    IF @var7 IS NOT NULL EXEC(N'ALTER TABLE [RawStockBalances] DROP CONSTRAINT [' + @var7 + '];');
    ALTER TABLE [RawStockBalances] ALTER COLUMN [WeightedAverageUnitCost] decimal(18,4) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260811200929_PreserveUnknownStockCosts'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260811200929_PreserveUnknownStockCosts', N'8.0.0');
END;
GO

COMMIT;
GO

