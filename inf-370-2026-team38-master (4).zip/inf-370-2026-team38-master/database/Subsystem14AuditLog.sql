/*
  INF370 Team 38 - Subsystem 14 Audit Log
  Idempotent SQL Server deployment script.

  This script preserves existing audit rows, creates missing columns/indexes,
  and enforces append-only UPDATE/DELETE protection. It does not fabricate
  historical records.
*/
SET XACT_ABORT ON;
BEGIN TRANSACTION;

IF OBJECT_ID(N'dbo.AuditLogs', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuditLogs
    (
        AuditLogId bigint IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_AuditLogs PRIMARY KEY,
        OccurredAtUtc datetime2(7) NOT NULL,
        UserId int NULL,
        UserEmailSnapshot nvarchar(320) NULL,
        UserDisplayNameSnapshot nvarchar(200) NULL,
        UserRoleSnapshot nvarchar(100) NULL,
        ActorType nvarchar(32) NOT NULL,
        ActionType nvarchar(64) NOT NULL,
        SystemModule nvarchar(80) NOT NULL,
        OperationName nvarchar(160) NOT NULL,
        EntityType nvarchar(128) NULL,
        EntityId nvarchar(256) NULL,
        EntityDisplay nvarchar(500) NULL,
        Description nvarchar(1000) NOT NULL,
        BeforeValuesJson nvarchar(max) NULL,
        AfterValuesJson nvarchar(max) NULL,
        ChangedFieldsJson nvarchar(max) NULL,
        Success bit NOT NULL,
        FailureReason nvarchar(1000) NULL,
        CorrelationId nvarchar(64) NOT NULL,
        RequestPath nvarchar(512) NULL,
        HttpMethod nvarchar(10) NULL,
        IpAddress nvarchar(64) NULL,
        UserAgent nvarchar(512) NULL,
        EventSource nvarchar(64) NOT NULL,
        CONSTRAINT CK_AuditLogs_BeforeValuesJson
            CHECK (BeforeValuesJson IS NULL OR ISJSON(BeforeValuesJson) = 1),
        CONSTRAINT CK_AuditLogs_AfterValuesJson
            CHECK (AfterValuesJson IS NULL OR ISJSON(AfterValuesJson) = 1),
        CONSTRAINT CK_AuditLogs_ChangedFieldsJson
            CHECK (ChangedFieldsJson IS NULL OR ISJSON(ChangedFieldsJson) = 1)
    );
END;

IF COL_LENGTH(N'dbo.AuditLogs', N'OccurredAtUtc') IS NULL
    ALTER TABLE dbo.AuditLogs ADD OccurredAtUtc datetime2(7) NOT NULL
        CONSTRAINT DF_AuditLogs_OccurredAtUtc DEFAULT SYSUTCDATETIME() WITH VALUES;
IF COL_LENGTH(N'dbo.AuditLogs', N'UserId') IS NULL
    ALTER TABLE dbo.AuditLogs ADD UserId int NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'UserEmailSnapshot') IS NULL
    ALTER TABLE dbo.AuditLogs ADD UserEmailSnapshot nvarchar(320) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'UserDisplayNameSnapshot') IS NULL
    ALTER TABLE dbo.AuditLogs ADD UserDisplayNameSnapshot nvarchar(200) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'UserRoleSnapshot') IS NULL
    ALTER TABLE dbo.AuditLogs ADD UserRoleSnapshot nvarchar(100) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'ActorType') IS NULL
    ALTER TABLE dbo.AuditLogs ADD ActorType nvarchar(32) NOT NULL
        CONSTRAINT DF_AuditLogs_ActorType DEFAULT N'System' WITH VALUES;
IF COL_LENGTH(N'dbo.AuditLogs', N'ActionType') IS NULL
    ALTER TABLE dbo.AuditLogs ADD ActionType nvarchar(64) NOT NULL
        CONSTRAINT DF_AuditLogs_ActionType DEFAULT N'Update' WITH VALUES;
IF COL_LENGTH(N'dbo.AuditLogs', N'SystemModule') IS NULL
    ALTER TABLE dbo.AuditLogs ADD SystemModule nvarchar(80) NOT NULL
        CONSTRAINT DF_AuditLogs_SystemModule DEFAULT N'Audit' WITH VALUES;
IF COL_LENGTH(N'dbo.AuditLogs', N'OperationName') IS NULL
    ALTER TABLE dbo.AuditLogs ADD OperationName nvarchar(160) NOT NULL
        CONSTRAINT DF_AuditLogs_OperationName DEFAULT N'MigratedAuditRecord' WITH VALUES;
IF COL_LENGTH(N'dbo.AuditLogs', N'EntityType') IS NULL
    ALTER TABLE dbo.AuditLogs ADD EntityType nvarchar(128) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'EntityId') IS NULL
    ALTER TABLE dbo.AuditLogs ADD EntityId nvarchar(256) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'EntityDisplay') IS NULL
    ALTER TABLE dbo.AuditLogs ADD EntityDisplay nvarchar(500) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'Description') IS NULL
    ALTER TABLE dbo.AuditLogs ADD Description nvarchar(1000) NOT NULL
        CONSTRAINT DF_AuditLogs_Description DEFAULT N'Migrated audit record' WITH VALUES;
IF COL_LENGTH(N'dbo.AuditLogs', N'BeforeValuesJson') IS NULL
    ALTER TABLE dbo.AuditLogs ADD BeforeValuesJson nvarchar(max) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'AfterValuesJson') IS NULL
    ALTER TABLE dbo.AuditLogs ADD AfterValuesJson nvarchar(max) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'ChangedFieldsJson') IS NULL
    ALTER TABLE dbo.AuditLogs ADD ChangedFieldsJson nvarchar(max) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'Success') IS NULL
    ALTER TABLE dbo.AuditLogs ADD Success bit NOT NULL
        CONSTRAINT DF_AuditLogs_Success DEFAULT 1 WITH VALUES;
IF COL_LENGTH(N'dbo.AuditLogs', N'FailureReason') IS NULL
    ALTER TABLE dbo.AuditLogs ADD FailureReason nvarchar(1000) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'CorrelationId') IS NULL
    ALTER TABLE dbo.AuditLogs ADD CorrelationId nvarchar(64) NOT NULL
        CONSTRAINT DF_AuditLogs_CorrelationId DEFAULT CONVERT(nvarchar(64), NEWID()) WITH VALUES;
IF COL_LENGTH(N'dbo.AuditLogs', N'RequestPath') IS NULL
    ALTER TABLE dbo.AuditLogs ADD RequestPath nvarchar(512) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'HttpMethod') IS NULL
    ALTER TABLE dbo.AuditLogs ADD HttpMethod nvarchar(10) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'IpAddress') IS NULL
    ALTER TABLE dbo.AuditLogs ADD IpAddress nvarchar(64) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'UserAgent') IS NULL
    ALTER TABLE dbo.AuditLogs ADD UserAgent nvarchar(512) NULL;
IF COL_LENGTH(N'dbo.AuditLogs', N'EventSource') IS NULL
    ALTER TABLE dbo.AuditLogs ADD EventSource nvarchar(64) NOT NULL
        CONSTRAINT DF_AuditLogs_EventSource DEFAULT N'EntityChange' WITH VALUES;

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_AuditLogs_BeforeValuesJson')
    ALTER TABLE dbo.AuditLogs ADD CONSTRAINT CK_AuditLogs_BeforeValuesJson
        CHECK (BeforeValuesJson IS NULL OR ISJSON(BeforeValuesJson) = 1);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_AuditLogs_AfterValuesJson')
    ALTER TABLE dbo.AuditLogs ADD CONSTRAINT CK_AuditLogs_AfterValuesJson
        CHECK (AfterValuesJson IS NULL OR ISJSON(AfterValuesJson) = 1);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_AuditLogs_ChangedFieldsJson')
    ALTER TABLE dbo.AuditLogs ADD CONSTRAINT CK_AuditLogs_ChangedFieldsJson
        CHECK (ChangedFieldsJson IS NULL OR ISJSON(ChangedFieldsJson) = 1);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.AuditLogs') AND name = N'IX_AuditLogs_OccurredAtUtc')
    CREATE INDEX IX_AuditLogs_OccurredAtUtc ON dbo.AuditLogs (OccurredAtUtc DESC);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.AuditLogs') AND name = N'IX_AuditLogs_User_OccurredAtUtc')
    CREATE INDEX IX_AuditLogs_User_OccurredAtUtc ON dbo.AuditLogs (UserId, OccurredAtUtc DESC);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.AuditLogs') AND name = N'IX_AuditLogs_Action_OccurredAtUtc')
    CREATE INDEX IX_AuditLogs_Action_OccurredAtUtc ON dbo.AuditLogs (ActionType, OccurredAtUtc DESC);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.AuditLogs') AND name = N'IX_AuditLogs_Module_OccurredAtUtc')
    CREATE INDEX IX_AuditLogs_Module_OccurredAtUtc ON dbo.AuditLogs (SystemModule, OccurredAtUtc DESC);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.AuditLogs') AND name = N'IX_AuditLogs_Entity')
    CREATE INDEX IX_AuditLogs_Entity ON dbo.AuditLogs (EntityType, EntityId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.AuditLogs') AND name = N'IX_AuditLogs_CorrelationId')
    CREATE INDEX IX_AuditLogs_CorrelationId ON dbo.AuditLogs (CorrelationId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.AuditLogs') AND name = N'IX_AuditLogs_Success_OccurredAtUtc')
    CREATE INDEX IX_AuditLogs_Success_OccurredAtUtc ON dbo.AuditLogs (Success, OccurredAtUtc DESC);

COMMIT TRANSACTION;

EXEC(N'
CREATE OR ALTER TRIGGER dbo.TR_AuditLogs_Immutable
ON dbo.AuditLogs
INSTEAD OF UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    THROW 51000, ''Audit logs are immutable and cannot be updated or deleted.'', 1;
END;
');

/*
  Exceptional retention or legal maintenance must be performed by an
  authorized DBA in a controlled change window after temporarily disabling
  this trigger. The application exposes no bypass.
*/
