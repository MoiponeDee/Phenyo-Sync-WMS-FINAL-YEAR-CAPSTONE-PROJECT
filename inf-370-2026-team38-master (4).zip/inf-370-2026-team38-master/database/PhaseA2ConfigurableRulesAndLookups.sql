/*
 Phase A2 deployment order:
 1. Back up WMS_DB.
 2. Give every existing user a unique real email address.
 3. Apply Phase A1 and verify login/permissions.
 4. Apply this idempotent Phase A2 script.

 This preflight is intentionally read-only. It never changes conflicting users.
*/
IF OBJECT_ID(N'dbo.Users', N'U') IS NOT NULL
   AND EXISTS
   (
       SELECT UPPER(LTRIM(RTRIM(Email)))
       FROM dbo.Users
       GROUP BY UPPER(LTRIM(RTRIM(Email)))
       HAVING COUNT(*) > 1
   )
    THROW 51002,
        'Phase A2 is blocked: duplicate normalized user emails must be assigned unique real addresses before Phase A1 and Phase A2 are applied.',
        1;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @var0 sysname;
    SELECT @var0 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[WarehouseSections]') AND [c].[name] = N'Status');
    IF @var0 IS NOT NULL EXEC(N'ALTER TABLE [WarehouseSections] DROP CONSTRAINT [' + @var0 + '];');
    ALTER TABLE [WarehouseSections] ALTER COLUMN [Status] nvarchar(20) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @var1 sysname;
    SELECT @var1 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[WarehouseSections]') AND [c].[name] = N'SectionName');
    IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [WarehouseSections] DROP CONSTRAINT [' + @var1 + '];');
    ALTER TABLE [WarehouseSections] ALTER COLUMN [SectionName] nvarchar(100) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @var2 sysname;
    SELECT @var2 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[WarehouseSections]') AND [c].[name] = N'Description');
    IF @var2 IS NOT NULL EXEC(N'ALTER TABLE [WarehouseSections] DROP CONSTRAINT [' + @var2 + '];');
    ALTER TABLE [WarehouseSections] ALTER COLUMN [Description] nvarchar(500) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    ALTER TABLE [WarehouseSections] ADD [CreatedAtUtc] datetime2 NOT NULL DEFAULT (SYSUTCDATETIME());
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    ALTER TABLE [WarehouseSections] ADD [RowVersion] rowversion NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    ALTER TABLE [WarehouseSections] ADD [SectionCode] nvarchar(40) NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    ALTER TABLE [WarehouseSections] ADD [UpdatedAtUtc] datetime2 NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    UPDATE dbo.WarehouseSections
    SET SectionCode = CONCAT('SECTION-', RIGHT(CONCAT('000000', SectionId), 6))
    WHERE SectionCode IS NULL OR LTRIM(RTRIM(SectionCode)) = '';
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @var3 sysname;
    SELECT @var3 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[WarehouseSections]') AND [c].[name] = N'SectionCode');
    IF @var3 IS NOT NULL EXEC(N'ALTER TABLE [WarehouseSections] DROP CONSTRAINT [' + @var3 + '];');
    ALTER TABLE [WarehouseSections] ALTER COLUMN [SectionCode] nvarchar(40) NOT NULL;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [LookupTypes] (
        [LookupTypeId] int NOT NULL IDENTITY,
        [SystemCode] nvarchar(80) NOT NULL,
        [DisplayName] nvarchar(120) NOT NULL,
        [Description] nvarchar(500) NULL,
        [IsSystemType] bit NOT NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_LookupTypes] PRIMARY KEY ([LookupTypeId])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [SystemSettings] (
        [SystemSettingId] int NOT NULL IDENTITY,
        [Key] nvarchar(150) NOT NULL,
        [Category] nvarchar(80) NOT NULL,
        [DisplayName] nvarchar(120) NOT NULL,
        [Description] nvarchar(500) NOT NULL,
        [ValueType] nvarchar(40) NOT NULL,
        [Value] nvarchar(2000) NOT NULL,
        [DefaultValue] nvarchar(2000) NOT NULL,
        [Unit] nvarchar(40) NULL,
        [MinimumValue] nvarchar(100) NULL,
        [MaximumValue] nvarchar(100) NULL,
        [AllowedValuesJson] nvarchar(max) NULL,
        [IsSensitive] bit NOT NULL,
        [IsSystemSetting] bit NOT NULL,
        [IsActive] bit NOT NULL,
        [RequiresRestart] bit NOT NULL,
        [UpdatedAtUtc] datetime2 NOT NULL,
        [UpdatedByUserId] int NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_SystemSettings] PRIMARY KEY ([SystemSettingId]),
        CONSTRAINT [FK_SystemSettings_Users_UpdatedByUserId] FOREIGN KEY ([UpdatedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [LookupValues] (
        [LookupValueId] int NOT NULL IDENTITY,
        [LookupTypeId] int NOT NULL,
        [SystemCode] nvarchar(80) NOT NULL,
        [DisplayName] nvarchar(120) NOT NULL,
        [Description] nvarchar(500) NULL,
        [SortOrder] int NOT NULL,
        [IsSystemValue] bit NOT NULL,
        [IsActive] bit NOT NULL,
        [CreatedAtUtc] datetime2 NOT NULL,
        [UpdatedAtUtc] datetime2 NULL,
        [RowVersion] rowversion NULL,
        CONSTRAINT [PK_LookupValues] PRIMARY KEY ([LookupValueId]),
        CONSTRAINT [FK_LookupValues_LookupTypes_LookupTypeId] FOREIGN KEY ([LookupTypeId]) REFERENCES [LookupTypes] ([LookupTypeId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [SystemSettingHistory] (
        [SystemSettingHistoryId] bigint NOT NULL IDENTITY,
        [SystemSettingId] int NOT NULL,
        [PreviousValue] nvarchar(2000) NOT NULL,
        [NewValue] nvarchar(2000) NOT NULL,
        [ChangedAtUtc] datetime2 NOT NULL,
        [ChangedByUserId] int NULL,
        [Reason] nvarchar(500) NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        [AppliedSuccessfully] bit NOT NULL,
        [FailureReason] nvarchar(500) NULL,
        CONSTRAINT [PK_SystemSettingHistory] PRIMARY KEY ([SystemSettingHistoryId]),
        CONSTRAINT [FK_SystemSettingHistory_SystemSettings_SystemSettingId] FOREIGN KEY ([SystemSettingId]) REFERENCES [SystemSettings] ([SystemSettingId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_SystemSettingHistory_Users_ChangedByUserId] FOREIGN KEY ([ChangedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE TABLE [LookupValueHistory] (
        [LookupValueHistoryId] bigint NOT NULL IDENTITY,
        [LookupValueId] int NOT NULL,
        [ChangeType] nvarchar(40) NOT NULL,
        [BeforeValuesJson] nvarchar(max) NULL,
        [AfterValuesJson] nvarchar(max) NULL,
        [ChangedByUserId] int NULL,
        [ChangedAtUtc] datetime2 NOT NULL,
        [Reason] nvarchar(500) NOT NULL,
        [CorrelationId] nvarchar(64) NOT NULL,
        CONSTRAINT [PK_LookupValueHistory] PRIMARY KEY ([LookupValueHistoryId]),
        CONSTRAINT [FK_LookupValueHistory_LookupValues_LookupValueId] FOREIGN KEY ([LookupValueId]) REFERENCES [LookupValues] ([LookupValueId]) ON DELETE NO ACTION,
        CONSTRAINT [FK_LookupValueHistory_Users_ChangedByUserId] FOREIGN KEY ([ChangedByUserId]) REFERENCES [Users] ([UserId]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'LookupTypeId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'IsSystemType', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[LookupTypes]'))
        SET IDENTITY_INSERT [LookupTypes] ON;
    EXEC(N'INSERT INTO [LookupTypes] ([LookupTypeId], [CreatedAtUtc], [Description], [DisplayName], [IsActive], [IsSystemType], [SystemCode], [UpdatedAtUtc])
    VALUES (1, ''2026-07-24T00:00:00.0000000Z'', N''Reasons recorded when stock is adjusted or moved.'', N''Stock movement reasons'', CAST(1 AS bit), CAST(1 AS bit), N''STOCK_MOVEMENT_REASON'', NULL),
    (2, ''2026-07-24T00:00:00.0000000Z'', N''Approved reasons for final stock write-off.'', N''Write-off reasons'', CAST(1 AS bit), CAST(1 AS bit), N''WRITE_OFF_REASON'', NULL),
    (3, ''2026-07-24T00:00:00.0000000Z'', N''Reasons used when a sales order is cancelled.'', N''Order cancellation reasons'', CAST(1 AS bit), CAST(1 AS bit), N''ORDER_CANCELLATION_REASON'', NULL),
    (4, ''2026-07-24T00:00:00.0000000Z'', N''Reasons used when an order is rejected during validation.'', N''Order rejection reasons'', CAST(1 AS bit), CAST(1 AS bit), N''ORDER_REJECTION_REASON'', NULL),
    (5, ''2026-07-24T00:00:00.0000000Z'', N''Reasons recorded when a delivery cannot be fulfilled.'', N''Delivery failure reasons'', CAST(1 AS bit), CAST(1 AS bit), N''DELIVERY_FAILURE_REASON'', NULL),
    (6, ''2026-07-24T00:00:00.0000000Z'', N''Approved customer and supplier payment methods.'', N''Payment methods'', CAST(1 AS bit), CAST(1 AS bit), N''PAYMENT_METHOD'', NULL),
    (7, ''2026-07-24T00:00:00.0000000Z'', N''Customer classifications used by operational forms.'', N''Customer types'', CAST(1 AS bit), CAST(1 AS bit), N''CUSTOMER_TYPE'', NULL),
    (8, ''2026-07-24T00:00:00.0000000Z'', N''Supplier classifications used by operational forms.'', N''Supplier types'', CAST(1 AS bit), CAST(1 AS bit), N''SUPPLIER_TYPE'', NULL),
    (9, ''2026-07-24T00:00:00.0000000Z'', N''Units available for quantities and packaging.'', N''Units of measure'', CAST(1 AS bit), CAST(1 AS bit), N''UNIT_OF_MEASURE'', NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'LookupTypeId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'IsSystemType', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[LookupTypes]'))
        SET IDENTITY_INSERT [LookupTypes] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] ON;
    EXEC(N'INSERT INTO [SystemSettings] ([SystemSettingId], [AllowedValuesJson], [Category], [DefaultValue], [Description], [DisplayName], [IsActive], [IsSensitive], [IsSystemSetting], [Key], [MaximumValue], [MinimumValue], [RequiresRestart], [Unit], [UpdatedAtUtc], [UpdatedByUserId], [Value], [ValueType])
    VALUES (1, NULL, N''Expiry'', N''72'', N''Hours before expiry when a batch becomes a yellow warning.'', N''Yellow warning threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.YellowThresholdHours'', N''720'', N''2'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''72'', N''TimeSpanHours''),
    (2, NULL, N''Expiry'', N''24'', N''Hours before expiry when a batch becomes urgent.'', N''Red urgent threshold'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.RedThresholdHours'', N''168'', N''1'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''24'', N''TimeSpanHours''),
    (3, NULL, N''Expiry'', N''60'', N''Minutes between automatic expiry scans.'', N''Expiry scan interval'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.ScanIntervalMinutes'', N''1440'', N''1'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''60'', N''TimeSpanMinutes''),
    (4, NULL, N''Expiry'', N''2'', N''Days added by a permitted one-time shelf-life extension.'', N''Shelf-life extension'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.ShelfLifeExtensionDays'', N''14'', N''1'', CAST(0 AS bit), N''days'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''2'', N''Integer''),
    (5, NULL, N''Expiry'', N''48'', N''Hours before a newly generated expiry decision link expires.'', N''Expiry action-link lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.ActionTokenLifetimeHours'', N''168'', N''1'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''48'', N''TimeSpanHours''),
    (6, NULL, N''Expiry'', N''["BusinessManager","CEO","COO","WarehouseManager"]'', N''Active role codes that receive new expiry-alert emails.'', N''Expiry recipient roles'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Expiry.RecipientRoleCodes'', NULL, NULL, CAST(0 AS bit), NULL, ''2026-07-24T00:00:00.0000000Z'', NULL, N''["BusinessManager","CEO","COO","WarehouseManager"]'', N''StringArray''),
    (7, NULL, N''Orders'', N''72'', N''Hours before a newly created customer order link expires.'', N''Customer order-link lifetime'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Orders.OrderLinkLifetimeHours'', N''168'', N''1'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''72'', N''TimeSpanHours''),
    (8, NULL, N''Orders'', N''0'', N''Extra hours beyond requested delivery time that reserved batches must remain valid.'', N''Delivery stock-safety window'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Orders.DeliverySafetyHours'', N''168'', N''0'', CAST(0 AS bit), N''hours'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''0'', N''TimeSpanHours''),
    (9, NULL, N''Delivery'', N''120'', N''Duration used for a new schedule when no end time is supplied.'', N''Default delivery duration'', CAST(1 AS bit), CAST(0 AS bit), CAST(1 AS bit), N''Delivery.DefaultDurationMinutes'', N''1440'', N''15'', CAST(0 AS bit), N''minutes'', ''2026-07-24T00:00:00.0000000Z'', NULL, N''120'', N''TimeSpanMinutes'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'SystemSettingId', N'AllowedValuesJson', N'Category', N'DefaultValue', N'Description', N'DisplayName', N'IsActive', N'IsSensitive', N'IsSystemSetting', N'Key', N'MaximumValue', N'MinimumValue', N'RequiresRestart', N'Unit', N'UpdatedAtUtc', N'UpdatedByUserId', N'Value', N'ValueType') AND [object_id] = OBJECT_ID(N'[SystemSettings]'))
        SET IDENTITY_INSERT [SystemSettings] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'LookupValueId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'IsSystemValue', N'LookupTypeId', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[LookupValues]'))
        SET IDENTITY_INSERT [LookupValues] ON;
    EXEC(N'INSERT INTO [LookupValues] ([LookupValueId], [CreatedAtUtc], [Description], [DisplayName], [IsActive], [IsSystemValue], [LookupTypeId], [SortOrder], [SystemCode], [UpdatedAtUtc])
    VALUES (1, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Production increase'', CAST(1 AS bit), CAST(1 AS bit), 1, 10, N''PRODUCTION_INCREASE'', NULL),
    (2, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Packing decrease'', CAST(1 AS bit), CAST(1 AS bit), 1, 20, N''PACKING_DECREASE'', NULL),
    (3, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Stock adjustment'', CAST(1 AS bit), CAST(1 AS bit), 1, 30, N''STOCK_ADJUSTMENT'', NULL),
    (4, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Expired stock'', CAST(1 AS bit), CAST(1 AS bit), 2, 10, N''EXPIRED'', NULL),
    (5, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Damaged stock'', CAST(1 AS bit), CAST(1 AS bit), 2, 20, N''DAMAGED'', NULL),
    (6, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Quality inspection failure'', CAST(1 AS bit), CAST(1 AS bit), 2, 30, N''QUALITY_FAILURE'', NULL),
    (7, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Customer request'', CAST(1 AS bit), CAST(1 AS bit), 3, 10, N''CUSTOMER_REQUEST'', NULL),
    (8, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Duplicate order'', CAST(1 AS bit), CAST(1 AS bit), 3, 20, N''DUPLICATE_ORDER'', NULL),
    (9, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Stock unavailable'', CAST(1 AS bit), CAST(1 AS bit), 3, 30, N''STOCK_UNAVAILABLE'', NULL),
    (10, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Insufficient stock'', CAST(1 AS bit), CAST(1 AS bit), 4, 10, N''INSUFFICIENT_STOCK'', NULL),
    (11, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Invalid order details'', CAST(1 AS bit), CAST(1 AS bit), 4, 20, N''INVALID_DETAILS'', NULL),
    (12, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Customer unavailable'', CAST(1 AS bit), CAST(1 AS bit), 5, 10, N''CUSTOMER_UNAVAILABLE'', NULL),
    (13, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Address not found'', CAST(1 AS bit), CAST(1 AS bit), 5, 20, N''ADDRESS_NOT_FOUND'', NULL),
    (14, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Vehicle issue'', CAST(1 AS bit), CAST(1 AS bit), 5, 30, N''VEHICLE_ISSUE'', NULL),
    (15, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Electronic funds transfer'', CAST(1 AS bit), CAST(1 AS bit), 6, 10, N''EFT'', NULL),
    (16, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Card'', CAST(1 AS bit), CAST(1 AS bit), 6, 20, N''CARD'', NULL),
    (17, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Cash'', CAST(1 AS bit), CAST(1 AS bit), 6, 30, N''CASH'', NULL),
    (18, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Retail'', CAST(1 AS bit), CAST(1 AS bit), 7, 10, N''RETAIL'', NULL),
    (19, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Wholesale'', CAST(1 AS bit), CAST(1 AS bit), 7, 20, N''WHOLESALE'', NULL),
    (20, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Distributor'', CAST(1 AS bit), CAST(1 AS bit), 7, 30, N''DISTRIBUTOR'', NULL),
    (21, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Producer'', CAST(1 AS bit), CAST(1 AS bit), 8, 10, N''PRODUCER'', NULL),
    (22, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Distributor'', CAST(1 AS bit), CAST(1 AS bit), 8, 20, N''DISTRIBUTOR'', NULL),
    (23, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Service provider'', CAST(1 AS bit), CAST(1 AS bit), 8, 30, N''SERVICE_PROVIDER'', NULL),
    (24, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Kilogram (kg)'', CAST(1 AS bit), CAST(1 AS bit), 9, 10, N''KG'', NULL),
    (25, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Gram (g)'', CAST(1 AS bit), CAST(1 AS bit), 9, 20, N''G'', NULL),
    (26, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Litre (L)'', CAST(1 AS bit), CAST(1 AS bit), 9, 30, N''L'', NULL),
    (27, ''2026-07-24T00:00:00.0000000Z'', NULL, N''Unit'', CAST(1 AS bit), CAST(1 AS bit), 9, 40, N''UNIT'', NULL)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'LookupValueId', N'CreatedAtUtc', N'Description', N'DisplayName', N'IsActive', N'IsSystemValue', N'LookupTypeId', N'SortOrder', N'SystemCode', N'UpdatedAtUtc') AND [object_id] = OBJECT_ID(N'[LookupValues]'))
        SET IDENTITY_INSERT [LookupValues] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_WarehouseSections_Status_SectionName] ON [WarehouseSections] ([Status], [SectionName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE UNIQUE INDEX [UX_WarehouseSections_SectionCode] ON [WarehouseSections] ([SectionCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_LookupTypes_IsActive_DisplayName] ON [LookupTypes] ([IsActive], [DisplayName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE UNIQUE INDEX [UX_LookupTypes_SystemCode] ON [LookupTypes] ([SystemCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_LookupValueHistory_ChangedByUserId] ON [LookupValueHistory] ([ChangedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_LookupValueHistory_LookupValueId_ChangedAtUtc] ON [LookupValueHistory] ([LookupValueId], [ChangedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_LookupValues_LookupTypeId_IsActive_SortOrder_DisplayName] ON [LookupValues] ([LookupTypeId], [IsActive], [SortOrder], [DisplayName]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE UNIQUE INDEX [UX_LookupValues_Type_SystemCode] ON [LookupValues] ([LookupTypeId], [SystemCode]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_SystemSettingHistory_ChangedByUserId] ON [SystemSettingHistory] ([ChangedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_SystemSettingHistory_SystemSettingId_ChangedAtUtc] ON [SystemSettingHistory] ([SystemSettingId], [ChangedAtUtc]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_SystemSettings_Category_IsActive] ON [SystemSettings] ([Category], [IsActive]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE INDEX [IX_SystemSettings_UpdatedByUserId] ON [SystemSettings] ([UpdatedByUserId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    CREATE UNIQUE INDEX [UX_SystemSettings_Key] ON [SystemSettings] ([Key]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    DECLARE @A2PermissionSeed TABLE
    (
        PermissionCode nvarchar(100) NOT NULL,
        DisplayName nvarchar(120) NOT NULL
    );
    INSERT INTO @A2PermissionSeed VALUES
        ('Lookups.View','View operational lookup values'),
        ('Lookups.Manage','Manage operational lookup values'),
        ('WarehouseSections.View','View warehouse sections'),
        ('WarehouseSections.Manage','Manage warehouse sections'),
        ('SystemSettings.View','View configurable business rules'),
        ('SystemSettings.Manage','Manage configurable business rules');
    INSERT INTO dbo.Permissions
        (PermissionName, PermissionCode, DisplayName, Module,
         IsSystemPermission, IsActive, CreatedAtUtc)
    SELECT seed.PermissionCode, seed.PermissionCode,
           seed.DisplayName, 'Configuration', 1, 1, SYSUTCDATETIME()
    FROM @A2PermissionSeed seed
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.Permissions existing
        WHERE existing.PermissionCode = seed.PermissionCode);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode IN
         ('Lookups.View','Lookups.Manage',
          'WarehouseSections.View','WarehouseSections.Manage',
          'SystemSettings.View','SystemSettings.Manage')
    WHERE role.RoleCode IN ('CEO','COO','BusinessManager')
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions mapping
          WHERE mapping.RoleId = role.RoleId
            AND mapping.PermissionId = permission.PermissionId);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode IN
         ('Lookups.View','WarehouseSections.View')
    WHERE role.RoleCode IN ('Admin','Packer','WarehouseManager')
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions mapping
          WHERE mapping.RoleId = role.RoleId
            AND mapping.PermissionId = permission.PermissionId);
    INSERT INTO dbo.RolePermissions
        (RoleId, PermissionId, AssignedAtUtc)
    SELECT role.RoleId, permission.PermissionId, SYSUTCDATETIME()
    FROM dbo.Roles role
    JOIN dbo.Permissions permission
      ON permission.PermissionCode = 'Lookups.View'
    WHERE role.RoleCode = 'Driver'
      AND NOT EXISTS (
          SELECT 1 FROM dbo.RolePermissions mapping
          WHERE mapping.RoleId = role.RoleId
            AND mapping.PermissionId = permission.PermissionId);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20260724130000_PhaseA2ConfigurableRulesAndLookups'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20260724130000_PhaseA2ConfigurableRulesAndLookups', N'8.0.0');
END;
GO

COMMIT;
GO

