/*
    PhenyoSync final presentation data
    ----------------------------------
    Safe, rerunnable preparation for the lecturer demonstration.

    This script deliberately preserves operational history. It deactivates
    non-presentation Product masters instead of deleting them and upserts only
    records identified by stable presentation names/codes.

    Review the verification result sets before committing this script to a
    shared environment. Take a verified backup before execution.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @Now datetime2(7) = SYSUTCDATETIME();
    DECLARE @ActorUserId int;
    DECLARE @WarehouseSectionId int;
    DECLARE @MarketAgencyCode nvarchar(40);
    DECLARE @DirectSupplierCode nvarchar(40);

    SELECT TOP (1) @ActorUserId = u.UserId
    FROM dbo.Users AS u
    INNER JOIN dbo.Roles AS r ON r.RoleId = u.RoleId
    WHERE u.Status = 'Active'
    ORDER BY CASE r.RoleCode
        WHEN 'OperationsManager' THEN 1
        WHEN 'Administrator' THEN 2
        WHEN 'BusinessManager' THEN 3
        WHEN 'CEO' THEN 4
        WHEN 'COO' THEN 5
        ELSE 20
    END, u.UserId;

    IF @ActorUserId IS NULL
        THROW 51000, 'An active authorised user is required for traceable presentation data.', 1;

    SELECT TOP (1) @WarehouseSectionId = SectionId
    FROM dbo.WarehouseSections
    WHERE Status = 'Active'
    ORDER BY CASE
        WHEN SectionCode IN ('RAW', 'RECEIVING', 'STORAGE') THEN 0
        WHEN SectionName LIKE '%Raw%' OR SectionName LIKE '%Storage%' THEN 1
        ELSE 2
    END, SectionId;

    IF @WarehouseSectionId IS NULL
        THROW 51001, 'Create or activate a Warehouse Section before loading opening Raw Stock.', 1;

    SELECT TOP (1) @MarketAgencyCode = lv.SystemCode
    FROM dbo.LookupValues AS lv
    INNER JOIN dbo.LookupTypes AS lt ON lt.LookupTypeId = lv.LookupTypeId
    WHERE lt.SystemCode = 'SupplierType'
      AND lv.IsActive = 1
      AND (lv.DisplayName LIKE '%Market%Agency%' OR lv.SystemCode LIKE '%Market%Agency%')
    ORDER BY lv.SortOrder, lv.LookupValueId;

    SELECT TOP (1) @DirectSupplierCode = lv.SystemCode
    FROM dbo.LookupValues AS lv
    INNER JOIN dbo.LookupTypes AS lt ON lt.LookupTypeId = lv.LookupTypeId
    WHERE lt.SystemCode = 'SupplierType'
      AND lv.IsActive = 1
      AND (
          lv.DisplayName LIKE '%Direct%Produce%'
          OR lv.DisplayName LIKE '%Produce%Supplier%'
          OR lv.SystemCode LIKE '%Direct%'
      )
    ORDER BY lv.SortOrder, lv.LookupValueId;

    IF @MarketAgencyCode IS NULL
    BEGIN
        SELECT TOP (1) @MarketAgencyCode = lv.SystemCode
        FROM dbo.LookupValues AS lv
        INNER JOIN dbo.LookupTypes AS lt ON lt.LookupTypeId = lv.LookupTypeId
        WHERE lt.SystemCode = 'SupplierType' AND lv.IsActive = 1
        ORDER BY lv.SortOrder, lv.LookupValueId;
    END;

    SET @DirectSupplierCode = COALESCE(@DirectSupplierCode, @MarketAgencyCode);

    IF @MarketAgencyCode IS NULL
        THROW 51002, 'An active Supplier Type lookup value is required before supplier seeding.', 1;

    --------------------------------------------------------------------------
    -- Clean Product hierarchy
    --------------------------------------------------------------------------
    DECLARE @Categories table
    (
        Name nvarchar(100) NOT NULL PRIMARY KEY,
        Description nvarchar(255) NOT NULL
    );

    INSERT @Categories (Name, Description)
    VALUES
        ('Fresh Produce', 'Whole fresh produce prepared and packed for sale.'),
        ('Salads', 'Prepared produce mixes packed for sale.');

    UPDATE category
    SET ProductCategoryName = source.Name,
        Description = source.Description,
        Status = 'Active',
        UpdatedAt = @Now
    FROM dbo.ProductCategory AS category
    INNER JOIN @Categories AS source
        ON source.Name = category.ProductCategoryName;

    INSERT dbo.ProductCategory
        (ProductCategoryName, Description, Status, CreatedAt)
    SELECT source.Name, source.Description, 'Active', @Now
    FROM @Categories AS source
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.ProductCategory AS category
        WHERE category.ProductCategoryName = source.Name
    );

    UPDATE dbo.ProductCategory
    SET Status = 'Inactive', UpdatedAt = @Now
    WHERE ProductCategoryName NOT IN (SELECT Name FROM @Categories)
      AND Status <> 'Inactive';

    DECLARE @Types table
    (
        Name nvarchar(100) NOT NULL PRIMARY KEY,
        Description nvarchar(255) NOT NULL
    );

    INSERT @Types (Name, Description)
    VALUES
        ('Fruit', 'Fruit Products and fruit-based prepared mixes.'),
        ('Veg', 'Vegetable Products and vegetable-based prepared mixes.');

    UPDATE productType
    SET ProductTypeName = source.Name,
        Description = source.Description,
        Status = 'Active',
        UpdatedAt = @Now
    FROM dbo.ProductType AS productType
    INNER JOIN @Types AS source ON source.Name = productType.ProductTypeName;

    INSERT dbo.ProductType
        (ProductTypeName, Description, Status, CreatedAt)
    SELECT source.Name, source.Description, 'Active', @Now
    FROM @Types AS source
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.ProductType AS productType
        WHERE productType.ProductTypeName = source.Name
    );

    UPDATE dbo.ProductType
    SET Status = 'Inactive', UpdatedAt = @Now
    WHERE ProductTypeName NOT IN (SELECT Name FROM @Types)
      AND Status <> 'Inactive';

    INSERT dbo.ProductCategoryTypes
        (ProductCategoryId, ProductTypeId, CreatedAtUtc, CreatedByUserId)
    SELECT category.ProductCategoryId,
           productType.ProductTypeId,
           @Now,
           @ActorUserId
    FROM dbo.ProductCategory AS category
    CROSS JOIN dbo.ProductType AS productType
    WHERE category.ProductCategoryName IN (SELECT Name FROM @Categories)
      AND productType.ProductTypeName IN (SELECT Name FROM @Types)
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.ProductCategoryTypes AS link
          WHERE link.ProductCategoryId = category.ProductCategoryId
            AND link.ProductTypeId = productType.ProductTypeId
      );

    --------------------------------------------------------------------------
    -- Final ten sellable Products
    --------------------------------------------------------------------------
    DECLARE @Products table
    (
        ProductName nvarchar(150) NOT NULL PRIMARY KEY,
        CategoryName nvarchar(100) NOT NULL,
        TypeName nvarchar(100) NOT NULL,
        Size nvarchar(50) NOT NULL,
        ShelfLifeDays int NOT NULL,
        Price decimal(18,2) NOT NULL,
        ProductCode nvarchar(80) NOT NULL
    );

    INSERT @Products
        (ProductName, CategoryName, TypeName, Size, ShelfLifeDays, Price, ProductCode)
    VALUES
        ('Granny Smith Apples', 'Fresh Produce', 'Fruit', '3 KG', 10, 27.50, 'GRANNY-3KG'),
        ('Pink Lady Apples', 'Fresh Produce', 'Fruit', '3 KG', 10, 30.00, 'PINK-3KG'),
        ('Mondial Potatoes', 'Fresh Produce', 'Veg', '10 KG', 10, 10.50, 'MONDIAL-10KG'),
        ('Sifra Potatoes', 'Fresh Produce', 'Veg', '10 KG', 10, 11.00, 'SIFRA-10KG'),
        ('Jam Tomatoes', 'Fresh Produce', 'Veg', '6 KG', 5, 18.00, 'JAMTOM-6KG'),
        ('Nantes Carrots', 'Fresh Produce', 'Veg', '5 KG', 7, 14.00, 'NANTES-5KG'),
        ('Brown Onions', 'Fresh Produce', 'Veg', '10 KG', 14, 11.00, 'BROWN-ONION-10KG'),
        ('Robot Peppers', 'Fresh Produce', 'Veg', '3 KG', 5, 35.00, 'ROBOT-PEPPER-3KG'),
        ('Garden Salad Mix', 'Salads', 'Veg', '1 KG', 3, 60.00, 'GARDEN-SALAD-1KG'),
        ('Fruit Salad Mix', 'Salads', 'Fruit', '1 KG', 3, 65.00, 'FRUIT-SALAD-1KG');

    UPDATE product
    SET ProductCategoryId = category.ProductCategoryId,
        ProductTypeId = productType.ProductTypeId,
        Size = source.Size,
        ShelfLifeDays = source.ShelfLifeDays,
        SellingPricePerKg = source.Price,
        QRCodeValue = CONCAT('PHENYOSYNC:PRODUCT:', source.ProductCode),
        Status = 'Active',
        UpdatedAt = @Now
    FROM dbo.Product AS product
    INNER JOIN @Products AS source ON source.ProductName = product.ProductName
    INNER JOIN dbo.ProductCategory AS category
        ON category.ProductCategoryName = source.CategoryName
    INNER JOIN dbo.ProductType AS productType
        ON productType.ProductTypeName = source.TypeName;

    INSERT dbo.Product
    (
        ProductName,
        ProductTypeId,
        ProductCategoryId,
        Size,
        ShelfLifeDays,
        SellingPricePerKg,
        QRCodeValue,
        Status,
        CreatedAt
    )
    SELECT source.ProductName,
           productType.ProductTypeId,
           category.ProductCategoryId,
           source.Size,
           source.ShelfLifeDays,
           source.Price,
           CONCAT('PHENYOSYNC:PRODUCT:', source.ProductCode),
           'Active',
           @Now
    FROM @Products AS source
    INNER JOIN dbo.ProductCategory AS category
        ON category.ProductCategoryName = source.CategoryName
    INNER JOIN dbo.ProductType AS productType
        ON productType.ProductTypeName = source.TypeName
    WHERE NOT EXISTS
    (
        SELECT 1 FROM dbo.Product AS product
        WHERE product.ProductName = source.ProductName
    );

    -- Operationally referenced Products are retained and merely deactivated.
    UPDATE dbo.Product
    SET Status = 'Inactive', UpdatedAt = @Now
    WHERE ProductName NOT IN (SELECT ProductName FROM @Products)
      AND Status <> 'Inactive';

    -- Preserve price history and guarantee exactly one active current price.
    UPDATE currentPrice
    SET EffectiveToUtc = @Now,
        IsCurrent = 0
    FROM dbo.ProductPrices AS currentPrice
    INNER JOIN dbo.Product AS product
        ON product.ProductId = currentPrice.ProductId
    INNER JOIN @Products AS source
        ON source.ProductName = product.ProductName
    WHERE currentPrice.IsCurrent = 1
      AND currentPrice.IsDeleted = 0
      AND currentPrice.SellingPrice <> source.Price;

    INSERT dbo.ProductPrices
    (
        ProductId,
        SellingPrice,
        EffectiveFromUtc,
        EffectiveToUtc,
        IsCurrent,
        IsDeleted,
        CreatedAtUtc,
        CreatedByUserId,
        ChangeReason
    )
    SELECT product.ProductId,
           source.Price,
           @Now,
           NULL,
           1,
           0,
           @Now,
           @ActorUserId,
           'Final presentation demo price'
    FROM @Products AS source
    INNER JOIN dbo.Product AS product
        ON product.ProductName = source.ProductName
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.ProductPrices AS price
        WHERE price.ProductId = product.ProductId
          AND price.IsCurrent = 1
          AND price.IsDeleted = 0
    );

    --------------------------------------------------------------------------
    -- Raw Stock master and recipes
    -- CategoryCode uses the supported Produce domain value. Fruit/Veg is
    -- retained in the description so application validation is not bypassed.
    --------------------------------------------------------------------------
    DECLARE @RawStock table
    (
        ItemCode nvarchar(40) NOT NULL PRIMARY KEY,
        ItemName nvarchar(160) NOT NULL,
        ProduceGroup nvarchar(20) NOT NULL,
        OpeningQuantity decimal(18,3) NOT NULL,
        UnitCost decimal(18,4) NOT NULL
    );

    INSERT @RawStock
        (ItemCode, ItemName, ProduceGroup, OpeningQuantity, UnitCost)
    VALUES
        ('RAW-FRU-GRANNY', 'Loose Granny Smith Apples', 'Fruit', 120, 12.00),
        ('RAW-FRU-PINK', 'Loose Pink Lady Apples', 'Fruit', 100, 13.00),
        ('RAW-VEG-MONDIAL', 'Loose Mondial Potatoes', 'Veg', 300, 5.00),
        ('RAW-VEG-SIFRA', 'Loose Sifra Potatoes', 'Veg', 250, 5.25),
        ('RAW-VEG-JAMTOM', 'Loose Jam Tomatoes', 'Veg', 150, 8.00),
        ('RAW-VEG-NANTES', 'Loose Nantes Carrots', 'Veg', 150, 6.00),
        ('RAW-VEG-BROWN-ONION', 'Loose Brown Onions', 'Veg', 250, 5.10),
        ('RAW-VEG-ROBOT-PEPPER', 'Loose Robot Peppers', 'Veg', 100, 16.00),
        ('RAW-VEG-ICEBERG', 'Loose Iceberg Lettuce', 'Veg', 60, 13.00),
        ('RAW-VEG-CUCUMBER', 'Loose English Cucumbers', 'Veg', 60, 10.00),
        ('RAW-FRU-PINEAPPLE', 'Loose Pineapple', 'Fruit', 60, 15.00),
        ('RAW-FRU-GRAPES', 'Loose Seedless Grapes', 'Fruit', 60, 24.00);

    UPDATE item
    SET ItemName = source.ItemName,
        CategoryCode = 'Produce',
        DefaultUnitOfMeasure = 'kg',
        Description = CONCAT(source.ProduceGroup, ' produce for presentation recipes.'),
        IsProduce = 1,
        IsActive = 1,
        UpdatedAtUtc = @Now
    FROM dbo.RawStockItems AS item
    INNER JOIN @RawStock AS source ON source.ItemCode = item.ItemCode;

    INSERT dbo.RawStockItems
    (
        ItemCode,
        ItemName,
        CategoryCode,
        DefaultUnitOfMeasure,
        Description,
        IsProduce,
        IsActive,
        CreatedAtUtc
    )
    SELECT source.ItemCode,
           source.ItemName,
           'Produce',
           'kg',
           CONCAT(source.ProduceGroup, ' produce for presentation recipes.'),
           1,
           1,
           @Now
    FROM @RawStock AS source
    WHERE NOT EXISTS
    (
        SELECT 1 FROM dbo.RawStockItems AS item
        WHERE item.ItemCode = source.ItemCode
    );

    INSERT dbo.RawStockBalances
    (
        RawStockItemId,
        WarehouseSectionId,
        UnitOfMeasure,
        QuantityOnHand,
        ReservedQuantity,
        WeightedAverageUnitCost,
        LastReceiptAtUtc
    )
    SELECT item.RawStockItemId,
           @WarehouseSectionId,
           'kg',
           0,
           0,
           source.UnitCost,
           @Now
    FROM @RawStock AS source
    INNER JOIN dbo.RawStockItems AS item ON item.ItemCode = source.ItemCode
    WHERE NOT EXISTS
    (
        SELECT 1 FROM dbo.RawStockBalances AS balance
        WHERE balance.RawStockItemId = item.RawStockItemId
          AND balance.WarehouseSectionId = @WarehouseSectionId
          AND balance.UnitOfMeasure = 'kg'
    );

    UPDATE batch
    SET RawStockItemId = item.RawStockItemId,
        RawStockBalanceId = balance.RawStockBalanceId,
        QuantityReceived = source.OpeningQuantity,
        QuantityRemaining = source.OpeningQuantity,
        UnitCost = source.UnitCost,
        ReceivedAtUtc = @Now,
        BestBeforeAtUtc = DATEADD(day, 21, @Now),
        Status = 'Available'
    FROM dbo.RawStockBatches AS batch
    INNER JOIN @RawStock AS source
        ON batch.BatchCode = CONCAT('DEMO-OPEN-', source.ItemCode)
    INNER JOIN dbo.RawStockItems AS item ON item.ItemCode = source.ItemCode
    INNER JOIN dbo.RawStockBalances AS balance
        ON balance.RawStockItemId = item.RawStockItemId
       AND balance.WarehouseSectionId = @WarehouseSectionId
       AND balance.UnitOfMeasure = 'kg';

    INSERT dbo.RawStockBatches
    (
        RawStockItemId,
        RawStockBalanceId,
        SupplierId,
        RawStockReceiptLineId,
        BatchCode,
        QrCodeValue,
        QuantityReceived,
        QuantityRemaining,
        UnitCost,
        ReceivedAtUtc,
        BestBeforeAtUtc,
        Status
    )
    SELECT item.RawStockItemId,
           balance.RawStockBalanceId,
           NULL,
           NULL,
           CONCAT('DEMO-OPEN-', source.ItemCode),
           CONCAT('PHENYOSYNC:RAW:', source.ItemCode, ':OPENING'),
           source.OpeningQuantity,
           source.OpeningQuantity,
           source.UnitCost,
           @Now,
           DATEADD(day, 21, @Now),
           'Available'
    FROM @RawStock AS source
    INNER JOIN dbo.RawStockItems AS item ON item.ItemCode = source.ItemCode
    INNER JOIN dbo.RawStockBalances AS balance
        ON balance.RawStockItemId = item.RawStockItemId
       AND balance.WarehouseSectionId = @WarehouseSectionId
       AND balance.UnitOfMeasure = 'kg'
    WHERE NOT EXISTS
    (
        SELECT 1 FROM dbo.RawStockBatches AS batch
        WHERE batch.BatchCode = CONCAT('DEMO-OPEN-', source.ItemCode)
    );

    UPDATE balance
    SET QuantityOnHand = totals.QuantityOnHand,
        WeightedAverageUnitCost = source.UnitCost,
        LastReceiptAtUtc = @Now
    FROM dbo.RawStockBalances AS balance
    INNER JOIN dbo.RawStockItems AS item
        ON item.RawStockItemId = balance.RawStockItemId
    INNER JOIN @RawStock AS source ON source.ItemCode = item.ItemCode
    CROSS APPLY
    (
        SELECT COALESCE(SUM(batch.QuantityRemaining), 0) AS QuantityOnHand
        FROM dbo.RawStockBatches AS batch
        WHERE batch.RawStockBalanceId = balance.RawStockBalanceId
          AND batch.Status = 'Available'
    ) AS totals
    WHERE balance.WarehouseSectionId = @WarehouseSectionId
      AND balance.UnitOfMeasure = 'kg';

    UPDATE movement
    SET RawStockBalanceId = balance.RawStockBalanceId,
        RawStockBatchId = batch.RawStockBatchId,
        CreatedByUserId = @ActorUserId,
        QuantityChange = source.OpeningQuantity,
        UnitCost = source.UnitCost,
        OccurredAtUtc = @Now,
        ReasonText = 'Final presentation opening Raw Stock'
    FROM dbo.RawStockMovements AS movement
    INNER JOIN @RawStock AS source ON movement.SourceId = source.ItemCode
    INNER JOIN dbo.RawStockItems AS item ON item.ItemCode = source.ItemCode
    INNER JOIN dbo.RawStockBalances AS balance
        ON balance.RawStockItemId = item.RawStockItemId
       AND balance.WarehouseSectionId = @WarehouseSectionId
       AND balance.UnitOfMeasure = 'kg'
    INNER JOIN dbo.RawStockBatches AS batch
        ON batch.BatchCode = CONCAT('DEMO-OPEN-', source.ItemCode)
    WHERE movement.SourceType = 'PresentationSeed';

    INSERT dbo.RawStockMovements
    (
        RawStockItemId,
        RawStockBalanceId,
        RawStockBatchId,
        OperationalReasonId,
        CreatedByUserId,
        MovementType,
        QuantityChange,
        UnitCost,
        OccurredAtUtc,
        SourceType,
        SourceId,
        ReasonText,
        CorrelationId
    )
    SELECT item.RawStockItemId,
           balance.RawStockBalanceId,
           batch.RawStockBatchId,
           NULL,
           @ActorUserId,
           'OpeningBalance',
           source.OpeningQuantity,
           source.UnitCost,
           @Now,
           'PresentationSeed',
           source.ItemCode,
           'Final presentation opening Raw Stock',
           'final-presentation-opening-stock'
    FROM @RawStock AS source
    INNER JOIN dbo.RawStockItems AS item ON item.ItemCode = source.ItemCode
    INNER JOIN dbo.RawStockBalances AS balance
        ON balance.RawStockItemId = item.RawStockItemId
       AND balance.WarehouseSectionId = @WarehouseSectionId
       AND balance.UnitOfMeasure = 'kg'
    INNER JOIN dbo.RawStockBatches AS batch
        ON batch.BatchCode = CONCAT('DEMO-OPEN-', source.ItemCode)
    WHERE NOT EXISTS
    (
        SELECT 1 FROM dbo.RawStockMovements AS movement
        WHERE movement.SourceType = 'PresentationSeed'
          AND movement.SourceId = source.ItemCode
    );

    DECLARE @Recipes table
    (
        ProductName nvarchar(150) NOT NULL,
        ItemCode nvarchar(40) NOT NULL,
        Quantity decimal(18,4) NOT NULL,
        PRIMARY KEY (ProductName, ItemCode)
    );

    INSERT @Recipes (ProductName, ItemCode, Quantity)
    VALUES
        ('Granny Smith Apples', 'RAW-FRU-GRANNY', 3.000),
        ('Pink Lady Apples', 'RAW-FRU-PINK', 3.000),
        ('Mondial Potatoes', 'RAW-VEG-MONDIAL', 10.000),
        ('Sifra Potatoes', 'RAW-VEG-SIFRA', 10.000),
        ('Jam Tomatoes', 'RAW-VEG-JAMTOM', 6.000),
        ('Nantes Carrots', 'RAW-VEG-NANTES', 5.000),
        ('Brown Onions', 'RAW-VEG-BROWN-ONION', 10.000),
        ('Robot Peppers', 'RAW-VEG-ROBOT-PEPPER', 3.000),
        ('Garden Salad Mix', 'RAW-VEG-ICEBERG', 0.450),
        ('Garden Salad Mix', 'RAW-VEG-CUCUMBER', 0.200),
        ('Garden Salad Mix', 'RAW-VEG-JAMTOM', 0.200),
        ('Garden Salad Mix', 'RAW-VEG-NANTES', 0.150),
        ('Fruit Salad Mix', 'RAW-FRU-GRANNY', 0.300),
        ('Fruit Salad Mix', 'RAW-FRU-PINK', 0.250),
        ('Fruit Salad Mix', 'RAW-FRU-PINEAPPLE', 0.250),
        ('Fruit Salad Mix', 'RAW-FRU-GRAPES', 0.200);

    UPDATE requirement
    SET RawQuantityPerProductUnit = source.Quantity,
        UnitOfMeasure = 'kg',
        WastePercentage = 0,
        YieldPercentage = 100,
        IsActive = 1,
        UpdatedByUserId = @ActorUserId,
        UpdatedAtUtc = @Now
    FROM dbo.ProductRawStockRequirements AS requirement
    INNER JOIN dbo.Product AS product ON product.ProductId = requirement.ProductId
    INNER JOIN dbo.RawStockItems AS item
        ON item.RawStockItemId = requirement.RawStockItemId
    INNER JOIN @Recipes AS source
        ON source.ProductName = product.ProductName
       AND source.ItemCode = item.ItemCode;

    INSERT dbo.ProductRawStockRequirements
    (
        ProductId,
        RawStockItemId,
        RawQuantityPerProductUnit,
        UnitOfMeasure,
        WastePercentage,
        YieldPercentage,
        IsActive,
        CreatedByUserId,
        CreatedAtUtc
    )
    SELECT product.ProductId,
           item.RawStockItemId,
           source.Quantity,
           'kg',
           0,
           100,
           1,
           @ActorUserId,
           @Now
    FROM @Recipes AS source
    INNER JOIN dbo.Product AS product
        ON product.ProductName = source.ProductName
    INNER JOIN dbo.RawStockItems AS item ON item.ItemCode = source.ItemCode
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM dbo.ProductRawStockRequirements AS requirement
        WHERE requirement.ProductId = product.ProductId
          AND requirement.RawStockItemId = item.RawStockItemId
    );

    UPDATE requirement
    SET IsActive = 0,
        UpdatedByUserId = @ActorUserId,
        UpdatedAtUtc = @Now
    FROM dbo.ProductRawStockRequirements AS requirement
    INNER JOIN dbo.Product AS product ON product.ProductId = requirement.ProductId
    INNER JOIN dbo.RawStockItems AS item
        ON item.RawStockItemId = requirement.RawStockItemId
    WHERE product.ProductName IN (SELECT ProductName FROM @Products)
      AND NOT EXISTS
      (
          SELECT 1 FROM @Recipes AS source
          WHERE source.ProductName = product.ProductName
            AND source.ItemCode = item.ItemCode
      );

    --------------------------------------------------------------------------
    -- Fictional South African-style Customers and produce Suppliers
    --------------------------------------------------------------------------
    DECLARE @Customers table
    (
        CustomerNumber nvarchar(30) NOT NULL PRIMARY KEY,
        CustomerName nvarchar(150) NOT NULL,
        ContactPerson nvarchar(150) NOT NULL,
        Email nvarchar(254) NOT NULL,
        Phone nvarchar(30) NOT NULL,
        Area nvarchar(200) NOT NULL
    );

    INSERT @Customers
        (CustomerNumber, CustomerName, ContactPerson, Email, Phone, Area)
    VALUES
        ('CUST-001', 'Mamelodi Fresh Foods', 'Demo Contact 01', 'orders01@example.invalid', '0120001001', 'Mamelodi, Gauteng'),
        ('CUST-002', 'Pretoria Central Caterers', 'Demo Contact 02', 'orders02@example.invalid', '0120001002', 'Pretoria Central, Gauteng'),
        ('CUST-003', 'Soshanguve School Nutrition Services', 'Demo Contact 03', 'orders03@example.invalid', '0120001003', 'Soshanguve, Gauteng'),
        ('CUST-004', 'Centurion Community Kitchen', 'Demo Contact 04', 'orders04@example.invalid', '0120001004', 'Centurion, Gauteng'),
        ('CUST-005', 'Hammanskraal Food Services', 'Demo Contact 05', 'orders05@example.invalid', '0120001005', 'Hammanskraal, Gauteng'),
        ('CUST-006', 'Atteridgeville Catering Solutions', 'Demo Contact 06', 'orders06@example.invalid', '0120001006', 'Atteridgeville, Gauteng'),
        ('CUST-007', 'Midrand Meal Prep Kitchen', 'Demo Contact 07', 'orders07@example.invalid', '0120001007', 'Midrand, Gauteng'),
        ('CUST-008', 'Ga-Rankuwa Catering Collective', 'Demo Contact 08', 'orders08@example.invalid', '0120001008', 'Ga-Rankuwa, Gauteng'),
        ('CUST-009', 'Menlyn Office Catering', 'Demo Contact 09', 'orders09@example.invalid', '0120001009', 'Menlyn, Gauteng'),
        ('CUST-010', 'Pretoria East Fresh Kitchen', 'Demo Contact 10', 'orders10@example.invalid', '0120001010', 'Pretoria East, Gauteng');

    UPDATE customer
    SET CustomerName = source.CustomerName,
        Email = source.Email,
        NormalizedEmail = UPPER(source.Email),
        ContactPerson = source.ContactPerson,
        PhoneNumber = source.Phone,
        BillingAddress = source.Area,
        DeliveryAddress = source.Area,
        Status = 'Active',
        UpdatedAtUtc = @Now
    FROM dbo.Customers AS customer
    INNER JOIN @Customers AS source
        ON source.CustomerNumber = customer.CustomerNumber;

    INSERT dbo.Customers
    (
        CustomerNumber,
        CustomerName,
        Email,
        NormalizedEmail,
        ContactPerson,
        PhoneNumber,
        BillingAddress,
        DeliveryAddress,
        Status,
        CreatedAtUtc
    )
    SELECT source.CustomerNumber,
           source.CustomerName,
           source.Email,
           UPPER(source.Email),
           source.ContactPerson,
           source.Phone,
           source.Area,
           source.Area,
           'Active',
           @Now
    FROM @Customers AS source
    WHERE NOT EXISTS
    (
        SELECT 1 FROM dbo.Customers AS customer
        WHERE customer.CustomerNumber = source.CustomerNumber
    );

    DECLARE @Suppliers table
    (
        SupplierCode nvarchar(40) NOT NULL PRIMARY KEY,
        SupplierName nvarchar(200) NOT NULL,
        SupplierTypeCode nvarchar(40) NOT NULL,
        Area nvarchar(200) NOT NULL
    );

    INSERT @Suppliers (SupplierCode, SupplierName, SupplierTypeCode, Area)
    VALUES
        ('SUP-001', 'Tshwane Market Produce Agency', @MarketAgencyCode, 'Tshwane Fresh Produce Market, Gauteng'),
        ('SUP-002', 'Gauteng Fresh Produce Agency', @MarketAgencyCode, 'Pretoria, Gauteng'),
        ('SUP-003', 'Highveld Potato Growers', @DirectSupplierCode, 'Highveld region'),
        ('SUP-004', 'Limpopo Fresh Harvest', @DirectSupplierCode, 'Limpopo'),
        ('SUP-005', 'Cape Orchard Produce', @DirectSupplierCode, 'Western Cape'),
        ('SUP-006', 'Vaal Valley Vegetable Supply', @DirectSupplierCode, 'Vaal Triangle, Gauteng'),
        ('SUP-007', 'Mpumalanga Farm Fresh Distributors', @DirectSupplierCode, 'Mpumalanga'),
        ('SUP-008', 'North West Produce Collective', @DirectSupplierCode, 'North West'),
        ('SUP-009', 'Lowveld Fruit & Vegetable Supply', @DirectSupplierCode, 'Lowveld region'),
        ('SUP-010', 'Pretoria Fresh Produce Traders', @MarketAgencyCode, 'Pretoria, Gauteng');

    UPDATE supplier
    SET SupplierName = source.SupplierName,
        SupplierTypeCode = source.SupplierTypeCode,
        ContactPerson = CONCAT('Demo Supplier Contact ', RIGHT(source.SupplierCode, 3)),
        Email = CONCAT(LOWER(source.SupplierCode), '@example.invalid'),
        NormalizedEmail = UPPER(CONCAT(LOWER(source.SupplierCode), '@example.invalid')),
        Phone = CONCAT('0120002', RIGHT(source.SupplierCode, 3)),
        Address = source.Area,
        Status = 'Active',
        UpdatedAtUtc = @Now
    FROM dbo.Suppliers AS supplier
    INNER JOIN @Suppliers AS source ON source.SupplierCode = supplier.SupplierCode;

    INSERT dbo.Suppliers
    (
        SupplierName,
        SupplierCode,
        SupplierTypeCode,
        ContactPerson,
        Email,
        NormalizedEmail,
        Phone,
        Address,
        Status,
        CreatedAtUtc
    )
    SELECT source.SupplierName,
           source.SupplierCode,
           source.SupplierTypeCode,
           CONCAT('Demo Supplier Contact ', RIGHT(source.SupplierCode, 3)),
           CONCAT(LOWER(source.SupplierCode), '@example.invalid'),
           UPPER(CONCAT(LOWER(source.SupplierCode), '@example.invalid')),
           CONCAT('0120002', RIGHT(source.SupplierCode, 3)),
           source.Area,
           'Active',
           @Now
    FROM @Suppliers AS source
    WHERE NOT EXISTS
    (
        SELECT 1 FROM dbo.Suppliers AS supplier
        WHERE supplier.SupplierCode = source.SupplierCode
    );

    COMMIT TRANSACTION;

    --------------------------------------------------------------------------
    -- Verification output
    --------------------------------------------------------------------------
    SELECT ProductCategoryId, ProductCategoryName, Status
    FROM dbo.ProductCategory
    WHERE Status = 'Active'
    ORDER BY ProductCategoryName;

    SELECT ProductTypeId, ProductTypeName, Status
    FROM dbo.ProductType
    WHERE Status = 'Active'
    ORDER BY ProductTypeName;

    SELECT category.ProductCategoryName, productType.ProductTypeName
    FROM dbo.ProductCategoryTypes AS link
    INNER JOIN dbo.ProductCategory AS category
        ON category.ProductCategoryId = link.ProductCategoryId
    INNER JOIN dbo.ProductType AS productType
        ON productType.ProductTypeId = link.ProductTypeId
    WHERE category.Status = 'Active' AND productType.Status = 'Active'
    ORDER BY category.ProductCategoryName, productType.ProductTypeName;

    SELECT product.ProductName,
           category.ProductCategoryName,
           productType.ProductTypeName,
           product.Size,
           product.ShelfLifeDays,
           price.SellingPrice,
           product.Status
    FROM dbo.Product AS product
    INNER JOIN dbo.ProductCategory AS category
        ON category.ProductCategoryId = product.ProductCategoryId
    INNER JOIN dbo.ProductType AS productType
        ON productType.ProductTypeId = product.ProductTypeId
    LEFT JOIN dbo.ProductPrices AS price
        ON price.ProductId = product.ProductId
       AND price.IsCurrent = 1
       AND price.IsDeleted = 0
    WHERE product.ProductName IN (SELECT ProductName FROM @Products)
    ORDER BY product.ProductName;

    SELECT item.ItemCode,
           item.ItemName,
           balance.QuantityOnHand,
           balance.WeightedAverageUnitCost,
           batch.BatchCode,
           batch.QuantityRemaining,
           batch.BestBeforeAtUtc,
           batch.Status
    FROM dbo.RawStockItems AS item
    INNER JOIN @RawStock AS source ON source.ItemCode = item.ItemCode
    INNER JOIN dbo.RawStockBalances AS balance
        ON balance.RawStockItemId = item.RawStockItemId
       AND balance.WarehouseSectionId = @WarehouseSectionId
       AND balance.UnitOfMeasure = 'kg'
    INNER JOIN dbo.RawStockBatches AS batch
        ON batch.BatchCode = CONCAT('DEMO-OPEN-', item.ItemCode)
    ORDER BY item.ItemCode;

    SELECT product.ProductName,
           item.ItemName AS RawStockItem,
           requirement.RawQuantityPerProductUnit,
           requirement.UnitOfMeasure,
           requirement.YieldPercentage,
           requirement.WastePercentage,
           requirement.IsActive
    FROM dbo.ProductRawStockRequirements AS requirement
    INNER JOIN dbo.Product AS product ON product.ProductId = requirement.ProductId
    INNER JOIN dbo.RawStockItems AS item
        ON item.RawStockItemId = requirement.RawStockItemId
    WHERE product.ProductName IN (SELECT ProductName FROM @Products)
    ORDER BY product.ProductName, item.ItemName;

    SELECT CustomerNumber, CustomerName, Email, PhoneNumber, Status
    FROM dbo.Customers
    WHERE CustomerNumber IN (SELECT CustomerNumber FROM @Customers)
    ORDER BY CustomerNumber;

    SELECT SupplierCode, SupplierName, SupplierTypeCode, Status
    FROM dbo.Suppliers
    WHERE SupplierCode IN (SELECT SupplierCode FROM @Suppliers)
    ORDER BY SupplierCode;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
