/*
    PhenyoSync Iteration 5 verification queries.
    Read-only: this script does not apply the migration or change business data.
*/

SELECT MigrationId, ProductVersion
FROM dbo.__EFMigrationsHistory
WHERE MigrationId =
    '20260816171840_Iteration5ProcurementProductionAndOrderIntake';

SELECT name
FROM sys.tables
WHERE name IN
(
    'ExternalOrderSubmissions',
    'PackingConversions',
    'PackingConversionRawStock'
)
ORDER BY name;

SELECT c.name AS ColumnName, t.name AS DataType, c.is_nullable
FROM sys.columns AS c
INNER JOIN sys.types AS t
    ON t.user_type_id = c.user_type_id
WHERE c.object_id = OBJECT_ID('dbo.Users')
  AND c.name = 'RequireTwoFactorOnNextWebLogin';

SELECT i.name AS IndexName, i.is_unique
FROM sys.indexes AS i
WHERE i.object_id = OBJECT_ID('dbo.ExternalOrderSubmissions')
  AND i.name = 'UX_ExternalOrderSubmissions_Source_Key';

SELECT i.name AS IndexName, i.is_unique
FROM sys.indexes AS i
WHERE i.object_id = OBJECT_ID('dbo.PackingConversions')
  AND i.name = 'UX_PackingConversions_ProductBatch';

SELECT HelpTopicId, Slug, Title, IsPublished
FROM dbo.HelpTopics
WHERE HelpTopicId IN (36, 37)
ORDER BY HelpTopicId;

SELECT HelpContextMappingId, RoutePattern, ComponentKey, HelpTopicId
FROM dbo.HelpContextMappings
WHERE HelpContextMappingId IN (41, 42, 43)
ORDER BY HelpContextMappingId;
